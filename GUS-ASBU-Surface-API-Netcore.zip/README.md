# hello.netcore-22.aws
hello.netcore-22.aws
