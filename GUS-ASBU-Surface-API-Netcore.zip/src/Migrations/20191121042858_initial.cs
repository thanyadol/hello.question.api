﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace surflex.netcore22.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "dbo");

            migrationBuilder.CreateTable(
                name: "__EFLoggingEvent",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Level = table.Column<string>(maxLength: 128, nullable: true),
                    TimeStamp = table.Column<DateTimeOffset>(nullable: false),
                    CAI = table.Column<string>(nullable: true),
                    Message = table.Column<string>(nullable: true),
                    MessageTemplate = table.Column<string>(nullable: true),
                    Exception = table.Column<string>(nullable: true),
                    Type = table.Column<string>(maxLength: 20, nullable: true),
                    ErrorCode = table.Column<string>(nullable: true),
                    RequestId = table.Column<Guid>(nullable: false),
                    RequestPath = table.Column<string>(maxLength: 500, nullable: true),
                    RequestScheme = table.Column<string>(maxLength: 500, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Date = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK___EFLoggingEvent", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Api",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Url = table.Column<string>(maxLength: 500, nullable: true),
                    Endpoint = table.Column<string>(maxLength: 500, nullable: true),
                    Params = table.Column<string>(maxLength: 500, nullable: true),
                    Type = table.Column<string>(maxLength: 10, nullable: true),
                    IsRequireAuthentication = table.Column<bool>(nullable: false),
                    Description = table.Column<string>(maxLength: 500, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Api", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Area",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    Name = table.Column<string>(maxLength: 100, nullable: true),
                    HcType = table.Column<string>(maxLength: 10, nullable: true),
                    Type = table.Column<string>(maxLength: 10, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Description = table.Column<string>(maxLength: 50, nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Area", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Attachment",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    Value = table.Column<string>(nullable: true),
                    Name = table.Column<string>(maxLength: 500, nullable: true),
                    Path = table.Column<string>(maxLength: 500, nullable: true),
                    Title = table.Column<string>(maxLength: 500, nullable: true),
                    Size = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Extension = table.Column<string>(maxLength: 10, nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    Description = table.Column<string>(maxLength: 1000, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Checksum = table.Column<string>(maxLength: 500, nullable: true),
                    Storage = table.Column<string>(maxLength: 50, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Attachment", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Job",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    WellId = table.Column<string>(maxLength: 50, nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    Type = table.Column<string>(maxLength: 10, nullable: true),
                    Activity = table.Column<string>(maxLength: 10, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Job", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Module",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(maxLength: 100, nullable: true),
                    Type = table.Column<string>(maxLength: 10, nullable: true),
                    Description = table.Column<string>(maxLength: 500, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Module", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Page",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Parent = table.Column<Guid>(nullable: true),
                    Title = table.Column<string>(maxLength: 100, nullable: true),
                    Sub = table.Column<string>(maxLength: 20, nullable: true),
                    Url = table.Column<string>(maxLength: 100, nullable: true),
                    Params = table.Column<string>(maxLength: 100, nullable: true),
                    Order = table.Column<int>(nullable: false),
                    Type = table.Column<string>(maxLength: 10, nullable: true),
                    Description = table.Column<string>(maxLength: 500, nullable: true),
                    IsRequireAuthentication = table.Column<bool>(nullable: false),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Page", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PeriodPrice",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    PriceId = table.Column<Guid>(nullable: false),
                    Value = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Year = table.Column<int>(nullable: false),
                    Month = table.Column<int>(nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PeriodPrice", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Platform",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    Name = table.Column<string>(maxLength: 100, nullable: true),
                    Country = table.Column<string>(maxLength: 20, nullable: true),
                    Description = table.Column<string>(maxLength: 100, nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Platform", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PresetWellScenario",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(maxLength: 50, nullable: true),
                    Description = table.Column<string>(maxLength: 255, nullable: true),
                    Status = table.Column<string>(maxLength: 50, nullable: true),
                    By = table.Column<string>(maxLength: 255, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true),
                    Updated = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PresetWellScenario", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Price",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(maxLength: 100, nullable: true),
                    HcType = table.Column<string>(maxLength: 10, nullable: true),
                    AreaId = table.Column<string>(maxLength: 50, nullable: true),
                    Unit = table.Column<string>(nullable: true),
                    Type = table.Column<string>(nullable: true),
                    Description = table.Column<string>(maxLength: 1000, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Structure = table.Column<string>(maxLength: 100, nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    TemplateId = table.Column<string>(maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Price", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Production",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    Name = table.Column<string>(maxLength: 100, nullable: true),
                    Asset = table.Column<string>(maxLength: 100, nullable: true),
                    Condition = table.Column<string>(maxLength: 50, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Key = table.Column<string>(maxLength: 50, nullable: true),
                    Rev = table.Column<string>(maxLength: 50, nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    StartDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    FinishDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    IsGasModelApplicable = table.Column<bool>(nullable: false),
                    IsOilModelApplicable = table.Column<bool>(nullable: false),
                    IsSeparateModelApplicable = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Production", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ProductionParam",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    ProductionProfileId = table.Column<string>(maxLength: 50, nullable: true),
                    Value = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    Name = table.Column<string>(maxLength: 10, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductionParam", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ProductionProfile",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    ProductionId = table.Column<string>(maxLength: 50, nullable: true),
                    EVFormulaForIPCDRATE = table.Column<string>(maxLength: 50, nullable: true),
                    Value = table.Column<decimal>(type: "decimal(18,1)", nullable: true),
                    AbandonmentRate = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    HoldupPercentage = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    ValueType = table.Column<string>(maxLength: 10, nullable: true),
                    ApplicableModel = table.Column<string>(maxLength: 10, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductionProfile", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Project",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    Name = table.Column<string>(maxLength: 20, nullable: true),
                    RLLCPReferenceId = table.Column<int>(nullable: true),
                    Status = table.Column<string>(nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true),
                    Description = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Project", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ProjectActivity",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    ProjectSpaceId = table.Column<string>(maxLength: 50, nullable: true),
                    Discriminator = table.Column<string>(maxLength: 50, nullable: true),
                    Action = table.Column<string>(maxLength: 50, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProjectActivity", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ProjectAttribute",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    ProjectId = table.Column<string>(maxLength: 50, nullable: true),
                    BgProfileId = table.Column<int>(nullable: true),
                    BoProfileId = table.Column<int>(nullable: true),
                    TotalPlannedWell = table.Column<int>(nullable: true),
                    ProductionProfileId = table.Column<string>(maxLength: 50, nullable: true),
                    ApplicableModelId = table.Column<string>(maxLength: 50, nullable: true),
                    OilProjectStartDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    GasProjectStartDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    ProjectCutOffDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    RampUpDay = table.Column<int>(nullable: true),
                    ShiftStartDay = table.Column<int>(nullable: true),
                    Description = table.Column<string>(maxLength: 1000, nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    StartDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    FinishDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProjectAttribute", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ProjectDrilled",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    AttachmentId = table.Column<string>(maxLength: 50, nullable: true),
                    TemplateTypeId = table.Column<string>(maxLength: 50, nullable: true),
                    ProjectSpaceId = table.Column<string>(maxLength: 50, nullable: true),
                    ActualDPI = table.Column<decimal>(type: "decimal(28,10)", nullable: true),
                    PlannedDPI = table.Column<decimal>(type: "decimal(28,10)", nullable: true),
                    Type = table.Column<string>(maxLength: 10, nullable: true),
                    Key = table.Column<string>(maxLength: 50, nullable: true),
                    Rev = table.Column<string>(maxLength: 50, nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    StartDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    FinishDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProjectDrilled", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ProjectLocation",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    ProjectId = table.Column<string>(maxLength: 50, nullable: true),
                    LocationId = table.Column<string>(maxLength: 50, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProjectLocation", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ProjectSpace",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    ProjectId = table.Column<string>(maxLength: 50, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Description = table.Column<string>(maxLength: 1000, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProjectSpace", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ProjectWell",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    Key = table.Column<string>(maxLength: 50, nullable: true),
                    Rev = table.Column<string>(maxLength: 50, nullable: true),
                    ProjectSpaceId = table.Column<string>(maxLength: 50, nullable: true),
                    StartDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    FinishDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProjectWell", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Resource",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    Name = table.Column<string>(maxLength: 500, nullable: true),
                    Type = table.Column<string>(maxLength: 10, nullable: true),
                    Description = table.Column<string>(maxLength: 1000, nullable: true),
                    Key = table.Column<string>(maxLength: 50, nullable: true),
                    Rev = table.Column<string>(maxLength: 50, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Resource", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ResourceLibrary",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    Formular = table.Column<string>(maxLength: 550, nullable: true),
                    ResourceType = table.Column<string>(maxLength: 50, nullable: true),
                    QueryParam = table.Column<string>(maxLength: 500, nullable: true),
                    Key = table.Column<string>(maxLength: 50, nullable: true),
                    Rev = table.Column<string>(maxLength: 50, nullable: true),
                    Name = table.Column<string>(maxLength: 100, nullable: true),
                    ValueType = table.Column<string>(maxLength: 20, nullable: true),
                    Value = table.Column<decimal>(type: "decimal(28,10)", nullable: true),
                    PlannerType = table.Column<string>(maxLength: 20, nullable: true),
                    Section = table.Column<string>(maxLength: 20, nullable: true),
                    Type = table.Column<string>(maxLength: 20, nullable: true),
                    IsReadonly = table.Column<bool>(nullable: false),
                    Description = table.Column<string>(maxLength: 500, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true),
                    StartDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    FinishDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ResourceLibrary", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ResourceTask",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    ResourceId = table.Column<string>(maxLength: 50, nullable: true),
                    LibraryId = table.Column<string>(maxLength: 50, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ResourceTask", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Rigg",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    Name = table.Column<string>(maxLength: 100, nullable: true),
                    Type = table.Column<string>(maxLength: 10, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Description = table.Column<string>(maxLength: 1000, nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Rigg", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RiggRate",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    RiggId = table.Column<string>(maxLength: 50, nullable: true),
                    TemplateId = table.Column<string>(maxLength: 50, nullable: true),
                    TIH = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    TOH = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Type = table.Column<string>(maxLength: 10, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Activity = table.Column<string>(maxLength: 100, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RiggRate", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Role",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(maxLength: 100, nullable: true),
                    LocationId = table.Column<string>(maxLength: 50, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Type = table.Column<string>(maxLength: 10, nullable: true),
                    Description = table.Column<string>(maxLength: 500, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Role", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Sand",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    WellDrilledId = table.Column<Guid>(nullable: false),
                    TopMD = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    BaseMD = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    Pos = table.Column<decimal>(type: "decimal(18, 2)", nullable: true),
                    Usi = table.Column<string>(maxLength: 50, nullable: true),
                    Iwd = table.Column<string>(maxLength: 20, nullable: true),
                    OpenWorksContactCategory = table.Column<string>(maxLength: 10, nullable: true),
                    Name = table.Column<string>(maxLength: 20, nullable: true),
                    SandReserveCategory = table.Column<string>(maxLength: 5, nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    OilP1DNWithoutBC = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    OilP1DNWithBC = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    CondensateP1DNWithBC = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    FreeGasP1DNWithoutBC = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    FreeGasP1DNWithBC = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    SolutionGasP1DNWithBC = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    HCLiquidWithBC = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    HCGasWithBC = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    PayClassification = table.Column<string>(maxLength: 20, nullable: true),
                    PressureRFTInPSI = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    PressureRFTInPPG = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    PressureEstimatedInitialInPSI = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    PressureEstimatedInitialInPPG = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    PressurePPi = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    FVFProfileBoProfile = table.Column<string>(nullable: true),
                    FVFProfileBgProfile = table.Column<string>(nullable: true),
                    FVFProfileBoProfileId = table.Column<int>(nullable: true),
                    FVFProfileBgProfileId = table.Column<int>(nullable: true),
                    FVFProfileBoValue = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    FVFProfileBgValue = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    AnalogyOilAreaScenarioId = table.Column<int>(nullable: true),
                    AnalogyGasAreaScenarioId = table.Column<int>(nullable: true),
                    AnalogyOilAreaSetId = table.Column<int>(nullable: true),
                    AnalogyGasAreaSetId = table.Column<int>(nullable: true),
                    AnalogyOilAreaName = table.Column<string>(maxLength: 500, nullable: true),
                    AnalogyOilAreaDiscountFactor = table.Column<string>(maxLength: 500, nullable: true),
                    AnalogyGasAreaName = table.Column<string>(maxLength: 500, nullable: true),
                    AnalogyGasAreaDiscountFactor = table.Column<string>(maxLength: 500, nullable: true),
                    AnalogyOilArea = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    AnalogyGasArea = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    DiscountFactorOilDepletion = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    DiscountFactorGasDepletion = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    DiscountFactorMechanical = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    DiscountFactorCementQuality = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    DiscountFactorCO2 = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    DiscountFactorBC = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    InPlaceByVolumetricOOIP = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    InPlaceByVolumetricOGIP = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    RecoveryEfficiencyOil = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    RecoveryEfficiencyGas = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    GrossIntervalFrom = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    GrossIntervalTo = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    TopTVDSS = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    BaseTVDSS = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    GocTVDSS = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    HwcTVDSS = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    GrossSandMT = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    GrossSandVT = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    NetGasVT = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    NetOilVT = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    MaximumResistivity = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    Vsh = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    AvgPor = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    AvgSw = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    TG = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    Fluid = table.Column<string>(maxLength: 10, nullable: true),
                    Remarks = table.Column<string>(maxLength: 1000, nullable: true),
                    AZI = table.Column<string>(maxLength: 10, nullable: true),
                    LookupRenderingOilRF = table.Column<string>(maxLength: 10, nullable: true),
                    LookupRenderingGasRF = table.Column<string>(maxLength: 10, nullable: true),
                    LookupRenderingOilBCIncremental = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    LookupRenderingGasBCIncremental = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    EstPhase = table.Column<string>(maxLength: 10, nullable: true),
                    IsValidate = table.Column<bool>(nullable: false),
                    ErrorMessage = table.Column<string>(maxLength: 1000, nullable: true),
                    DataSource = table.Column<string>(maxLength: 20, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    SORUpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Sand", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SessionLogg",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Token = table.Column<string>(maxLength: 1000, nullable: true),
                    UserId = table.Column<string>(maxLength: 50, nullable: true),
                    CAI = table.Column<string>(maxLength: 10, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    TokenExpiredDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SessionLogg", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Template",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    AttachmentId = table.Column<string>(maxLength: 50, nullable: true),
                    Name = table.Column<string>(maxLength: 500, nullable: true),
                    Description = table.Column<string>(maxLength: 1000, nullable: true),
                    TemplateTypeId = table.Column<string>(maxLength: 50, nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true),
                    Key = table.Column<string>(maxLength: 50, nullable: true),
                    Rev = table.Column<string>(maxLength: 50, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    StartDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    FinishDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Template", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "User",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    ADId = table.Column<Guid>(nullable: false),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    CAI = table.Column<string>(maxLength: 50, nullable: true),
                    DisplayName = table.Column<string>(maxLength: 100, nullable: true),
                    GivenName = table.Column<string>(maxLength: 100, nullable: true),
                    AccountName = table.Column<string>(maxLength: 100, nullable: true),
                    Name = table.Column<string>(maxLength: 200, nullable: true),
                    Unique = table.Column<string>(maxLength: 50, nullable: true),
                    Email = table.Column<string>(maxLength: 100, nullable: true),
                    EmployeeId = table.Column<string>(maxLength: 50, nullable: true),
                    IsADEnable = table.Column<bool>(nullable: false),
                    ADGroup = table.Column<string>(maxLength: 50, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_User", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "UserActivity",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Discriminator = table.Column<string>(maxLength: 50, nullable: true),
                    Action = table.Column<string>(maxLength: 50, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserActivity", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Well",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    Name = table.Column<string>(maxLength: 100, nullable: true),
                    ProjectId = table.Column<string>(maxLength: 50, nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Well", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "WellActivity",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    WellSpaceId = table.Column<Guid>(nullable: false),
                    Discriminator = table.Column<string>(maxLength: 50, nullable: true),
                    Action = table.Column<string>(maxLength: 50, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WellActivity", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "WellDrilled",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    WellSpaceId = table.Column<Guid>(nullable: false),
                    Key = table.Column<string>(maxLength: 50, nullable: true),
                    Rev = table.Column<string>(maxLength: 50, nullable: true),
                    CalculatedWellReserve = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    Datasource = table.Column<string>(nullable: true),
                    SORUpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    WellType = table.Column<string>(nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    TotalCalculateRecord = table.Column<int>(nullable: false),
                    CalculatedTimestamp = table.Column<string>(nullable: true),
                    CompleteCalculatedRecord = table.Column<int>(nullable: false),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true),
                    StartDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    FinishDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    GOR = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    CGR = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    PipelinePressure = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    BcPos = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    BcCompressionRatio = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    OilPipelinePressureCoeff = table.Column<decimal>(type: "decimal(36, 18)", nullable: true),
                    GasPipelinePressureCoeff = table.Column<decimal>(type: "decimal(36, 18)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WellDrilled", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "WellProperties",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    WellId = table.Column<string>(maxLength: 50, nullable: true),
                    ProjectWellId = table.Column<string>(maxLength: 50, nullable: true),
                    FaultBlock = table.Column<string>(maxLength: 10, nullable: true),
                    BatchNumber = table.Column<int>(nullable: true),
                    DrillingOrder = table.Column<int>(nullable: false),
                    ChartOrder = table.Column<int>(nullable: true),
                    Type = table.Column<string>(maxLength: 50, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Description = table.Column<string>(maxLength: 1000, nullable: true),
                    IsIncludeToCalculated = table.Column<bool>(nullable: false),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WellProperties", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "WellSpace",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    WellId = table.Column<string>(maxLength: 50, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Description = table.Column<string>(maxLength: 1000, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WellSpace", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "WellUndrilled",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    WellSpaceId = table.Column<Guid>(nullable: false),
                    CalculatedTimestamp = table.Column<string>(nullable: true),
                    WellName = table.Column<string>(maxLength: 50, nullable: true),
                    UndrilledMethod = table.Column<string>(maxLength: 50, nullable: true),
                    IsCalculatedReserve = table.Column<bool>(nullable: false),
                    LiquidInMBOE = table.Column<decimal>(type: "decimal(18, 10)", nullable: true),
                    GasInMMScf = table.Column<decimal>(type: "decimal(18, 10)", nullable: true),
                    TotalInMBOE = table.Column<decimal>(type: "decimal(18, 10)", nullable: true),
                    Datasource = table.Column<string>(nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    FinishDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    Key = table.Column<string>(maxLength: 50, nullable: true),
                    Rev = table.Column<string>(maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WellUndrilled", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ModulePage",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    ModuleId = table.Column<Guid>(nullable: false),
                    PageId = table.Column<Guid>(nullable: false),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    IsEnabled = table.Column<bool>(nullable: false),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ModulePage", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ModulePage_Module_ModuleId",
                        column: x => x.ModuleId,
                        principalSchema: "dbo",
                        principalTable: "Module",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ModulePage_Page_PageId",
                        column: x => x.PageId,
                        principalSchema: "dbo",
                        principalTable: "Page",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PageApi",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    PageId = table.Column<Guid>(nullable: false),
                    ApiId = table.Column<Guid>(nullable: false),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    WorkFlow = table.Column<string>(maxLength: 50, nullable: true),
                    IsEnabled = table.Column<bool>(nullable: false),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PageApi", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PageApi_Api_ApiId",
                        column: x => x.ApiId,
                        principalSchema: "dbo",
                        principalTable: "Api",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PageApi_Page_PageId",
                        column: x => x.PageId,
                        principalSchema: "dbo",
                        principalTable: "Page",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PresetDecisionNode",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(maxLength: 255, nullable: true),
                    Type = table.Column<string>(maxLength: 50, nullable: true),
                    X = table.Column<decimal>(type: "decimal(38, 4)", nullable: false),
                    Y = table.Column<decimal>(type: "decimal(38, 4)", nullable: false),
                    Created = table.Column<DateTime>(nullable: false),
                    ResourceId = table.Column<Guid>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PresetDecisionNode", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PresetDecisionNode_PresetWellScenario_ResourceId",
                        column: x => x.ResourceId,
                        principalSchema: "dbo",
                        principalTable: "PresetWellScenario",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "WellScenario",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(maxLength: 50, nullable: true),
                    Description = table.Column<string>(maxLength: 255, nullable: true),
                    Status = table.Column<string>(maxLength: 50, nullable: true),
                    By = table.Column<string>(maxLength: 255, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true),
                    Updated = table.Column<DateTime>(type: "datetime", nullable: true),
                    WellName = table.Column<string>(maxLength: 255, nullable: true),
                    ResourceId = table.Column<Guid>(nullable: false),
                    NewTD = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    MotorDepth = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    CurrentDepth = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    TrippedDepth = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    CurrentROP = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    NewROP = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    MotorROP = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    Case = table.Column<string>(maxLength: 50, nullable: true),
                    TIH = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    TOH = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    RigRate = table.Column<decimal>(type: "decimal(38, 18)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WellScenario", x => x.Id);
                    table.ForeignKey(
                        name: "FK_WellScenario_PresetWellScenario_ResourceId",
                        column: x => x.ResourceId,
                        principalSchema: "dbo",
                        principalTable: "PresetWellScenario",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "RoleModule",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    RoleId = table.Column<Guid>(nullable: false),
                    ModuleId = table.Column<Guid>(nullable: false),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    IsEnabled = table.Column<bool>(nullable: false),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    ProjectPermission = table.Column<string>(maxLength: 10, nullable: true),
                    RolePermission = table.Column<string>(maxLength: 10, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RoleModule", x => x.Id);
                    table.ForeignKey(
                        name: "FK_RoleModule_Module_ModuleId",
                        column: x => x.ModuleId,
                        principalSchema: "dbo",
                        principalTable: "Module",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_RoleModule_Role_RoleId",
                        column: x => x.RoleId,
                        principalSchema: "dbo",
                        principalTable: "Role",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ProjectAuthorize",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    ProjectId = table.Column<string>(maxLength: 50, nullable: true),
                    UserId = table.Column<string>(maxLength: 50, nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProjectAuthorize", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ProjectAuthorize_Project_ProjectId",
                        column: x => x.ProjectId,
                        principalSchema: "dbo",
                        principalTable: "Project",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProjectAuthorize_User_UserId",
                        column: x => x.UserId,
                        principalSchema: "dbo",
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "RoleAuthorize",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    RoleId = table.Column<Guid>(nullable: false),
                    UserId = table.Column<string>(maxLength: 50, nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RoleAuthorize", x => x.Id);
                    table.ForeignKey(
                        name: "FK_RoleAuthorize_Role_RoleId",
                        column: x => x.RoleId,
                        principalSchema: "dbo",
                        principalTable: "Role",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_RoleAuthorize_User_UserId",
                        column: x => x.UserId,
                        principalSchema: "dbo",
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "UserAuthen",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    UserId = table.Column<string>(maxLength: 50, nullable: true),
                    IsEnabled = table.Column<bool>(nullable: false),
                    Status = table.Column<string>(nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    ExpiredDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserAuthen", x => x.Id);
                    table.ForeignKey(
                        name: "FK_UserAuthen_User_UserId",
                        column: x => x.UserId,
                        principalSchema: "dbo",
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PresetDecisionEdge",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    ActivityId = table.Column<Guid>(nullable: true),
                    Label = table.Column<string>(maxLength: 255, nullable: true),
                    Payoff1 = table.Column<string>(maxLength: 50, nullable: true),
                    Payoff2 = table.Column<string>(maxLength: 50, nullable: true),
                    Probability = table.Column<string>(maxLength: 50, nullable: true),
                    Created = table.Column<DateTime>(nullable: false),
                    FromId = table.Column<Guid>(nullable: false),
                    ToId = table.Column<Guid>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PresetDecisionEdge", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PresetDecisionEdge_PresetDecisionNode_FromId",
                        column: x => x.FromId,
                        principalSchema: "dbo",
                        principalTable: "PresetDecisionNode",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PresetDecisionEdge_PresetDecisionNode_ToId",
                        column: x => x.ToId,
                        principalSchema: "dbo",
                        principalTable: "PresetDecisionNode",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DecisionOption",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    WellScenarioId = table.Column<Guid>(nullable: false),
                    Order = table.Column<int>(nullable: false),
                    Inv = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    Npv = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    Dpi = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    TotalBranchCost = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DecisionOption", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DecisionOption_WellScenario_WellScenarioId",
                        column: x => x.WellScenarioId,
                        principalSchema: "dbo",
                        principalTable: "WellScenario",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "WellScenarioNode",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(maxLength: 255, nullable: true),
                    Type = table.Column<string>(maxLength: 50, nullable: true),
                    X = table.Column<decimal>(type: "decimal(38, 4)", nullable: false),
                    Y = table.Column<decimal>(type: "decimal(38, 4)", nullable: false),
                    Created = table.Column<DateTime>(nullable: false),
                    ResourceId = table.Column<Guid>(nullable: false),
                    AdditionalCost = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    TotalCost = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    TotalInMBOE = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    GasInMMScf = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    LiquidInMBOE = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    INV = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    NPV = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    DPI = table.Column<decimal>(type: "decimal(38, 18)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WellScenarioNode", x => x.Id);
                    table.ForeignKey(
                        name: "FK_WellScenarioNode_WellScenario_ResourceId",
                        column: x => x.ResourceId,
                        principalSchema: "dbo",
                        principalTable: "WellScenario",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "WellScenarioTab",
                schema: "dbo",
                columns: table => new
                {
                    RevId = table.Column<Guid>(nullable: false),
                    TabId = table.Column<Guid>(nullable: false),
                    MasterVersionId = table.Column<Guid>(nullable: true),
                    WellScenarioId = table.Column<Guid>(nullable: false),
                    WellName = table.Column<string>(maxLength: 255, nullable: true),
                    Status = table.Column<string>(maxLength: 50, nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    By = table.Column<string>(maxLength: 255, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true),
                    Updated = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WellScenarioTab", x => x.RevId);
                    table.ForeignKey(
                        name: "FK_WellScenarioTab_WellScenarioTab_MasterVersionId",
                        column: x => x.MasterVersionId,
                        principalSchema: "dbo",
                        principalTable: "WellScenarioTab",
                        principalColumn: "RevId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_WellScenarioTab_WellScenario_WellScenarioId",
                        column: x => x.WellScenarioId,
                        principalSchema: "dbo",
                        principalTable: "WellScenario",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "DecisionOptionNode",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    DecisionOptionId = table.Column<Guid>(nullable: false),
                    ParentId = table.Column<Guid>(nullable: true),
                    Name = table.Column<string>(maxLength: 255, nullable: true),
                    Inv = table.Column<decimal>(type: "decimal(38, 18)", nullable: false),
                    Npv = table.Column<decimal>(type: "decimal(38, 18)", nullable: false),
                    Dpi = table.Column<decimal>(type: "decimal(38, 18)", nullable: false),
                    TotalBranchCost = table.Column<decimal>(type: "decimal(38, 18)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DecisionOptionNode", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DecisionOptionNode_DecisionOption_DecisionOptionId",
                        column: x => x.DecisionOptionId,
                        principalSchema: "dbo",
                        principalTable: "DecisionOption",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DecisionOptionNode_DecisionOptionNode_ParentId",
                        column: x => x.ParentId,
                        principalSchema: "dbo",
                        principalTable: "DecisionOptionNode",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "WellScenarioEdge",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    ActivityId = table.Column<Guid>(nullable: true),
                    Label = table.Column<string>(maxLength: 255, nullable: true),
                    Payoff1 = table.Column<string>(maxLength: 50, nullable: true),
                    Payoff2 = table.Column<string>(maxLength: 50, nullable: true),
                    Probability = table.Column<string>(maxLength: 50, nullable: true),
                    Created = table.Column<DateTime>(nullable: false),
                    FromId = table.Column<Guid>(nullable: false),
                    ToId = table.Column<Guid>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WellScenarioEdge", x => x.Id);
                    table.ForeignKey(
                        name: "FK_WellScenarioEdge_WellScenarioNode_FromId",
                        column: x => x.FromId,
                        principalSchema: "dbo",
                        principalTable: "WellScenarioNode",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_WellScenarioEdge_WellScenarioNode_ToId",
                        column: x => x.ToId,
                        principalSchema: "dbo",
                        principalTable: "WellScenarioNode",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DecisionResultGroup",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    WellScenarioId = table.Column<Guid>(nullable: false),
                    WellScenarioRevId = table.Column<Guid>(nullable: false),
                    Remark = table.Column<string>(maxLength: 1000, nullable: true),
                    By = table.Column<string>(maxLength: 255, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DecisionResultGroup", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DecisionResultGroup_WellScenario_WellScenarioId",
                        column: x => x.WellScenarioId,
                        principalSchema: "dbo",
                        principalTable: "WellScenario",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DecisionResultGroup_WellScenarioTab_WellScenarioRevId",
                        column: x => x.WellScenarioRevId,
                        principalSchema: "dbo",
                        principalTable: "WellScenarioTab",
                        principalColumn: "RevId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DecisionResult",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    DecisionGroupId = table.Column<Guid>(nullable: false),
                    DecisionOptionId = table.Column<Guid>(nullable: false),
                    IsChosen = table.Column<bool>(nullable: false),
                    Remark = table.Column<string>(maxLength: 1000, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DecisionResult", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DecisionResult_DecisionResultGroup_DecisionGroupId",
                        column: x => x.DecisionGroupId,
                        principalSchema: "dbo",
                        principalTable: "DecisionResultGroup",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DecisionResult_DecisionOption_DecisionOptionId",
                        column: x => x.DecisionOptionId,
                        principalSchema: "dbo",
                        principalTable: "DecisionOption",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_DecisionOption_WellScenarioId",
                schema: "dbo",
                table: "DecisionOption",
                column: "WellScenarioId");

            migrationBuilder.CreateIndex(
                name: "IX_DecisionOptionNode_DecisionOptionId",
                schema: "dbo",
                table: "DecisionOptionNode",
                column: "DecisionOptionId");

            migrationBuilder.CreateIndex(
                name: "IX_DecisionOptionNode_ParentId",
                schema: "dbo",
                table: "DecisionOptionNode",
                column: "ParentId");

            migrationBuilder.CreateIndex(
                name: "IX_DecisionResult_DecisionGroupId",
                schema: "dbo",
                table: "DecisionResult",
                column: "DecisionGroupId");

            migrationBuilder.CreateIndex(
                name: "IX_DecisionResult_DecisionOptionId",
                schema: "dbo",
                table: "DecisionResult",
                column: "DecisionOptionId");

            migrationBuilder.CreateIndex(
                name: "IX_DecisionResultGroup_WellScenarioId",
                schema: "dbo",
                table: "DecisionResultGroup",
                column: "WellScenarioId");

            migrationBuilder.CreateIndex(
                name: "IX_DecisionResultGroup_WellScenarioRevId",
                schema: "dbo",
                table: "DecisionResultGroup",
                column: "WellScenarioRevId");

            migrationBuilder.CreateIndex(
                name: "IX_ModulePage_ModuleId",
                schema: "dbo",
                table: "ModulePage",
                column: "ModuleId");

            migrationBuilder.CreateIndex(
                name: "IX_ModulePage_PageId",
                schema: "dbo",
                table: "ModulePage",
                column: "PageId");

            migrationBuilder.CreateIndex(
                name: "IX_PageApi_ApiId",
                schema: "dbo",
                table: "PageApi",
                column: "ApiId");

            migrationBuilder.CreateIndex(
                name: "IX_PageApi_PageId",
                schema: "dbo",
                table: "PageApi",
                column: "PageId");

            migrationBuilder.CreateIndex(
                name: "IX_PresetDecisionEdge_FromId",
                schema: "dbo",
                table: "PresetDecisionEdge",
                column: "FromId");

            migrationBuilder.CreateIndex(
                name: "IX_PresetDecisionEdge_ToId",
                schema: "dbo",
                table: "PresetDecisionEdge",
                column: "ToId");

            migrationBuilder.CreateIndex(
                name: "IX_PresetDecisionNode_ResourceId",
                schema: "dbo",
                table: "PresetDecisionNode",
                column: "ResourceId");

            migrationBuilder.CreateIndex(
                name: "IX_ProjectAuthorize_ProjectId",
                schema: "dbo",
                table: "ProjectAuthorize",
                column: "ProjectId");

            migrationBuilder.CreateIndex(
                name: "IX_ProjectAuthorize_UserId",
                schema: "dbo",
                table: "ProjectAuthorize",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_RoleAuthorize_RoleId",
                schema: "dbo",
                table: "RoleAuthorize",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "IX_RoleAuthorize_UserId",
                schema: "dbo",
                table: "RoleAuthorize",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_RoleModule_ModuleId",
                schema: "dbo",
                table: "RoleModule",
                column: "ModuleId");

            migrationBuilder.CreateIndex(
                name: "IX_RoleModule_RoleId",
                schema: "dbo",
                table: "RoleModule",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "IX_UserAuthen_UserId",
                schema: "dbo",
                table: "UserAuthen",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_WellScenario_ResourceId",
                schema: "dbo",
                table: "WellScenario",
                column: "ResourceId");

            migrationBuilder.CreateIndex(
                name: "IX_WellScenario_WellName",
                schema: "dbo",
                table: "WellScenario",
                column: "WellName");

            migrationBuilder.CreateIndex(
                name: "IX_WellScenarioEdge_FromId",
                schema: "dbo",
                table: "WellScenarioEdge",
                column: "FromId");

            migrationBuilder.CreateIndex(
                name: "IX_WellScenarioEdge_ToId",
                schema: "dbo",
                table: "WellScenarioEdge",
                column: "ToId");

            migrationBuilder.CreateIndex(
                name: "IX_WellScenarioNode_ResourceId",
                schema: "dbo",
                table: "WellScenarioNode",
                column: "ResourceId");

            migrationBuilder.CreateIndex(
                name: "IX_WellScenarioTab_MasterVersionId",
                schema: "dbo",
                table: "WellScenarioTab",
                column: "MasterVersionId");

            migrationBuilder.CreateIndex(
                name: "IX_WellScenarioTab_WellScenarioId",
                schema: "dbo",
                table: "WellScenarioTab",
                column: "WellScenarioId");

            migrationBuilder.CreateIndex(
                name: "IX_WellScenarioTab_TabId_WellName",
                schema: "dbo",
                table: "WellScenarioTab",
                columns: new[] { "TabId", "WellName" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "__EFLoggingEvent",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Area",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Attachment",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "DecisionOptionNode",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "DecisionResult",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Job",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ModulePage",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "PageApi",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "PeriodPrice",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Platform",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "PresetDecisionEdge",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Price",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Production",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ProductionParam",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ProductionProfile",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ProjectActivity",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ProjectAttribute",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ProjectAuthorize",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ProjectDrilled",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ProjectLocation",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ProjectSpace",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ProjectWell",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Resource",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ResourceLibrary",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ResourceTask",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Rigg",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "RiggRate",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "RoleAuthorize",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "RoleModule",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Sand",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "SessionLogg",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Template",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "UserActivity",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "UserAuthen",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Well",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "WellActivity",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "WellDrilled",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "WellProperties",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "WellScenarioEdge",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "WellSpace",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "WellUndrilled",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "DecisionResultGroup",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "DecisionOption",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Api",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Page",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "PresetDecisionNode",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Project",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Module",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Role",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "User",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "WellScenarioNode",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "WellScenarioTab",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "WellScenario",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "PresetWellScenario",
                schema: "dbo");
        }
    }
}
