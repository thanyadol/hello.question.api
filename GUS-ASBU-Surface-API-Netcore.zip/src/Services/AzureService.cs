using System; 

using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;

using Microsoft.AspNetCore.Http;
//Windows Authen

//configure
using Microsoft.Extensions.Configuration;
//logg
using Serilog;
using surflex.netcore22.Exceptions;
//JSON manipulate

//http

//model
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using Utility = surflex.netcore22.Helpers.Utility;
//using User = surflex.netcore22.Models.User;

//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;


//token
using System.IdentityModel.Tokens;
using System.Text;
using Microsoft.IdentityModel.Tokens;

//EF
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

//grapth
//using Microsoft.Azure.ActiveDirectory.GraphClient;  // Will eventually be removed
//using Microsoft.IdentityModel.Clients.ActiveDirectory;
//using Microsoft.Owin.Security;
//using Microsoft.Owin.Security.OpenIdConnect;
using Microsoft.Graph;
//using User = Microsoft.Graph.User;  // This is only here while I work on removing references to Microsoft.Azure.ActiveDirectory.GraphClient
using System.Configuration;
using System.Net.Http;
using Microsoft.AspNetCore.Authentication;
using System.Net.Http.Headers;

namespace surflex.netcore22.Services
{

    public interface IAzureService
    {
        // Task<User> GetUserProfileAsync();
        //Task<List<User>> SearchUsersAsync(string search, int limit);



    }

    public class AzureService : IAzureService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _configuration;

        public AzureService(IHttpContextAccessor httpContextAccessor, IConfiguration configuration)
        {

            _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
            _configuration = configuration;
        }

        private readonly IAuthenticationProvider _msGraphAuthenticationProvider;

        public AzureService(IAuthenticationProvider authenticationProvider)
        {
            _msGraphAuthenticationProvider = authenticationProvider;
        }

        /* 
        public async Task<User> GetUserProfileAsync()
        {
            var client = new GraphServiceClient(_msGraphAuthenticationProvider);
            return await client.Me.Request().GetAsync();
        }

        public async Task<List<User>> SearchUsersAsync(string search, int limit)
        {
            var client = new GraphServiceClient(_msGraphAuthenticationProvider);
            var users = new List<User>();

            var currentReferencesPage = await client.Users
                .Request()
                .Top(limit)
                .Filter($"startsWith(displayName, '{search}') or startswith(mail, '{search}')")
                .GetAsync();

            users.AddRange(currentReferencesPage);

            return users;
        }*/



    }

}
