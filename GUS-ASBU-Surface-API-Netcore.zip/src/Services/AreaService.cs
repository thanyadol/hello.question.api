using System; 

using System.Collections.Generic;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using surflex.netcore22.Exceptions;

//logg
using Serilog;
using surflex.netcore22.Helpers;

using GLOBAL = surflex.netcore22.Models.Constants.GlobalConstants;

namespace surflex.netcore22.Services
{

    public interface IAreaService
    {
        Task<Area> CreateAsync(Area area);
        Task<Area> UpdateAsync(Area area);
        //Task<Areas> DeleteAsync(string id);

        Task<Area> GetAsync(string id);

        Task<IEnumerable<Area>> ListAsync();
        Task<Area> EnforceAreaExistenceAsync(string id);
        Task<Area> EnforceAreaCreateAsync(Area area);

        Task<IEnumerable<Item>> ListLocationAsync();

    }

    public class AreaService : IAreaService
    {
        //area statu
        private readonly IAreaRepository _areaRepository;
        //private readonly IUserService _userService;

        private const string AREAR_STATUS_OPERATE = "OPERATE";
        //  private const string AREAR_STATUS_IDEL = "OPERATE";

        public AreaService(IAreaRepository areaRepository)//, IUserService userService)
        {
            _areaRepository = areaRepository ?? throw new ArgumentNullException(nameof(areaRepository));
            //  _userService = userService ?? throw new ArgumentNullException(nameof(userService));
            //
            //httpCurrentUser = _userService.GetHttpUserAsync().Result;

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }


        public async Task<IEnumerable<Item>> ListLocationAsync()
        {
            await Task.Delay(0);
            //  await this.EnforceRoleExistenceAsync(id);
            return GLOBAL.PROJECT_LOCATION;
        }


        public async Task<Area> CreateAsync(Area area)
        {
            //await this.EnforceWellExistenceAsync(Area.WellId);
            //assigned
            area.Id = Utility.ToUniqeIdentity(area.Name);
            area.Created = Utility.CurrentSEAsiaStandardTime();

            area.Status = AREAR_STATUS_OPERATE;

            //area.Description = "hello this is a new attachemnt from dev";

            //new rev and key
            //area.Rev = Guid.NewGuid().ToString();
            //area.Key = Guid.NewGuid().ToString();

            //await EnforceClanExistenceAsync(Area.Clan.Name);
            var entity = await _areaRepository.CreateAsync(area);
            if (entity == null)
            {
                throw new AreaNotFoundException(area);
            }

            return entity;
        }



        public async Task<Area> UpdateAsync(Area area)
        {
            var updated = await this.EnforceAreaExistenceAsync(area.Id);

            //assigned
            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //area.Key = Guid.NewGuid().ToString();

            var entity = await _areaRepository.UpdateAsync(area);
            if (entity == null)
            {
                throw new AreaNotFoundException(area);
            }

            return entity;
        }

        public async Task<Area> GetAsync(string id)
        {
            //  await this.EnforceAreaExistenceAsync(id);

            var entity = await _areaRepository.GetAsync(id);
            return entity;
        }


        /* *public async Task<Area> DeleteAsync(string id)
        {
            await this.EnforceAreaExistenceAsync(id);

            var deletedArea = await _areaRepository.DeleteAsync(id);
            return deletedArea;
        }*/

        public async Task<IEnumerable<Area>> ListAsync()
        {
            return await _areaRepository.ListAsync();
        }

        public async Task<Area> EnforceAreaExistenceAsync(string id)
        {
            var act = await _areaRepository.GetAsync(id);

            if (act == null)
            {
                throw new AreaNotFoundException();
            }

            return act;
        }


        public async Task<Area> EnforceAreaCreateAsync(Area area)
        {
            var id = Utility.ToUniqeIdentity(area.Name);
            var enforece = await _areaRepository.GetAsync(id);
            if (enforece != null)
            {
                return enforece;
            }

            //await EnforceClanExistenceAsync(Well.Clan.Name);
            var entity = await this.CreateAsync(area);
            return entity;
        }


    }

}