using System;

using System.Collections.Generic;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using surflex.netcore22.Exceptions;
using surflex.netcore22.Extensions;

//logg
using Serilog;
using surflex.netcore22.Helpers;

//calculation engine
using Jace;
using System.Reflection;
using surflex.netcore22.APIs.Gateway;

using RESOURCE = surflex.netcore22.Models.Constants.Resource;


//validator
using FluentValidation;

namespace surflex.netcore22.Services
{
    public class ResourceService : IResourceService
    {

        //private readonly static string ACTIVE = "ACTIVE";

        // private readonly string ARCHIVED = "ARCHIVED";
        //private readonly static string VARIABLE = "VARIABLE";
        //private readonly static string FIXED = "FIXED";
        // private readonly static string TEMPLATE = "TEMPLATE";


        // private readonly static string COST = "COST";
        // private readonly static string TIME = "TIME";
        // private readonly static string TANGIBLE = "TANGIBLE";

        // private readonly static string OPEX = "OPEX";
        //for tan intangible ratio
        // private readonly static string CONSTANT = "CONSTANT";



        //resource statu
        private readonly IResourceRepository _resourceRepository;

        private readonly IResourceTaskRepository _resourceTaskRepository;
        private readonly IResourceLibraryRepository _resourceLibraryRepository;

        private readonly IWellResourceService _wellService;
        private readonly AbstractValidator<WellDecisionParams> _decisionParamsValidator;

        private readonly User _httpCurrentUser;

        private readonly IUserService _userService;

        private readonly IHttpService _httpService;
        public ResourceService(IResourceRepository resourceRepository, IResourceLibraryRepository resourceLibraryRepository,
                                                         IResourceTaskRepository resourceTaskRepository, IUserService userService, IWellResourceService wellService, AbstractValidator<WellDecisionParams> decisionParamsValidator,
                                                         IHttpService httpService)
        {
            _resourceRepository = resourceRepository ?? throw new ArgumentNullException(nameof(resourceRepository));
            _resourceTaskRepository = resourceTaskRepository ?? throw new ArgumentNullException(nameof(resourceTaskRepository));
            _resourceLibraryRepository = resourceLibraryRepository ?? throw new ArgumentNullException(nameof(resourceLibraryRepository));
            _wellService = wellService ?? throw new ArgumentNullException(nameof(wellService));
            _decisionParamsValidator = decisionParamsValidator ?? throw new ArgumentNullException(nameof(decisionParamsValidator));

            _httpService = httpService ?? throw new ArgumentNullException(nameof(httpService));

            _userService = userService ?? throw new ArgumentNullException(nameof(userService));

            _httpCurrentUser = _httpService.GetHttpCurrentUserAsync().Result;


            //logg
            Log.Logger = new LoggerConfiguration()
                                .WriteTo.Console()
                                .CreateLogger();
        }

        public async Task<Resource> CreateAsync(Resource resource)
        {
            //assigned
            resource.Id = Guid.NewGuid().ToString();
            //  resource.Date = Utility.CurrentSEAsiaStandardTime();

            resource.Created = Utility.CurrentSEAsiaStandardTime();
            resource.Description = "dev";
            resource.By = _httpCurrentUser.Id;
            //resource.Status = ACTIVE;
            //new rev and key
            //resource.Rev = Guid.NewGuid().ToString();
            //resource.Key = Guid.NewGuid().ToString();

            //await EnforceClanExistenceAsync(Resource.Clan.Name);
            var entity = await _resourceRepository.CreateAsync(resource);
            if (entity == null)
            {
                throw new ResourceNotFoundException(resource);
            }

            return entity;
        }



        public async Task<Resource> UpdateAsync(Resource resource)
        {
            var updated = await this.EnforceResourceExistenceAsync(resource.Id);

            //assigned
            updated.Status = resource.Status;
            updated.Name = resource.Name;
            updated.Description = resource.Description;
            updated.Type = resource.Type;
            //updated.ValueType = resource.ValueType;
            //updated.Value = resource.Value;


            var entity = await _resourceRepository.UpdateAsync(updated);
            if (entity == null)
            {
                throw new ResourceNotFoundException(resource);
            }

            return entity;
        }

        public async Task<Resource> GetAsync(string id)
        {
            //  await this.EnforceResourceExistenceAsync(id);

            var entity = await _resourceRepository.GetAsync(id);
            return entity;
        }


        public async Task<ResourceTask> DeleteAsync(string id)
        {
            await this.EnforceResourceTaskExistenceAsync(id);

            var entity = await _resourceTaskRepository.DeleteAsync(id);
            return entity;
        }

        public async Task<IEnumerable<Resource>> ListAsync()
        {
            return await _resourceRepository.ListAsync();
        }

        public async Task<Resource> EnforceResourceExistenceAsync(string id)
        {
            var act = await _resourceRepository.GetAsync(id);

            if (act == null)
            {
                throw new ResourceNotFoundException();
            }

            return act;
        }



        //task

        public async Task<ResourceTask> CreateAsync(ResourceTask resource)
        {
            await this.EnforceResourceExistenceAsync(resource.ResourceId);
            await this.EnforceResourceLibraryExistenceAsync(resource.LibraryId);


            //assigned
            resource.Id = Guid.NewGuid().ToString();
            //  resource.Date = Utility.CurrentSEAsiaStandardTime();

            resource.Created = Utility.CurrentSEAsiaStandardTime();
            // resource.Description = "dev";

            //new rev and key
            //resource.Rev = Guid.NewGuid().ToString();
            //resource.Key = Guid.NewGuid().ToString();

            //await EnforceClanExistenceAsync(ResourceTask.Clan.Name);
            var entity = await _resourceTaskRepository.CreateAsync(resource);
            if (entity == null)
            {
                throw new ResourceNotFoundException();
            }

            return entity;
        }



        public async Task<ResourceTask> UpdateAsync(ResourceTask resource)
        {

            var updated = await this.EnforceResourceTaskExistenceAsync(resource.Id);

            await this.EnforceResourceExistenceAsync(resource.ResourceId);
            await this.EnforceResourceLibraryExistenceAsync(resource.LibraryId);

            //assigned
            updated.ResourceId = resource.ResourceId;
            updated.LibraryId = resource.LibraryId;

            var entity = await _resourceTaskRepository.UpdateAsync(updated);
            if (entity == null)
            {
                throw new ResourceNotFoundException();
            }

            return entity;
        }

        public async Task<ResourceTask> GetTaskAsync(string id)
        {
            //  await this.EnforceResourceTaskExistenceAsync(id);

            var entity = await _resourceTaskRepository.GetAsync(id);
            return entity;
        }


        /* *public async Task<ResourceTask> DeleteAsync(string id)
        {
            await this.EnforceResourceTaskExistenceAsync(id);

            var deletedResourceTask = await _resourceTaskRepository.DeleteAsync(id);
            return deletedResourceTask;
        }*/

        public async Task<IEnumerable<ResourceActivity>> ListTaskAsync()
        {
            return await _resourceTaskRepository.ListAsync();
        }



        //
        // Summary:
        //     Returns the list of resoiurce task by type and paranet id
        //
        // Returns:
        //     pair of ResourceActivity
        //
        // Type parameters:
        //   id:
        //     resouce id --parent
        //   type
        //     null, COST, TIME
        //
        //
        public async Task<IEnumerable<ResourceActivity>> ListTaskAsync(string id, string type)
        {
            var entity = await _resourceTaskRepository.ListAsync();

            if (!string.IsNullOrEmpty(type))
            {
                entity = entity.Where(c => c.Type == type);
            }

            if (!string.IsNullOrEmpty(id))
            {
                entity = entity.Where(c => c.ResourceId == id);
            }

            if (entity == null)
            {
                throw new ResourceNotFoundException();
            }

            return entity;
        }



        public async Task<ResourceTask> EnforceResourceTaskExistenceAsync(string id)
        {
            var act = await _resourceTaskRepository.GetAsync(id);

            if (act == null)
            {
                throw new ResourceNotFoundException();
            }

            return act;
        }


        //Library
        public async Task<ResourceLibrary> CreateAsync(ResourceLibrary resource)
        {

            //await this.EnforceWellExistenceAsync(ResourceLibrary.WellId);
            //assigned
            resource.Id = Guid.NewGuid().ToString();
            //  resource.Date = Utility.CurrentSEAsiaStandardTime();

            resource.Created = Utility.CurrentSEAsiaStandardTime();
            resource.Description = "dev";
            resource.Status = RecordStatus.ACTIVE.GetDescription();
            //new rev and key
            //resource.Rev = Guid.NewGuid().ToString();
            //resource.Key = Guid.NewGuid().ToString();

            resource.By = _httpCurrentUser.Id;
            resource.ValueType = FormulaType.FIXED.GetDescription();


            //await EnforceClanExistenceAsync(ResourceLibrary.Clan.Name);
            var entity = await _resourceLibraryRepository.CreateAsync(resource);
            if (entity == null)
            {
                throw new ResourceNotFoundException();
            }

            return entity;

            /* 
            //deactive old
            if (!String.IsNullOrEmpty(resource.Id))
            {
                var archive = await _resourceLibraryRepository.GetAsync(resource.Id);
                if (archive == null)
                {
                    throw new ResourceNotFoundException();
                }

                archive.Status = ARCHIVED;
                archive.FinishDate = Utility.CurrentSEAsiaStandardTime();

                await _resourceLibraryRepository.UpdateAsync(archive);

                //new rev old key
                resource.Rev = Guid.NewGuid().ToString();
                resource.Key = archive.Key;

            }
            else
            {
                //new key, rev
                resource.Rev = Guid.NewGuid().ToString();
                resource.Key = Guid.NewGuid().ToString();
            }

            //await this.EnforceWellExistenceAsync(ResourceLibrary.WellId);
            //assigned
            resource.Id = Guid.NewGuid().ToString();
            resource.StartDate = Utility.CurrentSEAsiaStandardTime();

            resource.Created = Utility.CurrentSEAsiaStandardTime();
            resource.Description = "dev";
            resource.Status = ACTIVE;
            //new rev and key

            //await EnforceClanExistenceAsync(ResourceLibrary.Clan.Name);
            var entity = await _resourceLibraryRepository.CreateAsync(resource);
            if (entity == null)
            {
                throw new ResourceNotFoundException();
            }

            return entity;*/
        }


        //Library
        public async Task<IEnumerable<ResourceLibrary>> InitialLibraryAsync(List<ResourceLibrary> libs)
        {
            var entities = new List<ResourceLibrary>();
            foreach (ResourceLibrary r in libs)
            {
                var entity = await _resourceLibraryRepository.CreateAsync(r);

                entities.Add(entity);
            }

            return entities;
        }

        public async Task<ResourceLibrary> UpdateAsync(ResourceLibrary resource)
        {
            var updated = await this.EnforceResourceLibraryExistenceAsync(resource.Id);

            //assigned
            updated.Status = resource.Status;
            updated.Name = resource.Name;
            updated.Description = resource.Description;

            updated.Value = resource.Value;
            updated.PlannerType = resource.PlannerType;
            updated.ValueType = resource.ValueType;
            updated.Type = resource.Type;

            //add lastes
            updated.By = _httpCurrentUser.Id;
            updated.Created = Utility.CurrentSEAsiaStandardTime();

            var entity = await _resourceLibraryRepository.UpdateAsync(updated);
            if (entity == null)
            {
                throw new ResourceNotFoundException();
            }

            return entity;
        }

        public async Task<ResourceLibrary> GetLibraryAsync(string id)
        {
            /* var intangilbe = new ResourceLibrary()
            {
                Id = "YYYRRREEE",
                Name = "Tangible", //Formular = "MotorDepth / TIHRate",
                Type = TANGIBLE,
                ValueType = CONSTANT,
                Value = 30,
                Status = ACTIVE,
                Created = Utility.CurrentSEAsiaStandardTime(),
                By = "user"
            };*/

            var entity = await _resourceLibraryRepository.GetAsync(id);
            return entity;
        }

        public async Task<ResourceLibrary> GetCurrentlyTangibleAsync()
        {
            var entity = await _resourceLibraryRepository.ListAsync();
            if (entity == null)
            {
                throw new ResourceNotFoundException(ResourceType.TANGIBLE.GetDescription());
            }

            return entity.Where(c => c.Type == ResourceType.TANGIBLE.GetDescription() && c.Status == RecordStatus.ACTIVE.GetDescription())
                            .OrderByDescending(c => c.StartDate).FirstOrDefault();
        }


        public async Task<IEnumerable<ResourceLibrary>> ListTangibleAsync()
        {
            var entity = await _resourceLibraryRepository.ListAsync();
            entity = entity.Where(c => c.Type == ResourceType.TANGIBLE.GetDescription() && c.Status == RecordStatus.ACTIVE.GetDescription()).OrderByDescending(c => c.StartDate).ToList();
            if (entity == null)
            {
                throw new ResourceNotFoundException(ResourceType.TANGIBLE.GetDescription());
            }

            return entity.Select(c => { c.By = _userService.GetAsync(c.By).Result == null ? null : _userService.GetAsync(c.By).Result.CAI; return c; }).ToList();
        }

        public async Task<IEnumerable<ResourceLibrary>> ListOpexCPPAsync()
        {
            var entity = await _resourceLibraryRepository.ListAsync();
            entity = entity.Where(c => c.Type == ResourceType.OPEX.GetDescription()
                        && c.Status == RecordStatus.ACTIVE.GetDescription()).OrderByDescending(c => c.StartDate).ToList();
            if (entity == null)
            {
                throw new ResourceNotFoundException(ResourceType.OPEX.GetDescription());
            }

            return entity.Select(c => { c.By = _userService.GetAsync(c.By).Result == null ? null : _userService.GetAsync(c.By).Result.CAI; return c; }).ToList();
        }


        /* *public async Task<ResourceLibrary> DeleteAsync(string id)
        {
            await this.EnforceResourceLibraryExistenceAsync(id);

            var deletedResourceLibrary = await _resourceLibraryRepository.DeleteAsync(id);
            return deletedResourceLibrary;
        }*/

        public async Task<IEnumerable<ResourceLibrary>> ListLibraryAsync(bool archive)
        {
            // await Task.Delay(0);
            //return this.RESOURCE_FORMULAR_LIBRARIES;  

            var entity = await _resourceLibraryRepository.ListAsync();
            entity = entity.Where(c => (c.Type == ResourceType.TIME.GetDescription() || c.Type == ResourceType.COST.GetDescription()));

            return entity.OrderBy(c => c.Name);
        }

        public async Task<IEnumerable<Item>> ListTypeAsync()
        {
            await Task.Delay(0);
            var entity = RESOURCE.TYPE;

            return entity;
        }


        public async Task<ResourceLibrary> EnforceResourceLibraryExistenceAsync(string id)
        {
            var act = await _resourceLibraryRepository.GetAsync(id);

            if (act == null)
            {
                throw new ResourceNotFoundException();
            }

            return act;
        }

        public async Task<WellDecisionParams> ValidateBatchResourceAsync(WellDecisionParams parameters)
        {
            //parameters.Id = Guid.NewGuid().ToString();
            //parameters.CalculatedTimestamp = Utility.CurrentSEAsiaStandardTime();

            var entities = new List<ResourceActivity>();
            foreach (Resource resource in parameters.Resources)
            {
                //await Task.Delay(0);
                //get resource list
                var activity = await _resourceTaskRepository.ListAsync();
                activity = activity.Where(c => c.ResourceId == resource.Id);

                entities.AddRange(activity);
            }

            //distince its
            entities = entities.GroupBy(p => new { p.LibraryId, p.Formular, p.ValueType }).Select(g => g.First()).ToList();

            //validate
            foreach (var a in entities)
            {
                //swithc with conatail
                if (a.ValueType == FormulaType.VARIABLE.GetDescription())
                {
                    //validate 
                    parameters.ValidateFormular = a.Formular;

                    var flag = _decisionParamsValidator.Validate(parameters);

                    if (!flag.IsValid)
                    {
                        // parameters.RequiredParameters.AddRange(flag.Errors.Select(c => c.PropertyName.ToUpper()).ToList());
                        parameters.ValidationResult = flag;
                        //var msg = flag.Errors.FirstOrDefault().PropertyName;
                        //throw new ResourceNotValidException(msg);
                    }

                }
                else
                {
                    //parameters.ValidateValue = a.Value;
                }
            }
            ///////////////////////////////////////////////////////////////////////////////////

            //required
            foreach (var a in entities)
            {
                var temp = new WellDecisionParams();
                //swithc with conatail
                if (a.ValueType == FormulaType.VARIABLE.GetDescription())
                {
                    //validate 
                    temp.ValidateFormular = a.Formular;

                    var flag = _decisionParamsValidator.Validate(temp);

                    if (!flag.IsValid)
                    {
                        //add value
                        parameters.RequiredParameters.AddRange(flag.Errors.Select(c => c.PropertyName.ToUpper()).ToList());
                        //parameters.ValidationResult = flag;
                        //var msg = flag.Errors.FirstOrDefault().PropertyName;
                        //throw new ResourceNotValidException(msg);
                    }

                }
                else
                {
                    //parameters.ValidateValue = a.Value;
                }
            }
            ////////////////////////////////////////////////////////////////////////

            //for devcheck
            parameters.RequiredParameters = parameters.RequiredParameters.Distinct().ToList();
            parameters.GroupedActivities = entities;

            return parameters;
        }

        public async Task<WellDecisionParams> CalculateBatchResourceAsync(WellDecisionParams parameters)
        {
            /* var flag = _decisionParamsValidator.Validate(parameters);
            if (!flag.IsValid)
            {
                var msg = flag.Errors.FirstOrDefault().ErrorMessage;
                throw new ResourceNotValidException(msg);
            }*/

            parameters.Id = Guid.NewGuid().ToString();
            parameters.CalculatedTimestamp = Utility.CurrentSEAsiaStandardTime();

            foreach (Resource resource in parameters.Resources)
            {
                //await Task.Delay(0);
                //get resource list
                var activity = await _resourceTaskRepository.ListAsync();
                activity = activity.Where(c => c.ResourceId == resource.Id);

                if (activity == null)
                {
                    throw new ResourceNotFoundException();
                }

                //prepai params form class     
                var tasks = new List<ResourceActivity>();

                Dictionary<string, double> variables = new Dictionary<string, double>();

                PropertyInfo[] props = typeof(WellDecisionParams).GetProperties();
                foreach (PropertyInfo prop in props)
                {
                    double value = 0;
                    try
                    {
                        value = Convert.ToDouble(parameters.GetType().GetProperty(prop.Name).GetValue(parameters, null));
                    }
                    catch (InvalidCastException)
                    {
                        //throw ex;
                    }
                    catch (FormatException)
                    {
                        //throw ex;
                    }
                    finally
                    {
                        variables.Add(prop.Name, value);
                    }

                    /*object[] attrs = prop.GetCustomAttributes(true);
                    foreach (object attr in attrs)
                     {

                     AuthorAttribute authAttr = attr as AuthorAttribute;
                     if (authAttr != null)
                        {
                            string propName = prop.Name;
                            string auth = authAttr.Name;

                            _dict.Add(propName, auth);
                        }
                      }*/
                }

                //return _dict;

                //engine run !!!!

                //string formular = "ln(PlannedTD - CurrentDepth) / ROP";

                //CalculationEngine engine = new CalculationEngine();

                //custom
                //engine.AddFunction("ln", (a) => Math.Log(a));
                //double result2 = engine.Calculate("ln(10)");

                //Func<Dictionary<string, double>, double> function = engine.Build(formular);
                //double result = function(variables);

                //sequence is important !!!!! 
                //loop
                decimal totalTime = 0m; //hrs
                foreach (var task in activity.Where(c => c.Type == ResourceType.TIME.GetDescription()))
                {

                    if (task.ValueType == FormulaType.FIXED.GetDescription())
                    {
                        totalTime = totalTime + task.Value.GetValueOrDefault();
                    }
                    else
                    {
                        CalculationEngine engine = new CalculationEngine();

                        //try
                        //{

                        Func<Dictionary<string, double>, double> function = engine.Build(task.Formular);
                        double result = function(variables);

                        totalTime = totalTime + Convert.ToDecimal(result);
                        task.Value = Convert.ToDecimal(result);

                        /*
                        catch (DivideByZeroException)
                        {
                            throw new ResourceNotValidException("Invalid activity name : " + resource.Name);
                        }
                        catch (OverflowException)
                        {
                            throw new ResourceNotValidException("Invalid activity name : " + resource.Name);
                        }*/

                    }

                    tasks.Add(task);

                }

                //assigned totlatime
                resource.TotalTime = totalTime;

                //add new parameter
                variables.Remove("TotalTime");
                variables.Add("TotalTime", Convert.ToDouble(totalTime));

                decimal totalCost = 0m; //usd
                foreach (var task in activity.Where(c => c.Type == ResourceType.COST.GetDescription()))
                {
                    //well cost
                    //query
                    if (task.ResourceType == "WELL_COST")
                    {
                        //assign value
                        var entity = await _wellService.GetPlannedProductiveCostAsync(parameters.WellName, task.QueryParam);
                        task.Value = entity.PlannedAFECost;
                    }


                    //summation

                    if (task.ValueType == FormulaType.FIXED.GetDescription())
                    {
                        totalCost = totalCost + task.Value.GetValueOrDefault();
                    }
                    else
                    {
                        CalculationEngine engine = new CalculationEngine();

                        Func<Dictionary<string, double>, double> function = engine.Build(task.Formular);
                        double result = function(variables);

                        totalCost = totalCost + Convert.ToDecimal(result);


                        //for dev check
                        task.Value = Convert.ToDecimal(result);
                    }

                    tasks.Add(task);
                }

                resource.TotalCost = totalCost;
                resource.Tasks = tasks;
                //last call

            }

            return parameters;

        }

    }

}