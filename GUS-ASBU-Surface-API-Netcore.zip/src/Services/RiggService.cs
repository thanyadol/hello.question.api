using System; 

using System.Collections.Generic;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using surflex.netcore22.Exceptions;

//logg
using Serilog;
using surflex.netcore22.Helpers;
using System.Data;
using surflex.netcore22.Extensions;
using System.IO;
using surflex.netcore22.APIs.Gateway;
using FluentValidation;
using surflex.netcore22.Helpers.DataHandler;

namespace surflex.netcore22.Services
{
    public interface IRiggService
    {
        Task<Rigg> CreateAsync(Rigg riggs);
        Task<Rigg> UpdateAsync(Rigg riggs);
        //Task<Rigg> DeleteAsync(string id);

        Task<Rigg> GetAsync(string id);

        Task<IEnumerable<Rigg>> ListAsync();
        Task<Rigg> EnforceRiggExistenceAsync(string id);

        //excel
        Task<DataTable> ExtractAsync(Attachment attacch, bool hasHeader = true);
        // Task<DataTable> ExtractAsync(OfficeOpenXml.ExcelWorksheet ws, bool hasHeader = true);

        Task<IEnumerable<Rigg>> TransformAsync(DataTable table);
        Task<IEnumerable<Rigg>> LoadAsync(IEnumerable<Rigg> riggs, string template);

        Task<IEnumerable<Rigg>> BatchCreateAsync(Template template);

        Task<Rigg> EnforceRiggCreateAsync(Rigg rig);
        //rate

        Task<RiggRate> CreateAsync(RiggRate rate);
        Task<RiggRate> UpdateAsync(RiggRate rate);
        //Task<Rigg> DeleteAsync(string id);

        Task<RiggRate> GetRateAsync(string id);

        Task<IEnumerable<RiggRate>> ListRateAsync(string id = null);

        Task<RiggRate> EnforceRiggRateExistenceAsync(string id);

        Task<FluentValidation.Results.ValidationResult> ValidateRateTemplateAsync(Attachment attach);

    }

    public class RiggService : IRiggService
    {
        //  private readonly string ACTIVE = "ACTIVE";

        private readonly string SHEET_NAME = "(1)3-String Monobore";
        //private readonly int START_COLUMN_INDEX = 6;
        //private readonly int START_ROW_INDEX = 4;

        private readonly IRiggRepository _riggRepository;
        //    private readonly IUserService _userService;

        private readonly IRiggRateRepository _rateRepository;


        // private readonly IPathFinderService _pathFinderService;
        private readonly IAttachmentService _attachementService;
        private readonly ITemplateService _templateService;
        private readonly IWorkUnitService _workUnitService;


        protected readonly IPathFinderService _pathFinderService;

        private readonly IHttpService _httpService;

        private readonly User httpCurrentUser;

        private readonly AbstractValidator<TemplateValidateParams> _templateValidator;

        public RiggService(IRiggRepository riggRepository, IRiggRateRepository rateRepository,// IUserService userService,// IPathFinderService pathFinder,
                               IWorkUnitService workUnitService, IAttachmentService attachementService, ITemplateService templateService, AbstractValidator<TemplateValidateParams> templateValidator,
                                     IHttpService httpService, IPathFinderService pathFinderService)
        {
            _rateRepository = rateRepository ?? throw new ArgumentNullException(nameof(rateRepository));
            _riggRepository = riggRepository ?? throw new ArgumentNullException(nameof(riggRepository));
            // _userService = userService ?? throw new ArgumentNullException(nameof(userService));


            _workUnitService = workUnitService ?? throw new ArgumentNullException(nameof(workUnitService));

            _attachementService = attachementService ?? throw new ArgumentNullException(nameof(attachementService));
            _templateService = templateService ?? throw new ArgumentNullException(nameof(templateService));

            _templateValidator = templateValidator ?? throw new ArgumentNullException(nameof(templateValidator));
            _pathFinderService = pathFinderService ?? throw new ArgumentNullException(nameof(pathFinderService));


            _httpService = httpService ?? throw new ArgumentNullException(nameof(httpService));


            httpCurrentUser = httpService.GetHttpCurrentUserAsync().Result;

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }

        public async Task<Rigg> CreateAsync(Rigg rigg)
        {
            //await this.EnforceWellExistenceAsync(Rigg.WellId);
            //assigned
            rigg.Id = Utility.ToUniqeIdentity(rigg.Name);
            rigg.Created = Utility.CurrentSEAsiaStandardTime();

            // rigg.By = httpCurrentUser.Id;

            rigg.Description = "hello this is a new rigg";

            //new rev and key
            //rigg.Rev = Guid.NewGuid().ToString();
            //rigg.Key = Guid.NewGuid().ToString();

            //await EnforceClanExistenceAsync(Rigg.Clan.Name);
            var entity = await _riggRepository.CreateAsync(rigg);
            if (entity == null)
            {
                throw new RiggNotFoundException(rigg);
            }

            return entity;
        }



        public async Task<Rigg> UpdateAsync(Rigg rigg)
        {
            var updated = await this.EnforceRiggExistenceAsync(rigg.Id);

            //assigned
            //rigg.Created = Utility.CurrentSEAsiaStandardTime();
            //Rigg.Rigg = Rigg.Rigg;
            //Rigg.Status = Rigg.Status;
            //rigg.By = httpCurrentUser.Id;

            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //rigg.Key = Guid.NewGuid().ToString();

            var entity = await _riggRepository.UpdateAsync(rigg);
            if (entity == null)
            {
                throw new RiggNotFoundException(rigg);
            }

            return entity;
        }

        public async Task<Rigg> GetAsync(string id)
        {
            //  await this.EnforceRiggExistenceAsync(id);

            var entity = await _riggRepository.GetAsync(id);
            return entity;
        }


        /* public async Task<Rigg> DeleteAsync(string id)
        {
            await this.EnforceRiggExistenceAsync(id);

            var deletedRigg = await _riggRepository.DeleteAsync(id);
            return deletedRigg;
        }*/

        public async Task<IEnumerable<Rigg>> ListAsync()
        {

            return await _riggRepository.ListAsync();
        }

        public async Task<Rigg> EnforceRiggExistenceAsync(string id)
        {
            var act = await _riggRepository.GetAsync(id);

            if (act == null)
            {
                throw new RiggNotFoundException();
            }

            return act;
        }


        public async Task<RiggRate> CreateAsync(RiggRate rate)
        {
            //await this.EnforceWellExistenceAsync(RiggRate.WellId);
            //assigned
            rate.Id = Guid.NewGuid().ToString();
            rate.Created = Utility.CurrentSEAsiaStandardTime();

            rate.By = httpCurrentUser.Id;

            //rate.Description = "hello this is a new attachemnt from dev";

            //new rev and key
            //rate.Rev = Guid.NewGuid().ToString();
            //rate.Key = Guid.NewGuid().ToString();

            //await EnforceClanExistenceAsync(RiggRate.Clan.Name);
            var entity = await _rateRepository.CreateAsync(rate);
            if (entity == null)
            {
                throw new RiggNotFoundException();
            }

            return entity;
        }

        public async Task<RiggRate> UpdateAsync(RiggRate rate)
        {
            var updated = await this.EnforceRiggRateExistenceAsync(rate.Id);

            //assigned
            rate.Created = Utility.CurrentSEAsiaStandardTime();
            //RiggRate.RiggRate = RiggRate.RiggRate;
            //RiggRate.Status = RiggRate.Status;
            rate.By = httpCurrentUser.Id;

            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //rate.Key = Guid.NewGuid().ToString();

            var entity = await _rateRepository.UpdateAsync(rate);
            if (entity == null)
            {
                throw new RiggNotFoundException();
            }

            return entity;
        }

        public async Task<RiggRate> GetRateAsync(string id)
        {
            //  await this.EnforceRiggRateExistenceAsync(id);

            var entity = await _rateRepository.GetAsync(id);
            return entity;
        }


        /* public async Task<RiggRate> DeleteAsync(string id)
        {
            await this.EnforceRiggRateExistenceAsync(id);

            var deletedRiggRate = await _rateRepository.DeleteAsync(id);
            return deletedRiggRate;
        }*/



        //
        // Summary:
        //     Returns the drilled rate  with rigg anme
        //
        // Returns:
        //     rigg list
        //
        // Type parameters:
        //   id:
        //     template id
        //
        //
        public async Task<IEnumerable<RiggRate>> ListRateAsync(string id = null)
        {
            if (!string.IsNullOrEmpty(id))
            {
                var entity = await _rateRepository.ListAsync(id);
                if (!entity.Any())
                {
                    throw new RiggNotFoundException();
                }

                return entity;
            }
            else
            {
                var entity = await _rateRepository.ListAsync();
                if (!entity.Any())
                {
                    throw new RiggNotFoundException();
                }

                return entity;
            }
        }

        public async Task<RiggRate> EnforceRiggRateExistenceAsync(string id)
        {
            var act = await _rateRepository.GetAsync(id);

            if (act == null)
            {
                throw new RiggNotFoundException();
            }

            return act;
        }


        //excel
        public async Task<FluentValidation.Results.ValidationResult> ValidateRateTemplateAsync(Attachment attach)
        {
            await Task.Delay(0);
            string VALIDATE_RULE_SET = "DRILLED_TRIP_RATE";
            //var w = await BeforeExtractAsync(attach);
            //extract
            var parameter = new TemplateValidateParams()
            {
                Extensions = attach.Extension,
                SheetName = SHEET_NAME,

                //Items = null,
                TemplateId = attach.UploadTemplateId
            };

            /* 
            var tb = await ExtractAsync(w);
            var items = new LocationValuePair[] {
               // new LocationValuePair("A", 1, a);
            };

            parameter.Items = items.ToList();*/

            //vlidate
            var flag = _templateValidator.Validate(parameter, ruleSet: VALIDATE_RULE_SET);
            if (flag.IsValid != true)
            {
                throw new Exception(flag.Errors.FirstOrDefault().ErrorMessage);
            }

            return flag;
        }

        public async Task<DataTable> ExtractAsync(Attachment attach, bool hasHeader = true)
        {
            await Task.Delay(0);
            //attachemtn
            Byte[] bytes = Convert.FromBase64String(attach.Value);
            //var path = await _pathFinderService.FindAsync(attach.Id + attach.Extension);

            //open
            Aspose.Cells.Worksheet ws;
            using (var stream = new MemoryStream(bytes))
            {
                var engine = new ExcelEngine(stream);
                var pck = engine.Excel;

                //validate sheet
                ws = pck.Worksheets[SHEET_NAME];
            }

            if (ws == null)
            {
                throw new AttachmentNotValidException(attach.Id);
            }

            if (ws.Cells == null)
            {
                throw new AttachmentNotValidException(attach.Id);
            }

            //await Task.Delay(0);
            //var start_header_row = 2;
            string[] cols = new string[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S",
                                                "T", "U", "V", "W", "X", "Y", "Z"};
            // hasHeader = false;
            DataTable tbl = new DataTable();

            Aspose.Cells.Range range = ws.Cells.MaxDisplayRange;

            var firstRow = ws.Cells.Rows[0];
            var startCol = 0;

            for (int i = startCol; i < range.ColumnCount; i++)
            {
                // Aspose.Cells.Cell cell = ws.Cells.GetCell(0, i);

                //with no hearder
                tbl.Columns.Add(cols[i]);
            }

            //shift for data
            int startRow = 1;
            for (int rowNum = startRow; rowNum <= range.RowCount - startRow; rowNum++)
            {
                var wsRow = ws.Cells.Rows[rowNum];

                //buffer for merged cell
                var buffer = "";
                DataRow row = tbl.Rows.Add();

                for (int j = startCol; j < range.ColumnCount; j++)
                {
                    try
                    {

                        Aspose.Cells.Cell cell = wsRow.GetCellOrNull(j);
                        buffer = cell.StringValue;
                        row[j] = buffer;
                    }
                    catch (NullReferenceException)
                    {
                        row[j] = buffer;
                    }

                }
            }

            return tbl;
        }

        public async Task<IEnumerable<Rigg>> TransformAsync(DataTable table)
        {
            await Task.Delay(0);

            // int minyear = 2000;
            //int i = 2;

            var entity = new List<Rigg>();
            // string cuurent = "Unknow";

            var activity = "NA";
            var type = "NA";
            var inout = "NA";
            //var inout = "NA";

            //transform
            for (int i = 0; i < table.Rows.Count; i++)
            {
                var dr = table.Rows[i];

                if (i == 0)
                {
                    activity = dr["F"].ToString();
                    //type = dr["G"].ToString();

                    continue;
                }

                if (i == 1)
                {
                    inout = dr["F"].ToString();
                    //type = dr["G"].ToString();

                    continue;
                }

                if (i == 2)
                {
                    // activity = dr["F"].ToString();
                    type = dr["G"].ToString();

                    continue;
                }


                //transform
                var rigg = new Rigg()
                {
                    Name = (string)dr["A"],
                    //Unit = (string)dr["Unit"],


                    Description = "hello world"
                    //how to know well type ??? Liquid or Gas
                };


                var rates = new List<RiggRate>();
                decimal tih = 0; // Not strictly required, as the default value is 0.0
                try
                {
                    tih = Convert.ToDecimal(dr["G"].ToString());
                }
                catch (FormatException)
                {
                    //string ss = string.Format("Invalid price exception, year {0}, row {1}", dc.ColumnName, i);
                    //throw new PriceNotValidException(ss, ex);
                }

                decimal toh = 0; // Not strictly required, as the default value is 0.0
                try
                {
                    toh = Convert.ToDecimal(dr["I"].ToString());
                }
                catch (FormatException)
                {
                    //string ss = string.Format("Invalid price exception, year {0}, row {1}", dc.ColumnName, i);
                    //throw new PriceNotValidException(ss, ex);
                }

                rates.Add(new RiggRate() { Activity = activity, Type = type, TIH = tih, TOH = toh });


                rigg.RiggRates = rates;
                entity.Add(rigg);
            }

            if (!entity.Any())
            {

                throw new RiggNotFoundException();
            }

            return entity;
        }


        public async Task<IEnumerable<Rigg>> LoadAsync(IEnumerable<Rigg> riggs, string template)
        {
            var entities = new List<Rigg>();

            using (var transaction = _workUnitService.BeginTransaction())
            {
                foreach (var rr in riggs)
                {
                    //persist area
                    var entity = await this.EnforceRiggCreateAsync(rr);

                    foreach (var pp in rr.RiggRates)
                    {
                        pp.Id = Guid.NewGuid().ToString();
                        pp.Created = Utility.CurrentSEAsiaStandardTime();
                        pp.RiggId = entity.Id;
                        pp.TemplateId = template;
                        pp.By = httpCurrentUser.Id;


                        await _workUnitService.RiggRates.CreateAsync(pp);
                    }
                    entities.Add(entity);
                }

                try
                {
                    transaction.Commit();
                    return entities;
                }
                catch (InvalidOperationException ex)
                {
                    transaction.Rollback();
                    throw new RiggNotFoundException(ex.Message);
                }
            }
        }


        public async Task<Rigg> EnforceRiggCreateAsync(Rigg rig)
        {
            var id = Utility.ToUniqeIdentity(rig.Name);
            var enforece = await this.GetAsync(id);
            if (enforece != null)
            {
                return enforece;
            }

            //await EnforceClanExistenceAsync(Well.Clan.Name);
            var entity = await this.CreateAsync(rig);
            return entity;
        }


        public async Task<IEnumerable<Rigg>> BatchCreateAsync(Template template)
        {
            var attach = await _attachementService.EnforceAttachmentExistenceAsync(template.AttachmentId);

            try
            {
                // var workbook = await _attachementService.GetWorkbookAsync(attach, SHEET_NAME);
                var table = await this.ExtractAsync(attach);

                //validate move validate at upload template time
                /* var flag = await this.ValidateAsync(attach, workbook.Name);
                if (flag.IsValid != true)
                {
                    throw new RiggNotValidException(flag.Errors.FirstOrDefault().ErrorMessage);
                }*/

                var entity = await this.TransformAsync(table);
                var rigg = await this.LoadAsync(entity, template.Id);

                return rigg;
            }
            catch (Exception)
            {
                await _templateService.RollbackAsync(template);

                //remove template, attachment 
                await _templateService.DeleteAsync(template.Id);
                await _attachementService.DeleteAsync(template.AttachmentId);

                throw new RiggNotValidException();
            }
        }


    }

}