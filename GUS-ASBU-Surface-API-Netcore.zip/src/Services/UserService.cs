using System;

using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;

using Microsoft.AspNetCore.Http;
//Windows Authen

//configure
using Microsoft.Extensions.Configuration;
//logg
using Serilog;
using surflex.netcore22.Exceptions;
//JSON manipulate

//http

//model
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using Utility = surflex.netcore22.Helpers.Utility;
using User = surflex.netcore22.Models.User;

//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;


//token
using System.IdentityModel.Tokens;
using System.Text;
using Microsoft.IdentityModel.Tokens;

//EF
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

using surflex.netcore22.Extensions;
using Microsoft.AspNetCore.Authentication;
using System.DirectoryServices.AccountManagement;

namespace surflex.netcore22.Services
{

    public interface IUserService
    {
        //Task<User> LDAPAuthenAsync();

        Task<User> CreateAsync(User user);
        Task<User> UpdateAsync(User user);
        Task<User> DeleteAsync(string id);

        // Task<User> GetByUniqueAsync(string unique);

        Task<User> GetAsync(string id);
        //Task<IEnumerable<UserAuthen>> ListUserAuthenAsync(string id);
        //Task<UserAuthen> PutProjectAsync(UserAuthen user);
        Task<User> EnforceUserExistenceAsync(string id);

        Task<IEnumerable<User>> ListAsync();
        Task<IEnumerable<User>> ListAuthorizeAsync();
        //Task<User> GetHttpUserAsync();

        Task<IEnumerable<User>> BatchRegisterAsync(List<User> users);
        Task<IEnumerable<User>> BatchRemoveAsync(List<User> users);
        //Task<IEnumerable<User>> HierarchyAsync(IQueryCollection query);

        Task<IEnumerable<User>> SynceAsync();
        //Task<IEnumerable<UserAuthen>> List\AuthenAsync();

        // Task<IEnumerable<User>> ListRecentlyAsync();
        // Task<IEnumerable<UserAuthen>> ListAuthenAsync();
        Task<IEnumerable<User>> ListAuthenAsync();
        Task<IEnumerable<User>> ListResponsibilityAsync();
        Task<UserAuthen> EnforceAuthenExistenceAsync(Guid id);
        Task<UserAuthen> UpdateAsync(UserAuthen user);
        Task<UserAuthen> CreateAsync(UserAuthen user);
        Task<User> AuthenAsync();

        Task<User> AuthenAsync(Token token);
    }

    public class UserService : IUserService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _configuration;
        private readonly IUserRepository _userRepository;

        private readonly IUserAuthenRepository _userAuthenRepository;

        private readonly ILoggService _sessionLoggService;

        protected readonly IRoleUserService _roleUserService;

        private readonly IProjectUserService _projectUserService;
        private readonly IHttpService _httpService;

        private readonly IWorkUnitService _workUnitService;
        private readonly User httpCurrentUser;
        //  private const int TOKEN_EXPIRED_DAYS = 7;
        //private const int TOKEN_EXPIRED_SEC = 30;

        public UserService(IHttpContextAccessor httpContextAccessor, IConfiguration configuration,
                IUserRepository userRepository, IUserAuthenRepository userAuthorizeRepository, ILoggService sessionLoggService, IHttpService httpService,
                IRoleUserService roleUserService, IProjectUserService projectUserService, IWorkUnitService workUnitService) //, IClanService clanService)
        {
            _userRepository = userRepository ?? throw new ArgumentNullException(nameof(userRepository));
            _userAuthenRepository = userAuthorizeRepository ?? throw new ArgumentNullException(nameof(userAuthorizeRepository));

            _httpService = httpService ?? throw new ArgumentNullException(nameof(httpService));

            _sessionLoggService = sessionLoggService ?? throw new ArgumentNullException(nameof(sessionLoggService));
            _roleUserService = roleUserService ?? throw new ArgumentNullException(nameof(roleUserService));
            _workUnitService = workUnitService ?? throw new ArgumentNullException(nameof(workUnitService));

            _projectUserService = projectUserService ?? throw new ArgumentNullException(nameof(projectUserService));

            _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor)); ;
            _configuration = configuration;

            try
            {

                httpCurrentUser = _httpService.GetHttpCurrentUserAsync().Result;
            }
            catch (InvalidTokenException) { }

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }

        //should refactory if using
        /* public async Task<User> LDAPAuthenAsync()
         {
             //Log.Information("authenAsync invoke");
             //default
             string httpContextUser = _httpContextAccessor.HttpContext.User.Identity.Name;

             if (httpContextUser == null)
             {
                 httpContextUser = _configuration["AppSettings:User:MockingName"];
             }

             //var user = await _userManager.GetUserAsync(_context.HttpContext.User);
             //HttpContextAccessor _httpContextAccessor = new HttpContextAccessor();

             //Serverless Binding 
             //gets the distinguished name of the domain that the local computer is a member 
             DirectoryEntry RootDirEntry = new DirectoryEntry("LDAP://RootDSE");
             Object distinguishedName = RootDirEntry.Properties["defaultNamingContext"].Value;

             RootDirEntry = new DirectoryEntry("LDAP://" + distinguishedName.ToString());

             //DirectorySearcher rootDirSearcher = new DirectorySearcher(RootDirEntry);

             //binary value that specifies the security identifier (SID) of the user. 
             //SID is a id value used to identify the user as a security principal.
             //Byte objectSID =  Convert.ToByte(RootDirEntry.Properties["objectSID"].Value);

             // Here starts the query
             DirectorySearcher search = new DirectorySearcher(RootDirEntry)
             {
                 SearchScope = SearchScope.Subtree,
                 Filter = "(&" +
                     "(objectClass=user)" +
                     // "(givenname=s*)" +
                     "(samaccountname=" + httpContextUser + ")" +
                 ")"
             };

             //search.PropertiesToLoad.Add("cvx-cai");
             //what the fuck ??? travelsal

             //CAI
             SearchResultCollection result = search.FindAll();
             ResultPropertyCollection collection = result[0].Properties;
             ResultPropertyValueCollection values = collection["cvx-cai"];

             string id = Guid.NewGuid().ToString();

             User u = new User()
             {
                 Id = id,
                 CAI = values[0].ToString()
             };

             //name
             values = collection["displayName"];
             u.Name = values[0].ToString();

             //is authentication
             PrincipalContext principalContext = new PrincipalContext(ContextType.Domain, "CT");
             UserPrincipal user = UserPrincipal.FindByIdentity(principalContext, httpContextUser);
             var roles = user.GetAuthorizationRoles();

             string authenticationRole = _configuration["AppSettings:User:AuthenticatedRole"];
             Log.Information(authenticationRole);

             u.IsAuthenticate = roles.Contains(RolePrincipal.FindByIdentity(principalContext, authenticationRole));

             return await Task.FromResult<User>(u);
         }*/


        //
        // Summary:
        //     Returns the http request api user from window credential
        //
        // Returns:
        //     Models.Entity.User object
        //
        // Type parameters:
        //   httpContext:
        //     a base of http context
        //
        /* /public async Task<User> GetHttpUserAsync()
        {
            await Task.Delay(0);
            throw new NotImplementedException();
        }*/

        public async Task<User> CreateAsync(User user)
        {
            if (string.IsNullOrEmpty(user.CAI))
            {
                throw new UserNotValidException(user);
            }

            user.CAI = user.CAI.ToUpper();

            user.By = httpCurrentUser.Id;

            //assigned
            user.Id = Utility.ToUniqeIdentity(user.CAI);
            user.Created = Utility.CurrentSEAsiaStandardTime();

            //await EnforceClanExistenceAsync(User.Clan.Name);
            var entity = await _userRepository.CreateAsync(user);
            return entity;


        }


        //
        // Summary:
        //     retrun the list of ACTIVE record of user authorizle 
        //
        // Returns:
        //
        //   list of  Models.Entity.User object
        //
        //

        public async Task<IEnumerable<User>> ListAuthenAsync()
        {
            return await _userRepository.ListAuthenAsync();
        }

        //
        // Summary:
        //     retrun the list of ACTIVE record of user authorizle with lass login
        //
        // Returns:
        //
        //   list of  Models.Entity.User object
        //
        //
        public async Task<IEnumerable<User>> ListAuthorizeAsync()
        {
            var entities = await _userRepository.ListAuthorizeAsync();
            return entities;
        }



        //
        // Summary:
        //     retrun the list of ACTIVE record of user authorizle with lass login
        //
        // Returns:
        //
        //   list of  Models.Entity.User object
        //
        //
        public async Task<IEnumerable<User>> ListResponsibilityAsync()
        {
            var entities = await _userRepository.ListAuthorizeAsync();
            var result = new List<User>();
            //set value
            foreach (var u in entities)
            {
                try
                {
                    u.LastLogin = await _sessionLoggService.GetRecentlyAsync(u.Id);

                }
                catch (SessionLoggNotFoundException) { }

                result.Add(u);
            }

            return result;
        }


        //Task<User> GetHttpUserAsync();


        public async Task<User> UpdateAsync(User _user)
        {
            var user = await this.EnforceUserExistenceAsync(_user.Id);

            user.CAI = user.CAI.ToUpper();

            //assigned
            //user.upda = Utility.CurrentSEAsiaStandardTime();
            user.Name = _user.Name;
            // user.Role = _user.Role;

            var entity = await _userRepository.UpdateAsync(user);
            return entity;
        }

        public async Task<User> GetAsync(string id)
        {
            //await EnforceClanExistenceAsync(User.Clan.Name);
            //await EnforceUserExistenceAsync(User.Clan.Name, User.Key);
            // await this.EnforceUserExistenceAsync(id);

            var user = await _userRepository.GetAsync(id);
            return user;
        }

        public async Task<User> DeleteAsync(string id)
        {
            await this.EnforceUserExistenceAsync(id);

            var entity = await _userRepository.DeleteAsync(id);
            return entity;
        }

        public async Task<IEnumerable<User>> ListAsync()
        {
            return await _userRepository.ListAsync();
        }


        public async Task<IEnumerable<User>> SynceAsync()
        {
            await Task.Delay(0);
            const string LDAP_PATH = "CT.CHEVRONTEXACO.NET";

            //move to config
            var surfaceRoleList = new string[] { };// "BKKHQ SURFACE DB Dev", "BKKHQ SURFACE Users Test" };
            surfaceRoleList = _configuration.GetSection("AppSettings:User:SynceADGroup").Get<string[]>();

            // _configuration.GetSection() ["AppSettings:SynceADGroup"];

            var entities = new List<User>();

            foreach (var roleName in surfaceRoleList)
            {
                //Log.Information("Members of the {0} Role in the {1} Domain", roleName, LDAP_PATH);

                using (var context = new PrincipalContext(ContextType.Domain, LDAP_PATH))
                {
                    using (var role = GroupPrincipal.FindByIdentity(context, roleName))
                    {
                        if (role == null)
                        {
                            //throw new RoleNotFoundException();
                        }
                        else
                        {
                            var users = role.GetMembers(true);
                            foreach (UserPrincipal user in users)
                            {
                                //user variable has the details about the user 
                                // Log.Information(user.EmailAddress);
                                if (user.SamAccountName == "nitiwutn")
                                {

                                };

                                var temp = new User()
                                {
                                    Email = user.EmailAddress,
                                    Name = user.Name,
                                    DisplayName = user.DisplayName,
                                    GivenName = user.GivenName,

                                    AccountName = user.SamAccountName,

                                    ADGroup = roleName,

                                    CAI = user.SamAccountName,

                                    ADId = user.Guid.GetValueOrDefault(),
                                    IsADEnable = user.Enabled.GetValueOrDefault(),

                                    EmployeeId = user.EmployeeId,

                                    Unique = user.EmailAddress
                                };


                                entities.Add(temp);
                            }
                        }
                    }
                }

                //  userDetailList.AddRange(Authenticate.getUsersFromRole(roleName));

            }
            return entities;
        }

        /* public async Task<IEnumerable<User>> HierarchyAsync(IQueryCollection query)
        {
            var userListQuery = new UserListQuery();

            if (!string.IsNullOrEmpty(query["cai"]))
                userListQuery.CAI = query["cai"];

            if (!string.IsNullOrEmpty(query["name"]))
                userListQuery.Name = query["name"];

            if (!string.IsNullOrEmpty(query["id"]))
                userListQuery.Unique = query["id"];

            int page;
            if (!string.IsNullOrEmpty(query["page"]) && int.TryParse(query["page"], out page))
                userListQuery.Page = page;

            int limit;
            if (!string.IsNullOrEmpty(query["limit"]) && int.TryParse(query["limit"], out limit))
                userListQuery.Limit = limit;

            return await _userRepository.HierarchyAsync(userListQuery);
        }*/

        /* public async Task<IEnumerable<UserAuthen>> ListUserAuthenAsync(string id)
        {
            //await _projectService.EnforceProjectExistenceAsync(id);

            return await _userRepository.ListUserAuthenAsync(id);
        }

        public async Task<UserAuthen> PutProjectAsync(UserAuthen auth)
        {
            await this.EnforceUserExistenceAsync(auth.UserId);
            //await _projectService.EnforceProjectExistenceAsync(auth.ProjectId);

            //assigned
            auth.Id = Guid.NewGuid().ToString();
            auth.By = "admin";
            auth.Started = Utility.CurrentSEAsiaStandardTime();

            var entity = await _userRepository.PutProjectAsync(auth);
            return entity;
        }*/



        //
        // Summary:
        //     Return the list of authorize role/project  if token is valid
        //
        // Returns:
        //     User object
        //
        // Type parameters:
        //   token:
        //      azure AD token
        //
        public async Task<User> AuthenAsync(Token token)
        {
            string secret = _configuration["AppSettings:SecretKey"];
            //string resourceId = _configuration["AppSettings:Resource"];


            var accessToken = new JwtSecurityToken(jwtEncodedString: token.AccessToken);
            var id = accessToken.Claims.First(c => c.Type == "unique_name").Value;
            //var id = httpCurrentUser.Id;

            //id = "thanyadol.ch@chevron.com";
            //checkuser
            var entity = await _userRepository.ListAsync();
            var us = entity.Where(c => c.Unique == id).FirstOrDefault();
            if (us == null)
            {
                throw new UserNotFoundException();
            }

            //use role from Auzre
            //tokenUser.Role = role;
            var user = this.PutTokenAsync(us, secret);

            //persist login session logg
            {
                var session = new SessionLogg()
                {
                    UserId = user.Id,
                    Token = user.Token,

                    CAI = user.CAI,
                    TokenExpiredDate = user.TokenExpiredDate,
                };

                var ss = await _sessionLoggService.CreateAsync(session);
                if (ss == null)
                {
                    throw new SessionLoggNotFoundException();
                }

                user.LastLogin = ss;
            }

            return user;
        }


        //
        // Summary:
        //     Return the list of authorize role/project  if token is valid
        //
        // Returns:
        //     User object
        //
        // Type parameters:
        //   token:
        //      azure AD token
        //
        public async Task<User> AuthenAsync()
        {
            string secret = _configuration["AppSettings:SecretKey"];
            //string resourceId = _configuration["AppSettings:Resource"];

            var id = httpCurrentUser.Id;

            //id = "thanyadol.ch@chevron.com";
            //checkuser
            var entity = await _userRepository.ListAsync();
            var us = entity.Where(c => c.Id == id).FirstOrDefault();
            if (us == null)
            {
                throw new UserNotFoundException();
            }

            //use role from Auzre
            //tokenUser.Role = role;
            var user = this.PutTokenAsync(us, secret);


            //persist login session logg
            {
                var session = new SessionLogg()
                {
                    UserId = user.Id,
                    Token = user.Token,

                    CAI = user.CAI,
                    TokenExpiredDate = user.TokenExpiredDate,
                };

                var ss = await _sessionLoggService.CreateAsync(session);
                if (ss == null)
                {
                    throw new SessionLoggNotFoundException();
                }

                user.LastLogin = ss;
            }

            return user;
        }


        //
        // Summary:
        //     Return the persistednce AD user to SURFACE
        //
        // Returns:
        //     User object
        //
        // Type parameters:
        //   token:
        //      azure AD token
        //
        public async Task<IEnumerable<User>> BatchRegisterAsync(List<User> users)
        {
            int ADD_DAY = Convert.ToInt16(_configuration["AppSettings:User:DefaultValidationInDay"]);

            var entities = new List<User>();
            using (var transaction = _workUnitService.BeginTransaction())
            {
                foreach (var u in users)
                {
                    var entity = await this.EnforceUserCreateAsync(u);
                    if (entity == null)
                    {
                        throw new UserNotFoundException();

                    }

                    //first authen 
                    var auth = new UserAuthen()
                    {
                        Id = Guid.NewGuid(),
                        UserId = entity.Id,
                        CAI = entity.CAI,
                        ExpiredDate = Utility.CurrentSEAsiaStandardTime().AddDays(ADD_DAY),
                        Status = RecordStatus.ACTIVE.GetDescription(),
                        Date = Utility.CurrentSEAsiaStandardTime(),
                        By = httpCurrentUser.Id,

                        IsEnabled = true,
                    };


                    var c = await _workUnitService.UserAuthens.CreateAsync(auth);
                    if (c == null)
                    {
                        throw new UserAuthenNotFoundException();

                    }

                    entities.Add(u);
                }

                try
                {
                    transaction.Commit();
                    return entities;
                }
                catch (InvalidOperationException ex)
                {
                    transaction.Rollback();
                    throw new PriceNotValidException(ex.Message);
                }

            }
        }

        //
        // Summary:
        //     Return the forget persistednce AD user to SURFACE
        //
        // Returns:
        //     User object
        //
        // Type parameters:
        //   token:
        //      azure AD token
        //
        public async Task<IEnumerable<User>> BatchRemoveAsync(List<User> users)
        {
            //const int ADD_MONTH = 6;

            var entities = new List<User>();
            using (var transaction = _workUnitService.BeginTransaction())
            {
                foreach (var u in users)
                {
                    //encforec created
                    var entity = await this.EnforceUserExistenceAsync(u.Id);
                    if (entity == null)
                    {
                        throw new UserNotFoundException();

                    }


                    //disable authen
                    var auths = await _userAuthenRepository.ListRecentlyAsync();
                    auths = auths.Where(c => c.UserId == u.Id);
                    foreach (var ent in auths)
                    {
                        var enty = await _userAuthenRepository.GetAsync(ent.Id);

                        //set archived
                        enty.Status = RecordStatus.ARCHIVED.GetDescription();
                        var c = await _workUnitService.UserAuthens.UpdateAsync(enty);
                    }


                    //disable role authorize
                    var roles = await _roleUserService.ListRecentlyAuthorizeAsync();
                    roles = roles.Where(c => c.UserId == u.Id);
                    foreach (var ent in roles)
                    {
                        var enty = await _roleUserService.GetAsync(ent.Id);

                        //set archived
                        enty.Status = RecordStatus.ARCHIVED.GetDescription();
                        var c = await _workUnitService.RoleAuthorizes.UpdateAsync(enty);
                    }


                    //disable project authorize
                    var authors = await _projectUserService.ListRecentlyAsync();
                    authors = authors.Where(c => c.UserId == u.Id);
                    foreach (var ent in authors)
                    {
                        var enty = await _projectUserService.GetAsync(ent.Id);

                        //set archived
                        enty.Status = RecordStatus.ARCHIVED.GetDescription();
                        var c = await _workUnitService.ProjectAuthorizes.UpdateAsync(enty);
                    }

                    entities.Add(u);
                }

                try
                {
                    transaction.Commit();
                    return entities;
                }
                catch (InvalidOperationException ex)
                {
                    transaction.Rollback();
                    throw new UserNotValidException(ex.Message);
                }

            }

            // return entities;
        }

        //generate token
        private User PutTokenAsync(User user, string secret)
        {
            // JWT specification -> https://self-issued.info/docs/draft-ietf-oauth-json-web-token.html
            // MSDN: https://msdn.microsoft.com/en-us/library/system.identitymodel.tokens.jwtsecuritytoken(v=vs.114).aspx

            var TOKEN_EXPIRED_SEC = 30;
            try
            {

                TOKEN_EXPIRED_SEC = Convert.ToInt16(_configuration["AppSettings:User:TokenTimeSpanInSeconds"]);
            }
            catch (ArgumentException) { throw new ConfigurationNotValidException("Appsetting is not valid"); }
            catch (NullReferenceException) { throw new ConfigurationNotFoundException("Appsetting is not valid"); }

            //checkuser
            //var user = _users.SingleOrDefault(x => x.Username == username && x.Password == password);
            var expired = DateTime.Now.AddSeconds(TOKEN_EXPIRED_SEC);
            // authentication successful so generate jwt token
            var tokenHandler = new JwtSecurityTokenHandler();

            var key = Encoding.ASCII.GetBytes(secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.NameIdentifier, user.Id),
                    new Claim(ClaimTypes.Name, user.CAI),
                    //new Claim(ClaimTypes.Role, user.Role),
             //       new Claim(ClaimTypes.Expired, user.CAI),
                    new Claim(JwtRegisteredClaimNames.Sid, user.Id),
                }),

                Expires = expired,
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var apiToken = tokenHandler.CreateToken(tokenDescriptor);
            user.Token = tokenHandler.WriteToken(apiToken);

            //set value buffer
            user.TokenExpiredDate = expired;

            return user;
        }


        public async Task<UserAuthen> CreateAsync(UserAuthen user)
        {
            //deactive
            //deactive old
            if (user.Id != Guid.Empty)
            {
                var product = await _userAuthenRepository.GetAsync(user.Id);
                if (product == null)
                {
                    throw new UserNotFoundException();
                }

                product.Status = RecordStatus.ARCHIVED.GetDescription();
                await _userAuthenRepository.UpdateAsync(product);
            }
            else
            {
                //user.Key = Guid.NewGuid().ToString();
            }

            //await this.EnforceWellExistenceAsync(Api.WellId);
            //assigned
            user.Id = Guid.NewGuid();
            user.Date = Utility.CurrentSEAsiaStandardTime();
            user.By = httpCurrentUser.Id;
            user.Status = RecordStatus.ACTIVE.GetDescription();

            //api. = httpCurrentUser.Id;

            //api.Description = "hello this is a new api from develper";

            //new rev and key
            //api.Rev = Guid.NewGuid().ToString();
            //api.Key = Guid.NewGuid().ToString();

            //await EnforceClanExistenceAsync(Api.Clan.Name);
            var entity = await _userAuthenRepository.CreateAsync(user);
            if (entity == null)
            {
                throw new UserAuthenNotFoundException();
            }

            return entity;
        }



        public async Task<UserAuthen> UpdateAsync(UserAuthen user)
        {
            var updated = await this.EnforceAuthenExistenceAsync(user.Id);

            updated.Date = Utility.CurrentSEAsiaStandardTime();
            updated.By = httpCurrentUser.Id;

            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //api.Key = Guid.NewGuid().ToString();

            var entity = await _userAuthenRepository.UpdateAsync(user);
            if (entity == null)
            {
                throw new UserAuthenNotFoundException();
            }

            return entity;
        }


        //
        // Summary:
        //     Return the validae user rols as strring 
        //
        // Returns:
        //     string object
        //
        // Type parameters:
        //   role:
        //      mathced role
        //
        /* private void ValidateUserRole(string role)
        {
            var roles = new string[] { "Drilling", "PetroleumEngineer", "EarthScientist" };

            if (!roles.Contains(role))
            {
                throw new InvalidTokenException();
            }
        }*/

        public async Task<User> EnforceUserExistenceAsync(string id)
        {
            var user = await _userRepository.GetAsync(id);

            if (user == null)
            {
                throw new UserNotFoundException();
            }

            return user;
        }


        public async Task<User> EnforceUserCreateAsync(User user)
        {
            var id = Utility.ToUniqeIdentity(user.CAI);
            var enforece = await _userRepository.GetAsync(id);
            if (enforece != null)
            {
                return enforece;
            }

            //await EnforceClanExistenceAsync(Well.Clan.Name);
            var entity = await this.CreateAsync(user);
            return entity;
        }

        public async Task<UserAuthen> EnforceAuthenExistenceAsync(Guid id)
        {
            var act = await _userAuthenRepository.GetAsync(id);

            if (act == null)
            {
                throw new UserAuthenNotFoundException();
            }

            return act;
        }

    }

}