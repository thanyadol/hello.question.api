using System; 

using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;

using Microsoft.AspNetCore.Http;
//Windows Authen

//configure
using Microsoft.Extensions.Configuration;
//logg
using Serilog;
using surflex.netcore22.Exceptions;
//JSON manipulate

//http

//model
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using Utility = surflex.netcore22.Helpers.Utility;
using User = surflex.netcore22.Models.User;

//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;


//token
using System.IdentityModel.Tokens;
using System.Text;
using Microsoft.IdentityModel.Tokens;

//EF
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

//grapth
// using Microsoft.Azure.ActiveDirectory.GraphClient;  // Will eventually be removed


namespace surflex.netcore22.Services
{

    public interface IHttpService
    {

        Task<User> GetHttpCurrentUserAsync();

    }

    public class HttpService : IHttpService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _configuration;

        private readonly IUserRepository _userRepository;

        public HttpService(IHttpContextAccessor httpContextAccessor, IConfiguration configuration, IUserRepository userRepository) //, IProjectService projectService) //, IClanService clanService)
        {

            _userRepository = userRepository ?? throw new ArgumentNullException(nameof(userRepository));

            _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
            _configuration = configuration;


            //httpCurrentHttp = this.GetHttpHttpAsync().Result;


            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }

        //
        // Summary:
        //     Returns the http request api user from window credential
        //
        // Returns:
        //     Models.Entity.Http object
        //
        // Type parameters:
        //   httpContext:
        //     a base of http context
        //
        public async Task<User> GetHttpCurrentUserAsync()
        {
            await Task.Delay(0);
            string mode = _configuration["AppSettings:AuthenticationMode"];
            var current = new User() { Id = "anonymous", DisplayName = "Anonymous" };
            var httpContext = _httpContextAccessor.HttpContext;

            //var someClaim = Http.Claims.FirstOrDefault(c => c.Type == "sid").Value;
            //var someClaim = Http.Claims.FirstOrDefault(c => c.Type == "unique_name").Value;

            //var claimsIdentity = Http.Identity as ClaimsIdentity;

            // alternatively
            // claimsIdentity = HttpContext.Http.Identity as ClaimsIdentity;

            // get some claim by type
            // var someClaim = Http.Claims.FirstOrDefault(c => c.Type == "Currency").Value;

            //  iterate all claims
            /*foreach (var claim in claimsIdentity.Claims)
            {
                Log.Information(claim.Type + ":" + claim.Value);
            }*/


            switch (mode)
            {
                case "Windows":

                    var claimsIdentity = httpContext.User.Identity as ClaimsIdentity;
                    //IsAuthenticated = httpContext.Http.Identity.IsAuthenticated;
                    if (claimsIdentity == null)
                    {
                        throw new SecurityTokenNotYetValidException();
                    }

                    //var claim = httpContext.Http.Claims.FirstOrDefault(c => c.Type == "Name").Value;
                    // alternatively
                    claimsIdentity = httpContext.User.Identity as ClaimsIdentity;

                    // get some claim by type
                    //var claim = claimsIdentity.Claims.FirstOrDefault(c => c.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name");
                    var claim = claimsIdentity.Name;
                    if (claim == null)
                    {
                        throw new SecurityTokenNotYetValidException();
                    }

                    // ctx\\hrzx
                    string[] words = claim.Split('\\');
                    if (words.Length < 2)
                    {
                        throw new SecurityTokenNotYetValidException();
                    }

                    var cai = words[1];

                    //get user
                    var entity = await _userRepository.GetAsync(Utility.ToUniqeIdentity(cai));
                    //  var user = entity.Where(c => c.CAI.ToLower() == cai).FirstOrDefault();
                    if (entity == null)
                    {
                        throw new UserNotFoundException(cai);
                    }

                    current.Id = entity.Id;//Utility.ToUniqeIdentity(cai);
                    current.CAI = entity.CAI; //cai;

                    break;

                case "OAuth2":
                    var sid = httpContext.User.Claims.FirstOrDefault(c => c.Type == "sid");
                    if (sid == null)
                    {
                        break;
                        //throw new InvalidTokenException();
                    }

                    var id = sid.Value;

                    // var query = await _userRepository.List(id);
                    // var user = entity.Where(c => c.CAI.ToLower() == cai).FirstOrDefault();
                    // if (query == null)
                    // {
                    //     throw new UserNotFoundException();
                    // }

                    current.Id = id;
                    //current.CAI = cai;


                    break;

                case "Anonymous":
                default:
                    break;
            }

            return current;
        }


    }

}