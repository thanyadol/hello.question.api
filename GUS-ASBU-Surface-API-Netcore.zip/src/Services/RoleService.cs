using System; 

using System.Collections.Generic;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using surflex.netcore22.Exceptions;

//logg
using Serilog;
using surflex.netcore22.Helpers;
using System.IO;
using System.Net.Http;
using surflex.netcore22.Extensions;
using System.IdentityModel.Tokens.Jwt;


using GLOBAL = surflex.netcore22.Models.Constants.GlobalConstants;
using Microsoft.Extensions.Configuration;
using System.Text;

namespace surflex.netcore22.Services
{
    public interface IRoleService
    {
        Task<Role> CreateAsync(Role role);
        Task<Role> UpdateAsync(Role role);
        Task<Role> DeleteAsync(Guid id);

        Task<Role> GetAsync(Guid id);

        Task<IEnumerable<Role>> ListAsync();
        Task<Role> EnforceRoleExistenceAsync(Guid id);


        //authen
        Task<RoleAuthorize> CreateAsync(RoleAuthorize role);
        //   Task<RoleAuthorize> UpdateAsync(RoleAuthorize role);
        // Task<RoleAuthorize> DeleteAsync(Guid id);

        Task<RoleAuthorize> GetAuthorizeAsync(Guid id);

        Task<IEnumerable<RoleAuthorize>> ListAuthorizeAsync();
        Task<RoleAuthorize> EnforceRoleAuthorizeExistenceAsync(Guid id);


        //page role
        // Task<RolePage> CreateAsync(RolePage page);
        // Task<RolePage> UpdateAsync(RolePage page);
        // // Task<RolePage> DeleteAsync(Guid id);

        // Task<RolePage> GetPageAsync(Guid id);

        // Task<IEnumerable<RolePage>> ListPageAsync();
        // Task<RolePage> EnforceRolePageExistenceAsync(Guid id);

        // Task<IEnumerable<RolePage>> ListRecentlyPageAsync();

        //  Task<IEnumerable<Role>> ListRecentlyAsync();

        Task<User> AuthorizeAsync(Token _token);
        //Task<IEnumerable<Item>> ListLocationAsync();

    }

    public class RoleService : IRoleService
    {


        //role status
        protected readonly IRoleRepository _roleRepository;
        protected readonly IRoleAuthorizeRepository _roleAuthorizeRepository;
        protected readonly IRoleModuleRepository _roleModuleRepository;

        // protected readonly IRolePageRepository _rolePageRepository;
        private readonly IWorkUnitService _workUnitService;
        protected readonly IHttpService _httpService;

        protected readonly IUserService _userService;
        protected readonly IProjectService _projectService;

        protected readonly IRoleUserService _roleUserService;

        private readonly User httpCurrentUser;

        private readonly IApiService _apiService;
        private readonly IPageService _pageService;
        private readonly IModuleService _moduleService;

        protected readonly IConfiguration _configuration;

        public RoleService(IRoleRepository roleRepository, IRoleAuthorizeRepository roleAuthorizeRepository, IWorkUnitService workUnitService, IUserService userService,
                IHttpService httpService, /* IRolePageRepository rolePageRepository,*/ IApiService apiService, IPageService pageService, IRoleUserService roleUserService,
                IRoleModuleRepository roleModuleRepository, IModuleService moduleService, IProjectService projectService, IConfiguration configuration) //, IPathFinderService pathFinderService)
        {
            _roleRepository = roleRepository ?? throw new ArgumentNullException(nameof(roleRepository));
            _roleAuthorizeRepository = roleAuthorizeRepository ?? throw new ArgumentNullException(nameof(roleAuthorizeRepository));

            _httpService = httpService ?? throw new ArgumentNullException(nameof(httpService));


            _workUnitService = workUnitService ?? throw new ArgumentNullException(nameof(workUnitService));
            _httpService = httpService ?? throw new ArgumentNullException(nameof(httpService));

            _apiService = apiService ?? throw new ArgumentNullException(nameof(apiService));
            _pageService = pageService ?? throw new ArgumentNullException(nameof(pageService));

            _userService = userService ?? throw new ArgumentNullException(nameof(userService));
            _projectService = projectService ?? throw new ArgumentNullException(nameof(projectService));

            _roleUserService = roleUserService ?? throw new ArgumentNullException(nameof(roleUserService));

            _roleModuleRepository = roleModuleRepository ?? throw new ArgumentNullException(nameof(roleModuleRepository));
            _moduleService = moduleService ?? throw new ArgumentNullException(nameof(moduleService));

            _configuration = configuration;

            try
            {

                httpCurrentUser = _httpService.GetHttpCurrentUserAsync().Result;
            }
            catch (InvalidTokenException) { }


            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }




        public async Task<Role> CreateAsync(Role role)
        {
            //await this.EnforceWellExistenceAsync(Role.WellId);
            //assigned
            role.Id = Guid.NewGuid();
            role.Created = Utility.CurrentSEAsiaStandardTime();

            //role. = httpCurrentUser.Id;

            role.Description = "hello this is a new role from develper";

            //new rev and key
            //role.Rev = Guid.NewGuid().ToString();
            //role.Key = Guid.NewGuid().ToString();

            //await EnforceClanExistenceAsync(Role.Clan.Name);
            var entity = await _roleRepository.CreateAsync(role);
            if (entity == null)
            {
                throw new RoleNotFoundException(role);
            }

            return entity;
        }



        public async Task<Role> UpdateAsync(Role role)
        {
            var updated = await this.EnforceRoleExistenceAsync(role.Id);

            //assigned
            //role.Created = Utility.CurrentSEAsiaStandardTime();
            //Role.Role = Role.Role;
            //Role.Status = Role.Status;
            //   role.By = httpCurrentUser.Id;

            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //role.Key = Guid.NewGuid().ToString();

            var entity = await _roleRepository.UpdateAsync(role);
            if (entity == null)
            {
                throw new RoleNotFoundException(role);
            }

            return entity;
        }

        public async Task<Role> GetAsync(Guid id)
        {
            //  await this.EnforceRoleExistenceAsync(id);

            var entity = await _roleRepository.GetAsync(id);
            return entity;
        }


        public async Task<Role> DeleteAsync(Guid id)
        {
            await this.EnforceRoleExistenceAsync(id);

            var entity = await _roleRepository.DeleteAsync(id);
            return entity;
        }

        public async Task<IEnumerable<Role>> ListAsync()
        {
            return await _roleRepository.ListAsync();
        }

        // public async Task<IEnumerable<Role>> ListRecentlyAsync()
        // {
        //     return await _roleRepository.ListRecentlyAsync();
        // }

        public async Task<Role> EnforceRoleExistenceAsync(Guid id)
        {
            var act = await _roleRepository.GetAsync(id);

            if (act == null)
            {
                throw new RoleNotFoundException(id.ToString());
            }

            return act;
        }


        //authen
        public async Task<RoleAuthorize> CreateAsync(RoleAuthorize role)
        {
            //await this.EnforceWellExistenceAsync(RoleAuthorize.WellId);
            //assigned
            role.Id = Guid.NewGuid();
            role.Date = Utility.CurrentSEAsiaStandardTime();
            role.Status = RecordStatus.ACTIVE.GetDescription();


            //role. = httpCurrentUser.Id;

            // role.Description = "hello this is a new role from develper";

            //new rev and key
            //role.Rev = Guid.NewGuid().ToString();
            //role.Key = Guid.NewGuid().ToString();

            //await EnforceClanExistenceAsync(RoleAuthorize.Clan.Name);
            var entity = await _roleAuthorizeRepository.CreateAsync(role);
            if (entity == null)
            {
                throw new RoleAuthorizeNotFoundException();
            }

            return entity;
        }



        /* public async Task<RoleAuthorize> UpdateAsync(RoleAuthorize role)
        {
            var updated = await this.EnforceRoleAuthorizeExistenceAsync(role.Id);

            //assigned
            //role.Created = Utility.CurrentSEAsiaStandardTime();
            //RoleAuthorize.RoleAuthorize = RoleAuthorize.RoleAuthorize;
            //RoleAuthorize.Status = RoleAuthorize.Status;
            //   role.By = httpCurrentUser.Id;

            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //role.Key = Guid.NewGuid().ToString();

            var entity = await _roleAuthorizeRepository.UpdateAsync(role);
            if (entity == null)
            {
                throw new RoleAuthorizeNotFoundException();
            }

            return entity;
        }*/

        public async Task<RoleAuthorize> GetAuthorizeAsync(Guid id)
        {
            //  await this.EnforceRoleAuthorizeExistenceAsync(id);

            var entity = await _roleAuthorizeRepository.GetAsync(id);
            return entity;
        }



        public async Task<IEnumerable<RoleAuthorize>> ListAuthorizeAsync()
        {
            return await _roleAuthorizeRepository.ListAsync();
        }




        //
        // Summary:
        //     retrun the list of ACTIVE record of user ROLE
        //
        // Returns:
        //
        //   list of  Models.Entity.RoleAuthorize object
        //
        //

        // public async Task<IEnumerable<RolePage>> ListRecentlyPageAsync()
        // {
        //     return await _rolePageRepository.ListRecentlyAsync();
        // }



        public async Task<RoleAuthorize> EnforceRoleAuthorizeExistenceAsync(Guid id)
        {
            var act = await _roleAuthorizeRepository.GetAsync(id);

            if (act == null)
            {
                throw new RoleNotFoundException(id.ToString());
            }

            return act;
        }


        //page
        // public virtual async Task<RolePage> CreateAsync(RolePage page)
        // {
        //     //await this.EnforceWellExistenceAsync(RolePage.WellId);
        //     //assigned
        //     page.Id = Guid.NewGuid();
        //     page.Date = Utility.CurrentSEAsiaStandardTime();

        //     //page. = httpCurrentUser.Id;

        //     //page.Description = "hello this is a new page from develper";

        //     //new rev and key
        //     //page.Rev = Guid.NewGuid().ToString();
        //     //page.Key = Guid.NewGuid().ToString();

        //     //await EnforceClanExistenceAsync(RolePage.Clan.Name);
        //     var entity = await _rolePageRepository.CreateAsync(page);
        //     if (entity == null)
        //     {
        //         throw new RoleNotApiNotFoundException()PAGE");
        //     }

        //     return entity;
        // }


        /* 
        public virtual async Task<RolePage> UpdateAsync(RolePage page)
        {
            var updated = await this.EnforceRolePageExistenceAsync(page.Id);

            //assigned
            //page.Created = Utility.CurrentSEAsiaStandardTime();
            //RolePage.RolePage = RolePage.RolePage;
            //RolePage.Status = RolePage.Status;
            //   page.By = httpCurrentUser.Id;

            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //page.Key = Guid.NewGuid().ToString();

            var entity = await _rolePageRepository.UpdateAsync(page);
            if (entity == null)
            {
                throw new RoleNotApiNotFoundException()PAGE");
            }

            return entity;
        }

        public virtual async Task<RolePage> GetPageAsync(Guid id)
        {
            //  await this.EnforceRolePageExistenceAsync(id);

            var entity = await _rolePageRepository.GetAsync(id);
            return entity;
        }

        /*
        public virtual async Task<RolePage> DeleteAsync(Guid id)
        {
            await this.EnforceRolePageExistenceAsync(id);

            var entity = await _rolePageRepository.DeleteAsync(id);
            return entity;
        }*

        public virtual async Task<IEnumerable<RolePage>> ListPageAsync()
        {
            return await _rolePageRepository.ListAsync();
        }

        public virtual async Task<RolePage> EnforceRolePageExistenceAsync(Guid id)
        {
            var act = await _rolePageRepository.GetAsync(id);

            if (act == null)
            {
                throw new RoleNotApiNotFoundException()PAGE");
            }

            return act;
        }*/


        //
        // Summary:
        //     Return the list of authorize role/project  if token is valid
        //
        // Returns:
        //     User object
        //
        // Type parameters:
        //   token:
        //      azure AD token
        //
        public async Task<User> AuthorizeAsync(Token token)
        {

            var accessToken = new JwtSecurityToken(jwtEncodedString: token.AccessToken);
            string id = accessToken.Claims.First(c => c.Type == "sid").Value;

            //validate date
            var effect = accessToken.ValidFrom;
            var expired = accessToken.ValidTo;
            var current = Utility.CurrentSEAsiaStandardTime();


            if (current < effect && current <= expired)
            {
                throw new InvalidTokenException("EXPIRED");
            }

            //var id = httpCurrentUser.Id;

            //id = "thanyadol.ch@chevron.com";
            //checkuser
            var entity = await _userService.ListAsync();
            var us = entity.Where(c => c.Id == id).FirstOrDefault();
            if (us == null)
            {
                throw new UserNotFoundException();
            }

            //chjeck authen
            var users = await _userService.ListAuthenAsync();
            users = users.Where(c => c.Id == us.Id && c.Authen.ExpiredDate >= Utility.CurrentSEAsiaStandardTime());
            if (!users.Any())
            {
                throw new UserAuthenNotFoundException();
            }

            //role, project, authorize
            var uuuu = await _userService.ListAuthorizeAsync();
            var user = uuuu.Where(c => c.Id == us.Id).FirstOrDefault();
            if (user == null)
            {
                throw new RoleAuthorizeNotFoundException();
            }

            //role 
            var access = await _roleRepository.ListRecentlyAsync();
            var modular = await _moduleService.ListRecentlyAsync();
            var pagers = await _pageService.ListRecentlyAsync();

            //buffer
            /* 
            var entities = new List<Role>();
            foreach (var r in user.RoleAuthorizes)
            {
                //transform ??
                var m = access.Where(c => c.Id == r.RoleId).FirstOrDefault();

                m.RoleModule = m.RoleModules.FirstOrDefault();

                var temp = new List<Module>();
                foreach (var j in m.Modules)
                {
                    var t = modular.Where(c => c.Id == j.Id).FirstOrDefault();

                    //   t.ModulePages.Select(c => {  });

                    temp.Add(t);
                }

                m.Modules = temp;
                entities.Add(m);
            }


            user.Roles = entities;*/

            //const string CENTRAL_LOCATION_ID = "CENTRAL";
            // const string NONE_LOCATION_ID = "NONE";

            //process plat object fpr frnt end
            var roles = await _roleRepository.ListAsync();
            var temp = user.RoleAuthorizes.Select(c => c.RoleId).ToArray();
            roles = roles.Where(c => temp.Contains(c.Id));

            var hashset = new HashSet<Guid>(roles.Select(c => c.Id).ToArray());
            var rms = access.Where(c => hashset.Contains(c.Id));

            //role modile
            var fms = rms.SelectMany(c => c.RoleModules.ToList());

            //  var pages = await _pageService.ListRecentlyAsync();

            //conclusion authorize data
            var modulates = new List<Module>();
            foreach (var r in fms)
            {
                var pages = r.Module.ModulePages.Select(c => c.Page);
                //string permission = r.RolePermission;

                var mmmm = new Module()
                {
                    Pages = pages.Select(c => { c.Permission = r.RolePermission; return c; }).ToList(),

                    Permission = r.RolePermission,
                    RoleName = r.Role.Name,
                    LocationId = r.Role.LocationId,

                    ProjectPermission = r.ProjectPermission,
                    RolePermission = r.RolePermission,
                };

                modulates.Add(mmmm);
            }

            user.Modules = modulates;

            //project list
            var projects = new List<Project>();

            //project team
            //where by user
            var authorize = await _projectService.ListAuthorizeAsync();
            authorize = authorize.Where(c => c.ProjectAuthorizes.Any(i => i.UserId == user.Id));

            //list all project
            var projs = await _projectService.ListLocationAsync();
            foreach (var p in projs)
            {
                //set default
                p.Permission = AccessControl.NONE.GetDescription();

                //central or match
                var mole = modulates.Where(c => c.LocationId == GLOBAL.CENTRAL_LOCATION_ID || c.LocationId == p.LocationId);

                //role access
                uint value = 0;
                foreach (var m in mole)
                {
                    // var output = AccessControl.NONE;
                    Enum.TryParse(p.Permission, out AccessControl out1);
                    value = (uint)out1;

                    Enum.TryParse(m.RolePermission, out AccessControl out2);
                    var role = (uint)out2;

                    if (role >= value)
                    {
                        p.Permission = m.RolePermission;

                    }

                    //project access
                    var au = authorize.Where(c => c.Id == p.Id).FirstOrDefault();
                    if (au != null)
                    {
                        // var output = AccessControl.NONE;
                        Enum.TryParse(p.Permission, out AccessControl out3);
                        value = (uint)out3;

                        Enum.TryParse(m.ProjectPermission, out AccessControl out4);
                        var team = (uint)out4;

                        if (team >= value)
                        {
                            p.Permission = m.ProjectPermission;
                        }
                    }
                }

                projects.Add(p);
            }


            //set key
            if (projects.Any(c => c.Permission == AccessControl.FULL.GetDescription()))
            {
                var Base64EncryptionKey = _configuration["AppSettings:Base64EncryptionKey"];

                byte[] key = Encoding.UTF8.GetBytes(Base64EncryptionKey);
                user.Base64EncryptionKey = Array.ConvertAll(key, c => (int)c);
            }


            user.Projects = projects;

            //PAGE FOR filter
            var query = user.Modules.SelectMany(x => x.Pages).Select(c => c.Id);
            hashset = new HashSet<Guid>(query.ToArray());
            //pagers
            pagers = pagers.Where(c => hashset.Contains(c.Id));
            user.Pages = pagers;

            return user;
        }

    }


    public interface IRoleUserService
    {
        Task<RoleAuthorize> GetAsync(Guid id);

        Task<IEnumerable<RoleAuthorize>> ListRecentlyAuthorizeAsync(string id = null);

        Task<IEnumerable<RoleAuthorize>> BatchCreateAsynce(IEnumerable<RoleAuthorize> authos);
    }



    public class RoleUserService : IRoleUserService
    {
        //role status
        protected readonly IRoleRepository _roleRepository;
        protected readonly IRoleAuthorizeRepository _roleAuthorizeRepository;
        // protected readonly IRolePageRepository _rolePageRepository;
        private readonly IWorkUnitService _workUnitService;
        protected readonly IHttpService _httpService;

        private readonly User httpCurrentUser;


        public RoleUserService(IRoleRepository roleRepository, IRoleAuthorizeRepository roleAuthorizeRepository, IWorkUnitService workUnitService,
                IHttpService httpService) //IRolePageRepository rolePageRepository)// IRoleService roleService) //, IPathFinderService pathFinderService)
        {
            _roleRepository = roleRepository ?? throw new ArgumentNullException(nameof(roleRepository));
            _roleAuthorizeRepository = roleAuthorizeRepository ?? throw new ArgumentNullException(nameof(roleAuthorizeRepository));

            _httpService = httpService ?? throw new ArgumentNullException(nameof(httpService));

            _workUnitService = workUnitService ?? throw new ArgumentNullException(nameof(workUnitService));
            //   _httpService = httpService ?? throw new ArgumentNullException(nameof(httpService));


            try
            {

                httpCurrentUser = _httpService.GetHttpCurrentUserAsync().Result;
            }
            catch (InvalidTokenException) { }

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }

        public async Task<RoleAuthorize> GetAsync(Guid id)
        {
            //  await this.EnforceRoleExistenceAsync(id);

            var entity = await _roleAuthorizeRepository.GetAsync(id);
            return entity;
        }


        //list recent authorize by location id
        public async Task<IEnumerable<RoleAuthorize>> ListRecentlyAuthorizeAsync(string id = null)
        {
            //central ??




            var entity = await _roleAuthorizeRepository.ListRecentlyAsync();
            if (String.IsNullOrEmpty(id))
            {
                return entity;
            }
            else
            {

                return entity.Where(c => c.LocationId == id || c.LocationId == GLOBAL.CENTRAL_LOCATION_ID);
            }
            //await Task.Delay(0);
            //throw new NotImplementedException();
        }


        //
        // Summary:
        //     batch operation of user ROLE dedicate by entity type
        //
        // Returns:
        //
        //   list of  Models.Entity.RoleAuthorize object
        //
        // Parameters:
        //   roles : list from front end
        //
        //

        public async Task<IEnumerable<RoleAuthorize>> BatchCreateAsynce(IEnumerable<RoleAuthorize> authos)
        {
            // return await _roleAuthorizeRepository.ListRecentlyAsync();
            var entities = new List<RoleAuthorize>();
            using (var transaction = _workUnitService.BeginTransaction())
            {

                foreach (var r in authos)
                {
                    //validate
                    var ee = await _roleRepository.GetAsync(r.RoleId);
                    if (ee == null)
                    {
                        throw new RoleNotFoundException(ee.Id.ToString());
                    }

                    switch (r.EntityState)
                    {
                        case "ADDED":

                            r.Id = Guid.NewGuid();
                            r.By = httpCurrentUser.Id;
                            r.Status = RecordStatus.ACTIVE.GetDescription();
                            r.Date = Utility.CurrentSEAsiaStandardTime();

                            var e = await _workUnitService.RoleAuthorizes.CreateAsync(r);
                            entities.Add(e);

                            break;

                        case "REMOVED":

                            var rr = await _roleAuthorizeRepository.GetAsync(r.Id);
                            if (rr == null)
                            {
                                throw new RoleAuthorizeNotFoundException();
                            }
                            //set archived
                            rr.Status = RecordStatus.ARCHIVED.GetDescription();

                            var c = await _workUnitService.RoleAuthorizes.UpdateAsync(rr);
                            entities.Add(c);

                            break;
                        default:

                            break;
                    }
                }

                try
                {
                    transaction.Commit();
                    return entities;
                }
                catch (InvalidOperationException ex)
                {
                    transaction.Rollback();
                    throw new RoleNotFoundException(ex.Message);
                }
            }
        }


    }
}