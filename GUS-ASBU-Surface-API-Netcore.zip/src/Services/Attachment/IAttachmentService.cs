//model
using surflex.netcore22.Models;
using System.Collections.Generic;
//logg
using System.IO;
using System.Threading.Tasks;

namespace surflex.netcore22.Services
{
    public interface IAttachmentService
    {
        Task<Attachment> CreateAsync(Attachment attachments);
        Task<Attachment> UpdateAsync(Attachment attachments);
        Task<Attachment> DeleteAsync(string id);

        Task<Attachment> GetAsync(string id);

        Task<Stream> DownloadAsync(string id);

        Task<IEnumerable<Attachment>> ListAsync();
        Task<Attachment> EnforceAttachmentExistenceAsync(string id);

        Task<Attachment> AesEncryptAsync(Attachment attach);
        Task<Attachment> AesDecryptAsync(Attachment cripher);

    }

    public interface IFileStorageAttachmentService : IAttachmentService
    {
    }
}