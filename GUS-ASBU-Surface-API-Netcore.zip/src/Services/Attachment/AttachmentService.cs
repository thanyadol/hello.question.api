using System; 

using System.Collections.Generic;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using surflex.netcore22.Exceptions;

//logg
using Serilog;
using surflex.netcore22.Helpers;
using System.IO;
using System.Net.Http;
using System.Security.Cryptography;
using Microsoft.Extensions.Configuration;
using System.Text;

namespace surflex.netcore22.Services
{
    public class AttachmentService : IAttachmentService
    {
        //attachment status
        protected readonly IAttachmentRepository _attachmentRepository;
        protected readonly IHttpService _httpService;

        protected readonly IPathFinderService _pathFinderService;
        protected readonly User httpCurrentUser;

        protected readonly string Base64EncryptionKey;
        protected readonly IConfiguration _configuration;

        public AttachmentService(IAttachmentRepository attachmentRepository, IHttpService httpService, IPathFinderService pathFinderService, IConfiguration configuration)
        {
            _attachmentRepository = attachmentRepository ?? throw new ArgumentNullException(nameof(attachmentRepository));
            _httpService = httpService ?? throw new ArgumentNullException(nameof(httpService));
            _pathFinderService = pathFinderService ?? throw new ArgumentNullException(nameof(pathFinderService));

            httpCurrentUser = _httpService.GetHttpCurrentUserAsync().Result;
            _configuration = configuration;

            //encrypted key
            Base64EncryptionKey = _configuration["AppSettings:Base64EncryptionKey"];

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }

        public virtual async Task<Attachment> CreateAsync(Attachment attachment)
        {
            //await this.EnforceWellExistenceAsync(Attachment.WellId);
            //assigned
            attachment.Id = Guid.NewGuid().ToString();
            attachment.Date = Utility.CurrentSEAsiaStandardTime();

            attachment.By = httpCurrentUser.Id;

            attachment.Description = "hello this is a new attachemnt from dev";

            //new rev and key
            //attachment.Rev = Guid.NewGuid().ToString();
            //attachment.Key = Guid.NewGuid().ToString();

            //await EnforceClanExistenceAsync(Attachment.Clan.Name);
            var entity = await _attachmentRepository.CreateAsync(attachment);
            if (entity == null)
            {
                throw new AttachmentNotFoundException(attachment);
            }

            return entity;
        }



        public virtual async Task<Attachment> UpdateAsync(Attachment attachment)
        {
            var updated = await this.EnforceAttachmentExistenceAsync(attachment.Id);

            //assigned
            attachment.Date = Utility.CurrentSEAsiaStandardTime();
            //Attachment.Attachment = Attachment.Attachment;
            //Attachment.Status = Attachment.Status;
            attachment.By = httpCurrentUser.Id;

            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //attachment.Key = Guid.NewGuid().ToString();

            var entity = await _attachmentRepository.UpdateAsync(attachment);
            if (entity == null)
            {
                throw new AttachmentNotFoundException(attachment);
            }

            return entity;
        }

        public virtual async Task<Attachment> GetAsync(string id)
        {
            //  await this.EnforceAttachmentExistenceAsync(id);
            var entity = await _attachmentRepository.GetAsync(id);
            return entity;
        }


        public virtual async Task<Stream> DownloadAsync(string id)
        {
            var entity = await _attachmentRepository.GetAsync(id);
            if (entity == null)
            {
                throw new AttachmentNotFoundException();
            }

            var bytes = Convert.FromBase64String(entity.Value);
            var contents = new StreamContent(new MemoryStream(bytes));
            return await contents.ReadAsStreamAsync();
        }


        public virtual async Task<Attachment> DeleteAsync(string id)
        {
            await this.EnforceAttachmentExistenceAsync(id);

            var entity = await _attachmentRepository.DeleteAsync(id);
            return entity;
        }

        public virtual async Task<IEnumerable<Attachment>> ListAsync()
        {
            return await _attachmentRepository.ListAsync();
        }

        public virtual async Task<Attachment> EnforceAttachmentExistenceAsync(string id)
        {
            var act = await _attachmentRepository.GetAsync(id);

            if (act == null)
            {
                throw new AttachmentNotFoundException();
            }

            return act;
        }



        public virtual async Task<Attachment> AesEncryptAsync(Attachment attach)
        {

            await Task.Delay(0);

            var key = Encoding.UTF8.GetBytes(Base64EncryptionKey);  //Convert.FromBase64String(Base64EncryptionKey);

            //  var iv = new byte[128 / 8];
            // RandomNumberGenerator.Fill(iv);
            //iv now contains random bytes

            // attach.Iv = Array.ConvertAll(iv, c => (int)c);
            //attach.Key = Array.ConvertAll(key, c => (int)c);

            //manual padding 
            //   var mod = attach.Value.Length % 16;

            //iv for UI
            var plainText = attach.Value; //.PadRight(mod, '=');
            //var key = Convert.FromBase64String(Base64EncryptionKey);


            if (plainText == null || plainText.Length <= 0)
                throw new AttachmentNotValidException();
            if (key == null || key.Length <= 0)
                throw new AttachmentNotValidException();
            // if (iv == null || iv.Length <= 0)
            //     throw new AttachmentNotValidException();
            byte[] encrypted;

            // Create a new instance of the Aes
            // class.  This generates a new key and initialization 
            // vector (IV).
            using (var aesAlgo = Aes.Create())
            {
                //aesAlgo.m
                aesAlgo.Key = key;
                // aesAlgo.IV = iv;

                //assigned iv
                attach.Iv = Array.ConvertAll(aesAlgo.IV, c => (int)c);
                aesAlgo.Padding = System.Security.Cryptography.PaddingMode.Zeros;
                //aesAlgo.Mode = System.Security.Cryptography.CipherMode.CTS;
                //aesAlgo.KeySize = 256;
                //aesAlgo.BlockSize = 128;
                //aesAlgo.BlockSize = 256 / 8;

                var encryptor = aesAlgo.CreateEncryptor(aesAlgo.Key, aesAlgo.IV);
                using (var msEncrypt = new MemoryStream())
                {
                    using (var csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (var swEncrypt = new StreamWriter(csEncrypt))
                        {
                            swEncrypt.Write(plainText);
                        }

                        encrypted = msEncrypt.ToArray();
                    }
                }

                attach.EncryptedValue = Array.ConvertAll(encrypted, c => (int)c); //Convert.ToBase64String(encrypted);
                                                                                  // Log.Information(attach.EncryptedValue.Totring());
            }

            //set null value
            //attach.EncryptedValue = null;
            attach.Value = null;
            return attach;
        }


        public virtual async Task<Attachment> AesDecryptAsync(Attachment cripher)
        {
            await Task.Delay(0);
            throw new NotImplementedException();

            //DEPRECATE

            /*  var iv = cripher.Iv;
             var cipherText = new byte[128]; //cripher.EncryptedValue; //Convert.FromBase64String();
             var key = Convert.FromBase64String(Base64EncryptionKey);

             // Check arguments.
             if (cipherText == null || cipherText.Length <= 0)
                 throw new AttachmentNotValidException("VALUE");
             if (key == null || key.Length <= 0)
                 throw new AttachmentNotValidException("KEY");
             if (iv == null || iv.Length <= 0)
                 throw new AttachmentNotValidException("IV");

             // Declare the string used to hold
             // the decrypted text.
             string plaintext = null;

             // Create an Aes object
             // with the specified key and IV.
             using (Aes aesAlg = Aes.Create())
             {
                 aesAlg.Key = key;
                 //aesAlg.IV = iv;
                 //aesAlg.KeySize = 256;
                 //aesAlg.BlockSize = 128;

                 // Create a decryptor to perform the stream transform.
                 ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

                 // Create the streams used for decryption.
                 using (MemoryStream msDecrypt = new MemoryStream(cipherText))
                 {
                     using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                     {
                         using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                         {
                             // Read the decrypted bytes from the decrypting stream
                             // and place them in a string.

                             plaintext = srDecrypt.ReadToEnd();
                             cripher.Value = plaintext;
                         }
                     }
                 }

             }

             return cripher;*/

        }


    }

}