using Microsoft.Extensions.Configuration;
using surflex.netcore22.Exceptions;
using surflex.netcore22.Extensions;
using surflex.netcore22.Models;
using surflex.netcore22.Models.Constants;
using surflex.netcore22.Repositories;
using System; 

using System.IO;
using System.Threading.Tasks;

namespace surflex.netcore22.Services
{
    public class FileSystemAttachmentService : AttachmentService, IFileStorageAttachmentService
    {
        //protected readonly IConfiguration _configuration;

        public FileSystemAttachmentService(IAttachmentRepository attachmentRepository, IHttpService httpService, IPathFinderService pathFinderService, IConfiguration configuration)
                : base(attachmentRepository, httpService, pathFinderService, configuration)
        {
            //_configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }

        public override async Task<Attachment> CreateAsync(Attachment attachment)
        {
            if (attachment == null) throw new ArgumentNullException(nameof(attachment));
            if (attachment.Value == null || attachment.Value?.Length == 0) throw new ArgumentNullException(nameof(attachment.Value));

            var isFileSystemStoring = false;
            string fileValue = null;

            if (attachment.TemplateTypeId == GlobalConstants.COTL_TEMPLATE_TYPE_ID ||
                attachment.TemplateTypeId == GlobalConstants.CTEP_TEMPLATE_TYPE_ID)
            {
                isFileSystemStoring = true;

                fileValue = attachment.Value;
                attachment.Value = null;
                attachment.Storage = GlobalConstants.AttachmentSource.STORAGE_FILE.GetDescription();
            }

            var entity = await base.CreateAsync(attachment);

            if (isFileSystemStoring)
            {
                var bytes = Convert.FromBase64String(fileValue);

                var basePath = _configuration["AppSettings:UploadedFilePath"];

                if (!Directory.Exists(await _pathFinderService.FindAsync(basePath)))
                    Directory.CreateDirectory(await _pathFinderService.FindAsync(basePath));

                string relativeFilePath;
                string actualFilePath;

                do
                {
                    relativeFilePath = $"{basePath}/{Guid.NewGuid().ToString()}{attachment.Extension}";
                    actualFilePath = await _pathFinderService.FindAsync(relativeFilePath);
                }
                while (File.Exists(actualFilePath));

                File.WriteAllBytes(actualFilePath, bytes);

                entity.Path = relativeFilePath;
                entity = await _attachmentRepository.UpdateAsync(entity);
            }

            // var compare = await this.GetAsync(entity.Id);
            // if (compare.Value != entity.Value)
            // {
            //     throw new AttachmentNotValidException("an exception was throw base64 not equal of getting and creating");
            // }

            return entity;
        }

        public override async Task<Attachment> UpdateAsync(Attachment attachment)
        {
            if (attachment == null) throw new ArgumentNullException(nameof(attachment));

            var isFileSystemStoring = false;
            string fileValue = null;

            if (attachment.TemplateTypeId == GlobalConstants.COTL_TEMPLATE_TYPE_ID ||
                attachment.TemplateTypeId == GlobalConstants.CTEP_TEMPLATE_TYPE_ID)
            {
                isFileSystemStoring = true;

                fileValue = attachment.Value;
                attachment.Value = null;
                attachment.Storage = GlobalConstants.AttachmentSource.STORAGE_FILE.GetDescription();
            }

            var entity = await base.UpdateAsync(attachment);

            if (isFileSystemStoring && fileValue != null)
            {
                var bytes = Convert.FromBase64String(fileValue);

                var basePath = _configuration["AppSettings:UploadedFilePath"];

                if (!Directory.Exists(await _pathFinderService.FindAsync(basePath)))
                    Directory.CreateDirectory(await _pathFinderService.FindAsync(basePath));

                string relativeFilePath;
                string actualFilePath;

                do
                {
                    relativeFilePath = $"{basePath}/{Guid.NewGuid().ToString()}{attachment.Extension}";
                    actualFilePath = await _pathFinderService.FindAsync(relativeFilePath);
                }
                while (File.Exists(actualFilePath));

                File.WriteAllBytes(actualFilePath, bytes);

                entity.Path = relativeFilePath;
                entity = await _attachmentRepository.UpdateAsync(entity);
            }

            return entity;
        }

        public override async Task<Attachment> GetAsync(string id)
        {
            var entity = await _attachmentRepository.GetAsync(id);

            if (entity != null && entity.Storage == GlobalConstants.AttachmentSource.STORAGE_FILE.GetDescription())
            {
                var relativeFilePath = entity.Path;
                var actualFilePath = await _pathFinderService.FindAsync(relativeFilePath);

                var ms = new MemoryStream();

                bool isSuccess = false;
                int tryCount = 0;
                do
                {
                    tryCount++;
                    try
                    {
                        using (var fs = new FileStream(actualFilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
                        {
                            fs.CopyTo(ms);
                        }
                        isSuccess = true;
                    }
                    catch (IOException ex)
                    {
                        if (tryCount == 5)
                            throw ex;

                        // wait til file available
                        await Task.Delay(1000);
                    }
                } while (!isSuccess && tryCount < 5);

                entity.Value = Convert.ToBase64String(ms.ToArray()); //should call encrypted
                                                                     //  return entity;
            }

            return entity;
        }

        public override async Task<Stream> DownloadAsync(string id)
        {
            var entity = await _attachmentRepository.GetAsync(id);

            if (entity != null && entity.Storage == GlobalConstants.AttachmentSource.STORAGE_FILE.GetDescription())
            {
                return File.OpenRead(entity.Path);
            }
            else
            {
                return await base.DownloadAsync(id);
            }
        }

        public override async Task<Attachment> DeleteAsync(string id)
        {
            var entity = await _attachmentRepository.DeleteAsync(id);

            if (entity != null && entity.Storage == GlobalConstants.AttachmentSource.STORAGE_FILE.GetDescription() &&
                entity.Path?.Length > 0 && File.Exists(entity.Path))
            {
                var relativeFilePath = entity.Path;
                var actualFilePath = await _pathFinderService.FindAsync(relativeFilePath);

                File.Delete(actualFilePath);
            }

            return entity;
        }

        public override async Task<Attachment> EnforceAttachmentExistenceAsync(string id)
        {
            var entity = await base.EnforceAttachmentExistenceAsync(id);

            if (entity != null && entity.Storage == GlobalConstants.AttachmentSource.STORAGE_FILE.GetDescription())
            {
                var relativeFilePath = entity.Path;
                var actualFilePath = await _pathFinderService.FindAsync(relativeFilePath);

                return entity.Path?.Length > 0 && File.Exists(actualFilePath) ? entity : throw new AttachmentNotFoundException(entity.Path);
            }
            else
            {
                return entity;
            }
        }

        public override async Task<Attachment> AesEncryptAsync(Attachment attach)
        {
            return await base.AesEncryptAsync(attach);
        }


        public override async Task<Attachment> AesDecryptAsync(Attachment cripher)
        {
            //await Task.Delay(0);
            return await base.AesDecryptAsync(cripher);
        }
    }

}