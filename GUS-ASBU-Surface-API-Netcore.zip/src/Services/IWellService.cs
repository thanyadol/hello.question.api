using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;

//model
using surflex.netcore22.Models;

namespace surflex.netcore22.Services
{
    public interface IWellService
    {
        Task<Well> CreateAsync(Well well);
        //Task<WellReserve> CreateWellReserveAsync(WellReserve well);
        Task<Well> UpdateAsync(Well well);
        Task<Well> DeleteAsync(string id);
        // Task<int> GetTotalPlannedWellAsync(int id);
        Task<Well> GetAsync(string id);
        Task<Well> EnforceWellExistingAsync(string id);
        // Task<Well> GetAsync(Well w);
        // Task<WellProductive> GetProductiveAsync(string name);
        Task<WellProductive> GetProductiveStatusAsync(string name);

        Task<IEnumerable<WellProductive>> ListProductiveAsync();
        //  Task<WellReserve> GetPlannedReserveAsync(string name);
        Task<WellJobProductive> GetActualProductiveAsync(string name);
        Task<Well> EnforceWellCreateAsync(Well w);

        Task<IEnumerable<WellPlanned>> ListPlannedAsync(int rllcp, bool status = false);
        // Task<IEnumerable<WellPlanned>> ListByProjectWithStatusAsync(int id);

        Task<WellAnalogy> GetUDVAnalogyAsync(string name);

        //well reserve

        // Task<WellReserve> CreateAsync(WellReserve reserve);

        //Task<WellReserveProductive> CreateProductiveAsync(WellReserveProductive reserve);
        // Task<WellReserve> UpdateAsync(WellReserve reserve);
        //        Task<WellReserve> DeleteReserveAsync(string id);
        //     Task<WellReserve> GetPlannedAsync(string name);
        // Task<WellReserve> GetReserveAsync(string id);
        //  Task<WellReserve> GetRecentlyReserveAsync(string timestamp);
        //  Task<IEnumerable<WellReserve>> ListReserveAsync();
        //    Task<WellReserve> EnforceWellReserveExistenceAsync(string id);

        Task<WellDecisionParams> InitialDecisionParamsAsync(string name);


        //scenario
        Task<PresetWellScenario> CreateAsync(PresetWellScenario scenarion);
        Task<PresetWellScenario> UpdateAsync(PresetWellScenario scenarion);
        //Task<Scenarios> DeleteAsync(string id);

        Task<PresetWellScenario> GetScenarioAsync(Guid id);

        Task<IEnumerable<PresetWellScenario>> ListScenarioAsync();
        Task<PresetWellScenario> EnforceWellScenarioExistenceAsync(Guid id);

        Task<FluentValidation.Results.ValidationResult> ValidateDPITemplateAsync(Attachment attach);

        // Task<FluentValidation.Results.ValidationResult> ValidateDPITemplateAsync(Template template);
        // Task<IEnumerable<WellEvaluateParams>> EvaluateBranchDPIAsync(WellEvaluateParams parameters);
        Task<WellEvaluateParams> EvaluateBranchDPIAsync(WellEvaluateParams parameter);
        Task<IEnumerable<WellEvaluateParams>> EvaluateBranchDPIAsync(IEnumerable<WellEvaluateParams> parameters);

        //Task<WellReserveParams> EstimateUndrilledReserveAsync(string name);


        Task<WellProperties> CreateAsync(WellProperties propertiess);
        Task<WellProperties> UpdateAsync(WellProperties propertiess);
        //Task<WellProperties> DeleteAsync(string id);

        Task<WellProperties> GetPropertiesAsync(string id);

        Task<IEnumerable<WellProperties>> ListPropertiesAsync();

        //  Task<IEnumerable<WellProperties>> SyncePropertiesAsync(int rllcp, string name, string id);
        Task<IEnumerable<WellProperties>> SyncePropertiesAsync(int rllcp, string name, string id);
        //Task<IEnumerable<WellProperties>> BatchCreateAsync(IEnumerable<WellProperties> properties);

        Task<WellProperties> EnforceWellPropertiesExistenceAsync(string id);
        Task<WellSpace> PublishAsync(Guid id);

        string GetDefaultWellType(IEnumerable<Sand> reserve);

        Task<IEnumerable<Item>> ListUndrilledMethodAsync();
        //activity
        Task<WellActivity> CreateAsync(WellActivity activity);
        // Task<WellActivity> CreateAsync(string type, string sand, string descript);
        Task<WellActivity> UpdateAsync(WellActivity activity);
        //Task<WellActivity> DeleteAsync(string id);

        Task<WellActivity> GetActivityAsync(Guid id);

        Task<IEnumerable<WellActivity>> ListActivityAsync();

        //Task<WellActivity> GetRecentlyActivityAsync(string name);

        // Task<WellActivity> GetRecentlyPublishedAsync(string id);

        // Task<WellActivity> GetRecentlySavedAsync(string id);
        Task<WellActivity> EnforceWellActivityExistenceAsync(Guid id);


        //space
        //activity
        Task<WellSpace> CreateAsync(WellSpace space);
        Task<WellSpace> UpdateAsync(WellSpace space);
        Task<WellSpace> GetSpaceAsync(Guid id);

        Task<IEnumerable<WellSpace>> ListSpaceAsync();

        // Task<WellSpace> GetRecentlySpaceAsync(string name);
        Task<WellSpace> EnforceWellSpaceExistenceAsync(Guid id);




        ///drilled

        Task<WellDrilled> CreateAsync(WellDrilled space);
        Task<WellDrilled> UpdateAsync(WellDrilled space);
        Task<WellDrilled> GetDrilledAsync(Guid id);

        Task<IEnumerable<WellDrilled>> ListDrilledAsync();

        //  Task<WellDrilled> GetRecentlyDrilledAsync(string name);
        Task<WellDrilled> EnforceDrilledExistenceAsync(Guid id);




        //undriiled


        Task<WellUndrilled> CreateAsync(WellUndrilled space);
        Task<WellUndrilled> UpdateAsync(WellUndrilled space);
        Task<WellUndrilled> GetUndrilledAsync(Guid id);

        Task<IEnumerable<WellUndrilled>> ListUndrilledAsync();

        //   Task<WellUndrilled> GetRecentlyUndriledAsync(string name);
        Task<WellUndrilled> EnforceUndrilledExistenceAsync(Guid id);

        Task<WellReserveParams> EvaluatedReserveAsync(string name, string status);
        Task<WellUndrilled> GetUndrilledRecentlyAsync(string name);
        Task<WellDrilled> GetDrilledRecentlyAsync(string name);

        //Task<WellPerformance> EvaluateSimpleDPIAsync(WellReserveParams parameters);//, string timestamp)

        // Task<WellEvaluateParams> EvaluateSimpleDPIAsync(WellEvaluateParams parameter);
        // Task<WellEvaluateParams> EvaluateSimpleDPIAsync(WellEvaluateParams parameter, string status = "Drilling");
        Task<WellEvaluateParams> EvaluateSimpleDPIAsync(WellEvaluateParams parameter);

        Task<WellUndrilled> CalculateUndrilledAsync(WellUndrilled undrilled);
        Task<WellDrilled> CalculateDrilledAsync(WellDrilled drilled);
        Task<WellDrilled> MergeDrilledAsync(WellDrilled drilled);

        Task<WellDrilled> SynceDrilledAsync(string well, string project, string platform);

        Task<WellUndrilled> SynceUndrilledAsync(string well, string project, string platform);

        Task<WellUndrilled> BatchCreateUnrilledAsync(WellUndrilled undrill);
        Task<WellDrilled> BatchCreateDrilledAsync(WellDrilled drill);

        //Task<WellReserveParams> DerivatedCompoundReserveAsync(string name, string status);
        Task<WellReserveParams> DerivatedCompoundReserveAsync(string name, string status, WellUndrilled us = null);

        Task<WellReserve> GetPlannedReserveAsync(string name);
        Task<IEnumerable<ProductionProfileParams>> EstimateYearlyProductAsync(WellEvaluateParams p);

        Task<WellProductiveAsync> GetProductiveAsync(string name);

        Task<IEnumerable<WellPay>> GetWellPayAsync(string[] name);

        Task<IEnumerable<SimpleWellPlanned>> ListSORNotificationAsync(IEnumerable<SimpleWellPlanned> wells);

    }

    public interface IWellResourceService
    {

        Task<WellJobProductive> GetPlannedProductiveCostAsync(string name, string section);

    }
}