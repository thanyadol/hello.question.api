using System; 

using System.Collections.Generic;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using surflex.netcore22.Exceptions;

//logg
using Serilog;
using surflex.netcore22.Helpers;
using System.IO;
using System.Net.Http;


namespace surflex.netcore22.Services
{
    public interface IModuleService
    {
        Task<Module> CreateAsync(Module module);
        Task<Module> UpdateAsync(Module module);
        Task<Module> DeleteAsync(Guid id);

        Task<Module> GetAsync(Guid id);

        Task<IEnumerable<Module>> ListAsync();

        //     Task<IEnumerable<Module>> ListRecentlyAsync();
        Task<Module> EnforceModuleExistenceAsync(Guid id);


        Task<IEnumerable<Module>> ListRecentlyAsync();
    }

    public class ModuleService : IModuleService
    {
        //module status
        protected readonly IModuleRepository _moduleRepository;
        protected readonly IModulePageRepository _modulePageRepository;
        // protected readonly IUserService _userService;
        public ModuleService(IModuleRepository moduleRepository, IModulePageRepository modulePageRepository) //, IUserService userService, IPathFinderService pathFinderService)
        {
            _moduleRepository = moduleRepository ?? throw new ArgumentNullException(nameof(moduleRepository));
            _modulePageRepository = modulePageRepository ?? throw new ArgumentNullException(nameof(modulePageRepository));

            //_userService = userService ?? throw new ArgumentNullException(nameof(userService));

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }

        public async Task<Module> CreateAsync(Module module)
        {
            //await this.EnforceWellExistenceAsync(Module.WellId);
            //assigned
            module.Id = Guid.NewGuid();
            module.Created = Utility.CurrentSEAsiaStandardTime();

            //module. = httpCurrentUser.Id;

            module.Description = "hello this is a new module from develper";

            //new rev and key
            //module.Rev = Guid.NewGuid().ToString();
            //module.Key = Guid.NewGuid().ToString();

            //await EnforceClanExistenceAsync(Module.Clan.Name);
            var entity = await _moduleRepository.CreateAsync(module);
            if (entity == null)
            {
                ////throw new ModuleNotFoundException(module);
            }

            return entity;
        }



        public async Task<Module> UpdateAsync(Module module)
        {
            var updated = await this.EnforceModuleExistenceAsync(module.Id);

            //assigned
            //module.Created = Utility.CurrentSEAsiaStandardTime();
            //Module.Module = Module.Module;
            //Module.Status = Module.Status;
            //   module.By = httpCurrentUser.Id;

            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //module.Key = Guid.NewGuid().ToString();

            var entity = await _moduleRepository.UpdateAsync(module);
            if (entity == null)
            {
                ////throw new ModuleNotFoundException(module);
            }

            return entity;
        }

        public async Task<Module> GetAsync(Guid id)
        {
            //  await this.EnforceModuleExistenceAsync(id);

            var entity = await _moduleRepository.GetAsync(id);
            return entity;
        }


        public async Task<Module> DeleteAsync(Guid id)
        {
            await this.EnforceModuleExistenceAsync(id);

            var entity = await _moduleRepository.DeleteAsync(id);
            return entity;
        }

        public async Task<IEnumerable<Module>> ListAsync()
        {
            return await _moduleRepository.ListAsync();
        }

        public async Task<IEnumerable<Module>> ListRecentlyAsync()
        {
            return await _moduleRepository.ListRecentlyAsync();
        }

        /* public async Task<IEnumerable<Module>> ListRecentlyAsync()
        {
            return await _moduleRepository.ListRecentlyAsync();
        }*/


        public async Task<Module> EnforceModuleExistenceAsync(Guid id)
        {
            var act = await _moduleRepository.GetAsync(id);

            if (act == null)
            {
                //throw new ModuleNotFoundException(id.ToString());
            }

            return act;
        }

        //api
        /* 
        public async Task<ModuleApi> CreateAsync(ModuleApi moduleApi)
        {
            //await this.EnforceWellExistenceAsync(ModuleApi.WellId);
            //assigned
            moduleApi.Id = Guid.NewGuid();
            moduleApi.Date = Utility.CurrentSEAsiaStandardTime();

            //moduleApi. = httpCurrentUser.Id;

            // moduleApi.Description = "hello this is a new moduleApi from develper";

            //new rev and key
            //moduleApi.Rev = Guid.NewGuid().ToString();
            //moduleApi.Key = Guid.NewGuid().ToString();

            //await EnforceClanExistenceAsync(ModuleApi.Clan.Name);
            var entity = await _moduleApiRepository.CreateAsync(moduleApi);
            if (entity == null)
            {
                //throw new ModuleNotApiNotFoundException()API");
            }

            return entity;
        }



        public async Task<ModuleApi> UpdateAsync(ModuleApi moduleApi)
        {
            var updated = await this.EnforceModuleApiExistenceAsync(moduleApi.Id);

            //assigned
            //moduleApi.Created = Utility.CurrentSEAsiaStandardTime();
            //ModuleApi.ModuleApi = ModuleApi.ModuleApi;
            //ModuleApi.Status = ModuleApi.Status;
            //   moduleApi.By = httpCurrentUser.Id;

            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //moduleApi.Key = Guid.NewGuid().ToString();

            var entity = await _moduleApiRepository.UpdateAsync(moduleApi);
            if (entity == null)
            {
                //throw new ModuleNotApiNotFoundException()API");
            }

            return entity;
        }

        public async Task<ModuleApi> GetApiAsync(Guid id)
        {
            //  await this.EnforceModuleApiExistenceAsync(id);

            var entity = await _moduleApiRepository.GetAsync(id);
            return entity;
        }


        /* public  async Task<ModuleApi> DeleteAsync(Guid id)
        {
            await this.EnforceModuleApiExistenceAsync(id);

            var entity = await _moduleApiRepository.DeleteAsync(id);
            return entity;
        }

        public async Task<IEnumerable<ModuleApi>> ListApiAsync()
        {
            return await _moduleApiRepository.ListAsync();
        }


        public async Task<IEnumerable<ModuleApi>> ListRecentlyApiAsync()
        {
            return await _moduleApiRepository.ListRecentlyAsync();
        }

        public async Task<ModuleApi> EnforceModuleApiExistenceAsync(Guid id)
        {
            var act = await _moduleApiRepository.GetAsync(id);

            if (act == null)
            {
                //throw new ModuleNotApiNotFoundException()API");
            }

            return act;
        }*/


    }

}