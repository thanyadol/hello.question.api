using System;

using System.Collections.Generic;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using surflex.netcore22.Exceptions;

using surflex.netcore22.Extensions;
//logg
using Serilog;
using surflex.netcore22.Helpers;
using TEMPLATE = surflex.netcore22.Models.Constants.Template;

namespace surflex.netcore22.Services
{
    public interface ITemplateService
    {
        Task<Template> CreateAsync(Template template);
        // Task<Template> CreateAsync(string type, string sand, string descript);
        Task<Template> UpdateAsync(Template template);
        Task<Template> DeleteAsync(string id);

        Task<Template> GetCurrentlyAsync(string id);

        Task<Template> GetAsync(string id);
        Task<Item> GetTypeAsync(string id);
        // Task<Template> GetRecentlyAsync(string id);

        Task<IEnumerable<Template>> ListAsync(string status);

        Task<IEnumerable<Item>> ListTypeAsync();
        //  Task<Template> RollbackAsync(string id, string status);

        Task<Attachment> GetAttachedAsync(string id);
        //Task<Template> UpdateStatusAsync(string id, string status);

        //Task<Template> GetRecentlyAsync(string key);

        // Task<Template> GetRecentlyPublishedAsync(string id);

        // Task<Template> GetRecentlySavedAsync(string id);
        Task<Template> EnforceTemplateExistenceAsync(string id);

        Task<Template> RollbackAsync(Template template);

        //TemplateProductive Map(TemplateProductiveAsync entity);
    }

    public class TemplateService : ITemplateService
    {
        //template status

        //private readonly string ACTIVE = "ACTIVE";

        //  private readonly string HISTORY = "ARCHIVED";


        private readonly ITemplateRepository _templateRepository;
        private readonly IAttachmentService _attachmentService;
        private readonly IHttpService _httpService;
        private readonly IUserService _userService;
        private readonly User httpCurrentUser;

        public TemplateService(ITemplateRepository templateRepository, IAttachmentService attachmentService, IHttpService httpService, IUserService userService)
        {
            _templateRepository = templateRepository ?? throw new ArgumentNullException(nameof(templateRepository));
            _attachmentService = attachmentService ?? throw new ArgumentNullException(nameof(attachmentService));

            _httpService = httpService ?? throw new ArgumentNullException(nameof(httpService));
            _userService = userService ?? throw new ArgumentNullException(nameof(userService));


            httpCurrentUser = _httpService.GetHttpCurrentUserAsync().Result;

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }

        public async Task<Template> CreateAsync(Template template)
        {
            var current = await this.GetCurrentlyAsync(template.TemplateTypeId);

            //deactive old
            if (current != null)
            {
                var temp = await _templateRepository.GetAsync(current.Id);
                if (temp == null)
                {
                    throw new TemplateNotFoundException();
                }

                temp.Status = RecordStatus.ARCHIVED.GetDescription();
                temp.FinishDate = Utility.CurrentSEAsiaStandardTime();

                await _templateRepository.UpdateAsync(temp);

                //old key
                template.Key = current.Key;
                template.LastActiveTemplateIdForRollback = current.Id;
            }
            else
            {
                template.Key = Guid.NewGuid().ToString();
            }

            //assigned
            template.Id = Guid.NewGuid().ToString();
            template.Created = Utility.CurrentSEAsiaStandardTime();
            template.Status = RecordStatus.ACTIVE.GetDescription();

            template.By = httpCurrentUser.Id;

            //new rev
            template.Rev = Guid.NewGuid().ToString();
            //          
            template.StartDate = Utility.CurrentSEAsiaStandardTime();
            //await EnforceClanExistenceAsync(ProjectAttribute.Clan.Name);

            var entity = await _templateRepository.CreateAsync(template);
            if (entity == null)
            {
                throw new TemplateNotFoundException();
            }

            //transfer value
            entity = await _templateRepository.GetAsync(entity.Id);
            entity.LastActiveTemplateIdForRollback = template.LastActiveTemplateIdForRollback;

            return entity;
        }

        /* public async Task<Template> CreateAsync(string type, string sand, string descript, string by)
        {

            //store template
            Template template = new Template()
            {
                Id = Guid.NewGuid().ToString(),
                By = by,

                Date = Utility.ToSEAsiaStandardTime(),
                Description = descript,
                SandId = sand,

                Type = type
            };


            template.Id = Guid.NewGuid().ToString();
            template.Date = Utility.CurrentSEAsiaStandardTime();

            //await EnforceClanExistenceAsync(Template.Clan.Name);
            var entity = await _templateRepository.CreateAsync(template);
            if (entity == null)
            {
                throw new TemplateNotFoundException(template);
            }


            return entity;
        }*/

        //loback template if load file fail
        public async Task<Template> RollbackAsync(Template template)
        {
            var updated = await this.EnforceTemplateExistenceAsync(template.LastActiveTemplateIdForRollback);
            if (updated == null)
            {
                throw new TemplateNotFoundException(updated);
            }

            //assigned
            updated.FinishDate = Utility.CurrentSEAsiaStandardTime();
            updated.Status = RecordStatus.ACTIVE.GetDescription();
            var entity = await _templateRepository.UpdateAsync(updated);

            return entity;
        }



        public async Task<Template> UpdateAsync(Template template)
        {
            var updated = await this.EnforceTemplateExistenceAsync(template.Id);

            //assigned
            //Template.Created = Utility.CurrentSEAsiaStandardTime();
            //Template.Template = Template.Template;
            updated.Name = template.Name;

            var entity = await _templateRepository.UpdateAsync(updated);
            if (entity == null)
            {
                throw new TemplateNotFoundException(template);
            }

            return entity;
        }

        public async Task<Template> GetAsync(string id)
        {
            //  await this.EnforceTemplateExistenceAsync(id);

            var entity = await _templateRepository.GetAsync(id);

            return entity;
        }

        public async Task<Item> GetTypeAsync(string id)
        {
            await Task.Delay(0);
            //  await this.EnforceTemplateExistenceAsync(id);

            var entity = TEMPLATE.TYPE.Where(c => c.Id == id).FirstOrDefault();

            return entity;
        }

        public async Task<Template> DeleteAsync(string id)
        {
            await this.EnforceTemplateExistenceAsync(id);

            var entity = await _templateRepository.DeleteAsync(id);
            return entity;
        }

        //
        // Summary:
        //     Returns current active template by type id
        //
        // Returns:
        //     Models.Entity.Template object
        //
        // Type parameters:
        //   id:
        //     by type id
        //
        //

        public async Task<Template> GetCurrentlyAsync(string id)
        {
            var entity = await _templateRepository.ListAsync();
            if (entity == null)
            {
                throw new TemplateNotFoundException();
            }

            return entity.Where(c => c.TemplateTypeId == id).OrderByDescending(c => c.Created).FirstOrDefault();
        }


        //
        // Summary:
        //     Returns current attachment by active template by type id
        //
        // Returns:
        //     Models.Entity.Template object
        //
        // Type parameters:
        //   id:
        //     by type id
        //
        //

        public async Task<Attachment> GetAttachedAsync(string id)
        {
            var entity = await _templateRepository.ListAsync();
            if (entity == null)
            {
                throw new TemplateNotFoundException();
            }

            var template = entity.Where(c => c.TemplateTypeId == id).OrderByDescending(c => c.Created).FirstOrDefault();
            var attach = await _attachmentService.GetAsync(template.AttachmentId);
            if (attach == null)
            {
                throw new AttachmentNotFoundException();
            }

            attach = await _attachmentService.AesEncryptAsync(attach);
            return attach;
        }


        public async Task<IEnumerable<Template>> ListAsync(string status)
        {
            var entity = await _templateRepository.ListAsync();
            if (entity == null)
            {
                throw new TemplateNotFoundException();
            }

            if (!string.IsNullOrEmpty(status))
            {
                entity = entity.Where(c => c.Status == status);
            }

            //map type for display
            var query = entity.Select(c =>
            {
                c.TemplateTypeDisplay = TEMPLATE.TYPE.FirstOrDefault(x => x.Id == c.TemplateTypeId) == null ? null : TEMPLATE.TYPE
                                .FirstOrDefault(x => x.Id == c.TemplateTypeId).Title;
                return c;

            }).ToList();


            //map CAI
            query = query.Select(c =>
            {
                c.By = _userService.GetAsync(c.By).Result?.CAI;
                return c;

            }).ToList();

            return query;
        }

        public async Task<IEnumerable<Item>> ListTypeAsync()
        {
            await Task.Delay(0);


            return TEMPLATE.TYPE;
        }


        public async Task<Template> EnforceTemplateExistenceAsync(string id)
        {
            var act = await _templateRepository.GetAsync(id);

            if (act == null)
            {
                throw new TemplateNotFoundException();
            }

            return act;
        }

        //
        // Summary:
        //     return true / false of validateion result
        //
        // Returns:
        //     bool
        //
        // Type parameters:
        //   id:
        //     by templateid
        //
        //
        /* public async Task<bool> EnfoceValidateAsync(Attachment attach)
        {
        }*/


    }

}