using System;

using System.Collections.Generic;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using surflex.netcore22.Exceptions;

//logg
using Serilog;
using surflex.netcore22.Helpers;
using System.Data;
using System.IO;
using surflex.netcore22.Extensions;
using Jace;
//using surflex.netcore22.Models.Constants;
using PRODUCTION = surflex.netcore22.Models.Constants.Production;


namespace surflex.netcore22.Services
{
    public interface IProductionService
    {
        Task<Production> CreateAsync(Production productions);
        Task<Production> UpdateAsync(Production productions);
        Task<Production> DeleteAsync(string id);

        Task<Production> GetAsync(string id);

        Task<IEnumerable<Production>> ListAsync(string status = "ACTIVE");
        Task<Production> EnforceProductionExistenceAsync(string id);

        //profile

        Task<ProductionProfile> CreateAsync(ProductionProfile profiles);
        Task<ProductionProfile> UpdateAsync(ProductionProfile profiles);
        //Task<ProductionProfile> DeleteAsync(string id);

        Task<ProductionProfile> GetProfileAsync(string id);

        Task<IEnumerable<ProductionProfile>> ListProfileAsync();
        Task<ProductionProfile> EnforceProductionProfileExistenceAsync(string id);


        //params

        Task<ProductionParam> CreateAsync(ProductionParam parameters);
        Task<ProductionParam> UpdateAsync(ProductionParam parameters);
        //Task<ProductionParam> DeleteAsync(string id);

        Task<ProductionParam> GetParamsAsync(string id);

        Task<IEnumerable<ProductionParam>> ListParamsAsync(string id = null);
        Task<ProductionParam> EnforceProductionProfileParamExistenceAsync(string id);

        Task<IEnumerable<Item>> ListApplicableModelAsync();

        Task<Production> GetCurentlyProductAsync(string id);
        Task<ProductionProfile> GetCurentlyProfileAsync(string id, string type);

        //Task<ProductionProfileParams> EnforceModelCalculateAsync(WellReserve reserve, ProjectAttribute attribute, ProductionProfile profile);

        //for separate reserve
        //   Task<IEnumerable<ProductionProfileParams>> EstimateYearsProductAsync(string well, string project, string platform, WellReserve reserve);
        // Task<IEnumerable<ProductionProfileParams>> EstimateYearsProductAsync(ProductionProfileParams parameters);
        // Task<IEnumerable<ProductionProfileParams>> EstimateMonthProductAsync(ProductionProfileParams parameters);
        Task<IEnumerable<Item>> GetAvailableApplicableModel(string id);

        Task<ProductionProfile> EvaluateProfileRateAsync(ProductionProfile p, WellReserve reserve);

        Task<ProductionProfileParams> EstimateRemainProductionAsync(ProductionProfileParams parameters);
    }

    public class ProductionService : IProductionService
    {
        //production statu
        private readonly IProductionRepository _productionRepository;

        private readonly IProductionProfileRepository _profileRepository;

        private readonly IProductionParamRepository _paramRepository;
        //  private readonly IAreaService _areaService;
        private readonly IHttpService _httpService;

        //private readonly ISandProductionService _sandService;
        // private readonly IProjectWellService _projectService;

        //  private readonly IWellService _wellService;
        private readonly User httpCurrentUser;


        private readonly IWorkUnitService _workUnitService;
        //   private readonly string RecordStatus.ACTIVE.GetDescription() = "ACTIVE";
        //  private readonly string ARCHIVED = "ARCHIVED";

        //private readonly string ApplicableModel.OIL.ToString() = "ApplicableModel.OIL.ToString()";
        //private readonly string ApplicableModel.GAS.ToString() = "ApplicableModel.GAS.ToString()";

        //private readonly string ApplicableModel.SEPARATE.ToString() = "ApplicableModel.SEPARATE.ToString()";

        //private readonly string DERIVED = "DERIVED";


        //private readonly string FormulaType.FIXED.GetDescription() = "FormulaType.FIXED.GetDescription()";
        // private readonly string VARIABLE = "VARIABLE";

        private readonly IMapper<ProductionProfileParams, ProductionProfileParams> _productionMapper;

        //enforce create area //
        public ProductionService(IProductionRepository productionRepository, IProductionProfileRepository profileRepository, IProductionParamRepository paramRepository,
                    IHttpService httpService, IPathFinderService pathFinderService, IWorkUnitService workUnitService,
          IMapper<ProductionProfileParams, ProductionProfileParams> productionMapper)
        {
            _productionRepository = productionRepository ?? throw new ArgumentNullException(nameof(productionRepository));
            _profileRepository = profileRepository ?? throw new ArgumentNullException(nameof(profileRepository));
            _paramRepository = paramRepository ?? throw new ArgumentNullException(nameof(paramRepository));

            // _areaService = areaService ?? throw new ArgumentNullException(nameof(areaService));

            _workUnitService = workUnitService ?? throw new ArgumentNullException(nameof(workUnitService));
            _httpService = httpService ?? throw new ArgumentNullException(nameof(httpService));

            // _clientService = clientService ?? throw new ArgumentNullException(nameof(clientService));
            // _projectService = projectService ?? throw new ArgumentNullException(nameof(projectService));
            // _sandService = sandService ?? throw new ArgumentNullException(nameof(sandService));

            _productionMapper = productionMapper ?? throw new ArgumentNullException(nameof(productionMapper));

            httpCurrentUser = _httpService.GetHttpCurrentUserAsync().Result;

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }

        public async Task<Production> CreateAsync(Production production)
        {
            //validate formular
            var flag = await this.ValidateFormulaAsync(production);
            if (!flag)
            {
                throw new ProductionNotValidException();
            }

            //gas
            if (!String.IsNullOrEmpty(production.GasProfile.EVFormulaForIPCDRATE))
            {
                production.GasProfile.ValueType = FormulaType.VARIABLE.GetDescription();
            }
            else
            {
                production.GasProfile.ValueType = FormulaType.FIXED.GetDescription();
            }

            //oil
            if (!String.IsNullOrEmpty(production.OilProfile.EVFormulaForIPCDRATE))
            {
                production.OilProfile.ValueType = FormulaType.VARIABLE.GetDescription();
            }
            else
            {
                production.OilProfile.ValueType = FormulaType.FIXED.GetDescription();
            }

            // var area = await _areaService.EnforceAreaCreateAsync(new Area() { Name = production.AreaName });

            //controlversion
            //deactive old
            if (!String.IsNullOrEmpty(production.Id))
            {
                var product = await _productionRepository.GetAsync(production.Id);
                if (product == null)
                {
                    throw new ProductionNotFoundException();
                }

                product.Status = RecordStatus.ARCHIVED.GetDescription();
                product.FinishDate = Utility.CurrentSEAsiaStandardTime();

                production.Key = product.Key;

                await _productionRepository.UpdateAsync(product);
            }
            else
            {
                production.Key = Guid.NewGuid().ToString();
            }


            //assigned
            //production.AreaId = area.Id;

            production.Id = Guid.NewGuid().ToString();
            production.Rev = Guid.NewGuid().ToString();
            //name as area name
            production.Name = production.Condition;

            production.Created = Utility.CurrentSEAsiaStandardTime();
            production.Status = RecordStatus.ACTIVE.GetDescription();


            production.StartDate = Utility.CurrentSEAsiaStandardTime();

            //persist parent
            var entity = await _productionRepository.CreateAsync(production);
            if (entity == null)
            {
                throw new ProductionNotFoundException();
            }

            //params
            using (var transaction = _workUnitService.BeginTransaction())
            {
                //gas
                if (production.GasProfile != null)
                {
                    var temp = production.GasProfile;

                    temp.Id = Guid.NewGuid().ToString();
                    temp.Created = Utility.CurrentSEAsiaStandardTime();
                    temp.ProductionId = entity.Id;
                    temp.By = httpCurrentUser.Id;

                    temp.ApplicableModel = ApplicableModel.GAS.ToString();

                    await _workUnitService.ProductionProfiles.CreateAsync(temp);


                    foreach (var ppp in temp.Params)
                    {
                        ppp.Id = Guid.NewGuid().ToString();
                        // ppp.Created = Utility.CurrentSEAsiaStandardTime();
                        ppp.ProductionProfileId = temp.Id;

                        await _workUnitService.ProductionParams.CreateAsync(ppp);
                    }
                }

                //oil
                if (production.OilProfile != null)
                {
                    var temp = production.OilProfile;

                    temp.Id = Guid.NewGuid().ToString();
                    temp.Created = Utility.CurrentSEAsiaStandardTime();
                    temp.ProductionId = entity.Id;
                    temp.By = httpCurrentUser.Id;

                    temp.ApplicableModel = ApplicableModel.OIL.ToString(); ;

                    await _workUnitService.ProductionProfiles.CreateAsync(temp);


                    foreach (var ppp in temp.Params)
                    {
                        ppp.Id = Guid.NewGuid().ToString();
                        //ppp.Created = Utility.CurrentSEAsiaStandardTime();
                        ppp.ProductionProfileId = temp.Id;

                        await _workUnitService.ProductionParams.CreateAsync(ppp);
                    }
                }


                try
                {
                    transaction.Commit();
                    return production;
                }
                catch (InvalidOperationException ex)
                {
                    transaction.Rollback();
                    throw new RiggNotFoundException(ex.Message);
                }
            }
        }

        public async Task<Production> UpdateAsync(Production production)
        {
            var updated = await this.EnforceProductionExistenceAsync(production.Id);

            //assigned
            production.Created = Utility.CurrentSEAsiaStandardTime();
            //Production.Production = Production.Production;
            //Production.Status = Production.Status;
            production.By = httpCurrentUser.Id;

            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //production.Key = Guid.NewGuid().ToString();

            var entity = await _productionRepository.UpdateAsync(production);
            if (entity == null)
            {
                throw new ProductionNotFoundException(production);
            }

            return entity;
        }


        public async Task<bool> ValidateFormulaAsync(Production production)
        {
            await this.GetAsync(production.Id);

            return true;
        }

        public async Task<Production> GetAsync(string id)
        {
            //  await this.EnforceProductionExistenceAsync(id);

            var entity = await _productionRepository.GetAsync(id);
            return entity;
        }


        public async Task<Production> DeleteAsync(string id)
        {
            await this.EnforceProductionExistenceAsync(id);

            var entity = await _productionRepository.DeleteAsync(id);
            return entity;
        }

        public async Task<IEnumerable<Production>> ListAsync(string status = "ACTIVE")
        {
            var entity = await _productionRepository.ListAsync();
            if (!string.IsNullOrEmpty(status))
            {
                entity = entity.Where(c => c.Status == RecordStatus.ACTIVE.GetDescription());
            }

            var query = await _profileRepository.ListAsync();

            var result = new List<Production>();
            foreach (Production p in entity)
            {
                //tansform to current
                var temp = await this.GetCurentlyProductAsync(p.Id);

                // query = query.Where(c => c.);
                // p.GasProfile = query.Where(c => c.ProductionId == p.Id && c.ApplicableModel == ApplicableModel.GAS.ToString()).FirstOrDefault();
                //p.OilProfile = query.Where(c => c.ProductionId == p.Id && c.ApplicableModel == ApplicableModel.OIL.ToString()).FirstOrDefault();

                result.Add(temp);
            }

            return result;
        }

        public async Task<Production> EnforceProductionExistenceAsync(string id)
        {
            var act = await _productionRepository.GetAsync(id);

            if (act == null)
            {
                throw new ProductionNotFoundException();
            }

            return act;
        }


        //**** profile *******/
        public async Task<ProductionProfile> CreateAsync(ProductionProfile profile)
        {

            profile.Id = Guid.NewGuid().ToString();
            profile.Created = Utility.CurrentSEAsiaStandardTime();
            //ProductionProfile.ProductionProfile = ProductionProfile.ProductionProfile;
            //ProductionProfile.Status = ProductionProfile.Status;
            profile.By = httpCurrentUser.Id;

            //await EnforceClanExistenceAsync(ProductionProfile.Clan.Name);
            var entity = await _profileRepository.CreateAsync(profile);
            if (entity == null)
            {
                throw new ProductionNotFoundException();
            }

            return entity;
        }

        public async Task<ProductionProfile> UpdateAsync(ProductionProfile profile)
        {
            var updated = await this.EnforceProductionProfileExistenceAsync(profile.Id);

            //assigned


            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //profile.Key = Guid.NewGuid().ToString();

            var entity = await _profileRepository.UpdateAsync(profile);
            if (entity == null)
            {
                throw new ProductionNotFoundException();
            }

            return entity;
        }

        public async Task<ProductionProfile> GetProfileAsync(string id)
        {
            //  await this.EnforceProductionProfileExistenceAsync(id);

            var entity = await _profileRepository.GetAsync(id);
            return entity;
        }


        /* public async Task<ProductionProfile> DeleteAsync(string id)
        {
            await this.EnforceProductionProfileExistenceAsync(id);

            var entity = await _profileRepository.DeleteAsync(id);
            return entity;
        }*/

        public async Task<IEnumerable<ProductionProfile>> ListProfileAsync()
        {
            return await _profileRepository.ListAsync();
        }

        public async Task<ProductionProfile> EnforceProductionProfileExistenceAsync(string id)
        {
            var act = await _profileRepository.GetAsync(id);

            if (act == null)
            {
                throw new ProductionNotFoundException();
            }

            return act;
        }


        //for params
        public async Task<ProductionParam> CreateAsync(ProductionParam parameters)
        {
            //await this.EnforceWellExistenceAsync(ProductionParam.WellId);
            //assigned
            parameters.Id = Guid.NewGuid().ToString();
            //parameters.Created = Utility.CurrentSEAsiaStandardTime();

            // parameters.By = httpCurrentUser.Id;


            //new rev and key
            //parameters.Rev = Guid.NewGuid().ToString();
            //parameters.Key = Guid.NewGuid().ToString();

            //await EnforceClanExistenceAsync(ProductionParam.Clan.Name);
            var entity = await _paramRepository.CreateAsync(parameters);
            if (entity == null)
            {
                throw new ProductionNotFoundException();
            }

            return entity;
        }



        public async Task<ProductionParam> UpdateAsync(ProductionParam parameters)
        {
            var updated = await this.EnforceProductionProfileParamExistenceAsync(parameters.Id);

            //assigned
            //parameters.Created = Utility.CurrentSEAsiaStandardTime();
            //ProductionParam.ProductionParam = ProductionParam.ProductionParam;
            //ProductionParam.Status = ProductionParam.Status;
            // parameters.By = httpCurrentUser.Id;

            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //parameters.Key = Guid.NewGuid().ToString();

            var entity = await _paramRepository.UpdateAsync(parameters);
            if (entity == null)
            {
                throw new ProductionNotFoundException();
            }

            return entity;
        }

        public async Task<ProductionParam> GetParamsAsync(string id)
        {
            //  await this.EnforceProductionProfileParamExistenceAsync(id);

            var entity = await _paramRepository.GetAsync(id);
            return entity;
        }


        public async Task<IEnumerable<Item>> ListApplicableModelAsync()
        {
            await Task.Delay(0);
            return PRODUCTION.APPLICABLE_MODEL;
        }


        /*public async Task<ProductionParam> DeleteAsync(string id)
        {
            await this.EnforceProductionProfileParamExistenceAsync(id);

            var entity = await _paramRepository.DeleteAsync(id);
            return entity;
        }*/

        //get by profile id
        public async Task<IEnumerable<ProductionParam>> ListParamsAsync(string id = null)
        {
            if (String.IsNullOrEmpty(id))
            {

                return await _paramRepository.ListAsync();
            }

            return await _paramRepository.ListAsync(id);
        }

        public async Task<ProductionParam> EnforceProductionProfileParamExistenceAsync(string id)
        {
            var act = await _paramRepository.GetAsync(id);

            if (act == null)
            {
                throw new ProductionNotFoundException();
            }

            return act;
        }


        public async Task<Production> GetCurentlyProductAsync(string id)
        {
            var entity = await _productionRepository.ListAsync();
            if (entity == null)
            {
                throw new ProductionNotFoundException();
            }

            var current = entity.Where(c => c.Id == id).FirstOrDefault();
            if (current == null)
            {
                throw new ProductionNotFoundException();
            }

            //get current by key
            var lastest = entity.Where(c => c.Key == current.Key && c.Status == RecordStatus.ACTIVE.GetDescription()).OrderByDescending(c => c.Created).FirstOrDefault();
            if (lastest == null)
            {
                throw new ProductionNotFoundException();
            }

            lastest.OilProfile = await this.GetCurentlyProfileAsync(lastest.Id, ApplicableModel.OIL.ToString());
            lastest.GasProfile = await this.GetCurentlyProfileAsync(lastest.Id, ApplicableModel.GAS.ToString());

            return lastest;
        }

        //
        // Summary:
        //     Returns the  currenty active profile by production(parent) id
        //
        // Returns:
        //     Models.Entity.ProductionProfile object
        //
        // Type parameters:
        //   id:
        //     by production id
        //
        //
        public async Task<ProductionProfile> GetCurentlyProfileAsync(string id, string type)
        {
            var entity = await _profileRepository.ListAsync();
            if (entity == null)
            {
                throw new ProductionNotFoundException();
            }

            var result = entity.Where(c => c.ProductionId == id && c.ApplicableModel == type).FirstOrDefault();
            return result;
        }

        public async Task<ProductionProfileParams> EstimateRemainProductionAsync(ProductionProfileParams parameters)
        {
            await Task.Delay(0);
            var onlineeeDate = parameters.SelectedStartDate;

            // decimal reserve = 0;

            //swap reserve when we ApplicableModel.SEPARATE.ToString() OLI or ApplicableModel.GAS.ToString()
            /* if (profile.ApplicableModel == ApplicableModel.GAS.ToString())
            {
                //init total reserve for profilr rate !!! importaatn
                reserve = reserve.GasInMMSCF.GetValueOrDefault();
                onlineeeDate = attribute.GasProjectStartDate.Value;
            }
            else
            {   //init total reserve for profilr rate !!! importaatn
                reserve = reserve.LiquidInMBOE.GetValueOrDefault();
                onlineeeDate = attribute.OilProjectStartDate.Value;
            }*/

            var engine = new CalculationEngine();
            //ProductionTrend.RAMPUP.GetDescription()
            engine.AddFunction("ramp_term1", (d, s, r) =>
                {
                    if (d > s + r) return r;
                    else return d - s;
                });

            engine.AddFunction("ramp_term2", (d, s, r) =>
            {
                if (d < s + r) return d - s;
                else return r;
            });

            engine.AddFunction("ramp_term3", (d, s, r) =>
            {
                if (d - 1 > s) return d - 1 - s;
                else return 0;
            });

            //ProductionTrend.PLATEAU.GetDescription()
            engine.AddFunction("plateau_term1", (d, s, r, p) =>
            {
                if (d < s + r + p) return d - s;
                else return r + p;
            });

            engine.AddFunction("plateau_term2", (d, s, r, p) =>
            {
                if (d - 1 > s + r) return d - 1 - s;
                else return r;
            });

            //ProductionTrend.DECLINE.GetDescription()
            engine.AddFunction("exp", (a) =>
            {
                return Math.Exp(a);
            });

            var attribute = parameters.SelectedAttribute;
            ///   attribute.RampUpDay = 0;


            var profile = parameters.PickedProfileRate;

            //oil
            int currentDay = parameters.CurrentDay;
            int shiftDay = attribute.ShiftStartDay.GetValueOrDefault();
            int rampDay = attribute.RampUpDay.GetValueOrDefault();

            //decimal initGasRate = await this.GetProfileRateAsync(profile);
            //profile.TotalReserve = parameters.Reserve.Value; //carry value

            decimal reserve = parameters.Reserve.Value.GetValueOrDefault();
            decimal rate = parameters.PickedProfileRate.Value.GetValueOrDefault();
            parameters.CalculatedRate = rate;

            /* if (rate <= 0)
            {
                //throw new ProductionNotValidException("initail rate must be more than zero");
            }*/

            var flag = false;
            List<ProductionVolumn> plots = new List<ProductionVolumn>();
            var totalRampVolumn = 0m;

            do
            {
                //initi reseve = 0
                if (reserve <= 0)
                {
                    //throw new ProductionNotValidException("initail reserve");
                    var entity = new ProductionVolumn() { CurrentDay = currentDay, CurrentDate = onlineeeDate.AddDays(currentDay) };
                    plots.Add(entity);

                    flag = false;
                }
                else
                {


                    decimal AbdRate = profile.AbandonmentRate.GetValueOrDefault();
                    decimal holdupPercentage = profile.HoldupPercentage.GetValueOrDefault() / 100;

                    decimal plateauDay = (holdupPercentage * reserve) / rate;
                    //  int gasPlateauDay = Convert.ToInt32((profile.HoldupPercentage * reserve) / initGasRate);
                    //Log.Information("rate: " + rate);
                    //   decimal jj = (holdupPercentage * reserve) / rate;

                    if (currentDay > shiftDay)
                    {
                        var totalReserver = 0m;


                        //construct params
                        Dictionary<string, double> variables = new Dictionary<string, double>();
                        variables.Add("InitailRate", Convert.ToDouble(rate));
                        variables.Add("ShiftDay", shiftDay);
                        variables.Add("RampDay", rampDay);
                        variables.Add("CurrentDay", currentDay);

                        var entity = new ProductionVolumn() { CurrentDay = currentDay, CurrentDate = onlineeeDate.AddDays(currentDay) };


                        if (currentDay > shiftDay && currentDay < (shiftDay + rampDay + 1))
                        {
                            //ProductionTrend.RAMPUP.GetDescription()UP
                            string term1 = String.Format("ramp_term1({0}, {1}, {2})", currentDay, shiftDay, rampDay);
                            string term2 = String.Format("ramp_term2({0}, {1}, {2})", currentDay, shiftDay, rampDay);
                            string term3 = String.Format("ramp_term3({0}, {1}, {2})", currentDay, shiftDay, rampDay);

                            variables.Add("RampTerm1Day", engine.Calculate(term1));
                            variables.Add("RampTerm2Day", engine.Calculate(term2));
                            variables.Add("RampTerm3Day", engine.Calculate(term3));

                            //!! execute
                            Func<Dictionary<string, double>, double> function = engine.Build(parameters.RampupProductionFormula);

                            var temp = 0m;
                            try
                            {
                                var result = function(variables);
                                temp = Convert.ToDecimal(result);
                            }
                            catch (Exception ex)
                            {
                                throw ex;
                            }

                            totalReserver = totalReserver + temp;
                            entity.RampVolumn = temp;
                            entity.Slope.Add(ProductionTrend.RAMPUP.GetDescription());

                            totalRampVolumn = totalRampVolumn + temp;


                            // Log.Information("rampDay: " + rampDay);


                            //Log.Information(string.Format("ramp_term1({0}, {1}, {2}) = {3}", currentDay, shiftDay, rampDay, engine.Calculate(term1)));
                            //Log.Information(string.Format("ramp_term2({0}, {1}, {2}) = {3}", currentDay, shiftDay, rampDay, engine.Calculate(term2)));
                            //Log.Information(string.Format("ramp_term3({0}, {1}, {2}) = {3}", currentDay, shiftDay, rampDay, engine.Calculate(term3)));
                        }

                        if (currentDay > shiftDay + rampDay && currentDay < (shiftDay + rampDay + plateauDay + 1))
                        {
                            //ProductionTrend.PLATEAU.GetDescription()
                            string term1 = String.Format("plateau_term1({0}, {1}, {2}, {3})", currentDay, shiftDay, rampDay, plateauDay);
                            string term2 = String.Format("plateau_term2({0}, {1}, {2}, {3})", currentDay, shiftDay, rampDay, plateauDay);

                            variables.Add("PlateauTerm1Day", engine.Calculate(term1));
                            variables.Add("PlateauTerm2Day", engine.Calculate(term2));


                            //!! execute
                            Func<Dictionary<string, double>, double> function = engine.Build(parameters.PlateauProductionFormula);

                            var temp = 0m;
                            try
                            {
                                var result = function(variables);
                                temp = Convert.ToDecimal(result);
                            }
                            catch (Exception ex)
                            {
                                throw ex;
                            }

                            totalReserver = totalReserver + temp;
                            entity.PlateauVolumn = temp;
                            entity.Slope.Add(ProductionTrend.PLATEAU.GetDescription());


                            //  Log.Information("plateauDay: " + plateauDay);

                            //Log.Information(string.Format("plateau_term1({0}, {1}, {2}, {3}) => {4}", currentDay, shiftDay, rampDay, plateauDay, engine.Calculate(term1)));
                            //Log.Information(string.Format("plateau_term2({0}, {1}, {2}, {3}) => {4}", currentDay, shiftDay, rampDay, plateauDay, engine.Calculate(term2)));
                        }

                        if (currentDay > shiftDay + rampDay + plateauDay)
                        {

                            decimal declineRate = (rate - AbdRate) / ((reserve - (holdupPercentage * reserve)) - totalRampVolumn);

                            //ProductionTrend.DECLINE.GetDescription()
                            variables.Add("AbandonRate", Convert.ToDouble(AbdRate));
                            variables.Add("DeclineRate", Convert.ToDouble(declineRate));
                            variables.Add("PlateauDay", Convert.ToDouble(plateauDay));

                            //assign
                            parameters.DeclineRate = declineRate;
                            parameters.PlateauDay = plateauDay;
                            //parameters.TotalRampupVolumn = totalRampVolumn;
                            //parameters.oilPlateauResereve = 

                            //!! execute
                            Func<Dictionary<string, double>, double> function = engine.Build(parameters.DeclineProductionFormula);


                            var temp = 0m;
                            try
                            {
                                var result = function(variables);
                                temp = Convert.ToDecimal(result);
                            }
                            catch (Exception ex)
                            {
                                throw ex;
                            }

                            totalReserver = totalReserver + temp;
                            entity.DeclineValue = temp;
                            entity.Slope.Add(ProductionTrend.DECLINE.GetDescription());


                            //Log.Information("rampDay: " + rampDay);
                        }

                        //lastdaay 
                        var summm = plots.Sum(c => c.TotalValue) + totalReserver;

                        //collect last day reserve
                        if (summm >= reserve)
                        {
                            var bb = reserve - plots.Sum(c => c.TotalValue);
                            // Log.Information(" last day  ->  " + bb);

                            entity.TotalValue = bb;
                        }
                        else
                        {
                            entity.TotalValue = totalReserver;
                        }


                        plots.Add(entity);
                        // Log.Information(parameters.ApplicableModel + " > day: " + currentDay.ToString() + " -> " + entity.TotalValue);

                        if (totalReserver <= 0 || entity.CurrentDate >= attribute.ProjectCutOffDate || summm >= reserve)
                        {
                            flag = false;
                        }
                        else
                        {
                            flag = true;
                        }

                        //add cutt off date condition
                        // if (entity.CurrentDate == attribute.ProjectCutOffDate)
                        // {
                        //     flag = false;
                        // }
                    }
                    else
                    {
                        flag = true;
                    }

                    currentDay++;
                }

            }
            while (flag); //for zero reserve

            //assign
            parameters.Plots = plots;
            parameters.ContinueDay = currentDay;

            ///for cross check
            parameters.PlotDates = parameters.Plots.Select(c => c.CurrentDate.Value.ToString("dd/MM/yyyy")).ToArray();
            parameters.PlotValues = parameters.Plots.Select(c => c.TotalValue).ToArray();

            //var summmmyyyyy = plots.Sum(c => c.TotalValue);

            // Log.Information("summary productive reserve -> " + (summmmyyyyy));
            //Log.Information("reserve productive reserve -> " + (reserve));

            return parameters;
        }

        //with calculate formular, count = number of well
        public async Task<ProductionProfile> EvaluateProfileRateAsync(ProductionProfile rate, WellReserve reserve)
        {
            await Task.Delay(0);

            if (rate.ValueType == FormulaType.FIXED.GetDescription())
            {
                return rate;
            }
            else
            {
                //return p.Value.GetValueOrDefault();
                if (reserve.Value == 0)
                {
                    rate.Value = 0;
                    return rate;
                }

                //add MMSCF profile rate
                // rate.Params = new List<ProductionParam>();
                rate.Params.Add(new ProductionParam() { Name = "MMSCF", Value = reserve.Value });


                //eval with formular 
                //!! execute
                var engine = new CalculationEngine();

                // engine.AddFunction("%", (a) =>
                // {
                //     return a / 100;
                // });

                // Regex r = new Regex("(?:[^a-z0-9 ]|(?<=['\"]))", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant | RegexOptions.Compiled);
                var formula = rate.EVFormulaForIPCDRATE.Replace(@"%", "/100");

                Func<Dictionary<string, double>, double> function = engine.Build(formula);
                Dictionary<string, double> variables = new Dictionary<string, double>();

                foreach (ProductionParam pp in rate.Params)
                {
                    variables.Remove(pp.Name);
                    variables.Add(pp.Name, Convert.ToDouble(pp.Value));
                }

                try
                {
                    rate.Value = 0m;

                    try
                    {
                        double result = function(variables);
                        rate.Value = Convert.ToDecimal(result);
                    }
                    catch (OverflowException)
                    {
                        throw new ProductionNotValidException();
                    }
                    catch (Exception)
                    {
                        throw new ProductionNotValidException(formula);
                    }

                    if (rate.Value.GetValueOrDefault() < PRODUCTION.LOWER_BOUNDARY)
                    {
                        rate.Value = PRODUCTION.LOWER_BOUNDARY;
                    }

                    return rate; //multiply by well count
                }
                catch (ParseException) // ex)
                {
                    throw new ProductionNotValidException();
                }
                catch (Jace.VariableNotDefinedException) // ex)
                {
                    throw new ProductionNotValidException(formula);
                }
            }
        }


        //
        // Summary:
        //     Returns the avaible applicatble model by porduction id
        //
        // Returns:
        //
        //   list of  Models.Entity.Item object
        //
        // Type parameters:
        //   id :  
        //     production id
        //


        public async Task<IEnumerable<Item>> GetAvailableApplicableModel(string id)
        {

            var production = await _productionRepository.GetAsync(id);
            if (production == null)
            {
                throw new ProductionNotFoundException();
            }

            var result = PRODUCTION.APPLICABLE_MODEL.ToList();
            if (production.IsGasModelApplicable == false)
            {
                result = result.Where(c => c.Id != ApplicableModel.GAS.ToString()).ToList();
            }

            if (production.IsOilModelApplicable == false)
            {
                result = result.Where(c => c.Id != ApplicableModel.OIL.ToString()).ToList();
            }

            if (production.IsSeparateModelApplicable == false)
            {
                result = result.Where(c => c.Id != ApplicableModel.SEPARATE.ToString()).ToList();
            }

            return result;

        }
    }
}