
using System; 

using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;

namespace surflex.netcore22.Services
{
    public interface IPathFinderService
    {
        Task<string> FindAsync(string path);
    }


    public class PathFinderService : IPathFinderService
    {
        private IHostingEnvironment _hostingEnvironment;

        public PathFinderService(IHostingEnvironment environment)
        {
            _hostingEnvironment = environment;
        }

        public async Task<string> FindAsync(string path)
        {
            var filePath = Path.Combine(_hostingEnvironment.ContentRootPath, path);
            return await Task.FromResult(filePath);
        }
    }
}