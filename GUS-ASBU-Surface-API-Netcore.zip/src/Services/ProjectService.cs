//configure

using Serilog;
//apis
using surflex.netcore22.APIs;
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;
using surflex.netcore22.Exceptions;
using surflex.netcore22.Extensions;
using surflex.netcore22.Helpers;
using surflex.netcore22.Helpers.DataHandler;
using surflex.netcore22.Helpers.TemplateProfile;
//model
using surflex.netcore22.Models;
using GLOBAL = surflex.netcore22.Models.Constants.GlobalConstants;
using surflex.netcore22.Repositories;
using System;

using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
//using surflex.netcore22.Helpers.TemplateProfile;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;


using DRILLED = surflex.netcore22.Models.Constants.Drilled;
using System.IdentityModel.Tokens.Jwt;
using System.Diagnostics;
using Microsoft.Extensions.Caching.Memory;

namespace surflex.netcore22.Services
{

    class ListComparer<T> : IEqualityComparer<List<T>>
    {
        public bool Equals(List<T> x, List<T> y)
        {
            return x.SequenceEqual(y);
        }

        public int GetHashCode(List<T> obj)
        {
            int hashcode = 0;
            foreach (T t in obj)
            {
                hashcode ^= t.GetHashCode();
            }
            return hashcode;
        }
    }

    public class ProjectService : IProjectService
    {

        //  private readonly string ActivityAction.PUBLISHED.GetDescription() = "ActivityAction.PUBLISHED.GetDescription()ED";
        // private readonly string SUMMARY = "WELL_SUMMARY";


        //   private readonly string ActivityAction.SAVED.GetDescription() = "ActivityAction.SAVED.GetDescription()D";
        // private readonly string UPDATE = "UPDATED";
        // private readonly string ActivityAction.PUBLISHED.GetDescription() = "ActivityAction.PUBLISHED.GetDescription()ED";
        private readonly string PROJECT_WELL = "PROJECT_WELL";
        private readonly string PROJECT_DRILLED = "PROJECT_DRILLED";

        // private const string PLANNED = "Planned";
        // private const string DRILLING = "Drilling";
        // private const string COMPLETED = "Completed";
        // private const string TUBING = "Tubing and Completion";

        private readonly IProjectRepository _projectRepository;
        //private readonly IclientService _clientService;
        private readonly IWellService _wellService;
        private readonly IProjectWellService _projectWellService;
        private readonly IJobService _jobService;
        private readonly ISandService _sandService;

        private readonly IProductionService _productionService;

        private readonly IMapper<IEnumerable<WellProductiveAsync>, IEnumerable<WellProductive>> _wellProductiveMapper;

        private readonly IProjectAttributeRepository _projectAttributeRepository;
        private readonly IMapper<IEnumerable<ProjectAsync>, IEnumerable<Project>> _projectMapper;


        private readonly IProjectSpaceRepository _projectSpaceRepository;
        private readonly IProjectWellRepository _projectWellRepository;
        private readonly IProjectActivityRepository _projectActivityRepository;

        private readonly IProjectDrilledRepository _projectDrilledRepository;


        private readonly IProjectLocationRepository _projectLocationRepository;

        private readonly IWorkUnitService _workUnitService;
        private readonly IEntityService _entityService;

        private readonly IPriceService _priceService;
        private readonly ITemplateService _templateService;

        private readonly IAttachmentService _attachmentService;
        private readonly IPathFinderService _pathFinderService;

        protected readonly IProjectAuthorizeRepository _projectAuthorizeRepository;


        private readonly IConfiguration _configuration;

        //user
        private readonly IUserService _userService;
        private readonly IHttpService _httpService;

        private readonly User httpCurrentUser;


        //private readonly Models.Cache _cachingService;
        public ProjectService(IProjectRepository projectRepository, //, IclientService clientService,
                            IWellService wellService, IUserService userService,
                            IMapper<IEnumerable<ProjectAsync>, IEnumerable<Project>> projectMapper,
                            IMapper<IEnumerable<WellProductiveAsync>, IEnumerable<WellProductive>> wellProductiveMapper, IProjectAttributeRepository projectAttributeRepository,
                            IProjectSpaceRepository projectSpaceRepository, IProjectWellRepository projectSummaryRepository, IProjectActivityRepository projectActivityRepository,
                            IWorkUnitService workUnitService, IJobService jobService, IEntityService entityService, IProjectWellService projectWellService, IProductionService productionService,
                            IProjectDrilledRepository projectDrilledRepository, IPriceService priceService, ITemplateService templateService, IAttachmentService attachmentService,
                            IPathFinderService pathFinder, IProjectAuthorizeRepository projectAuthorizeRepository, IHttpService httpService, IConfiguration configuration, IProjectLocationRepository projectLocationRepository,
                            ISandService sandService) //, Models.Cache cachingService)
        {
            _projectRepository = projectRepository ?? throw new ArgumentNullException(nameof(projectRepository));

            _projectMapper = projectMapper ?? throw new ArgumentNullException(nameof(projectMapper));
            _wellService = wellService ?? throw new ArgumentNullException(nameof(wellService));
            _projectWellService = projectWellService ?? throw new ArgumentNullException(nameof(projectWellService));
            _jobService = jobService ?? throw new ArgumentNullException(nameof(jobService));

            _wellProductiveMapper = wellProductiveMapper ?? throw new ArgumentNullException(nameof(_wellProductiveMapper));
            _projectAttributeRepository = projectAttributeRepository ?? throw new ArgumentNullException(nameof(projectAttributeRepository));
            _userService = userService ?? throw new ArgumentNullException(nameof(userService));

            _projectSpaceRepository = projectSpaceRepository ?? throw new ArgumentNullException(nameof(projectSpaceRepository));
            _projectWellRepository = projectSummaryRepository ?? throw new ArgumentNullException(nameof(projectSummaryRepository));
            _projectActivityRepository = projectActivityRepository ?? throw new ArgumentNullException(nameof(projectActivityRepository));

            _productionService = productionService ?? throw new ArgumentNullException(nameof(productionService));
            _projectDrilledRepository = projectDrilledRepository ?? throw new ArgumentNullException(nameof(projectDrilledRepository));

            _priceService = priceService ?? throw new ArgumentNullException(nameof(priceService));

            _templateService = templateService ?? throw new ArgumentNullException(nameof(templateService));

            _attachmentService = attachmentService ?? throw new ArgumentNullException(nameof(attachmentService));
            _pathFinderService = pathFinder ?? throw new ArgumentNullException(nameof(pathFinder));


            _workUnitService = workUnitService ?? throw new ArgumentNullException(nameof(workUnitService));
            _entityService = entityService ?? throw new ArgumentNullException(nameof(entityService));

            _projectAuthorizeRepository = projectAuthorizeRepository ?? throw new ArgumentNullException(nameof(projectAuthorizeRepository));

            _projectLocationRepository = projectLocationRepository ?? throw new ArgumentNullException(nameof(projectLocationRepository));

            _httpService = httpService ?? throw new ArgumentNullException(nameof(httpService));

            _sandService = sandService ?? throw new ArgumentNullException(nameof(sandService));
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));

            //_cachingService = cachingService;

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();


            httpCurrentUser = _httpService.GetHttpCurrentUserAsync().Result;
        }


        // public async Task<IEnumerable<Item>> ListLocationAsync()
        // {
        //     await Task.Delay(0);
        //     //  await this.EnforceRoleExistenceAsync(id);
        //     return GLOBAL.PROJECT_LOCATION;
        // }

        public async Task<Project> CreateAsync(Project project)
        {

            project.Id = Utility.ToUniqeIdentity(project.Name);

            //assigned
            project.Name = project.Name.ToUpper();
            project.RLLCPReferenceId = project.RLLCPReferenceId;
            project.Created = Utility.CurrentSEAsiaStandardTime();
            //well.By = httpCurrentUser.Id;

            var entity = await _projectRepository.CreateAsync(project);
            return entity;
        }

        public async Task<Project> UpdateAsync(Project project)
        {
            var update = await this.EnforceProjectExistenceAsync(project.Id);

            update.Name = project.Name;
            update.Created = Utility.CurrentSEAsiaStandardTime();

            //await EnforceClanExistenceAsync(Project.Clan.Name);
            //await EnforceProjectExistenceAsync(Project.Clan.Name, Project.Key);
            var entity = await _projectRepository.UpdateAsync(update);
            return entity;
        }

        public async Task<IEnumerable<Project>> ListAsync()
        {
            return await _projectRepository.ListAsync();
        }

        public async Task<Project> GetAsync(string id)
        {

            return await _projectRepository.GetAsync(id);
        }

        /*  public async Task<ProjectSummary> GetWithSummaryAsync(string id)
         {
             await this.EnforceProjectExistenceAsync(id);

             var entity = await _projectRepository.GetWithSummaryAsync(id);
             return entity;
         }*/

        /*  public async Task<IEnumerable<ProjectSummary>> ListActiveAsync()
         {
             List<ProjectSummary> sums = new List<ProjectSummary>();

             //List project from RLLCP
             var projects = await _projectRepository.ListActiveAsync();
             if (projects == null)
             {
                 throw new ProjectNotApiNotFoundException()ALL");
             }

             //Look up maxdate from UIDM to know project is active
             foreach (ProjectAsync p in projects)
             {
                 //list well heirachy by project
                 var wellHierarchys = await _wellService.ListAsync(p.Id); //_clientService.ListPlannedWellAsync(p.Id);

                 if (wellHierarchys == null)
                 {
                     continue;
                 }

                 // Stopwatch watch = Stopwatch.StartNew();

                 bool flag = await _wellService.ListProductiveAsync(wellHierarchys);

                 if (flag)
                 {
                     sums.Add(new ProjectSummary()
                     {
                         Id = p.Id.ToString(),
                         Name = p.Name,
                         PlatformName = p.Platform,
                         Status = "ACTIVE",
                         Created = p.CreatedDate,

                         Wells = wellHierarchys
                     });
                 }

                 // Log.Information("Elapsed time {0} ms", watch.ElapsedMilliseconds);
             }

             if (sums.Count <= 0)
             {
                 throw new ProjectNotActiveException();
             }
             else
             {
                 return sums; //date well project (ACTIVE)
             }
         }*/


        public async Task<IEnumerable<Project>> ListProductiveAsync()
        {

            //List<ProjectSummary> sums = new List<ProjectSummary>();

            var wells = await _wellService.ListProductiveAsync();
            //var mapped = _wellProductiveMapper.Reverse(wells);
            var entity = wells.Select(c => c.Name).Distinct().ToArray();

            var projects = await _entityService.ListPlannedProjectWellAsync(entity);
            if (!projects.Any())
            {
                throw new ProjectNotFoundException();
            }


            return _projectMapper.Mapp(projects);
        }

        public async Task<Project> EnforceProjectExistenceAsync(string id)
        {
            var project = await _projectRepository.GetAsync(id);

            if (project == null)
            {
                throw new ProjectNotFoundException();
            }

            return project;
        }

        public async Task<ProjectDrilled> EnforceDrilledExistenceAsync(Guid id)
        {
            var project = await _projectDrilledRepository.GetAsync(id);

            if (project == null)
            {
                throw new ProjectDrilledNotFoundException();
            }

            return project;
        }



        public async Task<Project> EnforceProjectCreateAsync(Project project)
        {
            var id = Utility.ToUniqeIdentity(project.Name);
            var enforece = await _projectRepository.GetAsync(id);
            if (enforece != null)
            {
                return enforece;
            }

            //await EnforceClanExistenceAsync(Well.Clan.Name);
            var entity = await this.CreateAsync(project);
            return entity;
        }


        //atrribute
        public async Task<ProjectAttribute> CreateAsync(ProjectAttribute attribute)
        {
            //deactive old
            if (!String.IsNullOrEmpty(attribute.Id))
            {
                var project = await _projectAttributeRepository.GetAsync(attribute.Id);
                if (project == null)
                {
                    throw new ProjectAttributeNotFoundException();
                }


                project.Status = RecordStatus.ARCHIVED.GetDescription();
                project.FinishDate = Utility.CurrentSEAsiaStandardTime();

                await _projectAttributeRepository.UpdateAsync(project);

            }

            //create new
            var ids = Utility.ToUniqeIdentity(attribute.ProjectName);
            var enforce = await this.EnforceProjectExistenceAsync(ids);

            //assigned
            attribute.ProjectId = enforce.Id;
            attribute.Id = Guid.NewGuid().ToString();

            attribute.Created = Utility.CurrentSEAsiaStandardTime();
            attribute.Status = RecordStatus.ACTIVE.GetDescription();

            attribute.StartDate = Utility.CurrentSEAsiaStandardTime();

            //to local time
            attribute.GasProjectStartDate = attribute.GasProjectStartDate?.ToLocalTime();
            attribute.OilProjectStartDate = attribute.OilProjectStartDate?.ToLocalTime();
            attribute.ProjectCutOffDate = attribute.ProjectCutOffDate?.ToLocalTime();


            attribute.By = httpCurrentUser.Id;
            //await EnforceClanExistenceAsync(ProjectAttribute.Clan.Name);

            var entity = await _projectAttributeRepository.CreateAsync(attribute);
            if (entity == null)
            {
                throw new ProjectAttributeNotFoundException();
            }

            //assigned name
            //swap namespace Name
            entity.By = httpCurrentUser.CAI;

            entity.ProjectName = attribute.ProjectName;
            return entity;
        }


        /* public async Task<ProjectAttribute> CreateAsync(string type, string sand, string descript, string by)
        {

            //store attribute
            ProjectAttribute attribute = new ProjectAttribute()
            {
                Id = Guid.NewGuid().ToString(),
                By = by,

                Date = Utility.ToSEAsiaStandardTime(),
                Description = descript,
                SandId = sand,

                Type = type
            };


            attribute.Id = Guid.NewGuid().ToString();
            attribute.Date = Utility.CurrentSEAsiaStandardTime();

            //await EnforceClanExistenceAsync(ProjectAttribute.Clan.Name);
            var entity = await _projectAttributeRepository.CreateAsync(attribute);
            if (entity == null)
            {
                throw new ProjectAttributeNotFoundException(attribute);
            }


            return entity;
        }*/


        public async Task<ProjectAttribute> UpdateAsync(ProjectAttribute attribute)
        {
            var updated = await this.EnforceProjectAttributeExistenceAsync(attribute.Id);

            //assigned
            //ProjectAttribute.Created = Utility.CurrentSEAsiaStandardTime();
            //ProjectAttribute.ProjectAttribute = ProjectAttribute.ProjectAttribute;
            //ProjectAttribute.Status = ProjectAttribute.Status;

            var entity = await _projectAttributeRepository.UpdateAsync(attribute);
            if (entity == null)
            {
                throw new ProjectAttributeNotFoundException();
            }

            return entity;
        }

        // public async Task<ProjectAttribute> GetAttributeAsync(string id)
        // {
        //     //  await this.EnforceProjectAttributeExistenceAsync(id);

        //     var entity = await _projectAttributeRepository.GetAsync(id);
        //     return entity;
        // }

        public async Task<ProjectAttribute> GetAttributeAsync(string id)
        {

            /* if (String.IsNullOrEmpty(attr.Id))
            {
                string ids = Utility.ToUniqeIdentity(attr.ProjectName);
                attr.ProjectId = ids;

                var result = await _projectAttributeRepository.GetAsync(attr);
                if (result == null)
                {
                    throw new ProjectAttributeNotFoundException();
                }

                //assigned name
                result.ProjectName = attr.ProjectName;

                return result;
            }*/

            //  await this.EnforceProjectAttributeExistenceAsync(id);
            var entity = await _projectAttributeRepository.GetAsync(id);
            if (entity == null)
            {
                throw new ProjectAttributeNotFoundException();
            }

            var p = await _projectRepository.GetAsync(entity.ProjectId);
            //assigned name
            entity.ProjectName = p.Name;

            return entity;
        }


        public async Task<ProjectAttribute> DeleteAsync(string id)
        {
            await this.EnforceProjectAttributeExistenceAsync(id);

            var entity = await _projectAttributeRepository.DeleteAsync(id);
            return entity;
        }

        public async Task<IEnumerable<ProjectAttribute>> ListAttributeAsync(string status)
        {
            //return await _projectAttributeRepository.ListAsync();

            var entity = await _projectAttributeRepository.ListAsync();
            if (entity == null)
            {
                throw new TemplateNotFoundException();
            }

            if (string.IsNullOrEmpty(status))
            {
                return entity;
            }

            return entity.Where(c => c.Status == status);
        }

        public async Task<ProjectAttribute> EnforceProjectAttributeExistenceAsync(string id)
        {
            var act = await _projectAttributeRepository.GetAsync(id);

            if (act == null)
            {
                throw new ProjectAttributeNotFoundException();
            }

            return act;
        }




        public async Task<ProjectSpace> EnforceProjectSpaceExistenceAsync(string id)
        {
            var entity = await _projectSpaceRepository.GetAsync(id);
            if (entity == null)
            {
                throw new ProjectNotFoundException();
            }

            return entity;
        }

        public async Task<ProjectWell> EnforceProjectWellExistenceAsync(string id)
        {
            var entity = await _projectWellRepository.GetAsync(id);
            if (entity == null)
            {
                throw new ProjectNotFoundException();
            }

            return entity;
        }


        public async Task<ProjectActivity> CreateAsync(ProjectActivity activity)
        {
            activity.Id = Guid.NewGuid().ToString();
            activity.Date = Utility.CurrentSEAsiaStandardTime();

            var entity = await _projectActivityRepository.CreateAsync(activity);
            if (entity == null)
            {
                throw new ProjectAttributeNotFoundException();
            }

            return entity;
        }

        //
        // Summary:
        //     retrun the well properties of publish project
        //
        // Returns:
        //
        //   list of  Models.Entity.WellProperties object
        //
        // Type parameters:
        //   id:
        //      project space id
        //
        public async Task<ProjectSpace> PublishSpaceAsync(string id)
        {
            //is well existitng    
            var project = await this.EnforceProjectSpaceExistenceAsync(id);

            //create activity
            var created = new ProjectActivity(id, "NA", ActivityAction.PUBLISHED.GetDescription(), httpCurrentUser.Id);
            created.Id = Guid.NewGuid().ToString();
            created.Date = Utility.CurrentSEAsiaStandardTime();

            var activity = await _projectActivityRepository.CreateAsync(created);

            project.ActivityDate = activity.Date;
            project.ActivityType = activity.Action;

            var user = await _userService.GetAsync(activity.By);
            project.By = user.CAI;

            return (project);
        }

        public async Task<ProjectSpace> CreateAsync(ProjectSpace space)
        {
            var id = Utility.ToUniqeIdentity(space.ProjectName);
            var project = await _projectRepository.GetAsync(id);
            if (project == null)
            {
                throw new ProjectNotFoundException();
            }

            space.Id = Guid.NewGuid().ToString();

            //assigned
            space.ProjectId = id;
            space.ProjectName = project.Name;
            // project.RLLCPReferenceId = project.RLLCPReferenceId;
            space.Created = Utility.CurrentSEAsiaStandardTime();
            //space.Status = RecordStatus.ACTIVE.GetDescription();
            space.By = httpCurrentUser.Id;

            var entity = await _projectSpaceRepository.CreateAsync(space);
            return entity;

        }


        public async Task<ProjectWell> CreateAsync(ProjectWell well)
        {
            //var ids = Utility.ToUniqeIdentity(space.ProjectName);
            var project = await this.EnforceProjectSpaceExistenceAsync(well.ProjectSpaceId);
            if (project == null)
            {
                throw new ProjectNotFoundException();
            }

            well.Rev = Guid.NewGuid().ToString();
            well.Key = Guid.NewGuid().ToString();

            //assigned
            //project.Name = project.Name.ToUpper();
            // project.RLLCPReferenceId = project.RLLCPReferenceId;
            well.Created = Utility.CurrentSEAsiaStandardTime();
            well.StartDate = Utility.CurrentSEAsiaStandardTime();

            well.Status = RecordStatus.ACTIVE.GetDescription();
            well.By = httpCurrentUser.Id;

            var entity = await _projectWellRepository.CreateAsync(well);
            return entity;
        }


        public async Task<ProjectWell> UpdateAsync(ProjectWell well)
        {
            var updated = await this.EnforceProjectWellExistenceAsync(well.Id);


            var entity = await _projectWellRepository.UpdateAsync(well);
            if (entity == null)
            {
                throw new ProjectWellNotFoundException();
            }

            return entity;
        }


        public async Task<ProjectSpace> UpdateAsync(ProjectSpace space)
        {
            var updated = await this.EnforceProjectSpaceExistenceAsync(space.Id);


            var entity = await _projectSpaceRepository.UpdateAsync(space);
            if (entity == null)
            {
                throw new ProjectWellNotFoundException();
            }

            return entity;
        }

        //
        // Summary:
        //     retrun the recently by project name, RLLCP project id
        //
        // Returns:
        //
        //   ProjectWell object
        //
        // Type parameters:
        //  rllcp
        //      rllcp project id
        //   nanme:
        //      project name
        //
        //
        public async Task<ProjectWell> GetWellRecentlyAsync(int rllcp, string name, bool synce)
        {
            var id = Utility.ToUniqeIdentity(name);
            //var well = await _wellService.EnforceWellExistingAsync(id);

            var entity = await _projectWellRepository.GetRecentlyAsync(id, httpCurrentUser.Id);
            if (entity == null)
            {
                throw new ProjectWellNotFoundException();
            }

            //get recet activity

            //get publisher
            if (entity.By == httpCurrentUser.Id)
            {
                entity.IsPublisher = true;
            }

            //synce new well >?????
            if (synce == true)
            {
                //set properties
                var props = await _wellService.SyncePropertiesAsync(rllcp, name, entity.Id);
                entity.Properties = props.Where(c => c.ProjectWellId == entity.Id).ToList();

            }
            else
            {
                //set properties
                var props = await _wellService.ListPropertiesAsync();
                entity.Properties = props.Where(c => c.ProjectWellId == entity.Id).ToList();

            }


            // //get user cai
            var user = await _userService.GetAsync(entity.By);
            entity.By = user == null ? entity.By : user.CAI;

            return entity;
        }

        //
        // Summary:
        //     retrun the synce WELL Properties by project name, RLLCP project id
        //
        // Returns:
        //
        //   ProjectWell object
        //
        // Type parameters:
        //  rllcp
        //      rllcp project id
        //   nanme:
        //      project name
        //
        //
        public async Task<ProjectWell> SynceWellAsync(int rllcp, string name)
        {
            var entity = new ProjectWell()
            {
                Id = "tempolary",
                ActivityType = ActivityAction.SYNCED.GetDescription(),
                ActivityDate = Utility.CurrentSEAsiaStandardTime(),

                ProjectName = name,
                ProjectId = Utility.ToUniqeIdentity(name),
            };

            //synce with default value
            var props = await _wellService.SyncePropertiesAsync(rllcp, name, entity.Id);
            entity.Properties = props.ToList(); //.Where(c => c.ProjectWellId == entity.Id).ToList();

            //get user cai
            // var user = await _userService.GetAsync(httpCurrentUser.CAI);
            entity.By = "SURFACE";

            return entity;
        }





        //
        // Summary:
        //     retrun the well of  RLLCP with total / completed
        //
        // Returns:
        //
        //   list of  Models.Entity.WellProperties object
        //
        // Type parameters:
        //   name:
        //     Project name
        //   rllcp:
        //     RLLCP project id
        //
        public async Task<ProjectWell> GetPlannedWellAsync(string name, int rllcp)
        {
            var id = Utility.ToUniqeIdentity(name);
            //var well = await _wellService.EnforceWellExistingAsync(id);


            var entity = new ProjectWell();

            //list planned well with status
            var wells = await _wellService.ListPlannedAsync(rllcp, true);
            if (wells == null)
            {
                throw new WellNotFoundException();
            }


            IEnumerable<WellProperties> props;
            //recent
            try
            {
                var pp = await this.GetWellRecentlyAsync(rllcp, name, false);
                //var temp = await _wellService.ListPropertiesAsync();
                props = pp.Properties.Where(c => c.ProjectWellId == pp.Id);

            }
            //synce
            catch (ProjectWellNotFoundException)
            {
                props = await _wellService.SyncePropertiesAsync(rllcp, name, id);
            }

            //filter by check box
            props = props.Where(c => c.IsIncludeToCalculated == true);

            //should pattern mapped
            /*
            *
            *
            *
            */

            var hashset = new HashSet<string>(props.Select(c => c.Name));

            entity.CompletedProductiveWell = wells.Where(c => c.Status == WellStatus.COMPLETED.GetDescription()
                                                                            && hashset.ContainSidetrack(c.Name)).Count();


            entity.TotalPlannedWell = await _projectWellService.CountPlannedWellAsync(name);
            entity.ProjectName = name;
            entity.RLLCPReferenceId = rllcp;

            //await Task.Delay(0);
            //throw new NotImplementedException();

            return entity;
        }

        public async Task<ProjectWell> GetProductiveWellAsync(string name, int rllcp)
        {

            var id = Utility.ToUniqeIdentity(name);
            var entity = new ProjectWell();


            IEnumerable<WellProperties> props;
            //recent
            try
            {
                var pp = await this.GetWellRecentlyAsync(rllcp, name, false);
                //var temp = await _wellService.ListPropertiesAsync();
                props = pp.Properties.Where(c => c.ProjectWellId == pp.Id);

            }
            //synce
            catch (ProjectWellNotFoundException)
            {
                props = await _wellService.SyncePropertiesAsync(rllcp, name, id);
            }

            //filter by check box
            props = props.Where(c => c.IsIncludeToCalculated == true);

            decimal plannedAFEDays = 0m;
            decimal productiveAFEDays = 0m;
            decimal plannedAFECost = 0m;
            decimal productiveAFECost = 0m;

            var enti = new List<JobProductive>();

            var jobs = await _jobService.ListProductiveAsync(props.Select(c => c.Name).ToArray());

            //loop get all productiv
            foreach (var p in props)
            {
                try
                {
                    /*JobProductive temp; //= _cachingService.JobProductives[well];
                    if (!_cachingService.JobProductives.TryGetValue(p.Name, out temp))
                    {
                        temp = jobs.FirstOrDefault(c => c.Name == p.Name);
                    }*/

                    var temp = jobs.OrderByDescending(c => c.EndDate).FirstOrDefault(c => c.Name == p.Name);

                    if (temp != null)
                    {
                        //enti.Add(temp);

                        plannedAFEDays = plannedAFEDays + Convert.ToDecimal(temp.PlannedAFEDays);
                        productiveAFEDays = productiveAFEDays + Convert.ToDecimal(temp.ActualAFEDays);

                        plannedAFECost = plannedAFECost + temp.PlannedCostAFE;
                        productiveAFECost = productiveAFECost + temp.ActualCostAFE;
                    }

                }
                catch (JobNotProductiveException)
                { }
            }

            //assigned
            entity.TotalPlannedAFECost = plannedAFECost;
            entity.TotalProductiveAFECost = productiveAFECost;
            entity.TotalPlannedAFEDays = plannedAFEDays;
            entity.TotalProductiveAFEDays = productiveAFEDays;

            entity.ProjectName = name;
            entity.RLLCPReferenceId = rllcp;

            //set dev check value
            entity.Productives = enti;

            //await Task.Delay(0);
            //throw new NotImplementedException();

            return entity;
        }

        private async Task<ProjectWell> GetProductiveCacheAsync(string name, int rllcp, IEnumerable<WellProperties> props)
        {

            var id = Utility.ToUniqeIdentity(name);
            var entity = new ProjectWell();

            decimal plannedAFEDays = 0m;
            decimal productiveAFEDays = 0m;

            decimal plannedAFECost = 0m;
            decimal productiveAFECost = 0m;

            var sw = new Stopwatch();
            sw.Start();

            var enti = new List<JobProductive>();
            var jobs = await _jobService.ListProductiveAsync(props.Select(c => c.Name).ToArray());

            //loop get all productiv
            foreach (var p in props)
            {
                try
                {
                    /*JobProductive temp; //= _cachingService.JobProductives[well];
                    if (!_cachingService.JobProductives.TryGetValue(p.Name, out temp))
                    {
                        temp = jobs.FirstOrDefault(c => c.Name == p.Name);
                    }*/

                    var temp = jobs.OrderByDescending(c => c.EndDate).FirstOrDefault(c => c.Name == p.Name);
                    if (temp != null)
                    {
                        //enti.Add(temp);
                        plannedAFEDays = plannedAFEDays + Convert.ToDecimal(temp.PlannedAFEDays);
                        productiveAFEDays = productiveAFEDays + Convert.ToDecimal(temp.ActualAFEDays);

                        plannedAFECost = plannedAFECost + temp.PlannedCostAFE;
                        productiveAFECost = productiveAFECost + temp.ActualCostAFE;
                    }

                }
                catch (JobNotProductiveException)
                { }
            }

            //assigned
            entity.TotalPlannedAFECost = plannedAFECost;
            entity.TotalProductiveAFECost = productiveAFECost;
            entity.TotalPlannedAFEDays = plannedAFEDays;
            entity.TotalProductiveAFEDays = productiveAFEDays;

            entity.ProjectName = name;
            entity.RLLCPReferenceId = rllcp;

            //set dev check value
            entity.Productives = enti;

            //sw.Stop();
            //Log.Information("GetProductiveWellAsync Elapsed={0} : {1}/{2}", sw.Elapsed, entity.TotalProductiveAFECost, entity.TotalProductiveAFEDays);

            return entity;
        }

        //
        // Summary:
        //     CRUD project well sachema with transaction controll
        //
        // Returns:
        //     Models.Entity.ProjectWell object
        //
        // Type parameters:
        //  
        //      wwww
        //

        public async Task<ProjectWell> BatchCreateAsync(ProjectWell wwww)
        {
            var pid = Utility.ToUniqeIdentity(wwww.ProjectName);
            var project = await this.EnforceProjectExistenceAsync(pid); //new Project() { Name = wwww.ProjectName });

            var entities = new List<WellProperties>();
            //do with transaction
            using (var transaction = _workUnitService.BeginTransaction())
            {
                //create space
                var space = new ProjectSpace() { Id = Guid.NewGuid().ToString(), ProjectId = project.Id, By = httpCurrentUser.Id, Created = Utility.CurrentSEAsiaStandardTime() };
                var sp = await _workUnitService.ProjectSpaces.CreateAsync(space);

                //create wwww
                var www = new ProjectWell() { Key = Guid.NewGuid().ToString(), Rev = Guid.NewGuid().ToString(), Id = Guid.NewGuid().ToString(), ProjectSpaceId = sp.Id, StartDate = Utility.CurrentSEAsiaStandardTime() };
                var sm = await _workUnitService.ProjectWells.CreateAsync(www);

                foreach (var pp in wwww.Properties)
                {
                    //enforc create well
                    var well = await _wellService.EnforceWellCreateAsync(new Well() { Name = pp.Name, ProjectId = project.Id, });

                    //persist group
                    //set value
                    pp.Id = Guid.NewGuid().ToString();
                    pp.Created = Utility.CurrentSEAsiaStandardTime();
                    pp.By = httpCurrentUser.Id;
                    pp.WellId = well.Id;
                    pp.ProjectWellId = sm.Id;

                    entities.Add(pp);
                }


                await _workUnitService.WellProperties.CreateRangeAsync(entities);

                //set value
                sm.Properties = entities;
                sm.ProjectName = project.Name;

                try
                {
                    transaction.Commit();

                    //trakc activity
                    var created = new ProjectActivity(sp.Id, PROJECT_WELL, ActivityAction.SAVED.GetDescription(), httpCurrentUser.Id);
                    var eee = await this.CreateAsync(created);

                    sm.ActivityDate = eee.Date;
                    sm.ActivityType = eee.Action;
                    sm.By = httpCurrentUser.CAI;

                    return sm;
                }
                catch (InvalidOperationException ex)
                {
                    transaction.Rollback();
                    throw new WellPropertiesNotValidException(ex.Message);
                }
            }
        }


        //
        // Summary:
        //     get total of  reserve box with project and well properties setup #
        //
        // Returns:
        //     Models.Entity.ProjectWell object
        //
        // Type parameters:
        //   name:
        //     project name,
        //   rllcp
        //      rllcp project id 
        //

        public async Task<ProjectWell> GetReserveWellAsync(string name, int rllcp)
        {
            var id = Utility.ToUniqeIdentity(name);
            var entity = new ProjectWell();


            IEnumerable<WellProperties> props;
            //recent
            try
            {
                var pp = await this.GetWellRecentlyAsync(rllcp, name, false);
                //var temp = await _wellService.ListPropertiesAsync();
                props = pp.Properties.Where(c => c.ProjectWellId == pp.Id);

            }
            //synce
            catch (ProjectWellNotFoundException)
            {
                props = await _wellService.SyncePropertiesAsync(rllcp, name, id);
            }

            //filter by check box
            props = props.Where(c => c.IsIncludeToCalculated == true);


            decimal planned = 0m;
            decimal drilled = 0m;
            decimal undrilled = 0m;

            //var temp = await _wellService.ListProductiveAsync();

            foreach (var p in props)
            {
                //mapping productive name

                // if (temp != null)
                // {
                //     p.Name = temp.Code;
                // }

                //get stauts
                var sts = await _wellService.GetProductiveStatusAsync(p.Name);

                var reserve = await _wellService.EvaluatedReserveAsync(p.Name, sts.Status);  //sannd
                if (reserve != null)
                {
                    planned = planned + reserve.Planned.Value;
                    drilled = drilled + reserve.Drilled.Value;

                    undrilled = undrilled + reserve.Undrilled.Value;
                }

            }

            //assifgned
            entity.TotalDrilledReserve = drilled;
            entity.TotalPlannedReserve = planned;
            entity.TotalUndrilledReserve = undrilled;

            return entity;
            //await Task.Delay(0);
            // throw new NotImplementedException();
        }

        //
        // Summary:
        //    return the ammout of 4 type of reservre
        //
        // Returns:
        //     Models.Entity.WellReserveParams object
        //
        // Type parameters:
        //   name:
        //     project name,
        //   rllcp
        //      rllcp project id 
        //
        public async Task<IEnumerable<WellReserveParams>> InitialReserveParamsAsync(string name, int rllcp)
        {
            await Task.Delay(0);
            throw new NotImplementedException();
        }



        //
        // Summary:
        //     CRUD project well sachema with transaction controll
        //
        // Returns:
        //     Models.Entity.ProjectDrilled object
        //
        // Type parameters:
        //  
        //      wwww
        //

        public async Task<ProjectDrilled> BatchCreateAsync(ProjectDrilled wwww)
        {

            //deactive old
            if (wwww.Id != null)
            {
                var drilled = await _projectDrilledRepository.GetAsync(wwww.Id.GetValueOrDefault());
                if (drilled == null)
                {
                    throw new ProjectDrilledNotFoundException();
                }

                drilled.Status = RecordStatus.ARCHIVED.GetDescription();
                drilled.FinishDate = Utility.CurrentSEAsiaStandardTime();

                await _projectDrilledRepository.UpdateAsync(drilled);
            }

            //validate attachment
            var pid = Utility.ToUniqeIdentity(wwww.ProjectName);
            var project = await this.EnforceProjectExistenceAsync(pid);

            var entities = new List<WellProperties>();
            //do with transaction
            using (var transaction = _workUnitService.BeginTransaction())
            {
                //create space
                var space = new ProjectSpace() { Id = Guid.NewGuid().ToString(), ProjectId = project.Id, By = httpCurrentUser.Id, Created = Utility.CurrentSEAsiaStandardTime() };
                var sp = await _workUnitService.ProjectSpaces.CreateAsync(space);

                //create wwww
                var www = new ProjectDrilled()
                {
                    Key = Guid.NewGuid().ToString(),
                    Rev = Guid.NewGuid().ToString(),
                    Id = Guid.NewGuid(),
                    ProjectSpaceId = sp.Id,
                    StartDate = Utility.CurrentSEAsiaStandardTime(),

                    Status = RecordStatus.ACTIVE.GetDescription(),

                    AttachmentId = wwww.AttachmentId,
                    TemplateTypeId = wwww.TemplateTypeId,

                    PlannedDPI = wwww.PlannedDPI,
                    ActualDPI = wwww.ActualDPI,

                    Type = wwww.Type
                };


                var sm = await _workUnitService.ProjectDrilleds.CreateAsync(www);

                //set value
                //  sm.Properties = entities;
                sm.ProjectName = project.Name;

                try
                {
                    transaction.Commit();

                    //trakc activity
                    var created = new ProjectActivity(sp.Id, PROJECT_DRILLED, ActivityAction.SAVED.GetDescription(), httpCurrentUser.Id);
                    var eee = await this.CreateAsync(created);

                    sm.ActivityDate = eee.Date;
                    sm.ActivityType = eee.Action;

                    sm.By = httpCurrentUser.CAI;

                    return sm;
                }
                catch (InvalidOperationException ex)
                {
                    transaction.Rollback();
                    throw new WellPropertiesNotValidException(ex.Message);
                }
            }
        }

        //
        public async Task<ProjectDrilled> CreateAsync(ProjectDrilled well)
        {
            //var ids = Utility.ToUniqeIdentity(space.ProjectName);
            var project = await this.EnforceProjectSpaceExistenceAsync(well.ProjectSpaceId);
            if (project == null)
            {
                throw new ProjectNotFoundException();
            }

            well.Rev = Guid.NewGuid().ToString();
            well.Key = Guid.NewGuid().ToString();

            //assigned
            //project.Name = project.Name.ToUpper();
            // project.RLLCPReferenceId = project.RLLCPReferenceId;
            //well.Created = Utility.CurrentSEAsiaStandardTime();
            well.StartDate = Utility.CurrentSEAsiaStandardTime();

            well.Status = RecordStatus.ACTIVE.GetDescription();
            well.By = httpCurrentUser.Id;

            var entity = await _projectDrilledRepository.CreateAsync(well);
            return entity;
        }


        public async Task<ProjectDrilled> UpdateAsync(ProjectDrilled well)
        {
            var updated = await this.EnforceDrilledExistenceAsync(well.Id.GetValueOrDefault());


            var entity = await _projectDrilledRepository.UpdateAsync(well);
            if (entity == null)
            {
                throw new ProjectDrilledNotFoundException();
            }

            return entity;
        }



        public async Task<IEnumerable<ProjectDrilled>> ListDrilledAsync()
        {
            var entity = await _projectDrilledRepository.ListRecentlyAsync();
            var mutate = entity.Select(c => { c.Attachment.Value = null; return c; }).ToList();

            return mutate;
        }


        //
        // Summary:
        //     Returns evaluation DPI / NPI / DPV of project with base 64 file
        //
        // Returns:
        //     Models.Entity.WellReserve object
        //
        // Type parameters:
        //   parameters:
        //     encape params (project, nad rllcp project id)
        //
        public async Task<ProjectEvaluateParams> EvaluateMasterDPIAsync(ProjectEvaluateParams parameters)
        {
            var basePath = _configuration["AppSettings:AssetsFilePath"];

            //new Item(0, "9THBSGYW6M", "Template 1", "MASTER_PROJECT", "Master Project DPI Calculate Template"),
            //new Item(1, "F8R96ZW3L3", "Template 2", "MASTER_PROJECT", "Master Project DPI Calculate Template"),

            var id = Utility.ToUniqeIdentity(parameters.ProjectName);
            var entity = await _projectDrilledRepository.GetRecentlyAsync(id, httpCurrentUser.Id);
            if (entity == null)
            {
                throw new ProjectDrilledNotFoundException();
            }

            //getwellrecently (2)
            //synce well properties

            IEnumerable<WellProperties> props;
            //recent
            try
            {
                var pp = await this.GetWellRecentlyAsync(parameters.RLLCPProjectId, parameters.ProjectName, false);
                //var temp = await _wellService.ListPropertiesAsync();
                props = pp.Properties.Where(c => c.ProjectWellId == pp.Id);

            }
            //synce
            catch (ProjectWellNotFoundException)
            {
                props = await _wellService.SyncePropertiesAsync(parameters.RLLCPProjectId, parameters.ProjectName, id);
            }

            //filter by check box
            props = props.Where(c => c.IsIncludeToCalculated == true);

            //Assign planned DPI
            parameters.PlannedDPI = entity.PlannedDPI;

            //template service
            var template = await _templateService.GetCurrentlyAsync(entity.TemplateTypeId);
            if (template == null)
                throw new InvalidOperationException("DPI template missing. Please check if the template has successfully uploaded.");

            //project setup
            var attribute = await _projectWellService.GetCurrentlyAttributeAsync(parameters.ProjectName);
            if (attribute == null)
            {
                throw new ProjectAttributeNotFoundException();
            }

            //get active monthly price template
            var pt = await _templateService.GetCurrentlyAsync(GLOBAL.MONTHLY_PRICE_TEMPLATE_ID);

            //list all price
            var prices = await _priceService.ListRecentlyAsync(pt.Id);

            //total cost  //getwellrecently (1)
            var drilling = await this.GetProductiveCacheAsync(parameters.ProjectName, parameters.RLLCPProjectId, props);


            //set new total planned logic
            attribute.TotalPlannedWell = await _projectWellService.CountPlannedWellAsync(parameters.ProjectName);
            //var reserves = await this.InitialReserveParamsAsync(parameters.ProjectName, parameters.RLLCPProjectId);

            //riggmove
            var riggmove = await _jobService.GetProductiveCostAsync(parameters.PlatformName);

            //oil gas profile for holdup
            var production = await _productionService.GetCurentlyProductAsync(attribute.ProductionProfileId); //gas oil, holupercantage

            // Write into excel template
            // Initialize handler
            IExcelTemplateHandler handler = new ExcelTemplateHandler();
            IDPITemplateProfile profile = null;
            ProjectDPIResult dpiResult = null;

            //sum by status
            // var id = Utility.ToUniqeIdentity(name);
            //var entities = new List<WellReserveParams>();

            //sum of reserve
            var gasInMMscf = 0m;// drilled.Sum(i => i.GasInMMscf) + undrilleds.Sum(i => i.GasInMMscf);
            var oilInMSTB = 0m; //drilled.Sum(i => i.OilInMSTB) + undrilleds.Sum(i => i.OilInMSTB);
            var condensateInMSTB = 0m; //drilled.Sum(i => i.CondensateInMSTB) + undrilleds.Sum(i => i.CondensateInMSTB);
            var solGasInMMscf = 0m; // drilled.Sum(i => i.SolGasInMMscf) + undrilleds.Sum(i => i.SolGasInMMscf);

            // var tasks = new List<Task>();
            // foreach (var p in props)
            // {
            //     var sts = await _wellService.GetProductiveStatusAsync(p.Name);

            //     tasks.Add(_wellService.DerivatedCompoundReserveAsync(p.Name, sts.Status));
            // }

            // Task.WaitAll(tasks.ToArray());


            foreach (var p in props)
            {

                // Stopwatch sw = new Stopwatch();
                // sw.Start();

                //get stauts
                var sts = await _wellService.GetProductiveStatusAsync(p.Name);
                var reserve = await _wellService.DerivatedCompoundReserveAsync(p.Name, sts.Status);  //sannd

                if (sts.Status == WellStatus.PLANNED.GetDescription())
                {
                    var planned = reserve.DerivedReserves.Where(x => x.Type == ReserveType.PLANNED.GetDescription()).FirstOrDefault();

                    gasInMMscf = gasInMMscf + planned.GasInMMscf.GetValueOrDefault();
                    oilInMSTB = oilInMSTB + planned.OilInMSTB.GetValueOrDefault();
                    condensateInMSTB = condensateInMSTB + planned.CondensateInMSTB.GetValueOrDefault();
                    solGasInMMscf = solGasInMMscf + planned.SolGasInMMscf.GetValueOrDefault();
                }
                else
                {
                    var drilled = reserve.DerivedReserves.Where(x => x.Type == ReserveType.DRILLED.GetDescription()).FirstOrDefault();
                    var undrilled = reserve.DerivedReserves.Where(x => x.Type == ReserveType.UNDRILLED.GetDescription()).FirstOrDefault();

                    gasInMMscf = gasInMMscf + drilled.GasInMMscf.GetValueOrDefault() + undrilled.GasInMMscf.GetValueOrDefault();
                    oilInMSTB = oilInMSTB + drilled.OilInMSTB.GetValueOrDefault() + undrilled.OilInMSTB.GetValueOrDefault();
                    condensateInMSTB = condensateInMSTB + drilled.CondensateInMSTB.GetValueOrDefault() + undrilled.CondensateInMSTB.GetValueOrDefault();
                    solGasInMMscf = solGasInMMscf + drilled.SolGasInMMscf.GetValueOrDefault() + undrilled.SolGasInMMscf.GetValueOrDefault();
                }

                //  sw.Stop();
                //  Log.Information("Loop DerivatedCompoundReserveAsync Elapsed={0}", sw.Elapsed);

            }


            //get undrill
            // var drilled = reserves.Select(c => c.DerivedReserves.Where(x => x.Type == ReserveType.DRILLED.GetDescription()).FirstOrDefault());
            // var undrilleds = reserves.Select(c => c.DerivedReserves.Where(x => x.Type == ReserveType.UNDRILLED.GetDescription()).FirstOrDefault());

            //attach
            var attached = await _attachmentService.GetAsync(entity.AttachmentId);

            var fileBase64Encoded = attached.Value;
            Byte[] bytes = Convert.FromBase64String(fileBase64Encoded);

            using (var stream = new MemoryStream(bytes))
            {
                handler.Load(stream);

                switch (template.TemplateTypeId)
                {
                    case GLOBAL.CTEP_TEMPLATE_TYPE_ID:
                        {
                            var revs = new WellProductiveReserve()
                            {
                                GasInMMscf = gasInMMscf,
                                OilInMSTB = oilInMSTB,
                                CondensateInMSTB = condensateInMSTB,
                                SolGasInMMscf = solGasInMMscf
                            };

                            var ctepProfile = new DPITemplateCTEPProfile();

                            //get end date from the template
                            ctepProfile.AddEndDateReadDefinition();

                            // Load profile
                            handler.Load(ctepProfile);

                            handler.Execute();

                            var endDate = ctepProfile.GetReadEndDate();

                            //clear executed definitions
                            ctepProfile.ClearDefinitions();

                            //construc parama
                            var temp = new WellEvaluateParams()
                            {
                                Project = parameters.ProjectName,
                                ProjectAtrributed = attribute,
                                ProductionProfile = production
                            };

                            //gen profile rate
                            var product = production;

                            //OIL
                            var rr = revs.OilInMSTB.GetValueOrDefault() / attribute.TotalPlannedWell.GetValueOrDefault();
                            var or = new WellReserve() { Value = rr };

                            //GAS
                            var vv = revs.GasInMMscf.GetValueOrDefault() / attribute.TotalPlannedWell.GetValueOrDefault();
                            var gr = new WellReserve() { Value = vv };

                            //get rate
                            var oil = await _productionService.EvaluateProfileRateAsync(product.OilProfile, or);
                            var gas = await _productionService.EvaluateProfileRateAsync(product.GasProfile, gr);


                            //generate profile
                            var productions = await _projectWellService.EstimateMonthlyProductAsync(temp, revs, oil, gas);

                            // Write production profile
                            foreach (var p in productions)
                            {
                                // Write all phases with the same value by month-year
                                if (p.ApplicableModel == "OIL")
                                {
                                    ctepProfile.AddProductionProfileOilDefinition(p.PeriodPlots, endDate);
                                }
                                else if (p.ApplicableModel == "SOLGAS")
                                {
                                    ctepProfile.AddProductionProfileSolutionGasDefinition(p.PeriodPlots, endDate);
                                }
                                else if (p.ApplicableModel == "GAS")
                                {
                                    ctepProfile.AddProductionProfileGasDefinition(p.PeriodPlots, endDate);
                                }
                                else if (p.ApplicableModel == "CONDY")
                                {
                                    ctepProfile.AddProductionProfileCondensateDefinition(p.PeriodPlots, endDate);
                                }
                            }

                            profile = ctepProfile;
                            break;
                        }
                    case GLOBAL.COTL_TEMPLATE_TYPE_ID:
                        {

                            //gas rate
                            var gasreserve = new WellReserve() { Value = gasInMMscf };
                            var gasrate = await _productionService.EvaluateProfileRateAsync(production.GasProfile, gasreserve);
                            //oil
                            var oilreserve = new WellReserve() { Value = Utility.ParseMMSCFtoMMBTU(oilInMSTB) };
                            var oilrate = await _productionService.EvaluateProfileRateAsync(production.OilProfile, oilreserve);

                            decimal zero = (decimal)Math.Pow(10, -12);

                            var cotlProfile = new DPITemplateCOTLProfile();
                            var prodRsv = new COTLProdRSV
                            {
                                NumberOfWells = attribute.TotalPlannedWell,
                                ModelSelection = attribute.ApplicableModelId,
                                OilReserves = oilInMSTB != 0 ? oilInMSTB : zero,
                                SolutionGasReserves = solGasInMMscf != 0 ? solGasInMMscf : zero,
                                GasReserves = gasInMMscf != 0 ? gasInMMscf : zero,
                                CondensateReserves = condensateInMSTB != 0 ? condensateInMSTB : zero,
                                GasOnlineDate = attribute.GasProjectStartDate,
                                GasPercentHold = production.GasProfile?.HoldupPercentage / 100,
                                OilOnlineDate = attribute.OilProjectStartDate,
                                OilPercentHold = production.OilProfile?.HoldupPercentage / 100,
                                InitialGasRate = gasrate.Value,
                                InitialOilRate = oilrate.Value,
                                GasAbandonmentRate = gasrate.AbandonmentRate,
                                OilAbandonmentRate = oilrate.AbandonmentRate,
                            };

                            // Add production rsv
                            cotlProfile.AddProdRSVDefinition(prodRsv);

                            profile = cotlProfile;
                            break;
                        }

                    default:
                        throw new TemplateNotFoundException(template.TemplateTypeId);
                }

                drilling.StartDate = riggmove.StartDate;
                drilling.TotalProductiveAFECost = drilling.TotalProductiveAFECost != null ? drilling.TotalProductiveAFECost / 1000000 : null;
                riggmove.TotalCostCalculate = riggmove.TotalCostCalculate != null ? riggmove.TotalCostCalculate / 1000000 : null;

                // Add drilling cost
                profile.AddDrillingCostDefinition(drilling);

                // Add rig move cost
                profile.AddRigMoveCostDefinition(riggmove);

                // Write price deck
                foreach (var price in prices)
                {
                    profile.AddPriceCaseDefinition(price.Structure, price.HcType, price.Name, price.Prices);
                }

                // Add DPI read profile
                profile.AddDPIReadDefinition();

                // Load profile
                handler.Load(profile);

                // Perform validation
                // This throws an exception when get failed on any cases
                handler.Execute();

                // Get DPI result 
                dpiResult = profile.GetReadDPI();
                parameters.ActualDPI = dpiResult.DPI;
                parameters.NPV = dpiResult.NPV;
                parameters.NPI = dpiResult.INV;

                // //Save result into memory
                using (var memoryStream = new MemoryStream())
                {
                    handler.SaveAs(memoryStream);

                    // Attach excel file in base64 encoded
                    var attachment = new Attachment();
                    attachment.Value = Convert.ToBase64String(memoryStream.ToArray());

                    //for fe savved file
                    attachment.Extension = attached.Extension;
                    attachment.Name = attached.Name;

                    //write file
                    var timestamp = DateTime.Now.ToString("yyyyMMdd_hhmm");

                    //write file
                    if (!Directory.Exists(await _pathFinderService.FindAsync($"{basePath}/projects")))
                        Directory.CreateDirectory(await _pathFinderService.FindAsync($"{basePath}/projects"));

                    var path = await _pathFinderService.FindAsync($"{basePath}/projects/{timestamp}_{parameters.ProjectName}_{Guid.NewGuid().ToString()}{attached.Extension}");

                    try
                    {
                        await File.WriteAllBytesAsync(path, memoryStream.ToArray());
                    }
                    catch (DirectoryNotFoundException)
                    {
                        throw new AttachmentNotValidException(path);
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }

                    //encryptes
                    parameters.Attachment = await _attachmentService.AesEncryptAsync(attachment);
                }
            }

            //for devcheck
            //  parameters._Attribute = attribute;
            //  parameters._Template = template;
            //parameters._CompoundedReserve = reserves;
            //parameters._DrillingCost = drilling;
            //parameters._RiggCost = riggmove;

            //parameters._Attribute = attribute;
            // parameters._CompoundedReserve = reserve;

            // sw.Stop();
            // Log.Information("I/O Processing  Elapsed={0}", sw.Elapsed);

            return parameters;
        }

        //
        // Summary:
        //     Returns a process data of pay summary from TCRS and SURFACE
        //
        // Returns:
        //     Models.Entity.ProjectPayParams object
        //
        // Type parameters:
        //   name:
        //     project name
        //
        public async Task<ProjectPayParams> GetPayAsync(string name, int rllcp)
        {
            var id = Utility.ToUniqeIdentity(name);
            var platform = Utility.ToPlaformIdentity(name);

            //props
            // var props = new List<WellProperties>();
            //recent

            IEnumerable<WellProperties> props;
            //recenta
            try
            {
                var pp = await this.GetWellRecentlyAsync(rllcp, name, false);
                //var temp = await _wellService.ListPropertiesAsync();
                props = pp.Properties.Where(c => c.ProjectWellId == pp.Id);

            }
            //synce
            catch (ProjectWellNotFoundException)
            {
                props = await _wellService.SyncePropertiesAsync(rllcp, name, id);
            }

            //filterand order  by check box
            props = props.Where(c => c.IsIncludeToCalculated == true).OrderBy(c => c.ChartOrder).OrderBy(c => c.Name);

            var plannedwell = props.Count();

            var pays = await _wellService.GetWellPayAsync(props.Select(c => c.Name).ToArray());
            var entity = new ProjectPayParams();


            //should go to service and mappper
            var wells = await _entityService.ListWellPressureAsync(props.Select(c => c.Name).ToArray());
            // var jobs = await _jobService.ListProductiveAsync(props.Select(c => c.Name).ToArray());
            var sands = await _sandService.ListProductiveAsync(props.Select(c => c.Name).ToArray());

            var entities = new List<WellPay>();
            foreach (var p in pays)
            {
                //var hashset = new HashSet<string>(new string[] { p.WellName });

                //Log.Information(p.WellName);
                // var w = new WellPay();   //remove uncheck well
                p.Property = props.FirstOrDefault(c => c.Name == p.WellName); //.FirstOrDefault();
                p.IsTakeRft = wells.Any(c => c.WellName == p.WellName);

                //change name to sidetrack, undrilled, holizon
                //mapping productive name
                /* var temp = await _wellService.GetProductiveAsync(p.WellName);
                if (temp != null)
                {
                    p.WellName = temp.Code;
                }*/

                if (p.Property == null)
                {
                    continue;
                }

                //recebnt
                bool synce = false;
                WellDrilled well = new WellDrilled();
                try
                {
                    well = await _wellService.GetDrilledRecentlyAsync(p.WellName);
                }
                //synce
                catch (WellDrilledNotFoundException)
                {
                    synce = true;
                }

                //synce
                if (synce)
                {

                    try
                    {
                        var temps = await _sandService.InitOpenWorksContactCategoryAsync(sands.Where(c => c.WellName == p.WellName));
                        well.Sands = temps.ToList(); // await _wellService.SynceDrilledAsync(p.WellName, name, platform); //well, project, platform

                    }
                    //synce
                    catch (SandNotFoundException)
                    {
                        //continue;
                    }
                }

                //only P1DN sand

                well.Sands = well.Sands.Where(c => !Utility.EnforceIsContainedAZI(c.OpenWorksContactCategory)).ToList();
                p.ActualTotalPay = well.Sands.Sum(c => (c.NetGasVT + c.NetOilVT)).GetValueOrDefault();

                /* if (p.ActualTotalPay == 0)
                {
                    continue;
                }*/

                p.ActualNewPay = well.Sands.Where(c => c.PayClassification == PayClassification.NEW.GetDescription()).Sum(c => (c.NetGasVT + c.NetOilVT)).GetValueOrDefault();
                p.ActualPDVAPay = well.Sands.Where(c => c.PayClassification == PayClassification.PDVA.GetDescription()).Sum(c => (c.NetGasVT + c.NetOilVT)).GetValueOrDefault();
                p.ActualNewPDVAPay = p.ActualNewPay + p.ActualPDVAPay;

                //in mapper
                // p.PredrilledNewOilPay 
                //p.PredrilledNewGasPay
                //oil
                p.ActualNewOilPay = well.Sands.Where(c => c.PayClassification == PayClassification.NEW.GetDescription() && DRILLED.OIL_CONTACT_CATEGORY.Contains(c.OpenWorksContactCategory))
                                        .Sum(c => (c.NetOilVT)).GetValueOrDefault();
                p.ActualPDVAOilPay = well.Sands.Where(c => c.PayClassification == PayClassification.PDVA.GetDescription() && DRILLED.OIL_CONTACT_CATEGORY.Contains(c.OpenWorksContactCategory))
                                            .Sum(c => (c.NetOilVT)).GetValueOrDefault();

                p.ActualNewPDVAOilPay = p.ActualNewOilPay + p.ActualPDVAOilPay;

                //gas
                p.ActualNewGasPay = well.Sands.Where(c => c.PayClassification == PayClassification.NEW.GetDescription() && DRILLED.GAS_CONTACT_CATEGORY.Contains(c.OpenWorksContactCategory))
                                        .Sum(c => (c.NetGasVT)).GetValueOrDefault();
                p.ActualPDVAGasPay = well.Sands.Where(c => c.PayClassification == PayClassification.PDVA.GetDescription() && DRILLED.GAS_CONTACT_CATEGORY.Contains(c.OpenWorksContactCategory))
                                            .Sum(c => (c.NetGasVT)).GetValueOrDefault();

                p.ActualNewPDVAGasPay = p.ActualNewGasPay + p.ActualPDVAGasPay;

                //skipped in mapper
                // p.UntruncatedNewPay
                //p.TruncatedNewPay

                //  p.ActualOilFraction = (p.ActualNewPDVAOilPay / p.ActualTotalPay) * 100;

                //summerize trend
                entity.UntruncatedNewPayTrend.Add(entity.UntruncatedNewPayTrend.LastOrDefault() + p.SWMUntruncatedNewPay);

                entity.TruncatedNewPayTrend.Add(entity.TruncatedNewPayTrend.LastOrDefault() + p.SWMTruncatedNewPay);
                entity.ActualNewPayTrend.Add(entity.ActualNewPayTrend.LastOrDefault() + p.ActualNewPay);

                entity.ActualPDVATrend.Add(entity.ActualPDVATrend.LastOrDefault() + p.ActualPDVAPay);
                entity.TotalNewPayPDVATrend.Add(entity.TotalNewPayPDVATrend.LastOrDefault() + p.ActualNewPDVAPay);



                entities.Add(p);
            }

            //cumulativve pay
            //PredrilledUntruncateNewPay = entity.PredrilledTruncatedNewPayFt,
            // PredrilledTruncateNewPay = entity.PredrilledUntruncatedNewPayFt,

            var totalpay = entities.Sum(c => c.ActualNewPDVAPay);
            var trcpay = entities.Sum(c => c.PredrilledTruncateNewPay);
            var untrcpay = entities.Sum(c => c.PredrilledUntruncateNewPay);

            entity.PredrilledUntruncateNewPay = untrcpay;
            entity.PredrilledTruncateNewPay = trcpay;

            if (trcpay > 0) entity.TruncatedNewPayDiffPercentage = ((totalpay - trcpay) * 100) / trcpay;
            if (untrcpay > 0) entity.UntruncatedNewPayDiffPercentage = ((totalpay - untrcpay) * 100) / untrcpay;

            //summary
            entity.ActualNewOilPay = entities.Sum(c => c.ActualNewOilPay);
            entity.ActualNewGasPay = entities.Sum(c => c.ActualNewGasPay);
            //entity.ActualOilFraction = entities.Sum(c => c.ActualOilFraction) / plannedwell;


            var fraction = entities.Sum(c => c.ActualTotalPay);
            if (fraction > 0) entity.ActualOilFraction = entities.Sum(c => c.ActualNewPDVAOilPay) / fraction * 100;



            entity.ActualNewPDVAPay = totalpay; //entities.Sum(c => c.ActualNewPDVAPay);
            entity.WellPays = entities;

            //setname
            entity.ProjectName = name;
            entity.PlatformName = platform;
            entity.RLLCPProjectId = rllcp;

            return entity;
        }

        //
        // Summary:
        //     Returns a process data of reserve summary from TCRS and SURFACE
        //
        // Returns:
        //     Models.Entity.ProjectPayParams object
        //
        // Type parameters:
        //   name:
        //     project name
        //
        public async Task<ProjectPayParams> GetReserveAsync(string name, int rllcp)
        {
            var id = Utility.ToUniqeIdentity(name);
            var platform = Utility.ToPlaformIdentity(name);

            //props
            // var props = new List<WellProperties>();
            //recent

            IEnumerable<WellProperties> props;
            //recenta
            try
            {
                var pp = await this.GetWellRecentlyAsync(rllcp, name, false);
                //var temp = await _wellService.ListPropertiesAsync();
                props = pp.Properties.Where(c => c.ProjectWellId == pp.Id);

            }
            //synce
            catch (ProjectWellNotFoundException)
            {
                props = await _wellService.SyncePropertiesAsync(rllcp, name, id);
            }

            //filterand order  by check box
            props = props.Where(c => c.IsIncludeToCalculated == true).OrderBy(c => c.ChartOrder).OrderBy(c => c.Name);

            var plannedwell = props.Count();

            var pays = await _wellService.GetWellPayAsync(props.Select(c => c.Name).ToArray());
            var entity = new ProjectPayParams();

            //should go to service and mappper
            var wells = await _entityService.ListWellPressureAsync(props.Select(c => c.Name).ToArray());
            // var jobs = await _jobService.ListProductiveAsync(props.Select(c => c.Name).ToArray());
            // var sands = await _sandService.ListProductiveAsync(props.Select(c => c.Name).ToArray());

            var entities = new List<WellPay>();
            foreach (var p in pays)
            {
                //var hashset = new HashSet<string>(new string[] { p.WellName });

                //Log.Information(p.WellName);
                // var w = new WellPay();   //remove uncheck well
                p.Property = props.FirstOrDefault(c => c.Name == p.WellName); //.FirstOrDefault();
                p.IsTakeRft = wells.Any(c => c.WellName == p.WellName);

                // //recebnt
                //bool synce = false;
                WellDrilled well = new WellDrilled();

                try
                {
                    well = await _wellService.GetDrilledRecentlyAsync(p.WellName);
                }
                //synce
                catch (WellDrilledNotFoundException)
                {
                    //default
                    well.Sands = new List<Sand>();
                }

                //synce
                /* if (synce)
                {

                    try
                    {
                        var temps = await _sandService.InitOpenWorksContactCategoryAsync(sands.Where(c => c.WellName == s.Name));
                        well.Sands = temps.ToList(); // await _wellService.SynceDrilledAsync(p.WellName, name, platform); //well, project, platform

                    }
                    //synce
                    catch (SandNotFoundException)
                    {
                        //continue;
                    }

                }*/

                /////////////////////////////////////////////////////////////////////////

                //pay reserve
                {
                    p.ActualGasInBCF = Utility.ParseMMBTUToMMSCF(well.Sands.Sum(c => (c.FreeGasP1DNWithBC + c.SolutionGasP1DNWithBC)).GetValueOrDefault());
                    p.ActualLiquidInMBBL = well.Sands.Sum(c => (c.OilP1DNWithBC + c.CondensateP1DNWithBC)).GetValueOrDefault();

                    p.ActualReserveInMBOE = Utility.ParseBCFtoMBOE(p.ActualGasInBCF) + p.ActualLiquidInMBBL;


                    var gaspay = Utility.ParseMMBTUToMMSCF(well.Sands.Where(c => c.PayClassification == PayClassification.NEW.GetDescription())
                                                         .Sum(c => (c.FreeGasP1DNWithBC + c.SolutionGasP1DNWithBC)).GetValueOrDefault());

                    var oilpay = well.Sands.Where(c => c.PayClassification == PayClassification.NEW.GetDescription())
                                                         .Sum(c => (c.OilP1DNWithBC + c.CondensateP1DNWithBC)).GetValueOrDefault();


                    p.ActualReserveNewPayInMBOE = Utility.ParseBCFtoMBOE(gaspay) + oilpay;


                    var gaspdva = Utility.ParseMMBTUToMMSCF(well.Sands.Where(c => c.PayClassification == PayClassification.PDVA.GetDescription())
                                                         .Sum(c => (c.FreeGasP1DNWithBC + c.SolutionGasP1DNWithBC)).GetValueOrDefault());

                    var oilpdva = well.Sands.Where(c => c.PayClassification == PayClassification.PDVA.GetDescription())
                                .Sum(c => (c.OilP1DNWithBC + c.CondensateP1DNWithBC)).GetValueOrDefault();

                    p.ActualReservePDVAInMBOE = Utility.ParseBCFtoMBOE(gaspdva) + oilpdva;

                    p.TotalReserveNewPayPDVAInMBOE = p.ActualReserveNewPayInMBOE + p.ActualReservePDVAInMBOE;


                    //summerize untrunc trend
                    entity.UntruncatedGasTrend.Add(entity.UntruncatedGasTrend.LastOrDefault() + p.UntruncatedGasInBCF);
                    entity.UntruncatedLiquidTrend.Add(entity.UntruncatedLiquidTrend.LastOrDefault() + p.UntruncatedLiquidInMBBL);
                    entity.UntruncatedReserveTrend.Add(entity.UntruncatedReserveTrend.LastOrDefault() + p.UntruncatedReserveMBOE);

                    //trunc
                    entity.TruncatedGasTrend.Add(entity.TruncatedGasTrend.LastOrDefault() + p.TruncatedGasInBCF);
                    entity.TruncatedLiquidTrend.Add(entity.TruncatedLiquidTrend.LastOrDefault() + p.TruncatedLiquidInMBBL);
                    entity.TruncatedReserveTrend.Add(entity.TruncatedReserveTrend.LastOrDefault() + p.TruncatedReserveMBOE);


                    //pay
                    entity.ActualReserveNewPayTrend.Add(entity.ActualReserveNewPayTrend.LastOrDefault() + p.ActualReserveNewPayInMBOE);
                    entity.ActualReservePDVATrend.Add(entity.ActualReservePDVATrend.LastOrDefault() + p.ActualReservePDVAInMBOE);

                    entity.TotalReserveNewPayPDVATrend.Add(entity.TotalReserveNewPayPDVATrend.LastOrDefault() + p.TotalReserveNewPayPDVAInMBOE);
                    entity.ActualReserveTrend.Add(entity.ActualReserveTrend.LastOrDefault() + p.ActualReserveInMBOE);

                    entity.ActualGasTrend.Add(entity.ActualGasTrend.LastOrDefault() + p.ActualGasInBCF);
                    entity.ActualLiquidTrend.Add(entity.ActualLiquidTrend.LastOrDefault() + p.ActualLiquidInMBBL);

                }


                entities.Add(p);
            }

            //cumulativve reserve
            {
                var unt = entity.UntruncatedReserveTrend.LastOrDefault();
                if (unt > 0) entity.UntruncatedReserveDiffPercentage = ((entity.ActualReserveTrend.LastOrDefault() - unt) * 100) / unt;

                var t = entity.TruncatedReserveTrend.LastOrDefault();
                if (t > 0) entity.TruncatedReserveDiffPercentage = ((entity.ActualReserveTrend.LastOrDefault() - t) * 100) / t;

            }


            entity.WellPays = entities;

            //setname
            entity.ProjectName = name;
            entity.PlatformName = platform;
            entity.RLLCPProjectId = rllcp;

            return entity;
        }




        //
        // Summary:
        //     Returns a process data of rigg summary from TCRS and SURFACE
        //
        // Returns:
        //     Models.Entity.ProjectPayParams object
        //
        // Type parameters:
        //   name:
        //     project name
        //
        public async Task<ProjectPayParams> GetRiggAsync(string name, int rllcp)
        {
            var id = Utility.ToUniqeIdentity(name);
            var platform = Utility.ToPlaformIdentity(name);

            //props
            // var props = new List<WellProperties>();
            //recent

            IEnumerable<WellProperties> props;
            //recenta
            try
            {
                var pp = await this.GetWellRecentlyAsync(rllcp, name, false);
                //var temp = await _wellService.ListPropertiesAsync();
                props = pp.Properties.Where(c => c.ProjectWellId == pp.Id);

            }
            //synce
            catch (ProjectWellNotFoundException)
            {
                props = await _wellService.SyncePropertiesAsync(rllcp, name, id);
            }

            //filterand order  by check box
            props = props.Where(c => c.IsIncludeToCalculated == true).OrderBy(c => c.ChartOrder).OrderBy(c => c.Name);

            var plannedwell = props.Count();

            var pays = await _wellService.GetWellPayAsync(props.Select(c => c.Name).ToArray());
            var entity = new ProjectPayParams();

            //should go to service and mappper
            var wells = await _entityService.ListWellPressureAsync(props.Select(c => c.Name).ToArray());
            var jobs = await _jobService.ListProductiveAsync(props.Select(c => c.Name).ToArray());
            //  var sands = await _sandService.ListProductiveAsync(props.Select(c => c.Name).ToArray());

            var entities = new List<WellPay>();
            foreach (var p in pays)
            {
                //var hashset = new HashSet<string>(new string[] { p.WellName });

                //Log.Information(p.WellName);
                // var w = new WellPay();   //remove uncheck well
                p.Property = props.FirstOrDefault(c => c.Name == p.WellName); //.FirstOrDefault();
                p.IsTakeRft = wells.Any(c => c.WellName == p.WellName);

                if (p.Property == null)
                {
                    continue;
                }

                //recebnt
                // bool synce = false;
                WellDrilled well = new WellDrilled();
                try
                {
                    well = await _wellService.GetDrilledRecentlyAsync(p.WellName);
                }
                //synce
                catch (WellDrilledNotFoundException)
                {
                    //default
                    well.Sands = new List<Sand>();
                }

                //synce
                /* if (synce)
                {
                    try
                    {
                        var temps = await _sandService.InitOpenWorksContactCategoryAsync(sands.Where(c => c.WellName == p.WellName));
                        well.Sands = temps.ToList(); // await _wellService.SynceDrilledAsync(p.WellName, name, platform); //well, project, platform

                    }
                    //synce
                    catch (SandNotFoundException)
                    {
                        //continue;
                    }
                }*/

                //reserve
                p.ActualGasInBCF = Utility.ParseMMBTUToMMSCF(well.Sands.Sum(c => (c.FreeGasP1DNWithBC + c.SolutionGasP1DNWithBC)).GetValueOrDefault());
                p.ActualLiquidInMBBL = well.Sands.Sum(c => (c.OilP1DNWithBC + c.CondensateP1DNWithBC)).GetValueOrDefault();

                p.ActualReserveInMBOE = Utility.ParseBCFtoMBOE(p.ActualGasInBCF) + p.ActualLiquidInMBBL;

                //rigg
                {
                    var job = jobs.OrderByDescending(c => c.EndDate).FirstOrDefault(c => c.Name == p.WellName); ;//await _jobService.GetProductiveAsync(p.WellName);
                    if (job != null)
                    {

                        p.AFEDays = job.PlannedAFEDays;
                        p.ActualAFEDays = job.ActualAFEDays;

                        // p.AFEDaysWell = p.AFEDays / plannedwell;
                        // p.ActualAFEDaysWell = p.ActualAFEDays / plannedwell;

                        if (p.AFEDays > 0) p.PredrilledRatioInMBOERD = p.TruncatedReserveMBOE / p.AFEDays;
                        if (p.ActualAFEDays > 0) p.ActualRatioInMBOERD = p.ActualReserveInMBOE / p.ActualAFEDays;   // how to ???
                    }

                }

                entities.Add(p);
            }

            //cumulativve rigg
            {
                var actual = entities.Sum(c => c.ActualAFEDays);
                var planned = entities.Sum(c => c.AFEDays);

                var res = entities.Sum(c => c.ActualReserveInMBOE);

                if (planned > 0) entity.AFEDayPredictDiffPercentage = ((actual - planned) * 100) / planned;

                //summary
                entity.ActualAFEDays = entities.Sum(c => c.ActualAFEDays);
                entity.AFEDays = entities.Sum(c => c.AFEDays);


                if (plannedwell > 0) entity.ActualAFEDaysWell = entity.ActualAFEDays / plannedwell;


                entity.ActualRatioInMBOERD = entities.Sum(c => c.ActualRatioInMBOERD);
                if (entity.ActualAFEDays > 0) entity.RiggEfficiencyInMBOERD = res / entity.ActualAFEDays;
            }

            entity.WellPays = entities;

            //setname
            entity.ProjectName = name;
            entity.PlatformName = platform;
            entity.RLLCPProjectId = rllcp;

            return entity;
        }


        public async Task<bool> ValidateMasterDPITemplateAsync(Attachment attachment)
        {
            //var masterProjectTypes = GlobalConstants.ADMIN_TEMPLATE_LIST.Where(x => x.Type == "MASTER_PROJECT");
            //await Task.Delay(0);
            //set value
            switch (attachment.TemplateTypeId)
            {

                case GLOBAL.CTEP_TEMPLATE_TYPE_ID:
                    {
                        var profile = new DPITemplateCTEPProfile();
                        profile.AddAdminPageValidate();

                        await this.EnforceValidateDPITemplateAsync(attachment, profile);
                        return true;
                    }
                //break;


                case GLOBAL.COTL_TEMPLATE_TYPE_ID:
                    {
                        var profile = new DPITemplateCOTLProfile();
                        profile.AddAdminPageValidate();

                        await this.EnforceValidateDPITemplateAsync(attachment, profile);
                        return true;
                    }
                // break;

                default:
                    throw new TemplateNotValidException();
                    //break;
            }


        }


        // Project Setup
        public async Task<bool> ValidateMasterDPIAsync(Attachment attachment)
        {
            //var masterProjectTypes = GlobalConstants.ADMIN_TEMPLATE_LIST.Where(x => x.Type == "MASTER_PROJECT");
            await Task.Delay(0);
            //set value
            switch (attachment.TemplateTypeId)
            {

                case GLOBAL.CTEP_TEMPLATE_TYPE_ID:
                    {
                        var profile = new DPITemplateCTEPProfile();
                        profile.AddAdminPageValidate();
                        profile.AddProjectSetUpValidate();

                        await this.EnforceValidateDPITemplateAsync(attachment, profile);
                        return true;
                    }
                //break;


                case GLOBAL.COTL_TEMPLATE_TYPE_ID:
                    {
                        var profile = new DPITemplateCOTLProfile();
                        profile.AddAdminPageValidate();
                        profile.AddProjectSetUpValidate();

                        await this.EnforceValidateDPITemplateAsync(attachment, profile);
                        return true;
                    }
                //break;

                default:
                    throw new TemplateNotValidException();
                    //break;
            }

        }


        // Validate Template
        private async Task EnforceValidateDPITemplateAsync(Attachment attachment, IExcelProfile profile)
        {
            await Task.Delay(0);
            if (attachment == null || attachment?.Value == null || attachment?.Value?.Length == 0)
                throw new AttachmentNotValidException("The attached file is missing or failed on upload.");

            if (profile == null)
                throw new ArgumentNullException("Profile hasn't been loaded or failed on loading.");

            var fileBase64Encoded = attachment.Value;
            Byte[] bytes = Convert.FromBase64String(fileBase64Encoded);

            using (var stream = new MemoryStream(bytes))
            {
                var handler = new ExcelTemplateHandler();

                // Load profile
                handler.Load(profile, stream);

                // Perform validation
                // This throws an exception when get failed on any cases
                handler.Execute();
            }
        }

        //  #endregion

        public async Task<ProjectAuthorize> EnforceProjectAuthorizeExistenceAsync(Guid id)
        {
            var act = await _projectAuthorizeRepository.GetAsync(id);

            if (act == null)
            {
                throw new ProjectAuthorizeNotFoundException(); //(id.ToString());
            }

            return act;
        }


        //
        // Summary:
        //     Return the list of authorize role/project  if token is valid
        //
        // Returns:
        //     User object
        //
        // Type parameters:
        //   token:
        //      azure AD token
        //
        public async Task<User> AuthorizeAsync(Token token)
        {

            var accessToken = new JwtSecurityToken(jwtEncodedString: token.AccessToken);
            string id = accessToken.Claims.First(c => c.Type == "sid").Value;

            //validate date
            var effect = accessToken.ValidFrom;
            var expired = accessToken.ValidTo;
            var current = Utility.CurrentSEAsiaStandardTime();


            if (current < effect && current <= expired)
            {
                throw new InvalidTokenException();
            }

            //var id = httpCurrentUser.Id;

            //id = "thanyadol.ch@chevron.com";
            //checkuser
            var entity = await _userService.ListAsync();
            var us = entity.Where(c => c.Id == id).FirstOrDefault();
            if (us == null)
            {
                throw new UserNotFoundException();
            }

            //chjeck autorize
            var authens = await _userService.ListAuthenAsync();
            authens = authens.Where(c => c.Id == us.Id && c.Authen.ExpiredDate >= Utility.CurrentSEAsiaStandardTime());
            if (!authens.Any())
            {
                throw new UserAuthenNotFoundException();
            }

            //check role authen
            //  var entities = new List<RoleAuthorize>();_
            // var authorize = await _projectAuthorizeRepository.ListRecentlyAsync();
            // authorize = authorize.Where(c => c.UserId == id);
            // if (!authorize.Any())
            // {
            //     throw new RoleNotApiNotFoundException()AUTHORIZE");
            // }

            //list page role
            /* var entities = await this.ListAsync();
            //role page
            var hashset = new HashSet<string>(authorize.Select(c => c.ProjectId).ToArray());
            entities = entities.Where(c => hashset.Contains(c.Id));
            if (!entities.Any())
            {
                throw new RoleNotFoundException();
            }*/

            //us.Projects = authorize;


            return us;
        }


        public async Task<IEnumerable<Project>> ListAuthorizeAsync()
        {
            return await _projectRepository.ListAuthorizeAsync();
        }



        //
        // Summary:
        //     merge the RLLCP project with SURFACE list project
        //
        // Returns:
        //
        //   list of  Models.Entity.Project object
        //
        //


        public async Task<IEnumerable<Project>> ListResponsibilityAsync()
        {
            var entities = await _projectRepository.ListAuthorizeAsync();
            var locations = await _projectLocationRepository.ListRecentlyAsync();

            var synces = await this.ListProductiveAsync();

            //union
            // entities = entities.Union(synces);

            var result = new List<Project>();

            //set value
            foreach (var u in entities)
            {
                u.CurrentLocation = locations.Where(c => c.ProjectId == u.Id).FirstOrDefault();

                var pp = synces.Where(c => c.Name == u.Name).FirstOrDefault();
                if (pp != null)
                {
                    u.Status = RecordStatus.ACTIVE.GetDescription();

                    //swap value
                    u.Name = pp.Name;
                    //u.Name = pp.RLLCPReferenceId;
                    u.RLLCPReferenceId = pp.RLLCPReferenceId;
                }
                else
                {
                    u.Status = RecordStatus.ARCHIVED.GetDescription();
                }

                u.IsPersistedSURFACE = true;
                result.Add(u);
            }


            //set value
            foreach (var u in synces)
            {
                var pp = entities.Where(c => c.Name == u.Name).FirstOrDefault();
                if (pp != null)
                {
                    u.CurrentLocation = locations.Where(c => c.ProjectId == pp.Id).FirstOrDefault();
                    u.IsPersistedSURFACE = true;
                }
                else
                {
                    //add id fr fe
                    u.Id = Utility.ToUniqeIdentity(u.Name);

                    u.IsPersistedSURFACE = false;
                    u.Status = RecordStatus.ACTIVE.GetDescription();


                    //for client react error if null
                    //u.CurrentLocation = new ProjectLocation() { RLLCPProjectId = u.RLLCPReferenceId.GetValueOrDefault(), ProjectName = u.Name };
                    u.ProjectAuthorizes = new ProjectAuthorize[] { };

                    result.Add(u);
                }
            }

            return result;
        }

        public async Task<IEnumerable<Project>> ListLocationAsync()
        {
            return await _projectRepository.ListLocationAsync();
        }


        //location

        public async Task<IEnumerable<ProjectLocation>> ListRecentlyLocationAsync()
        {
            var entity = await _projectLocationRepository.ListRecentlyAsync();
            entity.Select(c =>
            {
                c.LocationName = GLOBAL.PROJECT_LOCATION.Where(x => x.Id == c.LocationId).FirstOrDefault().Value; return c;
            }).ToList();

            return entity;
        }


        public async Task<ProjectLocation> CreateAsync(ProjectLocation location)
        {
            //create new wtf sith attribute
            var enforce = await this
                 .EnforceProjectCreateAsync(new Project()
                 {
                     RLLCPReferenceId = location.RLLCPProjectId == 0 ? location.RLLCReferenceId : location.RLLCPProjectId,
                     Name = string.IsNullOrEmpty(location.ProjectName) ? location.Name : location.ProjectName
                 });

            //deactive old
            if (location.Id != Guid.Empty)
            {
                var ll = await _projectLocationRepository.GetAsync(location.Id);
                if (ll == null)
                {
                    throw new ProjectLocationNotFoundException();
                }

                ll.Status = RecordStatus.ARCHIVED.GetDescription();
                //drilled.FinishDate = Utility.CurrentSEAsiaStandardTime();

                await _projectLocationRepository.UpdateAsync(ll);
            }


            location.Id = Guid.NewGuid();
            location.ProjectId = enforce.Id;

            //assigned
            location.By = httpCurrentUser.Id;
            location.Status = RecordStatus.ACTIVE.GetDescription();

            location.Date = Utility.CurrentSEAsiaStandardTime();
            //well.By = httpCurrentUser.Id;

            var entity = await _projectLocationRepository.CreateAsync(location);
            if (entity == null)
            {
                throw new ProjectLocationNotFoundException();
            }

            return entity;

        }

    }

    public class ProjectWellService : IProjectWellService
    {
        // private readonly string ACTIVE = "ACTIVE";

        private readonly IProjectAttributeRepository _projectAttributeRepository;
        private readonly IProjectWellRepository _projectWellRepository;
        // private readonly IProjectActivityRepository _projectActivityRepository;

        private readonly IProjectRepository _projectRepository;

        private readonly IProjectDrilledRepository _projectDrilledRepository;
        private readonly IProductionService _productionService;

        private readonly IWellPropertiesRepository _wellRepository;
        private readonly IUserService _userService;
        private readonly User httpCurrentUser;

        private readonly IHttpService _httpService;


        private readonly IAttachmentService _attachmentService;

        public ProjectWellService(IProjectAttributeRepository projectAttributeRepository, IProjectActivityRepository projectActivityRepository,
                IProjectSpaceRepository projectSpaceRepository, IProjectWellRepository projectSummaryRepository,
                IProjectRepository projectRepository, IUserService userService, IProjectWellRepository projectWellRepository, IWellPropertiesRepository wellRepository,
                IProductionService productionService, IProjectDrilledRepository projectDrilledRepository, IHttpService httpService,
                IAttachmentService attachmentService)
        {
            _projectRepository = projectRepository ?? throw new ArgumentNullException(nameof(projectRepository));
            _projectAttributeRepository = projectAttributeRepository ?? throw new ArgumentNullException(nameof(projectAttributeRepository));
            _projectWellRepository = projectWellRepository ?? throw new ArgumentNullException(nameof(projectWellRepository));
            _projectDrilledRepository = projectDrilledRepository ?? throw new ArgumentNullException(nameof(projectDrilledRepository));


            _productionService = productionService ?? throw new ArgumentNullException(nameof(productionService));


            _attachmentService = attachmentService ?? throw new ArgumentNullException(nameof(attachmentService));


            _wellRepository = wellRepository ?? throw new ArgumentNullException(nameof(wellRepository));
            _userService = userService ?? throw new ArgumentNullException(nameof(userService));
            _httpService = httpService ?? throw new ArgumentNullException(nameof(httpService));


            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();


            httpCurrentUser = _httpService.GetHttpCurrentUserAsync().Result;
        }


        //
        // Summary:
        //     Returns currently project atribute for used
        //
        // Returns:
        //     Models.Entity.ProjectAttribute object
        //
        // Type parameters:
        //   name :  
        //      project name
        //
        public async Task<ProjectAttribute> GetCurrentlyAttributeAsync(string name)
        {
            //  await this.EnforceProjectAttributeExistenceAsync(id);
            var entity = await _projectAttributeRepository.ListAsync();
            var id = Utility.ToUniqeIdentity(name);

            var query = entity.Where(c => c.ProjectId == id && c.Status == RecordStatus.ACTIVE.GetDescription())
                                                    .OrderByDescending(c => c.StartDate).FirstOrDefault();
            if (query == null)
            {
                throw new ProjectAttributeNotFoundException();
            }

            //new logic default well number
            query.TotalPlannedWell = await this.CountPlannedWellAsync(name);

            //swap production profile id
            try
            {
                var profile = await _productionService.GetCurentlyProductAsync(query.ProductionProfileId);
                query.ProductionProfileId = profile.Id;
            }
            catch (ProductionNotFoundException) { };

            try
            {
                var temp = await _userService.GetAsync(query.By);
                query.By = temp.CAI;
            }
            catch (Exception) { }

            query.ProjectName = name;

            return query;
        }

        //
        // Summary:
        //     retrun the number  well of  RLLCP
        //
        // Returns:
        //
        //   int
        //
        // Type parameters:
        //   name:
        //    project name
        //
        public async Task<int> CountPlannedWellAsync(string name) //, string id)
        {
            int count = 0;

            var id = Utility.ToUniqeIdentity(name);

            var pp = await _projectWellRepository.GetRecentlyAsync(id, httpCurrentUser.Id);
            if (pp == null)
            {
                //throw new ProjectNotApiNotFoundException()SUMMARY");
                count = await this.GetDefaultPlannedWellAsync(name);
            }
            else
            {
                //joine with well properties
                var props = await _wellRepository.ListAsync();
                count = props.Where(c => c.ProjectWellId == pp.Id && c.IsIncludeToCalculated == true).Count();
            }

            return count;
        }

        //
        // Summary:
        //     retrun the number  well from Project SUMMARY or default from project name
        //
        // Returns:
        //
        //   int
        //
        // Type parameters:
        //   nanme:
        //      project name
        //
        public async Task<int> GetDefaultPlannedWellAsync(string name)
        {
            await Task.Delay(0);

            int count = 0;
            try
            {
                string resultString = Regex.Match(name, @"\d+").Value;
                count = Int32.Parse(resultString);
            }
            catch (FormatException)
            {
                throw new ProjectNotValidException();
            }

            return count;
        }


        //
        // Summary:
        //     retrun the recently by project name, RLLCP project id
        //
        // Returns:
        //
        //   ProjectDrilled object
        //
        // Type parameters:
        //  rllcp
        //      rllcp project id
        //   nanme:
        //      project name
        //
        //
        public async Task<ProjectDrilled> GetDrilledRecentlyAsync(string name)
        {
            var id = Utility.ToUniqeIdentity(name);
            //var well = await _wellService.EnforceWellExistingAsync(id);

            var entity = await _projectDrilledRepository.GetRecentlyAsync(id, httpCurrentUser.Id);
            if (entity == null)
            {
                throw new ProjectDrilledNotFoundException();
            }

            //get recet activity


            //attachment id
            var attach = await _attachmentService.GetAsync(entity.AttachmentId);
            if (attach != null)
            {
                entity.AttachmentName = attach.Name;
            }


            //get publisher
            if (entity.By == httpCurrentUser.Id)
            {
                entity.IsPublisher = true;
            }

            //get user cai
            var user = await _userService.GetAsync(entity.By);
            entity.By = user == null ? entity.By : user.CAI;

            // entity.By = user == null ? entity.By :  user.CAI;

            return entity;
        }



        //
        // Summary:
        //     Returns evaluation DPI / NPI / DPV
        //
        // Returns:
        //     Models.Entity.WellReserve object
        //
        // Type parameters:
        //   well:
        //     wellname
        //   project :  
        //      project name
        //   platform :  
        //      platform name
        //
        public async Task<IEnumerable<ProductionProfileParams>> EstimateMonthlyProductAsync(WellEvaluateParams p, WellProductiveReserve revs, ProductionProfile oil, ProductionProfile gas)
        {
            var entities = new List<ProductionProfileParams>();

            //await Task.Delay(0);
            int currentYear = Utility.CurrentSEAsiaStandardTime().Year;
            // var reserves = await this.InitialReserveParamsAsync(p.Project, p.RLLCPProjectId);


            //project setup
            var attribute = p.ProjectAtrributed;
            if (attribute == null)
            {
                throw new ProjectAttributeNotFoundException();
            }

            //production rate //get by attribute id
            var product = p.ProductionProfile; //await _productionService.GetCurentlyProductAsync(attribute.ProductionProfileId);
            if (product == null)
            {
                throw new ProductionNotFoundException();
            }

            //attribute.ApplicableModelId = ApplicableModel.SEPARATE.GetDescription();

            //select way
            if (attribute.ApplicableModelId == ApplicableModel.SEPARATE.GetDescription())  //SEPARATE MODEL
            {

                var parameters = new ProductionProfileParams()
                {
                    //for dec check
                    UndrilledReserve = revs,

                    SelectedAttribute = attribute,
                    ApplicableModel = "OIL",
                    PeriodType = "MONTHLY",
                    CurrentDay = 1,
                    SelectedStartDate = attribute.OilProjectStartDate.GetValueOrDefault(),
                };

                //GOR
                if (revs.OilInMSTB > 0)
                {
                    var GOR = revs.SolGasInMMscf.GetValueOrDefault() / Utility.ParseMBOEToBOE(revs.OilInMSTB.GetValueOrDefault());


                    //transform to project level
                    //OIL
                    //var rr = revs.OilInMSTB.GetValueOrDefault() / attribute.TotalPlannedWell.GetValueOrDefault();
                    //parameters.Reserve = new WellReserve() { Value = Utility.ParseMMSCFtoMMBTU(rr) };

                    //get rate
                    var rate = oil; //await _productionService.EvaluateProfileRateAsync(product.OilProfile, parameters.Reserve);

                    //check compatibility
                    if (rate.Value == null)
                    {
                        throw new ProductionNotFoundException();
                    }

                    //transform to project level
                    rate.Value = rate.Value * attribute.TotalPlannedWell.GetValueOrDefault();
                    rate.AbandonmentRate = rate.AbandonmentRate * attribute.TotalPlannedWell.GetValueOrDefault();

                    parameters.PickedProfileRate = rate;
                    var estimate = await _productionService.EstimateRemainProductionAsync(parameters);

                    //sum
                    parameters.PeriodPlots = estimate.Plots.GroupBy(r => new { r.CurrentDate.Value.Year, r.CurrentDate.Value.Month })
                                            .Select(g => new ProductionVolumn()
                                            {
                                                Year = g.Key.Year,
                                                Month = g.Key.Month,
                                                TotalValue = g.Sum(c => c.TotalValue),
                                                CurrentDate = new DateTime(g.Key.Year, g.Key.Month, 1, 0, 0, 0)

                                            }).ToList();

                    entities.Add(parameters);

                    //GOR, CGR

                    //oil -> SolGAS (oil * GOR)
                    //assigned platofirm
                    var mutate = parameters.DeepClone();

                    mutate.ApplicableModel = "SOLGAS";
                    mutate.GOR = GOR;
                    mutate.PeriodPlots = mutate.PeriodPlots.Select(c => { c.TotalValue = c.TotalValue * GOR; return c; }).ToList();

                    entities.Add(mutate);
                }

                //GOR
                if (revs.GasInMMscf > 0)
                {

                    var CGR = Utility.ParseMBOEToBOE(revs.CondensateInMSTB.GetValueOrDefault()) / revs.GasInMMscf.GetValueOrDefault();

                    //reset day
                    attribute.RampUpDay = 0;
                    attribute.ShiftStartDay = 0;

                    //GAS -> Condensate (gas * CGR)   * continue day
                    var __parameters = new ProductionProfileParams()
                    {
                        SelectedAttribute = attribute,
                        ApplicableModel = "GAS",
                        //  CurrentDay = parameters.ContinueDay,
                        PeriodType = "MONTHLY",
                        SelectedStartDate = attribute.OilProjectStartDate.GetValueOrDefault().AddDays(parameters.ContinueDay - 1) //init start day
                    };

                    //__parameters.Reserve = new WellReserve() { Value = revs.GasInMMscf.GetValueOrDefault() };

                    //get rate
                    var __rate = gas; //await _productionService.EvaluateProfileRateAsync(product.GasProfile, __parameters.Reserve);

                    //check compatibility
                    if (__rate.Value == null)
                    {
                        throw new ProductionNotFoundException();
                    }

                    //transform to project level
                    __rate.Value = __rate.Value * attribute.TotalPlannedWell;
                    __rate.AbandonmentRate = __rate.AbandonmentRate * attribute.TotalPlannedWell;

                    __parameters.PickedProfileRate = __rate;

                    var __estimate = await _productionService.EstimateRemainProductionAsync(__parameters);

                    //sum
                    __parameters.PeriodPlots = __estimate.Plots.GroupBy(r => new { r.CurrentDate.Value.Year, r.CurrentDate.Value.Month })
                                            .Select(g => new ProductionVolumn()
                                            {
                                                Year = g.Key.Year,
                                                Month = g.Key.Month,
                                                TotalValue = g.Sum(c => c.TotalValue),
                                                CurrentDate = new DateTime(g.Key.Year, g.Key.Month, 1, 0, 0, 0)

                                            }).ToList();

                    entities.Add(__parameters);

                    //GOR, CGR


                    //oil -> SolGAS (oil * GOR)
                    //assigned platofirm
                    var __mutate = __parameters.DeepClone();

                    __mutate.ApplicableModel = "CONDY";
                    __mutate.CGR = CGR;
                    __mutate.PeriodPlots = __mutate.PeriodPlots.Select(c => { c.TotalValue = c.TotalValue * CGR; return c; }).ToList();

                    entities.Add(__mutate);
                }


            }
            else  //SPECIFIC MODEL
            {
                var parameters = new ProductionProfileParams()
                {
                    //for dec check
                    UndrilledReserve = revs,

                    SelectedAttribute = attribute,
                    //  ApplicableModel = "OIL",
                    PeriodType = "MONTHLY",
                    CurrentDay = 1,
                    //  SelectedStartDate =attribute.ApplicableModelId == ApplicableModel.OIL.GetDescription() == ? attribute.OilProjectStartDate.GetValueOrDefault(),
                };

                var liquid = Utility.ParseMBOEToBOE(revs.OilInMSTB.GetValueOrDefault() + revs.CondensateInMSTB.GetValueOrDefault());
                var gassss = revs.GasInMMscf.GetValueOrDefault() + revs.SolGasInMMscf.GetValueOrDefault();

                var coeff = 0m;

                var rate = new ProductionProfile();
                if (attribute.ApplicableModelId == ApplicableModel.OIL.GetDescription())
                {
                    //GOR
                    decimal GOR = 0;
                    try
                    {
                        GOR = gassss / liquid;
                    }
                    catch (DivideByZeroException) { }

                    parameters.ApplicableModel = ApplicableModel.OIL.GetDescription();
                    parameters.SelectedStartDate = attribute.OilProjectStartDate.GetValueOrDefault();
                    parameters.Reserve = new WellReserve()
                    {
                        Value = liquid
                    };

                    rate = oil; //await _productionService.EvaluateProfileRateAsync(product.OilProfile, parameters.Reserve);

                    //swap
                    coeff = GOR;
                }
                else
                {
                    decimal CGR = 0;
                    try
                    {
                        CGR = liquid / gassss;
                    }
                    catch (DivideByZeroException) { }


                    parameters.ApplicableModel = ApplicableModel.GAS.GetDescription();
                    parameters.SelectedStartDate = attribute.GasProjectStartDate.GetValueOrDefault();

                    parameters.Reserve = new WellReserve()
                    {
                        Value = gassss
                    };

                    //get rate
                    rate = gas; //await _productionService.EvaluateProfileRateAsync(product.GasProfile, parameters.Reserve);

                    coeff = CGR;
                }

                //check compatibility
                if (rate.Value == null)
                {
                    throw new ProductionNotFoundException();
                }

                //transform to project level
                rate.Value = rate.Value * attribute.TotalPlannedWell;
                rate.AbandonmentRate = rate.AbandonmentRate * attribute.TotalPlannedWell;

                parameters.PickedProfileRate = rate;

                var estimate = await _productionService.EstimateRemainProductionAsync(parameters);

                //sum
                parameters.PeriodPlots = estimate.Plots.GroupBy(r => new { r.CurrentDate.Value.Year, r.CurrentDate.Value.Month })
                                            .Select(g => new ProductionVolumn()
                                            {
                                                Year = g.Key.Year,
                                                Month = g.Key.Month,
                                                TotalValue = g.Sum(c => c.TotalValue),
                                                CurrentDate = new DateTime(g.Key.Year, g.Key.Month, 1, 0, 0, 0)

                                            }).ToList();

                entities.Add(parameters);

                //mutata
                var mutate = parameters.DeepClone();

                mutate.ApplicableModel = parameters.ApplicableModel == ApplicableModel.GAS.GetDescription() ? ApplicableModel.OIL.GetDescription()
                                                    : ApplicableModel.GAS.GetDescription();


                //assigned devcheck
                mutate.GOR = coeff;
                mutate.CGR = coeff;

                mutate.PeriodPlots = mutate.PeriodPlots.Select(c => { c.TotalValue = c.TotalValue * coeff; return c; }).ToList();

                entities.Add(mutate);
            }


            return entities;

        }


    }



    public class ProjectUserService : IProjectUserService
    {
        //project status
        protected readonly IProjectRepository _projectRepository;
        protected readonly IProjectAuthorizeRepository _projectAuthorizeRepository;
        //    protected readonly IProjectPageRepository _projectPageRepository;
        private readonly IWorkUnitService _workUnitService;
        protected readonly IHttpService _httpService;

        private readonly User httpCurrentUser;

        //  protected readonly IProjectService _projectRepository;

        public ProjectUserService(IProjectRepository projectRepository, IProjectAuthorizeRepository projectAuthorizeRepository, IWorkUnitService workUnitService,
                IHttpService httpService) //, IProjectPageRepository projectPageRepository)// IProjectService projectService) //, IPathFinderService pathFinderService)
        {
            _projectRepository = projectRepository ?? throw new ArgumentNullException(nameof(projectRepository));
            _projectAuthorizeRepository = projectAuthorizeRepository ?? throw new ArgumentNullException(nameof(projectAuthorizeRepository));

            _httpService = httpService ?? throw new ArgumentNullException(nameof(httpService));

            _workUnitService = workUnitService ?? throw new ArgumentNullException(nameof(workUnitService));
            _httpService = httpService ?? throw new ArgumentNullException(nameof(httpService));


            //_projectPageRepository = projectPageRepository ?? throw new ArgumentNullException(nameof(projectPageRepository));

            httpCurrentUser = _httpService.GetHttpCurrentUserAsync().Result;

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }


        //
        // Summary:
        //     retrun the list of ACTIVE record of user Project TEAM
        //
        // Returns:
        //
        //   list of  Models.Entity.ProjectAuthorize object
        //
        //
        // public async Task<IEnumerable<ProjectAuthorize>> ListRecentlyAuthorizeAsync()
        // {
        //     await Task.Delay(0);
        //     throw new NotImplementedException();
        //     //return  await _projectAuthorizeRepository.ListRecentlyAsync();
        // }

        public async Task<ProjectAuthorize> GetAsync(Guid id)
        {
            return await _projectAuthorizeRepository.GetAsync(id);
        }

        public async Task<IEnumerable<ProjectAuthorize>> ListRecentlyAsync()
        {
            return await _projectAuthorizeRepository.ListRecentlyAsync();
        }

        public async Task<IEnumerable<ProjectAuthorize>> BatchCreateAsynce(IEnumerable<ProjectAuthorize> projects)
        {
            // return await _groupAuthorizeRepository.ListRecentlyAsync();
            var entities = new List<ProjectAuthorize>();
            using (var transaction = _workUnitService.BeginTransaction())
            {
                foreach (var p in projects)
                {
                    //validate
                    var temp = await _projectRepository.GetAsync(p.ProjectId);
                    if (temp == null)
                    {
                        throw new ProjectNotFoundException();
                    }

                    switch (p.EntityState)
                    {
                        case "ADDED":

                            p.Id = Guid.NewGuid();
                            p.By = httpCurrentUser.Id;
                            p.Status = RecordStatus.ACTIVE.GetDescription();
                            p.Date = Utility.CurrentSEAsiaStandardTime();

                            var e = await _workUnitService.ProjectAuthorizes.CreateAsync(p);
                            entities.Add(e);

                            break;

                        case "REMOVED":

                            var ee = await _projectAuthorizeRepository.GetAsync(p.Id);
                            if (ee == null)
                            {
                                throw new ProjectAuthorizeNotFoundException();
                            }

                            //set archived
                            ee.Status = RecordStatus.ARCHIVED.GetDescription();

                            //remove deep shalow
                            // ee.User = null;
                            // ee.Project = null;

                            var c = await _workUnitService.ProjectAuthorizes.UpdateAsync(ee);
                            entities.Add(c);

                            break;
                        default:

                            break;

                    }

                }

                try
                {
                    transaction.Commit();
                    return entities;
                }
                catch (InvalidOperationException ex)
                {
                    transaction.Rollback();
                    throw new ProjectNotFoundException(ex.Message);
                }
            }
        }


    }

}