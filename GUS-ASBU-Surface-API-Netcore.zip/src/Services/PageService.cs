using System; 

using System.Collections.Generic;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using surflex.netcore22.Exceptions;

//logg
using Serilog;
using surflex.netcore22.Helpers;
using System.IO;
using System.Net.Http;
using surflex.netcore22.Extensions;

namespace surflex.netcore22.Services
{
    public interface IPageService
    {
        Task<Page> CreateAsync(Page page);
        Task<Page> UpdateAsync(Page page);
        Task<Page> DeleteAsync(Guid id);

        Task<Page> GetAsync(Guid id);

        Task<IEnumerable<Page>> ListAsync();

        //     Task<IEnumerable<Page>> ListRecentlyAsync();
        Task<Page> EnforcePageExistenceAsync(Guid id);


        Task<PageApi> CreateAsync(PageApi api);
        Task<PageApi> UpdateAsync(PageApi api);
        //   Task<PageApi> DeleteAsync(Guid id);

        Task<PageApi> GetApiAsync(Guid id);

        Task<IEnumerable<PageApi>> ListApiAsync();
        Task<PageApi> EnforceApiExistenceAsync(Guid id);


        // Task<IEnumerable<PageApi>> ListRecentlyApiAsync();
        Task<IEnumerable<Page>> ListRecentlyAsync();
        Task<IEnumerable<Page>> InitAsync(IEnumerable<Page> pages);
    }

    public class PageService : IPageService
    {
        //page status
        protected readonly IPageRepository _pageRepository;
        protected readonly IApiService _apiService;
        protected readonly IWorkUnitService _workUnitService;
        protected readonly IPageApiRepository _pageApiRepository;

        public PageService(IPageRepository pageRepository, IPageApiRepository pageApiRepository, IApiService apiService, IWorkUnitService workUnitService)
        {
            _pageRepository = pageRepository ?? throw new ArgumentNullException(nameof(pageRepository));
            _pageApiRepository = pageApiRepository ?? throw new ArgumentNullException(nameof(pageApiRepository));

            _apiService = apiService ?? throw new ArgumentNullException(nameof(apiService));
            _workUnitService = workUnitService ?? throw new ArgumentNullException(nameof(workUnitService));

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }

        //
        // Summary:
        //     initail a pages and apis
        //
        // Returns:
        //     User object
        //
        // Type parameters:
        //   token:
        //      azure AD token
        //
        public async Task<IEnumerable<Page>> InitAsync(IEnumerable<Page> pages)
        {
            //var url = _configuration["AppSettings:RemoteServiceBaseUrl"];

            var entities = new List<Page>();
            using (var transaction = _workUnitService.BeginTransaction())
            {
                foreach (var u in pages)
                {
                    var entity = await this.EnforcePageExistenceAsync(u.Id);
                    if (entity == null)
                    {
                        throw new PageNotFoundException();
                    }

                    var enti = new List<Api>();
                    foreach (var v in u.APIs)
                    {
                        var temp = v;
                        try
                        {
                            temp = await _apiService.EnforceEndpointExistenceAsync(v.Endpoint);
                        }
                        catch (ApiNotFoundException)
                        {
                            //create
                            v.Id = Guid.NewGuid();
                            //v.Status = RecordStatus.ACTIVE.GetDescription();
                            v.Url = "https://surface-dev.bkkhq.chevrontexaco.net:4433";

                            temp = await _workUnitService.Apis.CreateAsync(v);
                            if (temp == null)
                            {
                                throw new ApiNotFoundException();
                            }
                        }

                        //bundle page and apis
                        var pa = new PageApi()
                        {
                            Id = Guid.NewGuid(),
                            PageId = u.Id,
                            ApiId = temp.Id,

                            Date = Utility.CurrentSEAsiaStandardTime(),
                            IsEnabled = true,
                            By = "1ed0c5d5cd67eb4b3beb7abfc16548813359fb46"  //HRZX
                        };

                        var env = await _workUnitService.PageApis.CreateAsync(pa);
                        if (env == null)
                        {
                            throw new PageNotFoundException();
                        }


                        enti.Add(v);
                    }

                    u.APIs = enti;
                    entities.Add(u);
                }

                try
                {
                    transaction.Commit();
                    return entities;
                }
                catch (InvalidOperationException ex)
                {
                    transaction.Rollback();
                    throw new PriceNotValidException(ex.Message);
                }

            }
        }


        public async Task<Page> CreateAsync(Page page)
        {
            //await this.EnforceWellExistenceAsync(Page.WellId);
            //assigned
            //  page.Id = Guid.NewGuid();
            page.Created = Utility.CurrentSEAsiaStandardTime();

            //page. = httpCurrentUser.Id;

            //page.Description = "hello this is a new page from develper";

            //new rev and key
            //page.Rev = Guid.NewGuid().ToString();
            //page.Key = Guid.NewGuid().ToString();

            //await EnforceClanExistenceAsync(Page.Clan.Name);
            var entity = await _pageRepository.CreateAsync(page);
            if (entity == null)
            {
                throw new PageNotFoundException(page);
            }

            return entity;
        }



        public async Task<Page> UpdateAsync(Page page)
        {
            var updated = await this.EnforcePageExistenceAsync(page.Id);

            //assigned
            //page.Created = Utility.CurrentSEAsiaStandardTime();
            //Page.Page = Page.Page;
            //Page.Status = Page.Status;
            //   page.By = httpCurrentUser.Id;

            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //page.Key = Guid.NewGuid().ToString();

            var entity = await _pageRepository.UpdateAsync(page);
            if (entity == null)
            {
                throw new PageNotFoundException(page);
            }

            return entity;
        }

        public async Task<Page> GetAsync(Guid id)
        {
            //  await this.EnforcePageExistenceAsync(id);

            var entity = await _pageRepository.GetAsync(id);
            return entity;
        }


        public async Task<Page> DeleteAsync(Guid id)
        {
            await this.EnforcePageExistenceAsync(id);

            var entity = await _pageRepository.DeleteAsync(id);
            return entity;
        }

        public async Task<IEnumerable<Page>> ListAsync()
        {
            return await _pageRepository.ListAsync();
        }

        public async Task<IEnumerable<Page>> ListRecentlyAsync()
        {
            return await _pageRepository.ListRecentlyAsync();
        }

        /* public async Task<IEnumerable<Page>> ListRecentlyAsync()
        {
            return await _pageRepository.ListRecentlyAsync();
        }*/


        public async Task<Page> EnforcePageExistenceAsync(Guid id)
        {
            var act = await _pageRepository.GetAsync(id);

            if (act == null)
            {
                throw new PageNotFoundException(id.ToString());
            }

            return act;
        }

        //api

        public async Task<PageApi> CreateAsync(PageApi pageApi)
        {
            //await this.EnforceWellExistenceAsync(PageApi.WellId);
            //assigned
            pageApi.Id = Guid.NewGuid();
            pageApi.Date = Utility.CurrentSEAsiaStandardTime();

            //pageApi. = httpCurrentUser.Id;

            // pageApi.Description = "hello this is a new pageApi from develper";

            //new rev and key
            //pageApi.Rev = Guid.NewGuid().ToString();
            //pageApi.Key = Guid.NewGuid().ToString();

            //await EnforceClanExistenceAsync(PageApi.Clan.Name);
            var entity = await _pageApiRepository.CreateAsync(pageApi);
            if (entity == null)
            {
                throw new ApiNotFoundException();
            }

            return entity;
        }



        public async Task<PageApi> UpdateAsync(PageApi pageApi)
        {
            var updated = await this.EnforceApiExistenceAsync(pageApi.Id);

            //assigned
            //pageApi.Created = Utility.CurrentSEAsiaStandardTime();
            //PageApi.PageApi = PageApi.PageApi;
            //PageApi.Status = PageApi.Status;
            //   pageApi.By = httpCurrentUser.Id;

            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //pageApi.Key = Guid.NewGuid().ToString();

            var entity = await _pageApiRepository.UpdateAsync(pageApi);
            if (entity == null)
            {
                throw new ApiNotFoundException();
            }

            return entity;
        }

        public async Task<PageApi> GetApiAsync(Guid id)
        {
            //  await this.EnforceApiExistenceAsync(id);

            var entity = await _pageApiRepository.GetAsync(id);
            return entity;
        }


        /* public  async Task<PageApi> DeleteAsync(Guid id)
        {
            await this.EnforceApiExistenceAsync(id);

            var entity = await _pageApiRepository.DeleteAsync(id);
            return entity;
        }*/

        public async Task<IEnumerable<PageApi>> ListApiAsync()
        {
            return await _pageApiRepository.ListAsync();
        }


        // public async Task<IEnumerable<PageApi>> ListRecentlyApiAsync()
        // {
        //     return await _pageApiRepository.ListRecentlyAsync();
        // }

        public async Task<PageApi> EnforceApiExistenceAsync(Guid id)
        {
            var act = await _pageApiRepository.GetAsync(id);

            if (act == null)
            {
                throw new ApiNotFoundException();
            }

            return act;
        }


    }

}