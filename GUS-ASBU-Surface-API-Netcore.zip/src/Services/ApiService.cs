using System;

using System.Collections.Generic;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using surflex.netcore22.Exceptions;

//logg
using Serilog;
using surflex.netcore22.Helpers;
using System.IO;
using System.Net.Http;

namespace surflex.netcore22.Services
{
    public interface IApiService
    {
        Task<Api> CreateAsync(Api api);
        Task<Api> UpdateAsync(Api api);
        Task<Api> DeleteAsync(Guid id);

        Task<Api> GetAsync(Guid id);

        Task<IEnumerable<Api>> ListAsync();
        Task<Api> EnforceApiExistenceAsync(Guid id);
        Task<IEnumerable<Api>> InitAsync(List<Api> apis);
        Task<Api> EnforceEndpointExistenceAsync(string endpoint);
    }

    public class ApiService : IApiService
    {
        //api status
        protected readonly IApiRepository _apiRepository;
        // protected readonly IUserService _userService;
        public ApiService(IApiRepository apiRepository) //, IUserService userService, IPathFinderService pathFinderService)
        {
            _apiRepository = apiRepository ?? throw new ArgumentNullException(nameof(apiRepository));
            //_userService = userService ?? throw new ArgumentNullException(nameof(userService));

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }

        public async Task<IEnumerable<Api>> InitAsync(List<Api> apis)
        {

            var entities = new List<Api>();
            foreach (var r in apis)
            {
                var entity = await this.CreateAsync(r);

                entities.Add(entity);
            }

            return entities;
        }


        public virtual async Task<Api> CreateAsync(Api api)
        {
            //await this.EnforceWellExistenceAsync(Api.WellId);
            //assigned
            api.Id = Guid.NewGuid();
            api.Created = Utility.CurrentSEAsiaStandardTime();


            //api.Description = "hello this is a new api from develper";

            //new rev and key
            //api.Rev = Guid.NewGuid().ToString();
            //api.Key = Guid.NewGuid().ToString();

            //await EnforceClanExistenceAsync(Api.Clan.Name);
            var entity = await _apiRepository.CreateAsync(api);
            if (entity == null)
            {
                throw new ApiNotFoundException();
            }

            return entity;
        }



        public virtual async Task<Api> UpdateAsync(Api api)
        {
            var updated = await this.EnforceApiExistenceAsync(api.Id);

            //assigned
            //api.Created = Utility.CurrentSEAsiaStandardTime();
            //Api.Api = Api.Api;
            //Api.Status = Api.Status;
            //   api.By = httpCurrentUser.Id;

            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //api.Key = Guid.NewGuid().ToString();

            var entity = await _apiRepository.UpdateAsync(api);
            if (entity == null)
            {
                throw new ApiNotFoundException();
            }

            return entity;
        }

        public virtual async Task<Api> GetAsync(Guid id)
        {
            //  await this.EnforceApiExistenceAsync(id);

            var entity = await _apiRepository.GetAsync(id);
            return entity;
        }


        public virtual async Task<Api> DeleteAsync(Guid id)
        {
            await this.EnforceApiExistenceAsync(id);

            var entity = await _apiRepository.DeleteAsync(id);
            return entity;
        }

        public virtual async Task<IEnumerable<Api>> ListAsync()
        {
            return await _apiRepository.ListAsync();
        }

        public virtual async Task<Api> EnforceApiExistenceAsync(Guid id)
        {
            var act = await _apiRepository.GetAsync(id);

            if (act == null)
            {
                throw new ApiNotFoundException();
            }

            return act;
        }


        public virtual async Task<Api> EnforceEndpointExistenceAsync(string endpoint)
        {
            var entity = await _apiRepository.ListAsync();
            var temp = entity.Where(c => c.Endpoint == endpoint).FirstOrDefault();

            if (temp == null)
            {
                throw new ApiNotFoundException();
            }

            return temp;
        }

    }

}