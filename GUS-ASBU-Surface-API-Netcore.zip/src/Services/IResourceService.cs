using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;
using surflex.netcore22.APIs.Gateway;

namespace surflex.netcore22.Services
{
    public interface IResourceService
    {
        Task<Resource> CreateAsync(Resource resource);
        Task<Resource> UpdateAsync(Resource resource);
        //Task<Resources> DeleteAsync(string id);

        Task<Resource> GetAsync(string id);

        Task<IEnumerable<Resource>> ListAsync();
        Task<Resource> EnforceResourceExistenceAsync(string id);



        //librarry
        Task<ResourceLibrary> CreateAsync(ResourceLibrary resource);
        Task<ResourceLibrary> UpdateAsync(ResourceLibrary resource);
        //Task<Resources> DeleteAsync(string id);

        Task<ResourceLibrary> GetLibraryAsync(string id);

        Task<IEnumerable<ResourceLibrary>> ListLibraryAsync(bool archive);
        Task<ResourceLibrary> EnforceResourceLibraryExistenceAsync(string id);

        Task<IEnumerable<ResourceLibrary>> ListTangibleAsync();
        Task<IEnumerable<ResourceLibrary>> ListOpexCPPAsync();
        // Task<IEnumerable<ResourceLibrary>> ListConstantLibraryAsync()
        Task<IEnumerable<Item>> ListTypeAsync();
        // Task<IEnumerable<Item>> ListOpexNameAsync();
        //task
        Task<ResourceTask> CreateAsync(ResourceTask resource);
        Task<ResourceTask> UpdateAsync(ResourceTask resource);
        Task<ResourceTask> DeleteAsync(string id);

        Task<ResourceTask> GetTaskAsync(string id);

        Task<IEnumerable<ResourceActivity>> ListTaskAsync();
        Task<IEnumerable<ResourceActivity>> ListTaskAsync(string id, string type);
        Task<ResourceTask> EnforceResourceTaskExistenceAsync(string id);

        Task<ResourceLibrary> GetCurrentlyTangibleAsync();
        ///ca;cu;late engins
        Task<WellDecisionParams> CalculateBatchResourceAsync(WellDecisionParams parameters);

        Task<IEnumerable<ResourceLibrary>> InitialLibraryAsync(List<ResourceLibrary> resources);

        //Task<FluentValidation.Results.ValidationResult> ValidateBatchResourceAsync(WellDecisionParams parameters);
        Task<WellDecisionParams> ValidateBatchResourceAsync(WellDecisionParams parameters);
    }
}