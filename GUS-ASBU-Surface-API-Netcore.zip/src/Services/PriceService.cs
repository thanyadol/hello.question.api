using System; 

using System.Collections.Generic;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using surflex.netcore22.Exceptions;

//logg
using Serilog;
using surflex.netcore22.Helpers;

//io
using System.IO;
using Microsoft.AspNetCore.Hosting;
using System.Data;
using surflex.netcore22.Extensions;
using surflex.netcore22.APIs.Gateway;
using FluentValidation;
//using surflex.netcore22.Models.Constants;

using PRICE = surflex.netcore22.Models.Constants.Price;
using surflex.netcore22.Helpers.DataHandler;

namespace surflex.netcore22.Services
{
    public interface IPriceService
    {
        Task<PeriodPrice> CreateAsync(PeriodPrice price);
        Task<PeriodPrice> UpdateAsync(PeriodPrice price);
        //Task<Prices> DeleteAsync(Guid id);

        Task<PeriodPrice> GetAsync(Guid id);

        //  Task<IEnumerable<Price>> ExtractAsync(Attachment attach, bool hasHeader = true);
        //Task<DataTable> ExtractAsync(OfficeOpenXml.ExcelWorksheet ws, bool hasHeader = true);
        //Task<IEnumerable<Price>> TransformAsync(DataTable table);
        //Task<IEnumerable<Price>> LoadAsync(IEnumerable<Price> prices, Guid id);


        Task<IEnumerable<Price>> CreateMonthlyAsync(Template template);
        Task<IEnumerable<Price>> CreateYearlyAsync(Template template);

        Task<IEnumerable<PeriodPrice>> ListAsync();
        Task<PeriodPrice> EnforcePriceExistenceAsync(Guid id);

        Task<Price> GetGroupedAsync(Guid id);

        Task<Price> CreateAsync(Price price);
        Task<Price> EnforceGroupedExistenceAsync(Guid id);
        Task<IEnumerable<Price>> ListGroupedAsync();

        //by area
        Task<PeriodPrice> GetCurrentPriceAsync(string id, string structure);
        Task<PeriodPrice> GetYearPriceAsync(string id, string structure, int year);

        Task<IEnumerable<Price>> ListRecentlyAsync(string id = null);

        Task<bool> ValidateMonthlyTemplateAsync(Attachment attachment);

    }
    public class PriceService : IPriceService
    {
        private readonly string YEAR_SHEET_NAME = "Price";
        private readonly IPeriodPriceRepository _priceRepository;
        private readonly IPriceGroupRepository _priceGroupedRepository;

        //  private readonly IPathFinderService _pathFinderService;
        private readonly IAreaService _areaService;
        private readonly IAttachmentService _attachementService;
        private readonly ITemplateService _templateService;
        private readonly IWorkUnitService _workUnitService;

        protected readonly IPathFinderService _pathFinderService;

        private readonly AbstractValidator<TemplateValidateParams> _templateValidator;


        public PriceService(IPeriodPriceRepository priceRepository,
                                IPriceGroupRepository priceGroupedRepository, //IPathFinderService pathFinder,
                                IAreaService areaService, IWorkUnitService workUnitService, IAttachmentService attachementService,
                                ITemplateService templateService, IPathFinderService pathFinderService, AbstractValidator<TemplateValidateParams> templateValidator)
        {
            _priceRepository = priceRepository ?? throw new ArgumentNullException(nameof(priceRepository));
            _priceGroupedRepository = priceGroupedRepository ?? throw new ArgumentNullException(nameof(priceGroupedRepository));
            // _pathFinderService = pathFinder ?? throw new ArgumentNullException(nameof(pathFinder));
            _areaService = areaService ?? throw new ArgumentNullException(nameof(areaService));

            _workUnitService = workUnitService ?? throw new ArgumentNullException(nameof(workUnitService));

            _attachementService = attachementService ?? throw new ArgumentNullException(nameof(attachementService));
            _templateService = templateService ?? throw new ArgumentNullException(nameof(templateService));
            _templateValidator = templateValidator ?? throw new ArgumentNullException(nameof(templateValidator));

            _pathFinderService = pathFinderService ?? throw new ArgumentNullException(nameof(pathFinderService));

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }

        public async Task<PeriodPrice> CreateAsync(PeriodPrice price)
        {
            //await this.EnforceWellExistenceAsync(PeriodPrice.WellId);
            //assigned
            price.Id = Guid.NewGuid();
            // price.Date = Utility.CurrentSEAsiaStandardTime();

            // price.By = httpCurrentUser.Id;

            //price.Description = "hello this is a new attachemnt from dev";

            //new rev and key
            //price.Rev = Guid.NewGuid().ToString();
            //price.Key = Guid.NewGuid().ToString();

            //await EnforceClanExistenceAsync(PeriodPrice.Clan.Name);
            var entity = await _priceRepository.CreateAsync(price);
            if (entity == null)
            {
                throw new PriceNotFoundException();
            }

            return entity;
        }


        public async Task<PeriodPrice> UpdateAsync(PeriodPrice price)
        {
            var updated = await this.EnforcePriceExistenceAsync(price.Id);

            //assigned
            // price.Date = Utility.CurrentSEAsiaStandardTime();
            //PeriodPrice.Price = Price.Price;
            //Price.Status = Price.Status;
            //price.By = httpCurrentUser.Id;

            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //price.Key = Guid.NewGuid().ToString();

            var entity = await _priceRepository.UpdateAsync(price);
            if (entity == null)
            {
                throw new PriceNotFoundException();
            }

            return entity;
        }

        public async Task<PeriodPrice> GetAsync(Guid id)
        {
            //  await this.EnforcePriceExistenceAsync(id);

            var entity = await _priceRepository.GetAsync(id);
            return entity;
        }

        //by template id
        public async Task<IEnumerable<Price>> ListRecentlyAsync(string id = null)
        {
            var entity = await _priceRepository.ListRecentlyAsync();

            if (!string.IsNullOrEmpty(id))
            {

                entity = entity.Where(c => c.TemplateId == id);
            }

            var query = new List<Price>();
            foreach (var p in entity)
            {
                p.Prices = p.Prices.Select(c => { c.CurrentDate = new DateTime(c.Year, c.Month.GetValueOrDefault(), 1, 0, 0, 0); return c; }).ToList();

                query.Add(p);
            }

            return query;
        }


        //
        // Summary:
        //     Returns the price with structure (low, mid, heigh, sensitivity)
        //
        // Returns:
        //     price object
        //
        // Type parameters:
        //   id:
        //     area id
        //   structure :
        //     structure name
        //
        //
        public async Task<PeriodPrice> GetCurrentPriceAsync(string id, string structure)
        {
            //  await this.EnforcePriceExistenceAsync(id);
            var entity = await _priceGroupedRepository.ListAsync();

            var group = entity.Where(c => c.AreaId == id && c.Structure == structure)// && c.Status == ACTIVE)
                                 .OrderByDescending(c => c.Created).FirstOrDefault();
            if (group == null)
            {
                throw new PriceNotFoundException();
            }

            var price = await _priceRepository.GetCurrentAsync(group.Id);
            if (price == null)
            {
                throw new PriceNotFoundException();
            }

            return price;
        }

        //
        // Summary:
        //     Returns the price with structure (low, mid, heigh, sensitivity)
        //
        // Returns:
        //     price object
        //
        // Type parameters:
        //   id:
        //     area id
        //   structure :
        //     structure name
        //
        //
        public async Task<PeriodPrice> GetYearPriceAsync(string id, string structure, int year)
        {
            //  await this.EnforcePriceExistenceAsync(id);
            var entity = await _priceGroupedRepository.ListAsync();

            var group = entity.Where(c => c.AreaId == id && c.Structure == structure)// && c.Status == ACTIVE)
                                                 .OrderByDescending(c => c.Created).FirstOrDefault();

            if (group == null)
            {
                throw new PriceNotFoundException();
            }

            var price = await _priceRepository.GetYearAsync(group.Id, year);
            if (price == null)
            {
                throw new PriceNotFoundException();
            }

            return price;
        }


        public async Task<Price> GetGroupedAsync(Guid id)
        {
            //  await this.EnforcePriceExistenceAsync(id);

            var entity = await _priceGroupedRepository.GetAsync(id);
            return entity;
        }



        public async Task<Price> CreateAsync(Price price)
        {
            //await this.EnforceWellExistenceAsync(Price.WellId);
            //assigned
            price.Id = Guid.NewGuid();
            // price.Date = Utility.CurrentSEAsiaStandardTime();

            // price.By = httpCurrentUser.Id;

            //price.Description = "hello this is a new attachemnt from dev";

            //new rev and key
            //price.Rev = Guid.NewGuid().ToString();
            //price.Key = Guid.NewGuid().ToString();

            //await EnforceClanExistenceAsync(Price.Clan.Name);
            var entity = await _priceGroupedRepository.CreateAsync(price);
            if (entity == null)
            {
                throw new PriceNotFoundException();
            }

            return entity;
        }

        public async Task<Price> EnforceGroupedExistenceAsync(Guid id)
        {

            var act = await _priceGroupedRepository.GetAsync(id);

            if (act == null)
            {
                throw new PriceNotFoundException();
            }

            return act;
        }

        public async Task<IEnumerable<Price>> ListGroupedAsync()
        {
            return await _priceGroupedRepository.ListAsync();
        }


        public async Task<bool> ValidateMonthlyTemplateAsync(Attachment attachment)
        {
            await Task.Delay(0);

            string VALIDATE_RULE_SET = "PRICE";
            const int START_ROW = 0;

            var flag = new FluentValidation.Results.ValidationResult();
            var structure = PRICE.STRUCTURE;

            foreach (string sheet in structure)
            {
                DataTable dt = await this.ExtractAsync(attachment, sheet, START_ROW, false);

                if (dt == null)
                {
                    throw new TemplateNotValidException("PRICE");
                }

                //construc validate params
                var parameter = new TemplateValidateParams()
                {
                    Extensions = attachment.Extension,
                    SheetName = sheet,

                    //Items = null,
                    TemplateId = attachment.UploadTemplateId
                };

                //set item as location valur pair
                var items = new LocationTextPair[] {
                    new LocationTextPair("A", 0, dt.Rows[0]["A"].ToString()),
                    new LocationTextPair("B", 0, dt.Rows[0]["B"].ToString()),
                };

                parameter.Items = items.ToList();
                //vlidate
                flag = _templateValidator.Validate(parameter, ruleSet: VALIDATE_RULE_SET);
                if (flag.IsValid != true)
                {
                    throw new Exception(flag.Errors.FirstOrDefault().ErrorMessage);
                }

            }

            return flag.IsValid;
        }

        public async Task<IEnumerable<Price>> CreateYearlyAsync(Template template)
        {
            const int START_ROW = 1;
            ///string sheet

            var year = new LocationTextPair("A", 1, "Year");
            var str = new LocationTextPair("A", 2, "Structure");
            var area = new LocationTextPair("A", 3, "Area");
            var unit = new LocationTextPair("B", 1, "Unit");
            var start = new LocationTextPair("C", 1, "MinYear");

            //setup
            var parameters = new PriceTemplateParams() { Template = template, Sheet = "Price" };

            var attach = await _attachementService.EnforceAttachmentExistenceAsync(parameters.Template.AttachmentId);
            if (attach == null)
            {
                throw new AttachmentNotFoundException();
            }

            // var workbook = await _attachementService.GetWorkbookAsync(attach, parameters.Sheet);
            // var tbl = await this.ExtractAsync(attach, startRow, false);
            var tbl = await this.ExtractAsync(attach, YEAR_SHEET_NAME, START_ROW, false);

            //int i = 1;
            var structure = PRICE.STRUCTURE;
            string current = "";

            //for each row
            var entities = new List<Price>();
            for (int i = 1; i < tbl.Rows.Count; i++)
            {
                //i++;
                var dr = tbl.Rows[i];

                //determine current loop set    
                var temp = (string)dr[str.Column];

                if (structure.Contains(temp))
                {
                    current = temp;
                    continue;
                }

                //transform
                var uu = (string)dr[unit.Column];
                var grouped = new Price()
                {
                    Name = (string)dr[area.Column],
                    Unit = uu,

                    Structure = current,

                    Type = PriceType.YEARLY.GetDescription(),

                    Description = "yearly",
                    HcType = uu.IndexOf("MMBTU") > 0 ? "Gas" : "Oil",

                    TemplateId = template.Id
                };

                //by year
                foreach (DataColumn dc in tbl.Columns)
                {
                    int loopyear;

                    try
                    {
                        loopyear = Convert.ToInt32(tbl.Rows[0][dc.ColumnName]);
                    }
                    catch (FormatException)
                    {
                        // the FormatException is thrown when the string text does 
                        // not represent a valid integer.

                        continue;
                    }
                    /* catch (OverflowException)
                    {
                        // the OverflowException is thrown when the string is a valid integer, 
                        // but is too large for a 32 bit integer.  Use Convert.ToInt64 in
                        // this case.
                    }*/

                    decimal value = 0.0m; // Not strictly required, as the default value is 0.0
                    try
                    {
                        value = Convert.ToDecimal(dr[dc.ColumnName].ToString());

                    }
                    catch (FormatException ex)
                    {
                        //string ss = string.Format("Invalid price exception, year {0}, row {1}", dc.ColumnName, i);
                        throw new PriceNotValidException(ex.Message); //ss, ex);
                    }

                    grouped.Prices.Add(new PeriodPrice() { Value = value, Year = loopyear });
                }

                entities.Add(grouped);
            }

            // var result = await this.LoadAsync(entities);
            //return result;

            throw new NotImplementedException();
        }

        public async Task<IEnumerable<Price>> CreateMonthlyAsync(Template template)
        {
            const int START_ROW = 2;

            var year = new LocationTextPair("A", 1, "Year");
            var month = new LocationTextPair("B", 1, "Month");

            //setup
            var parameters = new PriceTemplateParams() { Template = template };
            var str = new List<PriceLocationValuePair>()
            {
                //new LocationValuePair("A", 1, "Year"),
                //new LocationValuePair("B", 1, "Month"),

                new PriceLocationValuePair("C", 1, "C1", "GAS"),
                new PriceLocationValuePair("D", 1, "CTEP", "GAS"),
                new PriceLocationValuePair("E", 1, "PAILIN", "GAS"),
                new PriceLocationValuePair("F", 1, "CONDENSATE DOMESTIC", "OIL"),
                new PriceLocationValuePair("G", 1, "Pattani Oil Domestic", "OIL"),
                new PriceLocationValuePair("H", 1, "Pattani Oil Export", "OIL"),
                new PriceLocationValuePair("I", 1, "B8/32 Gas", "GAS"),
                new PriceLocationValuePair("J", 1, "Arthit", "GAS"),
                new PriceLocationValuePair("K", 1, "B8/32 Oil Tan", "OIL"),
                new PriceLocationValuePair("L", 1, "B8/32 Oil Ben", "OIL"),
                new PriceLocationValuePair("M", 1, "WTI", "OIL"),
            };

            parameters.Structures = str;

            var attach = await _attachementService.EnforceAttachmentExistenceAsync(parameters.Template.AttachmentId);
            if (attach == null)
            {
                throw new AttachmentNotFoundException();
            }

            var entities = new List<Price>();
            var structure = PRICE.STRUCTURE;

            try
            {
                foreach (string sheet in structure)
                {
                    // var workbook = await _attachementService.GetWorkbookAsync(attach, s);
                    var tbl = await this.ExtractAsync(attach, sheet, START_ROW, false);

                    foreach (var l in parameters.Structures)
                    {
                        var group = new Price()
                        {
                            Name = l.Text,
                            Structure = sheet,
                            Description = "monthly",
                            HcType = l.HcType,
                            Type = PriceType.MONTHLY.GetDescription(),

                            TemplateId = template.Id
                        };

                        foreach (DataRow dr in tbl.Rows)
                        {
                            var entity = new PeriodPrice()
                            {
                                Year = Convert.ToInt32(dr[year.Column].ToString()),
                                Month = Utility.ParseMonthMMMToInt(dr[month.Column].ToString()),
                                Value = Convert.ToDecimal(dr[l.Column].ToString()),
                            };

                            group.Prices.Add(entity);
                        }


                        entities.Add(group);
                    }
                }

                //load
                var result = await this.LoadAsync(entities);
                return entities;
            }
            catch (Exception)
            {
                await _templateService.RollbackAsync(template);

                //remove template, attachment 
                await _templateService.DeleteAsync(template.Id);
                await _attachementService.DeleteAsync(template.AttachmentId);

                throw new PriceNotValidException();
            }
        }

        private async Task<DataTable> ExtractAsync(Attachment attachment, string sheet, int startRow, bool hasHeader = true)
        {

            await Task.Delay(0);
            //attachemtn
            Byte[] bytes = Convert.FromBase64String(attachment.Value);
            //var path = await _pathFinderService.FindAsync(attach.Id + attach.Extension);

            //open
            Aspose.Cells.Worksheet ws;
            using (var stream = new MemoryStream(bytes))
            {
                var engine = new ExcelEngine(stream);
                var pck = engine.Excel;

                //validate sheet
                ws = pck.Worksheets[sheet];
            }

            if (ws == null)
            {
                throw new AttachmentNotValidException(attachment.Id);
            }

            if (ws.Cells == null)
            {
                throw new AttachmentNotValidException(attachment.Id);
            }


            string[] cols = new string[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
                                            "AA", "AB", "AC", "AD", "AE", "AF", "AG", "AH", "AI", "AJ", "AK", "AL", "AM", "AN", "AO", "AP", "AQ", "AR", "AS", "AT", "AU", "AV", "AW", "AX", "AY", "AZ"  };
            // hasHeader = false;
            DataTable tbl = new DataTable();

            Aspose.Cells.Range range = ws.Cells.MaxDisplayRange;

            var firstRow = ws.Cells.Rows[0];
            var startCol = 0;

            for (int i = startCol; i < range.ColumnCount; i++)
            {
                // Aspose.Cells.Cell cell = ws.Cells.GetCell(0, i);

                //with no hearder
                tbl.Columns.Add(cols[i]);
            }

            //determine end row
            // endRow = endRow == 0 ? range.RowCount : endRow;

            //shift for data
            // int startRow = 1;
            for (int rowNum = startRow; rowNum <= range.RowCount - (startRow - 1); rowNum++)
            {
                var wsRow = ws.Cells.Rows[rowNum];

                //buffer for merged cell
                DataRow row = tbl.Rows.Add();

                for (int j = startCol; j < range.ColumnCount; j++)
                {
                    try
                    {

                        Aspose.Cells.Cell cell = wsRow.GetCellOrNull(j);
                        row[j] = cell.StringValue;
                    }
                    catch (NullReferenceException)// ex)
                    {
                        //throw ex;
                    }

                }
            }

            return tbl;
        }

        private async Task<IEnumerable<Price>> LoadAsync(IEnumerable<Price> groups)
        {
            var entities = new List<Price>();
            using (var transaction = _workUnitService.BeginTransaction())
            {
                foreach (var gg in groups)
                {
                    //persist area
                    var area = await _areaService.EnforceAreaCreateAsync(new Area(gg.Name, gg.HcType, "PRICE"));

                    //persist group
                    //set value
                    gg.Id = Guid.NewGuid();
                    gg.Created = Utility.CurrentSEAsiaStandardTime();
                    //    gg.TemplateId = template;
                    gg.AreaId = area.Id;

                    var entity = await _workUnitService.PriceGroups.CreateAsync(gg);

                    foreach (var pp in gg.Prices)
                    {
                        pp.Id = Guid.NewGuid();
                        pp.Created = Utility.CurrentSEAsiaStandardTime();
                        pp.PriceId = entity.Id;

                        await _workUnitService.Prices.CreateAsync(pp);
                    }

                    //clear
                    //entity.Prices = null;

                    entities.Add(entity);
                }

                try
                {
                    transaction.Commit();
                    return entities;
                }
                catch (InvalidOperationException ex)
                {
                    transaction.Rollback();
                    throw new PriceNotValidException(ex.Message);
                }
            }

        }


        /* *public async Task<PeriodPrice> DeleteAsync(Guid id)
        {
            await this.EnforcePriceExistenceAsync(id);

            var deletedPrice = await _priceRepository.DeleteAsync(id);
            return deletedPrice;
        }*/

        public async Task<IEnumerable<PeriodPrice>> ListAsync()
        {
            var entity = await _priceRepository.ListAsync();

            if (entity == null)
            {
                throw new PriceNotFoundException();
            }

            return entity;
        }

        public async Task<PeriodPrice> EnforcePriceExistenceAsync(Guid id)
        {
            var act = await _priceRepository.GetAsync(id);

            if (act == null)
            {
                throw new PriceNotFoundException();
            }

            return act;
        }


    }

}