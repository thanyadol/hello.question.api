using System; 

using System.Collections.Generic;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;

//logg
using Serilog;

//JSON manipulate
using Newtonsoft.Json;


//model
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using surflex.netcore22.Exceptions;

//DTO
using Analogy = surflex.netcore22.APIs.Model.Analogy;
using Factor = surflex.netcore22.APIs.Model.Factor;
using Product = surflex.netcore22.APIs.Model.Product;
using Usi = surflex.netcore22.APIs.Model.Usi;

using Newtonsoft.Json.Serialization;
using surflex.netcore22.Extensions;

using Depletion = surflex.netcore22.APIs.Model.Depletion;
using Category = surflex.netcore22.APIs.Model.Category;
using surflex.netcore22.APIs.Model;
using surflex.netcore22.APIs;

using surflex.netcore22.Helpers;

//validate
using FluentValidation;
using FluentValidation.Results;
using FluentValidation.Internal;
using FluentValidation.Validators;
using surflex.netcore22.APIs.Gateway;
//using surflex.netcore22.Models.Constants;

using DRILLED = surflex.netcore22.Models.Constants.Drilled;


namespace surflex.netcore22.Services
{
    public interface ISandService
    {
        Task<Sand> CreateAsync(Sand sand);
        Task<Sand> UpdateAsync(Sand sand);

        Task<Sand> GetAsync(Guid id);

        Task<IEnumerable<Sand>> ListAsync();

        Task<ValidationResult> ValidateAsync(Sand sand);

        Task<Usi> GetSandInfoAsync(string usi);
        Task<IEnumerable<Factor>> ListFactorProfileAsync(string type);
        Task<IEnumerable<Analogy>> ListAnalogyAsync(string type);
        Task<IEnumerable<Depletion>> ListDepletionTypeAsync();
        Task<IEnumerable<Category>> ListCategoryAsync();

        //    Task<Sand> EnforceSandExistenceAsync(string id);

        Task<IEnumerable<string>> GetRulesAsync();


        Task<Sand> CalculateP1DNAsync(Sand entity, Models.Platform platform);
        Task<IEnumerable<Sand>> SynceAsync(string name, string project, WellAnalogy analogy);

        Task<Sand> ClearP1DNAsync(Sand sand);
        // bool EnforceIsContainedAZI(string category);

        Task<IEnumerable<Sand>> ListProductiveAsync(string[] name);

        Task<IEnumerable<Sand>> InitOpenWorksContactCategoryAsync(IEnumerable<Sand> sands);
    }

    //
    // Summary:
    //     Class serviced for sand repository
    //

    public class SandService : ISandService
    {
        private const string AZI = "AZI";


        private readonly ISandRepository _sandRepository;

        // private readonly IActivityRepository _sandActivityRepository;

        //   private readonly IWellService _wellService;
        //   private readonly IUserService _userService;

        private readonly IProjectWellService _projectWellService;

        //  private readonly IPriceService _priceService;
        private readonly AbstractValidator<Sand> _sandValidator;


        private readonly IMapper<IEnumerable<SandAsync>, IEnumerable<Sand>> _collectionMapper;
        private readonly IMapper<SandAsync, Sand> _singleMapper;

        //client and entity
        private readonly IEntityService _entityService;
        private readonly IClientService _clientService;

        //lol di
        public SandService(ISandRepository SandRepository,
               IMapper<SandAsync, Sand> singleMapper, IMapper<IEnumerable<SandAsync>, IEnumerable<Sand>> collectionMapper,
                AbstractValidator<Sand> sandValidator, IProjectWellService projectWellService,
                IClientService clientService, IEntityService entityService)
        {
            _sandRepository = SandRepository ?? throw new ArgumentNullException(nameof(SandRepository));
            // _wellService = wellService ?? throw new ArgumentNullException(nameof(wellService));

            _collectionMapper = collectionMapper ?? throw new ArgumentNullException(nameof(collectionMapper));
            _singleMapper = singleMapper ?? throw new ArgumentNullException(nameof(singleMapper));

            //validatoor
            //    _platformValidator = platformValidator ?? throw new ArgumentNullException(nameof(platformValidator));
            _sandValidator = sandValidator ?? throw new ArgumentNullException(nameof(sandValidator));
            _projectWellService = projectWellService ?? throw new ArgumentNullException(nameof(projectWellService));

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();


            _clientService = clientService ?? throw new ArgumentNullException(nameof(clientService));
            _entityService = entityService ?? throw new ArgumentNullException(nameof(entityService));

        }


        //
        // Summary:
        //     basic CRUD, Returns the created sand 
        //
        // Returns:
        //     Models.Entity.Sand object
        //
        // Type parameters:
        //   sand:
        //     sand to create
        //
        public async Task<Sand> CreateAsync(Sand sand)
        {
            //Is well existing aysnce
            //await EnforceClanExistenceAsync(Sand.Clan.Name);
            var entity = await _sandRepository.CreateAsync(sand);
            if (entity == null)
            {
                throw new SandNotFoundException();
            }

            return entity;
        }


        //
        // Summary:
        //     basic CRUD, Returns the updated sand with logic
        //
        // Returns:
        //     Models.Entity.Sand object
        //
        // Type parameters:
        //   sand:
        //     sand to update
        //
        public async Task<Sand> UpdateAsync(Sand sand)
        {
            var updated = await this.EnforceSandExistenceAsync(sand.Id);


            var entity = await _sandRepository.UpdateAsync(sand);
            if (entity == null)
            {
                throw new SandNotFoundException();
            }

            return entity;
        }


        public async Task<Sand> GetAsync(Guid id)
        {
            //await this.EnforceSandExistenceAsync(id);

            var sand = await _sandRepository.GetAsync(id);
            return sand;
        }



        //
        // Summary:
        //     basic CRUD, Returns the list of sand without pagination
        //
        // Returns:
        //     Models.Entity.Sand collection object
        //
        public async Task<IEnumerable<Sand>> ListAsync()
        {
            return await _sandRepository.ListAsync();
        }

        //
        // Summary:
        //     List productive sand from UIDM with fist of well
        //
        // Returns:
        //     Models.Entity.Sand collection object
        //
        // Type parameters:
        //      name : array of well name
        //
        public async Task<IEnumerable<Sand>> ListProductiveAsync(string[] name)
        {
            var entities = await _entityService.ListSandAsync(name);
            if (entities == null)
            {
                throw new SandNotFoundException();
            }

            var mapped = _collectionMapper.Mapp(entities);
            return mapped;

        }



        //
        // Summary:
        //     basic CRUD, Returns the sand by id and force throw the exception when is null
        //
        // Returns:
        //     Models.Entity.Sand collection object
        //
        // Type parameters:
        //   id:
        //     id of sand
        //
        public async Task<Sand> EnforceSandExistenceAsync(Guid id)
        {
            var act = await _sandRepository.GetAsync(id);

            if (act == null)
            {
                throw new SandNotFoundException(id.ToString());
            }

            return act;
        }

        //
        // Summary:
        //    Sand information from TCRS endpoint API
        //
        // Returns:
        //     Models.Gateway.Usi object
        //
        // Type parameters:
        //   usi:
        //     sand usi logic name
        //
        public async Task<Usi> GetSandInfoAsync(string usi)
        {
            var sand = await _clientService.GetSandInfoAsync(usi);

            //assinged usi
            sand.SandUSI = usi;

            return sand;
        }

        //
        // Summary:
        //    Return the list of factor profile from TCRS endpoint API
        //
        // Returns:
        //     Models.Gateway.Factor object
        //
        // Type parameters:
        //   type:
        //     "oil" or "gas"
        //
        public async Task<IEnumerable<Factor>> ListFactorProfileAsync(string type)
        {
            var sand = await _clientService.ListFactorProfileAsync(type);
            return sand.OrderBy(c => c.FVFProfileName);
        }

        //
        // Summary:
        //    Return the list of analogy from TCRS endpoint API
        //
        // Returns:
        //     Models.Gateway.Analogy object
        //
        // Type parameters:
        //   type:
        //     "set" or "scenario"
        //
        public async Task<IEnumerable<Analogy>> ListAnalogyAsync(string type)
        {
            var analogy = await _clientService.ListAnalogyAsync(type);
            return analogy.OrderBy(c => c.AnalogyDataSetName).OrderBy(c => c.AnalogyScenarioName);
        }

        //
        // Summary:
        //    Return the list of depletion type from TCRS endpoint API
        //
        // Returns:
        //     Models.Gateway.Depletion collection object
        //
        public async Task<IEnumerable<Depletion>> ListDepletionTypeAsync()
        {
            var depletions = await _clientService.ListDepletionTypeAsync();

            //construct object
            var entity = new List<Depletion>();
            foreach (string s in depletions)
            {
                entity.Add(new Depletion { Id = s.ToLower().Replace(" ", ""), Type = s });
            }


            return entity.OrderBy(c => c.Type);
        }

        //
        // Summary:
        //    Return the list of reserve category type from TCRS endpoint API
        //
        // Returns:
        //     Models.Gateway.Category collection object
        //
        public async Task<IEnumerable<Category>> ListCategoryAsync()
        {
            var reservces = await _clientService.ListWellReservesCategoryAsync();

            //construct object
            var entity = new List<Category>();
            foreach (string s in reservces)
            {
                entity.Add(new Category { Id = s.ToLower().Replace(" ", ""), Value = s.ToUpper() });
            }

            return entity.OrderBy(c => c.Value);
        }



        //
        // Summary:
        //    Return the validation result of sand at calculate before sending to TCRS
        //
        // Returns:
        //     Fluentvalidate.ValidationResult object
        //
        // Type parameters:
        //   sand:
        //     sand productive to calculate
        //
        public async Task<ValidationResult> ValidateAsync(Sand sand)
        {
            await _sandRepository.GetAsync(sand.Id);
            //await TypeLoadException();
            return _sandValidator.Validate(sand);
        }



        public async Task<Sand> ClearP1DNAsync(Sand sand)
        {
            await Task.Delay(0);
            //await _sandRepository.GetAsync(sand.Id);
            //await TypeLoadException();
            return _singleMapper.Mutate(sand);
        }



        public async Task<Sand> CalculateP1DNAsync(Sand entity, Models.Platform platform)
        {
            //var json = Newtonsoft.Json.JsonConvert.SerializeObject(entity);
            //Log.Information(json);
            //ok calculate !!!!
            var product = new Product()
            {
                //Type= platfy.
                //platform    

                PlatformName = platform.Name,
                WellType = platform.WellType,  //platform

                //fvf
                BgProfileID = entity.FVFProfileBgProfileId.GetValueOrDefault(),
                BoProfileID = entity.FVFProfileBoProfileId.GetValueOrDefault(),

                //platform
                PipelinePressure = platform.PipelinePressure.GetValueOrDefault(),
                BcPos = platform.BcPos.GetValueOrDefault(),
                BcCompressionRatio = platform.BcCompressionRatio.GetValueOrDefault(),
                OilPipelinePressureCoeff = platform.OilPipelinePressureCoeff.GetValueOrDefault(),
                GasPipelinePressureCoeff = platform.GasPipelinePressureCoeff.GetValueOrDefault(),

                //analogy oil 
                OilAnalogyDatasetId = entity.AnalogyOilAreaSetId.GetValueOrDefault(),
                OilAnalogyScenarioId = entity.AnalogyOilAreaScenarioId.GetValueOrDefault(),

                //analogy gas
                GasAnalogyDatasetId = entity.AnalogyGasAreaSetId.GetValueOrDefault(),
                GasAnalogyScenarioId = entity.AnalogyGasAreaScenarioId.GetValueOrDefault(),

                NetGasPay = entity.NetGasVT,
                NetOilPay = entity.NetOilVT,

                //mocking
                WaterSaturation = entity.AvgSw,
                Porosity = entity.AvgPor,
                SubseaDepth = Math.Abs(entity.TopTVDSS.GetValueOrDefault()),

                //openworks
                PressureRFT = entity.PressureRFTInPSI,
                PressureInitial = entity.PressureEstimatedInitialInPSI,

                //sand info
                MechanicalDf = entity.DiscountFactorMechanical,
                Co2Df = entity.DiscountFactorCO2,
                CementQualityDf = entity.DiscountFactorCementQuality,
                BcDf = entity.DiscountFactorBC,
                DepletionCategory = entity.PayClassification,

                //openworks
                OpenworksReservesCategory = entity.OpenWorksContactCategory,

                //snad info
                GOR = platform.GOR.GetValueOrDefault(),
                CGR = platform.CGR.GetValueOrDefault(),
            };

            //cal p/pi
            entity.PressurePPi = product.PressureRFT / product.PressureInitial;

            //debug
            // var jsonp = JsonConvert.SerializeObject(product);
            // Log.Information(jsonp);

            //validate
            try
            {
                var calculate = await _clientService.GetCalculatedProductAsync(product);

                //oil
                entity.OilP1DNWithBC = calculate.OilP1dnWBC;
                entity.OilP1DNWithoutBC = calculate.OilP1dnWoBC;
                entity.LookupRenderingOilBCIncremental = calculate.OilBcIncremental;
                entity.InPlaceByVolumetricOOIP = calculate.OOIP;
                entity.DiscountFactorOilDepletion = calculate.OilDepletionDF;
                entity.RecoveryEfficiencyOil = calculate.OilRE;
                entity.FVFProfileBoValue = calculate.BoValue;
                //entity.RecoveryEfficiencyOil = pp.OilRecoveryDF;

                //gas
                entity.FreeGasP1DNWithBC = calculate.FreeGasP1dnWBC;
                entity.FreeGasP1DNWithoutBC = calculate.FreeGasP1dnWoBC;
                entity.InPlaceByVolumetricOGIP = calculate.OGIP;
                entity.DiscountFactorGasDepletion = calculate.GasDepletionDF;
                entity.RecoveryEfficiencyGas = calculate.GasRE;
                entity.FVFProfileBgValue = calculate.BgValue;
                //entity.RecoveryEfficiencyGil = pp.GilRecoveryDF;

                entity.CondensateP1DNWithBC = calculate.CondyP1dnWBC;
                entity.SolutionGasP1DNWithBC = calculate.SolGasP1dnWBC;

                entity.IsTCRSCompletedCalculated = true;
            }
            catch (ClientNotSuccessException)
            {
                entity.IsTCRSCompletedCalculated = false;
            }

            // var jsonp = JsonConvert.SerializeObject(product);
            //Log.Information(jsonp);

            //assigned to entity

            if (entity.IsTCRSCompletedCalculated)
            {

                //gas
                entity.HCLiquidWithBC = (entity.CondensateP1DNWithBC + entity.OilP1DNWithBC) * entity.Pos;
                entity.HCGasWithBC = Utility.ParseMMSCFtoMBOE(entity.SolutionGasP1DNWithBC.GetValueOrDefault() + entity.FreeGasP1DNWithBC.GetValueOrDefault()) * entity.Pos;

                //overide significant with pos
                entity.CondensateP1DNWithBC = entity.CondensateP1DNWithBC * entity.Pos;
                entity.OilP1DNWithBC = entity.OilP1DNWithBC * entity.Pos;
                entity.OilP1DNWithoutBC = entity.OilP1DNWithoutBC * entity.Pos;
                entity.SolutionGasP1DNWithBC = entity.SolutionGasP1DNWithBC * entity.Pos;
                entity.FreeGasP1DNWithBC = entity.FreeGasP1DNWithBC * entity.Pos;
                entity.FreeGasP1DNWithoutBC = entity.FreeGasP1DNWithoutBC * entity.Pos;

            }

            return entity;
        }


        //for uniitest
        /* public string InternalsVisibleToMappingCategory(string remark, string est, string azi)
        {
            return this.MappingCategory(remark, est, azi);
        }*/


        public string GetDefaultReserveCategory(string fluid, string remark, string estphase, string azi)
        {
            /// determine status
            string[] category = new string[] { "GAS", "GWC", "OIL", "OWC", "GOC", "GOW" };
            IDictionary<string, string> remarks = new Dictionary<string, string>()
            {
                {"O", "OIL"},
                {"G", "GAS"},
                {"O/W", "OWC"},
                {"G/W", "GWC"},
            };

            //check null or empty and to upper
            remark = String.IsNullOrEmpty(remark) ? "" : remark.ToUpper();

            var results = Array.FindAll(category, s => remark.Contains(s)).LastOrDefault();
            if (results == null)
            {
                results = String.IsNullOrEmpty(estphase) ? null : remarks[estphase];
            }

            //for fler
            //new logic with fluid
            //string[] fluids = new string[] { "GAS", "OIL", "GOC" };
            IDictionary<string, string[]> fluids = new Dictionary<string, string[]>()
            {
                {"GAS", new string[] { "GAS", "GWC" }},
                {"GAS?", new string[] { "GAS", "GWC" }},
                {"GASS", new string[] { "GAS", "GWC" }},
                {"OIL", new string[] { "OIL", "OWC" }},
                {"GOC", new string[] { "GOC" }}
            };

            //for FELR    
            if (!String.IsNullOrEmpty(fluid))
            {
                fluid = fluid.ToUpper();
                var temp = fluids[fluid];
                if (temp != null)
                {
                    //results = fluid; 
                    results = temp.Contains(results) ? results : fluid;
                }
            }

            //azi
            if (results != null && azi == "Y")
            {
                results = results + " " + AZI;
            }

            return results;
        }


        //
        // Summary:
        //    Return the mapping default well type (old logic )
        //
        // Returns:
        //     string
        //
        // Type parameters:
        //   reserve:
        //     sand reserve list
        //
        /* private string GetDefaultWellType(IEnumerable<Sand> reserve)
        {
            var category = new string[] { "GOW", "GOC", "OIL", "OWC" };
            var temp = reserve.Where(c => !String.IsNullOrEmpty(c.OpenWorksContactCategory));
            if (temp.Count() == 0)
            {
                return null;
            }

            temp = temp.Where(c => category.Contains(c.OpenWorksContactCategory.Replace(AZI, "").Trim()));
            if (temp.Count() == 0)
            {
                return WellType.GAS.GetDescription();
            }
            else
            {
                return WellType.OIL.GetDescription();
            }
        }*/

        //
        // Summary:
        //     Returns the refresh drilled sand for well
        //
        // Returns:
        //     Models.Entity.Sand object
        //
        // Type parameters:
        //   well:
        //     well name of the sand
        //
        public async Task<IEnumerable<Sand>> SynceAsync(string name, string project, WellAnalogy analogy)
        {

            // well = "SAWH-33";
            var productive = await _entityService.ListSandAsync(name);
            if (!productive.Any())
            {
                throw new SandNotFoundException($"Sand reserve not found with well = {name}");
            }

            //bo bg
            var attribute = new ProjectAttribute();
            try
            {
                // bo bg
                attribute = await _projectWellService.GetCurrentlyAttributeAsync(project);
            }
            catch (ProjectAttributeNotFoundException) { }

            var e = await _clientService.ListFactorProfileAsync("bo");
            var bo = e.Where(c => c.FVFProfileID == attribute.BoProfileId).FirstOrDefault();

            var t = await _clientService.ListFactorProfileAsync("bg");
            var bg = t.Where(c => c.FVFProfileID == attribute.BgProfileId).FirstOrDefault();

            var entities = _collectionMapper.Mapp(productive).ToArray();

            for (int i = 0; i < entities.Length; i++)
            {
                var entity = entities[i];

                var usi = this.ParseBaseToUSi(name, entity.TopMD, entity.BaseMD);
                entity.Usi = usi;

                var info = await _clientService.GetSandInfoAsync(usi);
                if (info == null)
                {
                    //exception ??? with default value
                }

                //assign
                entity.DiscountFactorMechanical = info.MechanicalDF;
                entity.DiscountFactorCementQuality = info.CementQualityDF;
                entity.DiscountFactorCO2 = info.Co2DF;
                entity.DiscountFactorBC = info.BcDF;
                entity.PayClassification = info.DepletionCategory;

                entity.OpenWorksContactCategory = this.GetDefaultReserveCategory(entity.Fluid, entity.Remarks, entity.EstPhase, entity.AZI);

                var flag = DRILLED.OIL_CONTACT_CATEGORY.Contains(entity.OpenWorksContactCategory?.Replace(AZI, "").Trim());
                if (flag == true)
                {
                    entity.AnalogyOilAreaScenarioId = analogy.OilAnalogyScenarioID;
                    entity.AnalogyOilAreaSetId = analogy.OilAnalogyDataSetID;
                    entity.AnalogyOilAreaName = analogy.OilAnalogyDataSetName;
                    entity.AnalogyOilArea = analogy.OilArea;
                    entity.AnalogyOilAreaDiscountFactor = analogy.OilAnalogyScenarioName;

                    if (bo != null)
                    {
                        entity.FVFProfileBoProfile = bo.FVFProfileName;
                        entity.FVFProfileBoProfileId = Convert.ToInt16(bo.FVFProfileID);
                    }

                }

                flag = DRILLED.GAS_CONTACT_CATEGORY.Contains(entity.OpenWorksContactCategory?.Replace(AZI, "").Trim());
                if (flag == true)
                {
                    //set default value
                    entity.AnalogyGasAreaScenarioId = analogy.GasAnalogyScenarioID;
                    entity.AnalogyGasAreaSetId = analogy.GasAnalogyDataSetID;
                    entity.AnalogyGasAreaName = analogy.GasAnalogyDataSetName;
                    entity.AnalogyGasArea = analogy.GasArea;
                    entity.AnalogyGasAreaDiscountFactor = analogy.GasAnalogyScenarioName;

                    if (bg != null)
                    {
                        //set default attribute
                        entity.FVFProfileBgProfileId = Convert.ToInt16(bg.FVFProfileID);
                        entity.FVFProfileBgProfile = bg.FVFProfileName; ;
                    }
                }

                entities[i] = entity;
            }

            return entities;

        }

        public async Task<IEnumerable<Sand>> InitOpenWorksContactCategoryAsync(IEnumerable<Sand> sands)
        {
            await Task.Delay(0);

            var entity = new List<Sand>();
            foreach (var s in sands)
            {
                s.OpenWorksContactCategory = this.GetDefaultReserveCategory(s.Fluid, s.Remarks, s.EstPhase, s.AZI);
                s.PayClassification = PayClassification.NEW.GetDescription();
                entity.Add(s);
            }

            return entity;
        }



        private string ParseBaseToUSi(string name, decimal? topmd, decimal? basemd)
        {
            //Sand USI = WellName_TopMD_BottomMD e.g. PMWE-06_10183_10217 

            //5 digits required
            var top = Convert.ToInt16(topmd).ToString("D5"); ;
            var bottom = Convert.ToInt16(basemd).ToString("D5");
            var usi = name + "_" + top + "_" + bottom;

            return usi;
        }


        //
        // Summary:
        //     Returns an enumerator that iterates through the collection of validation rules to client.
        //
        // Returns:
        //     A System.Collections.Generic.IEnumerator`1 that can be used to iterate through
        //     the collection.
        //
        // Type parameters:
        //   T:
        //     The type of the object being validated
        //
        public async Task<IEnumerable<string>> GetRulesAsync()
        {
            await Task.Delay(0);

            var rules = new List<string>();
            var descriptor = _sandValidator.CreateDescriptor();
            foreach (var member in descriptor.GetMembersWithValidators())
            {
                foreach (var validationRule in descriptor.GetRulesForMember(member.Key))
                {
                    var rule = (PropertyRule)validationRule; // cast 
                    foreach (var propertyValidator in rule.Validators)
                    {
                        var validator = (PropertyValidator)propertyValidator; // not needed, gives same without cast
                        rules.Add(
                           string.Format("validator:{0} | display:{1} | property:{2} | member:{3} | expression:{4}",
                                          validator.ToString().Replace("FluentValidation.Validators.", ""),
                                          rule.PropertyName,
                                          rule.GetDisplayName(),
                                          rule.Member,
                                          rule.Expression));
                    }
                }
            }

            return rules;
        }



    }


}