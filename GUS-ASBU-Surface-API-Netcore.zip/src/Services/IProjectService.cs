using System;

using System.Collections.Generic;
using System.Threading.Tasks;
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.Helpers.DataHandler;

//model
using surflex.netcore22.Models;

namespace surflex.netcore22.Services
{
    public interface IProjectService
    {
        Task<Project> GetAsync(string id);
        Task<Project> CreateAsync(Project project);
        Task<Project> UpdateAsync(Project project);
        // Task<Project> DeleteAsync(string id);

        // Task<bool> IsProjectExistsAsync(string id);

        Task<IEnumerable<Project>> ListAsync();

        //real time active project by RLLCP and UIDM endpoint
        //Task<IEnumerable<ProjectSummary>> ListActiveAsync();

        Task<IEnumerable<Project>> ListProductiveAsync();
        Task<Project> EnforceProjectExistenceAsync(string id);
        Task<Project> EnforceProjectCreateAsync(Project project);

        //attribute
        Task<ProjectAttribute> CreateAsync(ProjectAttribute attribute);
        // Task<ProjectAttribute> CreateAsync(string type, string sand, string descript);
        Task<ProjectAttribute> UpdateAsync(ProjectAttribute attribute);
        //Task<ProjectAttribute> DeleteAsync(string id);

        Task<ProjectAttribute> GetAttributeAsync(string id);
        //Task<ProjectAttribute> GetAttributeAsync(ProjectAttribute attr);
        Task<IEnumerable<ProjectAttribute>> ListAttributeAsync(string status);

        //Task<ProjectAttribute> GetRecentlyAsync(string key);

        // Task<ProjectAttribute> GetRecentlyPublishedAsync(string id);

        // Task<ProjectAttribute> GetRecentlySavedAsync(string id);
        Task<ProjectAttribute> EnforceProjectAttributeExistenceAsync(string id);

        //  Task<ProjectAttribute> GetCurrentlyAttributeAsync(string name);

        Task<ProjectActivity> CreateAsync(ProjectActivity activity);
        Task<ProjectSpace> UpdateAsync(ProjectSpace space);
        Task<ProjectWell> UpdateAsync(ProjectWell well);
        Task<ProjectSpace> CreateAsync(ProjectSpace space);
        Task<ProjectWell> CreateAsync(ProjectWell well);
        Task<ProjectSpace> PublishSpaceAsync(string id);
        Task<ProjectWell> EnforceProjectWellExistenceAsync(string id);
        Task<ProjectSpace> EnforceProjectSpaceExistenceAsync(string id);
        //  Task<ProjectWell> GetWellRecentlyAsync(int rllcp, string name);

        Task<ProjectWell> GetWellRecentlyAsync(int rllcp, string name, bool synce);

        Task<ProjectWell> BatchCreateAsync(ProjectWell well);
        Task<ProjectWell> SynceWellAsync(int rllcp, string name);


        Task<ProjectWell> GetPlannedWellAsync(string name, int rllcp);
        Task<ProjectWell> GetProductiveWellAsync(string name, int rllcp);
        //  Task<ProjectWell> GetCalculateWellReserveAsync(string name, int ids);

        //  Task<int> CountPlannedWellAsync(string name);
        Task<ProjectWell> GetReserveWellAsync(string name, int rllcp);

        Task<IEnumerable<WellReserveParams>> InitialReserveParamsAsync(string name, int rllcp);

        //  Task<IEnumerable<ProductionProfileParams>> EstimateMonthlyProductAsync(WellEvaluateParams p);

        Task<ProjectEvaluateParams> EvaluateMasterDPIAsync(ProjectEvaluateParams parameters);


        //drilled
        //Task<ProjectDrilled> GetDrilledRecentlyAsync(string name);

        Task<IEnumerable<ProjectDrilled>> ListDrilledAsync();
        Task<ProjectDrilled> EnforceDrilledExistenceAsync(Guid id);
        Task<ProjectDrilled> CreateAsync(ProjectDrilled well);
        Task<ProjectDrilled> UpdateAsync(ProjectDrilled well);
        Task<ProjectDrilled> BatchCreateAsync(ProjectDrilled wwww);

        Task<bool> ValidateMasterDPIAsync(Attachment attachment);
        Task<bool> ValidateMasterDPITemplateAsync(Attachment attachment);

        // Task ValidateDPITemplateAsync(Attachment attachment, IExcelProfile profile);

        //chartttttttttttt
        Task<ProjectPayParams> GetPayAsync(string name, int rllcp);

        Task<ProjectPayParams> GetReserveAsync(string name, int rllcp);
        Task<ProjectPayParams> GetRiggAsync(string name, int rllcp);
        // Task<ProjectEvaluateParams> BuildTryEvaluateMasterDPIForCTEPAsync(ProjectEvaluateParams parameters);



        Task<User> AuthorizeAsync(Token token);
        //authen
        // Task<ProjectAuthorize> EnforceProjectAuthorizeExistenceAsync(Guid id);
        // Task<IEnumerable<ProjectAuthorize>> ListRecentlyAuthorizeAsync();
        Task<IEnumerable<Project>> ListAuthorizeAsync();
        Task<IEnumerable<Project>> ListLocationAsync();

        //Task<IEnumerable<Item>> ListMasterAsync();
        Task<IEnumerable<ProjectLocation>> ListRecentlyLocationAsync();
        Task<IEnumerable<Project>> ListResponsibilityAsync();

        Task<ProjectLocation> CreateAsync(ProjectLocation location);

    }

    public interface IProjectWellService
    {
        Task<ProjectAttribute> GetCurrentlyAttributeAsync(string name);
        Task<int> CountPlannedWellAsync(string name);

        Task<int> GetDefaultPlannedWellAsync(string name);

        //Task<IEnumerable<ProductionProfileParams>> EstimateMonthlyProductAsync(WellEvaluateParams parameters);

        //  Task<IEnumerable<ProductionProfileParams>> EstimateMonthlyProductAsync(WellEvaluateParams p, WellProductiveReserve revs);
        Task<IEnumerable<ProductionProfileParams>> EstimateMonthlyProductAsync(WellEvaluateParams p, WellProductiveReserve revs, ProductionProfile oil, ProductionProfile gas);


        //Task<IEnumerable<ProductionProfileParams>> EstimateMonthlyProductAsync(WellEvaluateParams p, string level = "PROJECT");

        Task<ProjectDrilled> GetDrilledRecentlyAsync(string name);
    }



    public interface IProjectUserService
    {
        Task<IEnumerable<ProjectAuthorize>> ListRecentlyAsync();
        //  Task<IEnumerable<ProjectAuthorize>> ListRecentlyAuthorizeAsync();

        Task<ProjectAuthorize> GetAsync(Guid id);

        Task<IEnumerable<ProjectAuthorize>> BatchCreateAsynce(IEnumerable<ProjectAuthorize> authos);
    }

}