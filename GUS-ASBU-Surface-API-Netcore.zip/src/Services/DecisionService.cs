using AutoMapper;
using Serilog;
using surflex.netcore22.Exceptions;
using surflex.netcore22.Helpers;
using surflex.netcore22.Models;
using surflex.netcore22.Models.Constants;
using surflex.netcore22.Repositories;
using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Services
{
    public interface IDecisionService
    {
        Task<PresetWellScenarioParams> GetTemplateTreeAsync(Guid id);

        Task<PresetWellScenarioParams> UpdateTemplateTreeAsync(PresetWellScenarioParams tree);

        Task<WellScenarioParams> GetTreeByTabIdAsync(Guid id);

        Task<WellScenarioParams> SaveTreeAsync(WellScenarioParams tree);

        Task<DecisionResultDto> GetDecisionAsync(Guid tabId);

        Task<IEnumerable<DecisionResultDto>> GetDecisionListAsync(string wellName);

        Task<DecisionResultDto> SaveDecisionAsync(DecisionResultDto decision);

        Task<DecisionResultDto> PublishDecisionAsync(DecisionResultDto decision);

        Task DeleteDecisionAsync(Guid tabId);
    }

    public class DecisionService : IDecisionService
    {
        private readonly IUserService _userService;

        private readonly IDecisionRepository _decisionRepository;

        private readonly IMapper _mapper;

        private readonly User _httpCurrentUser;

        private readonly IHttpService _httpService;

        public DecisionService(IUserService userService, IDecisionRepository decisionRepository, IMapper mapper, IHttpService httpService)
        {
            _userService = userService ?? throw new ArgumentNullException(nameof(userService));
            _httpService = httpService ?? throw new ArgumentNullException(nameof(httpService));

            _decisionRepository = decisionRepository ?? throw new ArgumentNullException(nameof(decisionRepository));
            _httpCurrentUser = _httpService.GetHttpCurrentUserAsync().Result;

            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));

            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }

        public async Task<PresetWellScenarioParams> GetTemplateTreeAsync(Guid id)
        {
            var treeEntity = await _decisionRepository.GetTemplateTreeAsync(id);

            if (treeEntity == null) throw new WellScenarioNotFoundException(id.ToString());

            var nodeEntities = await _decisionRepository.GetTemplateNodesAsync(id);
            var edgeEntities = await _decisionRepository.GetTemplateEdgesAsync(id);

            var wellScenarioParams = _mapper.Map<PresetWellScenarioParams>(treeEntity);
            var tree = _mapper.Map<DecisionTreeDto>(treeEntity);
            var nodes = _mapper.Map<List<DecisionNodeDto>>(nodeEntities);
            var edges = _mapper.Map<List<DecisionEdgeDto>>(edgeEntities);

            var savedObject = DecisionTraveller.BuildFromEntity(tree, nodes, edges);
            wellScenarioParams.Trees = savedObject;

            User user = null;

            try
            {
                user = await _userService.GetAsync(wellScenarioParams.By);
            }
            catch (Exception)
            {
            }

            wellScenarioParams.By = user?.CAI;

            return wellScenarioParams;
        }

        public async Task<WellScenarioParams> GetTreeByTabIdAsync(Guid id)
        {
            if (id == null) throw new ArgumentNullException(nameof(id));

            var treeEntity = await _decisionRepository.GetLatestTreeAsync(id, _httpCurrentUser.Id);

            if (treeEntity == null) throw new WellScenarioNotFoundException(id.ToString());

            return await BuildFromEntity(treeEntity);
        }

        public async Task<IEnumerable<DecisionResultDto>> GetDecisionListAsync(string wellName)
        {
            if (wellName == null) throw new ArgumentNullException(nameof(wellName));

            var tabEntities = await _decisionRepository.GetScenarioTabListAsync(wellName, _httpCurrentUser.Id);

            var decisions = new HashSet<DecisionResultDto>();

            foreach (var tabEntity in tabEntities)
            {
                var result = new DecisionResultDto()
                {
                    Id = null,
                    RevId = tabEntity.RevId,
                    TabId = tabEntity.TabId,
                    WellName = tabEntity.WellName,
                    WellScenarioId = tabEntity.WellScenario?.Id,
                    Name = tabEntity.WellScenario?.Name,
                    ProblemType = tabEntity.WellScenario?.Resource?.Name,
                    Options = null,
                    Remark = null,
                    Status = tabEntity.Status,
                    By = null,
                    Created = null,
                };

                decisions.Add(result);
            }

            return decisions;
        }

        public async Task<DecisionResultDto> GetDecisionAsync(Guid tabId)
        {
            if (tabId == null) throw new ArgumentNullException(nameof(tabId));

            var tabEntity = await _decisionRepository.GetLatestTreeAsync(tabId, _httpCurrentUser.Id);
            if (tabEntity == null) throw new InvalidOperationException("Cannot find a given Scenario Tab Id.");

            var hasPublishedVersion = await _decisionRepository.CheckHasPublishedAsync(tabEntity);
            hasPublishedVersion = hasPublishedVersion && tabEntity.Status != GlobalConstants.STATUS_PUBLISHED;

            var treeEntity = tabEntity.WellScenario;
            if (treeEntity == null) throw new WellScenarioNotFoundException(nameof(tabEntity.WellName));

            var decisionOptionEntities = await _decisionRepository.ListDecisionOptionsAsync(treeEntity.Id);

            var decisionOptionNodeEntities = await _decisionRepository.ListDecisionOptionNodesAsync(decisionOptionEntities);

            var decisionOptions = _mapper.Map<HashSet<DecisionResultOptionDto>>(decisionOptionEntities);
            var decisionOptionNodes = _mapper.Map<HashSet<DecisionResultOptionNodeDto>>(decisionOptionNodeEntities);

            var decision = await _decisionRepository.GetDecisionResultAsync(tabEntity.RevId);

            foreach (var node in decisionOptionNodes)
            {
                if (node.ParentId == null)
                {
                    var option = decisionOptions.FirstOrDefault(x => x.Id == node.DecisionOptionId);

                    if (option == null) continue;

                    option.Root = node;

                    var matched = decision?.Decisions.Where(x => x.DecisionOptionId == option.Id).FirstOrDefault();
                    if (matched != null)
                    {
                        option.IsChosen = matched.IsChosen;
                        option.Remark = matched.Remark;
                    }
                    else
                    {
                        option.IsChosen = false;
                        option.Remark = string.Empty;
                    }
                }
                else
                {
                    var parent = decisionOptionNodes.FirstOrDefault(x => x.Id == node.ParentId);
                    if (parent != null)
                    {
                        parent.Scenarios.Add(node);
                    }
                }
            }

            var by = decision?.By ?? tabEntity.By;

            User user = null;

            try
            {
                user = await _userService.GetAsync(by);
            }
            catch (Exception)
            {
            }
            
            var result = new DecisionResultDto()
            {
                Id = decision?.Id,
                RevId = tabEntity.RevId,
                TabId = tabEntity.TabId,
                WellName = tabEntity.WellName,
                WellScenarioId = treeEntity.Id,
                Name = treeEntity.Name,
                ProblemType = treeEntity.Resource?.Name,
                Options = decisionOptions.OrderBy(x => x.Order).ToList(),
                Remark = decision?.Remark ?? string.Empty,
                Status = tabEntity.Status,
                HasPublishedVersion = hasPublishedVersion,
                By = user?.CAI,
                Created = decision?.Created ?? tabEntity.Created,
            };

            return result;
        }

        public async Task<DecisionResultDto> SaveDecisionAsync(DecisionResultDto decision)
        {
            return await MakeDecisionAsync(decision, GlobalConstants.STATUS_SAVED);
        }

        public async Task<DecisionResultDto> PublishDecisionAsync(DecisionResultDto decision)
        {
            return await MakeDecisionAsync(decision, GlobalConstants.STATUS_PUBLISHED);
        }

        public async Task DeleteDecisionAsync(Guid tabId)
        {
            if (tabId == null) throw new ArgumentNullException(nameof(tabId));

            await _decisionRepository.RemoveScenarioTabAsync(tabId, _httpCurrentUser.Id);
        }

        private async Task<DecisionResultDto> MakeDecisionAsync(DecisionResultDto decision, string status)
        {
            try
            {
                _decisionRepository.BeginTransaction();

                // Verify
                await VerifyDecisionOptions(decision);

                WellScenarioTab tabEntity = null;
                var isNewTabRequired = false;
                
                if (decision.TabId == null)
                {
                    isNewTabRequired = true;
                }
                else
                {
                    tabEntity = await _decisionRepository.GetLatestTreeAsync(decision.TabId.Value, _httpCurrentUser.Id);
                    if (tabEntity == null) throw new InvalidOperationException("Cannot find a given Scenario Tab Id.");

                    if (tabEntity.Status != status)
                        isNewTabRequired = true;
                }

                // Prepare author
                decision.By = _httpCurrentUser.Id;
                decision.Status = status;

                // Insert new scenario tab
                if (isNewTabRequired)
                {
                    tabEntity = await _decisionRepository.InsertScenarioTabAsync(decision);
                }

                // Insert decision group
                var decisionGroup = await _decisionRepository.InsertDecisionResultGroupAsync(decision);

                // Insert decision options in group
                await _decisionRepository.InsertDecisionResultsAsync(decision.Options, decisionGroup);

                // Display author CAI
                User user = null;

                try
                {
                    user = await _userService.GetAsync(decision.By);
                }
                catch (Exception)
                {
                }
                
                decision.By = user?.CAI;

                var hasPublishedVersion = await _decisionRepository.CheckHasPublishedAsync(tabEntity);
                hasPublishedVersion = hasPublishedVersion && tabEntity.Status != GlobalConstants.STATUS_PUBLISHED;

                decision.HasPublishedVersion = hasPublishedVersion;

                _decisionRepository.Commit();
            }
            catch (Exception ex)
            {
                _decisionRepository.Rollback();
                throw ex;
            }

            return decision;
        }

        private async Task VerifyDecisionOptions(DecisionResultDto decision)
        {
            var wellScenarioId = decision.WellScenarioId ?? throw new ArgumentNullException(nameof(decision.WellScenarioId));

            var allOptionEntities = await _decisionRepository.ListDecisionOptionsAsync(wellScenarioId);

            var isSuccess = decision.Options.Count > 0 && decision.Options.Count == allOptionEntities.Count() &&
                decision.Options.All(x => allOptionEntities.Any(y => y.Id == x.Id));

            if (!isSuccess)
            {
                throw new InvalidOperationException("Not all the decision options are supplied.");
            }
        }

        private async Task<WellScenarioParams> BuildFromEntity(WellScenarioTab tabEntity)
        {
            var treeEntity = tabEntity.WellScenario;
            var id = treeEntity.Id;

            var nodeEntities = await _decisionRepository.GetNodesAsync(id);
            var edgeEntities = await _decisionRepository.GetEdgesAsync(id);

            var wellScenarioParams = _mapper.Map<WellScenarioParams>(tabEntity);
            var tree = _mapper.Map<DecisionTreeDto>(treeEntity);
            var nodes = _mapper.Map<List<DecisionNodeDto>>(nodeEntities);
            var edges = _mapper.Map<List<DecisionEdgeDto>>(edgeEntities);

            var savedObject = DecisionTraveller.BuildFromEntity(tree, nodes, edges);
            wellScenarioParams.Trees = savedObject;

            User user = null;

            try
            {
                user = await _userService.GetAsync(wellScenarioParams.By);
            }
            catch (Exception)
            {
            }

            wellScenarioParams.By = user?.CAI;

            return wellScenarioParams;
        }

        public async Task<PresetWellScenarioParams> UpdateTemplateTreeAsync(PresetWellScenarioParams param)
        {
            var id = param.Id ?? throw new ArgumentNullException(nameof(param.Id));
            var trees = param.Trees ?? throw new ArgumentNullException(nameof(param.Trees));

            try
            {
                _decisionRepository.BeginTransaction();

                //Assign owner
                param.By = _httpCurrentUser.Id;

                //Get tree entity
                var presetWellScenario = await _decisionRepository.UpdateTemplateTreeAsync(param);

                //Deletes nodes and edges
                await _decisionRepository.DeleteTemplateNodesAndEdgesAsync(id);

                //Inserts new nodes and edges
                var result = DecisionTraveller.ExtractFromSavedObject(id, trees);
                var nodes = _mapper.Map<List<PresetWellScenarioNode>>(result.nodes);
                var edges = _mapper.Map<List<PresetWellScenarioEdge>>(result.edges);

                await _decisionRepository.CreateTemplateNodesAndEdgesAsync(nodes, edges);

                _decisionRepository.Commit();

                return param;
            }
            catch (Exception ex)
            {
                _decisionRepository.Rollback();
                throw ex;
            }
        }

        public async Task<WellScenarioParams> SaveTreeAsync(WellScenarioParams param)
        {
            var wellName = param.WellName ?? throw new ArgumentNullException(nameof(param.WellName));
            var trees = param.Trees ?? throw new ArgumentNullException(nameof(param.Trees));

            try
            {
                _decisionRepository.BeginTransaction();

                //Assign owner
                param.By = _httpCurrentUser.Id;
                param.Status = GlobalConstants.STATUS_SAVED;

                //Updates tree params
                var wellScenario = await _decisionRepository.InsertTreeAsync(param);

                //Inserts tree; new nodes and edges
                var result = DecisionTraveller.ExtractFromSavedObject(param.Id.Value, trees);
                var nodes = _mapper.Map<List<WellScenarioNode>>(result.nodes);
                var edges = _mapper.Map<List<WellScenarioEdge>>(result.edges);

                await _decisionRepository.CreateNodesAndEdgesAsync(nodes, edges);

                //Insert decision options
                await InsertDecisionOptionsAsync(wellScenario, param.Scenarios);
                
                await _decisionRepository.InsertScenarioTabAsync(param);

                _decisionRepository.Commit();

                return param;
            }
            catch (Exception ex)
            {
                _decisionRepository.Rollback();
                throw ex;
            }
        }

        private async Task InsertDecisionOptionsAsync(WellScenario scenario, IEnumerable<DecisionResultOptionNodeDto> options)
        {
            int i = 0;
            foreach (var option in options)
            {
                var _option = new DecisionResultOptionDto()
                {
                    Order = i++,
                    Inv = option.Inv,
                    Npv = option.Npv,
                    Dpi = option.Dpi,
                    TotalBranchCost = option.TotalBranchCost,
                };

                // Insert option
                var entity = await _decisionRepository.InsertDecisionOptionAsync(scenario, _option);

                // Insert nodes
                await InsertDecisionOptionNodesAsync(entity, new List<DecisionResultOptionNodeDto> { option });
            }
        }

        private async Task InsertDecisionOptionNodesAsync(DecisionOption option, IEnumerable<DecisionResultOptionNodeDto> nodes, DecisionOptionNode parent = null)
        {
            if (nodes == null) return;
            if (nodes.Count() == 0) return;

            foreach (var node in nodes)
            {
                // Insert nodes
                var entity = await _decisionRepository.InsertDecisionOptionNodeAsync(option, node, parent);

                if (node.Scenarios != null && node.Scenarios.Count > 0)
                {
                    // Loop through all the childrens
                    await InsertDecisionOptionNodesAsync(option, node.Scenarios, entity);
                }
            }
        }
    }
}