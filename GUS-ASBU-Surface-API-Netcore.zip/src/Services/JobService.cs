using System;

using System.Collections.Generic;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;

//logg
using Serilog;
using surflex.netcore22.Helpers;

//model
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using surflex.netcore22.Exceptions;


using JobProductiveAsync = surflex.netcore22.APIs.Gateway.JobProductiveAsync;
using JobAsync = surflex.netcore22.APIs.Model.JobAsync;
//using WellPlannedAsync = surflex.netcore22.APIs.Gateway.WellPlannedAsync;


using CACHE_KEY = surflex.netcore22.Models.Constants.CacheKeys;

using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;
using surflex.netcore22.APIs;
using surflex.netcore22.Model;
using Microsoft.Extensions.Caching.Memory;

namespace surflex.netcore22.Services
{
    public interface IJobService
    {
        //Task<Job> CreateAsync(Job job);

        //Task<JobProductive> CreateProductiveAsync(JobProductive job);
        // Task<Job> UpdateAsync(Job job);
        //Task<Job> DeleteAsync(string id);
        Task<Job> GetProductiveCostAsync(string name);
        Task<Job> GetPlannedAsync(string name);

        Task<IEnumerable<Job>> ListAsync();
        Task<IEnumerable<Job>> ListPlannedAsync(string[] name);

        Task<JobProductive> GetProductiveAsync(string name);

        Task<IEnumerable<JobProductive>> ListProductiveAsync(string[] name);

        //Task<JobProductive> GetLocalProductiveAsync(string id);
        //  Task<Job> EnforcePlannedJobExistenceAsync(string name);
        //Task<Job> GetLastestByWellAsync(string id);

        // Task<IEnumerable<JobProductiveAsync>> ListProductiveAsync(IEnumerable<WellPlannedAsync> wells);

        Task<IEnumerable<JobDrilledRate>> GetDrilledRateAsync(string name);

        //  Task<IEnumerable<JobProductive>> ListProductiveDaysAsync(string[] names);
        //Task<IEnumerable<JobProductive>> ListProductiveAsync(string[] names);

    }
    public class JobService : IJobService
    {
        private readonly IJobRepository _jobRepository;
        private readonly IMapper<JobProductiveAsync, JobProductive> _jobProductiveMapper;
        private readonly IMapper<IEnumerable<JobProductiveAsync>, IEnumerable<JobProductive>> _jobProductiveCollectionMapper;

        private readonly IMapper<JobAsync, Job> _singleMapper;
        // private readonly Models.Cache _cachingService;
        private readonly IMapper<IEnumerable<JobAsync>, IEnumerable<Job>> _collectionMapper;
        private readonly IMapper<IEnumerable<JobDrilledAsync>, IEnumerable<JobDrilledRate>> _collectionDrilledMapper;
        private readonly IEntityService _entityService;
        private readonly IMemoryCache _cache;


        public JobService(IJobRepository jobRepository, //IWellService wellService,
                                                    IMapper<JobProductiveAsync, JobProductive> jobProductiveMapper,
                                                     IMapper<JobAsync, Job> singleMapper,
                                                     IMapper<IEnumerable<JobAsync>, IEnumerable<Job>> collectionMapper,
                                                     IMapper<IEnumerable<JobDrilledAsync>, IEnumerable<JobDrilledRate>> collectionDrilledMapper, IEntityService entityService,
                                                      IMapper<IEnumerable<JobProductiveAsync>, IEnumerable<JobProductive>> jobProductiveCollectionMapper,
                                                     IMemoryCache memoryCache)//  Models.Cache cachingService)
        {
            _jobRepository = jobRepository ?? throw new ArgumentNullException(nameof(jobRepository));
            _jobProductiveMapper = jobProductiveMapper ?? throw new ArgumentNullException(nameof(jobProductiveMapper));

            _singleMapper = singleMapper ?? throw new ArgumentNullException(nameof(singleMapper));
            _collectionMapper = collectionMapper ?? throw new ArgumentNullException(nameof(collectionMapper));
            _collectionDrilledMapper = collectionDrilledMapper ?? throw new ArgumentNullException(nameof(collectionDrilledMapper));

            _jobProductiveCollectionMapper = jobProductiveCollectionMapper ?? throw new ArgumentNullException(nameof(jobProductiveCollectionMapper));
            _entityService = entityService ?? throw new ArgumentNullException(nameof(entityService));

            //   _cachingService = cachingService;
            _cache = memoryCache;
            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }

        public async Task<Job> CreateAsync(Job job)
        {
            //await this.EnforceWellExistenceAsync(job.WellId);
            //assigned
            job.Id = Guid.NewGuid().ToString();
            job.Created = Utility.CurrentSEAsiaStandardTime();
            //await EnforceClanExistenceAsync(Job.Clan.Name);
            var createdJob = await _jobRepository.CreateAsync(job);
            return createdJob;
        }

        /*  public async Task<JobProductive> CreateProductiveAsync(JobProductive job)
         {

             job.Id = Guid.NewGuid().ToString();
             job.Date = Utility.CurrentSEAsiaStandardTime();
             //job.da = Utility.CurrentSEAsiaStandardTime();
             //await EnforceClanExistenceAsync(Job.Clan.Name);
             var entity = await _jobRepository.CreateProductiveAsync(job);
             return entity;
         }*/

        /*   public async Task<Job> UpdateAsync(Job job)
          {
              var willUpdateJob = await this.EnforcePlannedJobExistenceAsync(job.Id);

              //assigned
              job.Created = Utility.CurrentSEAsiaStandardTime();
              job.Activity = job.Activity;
              job.Status = job.Status;

              var updatedJob = await _jobRepository.UpdateAsync(willUpdateJob);
              return updatedJob;
          }

          public async Task<Job> GetAsync(string id)
          {
              await this.EnforcePlannedJobExistenceAsync(id);

              var job = await _jobRepository.GetAsync(id);
              return job;
          }

          public async Task<Job> DeleteAsync(string id)
          {
              await this.EnforcePlannedJobExistenceAsync(id);

              var deletedJob = await _jobRepository.DeleteAsync(id);
              return deletedJob;
          }
        */


        /// <summary>
        /// get job productive by well name
        /// </summary>
        /// <returns>
        /// job report prodcutobe object
        /// </returns>
        /// <exception cref="System.Exception">Thrown when ??</exception>
        /// <param name="name">sand id</param>
        ///
        public async Task<JobProductive> GetProductiveAsync(string name)
        {

            JobProductive cahceProductive;
            // Look for cache key.
            if (_cache.TryGetValue(CACHE_KEY.JobProductives + name, out cahceProductive))
            {
                /// Log.Information("{0} _cache.TryGetValue CACHE_KEY.JobProductives > {1}", name, cahceProductive.ActualAFEDays);
                return cahceProductive;
            }

            //determine the wel satus by job
            var job = await _entityService.GetJobProductiveAsync(name);
            if (job == null)
            {
                throw new JobNotProductiveException();
            }
            //mapper
            var entity = _jobProductiveMapper.Mapp(job);


            //get rkb
            var rotary = await _entityService.GetJobRotaryAsync(name);
            if (rotary == null)
            {
                throw new JobNotProductiveException();
            }
            //calculate
            //mapper
            var mapped = _jobProductiveMapper.Mapp(rotary);

            //calculate
            entity.PlannedTVDSS = mapped.WellRkb - entity.PlannedTVD;
            entity.ActualTVDSS = mapped.WellRkb - entity.ActualTVD;

            //entity.TvdRkb = (-1) * entity.TvdRkb;


            //store data
            //_cachingService.JobProductives.Add(name, entity);
            // _cachingService.JobProductives.Remove(name);

            // Key not in cache, so get data.
            cahceProductive = entity;

            // Set cache options.
            var cacheEntryOptions = new MemoryCacheEntryOptions()
                // Keep in cache for this time, reset time if accessed.
                .SetSlidingExpiration(TimeSpan.FromHours(1));

            // Save data in cache.
            _cache.Set(CACHE_KEY.JobProductives + name, cahceProductive, cacheEntryOptions);

            return entity;
        }


        public async Task<Job> GetPlannedAsync(string name)
        {
            //determine the wel satus by job
            var job = await _entityService.GetPlannedJobAsync(name);

            if (job == null)
            {
                return null;
            }


            return _singleMapper.Mapp(job);
        }



        public async Task<Job> GetProductiveCostAsync(string name)
        {
            //determine the wel satus by job
            var job = await _entityService.GetJobProductiveCostAsync(name);
            if (job == null)
            {
                throw new JobNotFoundException();
            }

            return _singleMapper.Mapp(job);
        }

        /* public async Task<JobProductive> GetLocalProductiveAsync(string id)
        {
            //determine the wel satus by job
            var job = await _jobRepository.GetLocalProductiveAsync(new JobProductive() { Id = id });

            if (job == null)
            {
                throw new JobNotProductiveException();
            }

            return job;
        }*/

        public async Task<IEnumerable<Job>> ListAsync()
        {
            return await _jobRepository.ListAsync();
        }


        public async Task<IEnumerable<Job>> ListPlannedAsync(string[] name)
        {
            var entity = await _entityService.ListPlannedJobAsync(name);
            var mapped = _collectionMapper.Mapp(entity);

            return mapped;

        }



        // public async Task<Job> GetLastestByWellAsync(string id)
        // {

        //     //await this.EnforceWellExistenceAsync(id);

        //     return await _jobRepository.GetLastestByWellAsync(id);
        // }


        public async Task<IEnumerable<JobProductive>> ListProductiveAsync(string[] names)
        {
            //gen cahcig key
            var key = string.Join("", names);

            IEnumerable<JobProductive> cacheProjectProductive;
            // Look for cache key.
            if (_cache.TryGetValue(CACHE_KEY.ProjectProductive + key, out cacheProjectProductive))
            {
                //Log.Information("{0} _cache.TryGetValue CACHE_KEY.ProjectProductive > {1}", key, cacheProjectProductive.Sum(c => c.ActualCostAFE));
                return cacheProjectProductive;
            }

            var entity = await _entityService.ListJobProductiveAsync(names);
            var mapped = _jobProductiveCollectionMapper.Mapp(entity);

            // Save data in cache.
            // cacheProjectProductive = mapped;

            // Set cache options.
            var cacheEntryOptions = new MemoryCacheEntryOptions()
            // Keep in cache for this time, reset time if accessed.
                 .SetSlidingExpiration(TimeSpan.FromHours(1));


            _cache.Set(CACHE_KEY.ProjectProductive + key, cacheProjectProductive, cacheEntryOptions);


            return mapped;
        }


        //just day for perfomance
        // public async Task<IEnumerable<JobProductive>> ListProductiveDaysAsync(string[] names)
        // {

        //     var entity = await _entityService.ListJobProductiveDaysAsync(names);
        //     var mapped = _jobProductiveCollectionMapper.Mapp(entity);

        //     return mapped;

        // }


        //
        // Summary:
        //     Returns the drilled rate List of well by lastests
        //
        // Returns:
        //     list of lastedt drilled rate
        //
        // Type parameters:
        //   name:
        //     well name of the job
        //
        //

        public async Task<IEnumerable<JobDrilledRate>> GetDrilledRateAsync(string name)
        {
            var entity = await _entityService.GetJobDrilledRateAsync(name);
            if (entity == null)
            {
                throw new JobNotProductiveException();
            }

            var mapped = _collectionDrilledMapper.Mapp(entity);
            return mapped;
        }





    }

}