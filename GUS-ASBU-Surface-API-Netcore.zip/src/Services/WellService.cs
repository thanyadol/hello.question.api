using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using Microsoft.Extensions.Configuration;

//logg
using Serilog;


//model
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using surflex.netcore22.Exceptions;

//apis
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;

using surflex.netcore22.Helpers;
using surflex.netcore22.APIs;

using GLOBAL = surflex.netcore22.Models.Constants.GlobalConstants;
using DRILLED = surflex.netcore22.Models.Constants.Drilled;
using UNDRILLED = surflex.netcore22.Models.Constants.Undrilled;
using PRODUCTION = surflex.netcore22.Models.Constants.Production;

using CACHE_KEY = surflex.netcore22.Models.Constants.CacheKeys;

//validate
using FluentValidation;


//excel
//using OfficeOpenXml;

//properties
using System.Reflection;
using System.Text.RegularExpressions;
using surflex.netcore22.Extensions;
using surflex.netcore22.Helpers.TemplateProfile;
using surflex.netcore22.Helpers.DataHandler;
using System.Diagnostics;
using Microsoft.Extensions.Caching.Memory;

//apis
//using surflex.netcore22.APIs;

namespace surflex.netcore22.Services
{
    public class WellService : IWellService
    {
        // private readonly string WELL_DRILLED = "DRILLED";
        //private readonly string WELL_UNDRILLED = "UNDRILLED";
        private readonly IUserService _userService;


        private readonly IWellRepository _wellRepository;
        //  private readonly IWellReserveRepository _wellReserveRepository;
        private readonly IWellScenarioRepository _wellScenarioRepository;



        //private const string PREDEFINE = "PREDEFINE";


        // private const string CURRENT_YEAR_COLUMN_INDEX = "H";
        //private const string CURRENT_YEAR_SUMMARY_COLUMN_INDEX = "B";

        //private const decimal OPEX_CPP_RATIO = 0.2m;


        private const string SURFACE = "SURFACE";

        private readonly string FINAL_FELR_DATASOURCE = "FIN_FELR";
        private readonly string PRELIM_FELR_DATASOURCE = "FELR";



        private readonly User httpCurrentUser;
        //private readonly IMapper<JobProductiveAsync, JobProductive> _jobProductiveMapper;

        private readonly IJobService _jobService;
        private readonly IRiggService _riggService;
        private readonly ITemplateService _templateService;
        // private readonly IServiceFactory _serviceFactory;

        private readonly IMapper<IEnumerable<WellPlannedAsync>, IEnumerable<WellPlanned>> _wellPlannedMapper;
        private readonly IMapper<IEnumerable<WellPayAsync>, IEnumerable<WellPay>> _wellPayMapper;

        private readonly IMapper<IEnumerable<WellProductiveAsync>, IEnumerable<WellProductive>> _wellProductiveMapper;

        private readonly IMapper<WellJobProductiveAsync, WellJobProductive> _wellJobProductiveMapper;
        private readonly IMapper<WellReserveAsync, WellReserve> _wellReserveMapper;

        private readonly IPathFinderService _pathFinderService;
        //private readonly IProjectWellService _projectService;
        private readonly IProjectWellService _projectWellService;

        private readonly IPriceService _priceService;
        private readonly IResourceService _resourceService;

        private readonly IProductionService _productionService;
        private readonly AbstractValidator<TemplateValidateParams> _templateValidator;
        private readonly IAttachmentService _attachementService;

        private readonly IWellPropertiesRepository _wellPropertiesRepository;

        private readonly IWellSpaceRepository _wellSpaceRepository;
        private readonly IWellDrilledRepository _wellDrilledRepository;
        private readonly IWellUndrilledRepository _wellUndrilledRepository;
        private readonly IWellActivityRepository _wellActivityRepository;

        private readonly ISandService _sandService;
        private readonly IWorkUnitService _workUnitService;

        // private readonly IMapper<surflex.netcore22.APIs.Model.Platform, surflex.netcore22.Models.Platform> _platformMapper;

        private readonly AbstractValidator<Models.Platform> _platformValidator;
        private readonly AbstractValidator<WellEvaluateParams> _wellValidator;
        private readonly IConfiguration _configuration;

        private readonly IHttpService _httpService;
        private readonly IEntityService _entityService;
        private readonly IClientService _clientService;
        private readonly IMemoryCache _cache;
        // private readonly Serilog.ILogger Logg;
        //  private readonly Models.Cache _cachingService;

        //private readonly IProjectWellService _projectService;
        public WellService(IWellRepository wellRepository, IJobService jobService, IMapper<IEnumerable<WellPlannedAsync>, IEnumerable<WellPlanned>> wellPlannedMapper,
                                IMapper<IEnumerable<WellProductiveAsync>, IEnumerable<WellProductive>> wellProductiveMapper,
                                IMapper<WellReserveAsync, WellReserve> wellWellReserveMapper, IMapper<WellJobProductiveAsync, WellJobProductive> wellJobProductiveMapper, //IWellReserveRepository wellReserveRepository,
                                IRiggService riggService, ITemplateService templateService, IWellScenarioRepository wellScenarioRepository,
                                IUserService userService, AbstractValidator<TemplateValidateParams> templateValidator, IAttachmentService attachementService,
                                IPathFinderService pathFinder, IProjectWellService projectWellService, IPriceService priceService, IResourceService resourceService,
                                IProductionService productionService, IWellPropertiesRepository wellPropertiesRepository, IWellActivityRepository wellActivityRepository,
                                IWellSpaceRepository wellSpaceRepository, IWellDrilledRepository wellDrilledRepository, IWellUndrilledRepository wellUndrilledRepository,
                                ISandService sandService, AbstractValidator<Models.Platform> platformValidator, IWorkUnitService workUnitService,
                                IEntityService entityService, IClientService clientService, IMapper<IEnumerable<WellPayAsync>, IEnumerable<WellPay>> wellPayMapper, IHttpService httpService, IConfiguration configuration,
                                AbstractValidator<WellEvaluateParams> wellValidator, IMemoryCache memoryCache)// Models.Cache cachingService)
        // IMapper<surflex.netcore22.APIs.Model.Platform, surflex.netcore22.Models.Platform> platformMapper)
        {
            _wellRepository = wellRepository ?? throw new ArgumentNullException(nameof(wellRepository));
            // _projectService = projectService ?? throw new ArgumentNullException(nameof(projectService));

            _jobService = jobService ?? throw new ArgumentNullException(nameof(jobService));
            _wellPlannedMapper = wellPlannedMapper ?? throw new ArgumentNullException(nameof(wellPlannedMapper));
            _wellProductiveMapper = wellProductiveMapper ?? throw new ArgumentNullException(nameof(_wellProductiveMapper));
            _wellReserveMapper = wellWellReserveMapper ?? throw new ArgumentNullException(nameof(wellWellReserveMapper));

            _wellPayMapper = wellPayMapper ?? throw new ArgumentNullException(nameof(wellPayMapper));

            //    _wellReserveRepository = wellReserveRepository ?? throw new ArgumentNullException(nameof(wellReserveRepository));
            _wellScenarioRepository = wellScenarioRepository ?? throw new ArgumentNullException(nameof(wellScenarioRepository));

            _templateService = templateService ?? throw new ArgumentNullException(nameof(templateService));

            _wellJobProductiveMapper = wellJobProductiveMapper ?? throw new ArgumentNullException(nameof(wellJobProductiveMapper));
            _riggService = riggService ?? throw new ArgumentNullException(nameof(riggService));
            _templateValidator = templateValidator ?? throw new ArgumentNullException(nameof(templateValidator));

            _attachementService = attachementService ?? throw new ArgumentNullException(nameof(attachementService));

            _pathFinderService = pathFinder ?? throw new ArgumentNullException(nameof(pathFinder));

            //_projectService = projectService ?? throw new ArgumentNullException(nameof(projectService));
            _priceService = priceService ?? throw new ArgumentNullException(nameof(priceService));
            _resourceService = resourceService ?? throw new ArgumentNullException(nameof(resourceService));

            _productionService = productionService ?? throw new ArgumentNullException(nameof(productionService));
            _wellPropertiesRepository = wellPropertiesRepository ?? throw new ArgumentNullException(nameof(wellPropertiesRepository));


            _wellSpaceRepository = wellSpaceRepository ?? throw new ArgumentNullException(nameof(wellSpaceRepository));
            _wellDrilledRepository = wellDrilledRepository ?? throw new ArgumentNullException(nameof(wellDrilledRepository));
            _wellUndrilledRepository = wellUndrilledRepository ?? throw new ArgumentNullException(nameof(wellUndrilledRepository));
            _wellActivityRepository = wellActivityRepository ?? throw new ArgumentNullException(nameof(wellActivityRepository));

            _sandService = sandService ?? throw new ArgumentNullException(nameof(sandService));
            _platformValidator = platformValidator ?? throw new ArgumentNullException(nameof(platformValidator));

            _projectWellService = projectWellService ?? throw new ArgumentNullException(nameof(projectWellService));

            //_wellActivityRepository = wellActivityRepository ?? throw new ArgumentNullException(nameof(wellActivityRepository));
            _userService = userService ?? throw new ArgumentNullException(nameof(userService));
            _workUnitService = workUnitService ?? throw new ArgumentNullException(nameof(workUnitService));

            _entityService = entityService ?? throw new ArgumentNullException(nameof(entityService));
            _clientService = clientService ?? throw new ArgumentNullException(nameof(clientService));

            _httpService = httpService ?? throw new ArgumentNullException(nameof(httpService));
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));

            _wellValidator = wellValidator ?? throw new ArgumentNullException(nameof(wellValidator));
            //  _platformMapper = platformMapper ?? throw new ArgumentNullException(nameof(platformMapper));

            //_cachingService = cachingService;

            _cache = memoryCache;
            httpCurrentUser = _httpService.GetHttpCurrentUserAsync().Result;

            //var path = $"assets/logs";

            //logg
            // Logg = new LoggerConfiguration()
            //   .MinimumLevel.Debug()
            //   .WriteTo.RollingFile($@"{path}/debug.txt", retainedFileCountLimit: 7)
            //   //.WriteTo.Sink(new EntityLogEventSink())
            //   .CreateLogger();
        }


        public async Task<Well> CreateAsync(Well well)
        {
            //await this.EnforceProjectExistenceAsync(well.ProjectId);

            //assigned
            well.Id = Utility.ToUniqeIdentity(well.Name);
            well.Created = Utility.CurrentSEAsiaStandardTime();

            //var well = new Well();

            //assigned
            well.Name = well.Name.ToUpper();
            //well.Id = id;
            well.Created = Utility.CurrentSEAsiaStandardTime();
            well.By = httpCurrentUser.Id;

            //await EnforceClanExistenceAsync(Well.Clan.Name);
            var entity = await _wellRepository.CreateAsync(well);
            return entity;

        }

        public async Task<Well> EnforceWellCreateAsync(Well well)
        {
            var id = Utility.ToUniqeIdentity(well.Name);
            var enforece = await _wellRepository.GetAsync(id);
            if (enforece != null)
            {
                return enforece;
            }

            //await EnforceClanExistenceAsync(Well.Clan.Name);
            var entity = await this.CreateAsync(well);
            return entity;
        }


        public async Task<Well> UpdateAsync(Well well)
        {
            var willUpdateWell = await this.EnforceWellExistingAsync(well.Id);

            //assigned
            well.Created = Utility.CurrentSEAsiaStandardTime();
            well.Name = well.Name;
            // well.By = httpCurrentUser.Id;

            var updatedWell = await _wellRepository.UpdateAsync(willUpdateWell);
            return updatedWell;
        }


        public async Task<Well> GetAsync(string id)
        {
            // await this.EnforceExistenceAsync(id);

            var well = await _wellRepository.GetAsync(id);
            return well;
        }

        public async Task<WellProductive> GetProductiveStatusAsync(string name)
        {
            //await this.EnforceExistenceAsync(id);
            var productive = new WellProductive(name);

            //productive phase --activity
            var well = await _entityService.GetLatestWellPhaseAsync(name);


            if (well != null)
            {
                string[] temp = new string[] { well.WellPhase, well.PhaseFirst,
                well.PhaseSecond, well.CasingSize };

                productive.Activity = String.Join("-", temp.Where(c => !String.IsNullOrEmpty(c)));
                productive.Phase = well.PhaseFirst;
                productive.WellPhase = well.WellPhase;
            }

            //determine the wel satus by job
            var job = await _jobService.GetPlannedAsync(name);
            productive.Status = this.GetStatus(job, productive.WellPhase);

            return productive;
        }

        public async Task<Well> DeleteAsync(string id)
        {
            await this.EnforceWellExistingAsync(id);

            var entity = await _wellRepository.DeleteAsync(id);
            return entity;
        }


        //
        // Summary:
        //     retrun the well of  RLLCP
        //
        // Returns:
        //
        //   list of  Models.Entity.WellProperties object
        //
        // Type parameters:
        //   rllcp:
        //     RLLCP project id
        //

        public async Task<IEnumerable<WellPlanned>> ListPlannedAsync(int rllcp, bool status = false)
        {

            //RLLCP
            var entities = await _entityService.ListPlannedWellAsync(rllcp);
            if (entities == null)
            {
                throw new WellNotFoundException();
            }

            var well1st = entities.FirstOrDefault();

            //UIDM
            /*  var result = await _wellRepository.ListProductiveAsync(well);
             if (result == null)
             {
                 throw new WellNotProductiveException();
             }*/

            //map name UIDM (sidetrack, redirll, horizonal)
            var wells = await _entityService.ListPlannedProductiveAsync(entities.Select(c => c.Name).ToArray());

            var mappes = _wellPlannedMapper.Mapp(wells).OrderBy(c => c.Name);
            //with status
            if (status == true)
            {
                var entity = new List<WellPlanned>();
                var jobs = await _jobService.ListPlannedAsync(mappes.Select(c => c.Name).ToArray());


                foreach (var item in mappes)
                {
                    var j = jobs.Where(c => c.WellName == item.Name).FirstOrDefault();

                    //var j = await _jobService.GetAsync(item.Name);
                    var w = GetStatus(j, item.WellPhase);

                    //change name logic
                    /*if (w == PLANNED)
                    {
                        item.Name = item.Name.Replace("-", " ");
                    }*/

                    //assigned !!!! important
                    item.Project = well1st.Project;
                    item.Platform = well1st.Platform;
                    item.RLLCPProjectId = rllcp;
                    item.OperationArea = well1st.OperationArea;
                    item.Asset = well1st.Asset;
                    item.ProjectId = well1st.ProjectId.ToString();


                    //item.RLLCPId = project.Id;
                    item.Status = w;

                    entity.Add(item);
                }

                return entity;
            }
            else
            {
                // entity.Select(c => { ).ToList();
                return mappes.Select(c => { c.RLLCPProjectId = rllcp; c.ProjectId = rllcp.ToString(); return c; }).ToList();
            }
        }


        //
        // Summary:
        //     retrun the is SOR update for noti user
        //
        // Returns:
        //
        //   list of  Models.Entity.WellProperties object
        //
        // Type parameters:
        //   rllcp:
        //     list of well name (productive name)
        //

        public async Task<IEnumerable<SimpleWellPlanned>> ListSORNotificationAsync(IEnumerable<SimpleWellPlanned> wells)
        {
            //RLLCP
            //adcompatred SOR date
            var sands = await _sandService.ListProductiveAsync(wells.Select(c => c.Name).ToArray());
            var entity = new List<SimpleWellPlanned>();

            foreach (var item in wells)
            {
                var ids = Utility.ToUniqeIdentity(item.Name);
                //
                var drilled = await _wellDrilledRepository.GetRecentlyAsync(ids, httpCurrentUser.Id);
                if (drilled == null)
                {
                    item.IsSORUpdated = false;
                }
                else
                {
                    //check owner
                    //if (drilled.By != httpCurrentUser.Id)
                    //{
                    var temp = sands.Where(c => c.WellName == item.Name).FirstOrDefault();
                    item.IsSORUpdated = temp == null ? false : temp.SORUpdatedDate > drilled.ActivityDate;
                    //}
                }

                entity.Add(item);
            }
            return entity;
        }

        public async Task<Well> EnforceWellExistingAsync(string id)
        {
            var well = await _wellRepository.GetAsync(id);

            if (well == null)
            {
                throw new WellNotFoundException();
            }

            return well;
        }


        public async Task<IEnumerable<WellProductive>> ListProductiveAsync()
        {
            //mapper 
            var well = await _entityService.ListWellProductiveAsync();
            if (well == null)
            {
                throw new WellNotProductiveException();
            }

            return _wellProductiveMapper.Mapp(well);
        }

        /* private async Task EnforceProjectExistenceAsync(string id)
        {
            var projectExist = await _projectService.IsProjectExistsAsync(id);
            if (!projectExist)
            {r
                throw new ProjectNotFoundException();
            }
        }*/


        /* public async Task<WellReserve> CreateWellReserveAsync(WellReserve well)
        {
            //await this.EnforceProjectExistenceAsync(well.ProjectId);

            //assigned
            well.Id = Guid.NewGuid().ToString();
            well.Date = Utility.CurrentSEAsiaStandardTime();

            //await EnforceClanExistenceAsync(Well.Clan.Name);
            var entity = await _wellRepository.CreateWellReserveAsync(well);
            return entity;
        }*/


        /* public async Task<WellReserve> GetRecentlyWellReserveAsync(string name) //, string id = null)
        {
            //IServiceProvider provider = GetServiceProvider();
            // var sandService = provider.GetService(typeof(ISandService));
            //var serviceCollection = new Microsoft.Extensions.DependencyInjection.ServiceCollection();
            //string sandid = "hello";
            var sand = await _wellRepository.GetRecentlySandAsync(name);
            if (sand == null)
            {
                var job = await _wellRepository.GetPlannedWellReserveAsync(name);

                if (job == null)
                {
                    throw new WellNotPlannedException();
                }

                var entity = _wellReserveMapper.Mapp(job);
                //entity.Datasource = "SURFACE";
                entity.CreatedDate = Utility.CurrentSEAsiaStandardTime();

                //persist ???
                return entity;
            }

            //sandid = sand.Id;
            //check enforce and select way
            var well = await _wellRepository.GetRecentlyWellReserveAsync(sand.Id);
            //get new reserve
            if (well == null)
            {
                var job = await _wellRepository.GetPlannedWellReserveAsync(name);

                if (job == null)
                {
                    throw new WellNotPlannedException();
                }

                var entity = _wellReserveMapper.Mapp(job);
                //entity.Datasource = "SURFACE";
                entity.CreatedDate = Utility.CurrentSEAsiaStandardTime();

                //persist ???
                return entity;

            }

            return well;
        }*/

        /*  public async Task<WellReserve> GetPlannedWellReserveAsync(string name) //, string id = null)
         {
             var well = await _wellRepository.GetPlannedWellReserveAsync(name);
             if (well == null)
             {
                 throw new WellNotPlannedException();
             }


             return _wellReserveMapper.Mapp(well);
         }


         private async Task<WellReserve> EnforceWellReserveExistenceAsync(string id)
         {
             var reserve = await _wellRepository.GetRecentlyWellReserveAsync(id);

             if (reserve == null)
             {
                 throw new WellReserveNotFoundException();
             }

             return reserve;
         }*/




        //
        // Summary:
        //    Return key (oil gas) value pair of default UDV analogy by well sand from TCRS endpoint
        //
        // Returns:
        //     pair of Analogy class
        //
        // Type parameters:
        //   name:
        //    well name
        //

        public async Task<WellAnalogy> GetUDVAnalogyAsync(string name)
        {


            try
            {
                var entity = await _clientService.GetWellUDVAnalogyAsync(name);
                var result = new WellAnalogy
                {
                    OilAnalogyDataSetID = entity.OilAnalogyDataSetID,
                    OilAnalogyDataSetName = entity.OilAnalogyDataSetName,
                    OilAnalogyScenarioID = entity.OilAnalogyScenarioID,
                    OilAnalogyScenarioName = entity.OilAnalogyScenarioName,
                    OilArea = entity.OilArea,
                    GasAnalogyDataSetID = entity.GasAnalogyDataSetID,
                    GasAnalogyDataSetName = entity.GasAnalogyDataSetName,
                    GasAnalogyScenarioID = entity.GasAnalogyScenarioID,
                    GasAnalogyScenarioName = entity.GasAnalogyScenarioName,
                    GasArea = entity.GasArea,
                    WellName = entity.WellName,
                };


                return result;
            }
            catch (ClientNotSuccessException)
            {
                throw new WellAnalogyNotFoundException();
            }

            /*  var dictionary = new Dictionary<string, Analogy>()
             {
                  {  "Oil",
                     new Analogy()
                     {
                         AnalogyDataSetID = entity.OilAnalogyDataSetID,
                         AnalogyDataSetName = entity.OilAnalogyDataSetName,
                         AnalogyScenarioID = entity.OilAnalogyScenarioID,
                         AnalogyScenarioName = entity.OilAnalogyScenarioName,
                         GasArea = entity.OilArea
                     }
                  },
                  {  "Gas",
                     new Analogy()
                     {
                         AnalogyDataSetID = entity.GasAnalogyDataSetID,
                         AnalogyDataSetName = entity.GasAnalogyDataSetName,
                         AnalogyScenarioID = entity.GasAnalogyScenarioID,
                         AnalogyScenarioName = entity.GasAnalogyScenarioName,
                         GasArea = entity.GasArea
                     }
                 },
             };*/

        }

        //
        // Summary:
        //     Returns the  planned reserve from RLLCP with liquid ratio
        //
        // Returns:
        //     Models.Entity.WellReserve object
        //
        // Type parameters:
        //   name:
        //      well name
        //
        //

        public async Task<WellReserve> GetPlannedReserveAsync(string name)
        {

            // WellReserve reserve;
            // if (_cachingService.PlannedReserves.TryGetValue(name, out reserve))
            // {
            //     Log.Information("cachingService.PlannedReserves.TryGetValue {0}, {1}", name, reserve.Value);
            //     return reserve;
            // }

            WellReserve cacheReserve;
            // Look for cache key.
            if (_cache.TryGetValue(CACHE_KEY.PlannedReserves + name, out cacheReserve))
            {

                //  Log.Information("{0} _cache.TryGetValue CACHE_KEY.PlannedReserves > {1}", name, cacheReserve.Value);
                return cacheReserve;
            }

            //var sw = new Stopwatch();
            //sw.Start();

            var well = await _entityService.GetWellPlannedWellReserveAsync(name);

            // Log.Information(name);

            if (well == null)
            {
                throw new WellNotPlannedException();
            }

            var entity = _wellReserveMapper.Mapp(well);

            entity.Value = entity.TruncatedWellReserveInMBOE;
            entity.Type = ReserveType.PLANNED.GetDescription();

            entity.WellName = name;

            //for separate liqoud and gas reserve
            if (entity.TruncatedWellReserveInMBOE > 0)
            {
                entity.PlannedLiquidRatio = (entity.PlannedOil + entity.PlannedCondy) / entity.TruncatedWellReserveInMBOE;
            }

            //cahcing
            //store data
            //_cachingService.PlannedReserves.Remove(name);
            //   _cachingService.PlannedReserves.Add(name, entity);


            // Key not in cache, so get data.
            cacheReserve = entity;

            // Set cache options.
            var cacheEntryOptions = new MemoryCacheEntryOptions()
                // Keep in cache for this time, reset time if accessed.
                .SetSlidingExpiration(TimeSpan.FromHours(1));

            // Save data in cache.
            _cache.Set(CACHE_KEY.PlannedReserves + name, cacheReserve, cacheEntryOptions);


            //sw.Stop();
            //Log.Information("{1} GetPlannedReserveAsync Elapsed={0}", sw.Elapsed, name);

            return entity;
        }


        public async Task<WellJobProductive> GetActualProductiveAsync(string name)
        {
            var welljob = await _entityService.GetWellUndrilledReserveAsync(name);

            if (welljob == null)
            {
                throw new WellNotProductiveException();
            }

            var entity = _wellJobProductiveMapper.Mapp(welljob);

            return entity;
        }


        private string GetStatus(Job job, string phase)
        {
            var status = WellStatus.PLANNED.GetDescription();
            if (job == null)
            {
                return status;
            }

            //determine the wel satus by job

            //well.WellPhase = "COMP";
            //end date is null (still drill)
            if (job.EndDate == null)
            {

                switch (phase)
                {
                    case "DRLG":
                        status = WellStatus.DRILLING.GetDescription();
                        break;

                    case "GEOLEVAL":
                    case "COMP":
                        status = WellStatus.TUBING.GetDescription();
                        break;
                    default:
                        status = WellStatus.PLANNED.GetDescription();
                        break;
                }

            }
            else
            {
                status = WellStatus.COMPLETED.GetDescription();
            }

            return status;
        }

        //for reserve
        /* public async Task<WellReserve> CreateAsync(WellReserve reserve)
        {
            //await this.EnforceWellExistenceAsync(reserve.WellId);
            //assigned
            reserve.Id = Guid.NewGuid().ToString();
            reserve.Date = Utility.CurrentSEAsiaStandardTime();

            //await EnforceClanExistenceAsync(WellReserve.Clan.Name);
            var entity = await _wellReserveRepository.CreateAsync(reserve);
            if (entity == null)
            {
                throw new WellReserveNotFoundException();
            }

            return entity;
        }

        public async Task<WellReserve> UpdateAsync(WellReserve reserve)
        {
            var re = await this.EnforceWellReserveExistenceAsync(reserve.Id);

            var entity = await _wellReserveRepository.UpdateAsync(re);
            if (entity == null)
            {
                throw new WellReserveNotFoundException();
            }

            return entity;
        }

        public async Task<WellReserve> GetReserveAsync(string id)
        {
            //  await this.EnforceWellReserveExistenceAsync(id);

            var reserve = await _wellReserveRepository.GetAsync(id);
            return reserve;
        }

        //
        // Summary:
        //     Returns the  / drilled / undrilled reserve
        //
        // Returns:
        //     Models.Entity.WellReserve object
        //
        // Type parameters:
        //   id:
        //     by sandid
        //
        //
        public async Task<WellReserve> GetRecentlyReserveAsync(string timestamp)
        {
            // await this.EnforceWellReserveExistenceAsync(id);

            var entity = await _wellReserveRepository.GetRecentlyAsync(timestamp);
            if (entity == null)
            {
                throw new WellReserveNotFoundException();
            }


            return entity;

        }

        /* Task<WellReserve> GetPlannedAsync(string name)
        {
            var entity = await _reserveRepository.GetPlannedAsync(name);
            return entity;
        }*

        public async Task<WellReserve> DeleteReserveAsync(string id)
        {
            await this.EnforceWellReserveExistenceAsync(id);

            var entity = await _wellReserveRepository.DeleteAsync(id);
            return entity;
        }

        public async Task<IEnumerable<WellReserve>> ListReserveAsync()
        {
            return await _wellReserveRepository.ListAsync();
        }

        public async Task<WellReserve> EnforceWellReserveExistenceAsync(string id)
        {
            var reserve = await _wellReserveRepository.GetAsync(id);

            if (reserve == null)
            {
                throw new WellReserveNotFoundException();
            }

            return reserve;
        }*/


        //scenario
        public async Task<PresetWellScenario> CreateAsync(PresetWellScenario scenario)
        {
            var currentTime = Utility.CurrentSEAsiaStandardTime();
            scenario.Id = Guid.NewGuid();
            scenario.Created = currentTime;
            scenario.Updated = currentTime;
            scenario.By = httpCurrentUser.Id;

            if (scenario.Status == null)
            {
                scenario.Status = GLOBAL.STATUS_ACTIVE;
            }

            var entity = await _wellScenarioRepository.CreateAsync(scenario);
            if (entity == null)
            {
                throw new WellScenarioNotFoundException();
            }

            return entity;
        }

        public async Task<PresetWellScenario> UpdateAsync(PresetWellScenario scenario)
        {
            var updated = await this.EnforceWellScenarioExistenceAsync(scenario.Id);

            //assigned
            //scenario.Created = Utility.CurrentSEAsiaStandardTime();
            updated.Status = scenario.Status;
            updated.Name = scenario.Name;

            //scenario.By = httpCurrentUser.Id;

            var entity = await _wellScenarioRepository.UpdateAsync(updated);
            if (entity == null)
            {
                throw new WellScenarioNotFoundException();
            }

            return entity;
        }

        public async Task<PresetWellScenario> GetScenarioAsync(Guid id)
        {
            //  await this.EnforceScenarioExistenceAsync(id);

            var entity = await _wellScenarioRepository.GetAsync(id);
            return entity;
        }


        public async Task<IEnumerable<PresetWellScenario>> ListScenarioAsync()
        {
            return await _wellScenarioRepository.ListAsync();
        }

        public async Task<PresetWellScenario> EnforceWellScenarioExistenceAsync(Guid id)
        {
            var act = await _wellScenarioRepository.GetAsync(id);

            if (act == null)
            {
                throw new WellScenarioNotFoundException(id.ToString());
            }

            return act;
        }

        public async Task<WellDecisionParams> InitialDecisionParamsAsync(string name)
        {
            //get job
            var job = await _jobService.GetProductiveAsync(name);

            var actual = await this.GetActualProductiveAsync(name);
            if (actual == null)
            {
                throw new WellNotProductiveException();
            }

            var productive = await _entityService.GetWellProductiveAsync(name);
            if (productive == null)
            {
                throw new WellNotProductiveException();
            }

            //sum
            var drilleds = await _jobService.GetDrilledRateAsync(name);

            //get active template
            var template = await _templateService.GetCurrentlyAsync(GLOBAL.RIGG_TEMPLATE_ID);
            var rates = await _riggService.ListRateAsync(template.Id);

            //filter by name
            var rate = rates.Where(c => c.RiggId == Utility.ToUniqeIdentity(productive.RiggName)).FirstOrDefault();
            if (rate == null)
            {
                throw new RiggNotFoundException();
            }

            //construct
            var result = new WellDecisionParams()
            {
                PlannedTD = job.PlannedMD,
                WellName = name,
                //CalculatedRiggRate = rates,

                CalculatedRiggRate = rate,
                ActualJobProductive = actual,

                RiggName = rate.RiggName,
                // UsedTemplate = template,

                ActualMDStartCalculateDepth = actual.ActualMDStartCalculateDepth,
                StartDepthOfProductionSection = actual.ActualMDStartCalculateDepth,

                TIHRate = rate.TIH,
                TOHRate = rate.TOH,

                RigRate = drilleds.Sum(c => c.RateInHour).GetValueOrDefault(),

                //TotalTime = 0,
            };


            return result;
        }

        //dpi
        public async Task<FluentValidation.Results.ValidationResult> ValidateDPITemplateAsync(Attachment attach)
        {

            //string WELL_DPI_TEMPLATE_SHEET_PITA3 = "PITA III";
            //string WELL_DPI_TEMPLATE_SHEET_THAI3 = "THAI III (PITA IV) for no SRB";

            //var attach = await _attachementService.EnforceAttachmentExistenceAsync(template.AttachmentId);


            /* var temp = await _templateService.GetTypeAsync(attach.TemplateTypeId);
            if (temp == null)
            {
                throw new TemplateNotFoundException();
            }

            ExcelWorksheet ws = await _attachementService.GetWorkbookAsync(attach, PRODUCTION.MAPPED_WORK_SHEET[temp.Title]);

            string VALIDATE_RULE_SET = temp.Title;
            //var w = await BeforeExtractAsync(attach);
            //extract
            var parameter = new TemplateValidateParams()
            {
                Extensions = attach.Extension,
                SheetName = ws.Name,

                //Items = null,
                TemplateId = attach.UploadTemplateId
            };

            DataTable dt = await this.ExtractDPITemplateAsync(ws);

            //read work sheet for validate
            // int col = Utility.ParseExcelColumnToIndex("A");

            var items = new LocationTextPair[] {
                 new LocationTextPair("A", 1, dt.Rows[1 - 1]["A"].ToString()),
                 new LocationTextPair("A", 32,dt.Rows[32 - 1]["A"].ToString())
            };

            parameter.Items = items.ToList();
            //vlidate
            var flag = _templateValidator.Validate(parameter, ruleSet: VALIDATE_RULE_SET);
            //var flag = await this.ValidateTemplateAsync(attach, workbook);
            if (flag.IsValid != true)
            {
                //rollback
                //await _templateService.RollbackAsync(template.LastActiveTemplateIdForRollback, RecordStatus.ACTIVE.GetDescription());

                //remove template 
                // await _templateService.DeleteAsync(template.Id);
                //await _attachementService.DeleteAsync(template.AttachmentId);


                throw new Exception(flag.Errors.FirstOrDefault().ErrorMessage);
            }

            return flag;*/
            await Task.Delay(0);
            throw new NotImplementedException();
        }

        //extract only 
        private async Task<DataTable> ExtractDPITemplateAsync(Attachment attachment, string sheet, bool hasHeader = true)
        {
            /* await Task.Delay(0);
            string[] cols = new string[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S",
                                                "T", "U", "V", "W", "X", "Y", "Z"};

            //await Task.Delay(0);
            // DataTable tbl = new DataTable();

            const int END_EXTRACT_ROW = 33;
            const int END_EXTRACT_COL = 1;

            //attachemtn
            Byte[] bytes = Convert.FromBase64String(attachment.Value);
            //var path = await _pathFinderService.FindAsync(attach.Id + attach.Extension);

            //open
            Aspose.Cells.Worksheet ws;
            using (var stream = new MemoryStream(bytes))
            {
                var engine = new ExcelEngine(stream);
                var pck = engine.Excel;

                //validate sheet
                ws = pck.Worksheets[sheet];
            }

            if (ws == null)
            {
                throw new AttachmentNotValidException(attachment.Id);
            }

            if (ws.Cells == null)
            {
                throw new AttachmentNotValidException(attachment.Id);
            }

            // hasHeader = false;
            DataTable tbl = new DataTable();

            Aspose.Cells.Range range = ws.Cells.MaxDisplayRange;

            var firstRow = ws.Cells.Rows[0];
            var startCol = 0;

            for (int i = startCol; i < END_EXTRACT_COL /*range.ColumnCount*; i++)
            {
                // Aspose.Cells.Cell cell = ws.Cells.GetCell(0, i);

                //with no hearder
                tbl.Columns.Add(cols[i]);
            }

            //shift for data
            int startRow = 1;
            for (int rowNum = startRow; rowNum <= range.RowCount - startRow; rowNum++)
            {
                var wsRow = ws.Cells.Rows[rowNum];

                //buffer for merged cell
                DataRow row = tbl.Rows.Add();

                for (int j = startCol; j < /* range.ColumnCount* END_EXTRACT_COL; j++)
                {
                    try
                    {

                        Aspose.Cells.Cell cell = wsRow.GetCellOrNull(j);
                        row[j] = cell.StringValue;
                    }
                    catch (NullReferenceException ex)
                    {
                        throw ex;
                    }

                }
            }

            return tbl;*/

            await Task.Delay(0);
            throw new NotImplementedException();
        }

        //
        // Summary:
        //     Returns evaluation DPI / NPI / DPV
        //
        // Returns:
        //     Models.Entity.WellReserve object
        //
        // Type parameters:
        //   well:
        //     wellname
        //   project :  
        //      project name
        //   platform :  
        //      platform name
        //
        public async Task<IEnumerable<ProductionProfileParams>> EstimateYearlyProductAsync(WellEvaluateParams p)  ///genm profile  EvaluateMasterDPIAsync
        {

            var entities = new List<ProductionProfileParams>();

            //await Task.Delay(0);
            int currentYear = Utility.CurrentSEAsiaStandardTime().Year;
            //var reserves = await this.InitialReserveParamsAsync(p.Project, p.RLLCPProjectId);

            //sum of reserve
            // var summ = new WellProductiveReserve
            // {
            //     GasInMMscf = p.Reserve.GasInMMSCF.GetValueOrDefault(),
            //     OilInMSTB = p.Reserve.LiquidInMBOE.GetValueOrDefault(),
            // };

            //project setup
            var attribute = await _projectWellService.GetCurrentlyAttributeAsync(p.Project);
            if (attribute == null)
            {
                throw new ProjectAttributeNotFoundException();
            }

            //production rate //get by attribute id
            var product = await _productionService.GetCurentlyProductAsync(attribute.ProductionProfileId);
            if (product == null)
            {
                throw new ProductionNotFoundException();
            }

            //attribute.ApplicableModelId = ApplicableModel.SEPARATE.GetDescription();

            //select way
            if (attribute.ApplicableModelId == ApplicableModel.SEPARATE.GetDescription())  //SEPARATE MODEL
            {
                var parameters = new ProductionProfileParams()
                {
                    //for dec check
                    // UndrilledReserve = summ,

                    SelectedAttribute = attribute,
                    ApplicableModel = "OIL",
                    PeriodType = "YEARLY",
                    CurrentDay = 1,
                    SelectedStartDate = attribute.OilProjectStartDate.GetValueOrDefault(),
                };

                //GOR
                var GOR = p.Reserve.GasInMMSCF.GetValueOrDefault() / Utility.ParseMBOEToBOE(p.Reserve.LiquidInMBOE.GetValueOrDefault());

                //transform to project level
                //attribute
                //OIL
                parameters.Reserve = new WellReserve() { Value = Utility.ParseMMSCFtoMMBTU(p.Reserve.LiquidInMBOE.GetValueOrDefault()) };

                //get rate
                var rate = await _productionService.EvaluateProfileRateAsync(product.OilProfile, parameters.Reserve);

                //transform to project level
                rate.Value = rate.Value; // * attribute.TotalPlannedWell.GetValueOrDefault();
                rate.AbandonmentRate = rate.AbandonmentRate; // * attribute.TotalPlannedWell.GetValueOrDefault();

                parameters.PickedProfileRate = rate;

                // Log.Information(Newtonsoft.Json.JsonConvert.SerializeObject(parameters));

                var estimate = await _productionService.EstimateRemainProductionAsync(parameters);

                //sum year
                parameters.PeriodPlots = estimate.Plots.GroupBy(r => r.CurrentDate.Value.Year)
                                        .Select(g => new ProductionVolumn()
                                        {
                                            Year = g.Key,
                                            //  Month = g.Key.Month,
                                            TotalValue = g.Sum(c => c.TotalValue),
                                        }).ToList();

                entities.Add(parameters);



                //GAS -> Condensate (gas * CGR)   * continue day
                var __parameters = new ProductionProfileParams()
                {
                    SelectedAttribute = attribute,
                    ApplicableModel = "GAS",
                    //  CurrentDay = parameters.ContinueDay,
                    PeriodType = "YEARLY",
                    SelectedStartDate = attribute.GasProjectStartDate.GetValueOrDefault(),
                };

                __parameters.Reserve = new WellReserve() { Value = p.Reserve.GasInMMSCF.GetValueOrDefault() };

                //get rate
                var __rate = await _productionService.EvaluateProfileRateAsync(product.GasProfile, __parameters.Reserve);

                //transform to project level
                __rate.Value = __rate.Value; // * attribute.TotalPlannedWell;
                __rate.AbandonmentRate = __rate.AbandonmentRate; // * attribute.TotalPlannedWell;

                __parameters.PickedProfileRate = __rate;

                var __estimate = await _productionService.EstimateRemainProductionAsync(__parameters);

                //sum
                __parameters.PeriodPlots = __estimate.Plots.GroupBy(r => r.CurrentDate.Value.Year)
                                        .Select(g => new ProductionVolumn()
                                        {
                                            Year = g.Key,
                                            //   Month = g.Key.Month,
                                            TotalValue = g.Sum(c => c.TotalValue),
                                        }).ToList();

                entities.Add(__parameters);


            }
            else  //SPECIFIC MODEL
            {
                var parameters = new ProductionProfileParams()
                {
                    //for dec check
                    //UndrilledReserve = summ,

                    SelectedAttribute = attribute,
                    //  ApplicableModel = "OIL",
                    PeriodType = "YEARLY",
                    CurrentDay = 1,
                };

                var liquid = Utility.ParseMMSCFtoMMBTU(p.Reserve.LiquidInMBOE.GetValueOrDefault());
                var gas = p.Reserve.GasInMMSCF.GetValueOrDefault();


                var coeff = 0m;

                //GOR
                var CGR = liquid / gas;

                //GOR
                var GOR = gas / liquid;

                var rate = new ProductionProfile();
                if (attribute.ApplicableModelId == ApplicableModel.OIL.GetDescription())
                {
                    parameters.ApplicableModel = ApplicableModel.OIL.GetDescription();
                    parameters.Reserve = new WellReserve()
                    {
                        Value = liquid
                    };

                    rate = await _productionService.EvaluateProfileRateAsync(product.OilProfile, parameters.Reserve);


                    parameters.SelectedStartDate = attribute.OilProjectStartDate.GetValueOrDefault();
                    //swap
                    coeff = GOR;
                }
                else
                {
                    parameters.ApplicableModel = ApplicableModel.GAS.GetDescription();
                    parameters.Reserve = new WellReserve()
                    {
                        Value = gas
                    };

                    //get rate
                    rate = await _productionService.EvaluateProfileRateAsync(product.GasProfile, parameters.Reserve);
                    parameters.SelectedStartDate = attribute.GasProjectStartDate.GetValueOrDefault();

                    coeff = CGR;
                }

                //check compatibility
                if (rate.Value == null)
                {
                    throw new ProductionNotFoundException();
                }

                //transform to project level
                rate.Value = rate.Value; // * attribute.TotalPlannedWell;
                rate.AbandonmentRate = rate.AbandonmentRate; // * attribute.TotalPlannedWell;

                parameters.PickedProfileRate = rate;

                var estimate = await _productionService.EstimateRemainProductionAsync(parameters);

                //sum
                parameters.PeriodPlots = estimate.Plots.GroupBy(r => r.CurrentDate.Value.Year)
                                            .Select(g => new ProductionVolumn()
                                            {
                                                Year = g.Key,
                                                //  Month = g.Key.Month,
                                                TotalValue = g.Sum(c => c.TotalValue),
                                            }).ToList();

                entities.Add(parameters);

                //mutata
                var mutate = parameters.DeepClone();

                mutate.ApplicableModel = parameters.ApplicableModel == ApplicableModel.GAS.GetDescription() ? ApplicableModel.OIL.GetDescription()
                                                    : ApplicableModel.GAS.GetDescription();


                //assigned platofirm
                mutate.GOR = GOR;
                mutate.CGR = CGR;

                mutate.PeriodPlots = mutate.PeriodPlots.Select(c => { c.TotalValue = c.TotalValue * coeff; return c; }).ToList();

                entities.Add(mutate);
            }


            return entities;

        }



        //
        // Summary:
        //    estimate default undrilled reserve by wellname (name)
        //
        // Returns:
        //     Models.Entity.WellReserve object
        //
        // Type parameters:
        //   name:
        //     wellname
        //

        // public async Task<WellReserveParams> EstimateUndrilledReserveAsync(string name)
        // {
        // }


        //
        // Summary:
        //    CRUD op well propertied for project summary
        //
        // Returns:
        //     Models.Entity.WellProperties object
        //
        // Type parameters:
        //   WellProperties:
        //     well props attribute
        //

        public async Task<WellProperties> CreateAsync(WellProperties properties)
        {
            //await this.EnforceWellExistenceAsync(WellProperties.WellId);
            //assigned
            properties.Id = Guid.NewGuid().ToString();
            properties.Created = Utility.CurrentSEAsiaStandardTime();

            properties.By = httpCurrentUser.Id;

            // properties.Description = "hello this is a new attachemnt from dev";

            //new rev and key
            //properties.Rev = Guid.NewGuid().ToString();
            //properties.Key = Guid.NewGuid().ToString();

            //await EnforceClanExistenceAsync(WellProperties.Clan.Name);
            var entity = await _wellPropertiesRepository.CreateAsync(properties);
            if (entity == null)
            {
                throw new WellPropertiesNotFoundException(properties);
            }

            return entity;
        }

        public async Task<WellProperties> UpdateAsync(WellProperties properties)
        {
            var updated = await this.EnforceWellPropertiesExistenceAsync(properties.Id);

            //assigned
            //properties.Date = Utility.CurrentSEAsiaStandardTime();

            updated.FaultBlock = updated.FaultBlock;
            updated.BatchNumber = updated.BatchNumber;
            updated.DrillingOrder = updated.DrillingOrder;
            updated.ChartOrder = updated.ChartOrder;
            updated.Type = updated.FaultBlock;

            updated.Description = updated.Description;
            updated.IsIncludeToCalculated = updated.IsIncludeToCalculated;

            properties.By = httpCurrentUser.Id;

            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //properties.Key = Guid.NewGuid().ToString();

            var entity = await _wellPropertiesRepository.UpdateAsync(properties);
            if (entity == null)
            {
                throw new WellPropertiesNotFoundException(properties);
            }

            return entity;
        }

        public async Task<IEnumerable<WellProperties>> ListPropertiesAsync()
        {
            var entity = await _wellPropertiesRepository.ListAsync();

            //by name
            return entity.OrderBy(c => c.Name); // !important to calculate checked well
        }


        public async Task<WellProperties> GetPropertiesAsync(string id)
        {
            //  await this.EnforceWellPropertiesExistenceAsync(id);

            var entity = await _wellPropertiesRepository.GetAsync(id);
            return entity;
        }


        /*  public async Task<WellProperties> DeleteAsync(string id)
         {
             await this.EnforceWellPropertiesExistenceAsync(id);

             var entity = await _wellPropertiesRepository.DeleteAsync(id);
             return entity;
         }*/


        //
        // Summary:
        //     retrun the well properties list mapping with RLLCP
        //
        // Returns:
        //
        //   list of  Models.Entity.WellProperties object
        //
        // Type parameters:
        //   rllcp:
        //     RLLCP project id
        //   name
        //      SURFACE project name
        //   rllcp
        //     id of project summary       
        //

        public async Task<IEnumerable<WellProperties>> SyncePropertiesAsync(int rllcp, string name, string id)
        {
            //match RLLCP well with own DB
            //RLLCP

            var wells = await this.ListPlannedAsync(rllcp, true);
            if (!wells.Any())
            {
                throw new WellNotFoundException("no planned well");
            }

            //orders
            wells = wells.OrderBy(c => c.Name);

            //wells = wells.      //extract string
            // var mappes = _wellPlannedMapper.Mapp(wells);
            int count = await _projectWellService.GetDefaultPlannedWellAsync(name);

            //list proops
            var props = await _wellPropertiesRepository.ListAsync();
            // var ids = Utility.ToUniqeIdentity(name);
            props = props.Where(c => c.ProjectWellId == id);

            //join
            var entity = new List<WellProperties>();
            int order = props.Max(c => c.ChartOrder).GetValueOrDefault() + 1;

            foreach (var w in wells)
            {

                //filter by check box
                //should pattern mapped
                var hashset = new HashSet<string>(new string[] { w.Name });

                var temp = props.Where(c => hashset.ContainSidetrack(c.Name)).FirstOrDefault();
                if (temp == null)
                {
                    //default
                    temp = new WellProperties()
                    {
                        WellId = Utility.ToUniqeIdentity(w.Name),
                        ProjectWellId = id,
                        // Name = w.Name,
                        ChartOrder = order
                    };
                }

                //swap to productive name
                temp.Name = w.Name;

                //offet
                //temp.DatasourceDateOffset = temp.DatasourceDate.GetValueOrDefault().GetOffset();

                //check !!!
                if (order <= count)
                {
                    temp.IsIncludeToCalculated = true;
                }

                order++;
                entity.Add(temp);
            }

            //pathc SOR
            entity = await this.ListSORAsync(entity);

            //by name
            return entity.OrderBy(c => c.Name); // !important to calculate checked well
        }

        private async Task<List<WellProperties>> ListSORAsync(List<WellProperties> wells)
        {

            var entity = new List<WellProperties>();
            var sands = await _entityService.ListSandAsync(wells.Select(c => c.Name).ToArray());

            foreach (var w in wells)
            {

                //GET SOR
                var ids = Utility.ToUniqeIdentity(w.Name);
                var drilled = await _wellDrilledRepository.GetRecentlyAsync(ids, httpCurrentUser.Id);
                if (drilled == null)
                {
                    //drilled = await this.SynceDrilledAsync(w.Name, name, Utility.ToPlaformIdentity(name));
                    var sand = sands.FirstOrDefault(c => c.WellName == w.Name);
                    if (sand != null)
                    {
                        drilled = new WellDrilled() { Datasource = sand.DataSource, SORUpdatedDate = sand.UpdatedDate };

                    }
                }

                //set SOR
                w.Datasource = drilled != null ? drilled.Datasource : null;
                w.DatasourceDate = drilled != null ? drilled.SORUpdatedDate : null;

                w.IsSynceDatasource = true;

                entity.Add(w);

            }

            return entity;
        }


        public async Task<WellProperties> EnforceWellPropertiesExistenceAsync(string id)
        {
            var act = await _wellPropertiesRepository.GetAsync(id);

            if (act == null)
            {
                throw new WellPropertiesNotFoundException();
            }

            return act;
        }


        //activity

        //for activity
        public async Task<WellActivity> CreateAsync(WellActivity activity)
        {
            //await this.EnforceWellExistenceAsync(WellActivity.WellId);
            //assigned
            activity.Id = Guid.NewGuid(); //.ToString();
            activity.Date = Utility.CurrentSEAsiaStandardTime();

            //await EnforceClanExistenceAsync(WellActivity.Clan.Name);
            var entity = await _wellActivityRepository.CreateAsync(activity);
            if (entity == null)
            {
                throw new WellActivityNotFoundException();
            }


            return entity;
        }

        public async Task<WellActivity> UpdateAsync(WellActivity activity)
        {
            var updated = await this.EnforceWellActivityExistenceAsync(activity.Id);

            //assigned
            //WellActivity.Created = Utility.CurrentSEAsiaStandardTime();
            //WellActivity.WellActivity = WellActivity.WellActivity;
            //WellActivity.Status = WellActivity.Status;

            var entity = await _wellActivityRepository.UpdateAsync(activity);
            if (entity == null)
            {
                throw new WellActivityNotFoundException();
            }

            return entity;
        }

        public async Task<WellActivity> GetActivityAsync(Guid id)
        {
            //  await this.EnforceWellActivityExistenceAsync(id);

            var entity = await _wellActivityRepository.GetAsync(id);
            return entity;
        }


        //
        // Summary:
        //     basic CRUD, Returns the lastest activity of updaed sabd in a row
        //
        // Returns:
        //     Models.Entity.Sand object
        //
        // Type parameters:
        //   name:
        //     well name
        //
        /* public async Task<WellActivity> GetRecentlyActivityAsync(string key)
        {
            //  await this.EnforceWellActivityExistenceAsync(id);

            var entity = await _wellActivityRepository.ListAsync();
            return entity.Where(c => c.Key == key).OrderByDescending(c => c.Date).FirstOrDefault();
        }*/

        public async Task<IEnumerable<WellActivity>> ListActivityAsync()
        {
            return await _wellActivityRepository.ListAsync();
        }


        public async Task<WellActivity> EnforceWellActivityExistenceAsync(Guid id)
        {
            var act = await _wellActivityRepository.GetAsync(id);

            if (act == null)
            {
                throw new WellActivityNotFoundException();
            }

            return act;
        }




        //well space

        //
        // Summary:
        //     retrun the well properties of publish well
        //
        // Returns:
        //
        //   list of  Models.Entity.WellProperties object
        //
        // Type parameters:
        //   id:
        //      well space id
        //
        public async Task<WellSpace> PublishAsync(Guid id)
        {
            //is well existitng    
            var well = await this.EnforceWellSpaceExistenceAsync(id);

            //create activity
            var created = new WellActivity(id, "NA", ActivityAction.PUBLISHED.GetDescription(), httpCurrentUser.Id);
            created.Id = Guid.NewGuid();
            created.Date = Utility.CurrentSEAsiaStandardTime();
            var activity = await _wellActivityRepository.CreateAsync(created);

            well.ActivityDate = activity.Date;
            well.ActivityType = activity.Action;

            var user = await _userService.GetAsync(activity.By);
            well.By = user.CAI;

            return (well);
        }

        public async Task<WellSpace> CreateAsync(WellSpace space)
        {
            var id = Utility.ToUniqeIdentity(space.WellName);
            var well = await _wellRepository.GetAsync(id);
            if (well == null)
            {
                throw new WellNotFoundException();
            }

            space.Id = Guid.NewGuid();

            //assigned
            space.WellId = id;
            space.WellName = well.Name;
            // well.RLLCPReferenceId = well.RLLCPReferenceId;
            space.Created = Utility.CurrentSEAsiaStandardTime();
            //  space.Status = RecordStatus.ACTIVE.GetDescription();
            space.By = httpCurrentUser.Id;

            var entity = await _wellSpaceRepository.CreateAsync(space);
            return entity;

        }


        public async Task<WellSpace> UpdateAsync(WellSpace space)
        {
            var updated = await this.EnforceWellSpaceExistenceAsync(space.Id);


            var entity = await _wellSpaceRepository.UpdateAsync(space);
            if (entity == null)
            {
                throw new WellNotFoundException();
            }

            return entity;
        }

        public async Task<WellSpace> EnforceWellSpaceExistenceAsync(Guid id)
        {
            var space = await _wellSpaceRepository.GetAsync(id);

            if (space == null)
            {
                throw new WellNotFoundException();
            }

            return space;
        }

        public async Task<IEnumerable<WellSpace>> ListSpaceAsync()
        {
            return await _wellSpaceRepository.ListAsync();
        }

        public async Task<WellSpace> GetSpaceAsync(Guid id)
        {
            return await _wellSpaceRepository.GetAsync(id);
        }

        ///drilled

        public async Task<WellDrilled> CreateAsync(WellDrilled drilled)
        {
            //var ids = Utility.ToUniqeIdentity(space.WellName);
            var well = await this.EnforceWellSpaceExistenceAsync(drilled.WellSpaceId);
            if (well == null)
            {
                throw new WellNotFoundException();
            }

            drilled.Rev = Guid.NewGuid().ToString();
            drilled.Key = Guid.NewGuid().ToString();

            //assigned
            //well.Name = well.Name.ToUpper();
            // well.RLLCPReferenceId = well.RLLCPReferenceId;
            drilled.Created = Utility.CurrentSEAsiaStandardTime();
            drilled.StartDate = Utility.CurrentSEAsiaStandardTime();

            //drilled.Status = ACTIVE;
            drilled.By = httpCurrentUser.Id;

            var entity = await _wellDrilledRepository.CreateAsync(drilled);
            return entity;
        }


        public async Task<WellDrilled> UpdateAsync(WellDrilled drilled)
        {
            var updated = await this.EnforceDrilledExistenceAsync(drilled.Id);


            var entity = await _wellDrilledRepository.UpdateAsync(drilled);
            if (entity == null)
            {
                throw new WellNotFoundException();
            }

            return entity;
        }

        public async Task<WellDrilled> EnforceDrilledExistenceAsync(Guid id)
        {
            var entity = await _wellDrilledRepository.GetAsync(id);
            if (entity == null)
            {
                throw new WellDrilledNotFoundException();
            }

            return entity;
        }

        public async Task<IEnumerable<WellDrilled>> ListDrilledAsync()
        {
            return await _wellDrilledRepository.ListAsync();
        }

        public async Task<WellDrilled> GetDrilledAsync(Guid id)
        {
            return await _wellDrilledRepository.GetAsync(id);
        }

        //undrilled
        ///drilled
        public async Task<WellUndrilled> CreateAsync(WellUndrilled drilled)
        {
            //var ids = Utility.ToUniqeIdentity(space.WellName);
            var well = await this.EnforceWellSpaceExistenceAsync(drilled.WellSpaceId);
            if (well == null)
            {
                throw new WellNotFoundException();
            }

            drilled.Rev = Guid.NewGuid().ToString();
            drilled.Key = Guid.NewGuid().ToString();

            //assigned
            //well.Name = well.Name.ToUpper();
            // well.RLLCPReferenceId = well.RLLCPReferenceId;
            //drilled.Created = Utility.CurrentSEAsiaStandardTime();
            drilled.StartDate = Utility.CurrentSEAsiaStandardTime();

            //drilled.Status = ACTIVE;
            drilled.By = httpCurrentUser.Id;

            var entity = await _wellUndrilledRepository.CreateAsync(drilled);
            return entity;
        }


        public async Task<WellUndrilled> UpdateAsync(WellUndrilled drilled)
        {
            var updated = await this.EnforceDrilledExistenceAsync(drilled.Id);


            var entity = await _wellUndrilledRepository.UpdateAsync(drilled);
            if (entity == null)
            {
                throw new WellNotFoundException();
            }

            return entity;
        }

        public async Task<WellUndrilled> EnforceUndrilledExistenceAsync(Guid id)
        {
            var entity = await _wellUndrilledRepository.GetAsync(id);
            if (entity == null)
            {
                throw new WellUndrilledNotFoundException();
            }

            return entity;
        }

        public async Task<IEnumerable<WellUndrilled>> ListUndrilledAsync()
        {
            return await _wellUndrilledRepository.ListAsync();
        }

        public async Task<WellUndrilled> GetUndrilledAsync(Guid id)
        {
            return await _wellUndrilledRepository.GetAsync(id);
        }


        //
        // Summary:
        //     retrun the recently by project name, RLLCP project id
        //
        // Returns:
        //
        //   ProjectWell object
        //
        // Type parameters:
        //  rllcp
        //      rllcp project id
        //   nanme:
        //      project name
        //
        //
        public async Task<WellDrilled> GetDrilledRecentlyAsync(string name)
        {
            var id = Utility.ToUniqeIdentity(name);
            //var well = await _wellService.EnforceWellExistingAsync(id);

            var entity = await _wellDrilledRepository.GetRecentlyAsync(id, httpCurrentUser.Id);
            if (entity == null)
            {
                throw new WellDrilledNotFoundException();
            }

            //platform
            /* var platform = new Models.Platform()
            {
                GOR = entity.GOR,
                CGR = entity.CGR,
                BcCompressionRatio = entity.BcCompressionRatio,

                BcPos = entity.BcPos,
                GasPipelinePressureCoeff = entity.GasPipelinePressureCoeff,
                OilPipelinePressureCoeff = entity.OilPipelinePressureCoeff,
                PipelinePressure = entity.PipelinePressure
            };*/
            // entity.Platform = platform;

            //get recet activity
            //get publisher
            if (entity.By == httpCurrentUser.Id)
            {
                entity.IsPublisher = true;
            }

            //set properties
            var sands = await _sandService.ListAsync();
            entity.Sands = sands.Where(c => c.WellDrilledId == entity.Id).ToList();

            //get user cai
            var user = await _userService.GetAsync(entity.By);
            entity.By = user == null ? entity.By : user.CAI;

            return entity;
        }


        //
        // Summary:
        //     retrun the recently by project name, RLLCP project id
        //
        // Returns:
        //
        //   ProjectWell object
        //
        // Type parameters:
        //  rllcp
        //      rllcp project id
        //   nanme:
        //      project name
        //
        //
        public async Task<WellUndrilled> GetUndrilledRecentlyAsync(string name)
        {
            var id = Utility.ToUniqeIdentity(name);
            //var well = await this.EnforceWellExistingAsync(id);

            var entity = await _wellUndrilledRepository.GetRecentlyAsync(id, httpCurrentUser.Id);
            if (entity == null)
            {
                throw new WellUndrilledNotFoundException();
            }

            //get recet activity
            //get publisher
            if (entity.By == httpCurrentUser.Id)
            {
                entity.IsPublisher = true;
            }

            //set properties
            //var sands = await _sandService.ListAsync();
            //entity.Sands = sands.Where(c => c.WellDrilledId == entity.Id).ToList();

            //get user cai
            var user = await _userService.GetAsync(entity.By);
            entity.By = user == null ? entity.By : user.CAI;

            return entity;
        }



        //
        // Summary:
        //    Return calculaed drilled sand from TCRS endpoint
        //
        // Returns:
        //     Sand object
        //
        // Type parameters:
        //   sand:
        //     sand  to calculate
        //
        public async Task<WellDrilled> CalculateDrilledAsync(WellDrilled drilled)
        {

            int completeCalculate = 0;
            decimal drilledWellReserve = 0;

            //from header;
            var platform = new Models.Platform()
            {
                GOR = drilled.GOR,
                CGR = drilled.CGR,
                PipelinePressure = drilled.PipelinePressure,
                BcPos = drilled.BcPos,
                BcCompressionRatio = drilled.BcCompressionRatio,
                OilPipelinePressureCoeff = drilled.OilPipelinePressureCoeff,
                GasPipelinePressureCoeff = drilled.GasPipelinePressureCoeff,

                Name = drilled.PlatformName,
                WellType = drilled.WellType,
            };

            //validate platform
            var res = _platformValidator.Validate(platform);
            if (!res.IsValid)
            {
                var msg = res.Errors.FirstOrDefault().ErrorMessage;
                throw new PlatformNotValidException(msg);
            }

            var entities = drilled.Sands;
            if (entities == null)
            {
                throw new SandNotFoundException();
            }

            for (int i = 0; i < entities.ToArray().Length; i++)
            {
                var sandd = entities[i];

                //validate by sand
                var flag = await _sandService.ValidateAsync(sandd);
                if (!flag.IsValid)
                {
                    var msg = flag.Errors.FirstOrDefault().ErrorMessage;
                    //throw new PlatformNotValidException(msg);

                    //mutate //mapper
                    var mutated = await _sandService.ClearP1DNAsync(sandd);
                    mutated.ErrorMessage = msg;

                    entities[i] = mutated;
                    continue;
                }


                //cal completed check
                var called = await _sandService.CalculateP1DNAsync(sandd, platform);
                if (called.IsTCRSCompletedCalculated == true)
                {
                    completeCalculate++;
                    //drilledWellReserve = drilledWellReserve + called.P1;

                    //roll up sum
                    if (!Utility.EnforceIsContainedAZI(called.OpenWorksContactCategory))
                    {

                        drilledWellReserve += called.HCLiquidWithBC.GetValueOrDefault() + called.HCGasWithBC.GetValueOrDefault();
                    }
                }


                //add
                entities[i] = called;
            }

            drilled.TotalCalculateRecord = entities.Count();
            drilled.CompleteCalculatedRecord = completeCalculate;

            drilled.CalculatedWellReserve = drilledWellReserve;
            drilled.CalculatedTimestamp = Utility.ToUnixTimestamp(Utility.CurrentSEAsiaStandardTime()).ToString().Replace(".", "");


            //await _wellService.CreateAsync(new WellReserve(sand.WellReserve.GetValueOrDefault(), sand.Type, sand.CalculatedTimestamp, httpCurrentUser.Id));

            //persiste cal activity
            await this.CreateAsync(new WellActivity() { Action = ActivityAction.CALCULATED.GetDescription(), WellSpaceId = drilled.WellSpaceId, By = httpCurrentUser.Id, Discriminator = ReserveType.DRILLED.GetDescription() });

            //update reserve and time stamp


            return drilled;
        }



        //
        // Summary:
        //    Return calculaed undrilled sand from TCRS endpoint
        //
        // Returns:
        //     Sand object
        //
        // Type parameters:
        //   sand:
        //     sand  to calculate
        //
        public async Task<WellUndrilled> CalculateUndrilledAsync(WellUndrilled undrilled)
        {
            //int completeCalculate = 0;
            decimal total = 0;
            if (undrilled.IsCalculatedReserve == true)
            {
                total = undrilled.LiquidInMBOE.GetValueOrDefault() + (Utility.ParseMMSCFtoMBOE(undrilled.GasInMMScf.GetValueOrDefault()));

            }
            else
            {
                //                var planned = await this.GetPlannedReserveAsync(undrilled.WellName);
                var
                    reserve = await this.GetPlannedReserveAsync(undrilled.WellName);


                total = undrilled.TotalInMBOE.GetValueOrDefault();

                //liquid
                undrilled.LiquidInMBOE = total * reserve.PlannedLiquidRatio;

                //gas
                undrilled.GasInMMScf = Utility.ParseMBOEToMMSCF(total - undrilled.LiquidInMBOE.GetValueOrDefault());

            }

            //convert and sum
            undrilled.CalculatedWellReserve = total;
            //   sand.CompleteCalculatedRecord = completeCalculate;

            undrilled.CalculatedTimestamp = Utility.ToUnixTimestamp(Utility.CurrentSEAsiaStandardTime()).ToString().Replace(".", "");

            // await _wellService.CreateAsync(new WellReserve(sand.WellReserve.GetValueOrDefault(), sand.Type, sand.CalculatedTimestamp, httpCurrentUser.Id));
            //await this.CreateAsync(new WellActivity() { Action = ActivityAction.CALCULATED.GetDescription(), WellSpaceId = undrilled.WellSpaceId, By = httpCurrentUser.Id, Discriminator = ReserveType.UNDRILLED.GetDescription() });

            //update reserv and time stamp    


            return undrilled;
        }




        //
        // Summary:
        //    Return the validation result of sand at calculate before sending to TCRS
        //
        // Returns:
        //     Fluentvalidate.ValidationResult object
        //
        // Type parameters:
        //   sand:
        //     sand productive to calculate
        //
        public async Task<IEnumerable<Item>> ListUndrilledMethodAsync()
        {
            await Task.Delay(0);

            return UNDRILLED.METHOD;
        }


        //
        // Summary:
        //     Returns the refresh drilled sand for well
        //
        // Returns:
        //     Models.Entity.Sand object
        //
        // Type parameters:
        //   well:
        //     well name of the sand
        //   project:
        //     project name of the sand
        //   platform:
        //     platform name of the sand
        //
        public async Task<WellDrilled> SynceDrilledAsync(string well, string project, string platform)
        {
            //mocking openwork data
            var pppp = await _clientService.GetDefaultPlatformAsync(platform);
            if (pppp == null)
            {
                throw new WellNotFoundException();
            }

            //determine analogy
            var analogy = await this.GetUDVAnalogyAsync(well);

            // well = "SAWH-33";
            var productive = await _sandService.SynceAsync(well, project, analogy);
            if (!productive.Any())
            {
                throw new SandNotFoundException();
            }

            //source should be grouped
            var lastest = productive.GroupBy(p => new { p.SORUpdatedDate, p.DataSource },
                                        (key, g) => new WellDrilled { SORUpdatedDate = key.SORUpdatedDate, Datasource = key.DataSource });
            if (lastest.Count() > 1)
            {
                throw new SandNotValidException();
            }
            var temp = lastest.FirstOrDefault();

            var entity = new WellDrilled()
            {
                ProjectName = project,

                WellName = well.ToUpper(),

                // !!!mportant for updatedate OR grouped sand
                SORUpdatedDate = temp.SORUpdatedDate,
                Datasource = temp.Datasource,

                Sands = productive.ToList(),
                //By = httpCurrentUser.Id,
                Created = Utility.CurrentSEAsiaStandardTime(),

                By = SURFACE,
                ActivityType = ActivityAction.SYNCED.GetDescription(),
                ActivityDate = Utility.CurrentSEAsiaStandardTime(),

                GOR = pppp.GOR,
                CGR = pppp.CGR,
                BcCompressionRatio = pppp.BCCompressionRatio,

                BcPos = pppp.BCPos,
                GasPipelinePressureCoeff = pppp.GasPipelineCoeff,
                OilPipelinePressureCoeff = pppp.OilPipelineCoeff,
                PipelinePressure = pppp.PipelinePressure,


                WellType = this.GetDefaultWellType(productive)

                /* Platform = new Models.Platform()
                {

                    GOR = pppp.GOR,
                    CGR = pppp.CGR,
                    BcCompressionRatio = pppp.BCCompressionRatio,

                    BcPos = pppp.BCPos,
                    GasPipelinePressureCoeff = pppp.GasPipelineCoeff,
                    OilPipelinePressureCoeff = pppp.OilPipelineCoeff
                    PipelinePressure = pppp.PipelinePressure
                },*/

            };

            //

            await this.CreateAsync(new WellActivity() { Action = ActivityAction.SYNCED.GetDescription(), By = httpCurrentUser.Id, Discriminator = ReserveType.DRILLED.GetDescription() });
            return entity;

        }


        //
        // Summary:
        //     Returns the merged user recent sand with synce SOR (am report/ ferim /fin)
        //
        // Returns:
        //     Models.Entity.Sand object
        //
        // Type parameters:
        //   id:
        //     sand-id of the sand
        //
        public async Task<WellDrilled> MergeDrilledAsync(WellDrilled drilled)
        {
            //is sand existitng    
            var current = await this.GetDrilledRecentlyAsync(drilled.WellName);
            if (current == null)
            {
                throw new WellDrilledNotFoundException();
            }

            var platform = await _clientService.GetDefaultPlatformAsync(drilled.PlatformName);
            if (platform == null)
            {
                throw new PlatformNotFoundException();
            }

            var analog = await this.GetUDVAnalogyAsync(drilled.WellName);


            var lastest = await _sandService.SynceAsync(drilled.WellName, drilled.ProjectName, analog);
            if (lastest == null)
            {
                throw new SandNotFoundException();
            }

            //source should be grouped
            var buffer = lastest.GroupBy(p => new { p.SORUpdatedDate, p.DataSource },
                                        (key, g) => new WellDrilled { SORUpdatedDate = key.SORUpdatedDate, Datasource = key.DataSource });
            if (buffer.Count() > 1)
            {
                throw new SandNotValidException();
            }

            var temp = buffer.FirstOrDefault();
            //temp.Sands = lastest.ToList();

            //comparedate
            if (current.ActivityDate > temp.SORUpdatedDate)
            {
                throw new SandNotValidException();
            }
            // temp.Datasource = "AM";

            //merged
            if (temp.Datasource == PRELIM_FELR_DATASOURCE || temp.Datasource == FINAL_FELR_DATASOURCE)
            {
                current.Sands = lastest.ToList();
            }
            else
            {

                var hashset = new HashSet<string>(current.Sands.Select(c => c.Usi).ToArray());

                // int i = cc.Length;
                foreach (var l in lastest)
                {
                    var flag = hashset.Contains(l.Usi);
                    if (!flag)
                    {
                        current.Sands.Add(l);
                    }
                }

                // current.Value     //with camelcase
                /// = JsonConvert.SerializeObject(cc, new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() });

            }

            //common props
            current.Datasource = temp.Datasource;

            //resert value
            current.CalculatedWellReserve = 0;
            current.ActivityType = ActivityAction.MERGED.GetDescription();
            current.TotalCalculateRecord = 0;
            current.CompleteCalculatedRecord = 0;

            //  current.Type = ReserveType.;

            current.SORUpdatedDate = temp.SORUpdatedDate;

            //create activity
            // await _wellService.CreateAsync(new WellReserve(sand.WellReserve.GetValueOrDefault(), sand.Type, sand.CalculatedTimestamp, httpCurrentUser.Id));
            await this.CreateAsync(new WellActivity() { Action = ActivityAction.MERGED.GetDescription(), WellSpaceId = current.WellSpaceId, By = httpCurrentUser.Id, Discriminator = ReserveType.DRILLED.GetDescription() });

            return current;
        }


        //
        // Summary:
        //     Returns the refresh undrilled sand for well
        //
        // Returns:
        //     Models.Entity.Sand object
        //
        // Type parameters:
        //   well:
        //     well name of the sand
        //   project:
        //     project name of the sand
        //   platform:
        //     platform nme of the sand
        //
        public async Task<WellUndrilled> SynceUndrilledAsync(string well, string project, string platform)
        {
            //var undrilled = await this.EstimateUndrilledReserveAsync(well);
            //var planned = await this.GetPlannedReserveAsync(well);
            //get planned reserved
            // var reserve = await this.GetPlannedReserveAsync(name);


            var reserve = await this.GetPlannedReserveAsync(well);

            //            Log.Information("_cachingService.PlannedReserves.TryGetValue {0} PlannedReserves {1}", well, resez;


            decimal planned = reserve.Value.GetValueOrDefault();
            decimal? undrilled = null;

            try
            {

                var actual = await this.GetActualProductiveAsync(well);
                //timestamp, httpCurrentUser.Id);
                var uncalculate = actual.ActualTVDStartCalculateDepth.GetValueOrDefault();

                if (uncalculate == 0)
                {
                    //throw new WellReserveNotFoundException("Undrilled");
                    // undrilled = null;
                    undrilled = planned;
                }
                else
                {
                    //                    var productive = await _jobService.GetProductiveAsync(well);
                    JobProductive
                        productive = await _jobService.GetProductiveAsync(well);

                    //                    Log.Information("_cachingService.JobProductives.TryGetValue {0}, Productive {1}", well, productive.ActualTVD);


                    var progress = ((productive.ActualTVD - uncalculate) / (productive.PlannedTVD - uncalculate));
                    if (progress < 1)
                    {
                        undrilled = planned * (1 - progress);
                    }
                }


            }
            catch (JobNotProductiveException)    //no UIDM value found
            {
                //undrilled == planned
                undrilled = planned;
            }
            catch (WellNotProductiveException) //no UIDM value found
            {
                //undrilled == planned
                undrilled = planned;
            }


            //   return new WellReserveParams() { Value = undrilled, Type = ReserveType.UNDRILLED.GetDescription() };

            var entity = new WellUndrilled()
            {
                WellName = well,
                // LiquidInMBOE = ,
                //GasInMMScf = ,
                TotalInMBOE = undrilled, //.Value.GetValueOrDefault(),

                ProjectName = project,

                // GasInMMScf = undrilled.GasInMMSCF,
                //LiquidInMBOE = undrilled.LiquidInMBOE,

                // DataSource = ,
                UpdatedDate = Utility.CurrentSEAsiaStandardTime(),
                //PlannedLiquidRatio = planned.PlannedLiquidRatio.GetValueOrDefault(),

                //By = httpCurrentUser.Id,
                //Created = Utility.CurrentSEAsiaStandardTime(),

                By = SURFACE,
                ActivityType = ActivityAction.SYNCED.GetDescription(),
                ActivityDate = Utility.CurrentSEAsiaStandardTime()
            };

            return entity;
        }


        //
        // Summary:
        //     Returns the derivataive of compund reserve (planned / drilled / undrilled) reserve
        //
        // Returns:
        //     Models.Entity.WellReserve object
        //
        // Type parameters:
        //   name:
        //     by well name
        //   timestamp
        //     drilled calculate time stamp
        //
        //

        // will be refactor for mocking
        public async Task<WellReserveParams> DerivatedCompoundReserveAsync(string name, string status, WellUndrilled us = null)//, string timestamp)
        {

            //get user recent DRILLED sand
            var entity = new WellReserveParams() { WellName = name, Status = status };

            //planned  
            // var planned = await this.GetPlannedReserveAsync(name);

            WellReserve planned =
                 await this.GetPlannedReserveAsync(name);

            entity.DerivedReserves.Add(new WellProductiveReserve()
            {
                Type = ReserveType.PLANNED.GetDescription(),
                GasInMMscf = Utility.ParseBCFToMMSCF(planned.PlannedFreeGas.GetValueOrDefault()),
                OilInMSTB = planned.PlannedOil,
                SolGasInMMscf = Utility.ParseBCFToMMSCF(planned.PlannedSolGas.GetValueOrDefault()),
                CondensateInMSTB = planned.PlannedCondy,

            });


            //WellDrilled ds = null;
            var drilled = new WellProductiveReserve() { Type = ReserveType.DRILLED.GetDescription() };

            try
            {
                var ds = await this.GetDrilledRecentlyAsync(name);

                ///drilled
                //check completed callculaed
                if (ds.CompleteCalculatedRecord > 0)
                {
                    var azi = ds.Sands.Where(c => !Utility.EnforceIsContainedAZI(c.OpenWorksContactCategory));

                    drilled.GasInMMscf = azi.Sum(c => c.FreeGasP1DNWithBC);
                    drilled.OilInMSTB = azi.Sum(c => c.OilP1DNWithBC);
                    drilled.SolGasInMMscf = azi.Sum(c => c.SolutionGasP1DNWithBC);
                    drilled.CondensateInMSTB = azi.Sum(c => c.CondensateP1DNWithBC);
                }

            }
            catch (WellDrilledNotFoundException) { };
            entity.DerivedReserves.Add(drilled);


            //undrilled
            var undrilled = new WellProductiveReserve() { Type = ReserveType.UNDRILLED.GetDescription() };

            //dec check
            entity.RLLCPPlannedReserve = planned;

            // var p = WellStatus.PLANNED.GetDescription();

            switch (status)
            {
                case "Planned":

                    {
                        undrilled.GasInMMscf = Utility.ParseMMSCFtoMMBTU(planned.PlannedFreeGas.GetValueOrDefault());
                        undrilled.OilInMSTB = planned.PlannedOil;

                        undrilled.SolGasInMMscf = Utility.ParseMMSCFtoMMBTU(planned.PlannedSolGas.GetValueOrDefault());
                        undrilled.CondensateInMSTB = planned.PlannedCondy;
                    }
                    break;
                case "Completed":

                    {
                        undrilled.GasInMMscf = 0;
                        undrilled.OilInMSTB = 0;
                        undrilled.SolGasInMMscf = 0;
                        undrilled.CondensateInMSTB = 0;
                    }

                    break;

                default:
                    {
                        //int? gor = 1;
                        //int? cgr = 1;

                        //WellUndrilled us = new WellUndrilled();
                        if (us == null)
                        {
                            try
                            {
                                us = await this.GetUndrilledRecentlyAsync(name);
                            }
                            catch (WellUndrilledNotFoundException)
                            {
                                us = await this.SynceUndrilledAsync(planned.WellName, planned.Project, planned.Platform);

                                //separated reserve
                                us = await this.CalculateUndrilledAsync(us);
                            };

                        }
                        else
                        {
                            //no op
                        }


                        //drilling
                        if (planned.PlannedOil > 0)
                        {
                            //  undrilled.GasInMMscf = us.GasInMMScf;
                            // undrilled.CondensateInMSTB = us.LiquidInMBOE;
                            //undrilled.OilInMSTB = 0;
                            //undrilled.SolGasInMMscf = 0;

                            //set
                            entity.SolOilGOR = Utility.ParseMMSCFtoBBL(planned.PlannedSolGas.GetValueOrDefault()) / planned.PlannedOil;
                        }

                        if (planned.PlannedFreeGas > 0)
                        {

                            entity.CondyFreeCGR = planned.PlannedCondy / planned.PlannedFreeGas;
                        }


                        //for shot name
                        var CGR = entity.CondyFreeCGR.GetValueOrDefault();
                        var GOR = entity.SolOilGOR.GetValueOrDefault();

                        //STEP 1
                        undrilled.OilInMSTB = (us.LiquidInMBOE - (CGR * Utility.ParseMMBTUToMMSCF(us.GasInMMScf.GetValueOrDefault()))) /
                                                (1 - CGR * Utility.ParseMMSCFToSCF(GOR));


                        var OIL = undrilled.OilInMSTB.GetValueOrDefault();

                        //STEP 2
                        undrilled.SolGasInMMscf = Utility.ParseMMBTUToMMSCF(OIL * GOR);
                        var GAS = undrilled.SolGasInMMscf.GetValueOrDefault();


                        // STEP 4
                        undrilled.GasInMMscf = us.GasInMMScf - GAS;

                        // STEP 3
                        undrilled.CondensateInMSTB = Utility.ParseMMBTUToMMSCF(undrilled.GasInMMscf.GetValueOrDefault() * CGR);


                    }
                    break;
            }

            //assign
            entity.DerivedReserves.Add(undrilled);

            return entity;
        }


        //
        // Summary:
        //     Returns the completed (planned / drilled / undrilled) reserve
        //
        // Returns:
        //     Models.Entity.WellReserve object
        //
        // Type parameters:
        //   name:
        //     by well name
        //   timestamp
        //     drilled calculate time stamp
        //
        //

        // will be refactor for mocking
        public async Task<WellReserveParams> EvaluatedReserveAsync(string name, string status)//, string timestamp)
        {
            decimal planned = 0, drilled = 0, undrilled = 0;
            decimal actualtvd = 0, plannedtvd = 0, startdepth = 0;

            string SURFACE = "SURFACE";

            //default
            var di = new Info(ActivityAction.SYNCED.GetDescription(), SURFACE, Utility.CurrentSEAsiaStandardTime());
            var ui = new Info(ActivityAction.SYNCED.GetDescription(), SURFACE, Utility.CurrentSEAsiaStandardTime());

            //get user recent DRILLED sand
            try
            {
                var ds = await this.GetDrilledRecentlyAsync(name);

                di.Activity = ds.ActivityType;
                di.By = ds.By;
                di.Date = ds.ActivityDate;

                // di.IsPublished = true;
                /* try
                {
                    //get drilled reseve
                    var entity = await _wellService.GetRecentlyReserveAsync(ds.CalculatedTimestamp); //timestamp, httpCurrentUser.Id);
                    drilled = entity.Value.GetValueOrDefault();
                }
                catch (WellReserveNotFoundException)
                { }*/

                drilled = ds.CalculatedWellReserve.GetValueOrDefault();
            }
            catch (WellDrilledNotFoundException) { }


            //get planned reserved
            //var reserve = await this.GetPlannedReserveAsync(name);
            WellReserve
                reserve = await this.GetPlannedReserveAsync(name);

            planned = reserve.Value.GetValueOrDefault();

            //undrilled
            if (status != WellStatus.COMPLETED.GetDescription())
            {
                //user value


                try
                {
                    var us = await this.GetUndrilledRecentlyAsync(name);

                    undrilled = us.TotalInMBOE.GetValueOrDefault();

                    //throw new SandNotFoundException();
                    //
                    //var reserves = JsonConvert.DeserializeObject<UndrilledProductive[]>(us.Value);

                    // try
                    // {
                    //     //get drilled reseve
                    //     var entity = await _wellService.GetRecentlyReserveAsync(us.CalculatedTimestamp); //timestamp, httpCurrentUser.Id);
                    //     undrilled = entity.Value.GetValueOrDefault();
                    // }
                    // catch (WellReserveNotFoundException)
                    // { }

                    ui.Activity = us.ActivityType;
                    ui.By = us.By;
                    ui.Date = us.ActivityDate;
                    ui.Method = UNDRILLED.METHOD.Where(c => c.Id == us.UndrilledMethod).FirstOrDefault().Title;
                }
                catch (WellUndrilledNotFoundException)
                {

                    var entity = await this.SynceUndrilledAsync(name, reserve.Project, reserve.Platform);
                    if (entity != null)
                    {
                        undrilled = entity.TotalInMBOE.GetValueOrDefault();
                    }
                    else
                    {

                        undrilled = planned;
                    }

                }
                catch (NullReferenceException)
                {
                    throw new WellUndrilledNotFoundException();
                }

            }


            var result = new WellReserveParams() { Planned = planned, Drilled = drilled, Undrilled = undrilled };
            //return result;

            //dev check
            result.WellName = name;
            result.ActualTVD = actualtvd;
            result.PlannedTVD = plannedtvd;
            result.DepthCalculatedStart = startdepth;
            //result.UndrilledCalculateMethod = method;

            //detail
            result.DrilledDetail = di;
            result.UndrilledDetail = ui;

            result.Status = status;

            return result;

        }


        //
        // Summary:
        //     Returns evaluation DPI / NPI / DPV
        //
        // Returns:
        //     Models.Entity.WellReserve object
        //
        // Type parameters:
        //   well:
        //     wellname
        //   project :  
        //      project name
        //   platform :  
        //      platform name
        //
        public async Task<WellEvaluateParams> EvaluateBranchDPIAsync(WellEvaluateParams parameter)
        {
            await Task.Delay(0);
            throw new NotImplementedException();
        }

        //
        // Summary:
        //     Returns evaluation DPI / NPI / DPV
        //
        // Returns:
        //     Models.Entity.WellReserve object
        //
        // Type parameters:
        //   well:
        //     wellname
        //   project :  
        //      project name
        //   platform :  
        //      platform name
        //
        public async Task<IEnumerable<WellEvaluateParams>> EvaluateBranchDPIAsync(IEnumerable<WellEvaluateParams> parameters)
        {
            if (parameters?.Count() == 0)
                throw new InvalidOperationException("No branch has created.");

            int currentYear = Utility.CurrentSEAsiaStandardTime().Year;

            var commonParam = parameters.FirstOrDefault();
            var project = commonParam.Project;
            var platform = commonParam.Platform;
            var wellName = commonParam.WellName;
            var wellStatus = commonParam.WellStatus;

            //get project attribute
            var attribute = await _projectWellService.GetCurrentlyAttributeAsync(project);

            //new logic to get well count
            // attribute.TotalPlannedWell = 1;
            // if (attribute.TotalPlannedWell <= 0)
            // {
            //     throw new ProjectNotValidException("ATTRIBUTE");
            // }

            var entity = await _projectWellService.GetDrilledRecentlyAsync(project);
            if (entity == null)
            {
                throw new ProjectDrilledNotFoundException();
            }

            //template service
            var template = await _templateService.GetCurrentlyAsync(entity.TemplateTypeId);

            //get rigg moved cost
            var riggmove = await _jobService.GetProductiveCostAsync(platform);

            // undrilled from FE UI ?????
            //drive resreve CTEP
            //var reserves = await this.DerivatedCompoundReserveAsync(wellName, wellStatus);  //sannd

            //get active monthly price template
            var pt = await _templateService.GetCurrentlyAsync(GLOBAL.MONTHLY_PRICE_TEMPLATE_ID);

            //list all price
            var prices = await _priceService.ListRecentlyAsync(pt.Id);

            //oil gas profile for holdup
            var production = await _productionService.GetCurentlyProductAsync(attribute.ProductionProfileId); //gas oil, holupercantage

            //attach
            var attached = await _attachementService.GetAsync(entity.AttachmentId);
            if (attached == null)
            {
                throw new AttachmentNotFoundException();
            }

            var fileBase64Encoded = attached.Value;
            Byte[] bytes = Convert.FromBase64String(fileBase64Encoded);


            var tasks = new List<Task>();
            int branchNo = 1;
            foreach (var parameter in parameters)
            {
                var clonnedAttribute = attribute.DeepClone();
                tasks.Add(EvaluateBranchDPIAsync(bytes, parameter, template, clonnedAttribute, riggmove, production, prices, attached, project, branchNo++));
            }

            Task.WaitAll(tasks.ToArray());

            return parameters;
        }

        private async Task EvaluateBranchDPIAsync(Byte[] bytes, WellEvaluateParams parameter, Template template,
            ProjectAttribute attribute, Job riggmove, Production production, IEnumerable<Price> prices, Attachment attached, string project, int branchNo)
        {
            int ml = 1000000;
            var basePath = _configuration["AppSettings:AssetsFilePath"];

            var branchCost = parameter.TotalBranchCost;

            //total cost
            var drilling = new ProjectWell() { TotalProductiveAFECost = branchCost };

            // undrilled from FE UI ?????
            //drive resreve CTEP
            var undrilled = new WellUndrilled() { GasInMMScf = parameter.Reserve.GasInMMSCF, LiquidInMBOE = parameter.Reserve.LiquidInMBOE };
            var reserves = await this.DerivatedCompoundReserveAsync(parameter.WellName, parameter.WellStatus, undrilled);  //sannd

            //var buffer_total_planned_well = attribute.TotalPlannedWell.GetValueOrDefault();
            var buffer_total_planned_well = await _projectWellService.CountPlannedWellAsync(parameter.Project);

            //   var COTL_total_planned_well = 1;
            attribute.TotalPlannedWell = 1;

            // Write into excel template
            // Initialize handler
            IExcelTemplateHandler handler = new ExcelTemplateHandler();
            IDPITemplateProfile profile = null;
            ProjectDPIResult dpiResult = null;

            //get undrill
            var undrilleds = reserves.DerivedReserves.Where(x => x.Type == ReserveType.UNDRILLED.GetDescription()).FirstOrDefault();

            //sum of reserve
            var gasInMMscf = undrilleds.GasInMMscf.GetValueOrDefault();
            var oilInMSTB = undrilleds.OilInMSTB.GetValueOrDefault();
            var condensateInMSTB = undrilleds.CondensateInMSTB.GetValueOrDefault();
            var solGasInMMscf = undrilleds.SolGasInMMscf.GetValueOrDefault();

            using (var stream = new MemoryStream(bytes))
            {
                handler.Load(stream);

                //for loop ad return entities
                switch (template.TemplateTypeId)
                {
                    case GLOBAL.CTEP_TEMPLATE_TYPE_ID:
                        {
                            var ctepProfile = new DPITemplateCTEPProfile();

                            var revs = new WellProductiveReserve()
                            {
                                GasInMMscf = gasInMMscf,
                                OilInMSTB = oilInMSTB,
                                CondensateInMSTB = condensateInMSTB,
                                SolGasInMMscf = solGasInMMscf
                            };

                            //get end date from the template
                            ctepProfile.AddEndDateReadDefinition();

                            // Load profile
                            handler.Load(ctepProfile);

                            handler.Execute();

                            var endDate = ctepProfile.GetReadEndDate();

                            //clear executed definitions
                            ctepProfile.ClearDefinitions();

                            //construc parama
                            var temp = new WellEvaluateParams()
                            {
                                Project = project,
                                Reserves = new List<WellReserveParams> { reserves },
                                ProjectAtrributed = attribute,
                                ProductionProfile = production
                            };

                            //gen profile rate
                            var product = production; //parameter.ProductionProfile;

                            //OIL
                            var rr = revs.OilInMSTB.GetValueOrDefault();
                            var or = new WellReserve() { Value = rr };

                            //GAS
                            var vv = revs.GasInMMscf.GetValueOrDefault();
                            var gr = new WellReserve() { Value = vv };

                            //get rate
                            var oil = await _productionService.EvaluateProfileRateAsync(product.OilProfile, or);
                            var gas = await _productionService.EvaluateProfileRateAsync(product.GasProfile, gr);

                            //by year or month
                            var productions = await _projectWellService.EstimateMonthlyProductAsync(temp, revs, oil, gas);

                            // Write production profile
                            foreach (var pp in productions)
                            {
                                // Write all phases with the same value by month-year
                                if (pp.ApplicableModel == "OIL")
                                {
                                    ctepProfile.AddProductionProfileOilDefinition(pp.PeriodPlots, endDate);
                                }
                                else if (pp.ApplicableModel == "SOLGAS")
                                {
                                    ctepProfile.AddProductionProfileSolutionGasDefinition(pp.PeriodPlots, endDate);
                                }
                                else if (pp.ApplicableModel == "GAS")
                                {
                                    ctepProfile.AddProductionProfileGasDefinition(pp.PeriodPlots, endDate);
                                }
                                else if (pp.ApplicableModel == "CONDY")
                                {
                                    ctepProfile.AddProductionProfileCondensateDefinition(pp.PeriodPlots, endDate);
                                }
                            }

                            profile = ctepProfile;
                            break;
                        }
                    case GLOBAL.COTL_TEMPLATE_TYPE_ID:
                        {

                            //gas rate
                            var gasreserve = new WellReserve() { Value = gasInMMscf };
                            var gasrate = await _productionService.EvaluateProfileRateAsync(production.GasProfile, gasreserve);

                            //oil
                            var oilreserve = new WellReserve() { Value = Utility.ParseMMSCFtoMMBTU(oilInMSTB) };
                            var oilrate = await _productionService.EvaluateProfileRateAsync(production.OilProfile, oilreserve);

                            decimal zero = (decimal)Math.Pow(10, -12);

                            var cotlProfile = new DPITemplateCOTLProfile();
                            var prodRsv = new COTLProdRSV
                            {
                                NumberOfWells = attribute.TotalPlannedWell, //1
                                ModelSelection = attribute.ApplicableModelId,
                                OilReserves = oilInMSTB != 0 ? oilInMSTB : zero,
                                SolutionGasReserves = solGasInMMscf != 0 ? solGasInMMscf : zero,
                                GasReserves = gasInMMscf != 0 ? gasInMMscf : zero,
                                CondensateReserves = condensateInMSTB != 0 ? condensateInMSTB : zero,
                                GasOnlineDate = attribute.GasProjectStartDate,
                                GasPercentHold = production.GasProfile?.HoldupPercentage / 100,
                                OilOnlineDate = attribute.OilProjectStartDate,
                                OilPercentHold = production.OilProfile?.HoldupPercentage / 100,
                                InitialGasRate = gasrate.Value,
                                InitialOilRate = oilrate.Value,
                                GasAbandonmentRate = gasrate.AbandonmentRate,
                                OilAbandonmentRate = oilrate.AbandonmentRate,
                            };

                            // Add production rsv
                            cotlProfile.AddProdRSVDefinition(prodRsv);

                            profile = cotlProfile;
                            break;
                        }

                    default:
                        throw new TemplateNotFoundException(template.TemplateTypeId);
                }

                drilling.StartDate = riggmove.StartDate;
                drilling.TotalProductiveAFECost = drilling.TotalProductiveAFECost != null ? drilling.TotalProductiveAFECost / ml : null;

                // Add drilling cost
                profile.AddDrillingCostDefinition(drilling);

                // Write price deck
                foreach (var price in prices)
                {
                    profile.AddPriceCaseDefinition(price.Structure, price.HcType, price.Name, price.Prices);
                }

                // Add price case type
                profile.AddPriceCaseTypeDefinition(parameter.PriceStructure);

                // Add Well DPI dividing
                profile.AddWellDPIDividingDefinition(buffer_total_planned_well);

                // Add value clearing
                profile.AddClearValuesDefinition();

                // Add DPI read profile
                profile.AddDPIReadDefinition();

                // Load profile
                handler.Load(profile);

                try
                {
                    // Perform validation
                    // This throws an exception when get failed on any cases
                    handler.Execute();

                    // Get DPI result 
                    dpiResult = profile.GetReadDPI();
                    // parameter.ActualDPI = dpiResult.DPI;
                    parameter.DPI = dpiResult.DPI;
                    parameter.NPV = dpiResult.NPV * ml;
                    parameter.INV = dpiResult.INV * ml;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    //Save result into memory
                    using (var memoryStream = new MemoryStream())
                    {
                        handler.SaveAs(memoryStream);

                        var timestamp = DateTime.Now.ToString("yyyyMMdd_hhmm");

                        //write file
                        if (!Directory.Exists(await _pathFinderService.FindAsync($"{basePath}/branches")))
                            Directory.CreateDirectory(await _pathFinderService.FindAsync($"{basePath}/branches"));

                        var path = await _pathFinderService.FindAsync($"{basePath}/branches/{timestamp}_{parameter.WellName}_{branchNo}_{parameter.Id}{attached.Extension}");
                        try
                        {
                            await File.WriteAllBytesAsync(path, memoryStream.ToArray());
                        }
                        catch (DirectoryNotFoundException)
                        {
                            throw new AttachmentNotValidException(path);
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }
                }
            }
        }

        //
        // Summary:
        //     Returns the calculated dpi
        //
        // Returns:
        //     pair of decimal
        //
        // Type parameters:
        //   name:
        //     by well name
        //   timestamp
        //     dpi cost calculate time stamp
        //
        //   
        public async Task<WellEvaluateParams> EvaluateSimpleDPIAsync(WellEvaluateParams parameter)  //WellReserveParams parameter)//, string timestamp)
        {

            //setvalue
            var status = parameter.WellStatus;

            //validate status
            /* var validate = _wellValidator.Validate(parameter);
            if (!validate.IsValid)
            {
                throw new WellNotValidException();
            };*/

            var basePath = _configuration["AppSettings:AssetsFilePath"];

            var well = parameter.WellName;
            var project = parameter.Project;
            var platform = parameter.Platform;


            //parameter.Well;
            //var PRICE_STRUCTURE_MID = "MID";

            int ml = 1000000;

            //AFE, total well
            var attribute = await _projectWellService.GetCurrentlyAttributeAsync(project);
            var buffer_total_planned_well = await _projectWellService.CountPlannedWellAsync(parameter.Project);

            //   var COTL_total_planned_well = 1;
            attribute.TotalPlannedWell = 1;

            //well cost

            //var sw = new Stopwatch();
            // sw.Start();
            //try to get singleton di cache
            JobProductive productive = await _jobService.GetProductiveAsync(well);

            //sw.Stop();
            // Logg.Debug("GetProductiveAsync Elapsed={0}", sw.Elapsed);


            //riggmove
            var riggmove = await _jobService.GetProductiveCostAsync(parameter.Platform);

            //default is planned
            decimal rig_cost_planned = riggmove.AFTAmountCalculate.GetValueOrDefault() / buffer_total_planned_well;
            decimal rig_cost_actual = riggmove.TotalCostCalculate.GetValueOrDefault() / buffer_total_planned_well;

            decimal drilling_cost_planned = productive.PlannedCostAFE;
            decimal drilling_cost_actual = productive.ActualCostAFE;

            //total cost
            var drilling = new ProjectWell() { TotalProductiveAFECost = drilling_cost_actual }; //+ rig_cost_actual };

            // undrilled from FE UI ?????
            //drive resreve CTEP
            var reserves = await this.DerivatedCompoundReserveAsync(parameter.WellName, status);  //sannd


            //actual = plan if status
            if (String.Equals(WellStatus.PLANNED.GetDescription(), status, StringComparison.OrdinalIgnoreCase))
            {

                //total cost
                drilling.TotalProductiveAFECost = drilling_cost_planned;
                riggmove.TotalCostCalculate = rig_cost_planned;
            }
            else
            {
                drilling.TotalProductiveAFECost = drilling_cost_actual;
                riggmove.TotalCostCalculate = rig_cost_actual;
            }

            //oil gas profile for holdup
            var production = await _productionService.GetCurentlyProductAsync(attribute.ProductionProfileId); //gas oil, holupercantage


            //get active monthly price template
            var pt = await _templateService.GetCurrentlyAsync(GLOBAL.MONTHLY_PRICE_TEMPLATE_ID);

            //list all price
            var prices = await _priceService.ListRecentlyAsync(pt.Id);


            var entity = await _projectWellService.GetDrilledRecentlyAsync(parameter.Project);
            if (entity == null)
            {
                throw new ProjectDrilledNotFoundException();
            }

            //template service
            var template = await _templateService.GetCurrentlyAsync(entity.TemplateTypeId);

            // Write into excel template
            // Initialize handler
            IExcelTemplateHandler handler = new ExcelTemplateHandler();
            IDPITemplateProfile profile = null;
            ProjectDPIResult dpiResult = null;

            // template.TemplateTypeId = CTEP_TEMPLATE_TYPE_ID;
            //swithc reserve
            decimal gasInMMscf = 0m;
            decimal oilInMSTB = 0m;
            decimal condensateInMSTB = 0m;
            decimal solGasInMMscf = 0m;

            //if planned
            if (String.Equals(WellStatus.PLANNED.GetDescription(), status, StringComparison.OrdinalIgnoreCase))
            {

                var planned = reserves.DerivedReserves.Where(x => x.Type == ReserveType.PLANNED.GetDescription()).FirstOrDefault();

                //sum of reserve
                gasInMMscf = planned.GasInMMscf.GetValueOrDefault();
                oilInMSTB = planned.OilInMSTB.GetValueOrDefault();
                condensateInMSTB = planned.CondensateInMSTB.GetValueOrDefault();
                solGasInMMscf = planned.SolGasInMMscf.GetValueOrDefault();
            }
            else
            {


                var drilled = reserves.DerivedReserves.Where(x => x.Type == ReserveType.DRILLED.GetDescription()).FirstOrDefault();
                var undrilleds = reserves.DerivedReserves.Where(x => x.Type == ReserveType.UNDRILLED.GetDescription()).FirstOrDefault();

                //sum of reserve
                gasInMMscf = drilled.GasInMMscf.GetValueOrDefault() + undrilleds.GasInMMscf.GetValueOrDefault();
                oilInMSTB = drilled.OilInMSTB.GetValueOrDefault() + undrilleds.OilInMSTB.GetValueOrDefault();
                condensateInMSTB = drilled.CondensateInMSTB.GetValueOrDefault() + undrilleds.CondensateInMSTB.GetValueOrDefault();
                solGasInMMscf = drilled.SolGasInMMscf.GetValueOrDefault() + undrilleds.SolGasInMMscf.GetValueOrDefault();

            }

            //attach
            var attached = await _attachementService.GetAsync(entity.AttachmentId);
            if (attached == null)
            {
                throw new AttachmentNotFoundException();
            }

            var fileBase64Encoded = attached.Value;
            Byte[] bytes = Convert.FromBase64String(fileBase64Encoded);

            var dpi = 0m;

            using (var stream = new MemoryStream(bytes))
            {
                handler.Load(stream);
            }

            //for loop ad return entities
            switch (template.TemplateTypeId)
            {
                case GLOBAL.CTEP_TEMPLATE_TYPE_ID:
                    {

                        var revs = new WellProductiveReserve()
                        {
                            GasInMMscf = gasInMMscf,
                            OilInMSTB = oilInMSTB,
                            CondensateInMSTB = condensateInMSTB,
                            SolGasInMMscf = solGasInMMscf
                        };

                        //construc parama
                        var temp = new WellEvaluateParams()
                        {
                            Project = parameter.Project,
                            Reserves = new List<WellReserveParams> { reserves },
                            ProjectAtrributed = attribute,
                            ProductionProfile = production,
                            // WellStatus = status
                        };

                        //gen profile rate
                        var product = production;

                        //OIL
                        var rr = revs.OilInMSTB.GetValueOrDefault();
                        var or = new WellReserve() { Value = rr };

                        //GAS
                        var vv = revs.GasInMMscf.GetValueOrDefault();
                        var gr = new WellReserve() { Value = vv };

                        //get rate
                        var oil = await _productionService.EvaluateProfileRateAsync(product.OilProfile, or);
                        var gas = await _productionService.EvaluateProfileRateAsync(product.GasProfile, gr);


                        //by year or month
                        var productions = await _projectWellService.EstimateMonthlyProductAsync(temp, revs, oil, gas); //, DomainLevel.WELL.GetDescription());

                        var ctepProfile = new DPITemplateCTEPProfile();

                        //get end date from the template
                        ctepProfile.AddEndDateReadDefinition();

                        // Load profile
                        handler.Load(ctepProfile);

                        handler.Execute();

                        var endDate = ctepProfile.GetReadEndDate();

                        //clear executed definitions
                        ctepProfile.ClearDefinitions();

                        // Write production profile
                        foreach (var pp in productions)
                        {
                            // Write all phases with the same value by month-year
                            if (pp.ApplicableModel == "OIL")
                            {
                                ctepProfile.AddProductionProfileOilDefinition(pp.PeriodPlots, endDate);
                            }
                            else if (pp.ApplicableModel == "SOLGAS")
                            {
                                ctepProfile.AddProductionProfileSolutionGasDefinition(pp.PeriodPlots, endDate);
                            }
                            else if (pp.ApplicableModel == "GAS")
                            {
                                ctepProfile.AddProductionProfileGasDefinition(pp.PeriodPlots, endDate);
                            }
                            else if (pp.ApplicableModel == "CONDY")
                            {
                                ctepProfile.AddProductionProfileCondensateDefinition(pp.PeriodPlots, endDate);
                            }
                        }

                        profile = ctepProfile;
                        break;
                    }
                case GLOBAL.COTL_TEMPLATE_TYPE_ID:
                    {


                        //get rigg moved cost
                        //var jobb = await _jobService.GetProductiveCostAsync(parameter.Platform);
                        //var rigcost = jobb.TotalCostCalculate;


                        //gas rate
                        var gasreserve = new WellReserve() { Value = gasInMMscf };
                        var gasrate = await _productionService.EvaluateProfileRateAsync(production.GasProfile, gasreserve);
                        //oil
                        var oilreserve = new WellReserve() { Value = Utility.ParseMMSCFtoMMBTU(oilInMSTB) };
                        var oilrate = await _productionService.EvaluateProfileRateAsync(production.OilProfile, oilreserve);

                        decimal zero = (decimal)Math.Pow(10, -12);
                        var cotlProfile = new DPITemplateCOTLProfile();

                        var prodRsv = new COTLProdRSV
                        {
                            NumberOfWells = attribute.TotalPlannedWell,  //1 
                            ModelSelection = attribute.ApplicableModelId,
                            OilReserves = oilInMSTB != 0 ? oilInMSTB : zero,
                            SolutionGasReserves = solGasInMMscf != 0 ? solGasInMMscf : zero,
                            GasReserves = gasInMMscf != 0 ? gasInMMscf : zero,
                            CondensateReserves = condensateInMSTB != 0 ? condensateInMSTB : zero,
                            GasOnlineDate = attribute.GasProjectStartDate,
                            GasPercentHold = production.GasProfile?.HoldupPercentage / 100,
                            OilOnlineDate = attribute.OilProjectStartDate,
                            OilPercentHold = production.OilProfile?.HoldupPercentage / 100,
                            InitialGasRate = gasrate.Value,
                            InitialOilRate = oilrate.Value,
                            GasAbandonmentRate = gasrate.AbandonmentRate,
                            OilAbandonmentRate = oilrate.AbandonmentRate,
                        };

                        // Add production rsv
                        cotlProfile.AddProdRSVDefinition(prodRsv);

                        profile = cotlProfile;
                        break;
                    }

                default:
                    throw new TemplateNotFoundException(template.TemplateTypeId);
            }

            drilling.StartDate = riggmove.StartDate;
            drilling.TotalProductiveAFECost = drilling.TotalProductiveAFECost != null ? drilling.TotalProductiveAFECost / ml : null;

            riggmove.TotalCostCalculate = riggmove.TotalCostCalculate != null ? riggmove.TotalCostCalculate / ml : null;

            // Add drilling cost
            profile.AddDrillingCostDefinition(drilling);

            // Add rig move cost
            profile.AddRigMoveCostDefinition(riggmove);

            // Write price deck
            foreach (var pp in prices)
            {
                profile.AddPriceCaseDefinition(pp.Structure, pp.HcType, pp.Name, pp.Prices);
            }

            // Add price case type
            //profile.AddPriceCaseTypeDefinition(PRICE_STRUCTURE_MID);

            // Add Well DPI dividing
            profile.AddWellDPIDividingDefinition(buffer_total_planned_well);//attribute.TotalPlannedWell.GetValueOrDefault());

            // Add DPI read profile
            profile.AddDPIReadDefinition();

            // Load profile
            handler.Load(profile);

            // Perform validation
            // This throws an exception when get failed on any cases
            handler.Execute();

            // Get DPI result 
            dpiResult = profile.GetReadDPI();
            dpi = dpiResult.DPI;
            //parameter.DPI = dpiResult.DPI;
            //parameter.NPV = dpiResult.NPV;
            //parameter.INV = dpiResult.INV;

            //  parameter.PlannedDPI = 9.999m;

            //Save result into memory
            using (var memoryStream = new MemoryStream())
            {
                handler.SaveAs(memoryStream);

                var timestamp = DateTime.Now.ToString("yyyyMMdd_hhmm");

                //write file
                if (!Directory.Exists(await _pathFinderService.FindAsync($"{basePath}/wells")))
                    Directory.CreateDirectory(await _pathFinderService.FindAsync($"{basePath}/wells"));

                var path = await _pathFinderService.FindAsync($"{basePath}/wells/{timestamp}_{parameter.WellName}_{Guid.NewGuid().ToString()}{attached.Extension}");
                try
                {
                    await File.WriteAllBytesAsync(path, memoryStream.ToArray());
                }
                catch (DirectoryNotFoundException)
                {
                    throw new AttachmentNotValidException(path);
                }
                catch (Exception ex)
                {
                    throw ex;
                }

            }


            //swithch param
            if (String.Equals(WellStatus.PLANNED.GetDescription(), status, StringComparison.OrdinalIgnoreCase))
            {
                parameter.PlannedDPI = dpi;
            }
            else
            {
                parameter.ActualDPI = dpi;
            }


            return parameter;
        }


        //
        // Summary:
        //     CRUD project well sachema with transaction controll
        //
        // Returns:
        //     Models.Entity.ProjectWell object
        //
        // Type parameters:
        //  
        //      wwww
        //

        public async Task<WellDrilled> BatchCreateDrilledAsync(WellDrilled drill)
        {
            var pid = drill.Id;
            var sid = Utility.ToUniqeIdentity(drill.ProjectName);

            var well = await this.EnforceWellCreateAsync(new Well() { Name = drill.WellName, ProjectId = sid });

            var entities = new List<Sand>();
            //do with transaction
            using (var transaction = _workUnitService.BeginTransaction())
            {
                //create space
                var space = new WellSpace() { Id = Guid.NewGuid(), WellId = well.Id, By = httpCurrentUser.Id, Created = Utility.CurrentSEAsiaStandardTime() };
                var sp = await _workUnitService.WellSpaces.CreateAsync(space);

                //create wwww
                // var www = new WellDrilled() { Key = Guid.NewGuid().ToString(), Rev = Guid.NewGuid().ToString(), Id = Guid.NewGuid(), WellSpaceId = sp.Id, StartDate = Utility.CurrentSEAsiaStandardTime() };
                //create assign
                //keep key if update
                drill.Key = drill.Id == Guid.Empty ? Guid.NewGuid().ToString() : drill.Key;
                var action = drill.Id == Guid.Empty ? ActivityAction.SAVED.GetDescription() : ActivityAction.UPDATED.GetDescription();

                drill.Rev = Guid.NewGuid().ToString();
                drill.Id = Guid.NewGuid();
                drill.WellSpaceId = sp.Id;
                drill.Created = Utility.CurrentSEAsiaStandardTime();
                drill.Status = RecordStatus.ACTIVE.GetDescription();
                var sm = await _workUnitService.WellDrilleds.CreateAsync(drill);

                foreach (var s in drill.Sands)
                {
                    //set value
                    s.Id = Guid.NewGuid();
                    s.CreatedDate = Utility.CurrentSEAsiaStandardTime();
                    s.WellDrilledId = sm.Id;

                    entities.Add(s);
                }


                await _workUnitService.Sands.CreateRangeAsync(entities);

                //set value
                sm.Sands = entities;
                sm.WellName = well.Name;

                try
                {
                    transaction.Commit();

                    //trakc activity
                    var activity = new WellActivity(sp.Id, ReserveType.DRILLED.GetDescription(), action, httpCurrentUser.Id);
                    var temp = await this.CreateAsync(activity);

                    sm.ActivityDate = temp.Date;
                    sm.ActivityType = temp.Action;

                    //var user = await _userService.GetAsync(temp.By);
                    sm.By = httpCurrentUser.CAI;


                    return sm;
                }
                catch (InvalidOperationException ex)
                {
                    transaction.Rollback();
                    throw new WellPropertiesNotValidException(ex.Message);
                }
            }
        }


        public async Task<WellUndrilled> BatchCreateUnrilledAsync(WellUndrilled undrill)
        {
            var pid = undrill.Id;

            var sid = Utility.ToUniqeIdentity(undrill.ProjectName);
            var well = await this.EnforceWellCreateAsync(new Well() { Name = undrill.WellName, ProjectId = sid });

            //do with transaction
            using (var transaction = _workUnitService.BeginTransaction())
            {
                //create space
                var space = new WellSpace() { Id = Guid.NewGuid(), WellId = well.Id, By = httpCurrentUser.Id, Created = Utility.CurrentSEAsiaStandardTime() };
                var sp = await _workUnitService.WellSpaces.CreateAsync(space);

                //create assign
                //keep key if update
                undrill.Key = undrill.Id == Guid.Empty ? Guid.NewGuid().ToString() : undrill.Key;
                var action = undrill.Id == Guid.Empty ? ActivityAction.SAVED.GetDescription() : ActivityAction.UPDATED.GetDescription();
                undrill.Rev = Guid.NewGuid().ToString();

                undrill.Id = Guid.NewGuid();
                undrill.WellSpaceId = sp.Id;
                undrill.Created = Utility.CurrentSEAsiaStandardTime();
                //  undrill.StartDate = Utility.CurrentSEAsiaStandardTime();
                undrill.Status = RecordStatus.ACTIVE.GetDescription();

                var sm = await _workUnitService.WellUndrilleds.CreateAsync(undrill);

                sm.WellName = well.Name;

                try
                {
                    transaction.Commit();

                    //trakc activity
                    var activity = new WellActivity(sp.Id, ReserveType.UNDRILLED.GetDescription(), action, httpCurrentUser.Id);
                    var temp = await this.CreateAsync(activity);

                    sm.ActivityDate = temp.Date;
                    sm.ActivityType = temp.Action;

                    sm.By = httpCurrentUser.CAI;

                    return sm;
                }
                catch (InvalidOperationException ex)
                {
                    transaction.Rollback();
                    throw new WellPropertiesNotValidException(ex.Message);
                }
            }
        }



        public async Task<WellProductiveAsync> GetProductiveAsync(string name)
        {
            var well = await _entityService.GetWellProductiveAsync(name);

            //should mapper service and class
            /* var well = new WellProductiveMapper()
            {
                Id = Guid.NewGuid().ToString(),
                Name = re.Name,
            };*/

            return well;
        }



        //
        // Summary:
        //    Get list of platform from TCRS endpoint API
        //
        // Returns:
        //     Models.Gateway.Platform object
        //
        // Type parameters:
        //   name:
        //     unique name of platform
        //
        /* public async Task<Models.Platform> GetDefaultPlatformAsync(string name)
        {
            var platform = await _clientService.GetDefaultPlatformAsync(name);
            return _platformMapper.Mapp(platform);
        }*/


        public string GetDefaultWellType(IEnumerable<Sand> reserve)
        {
            String[] oilTypes = { "oil", "owc", "goc", "gow" };
            String[] gasTypes = { "gas", "gwc" };
            String[] oilTypesAzi = { "oil azi", "owc azi" };
            String[] gasTypesAzi = { "gas azi", "gwc azi" };

            // public readonly static string[] GAS_CONTACT_CATEGORY = new string[] { "GAS", "GWC", "GOC", "GOW" };
            // public readonly static string[] OIL_CONTACT_CATEGORY = new string[] { "OWC", "GOC", "GOW", "OIL" };


            if (Array.Exists(reserve.ToArray(), sand =>
                            Array.Exists(oilTypes, type => sand.OpenWorksContactCategory != null ? sand.OpenWorksContactCategory.ToLower().Equals(type) : false)))
            {
                return "OIL";
            }
            else if (Array.Exists(reserve.ToArray(), sand =>
                             Array.Exists(gasTypes, type => sand.OpenWorksContactCategory != null ? sand.OpenWorksContactCategory.ToLower().Equals(type) : false)))
            {
                return "GAS";
            }
            else if (Array.Exists(reserve.ToArray(), sand =>
                            Array.Exists(oilTypesAzi, type => sand.OpenWorksContactCategory != null ? sand.OpenWorksContactCategory.ToLower().Equals(type) : false)))
            {
                return "OIL";
            }
            else if (Array.Exists(reserve.ToArray(), sand =>
                            Array.Exists(gasTypesAzi, type => sand.OpenWorksContactCategory != null ? sand.OpenWorksContactCategory.ToLower().Equals(type) : false)))
            {
                return "GAS";
            }


            return "GAS";
        }


        //
        // Summary:
        //    Return list of well pay from TCRS for project summary
        //
        // Returns:
        //     list of well pay
        //
        // Type parameters:
        //   name:
        //    list of well name
        //

        public async Task<IEnumerable<WellPay>> GetWellPayAsync(string[] name)
        {
            //RLLCP
            var entities = await _clientService.GetWellPayAsync(name);
            if (entities == null)
            {
                throw new WellNotFoundException();
            }

            var mapped = _wellPayMapper.Mapp(entities).OrderBy(c => c.WellName);
            return mapped;

        }

    }

    public class WellResourceService : IWellResourceService
    {
        private readonly IWellRepository _wellRepository;

        private readonly IEntityService _entityService;
        private readonly IMapper<WellJobProductiveAsync, WellJobProductive> _wellJobProductiveMapper;

        public WellResourceService(IWellRepository wellRepository, IMapper<WellJobProductiveAsync, WellJobProductive> wellJobProductiveMapper, IEntityService entityService)
        {
            _wellRepository = wellRepository ?? throw new ArgumentNullException(nameof(wellRepository));
            _wellJobProductiveMapper = wellJobProductiveMapper ?? throw new ArgumentNullException(nameof(wellJobProductiveMapper));

            _entityService = entityService ?? throw new ArgumentNullException(nameof(entityService));
        }

        //
        // Summary:
        //     Returns the planned AFE cost for calculated well decision 
        //
        // Returns:

        //     Models.Entity.WellReserve object
        //
        // Type parameters:
        //   name:
        //     wellname
        //   type :  
        //     well cost type
        //
        public async Task<WellJobProductive> GetPlannedProductiveCostAsync(string name, string type)
        {

            var welljob = await _entityService.GetWellPlannedProductiveCostAsync(name, type);

            if (welljob == null)
            {
                throw new WellNotProductiveException();
            }

            var entity = _wellJobProductiveMapper.Mapp(welljob);

            return entity;
        }



    }
}