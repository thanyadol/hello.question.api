using System; 

using System.Collections.Generic;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using surflex.netcore22.Exceptions;

//logg
using Serilog;
using surflex.netcore22.Helpers;
using System.IO;
using System.Net.Http;

namespace surflex.netcore22.Services
{
    public interface ILoggService
    {
        Task<SessionLogg> CreateAsync(SessionLogg logg);
        Task<SessionLogg> UpdateAsync(SessionLogg logg);
        // Task<SessionLogg> DeleteAsync(Guid id);

        Task<SessionLogg> GetAsync(Guid id);

        Task<IEnumerable<SessionLogg>> ListAsync();
        Task<SessionLogg> GetRecentlyAsync(string id);
        Task<SessionLogg> EnforceSessionLoggExistenceAsync(Guid id);


    }

    public class LoggService : ILoggService
    {
        //logg status
        protected readonly ISessionLoggRepository _sessionRepository;
        // protected readonly IUserService _userService;
        public LoggService(ISessionLoggRepository sessionRepository) //, IUserService userService, IPathFinderService pathFinderService)
        {
            _sessionRepository = sessionRepository ?? throw new ArgumentNullException(nameof(sessionRepository));
            //_userService = userService ?? throw new ArgumentNullException(nameof(userService));

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }

        public async Task<SessionLogg> CreateAsync(SessionLogg logg)
        {
            //await this.EnforceWellExistenceAsync(SessionLogg.WellId);
            //assigned
            logg.Id = Guid.NewGuid();
            logg.Date = Utility.CurrentSEAsiaStandardTime();

            //logg. = httpCurrentUser.Id;

            //l//ogg.Description = "hello this is a new logg from develper";

            //new rev and key
            //logg.Rev = Guid.NewGuid().ToString();
            //logg.Key = Guid.NewGuid().ToString();

            //await EnforceClanExistenceAsync(SessionLogg.Clan.Name);
            var entity = await _sessionRepository.CreateAsync(logg);
            if (entity == null)
            {
                throw new SessionLoggNotFoundException(logg);
            }

            return entity;
        }



        public async Task<SessionLogg> UpdateAsync(SessionLogg logg)
        {
            var updated = await this.EnforceSessionLoggExistenceAsync(logg.Id);

            //assigned
            //logg.Created = Utility.CurrentSEAsiaStandardTime();
            //SessionLogg.SessionLogg = SessionLogg.SessionLogg;
            //SessionLogg.Status = SessionLogg.Status;
            //   logg.By = httpCurrentUser.Id;

            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //logg.Key = Guid.NewGuid().ToString();

            var entity = await _sessionRepository.UpdateAsync(logg);
            if (entity == null)
            {
                throw new SessionLoggNotFoundException(logg);
            }

            return entity;
        }

        public async Task<SessionLogg> GetAsync(Guid id)
        {
            //  await this.EnforceSessionLoggExistenceAsync(id);

            var entity = await _sessionRepository.GetAsync(id);
            return entity;
        }


        /*  public async Task<SessionLogg> DeleteAsync(Guid id)
         {
             await this.EnforceSessionLoggExistenceAsync(id);

             var entity = await _sessionRepository.DeleteAsync(id);
             return entity;
         }*/

        public async Task<IEnumerable<SessionLogg>> ListAsync()
        {
            return await _sessionRepository.ListAsync();
        }


        public async Task<SessionLogg> GetRecentlyAsync(string id)
        {
            var entities = await _sessionRepository.ListAsync();

            var user = entities.Where(c => c.UserId == id).OrderByDescending(c => c.Date).FirstOrDefault();
            if (user == null)
            {
                throw new SessionLoggNotFoundException();
            }

            return user;
        }

        public async Task<SessionLogg> EnforceSessionLoggExistenceAsync(Guid id)
        {
            var act = await _sessionRepository.GetAsync(id);

            if (act == null)
            {
                throw new SessionLoggNotFoundException();
            }

            return act;
        }

    }

}