using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//apis
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;

using JobProductiveAsync = surflex.netcore22.APIs.Gateway.JobProductiveAsync;
//model
//using surflex.netcore22.Models;

namespace surflex.netcore22.APIs
{
    public interface IClientService
    {
        Task<IEnumerable<ProjectAsync>> ListPlannedProjectAsync();

        Task<WellAsync> GetPlannedWellAsync(string name);

        Task<IEnumerable<WellPlannedAsync>> ListPlannedWellAsync(int id);

        Task<bool> IsWellProductiveAsync(IEnumerable<WellPlannedAsync> wells);
        Task<IEnumerable<ProjectAsync>> ListPlannedProjectWellAsync(IEnumerable<WellProductiveAsync> wells);
        Task<IEnumerable<WellProductiveAsync>> ListWellProductiveAsync();
        Task<WellReserveAsync> GetWellPlannedWellReserveAsync(string name);
        Task<JobProductiveAsync> GetJobProductiveAsync(string name);

        Task<WellProductiveAsync> GetWellProductiveAsync(string name);

        //for TCRS
        Task<PlatformAsync> GetDefaultPlatformAsync(string name);
        //fomular volumn factor
        Task<IEnumerable<Factor>> ListFactorProfileAsync(string type);
        Task<IEnumerable<Analogy>> ListAnalogyAsync(string type);
        Task<Usi> GetSandInfoAsync(string name);

        Task<Product> GetCalculatedProductAsync(Product _product);

        Task<string[]> ListWellReservesCategoryAsync();
        Task<string[]> ListDepletionTypeAsync();

        Task<IEnumerable<SandAsync>> ListSandAsync(string name);
        Task<WellAnalogyAsync> GetWellUDVAnalogyAsync(string name);


        Task<IEnumerable<WellPayAsync>> GetWellPayAsync(string[] name);

        Task<JobAsync> GetJobProductiveCostAsync(string name);
    }
}