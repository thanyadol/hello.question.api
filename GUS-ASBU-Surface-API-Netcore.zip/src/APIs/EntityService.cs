using System; 

using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

//log
using Serilog;


//apis
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;
using surflex.netcore22.APIs.Repository;

using JobProductiveAsync = surflex.netcore22.APIs.Gateway.JobProductiveAsync;

//model
//using surflex.netcore22.Models;

namespace surflex.netcore22.APIs
{
    public class EntityService : IEntityService
    {
        private readonly IJobRepository _jobRepository;
        private readonly IProjectRepository _projectRepository;
        private readonly IWellRepository _wellRepository;

        private readonly ISandRepository _sandRepository;

        public EntityService(IJobRepository jobRepository, IProjectRepository projectRepository,
                    IWellRepository wellRepository, ISandRepository sandRepository)
        {
            _projectRepository = projectRepository ?? throw new ArgumentNullException(nameof(projectRepository));
            _jobRepository = jobRepository ?? throw new ArgumentNullException(nameof(jobRepository));
            _wellRepository = wellRepository ?? throw new ArgumentNullException(nameof(wellRepository));

            _sandRepository = sandRepository ?? throw new ArgumentNullException(nameof(sandRepository));

        }

        public async Task<IEnumerable<ProjectAsync>> ListPlannedProjectAsync()
        {
            var entity = await _projectRepository.ListAsync();
            return entity;
        }


        public async Task<IEnumerable<ProjectAsync>> ListPlannedProjectWellAsync(string[] wells)//(IEnumerable<WellProductiveAsync> wells)
        {
            var entity = await _projectRepository.ListProductiveAsync(wells);
            return entity;

        }


        public async Task<IEnumerable<JobAsync>> ListPlannedJobAsync(string[] name)
        {
            var entity = await _jobRepository.ListAsync(name);
            return entity;
        }


        public async Task<IEnumerable<Gateway.WellPlannedAsync>> ListPlannedWellAsync(int id)
        {
            var entity = await _wellRepository.ListAsync(id);
            return entity;
        }


        public async Task<WellAsync> GetPlannedWellAsync(string name)
        {
            var entity = await _wellRepository.GetAsync(name);
            return entity;
        }



        public async Task<IEnumerable<WellPlannedAsync>> ListPlannedProductiveAsync(string[] wells)
        {
            var entity = await _wellRepository.ListPlannedProductiveAsync(wells);
            return entity;

        }

        public async Task<JobProductiveAsync> GetJobProductiveAsync(string name)
        {
            var job = await _jobRepository.GetProductiveAsync(name);
            return job;

        }

        public async Task<JobProductiveAsync> GetJobRotaryAsync(string name)
        {
            var job = await _jobRepository.GetRotaryAsync(name);
            return job;

        }


        // public async Task<IEnumerable<WellProductiveAsync>> ListWellProductiveAsync(IEnumerable<WellPlannedAsync> wells)
        // {
        //     var entity = await _wellRepository.ListProductiveAsync(wells);
        //     return entity;

        // }


        public async Task<IEnumerable<WellProductiveAsync>> ListWellProductiveAsync()
        {
            var entity = await _wellRepository.ListProductiveAsync();
            return entity;
        }


        public async Task<WellProductiveAsync> GetWellProductiveAsync(string name)
        {
            var entity = await _wellRepository.GetProductiveAsync(name);
            return entity;
        }

        public async Task<WellReserveAsync> GetWellPlannedWellReserveAsync(string name)
        {
            var entity = await _wellRepository.GetPlannedReserveAsync(name);
            return entity;

        }

        public async Task<WellJobProductiveAsync> GetWellUndrilledReserveAsync(string name)
        {
            var entity = await _wellRepository.GetActualProductiveAsync(name);
            return entity;

        }

        public async Task<JobAsync> GetPlannedJobAsync(string name)
        {
            var job = await _jobRepository.GetAsync(name);
            return job;

        }


        public async Task<IEnumerable<JobProductiveAsync>> ListJobProductiveAsync(string[] wells)
        {
            var job = await _jobRepository.ListProductiveAsync(wells);
            return job;

        }


        public async Task<IEnumerable<SandAsync>> ListSandAsync(string name)
        {
            var sands = await _sandRepository.ListProductiveAsync(name);
            return sands;

        }

        public async Task<IEnumerable<SandAsync>> ListSandAsync(string[] name)
        {
            var sands = await _sandRepository.ListProductiveAsync(name);
            return sands;

        }


        //
        // Summary:
        //    Return the cost od rig moved from UIDM
        //
        // Returns:
        //     job object
        //
        // Type parameters:
        //   name:
        //    platofrm name
        //

        public async Task<JobAsync> GetJobProductiveCostAsync(string name)
        {
            var sands = await _jobRepository.GetProductiveCostAsync(name);
            return sands;
        }


        public async Task<IEnumerable<JobDrilledAsync>> GetJobDrilledRateAsync(string name)
        {
            var sands = await _jobRepository.GetDrilledRateAsync(name);
            return sands;
        }

        public async Task<WellJobProductiveAsync> GetWellPlannedProductiveCostAsync(string name, string section)
        {
            var entity = await _wellRepository.GetPlannedProductiveCostAsync(name, section);
            return entity;
        }


        public async Task<WellPressureAsync> GetWellPressureAsync(string name)
        {
            var entity = await _wellRepository.GetFreePressureAsync(name);
            return entity;
        }

        public async Task<IEnumerable<WellPressureAsync>> ListWellPressureAsync(string[] names)
        {
            var entities = await _wellRepository.ListFreePressureAsync(names);
            return entities;
        }

        // public async Task<IEnumerable<JobProductiveAsync>> ListJobProductiveDaysAsync(string[] names)
        // {
        //     var entities = await _jobRepository.ListProductiveDaysAsync(names);
        //     return entities;
        // }

        public async Task<WellJobProductiveAsync> GetLatestWellPhaseAsync(string wellName)
        {
            var entity = await _wellRepository.GetLatestWellPhaseAsync(wellName);
            return entity;
        }
    }
}