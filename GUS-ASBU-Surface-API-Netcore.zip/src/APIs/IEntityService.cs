using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//apis
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;
using JobProductiveAsync = surflex.netcore22.APIs.Gateway.JobProductiveAsync;

//model
//using surflex.netcore22.Models;

namespace surflex.netcore22.APIs
{
    public interface IEntityService
    {
        Task<IEnumerable<ProjectAsync>> ListPlannedProjectAsync();
        Task<WellAsync> GetPlannedWellAsync(string name);

        Task<IEnumerable<JobAsync>> ListPlannedJobAsync(string[] name);

        Task<JobProductiveAsync> GetJobProductiveAsync(string name);

        Task<IEnumerable<WellPlannedAsync>> ListPlannedWellAsync(int id);

        //Task<bool> IsWellProductiveAsync(IEnumerable<WellPlannedAsync> wells);
        Task<IEnumerable<ProjectAsync>> ListPlannedProjectWellAsync(string[] wells);//(IEnumerable<WellProductiveAsync> wells);
        Task<IEnumerable<WellProductiveAsync>> ListWellProductiveAsync();

        Task<IEnumerable<Gateway.JobProductiveAsync>> ListJobProductiveAsync(string[] wells);
        //  Task<IEnumerable<WellProductiveAsync>> ListWellProductiveAsync(IEnumerable<WellPlannedAsync> wells);

        Task<IEnumerable<WellPlannedAsync>> ListPlannedProductiveAsync(string[] wells);
        Task<WellReserveAsync> GetWellPlannedWellReserveAsync(string name);
        Task<WellJobProductiveAsync> GetWellUndrilledReserveAsync(string name);
        Task<JobAsync> GetPlannedJobAsync(string name);

        Task<WellProductiveAsync> GetWellProductiveAsync(string name);

        //Task<IEnumerable<JobAsync>> ListPlannedJobAsync(string[] name);

        Task<IEnumerable<SandAsync>> ListSandAsync(string name);
        Task<IEnumerable<SandAsync>> ListSandAsync(string[] name);

        Task<JobAsync> GetJobProductiveCostAsync(string name);

        Task<IEnumerable<JobDrilledAsync>> GetJobDrilledRateAsync(string name);

        Task<WellJobProductiveAsync> GetWellPlannedProductiveCostAsync(string name, string section);


        Task<WellPressureAsync> GetWellPressureAsync(string name);
        Task<IEnumerable<WellPressureAsync>> ListWellPressureAsync(string[] name);

        //Task<IEnumerable<JobProductiveAsync>> ListJobProductiveDaysAsync(string[] names);


        Task<JobProductiveAsync> GetJobRotaryAsync(string name);

        Task<WellJobProductiveAsync> GetLatestWellPhaseAsync(string wellName);
    }
}