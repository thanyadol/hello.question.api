using System;

using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

//log
using Serilog;
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;

using Depletion = surflex.netcore22.APIs.Model.Depletion;
using Category = surflex.netcore22.APIs.Model.Category;
using JobProductiveAsync = surflex.netcore22.APIs.Gateway.JobProductiveAsync;
using WellPlannedAsync = surflex.netcore22.APIs.Gateway.WellPlannedAsync;

//model
//using surflex.netcore22.Models;

namespace surflex.netcore22.APIs
{
    public class ClientService : IClientService
    {
        private readonly HttpClient _httpClient;

        private string _remoteServiceBaseUrl; // = "https://localhost:5001";
        private string _remoteTCRSServiceBaseUrl;


        private const string PROFILE_BO_METHOD = "getfvfboprofiledata";
        private const string PROFILE_BG_METHOD = "getfvfbgprofiledata";

        private const string ANALOG_SET_METHOD = "GetAnalogyDataSetData";
        private const string ANALOG_SCENARIO_METHOD = "GetAllAnalogyScenarioData";

        // private const string GAS_PRODUCT_TYPE = "postcalculategasproduct";

        //private const string OIL_PRODUCT_TYPE = "postcalculateoilproduct";


        private readonly IConfiguration _configuration;

        public ClientService(HttpClient httpClient, IConfiguration configuration)
        {
            // _httpClient = httpClient;
            _configuration = configuration;

            //var credentialsCache = new CredentialCache { { uri, "NTLM", CredentialCache.DefaultNetworkCredentials } };
            //var handler = new HttpClientHandler { Credentials = credentialsCache };

            // Create an HttpClientHandler object and set to use default credentials
            HttpClientHandler handler = new HttpClientHandler();
            handler.UseDefaultCredentials = true;
            //handler.UseProxy = false;

            // handler.Credentials = new NetworkCredential("svc-bkkhq-surface-dv", "svc-bkkhq-surface-dv", "CT");

            // Create an HttpClient object
            _httpClient = new HttpClient(handler);

            _remoteServiceBaseUrl = _configuration["ApiSettings:RemoteServiceBaseUrl"];
            _remoteTCRSServiceBaseUrl = _configuration["ApiSettings:TCRSServiceBaseUrl"];
        }

        //
        // Summary:
        //   list of planned project from RLLCP
        //
        // Returns:
        //    project list
        //
        public async Task<IEnumerable<ProjectAsync>> ListPlannedProjectAsync()
        {
            //RLLCP enpoint
            var uri = new Uri(_remoteServiceBaseUrl + "/apis/1.0/project/list");

            //call
            var result = await _httpClient.GetAsync(uri);

            try
            {
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            // var wells = JsonConvert.DeserializeObject<WellProductiveAsync>(httpReponse);

            //return
            //var httpReponse = await result.Content.ReadAsStringAsync();
            var projects = JsonConvert.DeserializeObject<ProjectAsync[]>(httpReponse);

            //mappler

            //persis to live

            return projects;
        }


        //
        // Summary:
        //   list of well by project from RLLCP
        //
        // Returns:
        //    well list
        //
        // Type parameters:
        //   id:
        //   project id
        //
        public async Task<IEnumerable<WellPlannedAsync>> ListPlannedWellAsync(int id)
        {
            //RLLCP enpoint
            var uri = new Uri(_remoteServiceBaseUrl + $"/apis/1.0/well/listbyproject?id={id}");

            //call
            //ar result = await _httpClient.GetStringAsync(uri);

            // Act
            var result = await _httpClient.GetAsync(uri);

            try
            {
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var wells = JsonConvert.DeserializeObject<WellPlannedAsync[]>(httpReponse);

            //return
            //var httpReponse = await result.Content.ReadAsStringAsync();
            //var wells = JsonConvert.DeserializeObject<WellPlannedAsync[]>(result);

            //mappler

            //persis to live

            return wells;
        }

        //
        // Summary:
        //   list of planned well by project
        //
        // Returns:
        //    planned well props by name for dsiplay on well summary section
        //
        // Type parameters:
        //   name:
        //    well name
        //
        public async Task<WellAsync> GetPlannedWellAsync(string name)
        {
            //RLLCP enpoint
            var uri = new Uri(_remoteServiceBaseUrl + $"/apis/1.0/well/get?name={ name }");

            // Act
            var result = await _httpClient.GetAsync(uri);

            try
            {
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            //var wells = JsonConvert.DeserializeObject<WellPlannedAsync[]>(httpReponse);

            //return
            //var httpReponse = await result.Content.ReadAsStringAsync();
            var wells = JsonConvert.DeserializeObject<WellAsync>(httpReponse);

            //mappler

            //persis to live

            return wells;
        }

        //
        // Summary:
        //   is well productive ??
        //
        // Returns:
        //    bool
        //
        // Type parameters:
        //   wells:
        //    list of well productive
        //
        public async Task<bool> IsWellProductiveAsync(IEnumerable<WellPlannedAsync> wells)
        {

            //RLLCP enpoint
            var uri = new Uri(_remoteServiceBaseUrl + "/apis/1.0/well/isproductive");

            var json = JsonConvert.SerializeObject(wells);
            var buffer = Encoding.UTF8.GetBytes(json);
            var byteContent = new ByteArrayContent(buffer);
            byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            var result = await _httpClient.PostAsync(uri, byteContent);

            try
            {
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPPOST", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();

            //return
            //var httpReponse = await result.Content.ReadAsStringAsync();
            var flag = JsonConvert.DeserializeObject<bool>(httpReponse);

            //mappler

            //persis to live

            return flag;
        }

        //
        // Summary:
        //    Return a planned project form up to well productive report 
        //
        // Returns:
        //    list of active projsct
        //
        // Type parameters:
        //   wells:
        //    list of well productive
        //
        public async Task<IEnumerable<ProjectAsync>> ListPlannedProjectWellAsync(IEnumerable<WellProductiveAsync> wells)
        {

            //RLLCP enpoint
            var uri = new Uri(_remoteServiceBaseUrl + "/apis/1.0/project/isproductive");

            var json = JsonConvert.SerializeObject(wells);
            var buffer = Encoding.UTF8.GetBytes(json);
            var byteContent = new ByteArrayContent(buffer);
            byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            var result = await _httpClient.PostAsync(uri, byteContent);
            try
            {
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPPOST", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();

            //return
            //var httpReponse = await result.Content.ReadAsStringAsync();
            var project = JsonConvert.DeserializeObject<IEnumerable<ProjectAsync>>(httpReponse);

            //mappler

            //persis to live\\\\\\\\
            return project;
        }

        //
        // Summary:
        //    Return a list Well productive form am report (WFM_CV_NON_PRODUCTIVE_RPT)
        //
        // Returns:
        //    latestet well productive report 
        //
        public async Task<IEnumerable<WellProductiveAsync>> ListWellProductiveAsync()
        {

            //RLLCP enpoint
            var uri = new Uri(_remoteServiceBaseUrl + $"/apis/1.0/well/listproductive");

            // Act
            var result = await _httpClient.GetAsync(uri);

            try
            {
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();

            //return
            //var httpReponse = await result.Content.ReadAsStringAsync();
            var wells = JsonConvert.DeserializeObject<WellProductiveAsync[]>(httpReponse);

            //mappler

            //persis to live
            return wells;
        }


        //
        // Summary:
        //    Return a Well productive  form am report (WFM_CV_NON_PRODUCTIVE_RPT)
        //
        // Returns:
        //    latestet well productive report 
        //
        // Type parameters:
        //   name:
        //    wellname
        //
        public async Task<WellProductiveAsync> GetWellProductiveAsync(string name)
        {
            //UIDM enpoint
            var uri = new Uri(_remoteServiceBaseUrl + $"/apis/1.0/well/productive?name={name}");

            // Act
            var result = await _httpClient.GetAsync(uri);

            try
            {
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var wells = JsonConvert.DeserializeObject<WellProductiveAsync>(httpReponse);

            //mappler

            //persis to live

            return wells;
        }

        //
        // Summary:
        //    Return a Well planned reserve for display on well summary
        //
        // Returns:
        //     planned reserve of well
        //
        // Type parameters:
        //   name:
        //    wellname
        //
        public async Task<WellReserveAsync> GetWellPlannedWellReserveAsync(string name)
        {
            //UIDM enpoint
            var uri = new Uri(_remoteServiceBaseUrl + $"/apis/1.0/well/reserve?name={name}");

            //call
            // var result = await _httpClient.GetStringAsync(uri);

            // Act
            var result = await _httpClient.GetAsync(uri);

            try
            {
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var wells = JsonConvert.DeserializeObject<WellReserveAsync>(httpReponse);

            //mappler

            //persis to live

            return wells;
        }


        //
        // Summary:
        //    Return a JOB productive (drill) report from am report (CV_WV_JOBREPORT)
        //
        // Returns:
        //     lastest productive report job record
        // Type parameters:
        //   name:
        //    wellname
        //
        public async Task<JobProductiveAsync> GetJobProductiveAsync(string name)
        {
            //UIDM enpoint
            var uri = new Uri(_remoteServiceBaseUrl + $"/apis/1.0/job/productive?name={name}");
            var result = await _httpClient.GetAsync(uri);

            try
            {
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var job = JsonConvert.DeserializeObject<JobProductiveAsync>(httpReponse);

            //return
            //var httpReponse = await result.Content.ReadAsStringAsync();
            //var job = JsonConvert.DeserializeObject<JobProductive>(result);

            //mappler

            //persis to live
            return job;
        }


        //
        // Summary:
        //    Return a SAND info from TCRS
        //
        // Returns:
        //     USI class storring a some sand info props
        // Type parameters:
        //   usi:
        //    sand uis (wellname + topmd + basemd)
        //
        public async Task<Usi> GetSandInfoAsync(string usi)
        {
            //UIDM enpoint
            var uri = new Uri(_remoteTCRSServiceBaseUrl + $"/api/volumetric/getsandinfodata/{usi}");

            //call
            // var result = await _httpClient.GetStringAsync(uri);

            // Act
            var result = await _httpClient.GetAsync(uri);

            try
            {
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var sand = JsonConvert.DeserializeObject<Usi>(httpReponse);

            //mappler

            //persis to live

            return sand;
        }


        //
        // Summary:
        //    Return platform from TCRS endpoind
        //
        // Returns:
        //     platform props
        // Type parameters:
        //   name:
        //    platform name
        //
        public async Task<PlatformAsync> GetDefaultPlatformAsync(string name)
        {

            //UIDM enpoint
            var uri = new Uri(_remoteTCRSServiceBaseUrl + $"/api/volumetric/GetPlatformData/{name}");

            //call
            // var result = await _httpClient.GetStringAsync(uri);

            // Act
            var result = await _httpClient.GetAsync(uri);

            try
            {
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var platform = JsonConvert.DeserializeObject<PlatformAsync>(httpReponse);

            //mappler

            //persis to live

            return platform;
        }

        //
        // Summary:
        //    Return a list of factor profile combobox from TCRS endpoind
        //
        // Returns:
        //     string array

        // Type parameters:
        //   type:
        //    BO (oil) or BG (gas)
        //
        public async Task<IEnumerable<Factor>> ListFactorProfileAsync(string type)
        {
            string method = PROFILE_BO_METHOD;
            if (type.ToUpper() == "BG")
            {
                method = PROFILE_BG_METHOD;
            }

            //UIDM enpoint
            var uri = new Uri(_remoteTCRSServiceBaseUrl + $"/api/volumetric/{method}");

            //call
            // var result = await _httpClient.GetStringAsync(uri);

            // Act
            var result = await _httpClient.GetAsync(uri);

            try
            {
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var profile = JsonConvert.DeserializeObject<Factor[]>(httpReponse);

            //mappler

            //persis to live
            return profile;
        }

        //
        // Summary:
        //    Return alalogy set/scenario combobox from TCRS endpoind
        //
        // Returns:
        //     string array

        // Type parameters:
        //   type:
        //    set or scenario
        //
        public async Task<IEnumerable<Analogy>> ListAnalogyAsync(string type)
        {
            string method = ANALOG_SCENARIO_METHOD;
            if (type.ToUpper() == "SET")
            {
                method = ANALOG_SET_METHOD;
            }

            //UIDM enpoint
            var uri = new Uri(_remoteTCRSServiceBaseUrl + $"/api/volumetric/{method}");

            //call
            // var result = await _httpClient.GetStringAsync(uri);

            // Act
            var result = await _httpClient.GetAsync(uri);

            try
            {
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var analogy = JsonConvert.DeserializeObject<Analogy[]>(httpReponse);

            //mappler

            //persis to live
            return analogy;
        }

        //
        // Summary:
        //    Return depretion type combobox from TCRS endpoind
        //
        // Returns:
        //     string array
        //
        /* public async Task<IEnumerable<Analogy>> ListAnalogyAsync()
        {
            /* string method = ANALOG_SCENARIO_METHOD;
            if (type.ToUpper() == "SET")
            {
                method = ANALOG_SET_METHOD;
            }*

            //UIDM enpoint
            var uri = new Uri(_remoteTCRSServiceBaseUrl + $"/api/volumetric/getanalogyscenariodata");

            //call
            // var result = await _httpClient.GetStringAsync(uri);

            // Act
            var result = await _httpClient.GetAsync(uri);

            try
            {
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var analogy = JsonConvert.DeserializeObject<Analogy[]>(httpReponse);

            //mappler

            //persis to live
            return analogy;
        }*/

        //
        // Summary:
        //    Return depretion type combobox from TCRS endpoind
        //
        // Returns:
        //     string array
        //

        public async Task<string[]> ListDepletionTypeAsync()
        {

            //UIDM enpoint
            var uri = new Uri(_remoteTCRSServiceBaseUrl + $"/api/volumetric/getsanddepletiontypedata");

            //call
            // var result = await _httpClient.GetStringAsync(uri);

            // Act
            var result = await _httpClient.GetAsync(uri);

            try
            {
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var deslpition = JsonConvert.DeserializeObject<string[]>(httpReponse);

            //mappler

            //persis to live
            return deslpition;
        }

        //
        // Summary:
        //    Return reserve catagory combobox from TCRS endpoind
        //
        // Returns:
        //     string array
        //
        public async Task<string[]> ListWellReservesCategoryAsync()
        {

            //UIDM enpoint
            var uri = new Uri(_remoteTCRSServiceBaseUrl + $"/api/volumetric/getopenworkreservescategorydata");

            //call
            // var result = await _httpClient.GetStringAsync(uri);

            // Act
            var result = await _httpClient.GetAsync(uri);

            try
            {
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var deslpition = JsonConvert.DeserializeObject<string[]>(httpReponse);

            //mappler

            //persis to live
            return deslpition;
        }

        //
        // Summary:
        //    Return calculated SAND Product reserve from TCRS endpoind
        //
        // Returns:
        //     calculated Product
        //
        // Type parameters:
        //   product:
        //    product input from frontend
        //
        public async Task<Product> GetCalculatedProductAsync(Product _product)
        {
            /*  string method = OIL_PRODUCT_TYPE;
             if (_product.WellType.ToUpper() == "GAS")
             {
                 method = GAS_PRODUCT_TYPE;
             }*/

            //RLLCP enpoint
            var uri = new Uri(_remoteTCRSServiceBaseUrl + $"/api/volumetric/PostCalculateSandReserve");

            var json = JsonConvert.SerializeObject(_product);
            var buffer = Encoding.UTF8.GetBytes(json);
            var byteContent = new ByteArrayContent(buffer);
            byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            var result = await _httpClient.PostAsync(uri, byteContent);

            try
            {
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPPOST", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();

            //return
            //var httpReponse = await result.Content.ReadAsStringAsync();
            var product = JsonConvert.DeserializeObject<Product>(httpReponse);

            //mappler

            //persis to live\\\\\\\\
            return product;
        }

        //
        // Summary:
        //    Return SAND productive from suface endpoit
        //
        // Returns:
        //     list of sand productive class
        //
        // Type parameters:
        //   name:
        //    well name
        //
        public async Task<IEnumerable<SandAsync>> ListSandAsync(string name)
        {

            //UIDM enpoint
            var uri = new Uri(_remoteServiceBaseUrl + $"/apis/1.0/sand/list?name={name}");

            //call
            // var result = await _httpClient.GetStringAsync(uri);

            // Act
            var result = await _httpClient.GetAsync(uri);

            try
            {
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var sands = JsonConvert.DeserializeObject<SandAsync[]>(httpReponse);

            //mappler

            //persis to live
            return sands;
        }

        //
        // Summary:
        //    Return key (oil gas) value pair of default UDV analogy by well sand from TCRS endpoint
        //
        // Returns:
        //     pair of Analogy class
        //
        // Type parameters:
        //   name:
        //    well name
        //
        public async Task<WellAnalogyAsync> GetWellUDVAnalogyAsync(string name)
        {

            // name = "PMWN-99";

            //RLLCP enpoint
            var uri = new Uri(_remoteTCRSServiceBaseUrl + $"/api/volumetric/GetUDVAnalogyArea/{name}");

            //call
            // var result = await _httpClient.GetStringAsync(uri);

            // Act
            var result = await _httpClient.GetAsync(uri);

            try
            {
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var entity = JsonConvert.DeserializeObject<WellAnalogyAsync>(httpReponse);

            entity.WellName = name;

            //persis to live\\\\\\\\
            return entity;
        }


        //
        // Summary:
        //    Return list of well pay from TCRS for project summary
        //
        // Returns:
        //     list of well pay
        //
        // Type parameters:
        //   name:
        //    list of well name
        //
        public async Task<IEnumerable<WellPayAsync>> GetWellPayAsync(string[] name)
        {

            //RLLCP enpoint
            var uri = new Uri(_remoteTCRSServiceBaseUrl + $"/api/volumetric/GETPROJECTSUMMARY");

            var json = JsonConvert.SerializeObject(name);
            var buffer = Encoding.UTF8.GetBytes(json);
            var byteContent = new ByteArrayContent(buffer);

            byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            var result = await _httpClient.PostAsync(uri, byteContent);

            try
            {
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPPOST", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();

            //return
            //var httpReponse = await result.Content.ReadAsStringAsync();
            var pays = JsonConvert.DeserializeObject<WellPayAsync[]>(httpReponse);

            //mappler

            //persis to live\\\\\\\\
            return pays;
        }

        //
        // Summary:
        //    Return the cost od rig moved from UIDM
        //
        // Returns:
        //     job object
        //
        // Type parameters:
        //   name:
        //    platofrm name
        //

        public async Task<JobAsync> GetJobProductiveCostAsync(string name)
        {
            await Task.Delay(0);
            throw new NotImplementedException();
        }

    }
}