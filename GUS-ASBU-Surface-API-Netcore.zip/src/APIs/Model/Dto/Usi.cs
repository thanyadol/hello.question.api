using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Model
{
    public class Usi
    {
        public string SandUSI { get; set; }
        public Nullable<decimal> MechanicalDF { get; set; }
        public Nullable<decimal> CementQualityDF { get; set; }
        public Nullable<decimal> Co2DF { get; set; }
        public Nullable<decimal> BcDF { get; set; }
        public string DepletionCategory { get; set; }

    }
}