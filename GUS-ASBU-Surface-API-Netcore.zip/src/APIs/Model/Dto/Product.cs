using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Model
{
    public class Product
    {
        //GAS or OIL
        public string Type { get; set; }
        /* public Product()
        {
            Type = "OIL";
        }
        public Product(string type)
        {
            Type = type;
        }*/

        public string PlatformName { get; set; }
        public string WellType { get; set; }
        public decimal BgProfileID { get; set; }
        public decimal BoProfileID { get; set; }
        public decimal PipelinePressure { get; set; }
        public decimal OilPipelinePressureCoeff { get; set; }
        public decimal GasPipelinePressureCoeff { get; set; }
        public decimal BcPos { get; set; }
        public decimal BcCompressionRatio { get; set; }
        public decimal OilAnalogyDatasetId { get; set; }
        public decimal OilAnalogyScenarioId { get; set; }

        public decimal GasAnalogyDatasetId { get; set; }
        public decimal GasAnalogyScenarioId { get; set; }

        public Nullable<decimal> NetGasPay { get; set; }

        public Nullable<decimal> NetOilPay { get; set; }
        public Nullable<decimal> WaterSaturation { get; set; }
        public Nullable<decimal> Porosity { get; set; }
        public Nullable<decimal> SubseaDepth { get; set; }
        public Nullable<decimal> PressureRFT { get; set; }

        public Nullable<decimal> PressurePPi { get; set; }

        public Nullable<decimal> PressureInitial { get; set; }
        public Nullable<decimal> MechanicalDf { get; set; }
        public Nullable<decimal> Co2Df { get; set; }
        public Nullable<decimal> CementQualityDf { get; set; }
        public Nullable<decimal> BcDf { get; set; }
        public string DepletionCategory { get; set; }
        public string OpenworksReservesCategory { get; set; }
        public decimal GOR { get; set; }
        public decimal CGR { get; set; }

        //output
        public Nullable<decimal> OilP1dnWBC { get; set; }
        public Nullable<decimal> OilP1dnWoBC { get; set; }
        public Nullable<decimal> OilBcIncremental { get; set; }
        public Nullable<decimal> OOIP { get; set; }
        public Nullable<decimal> OilDepletionDF { get; set; }
        public Nullable<decimal> OilRF { get; set; }


        public Nullable<decimal> OilRE { get; set; }

        public Nullable<decimal> BoValue { get; set; }
        public Nullable<decimal> OilRecoveryDF { get; set; }

        public Nullable<decimal> FreeGasP1dnWBC { get; set; }
        public Nullable<decimal> FreeGasP1dnWoBC { get; set; }
        public Nullable<decimal> FreeGasBcIncremental { get; set; }
        public Nullable<decimal> OGIP { get; set; }
        public Nullable<decimal> GasDepletionDF { get; set; }
        public Nullable<decimal> GasRF { get; set; }

        public Nullable<decimal> GasRE { get; set; }
        public Nullable<decimal> BgValue { get; set; }
        public Nullable<decimal> GasRecoveryDF { get; set; }

        public Nullable<decimal> CondyP1dnWBC { get; set; }
        public Nullable<decimal> SolGasP1dnWBC { get; set; }
    }
}