using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Model
{
    public class Factor
    {

        public int Id { get; set; }

        public string Name { get; set; }


        public decimal FVFProfileID { get; set; }

        public string FVFProfileName { get; set; }
    }
}