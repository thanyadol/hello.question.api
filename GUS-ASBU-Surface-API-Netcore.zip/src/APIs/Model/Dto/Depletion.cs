using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Model
{
    public class Depletion
    {
        public string Id { get; set; }
        public string Type { get; set; }
    }
}