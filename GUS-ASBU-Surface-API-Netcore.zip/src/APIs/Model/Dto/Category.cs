using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Model
{
    public class Category
    {
        public string Id { get; set; }
        public string Value { get; set; }
    }
}