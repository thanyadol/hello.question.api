using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Model
{
    public class Analogy
    {
        public int Id { get; set; }
        public int SetId { get; set; }

        public string SetName { get; set; }

        public int AnalogyDataSetID { get; set; }
        public string AnalogyDataSetName { get; set; }
        public int AnalogyScenarioID { get; set; }
        public string AnalogyScenarioName { get; set; }

        public Nullable<decimal> GasArea { get; set; }
        public Nullable<decimal> OilArea { get; set; }
    }
}