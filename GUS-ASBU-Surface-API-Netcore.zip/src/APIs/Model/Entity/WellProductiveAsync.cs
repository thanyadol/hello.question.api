using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Model
{
    [Table("WFM_CV_NON_PRODUCTIVE_RPT", Schema = "UIDM")]
    public class WellProductiveAsync
    {
        //[Column("WELL_ID")]
        [NotMapped]
        public int Id { get; set; }



        [Column("RIGNO")]
        public string RiggName { get; set; }

        [Column("WELLNAME")]
        public string Name { get; set; }

        [Column("WB_CODE")]
        public string Code { get; set; }

        [Column("DTTMSTART")]

        public Nullable<DateTime> StartDate { get; set; }


        [Column("DTTMEND")]

        public Nullable<DateTime> EndDate { get; set; }


        [Column("WELL_PHASE")]
        public string WellPhase { get; set; }

        [Column("PHASE1")]
        public string PhaseFirst { get; set; }

        [Column("PHASE2")]
        public string PhaseSecond { get; set; }

        [Column("CASING_SIZE")]
        public string CasingSize { get; set; }

        [NotMapped]
        public string Activity { get; set; } //%COM-PROD%

        [NotMapped]
        public string Status { get; set; }

        [Column("PLANNED_TD_TVD")]
        public Nullable<decimal> PlanTdTvd { get; set; }
    }
}