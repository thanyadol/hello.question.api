using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Model
{
    [Table("CV_WV_RKB", Schema = "UIDM")]
    public class WellRotaryAsync
    {

        [Column("WELLNAME")]
        public string Name { get; set; }

        [Column("WELL_UWI")]
        public string Uwi { get; set; }

        [Column("IDRECWELLBORE")]
        public string WellBoreId { get; set; }

        [Column("RKB")]
        public Nullable<decimal> Rkb { get; set; }

        [Column("CURRENT_KB")]
        public Nullable<decimal> CurrentRkb { get; set; }



    }
}