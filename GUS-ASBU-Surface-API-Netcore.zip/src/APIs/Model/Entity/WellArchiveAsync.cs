using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Model
{
    [Table("CV_TCRS_UDV_WELLS", Schema = "UIDM")]
    public class WellArchiveAsync
    {
        [Column("ARCHIVE_ID")]
        public int ArchiveId { get; set; }

        [Column("UDV_WELL_ID")]
        public int UdvWellId { get; set; }

        [Column("WELL_NAME")]
        public string Name { get; set; }

        [Column("CREATED_DT")]
        public DateTime CreatedDate { get; set; }

    }
}