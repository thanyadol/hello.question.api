using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Model
{
    [Table("RLLCP_WELL", Schema = "RLLCP")]
    public class WellAsync
    {
        [Column("WELL_ID")]
        public int Id { get; set; }

        [Column("WELL_NAME")]
        public string Name { get; set; }

        [Column("WELL_CATEGORY")]
        public string Category { get; set; }

        [Column("WELL_STATUS")]
        public string Status { get; set; }

        [Column("CREATED_DATE")]
        public DateTime CreatedDate { get; set; }

    }
}