using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Model
{
    public class PlatformAsync
    {

        public int Id { get; set; }

        public string Name { get; set; }

        public string WellType { get; set; }

        public decimal BCPos { get; set; }
        public decimal BCCompressionRatio { get; set; }
        public decimal PipelinePressure { get; set; }
        public decimal OilPipelineCoeff { get; set; }
        public decimal GasPipelineCoeff { get; set; }
        public Nullable<decimal> GOR { get; set; }
        public Nullable<decimal> CGR { get; set; }
    }
}