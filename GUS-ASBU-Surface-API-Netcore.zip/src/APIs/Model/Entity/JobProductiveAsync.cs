using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Model
{
    [Table("CV_WV_JOBREPORT", Schema = "UIDM")]
    public class JobProductiveAsync
    {

        [Column("IDRECJOBRPT")]
        public string Id { get; set; }

        [Column("IDRECJOB")]
        public string JobId { get; set; }



        [Column("JOBRPT_START_DT")]

        public Nullable<DateTime> StartDate { get; set; }


        [Column("JOBRPT_END_DT")]
        public Nullable<DateTime> EndDate { get; set; }

        [Column("COSTTODATECALC")]
        public Nullable<Decimal> CostToDateCalculate { get; set; }

        [Column("DURATIONTIMELOGTOTCUMCALC")]
        public Nullable<Decimal> DurationTimeLogToCumulative { get; set; }


        [Column("STATUS")]
        public string Status { get; set; }

    }
}