using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Model
{
    [Table("CV_WV_JOB", Schema = "UIDM")]
    public class JobAsync
    {
        [Column("IDRECJOB")]
        public string Id { get; set; }

        [Column("WELL_NAME")]
        public string WellName { get; set; }

        [Column("JOBTYP")]
        public string Type { get; set; }

        [Column("DTTMSTART")]

        public Nullable<DateTime> StartDate { get; set; }


        [Column("DTTMEND")]
        public Nullable<DateTime> EndDate { get; set; }

        [Column("TARGETDEPTHTVDCALC")]
        public Nullable<Decimal> TargetDepthTVDCalculate { get; set; }

        [Column("AFEAMTCALC")]
        public Nullable<Decimal> AFTAmountCalculate { get; set; }

        [Column("DurationMLTotalCalc")]
        public Nullable<Decimal> DurationMLTotalCalculate { get; set; }


        //TARGETDEPTH ,TOTALDEPTHCALC 

        [Column("TARGETDEPTH")]
        public Nullable<Decimal> TargetDepth { get; set; }

        [Column("TOTALDEPTHCALC")]
        public Nullable<Decimal> TotalDepthCalculate { get; set; }



        [Column("TOTALDEPTHTVDCALC")]
        public Nullable<Decimal> TotalDepthTVDCalculate { get; set; }



        // [Column("AFEAMTCALC")]
        // public Nullable<Decimal> AmountAFECalculate { get; set; }



        [Column("COSTTOTALCALC")]
        public Nullable<Decimal> TotalCostCalculate { get; set; }




        [Column("IDRECWELLBORE")]
        public string WellBoreId { get; set; }


        // [Column("DURATIONTIMELOGTOTCUMCALC")]
        //public Nullable<Decimal> DurationTimeLogToCumulative { get; set; }


        //[NotMapped]
        //public string Activity { get; set; } //%COM-PROD%

        //[NotMapped]
        //public string Status { get; set; }

    }
}