using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Model
{
    [Table("CV_WV_JOBRENTALITEM", Schema = "UIDM")]
    public class JobDrilledAsync
    {

        [Column("IDREC")]
        public string Id { get; set; }

        [Column("IDRECJOB")]
        public string JobId { get; set; }

        [Column("IDRECWELLBORE")]
        public string WellBoreId { get; set; }

        [Column("WB_NAME")]
        public string WellName { get; set; }


        [Column("DES")]
        public string Description { get; set; }


        [Column("RATEDAY")]
        public Nullable<Decimal> RateInDay { get; set; }
        [Column("RATEDEPTH")]
        public Nullable<Decimal> RateInDepth { get; set; }

        [Column("RATEHOUR")]
        public Nullable<Decimal> RateInHour { get; set; }



        [Column("DTTMSTARTCALC")]

        public Nullable<DateTime> StartDate { get; set; }


        [Column("DTTMENDCALC")]
        public Nullable<DateTime> EndDate { get; set; }


    }
}