using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Model
{
    [Table("RLLCP_PROJECT", Schema = "RLLCP")]
    public class ProjectAsync
    {
        [Column("PROJECT_ID")]
        public int Id { get; set; }

        [Column("DISPLAY_PROJECTNAME")]
        public string Name { get; set; }

        [Column("PROJECT_TYPE")]
        public string Type { get; set; }

        //[Column("TARGET_DATE")]
        //public DateTime Target { get; set; }

        [Column("PLATFORM_NAME")]
        public string Platform { get; set; }

        [Column("OPERATING_AREA")]
        public string Area { get; set; }

        [Column("ASSET")]
        public string Asset { get; set; }


        [Column("PROJECT_STATUS")]
        public string Status { get; set; }

        [Column("CREATED_DATE")]
        public DateTime CreatedDate { get; set; }

    }
}