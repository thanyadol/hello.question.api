using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Model
{
    [Table("UTDBA_CV_STRAT_UNIT_INTERP", Schema = "UIDM")]
    public class SandAsync
    {
        public SandAsync()
        {
            Pos = 1.0m;
        }


        [Column("ID")]
        public int Id { get; set; }

        [Column("WELL_UWI")]
        public string Uwi { get; set; }


        [Column("WELL_NAME_FREE")]
        public string WellName { get; set; }

        [Column("SAND_NAME")]
        public string SandName { get; set; }


        [Column("TOP_MD")]
        public Nullable<decimal> TopMd { get; set; }


        [Column("BASE_MD")]
        public string BaseMd { get; set; }


        [Column("TOP_TVDSS")]
        public string TopTvdss { get; set; }

        [Column("BASE_TVDSS")]
        public string BaseTvdss { get; set; }

        [Column("GOC_TVDSS")]
        public Nullable<decimal> GocTvdss { get; set; }


        [Column("HCWC_TVDSS")]
        public string HcwcTvdss { get; set; }

        [Column("GROSS_SAND_MT")]
        public string GrossSandMT { get; set; }

        [Column("GROSS_SAND_VT")]
        public string GrossSandVT { get; set; }

        // [Column("NETGAS_MT")]
        // public Nullable<decimal> NetGasMT { get; set; }

        // [Column("NETOIL_MT")]
        // public Nullable<decimal> NetOilMT { get; set; }

        [Column("NETGAS_VT")]
        public string NetGasVT { get; set; }

        [Column("NETOIL_VT")]
        public string NetOilVT { get; set; }


        //"RT", "VSH", "POR", "SW", "TG", "MW", "BG", 
        [Column("RT")]
        public string Rt { get; set; }

        [Column("VSH")]
        public string Vsh { get; set; }

        [Column("POR")]
        public string Por { get; set; }

        [Column("SW")]
        public string Sw { get; set; }

        [Column("TG")]
        public string Tg { get; set; }


        [Column("MW")]
        public string Mw { get; set; }

        [Column("BG")]
        public string Bg { get; set; }


        // "EST_PHASE", "REMARK", "AZI", "DATA_SOURCE", "UPDATE_DATE", "CREATED_DATE"

        [Column("PREDICT_FLUIDS")]
        public string Fluid { get; set; }

        [Column("EST_PHASE")]
        public string EstPhase { get; set; }

        [Column("REMARK")]
        public string Remark { get; set; }

        [Column("AZI")]
        public string Azi { get; set; }

        [Column("DATA_SOURCE")]
        public string DataSource { get; set; }

        [Column("UPDATE_DATE")]
        public Nullable<DateTime> UpdatedDate { get; set; }

        [Column("CREATED_DATE")]
        public Nullable<DateTime> CreatedDate { get; set; }



        [NotMapped]
        public Nullable<decimal> Pos { get; set; }

    }
}

