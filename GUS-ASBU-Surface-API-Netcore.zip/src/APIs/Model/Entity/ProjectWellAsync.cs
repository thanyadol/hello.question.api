using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Model
{
    [Table("RLLCP_PROJECT_WELL", Schema = "RLLCP")]
    public class ProjectWellAsync
    {

        [Column("PROJECT_WELL_ID")]
        public int Id { get; set; }

        [Column("WELL_ID")]
        public int WellId { get; set; }

        [Column("PROJECT_ID")]
        public int ProjectId { get; set; }



        [Column("CREATED_DATE")]
        public DateTime CreatedDate { get; set; }

    }
}