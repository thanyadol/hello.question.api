using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Model
{
    [Table("CV_WELL_TEST_RFT", Schema = "UIDM")]
    public class WellPressureAsync
    {
        [Column("UWI")]
        public string Id { get; set; }

        [Column("UWI")]
        public string Uwi { get; set; }

        [Column("WELL_NAME_FREE")]
        public string WellName { get; set; }

        [Column("PRESSURE")]
        public decimal? Pressure { get; set; }


        [Column("TEMPERATURE")]
        public decimal? Temperature { get; set; }


        [Column("TEST_TYPE")]
        public string Type { get; set; }


        [Column("REMARK")]
        public string Remark { get; set; }

        [Column("CREATE_DATE")]
        public DateTime CreatedDate { get; set; }

    }
}