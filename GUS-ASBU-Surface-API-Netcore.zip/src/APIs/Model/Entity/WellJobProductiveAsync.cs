using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Model
{
    [Table("WFO_CV_PROGRAM_PHASE", Schema = "UIDM")]
    public class WellJobProductiveAsync
    {
        //[Column("WELL_ID")]
        [NotMapped]
        public int Id { get; set; }

        [NotMapped]
        // [Column("WELLNAME")]
        public string Name { get; set; }

        [Column("WB_CODE")]
        public string Code { get; set; }



        [Column("WELL_PHASE")]
        public string WellPhase { get; set; }


        [Column("PHASE1")]
        public string PhaseFirst { get; set; }
        [Column("PHASE2")]
        public string PhaseSecond { get; set; }

        [Column("CASING_SIZE")]
        public string CasingSize { get; set; }

        [Column("PRIMARY_JOB_TYPE")]
        public string JobType { get; set; }


        [Column("JOB_CATEGORY")]
        public string JobCategory { get; set; }

        [Column("PLANNED_AFE_COST")]
        public Nullable<decimal> PlannedAFECost { get; set; }



        [Column("DEPTHTVDSTARTACTUALCALC")]
        public Nullable<decimal> ActualTVDStartCalculateDepth { get; set; }

        [Column("PLANNED_START_DEPTH")]
        public Nullable<decimal> PlannedMDStartDepth { get; set; }


        [Column("PLANNED_END_DEPTH")]
        public Nullable<decimal> PlannedMDEndDepth { get; set; }


        [Column("DEPTHTVDENDACTUALCALC")]
        public Nullable<decimal> ActualTVDEndCalculateDepth { get; set; }


        [Column("DEPTHSTARTACTUALCALC")]
        public Nullable<decimal> ActualMDStartCalculateDepth { get; set; }

        [Column("DEPTHENDACTUALCALC")]
        public Nullable<decimal> ActualMDEndCalculateDepth { get; set; }




        [Column("JOB_ACTUAL_START_DATE")]
        public Nullable<DateTime> StartDate { get; set; }

        [Column("JOB_ACTUAL_END_DATE")]
        public Nullable<DateTime> EndDate { get; set; }


        [Column("PH_ACTUAL_START_DT")]
        public Nullable<DateTime> PhaseStartDate { get; set; }

        [Column("PH_ACTUAL_END_DT")]
        public Nullable<DateTime> PhaseEndDate { get; set; }
        
        [Column("SYSSEQ")]
        public Nullable<decimal> Sequence { get; set; }
    }
}