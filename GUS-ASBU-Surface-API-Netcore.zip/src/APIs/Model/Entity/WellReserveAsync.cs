using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Model
{
    //planned well reserve
    [Table("RLLCP_WELL_RESERVES", Schema = "RLLCP")]
    public class WellReserveAsync
    {

        public WellReserveAsync()
        {

        }


        [Column("WELL_RESERVE_ID")]
        public int Id { get; set; }

        [Column("WELL_ID")]
        public int WellId { get; set; }


        [Column("TRUNCATION_FACTORS")]
        public Nullable<decimal> TruncatedFactor { get; set; }

        [Column("OIL_WELL")]
        public Nullable<decimal> OilWell { get; set; }

        // "TRUNCATED_RESERVES_MBOE", "TRUNCATED_RESERVES_BCFE", "FREE_GAS", "SOL_GAS", "OIL", "CONDY", 

        [Column("TRUNCATED_RESERVES_MBOE")]
        public Nullable<decimal> TruncatedWellReserveInMBOE { get; set; }

        [Column("TRUNCATED_RESERVES_BCFE")] // MBOE Unit
        public Nullable<decimal> TruncatedWellReserveInBCFE { get; set; }


        [Column("FREE_GAS")] //Unit MMSCF
        public Nullable<decimal> FreeGas { get; set; }

        [Column("SOL_GAS")] //Unit MMSCF
        public Nullable<decimal> SolGas { get; set; }

        [Column("OIL")] //Unit MMSCF
        public Nullable<decimal> Oil { get; set; }


        [Column("CONDY")] //Unit MMSCF
        public Nullable<decimal> Condy { get; set; }




        [Column("CREATED_DATE")]
        public Nullable<DateTime> CreatedDate { get; set; }


        [Column("UPDATED_DATE")]
        public Nullable<DateTime> UpdatedDate { get; set; }


        [Column("RESERVES_COMMENTS")]
        public string Remarks { get; set; }

    }
}