using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Gateway
{
    public class WellPlannedAsync
    {

        public int Id { get; set; }

        public string Name { get; set; }

        //refrenece key to platform
        public int ProjectId { get; set; }
        public string ProjectStatus { get; set; }

        public string Platform { get; set; }
        //public string WellName { get; set; }

        public string Project { get; set; }

        public string Phase { get; set; }


        public string WellPhase { get; set; }
        public string Activity { get; set; }
        public string Status { get; set; }

        public string OperationArea { get; set; }

        public string Asset { get; set; }
        public DateTime Created { get; set; }


        //UIDM
        public string Code { get; set; }
        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }
        public string PlanTdTvd { get; set; }

        //public IEnumerable<User> Users { get; set; }
        //public IEnumerable<Well> Wells { get; set; }

    }
}