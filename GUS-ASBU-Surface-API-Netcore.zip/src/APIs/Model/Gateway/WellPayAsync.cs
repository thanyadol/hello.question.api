using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Gateway
{
    public class WellPayAsync
    {
        public string WellName { get; set; }
        public bool WellExisted { get; set; }
        public string WellDetResvWithKahCateCode { get; set; }
        public decimal PredrilledNewOilPayFt { get; set; }
        public decimal PredrilledNewGasPayFt { get; set; }
        public decimal PredrilledUntruncatedNewPayFt { get; set; }
        public decimal PredrilledTruncatedNewPayFt { get; set; }
        public decimal TFTotal { get; set; }
        public decimal TotalGasPayFtEV { get; set; }
        public decimal TotalOilPayFtEV { get; set; }
        public decimal TotalNewGasPayFtEV { get; set; }
        public decimal TotalNewOilPayFtEV { get; set; }
        public decimal TotalPayMean { get; set; }
        public decimal UntruncatedGasResvBcf { get; set; }
        public decimal UntruncatedLiqResvMbbl { get; set; }
        public decimal UntruncatedResvMboe { get; set; }
        public decimal TruncatedGasResvBcf { get; set; }
        public decimal TruncatedLiqResvMbbl { get; set; }
        public decimal TruncatedResvMboe { get; set; }
    }

}