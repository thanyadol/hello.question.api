using System; 


namespace surflex.netcore22.APIs.Gateway
{
    public class JobProductiveAsync
    {
        public string Id { get; set; }


        public string JobReportId { get; set; }
        public string WellName { get; set; }


        public string Type { get; set; }


        public Nullable<DateTime> StartDate { get; set; }

        public Nullable<DateTime> EndDate { get; set; }

        public Decimal TargetDepthTVDCalculate { get; set; }

        public Decimal AFTAmountCalculate { get; set; }

        public Decimal DurationMLTotalCalculate { get; set; }

        public Nullable<DateTime> JobReportStartDate { get; set; }


        public Nullable<DateTime> JobReportEndDate { get; set; }

        public Decimal CostToDateCalculate { get; set; }

        public Decimal TargetDepth { get; set; }

        public Decimal TotalDepthCalculate { get; set; }


        public Decimal TotalDepthTVDCalculate { get; set; }

        public Decimal DurationTimeLogToCumulative { get; set; }


        public string Activity { get; set; }

        public string WellUwi { get; set; }
        public string WellBoreId { get; set; }
        public Decimal Rkb { get; set; }

        public Decimal CurrentRkb { get; set; }

        //public Decimal TvdRkb { get; set; }

        public string Status { get; set; }

    }
}