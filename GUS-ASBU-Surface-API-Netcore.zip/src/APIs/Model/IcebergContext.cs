using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using System; 


namespace surflex.netcore22.APIs.Model
{
    public class IcebergContext : DbContext
    {
        public IcebergContext()
        { }

        //virtual for Moq ovverride
        public virtual DbQuery<WellProductiveAsync> WellProductiveAsyncs { get; set; }

        public virtual DbQuery<JobAsync> JobAsyncs { get; set; }
        public virtual DbQuery<JobProductiveAsync> JobProductiveAsyncs { get; set; }

        // public virtual DbQuery<WellReserveAsync> WellReserveAsyncs { get; set; }
        public virtual DbQuery<WellArchiveAsync> WellArchiveAsyncs { get; set; }

        public virtual DbQuery<WellRotaryAsync> WellRotaryAsyncs { get; set; }

        public virtual DbQuery<SandAsync> SandAsyncs { get; set; }
        public virtual DbQuery<JobDrilledAsync> JobDrilledAsyncs { get; set; }

        public virtual DbQuery<WellJobProductiveAsync> WellJobProductiveAsyncs { get; set; }

        public virtual DbQuery<WellPressureAsync> WellPressureAsyncs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Query<WellProductiveAsync>().ToView("WFM_CV_NON_PRODUCTIVE_RPT");
            modelBuilder.Query<JobAsync>().ToView("CV_WV_JOB");
            modelBuilder.Query<WellArchiveAsync>().ToView("CV_TCRS_UDV_WELLS");
            // modelBuilder.Query<WellReserveAsync>().ToView("CV_TCRS_UDV_WELL_RESERVES");

            modelBuilder.Query<JobProductiveAsync>().ToView("CV_WV_JOBREPORT");
            modelBuilder.Query<WellRotaryAsync>().ToView("CV_WV_RKB");

            modelBuilder.Query<SandAsync>().ToView("UTDBA_CV_STRAT_UNIT_INTERP");


            modelBuilder.Query<WellJobProductiveAsync>().ToView("WFO_CV_PROGRAM_PHASE");
            modelBuilder.Query<JobDrilledAsync>().ToView("CV_WV_JOBRENTALITEM");
            modelBuilder.Query<WellPressureAsync>().ToView("CV_WELL_TEST_RFT");

            //convert type
            /* var converter = new ValueConverter<decimal, string>(
            v => v.ToString(),
            v => Convert.ToDecimal(v));

            modelBuilder
                .Query<SandAsync>().ToView("UTDBA_CV_STRAT_UNIT_INTERP")
                .Property(e => e.BaseMd)
                .HasConversion(converter);*/

        }

        public IcebergContext(DbContextOptions<IcebergContext> options)
            : base(options)
        { }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(@"Server=(localdb)\mssqllocaldb;Database=EFProviders.InMemory;Trusted_Connection=True;ConnectRetryCount=0");
            }
        }
    }
}