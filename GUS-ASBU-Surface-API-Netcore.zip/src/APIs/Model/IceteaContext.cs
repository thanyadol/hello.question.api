using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using System; 


namespace surflex.netcore22.APIs.Model
{
    public class IceteaContext : DbContext
    {
        public IceteaContext()
        { }

        //virtual for Moq ovverride
        public virtual DbQuery<WellAsync> WellAsyncs { get; set; }
        public virtual DbQuery<WellReserveAsync> WellReserveAsyncs { get; set; }
        public virtual DbQuery<ProjectAsync> ProjectAsyncs { get; set; }
        public virtual DbQuery<ProjectWellAsync> ProjectWellAsyncs { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Query<WellAsync>().ToView("RLLCP_WELL");
            modelBuilder.Query<ProjectAsync>().ToView("RLLCP_PROJECT");
            modelBuilder.Query<ProjectWellAsync>().ToView("RLLCP_PROJECT_WELL");
            modelBuilder.Query<WellReserveAsync>().ToView("RLLCP_WELL_RESERVES");
        }

        public IceteaContext(DbContextOptions<IceteaContext> options)
            : base(options)
        { }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(@"Server=(localdb)\mssqllocaldb;Database=EFProviders.InMemory;Trusted_Connection=True;ConnectRetryCount=0");
            }
        }
    }
}