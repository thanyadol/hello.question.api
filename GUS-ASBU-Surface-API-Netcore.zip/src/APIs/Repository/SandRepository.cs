using System; 

using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

//log
using Serilog;
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;



namespace surflex.netcore22.APIs.Repository
{
    public interface ISandRepository
    {
        Task<IEnumerable<SandAsync>> ListProductiveAsync(string[] name);
        Task<IEnumerable<SandAsync>> ListProductiveAsync(string name);
    }

    public class SandRepository : ISandRepository
    {

        //private readonly IceteaContext _iceteaContext;
        private readonly IcebergContext _icebergContext;

        public SandRepository(IcebergContext icecontext)
        {
            //_iceteaContext = wwcontext ?? throw new ArgumentNullException(nameof(wwcontext));
            _icebergContext = icecontext ?? throw new ArgumentNullException(nameof(icecontext));
        }

        public async Task<IEnumerable<SandAsync>> ListProductiveAsync(string name)
        {
            //var entities = await _icebergContext
            //                 ).ToListAsync();


            //exsactly mathc !!!
            return await _icebergContext.SandAsyncs.Where(c => c.WellName == name).ToListAsync();
        }


        public async Task<IEnumerable<SandAsync>> ListProductiveAsync(string[] name)
        {
            var hashset = new HashSet<string>(name);

            var query = await _icebergContext.SandAsyncs.Where(c => hashset.Contains(c.WellName)).ToListAsync();
            // .GroupBy(c => new { c.WellName, c.UpdatedDate }).Select(x => x.First()).ToListAsync();

            return query;
        }

    }
}