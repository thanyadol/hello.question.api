using System;

using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

//log
using Serilog;
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;
using surflex.netcore22.APIs.Extensions;
using JobProductiveAsync = surflex.netcore22.APIs.Gateway.JobProductiveAsync;
using System.Diagnostics;

//model
//using surflex.netcore22.Models;

namespace surflex.netcore22.APIs.Repository
{
    public interface IJobRepository
    {
        //rig move cost
        Task<JobAsync> GetProductiveCostAsync(string name);
        Task<JobProductiveAsync> GetProductiveAsync(string name);

        Task<JobAsync> GetAsync(string name);
        Task<IEnumerable<JobAsync>> ListAsync(string[] name);
        //Task<IEnumerable<JobAsync>> ListProductiveAsync(IEnumerable<WellPlannedAsync> wells);
        Task<IEnumerable<JobProductiveAsync>> ListProductiveAsync(string[] names);

        Task<IEnumerable<JobDrilledAsync>> GetDrilledRateAsync(string name);
        //   Task<IEnumerable<JobProductiveAsync>> ListProductiveDaysAsync(string[] names);

        Task<JobProductiveAsync> GetRotaryAsync(string name);
    }


    public class JobRepository : IJobRepository
    {
        private const string DRILL_AND_COMPLETE = "Drill and Complete";

        private const string SIDETRACK_AND_COMPLETE = "Sidetrack and Complete";

        private readonly IcebergContext _icebergContext;
        private readonly IWellRepository _wellRepository;

        public JobRepository(IcebergContext icecontext, IWellRepository wellRepository)
        {
            // _iceteaContext = wwcontext ?? throw new ArgumentNullException(nameof(wwcontext));
            _icebergContext = icecontext ?? throw new ArgumentNullException(nameof(icecontext));
            _wellRepository = wellRepository ?? throw new ArgumentNullException(nameof(wellRepository));
        }

        /*  public async Task<IEnumerable<JobAsync>> ListProductiveAsync(IEnumerable<WellPlannedAsync> wells)
         {
             //DateTime enddate = Utility.ToSEAsiaStandardTime().AddDays(ADD_DAY);
             //max date record is yesterday
             var entities = await _icebergContext.JobAsyncs
                                .Where(x => wells.Any(c => _wellRepository.IsWellProductiveAsync(x.WellName, c.Name)
                                  && (x.Type == DRILL_AND_COMPLETE || x.Type == SIDETRACK_AND_COMPLETE)))
                                .ToListAsync();
             //.OrderByDescending(c => c.EndDate)
             //.OrderByDescending(c => c.EndDate)

             return entities;
         }*/


        //get productive cost (rigg move cost)
        public async Task<JobAsync> GetProductiveCostAsync(string name)
        {
            var prefix = "RM%" + name;  //RM_from_name


            var entity = await _icebergContext.JobAsyncs.Where(c => c.WellName.Like(prefix))
                            .OrderByDescending(c => c.StartDate).FirstOrDefaultAsync();

            return entity;
        }


        public async Task<IEnumerable<JobDrilledAsync>> GetDrilledRateAsync(string name)
        {
            var date = _icebergContext.JobDrilledAsyncs.Where(x => x.WellName == name).Max(x => x.StartDate);

            var entity = await _icebergContext.JobDrilledAsyncs.Where(c => c.WellName == name
                                && c.StartDate == date).ToListAsync();

            return entity;
        }


        public async Task<JobAsync> GetAsync(string name)
        {
            var entities = await (from j in _icebergContext.JobAsyncs
                                  where (j.Type == DRILL_AND_COMPLETE || j.Type == SIDETRACK_AND_COMPLETE)
                                  && j.WellName == name
                                  select new JobAsync()
                                  {
                                      Id = j.Id,
                                      WellName = j.WellName,
                                      Type = j.Type,
                                      StartDate = j.StartDate,
                                      EndDate = j.EndDate,

                                      // TargetDepthTVDCalculate = j.TargetDepthTVDCalculate.GetValueOrDefault(),
                                      // AFTAmountCalculate = j.AFTAmountCalculate.GetValueOrDefault(),
                                      // DurationMLTotalCalculate = j.DurationMLTotalCalculate.GetValueOrDefault(),

                                      //TargetDepth = j.TargetDepth.GetValueOrDefault(),
                                      //TotalDepthCalculate = j.TotalDepthCalculate.GetValueOrDefault(),
                                      // TotalDepthTVDCalculate = j.TotalDepthTVDCalculate.GetValueOrDefault(),

                                  }).FirstOrDefaultAsync();

            return entities;
        }


        public async Task<IEnumerable<JobAsync>> ListAsync(string[] name)
        {
            var hashset = new HashSet<string>(name);

            var entities = await (from j in _icebergContext.JobAsyncs
                                  where (j.Type == DRILL_AND_COMPLETE || j.Type == SIDETRACK_AND_COMPLETE)
                                  && hashset.Contains(j.WellName)
                                  select new JobAsync()
                                  {
                                      Id = j.Id,
                                      WellName = j.WellName,
                                      Type = j.Type,
                                      StartDate = j.StartDate,
                                      EndDate = j.EndDate,

                                  }).ToListAsync();

            return entities;
        }


        public async Task<JobProductiveAsync> GetRotaryAsync(string name)
        {
            //"Completed" is the well in the project that drilling activities have ended < Drilling Job End date is not null >
            //"Drilling  with < Activity > " is the well in the project that currently has drilling activities <Drilling Job End date is null> and Drilling in Production Section <Activity like " % PROD % ">
            //ELSE status = "Planned"

            var hashset = new HashSet<string>(new string[] { name });
            var entities = await (from j in _icebergContext.JobAsyncs
                                      //join jp in _icebergContext.JobProductiveAsyncs on j.Id equals jp.JobId
                                  join r in _icebergContext.WellRotaryAsyncs on j.WellBoreId equals r.WellBoreId
                                  where hashset.Contains(j.WellName)
                                  select new JobProductiveAsync()
                                  {

                                      WellUwi = r.Uwi,
                                      WellBoreId = r.WellBoreId,
                                      Rkb = r.Rkb.GetValueOrDefault(),
                                      CurrentRkb = r.CurrentRkb.GetValueOrDefault(),

                                  }).ToListAsync();

            return entities.FirstOrDefault();
        }


        public async Task<JobProductiveAsync> GetProductiveAsync(string name)
        {
            // var sw = new Stopwatch();
            // sw.Start();

            //"Completed" is the well in the project that drilling activities have ended < Drilling Job End date is not null >
            //"Drilling  with < Activity > " is the well in the project that currently has drilling activities <Drilling Job End date is null> and Drilling in Production Section <Activity like " % PROD % ">
            //ELSE status = "Planned"

            var hashset = new HashSet<string>(new string[] { name });

            var entity = await (from j in _icebergContext.JobAsyncs
                                join jp in _icebergContext.JobProductiveAsyncs on j.Id equals jp.JobId
                                //  join r in _icebergContext.WellRotaryAsyncs on j.WellBoreId equals r.WellBoreId
                                where hashset.Contains(j.WellName)
                                select new JobProductiveAsync()
                                {
                                    Id = j.Id,
                                    WellName = j.WellName,
                                    Type = j.Type,
                                    StartDate = j.StartDate,
                                    EndDate = jp.EndDate,

                                    TargetDepthTVDCalculate = j.TargetDepthTVDCalculate.GetValueOrDefault(),
                                    AFTAmountCalculate = j.AFTAmountCalculate.GetValueOrDefault(),
                                    DurationMLTotalCalculate = j.DurationMLTotalCalculate.GetValueOrDefault(),

                                    JobReportId = jp.Id,
                                    JobReportStartDate = jp.StartDate,
                                    JobReportEndDate = jp.EndDate,

                                    TargetDepth = j.TargetDepth.GetValueOrDefault(),
                                    TotalDepthCalculate = j.TotalDepthCalculate.GetValueOrDefault(),
                                    TotalDepthTVDCalculate = j.TotalDepthTVDCalculate.GetValueOrDefault(),

                                    CostToDateCalculate = jp.CostToDateCalculate.GetValueOrDefault(),
                                    DurationTimeLogToCumulative = jp.DurationTimeLogToCumulative.GetValueOrDefault(),
                                    Status = jp.Status,

                                    //WellUwi = r.Uwi,
                                    // WellBoreId = r.WellBoreId,
                                    //Rkb = r.Rkb.GetValueOrDefault(),
                                    //CurrentRkb = r.CurrentRkb.GetValueOrDefault(),

                                }).OrderByDescending(c => c.EndDate).FirstOrDefaultAsync();


            // sw.Stop();
            // Log.Information("{1} GetProductiveAsync Elapsed={0}", sw.Elapsed, name);


            return entity;

        }

        public async Task<IEnumerable<JobProductiveAsync>> ListProductiveAsync(string[] names)
        {
            //"Completed" is the well in the project that drilling activities have ended < Drilling Job End date is not null >
            //"Drilling  with < Activity > " is the well in the project that currently has drilling activities <Drilling Job End date is null> and Drilling in Production Section <Activity like " % PROD % ">
            //ELSE status = "Planned"
            // var sw = new Stopwatch();
            // sw.Start();


            var hashset = new HashSet<string>(names);

            var entities = await (from j in _icebergContext.JobAsyncs
                                  join jp in _icebergContext.JobProductiveAsyncs on j.Id equals jp.JobId
                                  //  join r in _icebergContext.WellRotaryAsyncs on j.WellBoreId equals r.WellBoreId
                                  where hashset.Contains(j.WellName)
                                  select new JobProductiveAsync()
                                  {
                                      Id = j.Id,
                                      WellName = j.WellName,
                                      Type = j.Type,
                                      StartDate = j.StartDate,
                                      EndDate = j.EndDate,

                                      TargetDepthTVDCalculate = j.TargetDepthTVDCalculate.GetValueOrDefault(),
                                      AFTAmountCalculate = j.AFTAmountCalculate.GetValueOrDefault(),
                                      DurationMLTotalCalculate = j.DurationMLTotalCalculate.GetValueOrDefault(),

                                      JobReportId = jp.Id,
                                      JobReportStartDate = jp.StartDate,
                                      JobReportEndDate = jp.EndDate,

                                      TargetDepth = j.TargetDepth.GetValueOrDefault(),
                                      TotalDepthCalculate = j.TotalDepthCalculate.GetValueOrDefault(),
                                      TotalDepthTVDCalculate = j.TotalDepthTVDCalculate.GetValueOrDefault(),

                                      CostToDateCalculate = jp.CostToDateCalculate.GetValueOrDefault(),
                                      DurationTimeLogToCumulative = jp.DurationTimeLogToCumulative.GetValueOrDefault(),
                                      Status = jp.Status,

                                      // WellUwi = r.Uwi,
                                      // WellBoreId = r.WellBoreId,
                                      // Rkb = r.Rkb.GetValueOrDefault(),
                                      //CurrentRkb = r.CurrentRkb.GetValueOrDefault(),

                                  }).ToListAsync();

            return entities;

        }


    }

}