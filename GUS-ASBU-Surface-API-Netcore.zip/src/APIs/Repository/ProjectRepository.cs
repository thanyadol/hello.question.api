using System; 

using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

//log
using Serilog;
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;
using surflex.netcore22.Extensions;

//model
//using surflex.netcore22.Models;

namespace surflex.netcore22.APIs.Repository
{
    public interface IProjectRepository
    {
        Task<IEnumerable<ProjectAsync>> ListAsync();
        Task<IEnumerable<ProjectAsync>> ListProductiveAsync(string[] wells);//(IEnumerable<WellProductiveAsync> wells);
    }


    public class ProjectRepository : IProjectRepository
    {
        private const string COMPLETED = "Completed";
        private const string FULLY_APPROVED = "Fully Approved";
        private readonly IceteaContext _iceteaContext;
        private readonly IWellRepository _wellRepository;

        public ProjectRepository(IceteaContext iceteaContext, IWellRepository wellRepository)
        {
            // _iceteaContext = wwcontext ?? throw new ArgumentNullException(nameof(wwcontext));
            _iceteaContext = iceteaContext ?? throw new ArgumentNullException(nameof(iceteaContext));
            _wellRepository = wellRepository ?? throw new ArgumentNullException(nameof(wellRepository));
        }


        public async Task<IEnumerable<ProjectAsync>> ListAsync()
        {
            //Project_Status = 'Completed' or 'Fully Approved'
            var entities = await _iceteaContext.ProjectAsyncs
                            .Where(c => c.Status == COMPLETED || c.Status == FULLY_APPROVED).ToListAsync();

            return entities;
        }


        public async Task<IEnumerable<ProjectAsync>> ListProductiveAsync(string[] wells)//IEnumerable<WellProductiveAsync> wells)
        {

            var temp = new HashSet<string>(wells);


            //max date record is yesterday
            var entities = await (from p in _iceteaContext.ProjectAsyncs
                                  join wp in _iceteaContext.ProjectWellAsyncs on p.Id equals wp.ProjectId
                                  join w in _iceteaContext.WellAsyncs on wp.WellId equals w.Id
                                  where temp.Contains(w.Name)

                                  && (p.Status == COMPLETED || p.Status == FULLY_APPROVED)
                                  //&& (w.Status == COMPLETED || w.Status == FULLY_APPROVED)
                                  //&& (w.Status == "Completed" || w.Status == "Fully Approved")
                                  //add well condition status

                                  //   group p by new { /* *p.Id,*  p.Name /* , p.Status, p.CreatedDate* } into g
                                  select new ProjectAsync
                                  {
                                      Id = p.Id,
                                      Name = p.Name,
                                      Platform = p.Platform,
                                      //CreatedDate = g.Key.CreatedDate,
                                      // Status = g.Key.Status

                                  }).Distinct().ToListAsync();


            return entities;


            /* *var chunk_wells = wells.ToList().Chunk(wells.Count() / 10);

            var multipleTasks = new[]
            {
                Task.Run(() => DoComplexCalculation(chunk_wells[0])),
                Task.Run(() => DoComplexCalculation(chunk_wells[1])),
                Task.Run(() => DoComplexCalculation(chunk_wells[2])),
                Task.Run(() => DoComplexCalculation(chunk_wells[3])),

                Task.Run(() => DoComplexCalculation(chunk_wells[4])),
                Task.Run(() => DoComplexCalculation(chunk_wells[5])),
                Task.Run(() => DoComplexCalculation(chunk_wells[6])),
                Task.Run(() => DoComplexCalculation(chunk_wells[7])),

                Task.Run(() => DoComplexCalculation(chunk_wells[8])),
                Task.Run(() => DoComplexCalculation(chunk_wells[9])),
            };

            // var combinedTask = Task.WhenAll(multipleTasks);

            var completedTask = await Task.WhenAll(multipleTasks);
            try
            {
                var result = completedTask;

                return result.LastOrDefault();
            }
            catch (Exception ex)
            {
                // handle exception
                throw new Exception(ex.Message);

            }*/

            /* var parallel = Enumerable.Range(0, 4)
            .AsParallel()
            .AsOrdered()
            .Select(n => DoComplexCalculation(wells))
            .ToArray();

            // await Task.WhenAny(parallel);
            // await Task.WhenAll(parallel);

            var completedTask = await Task.WhenAny(parallel);
            try
            {
                var result = await completedTask;

                return result;
            }
            catch (Exception ex)
            {
                // handle exception
                throw new Exception(ex.Message);

            }*/
        }


    }

}