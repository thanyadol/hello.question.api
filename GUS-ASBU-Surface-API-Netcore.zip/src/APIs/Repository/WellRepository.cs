using System;

using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

using surflex.netcore22.Helpers;

//log
using Serilog;
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;

//model
//using surflex.netcore22.Models;

namespace surflex.netcore22.APIs.Repository
{

    public interface IWellRepository
    {
        // Task<IEnumerable<WellProductiveAsync>> ListProductiveAsync();
        Task<WellReserveAsync> GetPlannedReserveAsync(string name);

        Task<WellJobProductiveAsync> GetActualProductiveAsync(string name);

        Task<WellProductiveAsync> GetProductiveAsync(string name);
        Task<WellAsync> GetAsync(string name);
        Task<IEnumerable<WellPlannedAsync>> ListAsync(int id);
        Task<IEnumerable<WellProductiveAsync>> ListProductiveAsync();
        //bool IsNameContained(IEnumerable<WellProductiveAsync> wells, string name);
        //  bool IsNameContain(string n1, string n2);

        Task<IEnumerable<WellPlannedAsync>> ListPlannedProductiveAsync(string[] wells);
        Task<WellJobProductiveAsync> GetPlannedProductiveCostAsync(string name, string section);


        Task<WellPressureAsync> GetFreePressureAsync(string name);
        Task<IEnumerable<WellPressureAsync>> ListFreePressureAsync(string[] name);

        Task<WellJobProductiveAsync> GetLatestWellPhaseAsync(string wellName);
    }

    public class WellRepository : IWellRepository
    {

        //  private const int MAX_ARCHIVE = 10000;
        //  private const int ADD_DAY = -365;
        private const string COMPLETED = "Completed";

        private const string PRODUCTION = "PRODOH";
        private const string DRILL = "DRILL";

        private const string FULLY_APPROVED = "Fully Approved";
        private readonly IceteaContext _iceteaContext;
        private readonly IcebergContext _icebergContext;

        private readonly IConfiguration _configuration;

        private readonly DateTime date;

        public WellRepository(IceteaContext wwcontext, IcebergContext icecontext, IConfiguration configuration)
        {
            _iceteaContext = wwcontext ?? throw new ArgumentNullException(nameof(wwcontext));
            _icebergContext = icecontext ?? throw new ArgumentNullException(nameof(icecontext));

            _configuration = configuration;

            var ADD_DAY = Convert.ToInt16(_configuration["ApiSettings:LiveProductiveInDays"]);
            date = Utility.CurrentSEAsiaStandardTime().AddDays(ADD_DAY);
        }

        /* * public async Task<bool> ListProductiveAsync(IEnumerable<WellPlannedAsync> wells)
         {
             //DateTime enddate = Utility.CurrentSEAsiaStandardTime().AddDays(ADD_DAY);
             //max date record is yesterday
             var entities = await _icebergContext.WellProductiveAsyncs
                                 .Where(x => wells.Any(c => IsNameContain(x.Code, c.Name)) && x.EndDate >= date).CountAsync();
             //.OrderByDescending(c => c.EndDate)

             //.FirstOrDefaultAsync();
             if (entities > 0)
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         /* *public async Task<IEnumerable<WellProductiveAsync>> ListProductiveAsync(IEnumerable<WellPlannedAsync> wells)
         {
             //DateTime enddate = Utility.CurrentSEAsiaStandardTime().AddDays(ADD_DAY);
             //max date record is yesterday
             var entities = await _icebergContext.WellProductiveAsyncs
                                 .Where(x => wells.Any(c => IsNameContain(x.Code, c.Name))).GroupBy(e => new
                                 {
                                     e.Name,
                                     e.Code,
                                     // e.StartDate,
                                     // e.EndDate
                                 })
                                  .Select(g => new WellProductiveAsync()
                                  {
                                      Name = g.Key.Name,
                                      Code = g.Key.Code,

                                  }).ToListAsync();

             /* var results = new List<WellProductiveAsync>();

             foreach (var w in wells)
             {
                 var query = await _icebergContext.WellProductiveAsyncs
                         .Where(x => IsNameContain(x.Code, w.Name)).FirstOrDefaultAsync();

                 if (query != null)
                 {
                     results.Add(query);
                     continue;
                 }
             }*


             return entities;
         }*/


        public async Task<IEnumerable<WellPlannedAsync>> ListPlannedProductiveAsync(string[] wells)
        {
            var temp = new List<WellPlannedAsync>();

            foreach (var s in wells)
            {
                //string[] words = s.Split("-");

                //var hashset = new HashSet<string>(new string[] { s });

                var ee = await (from programPhase in _icebergContext.WellJobProductiveAsyncs
                                where programPhase.Code.StartsWith(s) && programPhase.PhaseStartDate != null
                                orderby programPhase.Code ascending, programPhase.StartDate descending, programPhase.Sequence descending
                                select programPhase
                                  ).FirstOrDefaultAsync();

                if (ee != null)
                {
                    var w = new WellPlannedAsync();

                    w.Name = ee.Code;
                    w.Code = ee.Code;

                    w.Phase = ee.PhaseFirst;
                    w.WellPhase = ee.WellPhase;

                    w.StartDate = ee.StartDate.GetValueOrDefault();
                    w.EndDate = ee.EndDate.GetValueOrDefault();

                    //  w.Platform = words[0];

                    temp.Add(w);

                    continue;
                }
                else
                {
                    var w = new WellPlannedAsync();
                    w.Name = s;
                    w.Code = s;

                    temp.Add(w);
                }

            }

            return temp;
        }

        public async Task<IEnumerable<WellProductiveAsync>> ListProductiveAsync()
        {
            //DateTime enddate = Utility.CurrentSEAsiaStandardTime().AddDays(ADD_DAY);
            // Stopwatch sw = new Stopwatch();
            // sw.Start();
            const string ABAN = "ABAN";

            var entities = await _icebergContext
                                .WellProductiveAsyncs
                                .Where(c => c.EndDate >= date && c.WellPhase.ToUpper() != ABAN)
                                .GroupBy(e => new
                                {
                                    e.Name,
                                    e.Code
                                })
                                .Select(g => new WellProductiveAsync()
                                {
                                    Name = g.Key.Code,
                                    Code = g.Key.Code,

                                }).ToListAsync();

            // sw.Stop();
            // Console.WriteLine("---------------------------Elapsed={0}-------------------------- - ", sw.Elapsed);
            return entities;
        }

        public async Task<WellReserveAsync> GetPlannedReserveAsync(string name)
        {


            var entities = await (from w in _iceteaContext.WellAsyncs
                                  join wp in _iceteaContext.WellReserveAsyncs on w.Id equals wp.WellId
                                  where name.Contains(w.Name) && (w.Status == COMPLETED || w.Status == FULLY_APPROVED)

                                  select wp).FirstOrDefaultAsync();

            return entities;

        }



        public async Task<WellJobProductiveAsync> GetActualProductiveAsync(string name)
        {

            var entities = await (from w in _icebergContext.WellJobProductiveAsyncs
                                  where w.Code == name && w.PhaseFirst == PRODUCTION && w.PhaseSecond == DRILL
                                  select w
                                  ).FirstOrDefaultAsync();

            return entities;

        }


        public async Task<WellJobProductiveAsync> GetPlannedProductiveCostAsync(string name, string section)
        {
            const string PROD = "PROD";
            const string INT = "INTPROD";
            const string HOLD = "3HOLD";

            Dictionary<string, string[]> WELL_PRODUCTION_SECTION = new Dictionary<string, string[]>()
            {
                { PROD, new string[] { "DRLG-PRODOH-DRILL", "GEOLEVAL-PRODOH-EVAL", "COMP-PRODTBG-TBG"} },
                { INT, new string[]  { "DRLG-INTCSG1-DRILL", "DRLG-INTCSG1-CSGCMT", "DRLG-PRODOH-DRILL", "GEOLEVAL-PRODOH-EVAL", "COMP-PRODTBG-TBG" } },
                { HOLD, new string[]  { "DRLG-SURF-DRILL", "DRLG-SURF-CSGCMT", "DRLG-INTCSG1-DRILL", "DRLG-INTCSG1-CSGCMT", "DRLG-PRODOH-DRILL", "GEOLEVAL-PRODOH-EVAL", "COMP-PRODTBG-TBG" } },
            };

            var hashset = new HashSet<string>(WELL_PRODUCTION_SECTION[section]);

            var entities = await (from w in _icebergContext.WellJobProductiveAsyncs
                                  where w.Code == name && hashset.Contains(w.WellPhase + "-" + w.PhaseFirst + "-" + w.PhaseSecond)
                                  select w
                                  ).ToListAsync();

            var temp = entities.Sum(c => c.PlannedAFECost);
            var entity = new WellJobProductiveAsync() { PlannedAFECost = temp, Name = name, WellPhase = section };

            return entity;
        }

        public async Task<WellProductiveAsync> GetProductiveAsync(string name)
        {
            //DateTime edndate = Utility.CurrentSEAsiaStandardTime().AddDays(ADD_DAY);
            string[] words = name.Split("-");

            //max date record is yesterday
            var entity = await _icebergContext.WellProductiveAsyncs
                            .Where(x => x.Code.Contains(words[0]) && x.Code.Contains(words[1]))
                              .OrderBy(c => c.Code)
                                    .OrderByDescending(c => c.EndDate)
                                    //  .Select(c => c.Code)
                                    .FirstOrDefaultAsync();

            if (entity == null)
            {
                return null;
            }

            // if (entity.EndDate < date)
            // {
            //     return null;
            // }

            //swap name
            entity.Name = entity.Code;
            return entity;
        }

        /* public async Task<int> GetRLLCPId(string name)
        {
            //DateTime edndate = Utility.CurrentSEAsiaStandardTime().AddDays(ADD_DAY);

            //max date record is yesterday
            var id = await _iceteaContext.WellAsyncs.Where(c => c.Name == name).Select(c => c.Id).FirstOrDefaultAsync();
            return id;
        }*/

        public async Task<IEnumerable<WellPlannedAsync>> ListAsync(int id)
        {
            //Well_Status = 'Completed' or 'Fully Approved'
            var entities = await (from p in _iceteaContext.ProjectAsyncs
                                  join wp in _iceteaContext.ProjectWellAsyncs on p.Id equals wp.ProjectId
                                  join w in _iceteaContext.WellAsyncs on wp.WellId equals w.Id
                                  where p.Id == id
                                  && (p.Status == COMPLETED || p.Status == FULLY_APPROVED)
                                  && (w.Status == COMPLETED || w.Status == FULLY_APPROVED)

                                  select new WellPlannedAsync
                                  {
                                      Id = w.Id,
                                      Name = w.Name,

                                      ProjectId = p.Id,
                                      ProjectStatus = p.Status,

                                      Asset = p.Asset,
                                      OperationArea = p.Area,

                                      //Phase = w.phase,

                                      Platform = p.Platform,

                                      Project = p.Name

                                  }).ToListAsync();

            return entities;
        }

        /* public async Task<IEnumerable<WellPlannedAsync>> ListNameProductiveAsync(IEnumerable<WellPlannedAsync> wells)
        {
            var entity = new List<WellPlannedAsync>();

            foreach(var w in wells)
            {
                var entity = this.GetProductiveAsync(w.Name);
            }


            return entities;
        }*/

        public async Task<WellAsync> GetAsync(string name)
        {
            var entities = await _iceteaContext.WellAsyncs
                                .Where(w => w.Name == name && (w.Status == COMPLETED || w.Status == FULLY_APPROVED))
                                .FirstOrDefaultAsync();

            return entities;
        }


        /* private bool IsNameContained(string source, string destination)
        {
            //await _iceteaContext.WellAsyncs.Where(c => c.Name == name).Select(c => c.Id).FirstOrDefaultAsync();
            if (string.IsNullOrEmpty(destination))
            {
                return false;
            }

            //await _iceteaContext.WellAsyncs.Where(c => c.Name == name).Select(c => c.Id).FirstOrDefaultAsync();

            string[] words = destination.Split("-");
            string pattern = words[0] + @"[-_\s]" + words[1] + @"($|[^0-9]+)";
            Regex reg = new Regex(pattern);

            bool b = reg.Match(source).Success;
            return b;
        }*/


        public async Task<WellPressureAsync> GetFreePressureAsync(string name)
        {
            string[] words = name.Split("-");

            //max date record is yesterday
            var entity = await _icebergContext.WellPressureAsyncs
                            .Where(x => x.WellName.Contains(words[0]) && x.WellName.Contains(words[1])).FirstOrDefaultAsync();

            return entity;
        }

        public async Task<IEnumerable<WellPressureAsync>> ListFreePressureAsync(string[] name)
        {
            var hashset = new HashSet<string>(name);

            //max date record is yesterday
            var entities = await _icebergContext.WellPressureAsyncs
                            .Where(x => hashset.Contains(x.WellName)).ToListAsync();

            return entities;
        }


        public async Task<WellJobProductiveAsync> GetLatestWellPhaseAsync(string wellName)
        {

            var matched = await (from programPhase in _icebergContext.WellJobProductiveAsyncs
                                  where programPhase.Code == wellName && programPhase.PhaseStartDate != null
                                 orderby programPhase.Code ascending, programPhase.StartDate descending, programPhase.Sequence descending
                                 select programPhase
                                  ).FirstOrDefaultAsync();

            return matched;

        }

    }

}