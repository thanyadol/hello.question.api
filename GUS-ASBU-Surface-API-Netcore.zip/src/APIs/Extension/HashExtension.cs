using System.Collections.Generic;
using System; 


namespace surflex.netcore22.APIs.Extensions
{
    public static class HashExtension
    {
        public static bool ContainSidetrack(this IEnumerable<string> self, string value)
        {
            foreach (var item in self)
            {
                var words = item.Split("-");
                if (value.Contains(words[0]) && value.Contains(words[1]))
                {
                    return true;
                }
            }

            return false;
        }
    }
}