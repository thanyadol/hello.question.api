using System.Collections.Generic;
using System;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;

namespace surflex.netcore22.APIs.Extensions
{
    public static class EntityExtension
    {
        [DbFunction("CodeFirstDatabaseSchema", "Like")]
        public static bool Like(this string target, string pattern)
        {
            // Escape all the special regex characters by default
            pattern = Regex.Escape(pattern);

            // Add regex equivalents for the various SQL LIKE characters
            pattern = pattern.Replace("%", ".+");
            pattern = pattern.Replace("_", ".");
            pattern = pattern.Replace(@"\[", "[");
            pattern = pattern.Replace(@"\]", "]");
            pattern = pattern.Replace(@"[\^", "[^");

            // Match against the entire string
            pattern = "^" + pattern + "$";

            return Regex.IsMatch(target, pattern, RegexOptions.IgnoreCase);
        }
    }
}