    
$snapshotname = 'spin13th_2nd_uat_23@spin12'
dotnet ef migrations add $snapshotname  --project 	surflex.netcore22.csproj --context NorthwindContext