info: Microsoft.EntityFrameworkCore.Infrastructure[10403]
      Entity Framework Core 2.2.4-servicing-10062 initialized 'NorthwindContext' using provider 'Microsoft.EntityFrameworkCore.SqlServer' with options: MigrationsHistoryTable=dbo.__EFMigrationsHistory 
IF OBJECT_ID(N'[dbo].[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [dbo].[__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;

GO

CREATE TABLE [dbo].[__EFLoggingEvent] (
    [Id] uniqueidentifier NOT NULL,
    [Level] nvarchar(128) NULL,
    [TimeStamp] datetimeoffset NOT NULL,
    [CAI] nvarchar(max) NULL,
    [Message] nvarchar(max) NULL,
    [MessageTemplate] nvarchar(max) NULL,
    [Exception] nvarchar(max) NULL,
    [Type] nvarchar(20) NULL,
    [ErrorCode] nvarchar(max) NULL,
    [RequestId] uniqueidentifier NOT NULL,
    [RequestPath] nvarchar(500) NULL,
    [RequestScheme] nvarchar(500) NULL,
    [By] nvarchar(50) NULL,
    [Date] datetime2 NOT NULL,
    CONSTRAINT [PK___EFLoggingEvent] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[Api] (
    [Id] uniqueidentifier NOT NULL,
    [Url] nvarchar(500) NULL,
    [Endpoint] nvarchar(500) NULL,
    [Params] nvarchar(500) NULL,
    [Type] nvarchar(10) NULL,
    [IsRequireAuthentication] bit NOT NULL,
    [Description] nvarchar(500) NULL,
    [Created] datetime NULL,
    CONSTRAINT [PK_Api] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[Area] (
    [Id] nvarchar(50) NOT NULL,
    [Name] nvarchar(100) NULL,
    [HcType] nvarchar(10) NULL,
    [Type] nvarchar(10) NULL,
    [By] nvarchar(50) NULL,
    [Description] nvarchar(50) NULL,
    [Status] nvarchar(10) NULL,
    [Created] datetime NULL,
    CONSTRAINT [PK_Area] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[Attachment] (
    [Id] nvarchar(50) NOT NULL,
    [Value] nvarchar(max) NULL,
    [Name] nvarchar(500) NULL,
    [Path] nvarchar(500) NULL,
    [Title] nvarchar(500) NULL,
    [Size] decimal(18,2) NOT NULL,
    [Extension] nvarchar(10) NULL,
    [Status] nvarchar(10) NULL,
    [Description] nvarchar(1000) NULL,
    [By] nvarchar(50) NULL,
    [Checksum] nvarchar(500) NULL,
    [Storage] nvarchar(50) NULL,
    [Date] datetime NULL,
    CONSTRAINT [PK_Attachment] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[Job] (
    [Id] nvarchar(50) NOT NULL,
    [WellId] nvarchar(50) NULL,
    [Status] nvarchar(10) NULL,
    [Type] nvarchar(10) NULL,
    [Activity] nvarchar(10) NULL,
    [Created] datetime NULL,
    CONSTRAINT [PK_Job] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[Module] (
    [Id] uniqueidentifier NOT NULL,
    [Name] nvarchar(100) NULL,
    [Type] nvarchar(10) NULL,
    [Description] nvarchar(500) NULL,
    [Created] datetime NULL,
    CONSTRAINT [PK_Module] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[Page] (
    [Id] uniqueidentifier NOT NULL,
    [Parent] uniqueidentifier NULL,
    [Title] nvarchar(100) NULL,
    [Sub] nvarchar(20) NULL,
    [Url] nvarchar(100) NULL,
    [Params] nvarchar(100) NULL,
    [Order] int NOT NULL,
    [Type] nvarchar(10) NULL,
    [Description] nvarchar(500) NULL,
    [IsRequireAuthentication] bit NOT NULL,
    [Created] datetime NULL,
    CONSTRAINT [PK_Page] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[PeriodPrice] (
    [Id] uniqueidentifier NOT NULL,
    [PriceId] uniqueidentifier NOT NULL,
    [Value] decimal(18,2) NOT NULL,
    [Year] int NOT NULL,
    [Month] int NULL,
    [Created] datetime NULL,
    [By] nvarchar(50) NULL,
    CONSTRAINT [PK_PeriodPrice] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[Platform] (
    [Id] nvarchar(50) NOT NULL,
    [Name] nvarchar(100) NULL,
    [Country] nvarchar(20) NULL,
    [Description] nvarchar(100) NULL,
    [Status] nvarchar(10) NULL,
    [Created] datetime NULL,
    CONSTRAINT [PK_Platform] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[PresetWellScenario] (
    [Id] uniqueidentifier NOT NULL,
    [Name] nvarchar(50) NULL,
    [Description] nvarchar(255) NULL,
    [Status] nvarchar(50) NULL,
    [By] nvarchar(255) NULL,
    [Created] datetime NULL,
    [Updated] datetime NULL,
    CONSTRAINT [PK_PresetWellScenario] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[Price] (
    [Id] uniqueidentifier NOT NULL,
    [Name] nvarchar(100) NULL,
    [HcType] nvarchar(10) NULL,
    [AreaId] nvarchar(50) NULL,
    [Unit] nvarchar(max) NULL,
    [Type] nvarchar(max) NULL,
    [Description] nvarchar(1000) NULL,
    [Created] datetime NULL,
    [By] nvarchar(50) NULL,
    [Structure] nvarchar(100) NULL,
    [Status] nvarchar(10) NULL,
    [TemplateId] nvarchar(50) NULL,
    CONSTRAINT [PK_Price] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[Production] (
    [Id] nvarchar(50) NOT NULL,
    [Name] nvarchar(100) NULL,
    [Asset] nvarchar(100) NULL,
    [Condition] nvarchar(50) NULL,
    [Created] datetime NULL,
    [By] nvarchar(50) NULL,
    [Key] nvarchar(50) NULL,
    [Rev] nvarchar(50) NULL,
    [Status] nvarchar(10) NULL,
    [StartDate] datetime NULL,
    [FinishDate] datetime NULL,
    [IsGasModelApplicable] bit NOT NULL,
    [IsOilModelApplicable] bit NOT NULL,
    [IsSeparateModelApplicable] bit NOT NULL,
    CONSTRAINT [PK_Production] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[ProductionParam] (
    [Id] nvarchar(50) NOT NULL,
    [ProductionProfileId] nvarchar(50) NULL,
    [Value] decimal(18,2) NULL,
    [Name] nvarchar(10) NULL,
    CONSTRAINT [PK_ProductionParam] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[ProductionProfile] (
    [Id] nvarchar(50) NOT NULL,
    [ProductionId] nvarchar(50) NULL,
    [EVFormulaForIPCDRATE] nvarchar(50) NULL,
    [Value] decimal(18,1) NULL,
    [AbandonmentRate] decimal(18,2) NULL,
    [HoldupPercentage] decimal(18,2) NULL,
    [ValueType] nvarchar(10) NULL,
    [ApplicableModel] nvarchar(10) NULL,
    [Created] datetime NULL,
    [By] nvarchar(50) NULL,
    CONSTRAINT [PK_ProductionProfile] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[Project] (
    [Id] nvarchar(50) NOT NULL,
    [Name] nvarchar(20) NULL,
    [RLLCPReferenceId] int NULL,
    [Status] nvarchar(max) NULL,
    [Created] datetime NULL,
    [Description] nvarchar(max) NULL,
    CONSTRAINT [PK_Project] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[ProjectActivity] (
    [Id] nvarchar(50) NOT NULL,
    [ProjectSpaceId] nvarchar(50) NULL,
    [Discriminator] nvarchar(50) NULL,
    [Action] nvarchar(50) NULL,
    [By] nvarchar(50) NULL,
    [Date] datetime NULL,
    CONSTRAINT [PK_ProjectActivity] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[ProjectAttribute] (
    [Id] nvarchar(50) NOT NULL,
    [ProjectId] nvarchar(50) NULL,
    [BgProfileId] int NULL,
    [BoProfileId] int NULL,
    [TotalPlannedWell] int NULL,
    [ProductionProfileId] nvarchar(50) NULL,
    [ApplicableModelId] nvarchar(50) NULL,
    [OilProjectStartDate] datetime NULL,
    [GasProjectStartDate] datetime NULL,
    [ProjectCutOffDate] datetime NULL,
    [RampUpDay] int NULL,
    [ShiftStartDay] int NULL,
    [Description] nvarchar(1000) NULL,
    [Status] nvarchar(10) NULL,
    [Created] datetime NULL,
    [By] nvarchar(50) NULL,
    [StartDate] datetime NULL,
    [FinishDate] datetime NULL,
    CONSTRAINT [PK_ProjectAttribute] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[ProjectDrilled] (
    [Id] uniqueidentifier NOT NULL,
    [AttachmentId] nvarchar(50) NULL,
    [TemplateTypeId] nvarchar(50) NULL,
    [ProjectSpaceId] nvarchar(50) NULL,
    [ActualDPI] decimal(28,10) NULL,
    [PlannedDPI] decimal(28,10) NULL,
    [Type] nvarchar(10) NULL,
    [Key] nvarchar(50) NULL,
    [Rev] nvarchar(50) NULL,
    [Status] nvarchar(10) NULL,
    [StartDate] datetime NULL,
    [FinishDate] datetime NULL,
    CONSTRAINT [PK_ProjectDrilled] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[ProjectLocation] (
    [Id] uniqueidentifier NOT NULL,
    [ProjectId] nvarchar(50) NULL,
    [LocationId] nvarchar(50) NULL,
    [By] nvarchar(50) NULL,
    [Status] nvarchar(10) NULL,
    [Date] datetime NULL,
    CONSTRAINT [PK_ProjectLocation] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[ProjectSpace] (
    [Id] nvarchar(50) NOT NULL,
    [ProjectId] nvarchar(50) NULL,
    [By] nvarchar(50) NULL,
    [Description] nvarchar(1000) NULL,
    [Created] datetime NULL,
    CONSTRAINT [PK_ProjectSpace] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[ProjectWell] (
    [Id] nvarchar(50) NOT NULL,
    [Key] nvarchar(50) NULL,
    [Rev] nvarchar(50) NULL,
    [ProjectSpaceId] nvarchar(50) NULL,
    [StartDate] datetime NULL,
    [FinishDate] datetime NULL,
    CONSTRAINT [PK_ProjectWell] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[Resource] (
    [Id] nvarchar(50) NOT NULL,
    [Name] nvarchar(500) NULL,
    [Type] nvarchar(10) NULL,
    [Description] nvarchar(1000) NULL,
    [Key] nvarchar(50) NULL,
    [Rev] nvarchar(50) NULL,
    [By] nvarchar(50) NULL,
    [Status] nvarchar(10) NULL,
    [Created] datetime NULL,
    CONSTRAINT [PK_Resource] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[ResourceLibrary] (
    [Id] nvarchar(50) NOT NULL,
    [Formular] nvarchar(550) NULL,
    [ResourceType] nvarchar(50) NULL,
    [QueryParam] nvarchar(500) NULL,
    [Key] nvarchar(50) NULL,
    [Rev] nvarchar(50) NULL,
    [Name] nvarchar(100) NULL,
    [ValueType] nvarchar(20) NULL,
    [Value] decimal(28,10) NULL,
    [PlannerType] nvarchar(20) NULL,
    [Section] nvarchar(20) NULL,
    [Type] nvarchar(20) NULL,
    [IsReadonly] bit NOT NULL,
    [Description] nvarchar(500) NULL,
    [By] nvarchar(50) NULL,
    [Status] nvarchar(10) NULL,
    [Created] datetime NULL,
    [StartDate] datetime NULL,
    [FinishDate] datetime NULL,
    CONSTRAINT [PK_ResourceLibrary] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[ResourceTask] (
    [Id] nvarchar(50) NOT NULL,
    [ResourceId] nvarchar(50) NULL,
    [LibraryId] nvarchar(50) NULL,
    [Created] datetime NULL,
    CONSTRAINT [PK_ResourceTask] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[Rigg] (
    [Id] nvarchar(50) NOT NULL,
    [Name] nvarchar(100) NULL,
    [Type] nvarchar(10) NULL,
    [By] nvarchar(50) NULL,
    [Description] nvarchar(1000) NULL,
    [Status] nvarchar(10) NULL,
    [Created] datetime NULL,
    CONSTRAINT [PK_Rigg] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[RiggRate] (
    [Id] nvarchar(50) NOT NULL,
    [RiggId] nvarchar(50) NULL,
    [TemplateId] nvarchar(50) NULL,
    [TIH] decimal(18,2) NOT NULL,
    [TOH] decimal(18,2) NOT NULL,
    [Type] nvarchar(10) NULL,
    [By] nvarchar(50) NULL,
    [Activity] nvarchar(100) NULL,
    [Created] datetime NULL,
    CONSTRAINT [PK_RiggRate] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[Role] (
    [Id] uniqueidentifier NOT NULL,
    [Name] nvarchar(100) NULL,
    [LocationId] nvarchar(50) NULL,
    [By] nvarchar(50) NULL,
    [Type] nvarchar(10) NULL,
    [Description] nvarchar(500) NULL,
    [Created] datetime NULL,
    CONSTRAINT [PK_Role] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[Sand] (
    [Id] uniqueidentifier NOT NULL,
    [WellDrilledId] uniqueidentifier NOT NULL,
    [TopMD] decimal(36, 18) NULL,
    [BaseMD] decimal(36, 18) NULL,
    [Pos] decimal(18, 2) NULL,
    [Usi] nvarchar(50) NULL,
    [Iwd] nvarchar(20) NULL,
    [OpenWorksContactCategory] nvarchar(10) NULL,
    [Name] nvarchar(20) NULL,
    [SandReserveCategory] nvarchar(5) NULL,
    [Status] nvarchar(10) NULL,
    [OilP1DNWithoutBC] decimal(36, 18) NULL,
    [OilP1DNWithBC] decimal(36, 18) NULL,
    [CondensateP1DNWithBC] decimal(36, 18) NULL,
    [FreeGasP1DNWithoutBC] decimal(36, 18) NULL,
    [FreeGasP1DNWithBC] decimal(36, 18) NULL,
    [SolutionGasP1DNWithBC] decimal(36, 18) NULL,
    [HCLiquidWithBC] decimal(36, 18) NULL,
    [HCGasWithBC] decimal(36, 18) NULL,
    [PayClassification] nvarchar(20) NULL,
    [PressureRFTInPSI] decimal(36, 18) NULL,
    [PressureRFTInPPG] decimal(36, 18) NULL,
    [PressureEstimatedInitialInPSI] decimal(36, 18) NULL,
    [PressureEstimatedInitialInPPG] decimal(36, 18) NULL,
    [PressurePPi] decimal(36, 18) NULL,
    [FVFProfileBoProfile] nvarchar(max) NULL,
    [FVFProfileBgProfile] nvarchar(max) NULL,
    [FVFProfileBoProfileId] int NULL,
    [FVFProfileBgProfileId] int NULL,
    [FVFProfileBoValue] decimal(36, 18) NULL,
    [FVFProfileBgValue] decimal(36, 18) NULL,
    [AnalogyOilAreaScenarioId] int NULL,
    [AnalogyGasAreaScenarioId] int NULL,
    [AnalogyOilAreaSetId] int NULL,
    [AnalogyGasAreaSetId] int NULL,
    [AnalogyOilAreaName] nvarchar(500) NULL,
    [AnalogyOilAreaDiscountFactor] nvarchar(500) NULL,
    [AnalogyGasAreaName] nvarchar(500) NULL,
    [AnalogyGasAreaDiscountFactor] nvarchar(500) NULL,
    [AnalogyOilArea] decimal(36, 18) NULL,
    [AnalogyGasArea] decimal(36, 18) NULL,
    [DiscountFactorOilDepletion] decimal(36, 18) NULL,
    [DiscountFactorGasDepletion] decimal(36, 18) NULL,
    [DiscountFactorMechanical] decimal(36, 18) NULL,
    [DiscountFactorCementQuality] decimal(36, 18) NULL,
    [DiscountFactorCO2] decimal(36, 18) NULL,
    [DiscountFactorBC] decimal(36, 18) NULL,
    [InPlaceByVolumetricOOIP] decimal(36, 18) NULL,
    [InPlaceByVolumetricOGIP] decimal(36, 18) NULL,
    [RecoveryEfficiencyOil] decimal(36, 18) NULL,
    [RecoveryEfficiencyGas] decimal(36, 18) NULL,
    [GrossIntervalFrom] decimal(36, 18) NULL,
    [GrossIntervalTo] decimal(36, 18) NULL,
    [TopTVDSS] decimal(36, 18) NULL,
    [BaseTVDSS] decimal(36, 18) NULL,
    [GocTVDSS] decimal(36, 18) NULL,
    [HwcTVDSS] decimal(36, 18) NULL,
    [GrossSandMT] decimal(36, 18) NULL,
    [GrossSandVT] decimal(36, 18) NULL,
    [NetGasVT] decimal(36, 18) NULL,
    [NetOilVT] decimal(36, 18) NULL,
    [MaximumResistivity] decimal(36, 18) NULL,
    [Vsh] decimal(36, 18) NULL,
    [AvgPor] decimal(36, 18) NULL,
    [AvgSw] decimal(36, 18) NULL,
    [TG] decimal(36, 18) NULL,
    [Fluid] nvarchar(10) NULL,
    [Remarks] nvarchar(1000) NULL,
    [AZI] nvarchar(10) NULL,
    [LookupRenderingOilRF] nvarchar(10) NULL,
    [LookupRenderingGasRF] nvarchar(10) NULL,
    [LookupRenderingOilBCIncremental] decimal(36, 18) NULL,
    [LookupRenderingGasBCIncremental] decimal(36, 18) NULL,
    [EstPhase] nvarchar(10) NULL,
    [IsValidate] bit NOT NULL,
    [ErrorMessage] nvarchar(1000) NULL,
    [DataSource] nvarchar(20) NULL,
    [CreatedDate] datetime NULL,
    [SORUpdatedDate] datetime NULL,
    CONSTRAINT [PK_Sand] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[SessionLogg] (
    [Id] uniqueidentifier NOT NULL,
    [Token] nvarchar(1000) NULL,
    [UserId] nvarchar(50) NULL,
    [CAI] nvarchar(10) NULL,
    [Date] datetime NULL,
    [TokenExpiredDate] datetime NULL,
    CONSTRAINT [PK_SessionLogg] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[Template] (
    [Id] nvarchar(50) NOT NULL,
    [AttachmentId] nvarchar(50) NULL,
    [Name] nvarchar(500) NULL,
    [Description] nvarchar(1000) NULL,
    [TemplateTypeId] nvarchar(50) NULL,
    [Status] nvarchar(10) NULL,
    [Created] datetime NULL,
    [Key] nvarchar(50) NULL,
    [Rev] nvarchar(50) NULL,
    [By] nvarchar(50) NULL,
    [StartDate] datetime NULL,
    [FinishDate] datetime NULL,
    CONSTRAINT [PK_Template] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[User] (
    [Id] nvarchar(50) NOT NULL,
    [ADId] uniqueidentifier NOT NULL,
    [By] nvarchar(50) NULL,
    [CAI] nvarchar(50) NULL,
    [DisplayName] nvarchar(100) NULL,
    [GivenName] nvarchar(100) NULL,
    [AccountName] nvarchar(100) NULL,
    [Name] nvarchar(200) NULL,
    [Unique] nvarchar(50) NULL,
    [Email] nvarchar(100) NULL,
    [EmployeeId] nvarchar(50) NULL,
    [IsADEnable] bit NOT NULL,
    [ADGroup] nvarchar(50) NULL,
    [Created] datetime NULL,
    CONSTRAINT [PK_User] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[UserActivity] (
    [Id] uniqueidentifier NOT NULL,
    [Discriminator] nvarchar(50) NULL,
    [Action] nvarchar(50) NULL,
    [By] nvarchar(50) NULL,
    [Date] datetime NULL,
    CONSTRAINT [PK_UserActivity] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[Well] (
    [Id] nvarchar(50) NOT NULL,
    [Name] nvarchar(100) NULL,
    [ProjectId] nvarchar(50) NULL,
    [Status] nvarchar(10) NULL,
    [By] nvarchar(50) NULL,
    [Created] datetime NULL,
    CONSTRAINT [PK_Well] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[WellActivity] (
    [Id] uniqueidentifier NOT NULL,
    [WellSpaceId] uniqueidentifier NOT NULL,
    [Discriminator] nvarchar(50) NULL,
    [Action] nvarchar(50) NULL,
    [By] nvarchar(50) NULL,
    [Date] datetime NULL,
    CONSTRAINT [PK_WellActivity] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[WellDrilled] (
    [Id] uniqueidentifier NOT NULL,
    [WellSpaceId] uniqueidentifier NOT NULL,
    [Key] nvarchar(50) NULL,
    [Rev] nvarchar(50) NULL,
    [CalculatedWellReserve] decimal(36, 18) NULL,
    [Datasource] nvarchar(max) NULL,
    [SORUpdatedDate] datetime NULL,
    [WellType] nvarchar(max) NULL,
    [Status] nvarchar(10) NULL,
    [TotalCalculateRecord] int NOT NULL,
    [CalculatedTimestamp] nvarchar(max) NULL,
    [CompleteCalculatedRecord] int NOT NULL,
    [Created] datetime NULL,
    [StartDate] datetime NULL,
    [FinishDate] datetime NULL,
    [GOR] decimal(36, 18) NULL,
    [CGR] decimal(36, 18) NULL,
    [PipelinePressure] decimal(36, 18) NULL,
    [BcPos] decimal(36, 18) NULL,
    [BcCompressionRatio] decimal(36, 18) NULL,
    [OilPipelinePressureCoeff] decimal(36, 18) NULL,
    [GasPipelinePressureCoeff] decimal(36, 18) NULL,
    CONSTRAINT [PK_WellDrilled] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[WellProperties] (
    [Id] nvarchar(50) NOT NULL,
    [WellId] nvarchar(50) NULL,
    [ProjectWellId] nvarchar(50) NULL,
    [FaultBlock] nvarchar(10) NULL,
    [BatchNumber] int NULL,
    [DrillingOrder] int NOT NULL,
    [ChartOrder] int NULL,
    [Type] nvarchar(50) NULL,
    [By] nvarchar(50) NULL,
    [Description] nvarchar(1000) NULL,
    [IsIncludeToCalculated] bit NOT NULL,
    [Created] datetime NULL,
    CONSTRAINT [PK_WellProperties] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[WellSpace] (
    [Id] uniqueidentifier NOT NULL,
    [WellId] nvarchar(50) NULL,
    [By] nvarchar(50) NULL,
    [Description] nvarchar(1000) NULL,
    [Created] datetime NULL,
    CONSTRAINT [PK_WellSpace] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[WellUndrilled] (
    [Id] uniqueidentifier NOT NULL,
    [WellSpaceId] uniqueidentifier NOT NULL,
    [CalculatedTimestamp] nvarchar(max) NULL,
    [WellName] nvarchar(50) NULL,
    [UndrilledMethod] nvarchar(50) NULL,
    [IsCalculatedReserve] bit NOT NULL,
    [LiquidInMBOE] decimal(18, 10) NULL,
    [GasInMMScf] decimal(18, 10) NULL,
    [TotalInMBOE] decimal(18, 10) NULL,
    [Datasource] nvarchar(max) NULL,
    [Created] datetime NULL,
    [Status] nvarchar(10) NULL,
    [FinishDate] datetime NULL,
    [Key] nvarchar(50) NULL,
    [Rev] nvarchar(50) NULL,
    CONSTRAINT [PK_WellUndrilled] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [dbo].[ModulePage] (
    [Id] uniqueidentifier NOT NULL,
    [ModuleId] uniqueidentifier NOT NULL,
    [PageId] uniqueidentifier NOT NULL,
    [By] nvarchar(50) NULL,
    [IsEnabled] bit NOT NULL,
    [Date] datetime NULL,
    CONSTRAINT [PK_ModulePage] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_ModulePage_Module_ModuleId] FOREIGN KEY ([ModuleId]) REFERENCES [dbo].[Module] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_ModulePage_Page_PageId] FOREIGN KEY ([PageId]) REFERENCES [dbo].[Page] ([Id]) ON DELETE CASCADE
);

GO

CREATE TABLE [dbo].[PageApi] (
    [Id] uniqueidentifier NOT NULL,
    [PageId] uniqueidentifier NOT NULL,
    [ApiId] uniqueidentifier NOT NULL,
    [By] nvarchar(50) NULL,
    [WorkFlow] nvarchar(50) NULL,
    [IsEnabled] bit NOT NULL,
    [Date] datetime NULL,
    CONSTRAINT [PK_PageApi] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_PageApi_Api_ApiId] FOREIGN KEY ([ApiId]) REFERENCES [dbo].[Api] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_PageApi_Page_PageId] FOREIGN KEY ([PageId]) REFERENCES [dbo].[Page] ([Id]) ON DELETE CASCADE
);

GO

CREATE TABLE [dbo].[PresetDecisionNode] (
    [Id] uniqueidentifier NOT NULL,
    [Name] nvarchar(255) NULL,
    [Type] nvarchar(50) NULL,
    [X] decimal(38, 4) NOT NULL,
    [Y] decimal(38, 4) NOT NULL,
    [Created] datetime2 NOT NULL,
    [ResourceId] uniqueidentifier NOT NULL,
    CONSTRAINT [PK_PresetDecisionNode] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_PresetDecisionNode_PresetWellScenario_ResourceId] FOREIGN KEY ([ResourceId]) REFERENCES [dbo].[PresetWellScenario] ([Id]) ON DELETE CASCADE
);

GO

CREATE TABLE [dbo].[WellScenario] (
    [Id] uniqueidentifier NOT NULL,
    [Name] nvarchar(50) NULL,
    [Description] nvarchar(255) NULL,
    [Status] nvarchar(50) NULL,
    [By] nvarchar(255) NULL,
    [Created] datetime NULL,
    [Updated] datetime NULL,
    [WellName] nvarchar(255) NULL,
    [ResourceId] uniqueidentifier NOT NULL,
    [NewTD] decimal(38, 18) NULL,
    [MotorDepth] decimal(38, 18) NULL,
    [CurrentDepth] decimal(38, 18) NULL,
    [TrippedDepth] decimal(38, 18) NULL,
    [CurrentROP] decimal(38, 18) NULL,
    [NewROP] decimal(38, 18) NULL,
    [MotorROP] decimal(38, 18) NULL,
    [Case] nvarchar(50) NULL,
    [TIH] decimal(38, 18) NULL,
    [TOH] decimal(38, 18) NULL,
    [RigRate] decimal(38, 18) NULL,
    CONSTRAINT [PK_WellScenario] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_WellScenario_PresetWellScenario_ResourceId] FOREIGN KEY ([ResourceId]) REFERENCES [dbo].[PresetWellScenario] ([Id]) ON DELETE CASCADE
);

GO

CREATE TABLE [dbo].[RoleModule] (
    [Id] uniqueidentifier NOT NULL,
    [RoleId] uniqueidentifier NOT NULL,
    [ModuleId] uniqueidentifier NOT NULL,
    [By] nvarchar(50) NULL,
    [IsEnabled] bit NOT NULL,
    [Date] datetime NULL,
    [ProjectPermission] nvarchar(10) NULL,
    [RolePermission] nvarchar(10) NULL,
    CONSTRAINT [PK_RoleModule] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_RoleModule_Module_ModuleId] FOREIGN KEY ([ModuleId]) REFERENCES [dbo].[Module] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_RoleModule_Role_RoleId] FOREIGN KEY ([RoleId]) REFERENCES [dbo].[Role] ([Id]) ON DELETE CASCADE
);

GO

CREATE TABLE [dbo].[ProjectAuthorize] (
    [Id] uniqueidentifier NOT NULL,
    [ProjectId] nvarchar(50) NULL,
    [UserId] nvarchar(50) NULL,
    [Status] nvarchar(10) NULL,
    [By] nvarchar(50) NULL,
    [Date] datetime NULL,
    CONSTRAINT [PK_ProjectAuthorize] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_ProjectAuthorize_Project_ProjectId] FOREIGN KEY ([ProjectId]) REFERENCES [dbo].[Project] ([Id]) ON DELETE NO ACTION,
    CONSTRAINT [FK_ProjectAuthorize_User_UserId] FOREIGN KEY ([UserId]) REFERENCES [dbo].[User] ([Id]) ON DELETE NO ACTION
);

GO

CREATE TABLE [dbo].[RoleAuthorize] (
    [Id] uniqueidentifier NOT NULL,
    [RoleId] uniqueidentifier NOT NULL,
    [UserId] nvarchar(50) NULL,
    [Status] nvarchar(10) NULL,
    [By] nvarchar(50) NULL,
    [Date] datetime NULL,
    CONSTRAINT [PK_RoleAuthorize] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_RoleAuthorize_Role_RoleId] FOREIGN KEY ([RoleId]) REFERENCES [dbo].[Role] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_RoleAuthorize_User_UserId] FOREIGN KEY ([UserId]) REFERENCES [dbo].[User] ([Id]) ON DELETE NO ACTION
);

GO

CREATE TABLE [dbo].[UserAuthen] (
    [Id] uniqueidentifier NOT NULL,
    [UserId] nvarchar(50) NULL,
    [IsEnabled] bit NOT NULL,
    [Status] nvarchar(max) NULL,
    [By] nvarchar(50) NULL,
    [Date] datetime NULL,
    [ExpiredDate] datetime NULL,
    CONSTRAINT [PK_UserAuthen] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_UserAuthen_User_UserId] FOREIGN KEY ([UserId]) REFERENCES [dbo].[User] ([Id]) ON DELETE NO ACTION
);

GO

CREATE TABLE [dbo].[PresetDecisionEdge] (
    [Id] uniqueidentifier NOT NULL,
    [ActivityId] uniqueidentifier NULL,
    [Label] nvarchar(255) NULL,
    [Payoff1] nvarchar(50) NULL,
    [Payoff2] nvarchar(50) NULL,
    [Probability] nvarchar(50) NULL,
    [Created] datetime2 NOT NULL,
    [FromId] uniqueidentifier NOT NULL,
    [ToId] uniqueidentifier NOT NULL,
    CONSTRAINT [PK_PresetDecisionEdge] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_PresetDecisionEdge_PresetDecisionNode_FromId] FOREIGN KEY ([FromId]) REFERENCES [dbo].[PresetDecisionNode] ([Id]) ON DELETE NO ACTION,
    CONSTRAINT [FK_PresetDecisionEdge_PresetDecisionNode_ToId] FOREIGN KEY ([ToId]) REFERENCES [dbo].[PresetDecisionNode] ([Id]) ON DELETE NO ACTION
);

GO

CREATE TABLE [dbo].[DecisionOption] (
    [Id] uniqueidentifier NOT NULL,
    [WellScenarioId] uniqueidentifier NOT NULL,
    [Order] int NOT NULL,
    [Inv] decimal(38, 18) NULL,
    [Npv] decimal(38, 18) NULL,
    [Dpi] decimal(38, 18) NULL,
    [TotalBranchCost] decimal(38, 18) NULL,
    [Created] datetime NULL,
    CONSTRAINT [PK_DecisionOption] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_DecisionOption_WellScenario_WellScenarioId] FOREIGN KEY ([WellScenarioId]) REFERENCES [dbo].[WellScenario] ([Id]) ON DELETE CASCADE
);

GO

CREATE TABLE [dbo].[WellScenarioNode] (
    [Id] uniqueidentifier NOT NULL,
    [Name] nvarchar(255) NULL,
    [Type] nvarchar(50) NULL,
    [X] decimal(38, 4) NOT NULL,
    [Y] decimal(38, 4) NOT NULL,
    [Created] datetime2 NOT NULL,
    [ResourceId] uniqueidentifier NOT NULL,
    [AdditionalCost] decimal(38, 18) NULL,
    [TotalCost] decimal(38, 18) NULL,
    [TotalInMBOE] decimal(38, 18) NULL,
    [GasInMMScf] decimal(38, 18) NULL,
    [LiquidInMBOE] decimal(38, 18) NULL,
    [INV] decimal(38, 18) NULL,
    [NPV] decimal(38, 18) NULL,
    [DPI] decimal(38, 18) NULL,
    CONSTRAINT [PK_WellScenarioNode] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_WellScenarioNode_WellScenario_ResourceId] FOREIGN KEY ([ResourceId]) REFERENCES [dbo].[WellScenario] ([Id]) ON DELETE CASCADE
);

GO

CREATE TABLE [dbo].[WellScenarioTab] (
    [RevId] uniqueidentifier NOT NULL,
    [TabId] uniqueidentifier NOT NULL,
    [MasterVersionId] uniqueidentifier NULL,
    [WellScenarioId] uniqueidentifier NOT NULL,
    [WellName] nvarchar(255) NULL,
    [Status] nvarchar(50) NULL,
    [IsDeleted] bit NOT NULL,
    [By] nvarchar(255) NULL,
    [Created] datetime NULL,
    [Updated] datetime NULL,
    CONSTRAINT [PK_WellScenarioTab] PRIMARY KEY ([RevId]),
    CONSTRAINT [FK_WellScenarioTab_WellScenarioTab_MasterVersionId] FOREIGN KEY ([MasterVersionId]) REFERENCES [dbo].[WellScenarioTab] ([RevId]) ON DELETE NO ACTION,
    CONSTRAINT [FK_WellScenarioTab_WellScenario_WellScenarioId] FOREIGN KEY ([WellScenarioId]) REFERENCES [dbo].[WellScenario] ([Id]) ON DELETE CASCADE
);

GO

CREATE TABLE [dbo].[DecisionOptionNode] (
    [Id] uniqueidentifier NOT NULL,
    [DecisionOptionId] uniqueidentifier NOT NULL,
    [ParentId] uniqueidentifier NULL,
    [Name] nvarchar(255) NULL,
    [Inv] decimal(38, 18) NOT NULL,
    [Npv] decimal(38, 18) NOT NULL,
    [Dpi] decimal(38, 18) NOT NULL,
    [TotalBranchCost] decimal(38, 18) NULL,
    [Created] datetime NULL,
    CONSTRAINT [PK_DecisionOptionNode] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_DecisionOptionNode_DecisionOption_DecisionOptionId] FOREIGN KEY ([DecisionOptionId]) REFERENCES [dbo].[DecisionOption] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_DecisionOptionNode_DecisionOptionNode_ParentId] FOREIGN KEY ([ParentId]) REFERENCES [dbo].[DecisionOptionNode] ([Id]) ON DELETE NO ACTION
);

GO

CREATE TABLE [dbo].[WellScenarioEdge] (
    [Id] uniqueidentifier NOT NULL,
    [ActivityId] uniqueidentifier NULL,
    [Label] nvarchar(255) NULL,
    [Payoff1] nvarchar(50) NULL,
    [Payoff2] nvarchar(50) NULL,
    [Probability] nvarchar(50) NULL,
    [Created] datetime2 NOT NULL,
    [FromId] uniqueidentifier NOT NULL,
    [ToId] uniqueidentifier NOT NULL,
    CONSTRAINT [PK_WellScenarioEdge] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_WellScenarioEdge_WellScenarioNode_FromId] FOREIGN KEY ([FromId]) REFERENCES [dbo].[WellScenarioNode] ([Id]) ON DELETE NO ACTION,
    CONSTRAINT [FK_WellScenarioEdge_WellScenarioNode_ToId] FOREIGN KEY ([ToId]) REFERENCES [dbo].[WellScenarioNode] ([Id]) ON DELETE NO ACTION
);

GO

CREATE TABLE [dbo].[DecisionResultGroup] (
    [Id] uniqueidentifier NOT NULL,
    [WellScenarioId] uniqueidentifier NOT NULL,
    [WellScenarioRevId] uniqueidentifier NOT NULL,
    [Remark] nvarchar(1000) NULL,
    [By] nvarchar(255) NULL,
    [Created] datetime NULL,
    CONSTRAINT [PK_DecisionResultGroup] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_DecisionResultGroup_WellScenario_WellScenarioId] FOREIGN KEY ([WellScenarioId]) REFERENCES [dbo].[WellScenario] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_DecisionResultGroup_WellScenarioTab_WellScenarioRevId] FOREIGN KEY ([WellScenarioRevId]) REFERENCES [dbo].[WellScenarioTab] ([RevId]) ON DELETE NO ACTION
);

GO

CREATE TABLE [dbo].[DecisionResult] (
    [Id] uniqueidentifier NOT NULL,
    [DecisionGroupId] uniqueidentifier NOT NULL,
    [DecisionOptionId] uniqueidentifier NOT NULL,
    [IsChosen] bit NOT NULL,
    [Remark] nvarchar(1000) NULL,
    [Created] datetime NULL,
    CONSTRAINT [PK_DecisionResult] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_DecisionResult_DecisionResultGroup_DecisionGroupId] FOREIGN KEY ([DecisionGroupId]) REFERENCES [dbo].[DecisionResultGroup] ([Id]) ON DELETE NO ACTION,
    CONSTRAINT [FK_DecisionResult_DecisionOption_DecisionOptionId] FOREIGN KEY ([DecisionOptionId]) REFERENCES [dbo].[DecisionOption] ([Id]) ON DELETE NO ACTION
);

GO

CREATE INDEX [IX_DecisionOption_WellScenarioId] ON [dbo].[DecisionOption] ([WellScenarioId]);

GO

CREATE INDEX [IX_DecisionOptionNode_DecisionOptionId] ON [dbo].[DecisionOptionNode] ([DecisionOptionId]);

GO

CREATE INDEX [IX_DecisionOptionNode_ParentId] ON [dbo].[DecisionOptionNode] ([ParentId]);

GO

CREATE INDEX [IX_DecisionResult_DecisionGroupId] ON [dbo].[DecisionResult] ([DecisionGroupId]);

GO

CREATE INDEX [IX_DecisionResult_DecisionOptionId] ON [dbo].[DecisionResult] ([DecisionOptionId]);

GO

CREATE INDEX [IX_DecisionResultGroup_WellScenarioId] ON [dbo].[DecisionResultGroup] ([WellScenarioId]);

GO

CREATE INDEX [IX_DecisionResultGroup_WellScenarioRevId] ON [dbo].[DecisionResultGroup] ([WellScenarioRevId]);

GO

CREATE INDEX [IX_ModulePage_ModuleId] ON [dbo].[ModulePage] ([ModuleId]);

GO

CREATE INDEX [IX_ModulePage_PageId] ON [dbo].[ModulePage] ([PageId]);

GO

CREATE INDEX [IX_PageApi_ApiId] ON [dbo].[PageApi] ([ApiId]);

GO

CREATE INDEX [IX_PageApi_PageId] ON [dbo].[PageApi] ([PageId]);

GO

CREATE INDEX [IX_PresetDecisionEdge_FromId] ON [dbo].[PresetDecisionEdge] ([FromId]);

GO

CREATE INDEX [IX_PresetDecisionEdge_ToId] ON [dbo].[PresetDecisionEdge] ([ToId]);

GO

CREATE INDEX [IX_PresetDecisionNode_ResourceId] ON [dbo].[PresetDecisionNode] ([ResourceId]);

GO

CREATE INDEX [IX_ProjectAuthorize_ProjectId] ON [dbo].[ProjectAuthorize] ([ProjectId]);

GO

CREATE INDEX [IX_ProjectAuthorize_UserId] ON [dbo].[ProjectAuthorize] ([UserId]);

GO

CREATE INDEX [IX_RoleAuthorize_RoleId] ON [dbo].[RoleAuthorize] ([RoleId]);

GO

CREATE INDEX [IX_RoleAuthorize_UserId] ON [dbo].[RoleAuthorize] ([UserId]);

GO

CREATE INDEX [IX_RoleModule_ModuleId] ON [dbo].[RoleModule] ([ModuleId]);

GO

CREATE INDEX [IX_RoleModule_RoleId] ON [dbo].[RoleModule] ([RoleId]);

GO

CREATE INDEX [IX_UserAuthen_UserId] ON [dbo].[UserAuthen] ([UserId]);

GO

CREATE INDEX [IX_WellScenario_ResourceId] ON [dbo].[WellScenario] ([ResourceId]);

GO

CREATE INDEX [IX_WellScenario_WellName] ON [dbo].[WellScenario] ([WellName]);

GO

CREATE INDEX [IX_WellScenarioEdge_FromId] ON [dbo].[WellScenarioEdge] ([FromId]);

GO

CREATE INDEX [IX_WellScenarioEdge_ToId] ON [dbo].[WellScenarioEdge] ([ToId]);

GO

CREATE INDEX [IX_WellScenarioNode_ResourceId] ON [dbo].[WellScenarioNode] ([ResourceId]);

GO

CREATE INDEX [IX_WellScenarioTab_MasterVersionId] ON [dbo].[WellScenarioTab] ([MasterVersionId]);

GO

CREATE INDEX [IX_WellScenarioTab_WellScenarioId] ON [dbo].[WellScenarioTab] ([WellScenarioId]);

GO

CREATE INDEX [IX_WellScenarioTab_TabId_WellName] ON [dbo].[WellScenarioTab] ([TabId], [WellName]);

GO

INSERT INTO [dbo].[__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20191121042858_initial', N'2.2.4-servicing-10062');

GO


