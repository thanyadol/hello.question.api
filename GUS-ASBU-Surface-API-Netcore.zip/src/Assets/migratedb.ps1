
$date = Get-Date -Format "yyyyMMddHHmmss"
$fromsnapshot = '20190828022326_snap_for_mini_uat_3@spin8'
$path = "Migrations/20190828022326_snap_for_mini_uat_3@spin8.sql" + $date
dotnet ef migrations script $fromsnapshot  > $path   --context 		NorthwindContext