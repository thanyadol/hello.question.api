

$workingdir = "C:\Users\hrzx\source\repos\GUS-ASBU-Surface-API-Netcore\src"
Set-Location $workingdir

$Username = 'CT\!PUIV'
$Password = "UN<xw>86A)$qQgE^q&W5"
$pass = ConvertTo-SecureString -AsPlainText $Password -Force

$SecureString = $pass
# Users you password securly
$credentials_from_last_step = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $Username, $SecureString 


Invoke-Command -ComputerName "Bkkhqw12ahva10" -Credential $credentials_from_last_step -ScriptBlock { Stop-WebAppPool -Name "SURFACE-DEV-API" }

dotnet publish --output=\\Bkkhqw12ahva10\SURFACE-DEV-API

Invoke-Command -ComputerName "Bkkhqw12ahva10" -Credential $credentials_from_last_step -ScriptBlock { Start-WebAppPool -Name "SURFACE-DEV-API" }