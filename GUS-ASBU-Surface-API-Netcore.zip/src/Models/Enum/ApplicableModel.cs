

using System; 

using System.ComponentModel;
using surflex.netcore22.Helpers;

namespace surflex.netcore22.Models
{
    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum ApplicableModel
    {

        [Description("SEPARATE")]
        SEPARATE,


        [Description("OIL")]
        OIL,



        [Description("GAS")]
        GAS,

    }
}