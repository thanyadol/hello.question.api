
using System; 

using System.ComponentModel;
using surflex.netcore22.Helpers;

namespace surflex.netcore22.Models
{
    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum ActivityAction
    {

        [Description("SAVED")]
        SAVED,


        [Description("PUBLISHED")]
        PUBLISHED,


        [Description("UPDATED")]
        UPDATED,

        [Description("SYNCED")]
        SYNCED,

        [Description("CALCULATED")]
        CALCULATED,


        [Description("MERGED")]
        MERGED,



    }
}