

using System; 

using System.ComponentModel;
using surflex.netcore22.Helpers;

namespace surflex.netcore22.Models
{
    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum FormulaType
    {

        [Description("FIXED")]
        FIXED,


        [Description("VARIABLE")]
        VARIABLE,



        [Description("CONSTANST")]
        CONSTANST,

    }
}