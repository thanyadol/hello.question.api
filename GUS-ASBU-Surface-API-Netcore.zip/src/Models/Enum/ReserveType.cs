
using System; 

using System.ComponentModel;
using surflex.netcore22.Helpers;

namespace surflex.netcore22.Models
{
    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum ReserveType
    {

        [Description("DRILLED")]
        DRILLED,


        [Description("UNDRILLED")]
        UNDRILLED,


        [Description("PLANNED")]
        PLANNED,

    }
}