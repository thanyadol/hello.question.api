
using System; 

using System.ComponentModel;
using surflex.netcore22.Helpers;

namespace surflex.netcore22.Models
{
    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum WellStatus
    {
        /*    
        private const string PLANNED = "Planned";
        private const string DRILLING = "Drilling";
        private const string COMPLETED = "Completed";
        private const string TUBING = "Tubing and Completion";
         */

        [Description("Planned")]
        PLANNED,


        [Description("Tubing and Completion")]
        TUBING,


        [Description("Drilling")]
        DRILLING,

        [Description("Completed")]
        COMPLETED,
    }

}