
using System; 

using System.ComponentModel;
using surflex.netcore22.Helpers;

namespace surflex.netcore22.Models
{
    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum AccessControl
    {
        [Description("NONE")]  //0
        NONE,

        [Description("READ")]  //0
        READ,


        [Description("FULL")] //1
        FULL,
    }
}
