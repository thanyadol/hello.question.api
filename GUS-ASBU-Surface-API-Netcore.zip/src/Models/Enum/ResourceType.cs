
using System; 

using System.ComponentModel;
using surflex.netcore22.Helpers;

namespace surflex.netcore22.Models
{
    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum ResourceType
    {

        [Description("TIME")]
        TIME,


        [Description("COST")]
        COST,


        [Description("TANGIBLE")]
        TANGIBLE,

        [Description("OPEX")]
        OPEX,

    }
}