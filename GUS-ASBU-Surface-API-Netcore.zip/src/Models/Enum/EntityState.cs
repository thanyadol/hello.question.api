

using System; 

using System.ComponentModel;
using surflex.netcore22.Helpers;

namespace surflex.netcore22.Models
{
    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum EntityState
    {

        [Description("MODIFIED")]
        MODIFIED,


        [Description("ADDED")]
        ADDED,



        [Description("REMOVED")]
        REMOVED,

    }
}