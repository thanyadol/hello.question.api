

using System; 

using System.ComponentModel;
using surflex.netcore22.Helpers;

namespace surflex.netcore22.Models
{
    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum PriceType
    {

        [Description("DAILY")]
        DAILY,


        [Description("MONTHLY")]
        MONTHLY,



        [Description("YEARLY")]
        YEARLY,

    }
}