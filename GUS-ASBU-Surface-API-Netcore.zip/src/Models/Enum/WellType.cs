
using System; 

using System.ComponentModel;
using surflex.netcore22.Helpers;

namespace surflex.netcore22.Models
{
    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum WellType
    {
        /*    
        private const string PLANNED = "Planned";
        private const string DRILLING = "Drilling";
        private const string COMPLETED = "Completed";
        private const string TUBING = "Tubing and Completion";
         */

        [Description("Gas")]
        GAS,


        [Description("Oil")]
        OIL,
    }

}