using Microsoft.EntityFrameworkCore;

namespace surflex.netcore22.Models
{
    public class NorthwindContext : DbContext
    {
        public NorthwindContext()
        { }

        //virtual for Moq ovverride
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<Project> Projects { get; set; }

        //public virtual DbSet<UserAuthen> UserAuthens { get; set; }

        public virtual DbSet<Attachment> Attachments { get; set; }

        public virtual DbSet<Well> Wells { get; set; }

        public virtual DbSet<Job> Jobs { get; set; }
        public virtual DbSet<Platform> Platforms { get; set; }

        public virtual DbSet<Sand> Sands { get; set; }
        public virtual DbSet<Template> Templates { get; set; }
        // public virtual DbSet<SandActivity> SandActivities { get; set; }


        //public virtual DbSet<JobProductive> JobProductives { get; set; }

        //   public virtual DbSet<WellReserve> WellReserves { get; set; }
        public virtual DbSet<ProjectAttribute> ProjectAttributes { get; set; }
        //public virtual DbSet<WellReserve> WellReserves { get; set; }

        public virtual DbSet<Price> PriceGroups { get; set; }
        public virtual DbSet<PeriodPrice> Prices { get; set; }
        public virtual DbSet<Area> Areas { get; set; }

        public virtual DbSet<Resource> Resources { get; set; }
        public virtual DbSet<ResourceLibrary> ResourceLibraries { get; set; }
        public virtual DbSet<ResourceTask> ResourceTasks { get; set; }

        public virtual DbSet<Rigg> Riggs { get; set; }
        public virtual DbSet<RiggRate> RiggRates { get; set; }

        //   public virtual DbSet<ScenarioActivity> ScenarioActivities { get; set; }

        public virtual DbSet<PresetWellScenario> PresetWellScenarios { get; set; }
        public virtual DbSet<PresetWellScenarioNode> PresetDecisionNodes { get; set; }
        public virtual DbSet<PresetWellScenarioEdge> PresetDecisionEdges { get; set; }

        public virtual DbSet<WellScenarioTab> WellScenarioTabs { get; set; }
        public virtual DbSet<WellScenario> WellScenarios { get; set; }
        public virtual DbSet<WellScenarioNode> DecisionNodes { get; set; }
        public virtual DbSet<WellScenarioEdge> DecisionEdges { get; set; }
        public virtual DbSet<DecisionResultGroup> DecisionResultGroups { get; set; }
        public virtual DbSet<DecisionResult> DecisionResults { get; set; }
        public virtual DbSet<DecisionOption> DecisionOptions { get; set; }
        public virtual DbSet<DecisionOptionNode> DecisionOptionNodes { get; set; }

        public virtual DbSet<Production> Productions { get; set; }
        public virtual DbSet<ProductionProfile> ProductionProfiles { get; set; }
        public virtual DbSet<ProductionParam> ProductionProfileParams { get; set; }

        public virtual DbSet<ProjectActivity> ProjectActivities { get; set; }
        public virtual DbSet<WellProperties> WellPropertieses { get; set; }

        public virtual DbSet<ProjectSpace> ProjectSpaces { get; set; }
        public virtual DbSet<ProjectWell> ProjectWells { get; set; }

        public virtual DbSet<ProjectDrilled> ProjectDrilleds { get; set; }

        public virtual DbSet<WellActivity> WellActivities { get; set; }

        public virtual DbSet<WellSpace> WellSpaces { get; set; }

        public virtual DbSet<WellDrilled> WellDrilleds { get; set; }

        public virtual DbSet<WellUndrilled> WellUndrilleds { get; set; }


        //authen
        public virtual DbSet<Role> Roles { get; set; }
        public virtual DbSet<Module> Modules { get; set; }
        public virtual DbSet<Page> Pages { get; set; }
        public virtual DbSet<RoleModule> RoleModules { get; set; }
        public virtual DbSet<ModulePage> ModulePages { get; set; }
        public virtual DbSet<RoleAuthorize> RoleAuthorizes { get; set; }
        public virtual DbSet<ProjectAuthorize> ProjectAuthorizes { get; set; }

        public virtual DbSet<UserActivity> UserActivities { get; set; }
        public virtual DbSet<UserAuthen> UserAuthens { get; set; }


        public virtual DbSet<SessionLogg> SessionLoggs { get; set; }
        public virtual DbSet<ProjectLocation> ProjectLocations { get; set; }



        public virtual DbSet<PageApi> PageApis { get; set; }
        public virtual DbSet<Api> Apis { get; set; }
        public virtual DbSet<__EFLoggingEvent> __EFLoggingEvents { get; set; }


        private const string DEFAULT_SCHEMA = "dbo";

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // modelBuilder.Entity<User>().ToTable("User");
            modelBuilder.Entity<Project>().ToTable("Project");
            modelBuilder.Entity<Platform>().ToTable("Platform");
            modelBuilder.Entity<Well>().ToTable("Well");
            //  modelBuilder.Entity<UserAuthen>().ToTable("UserAuthen");
            modelBuilder.Entity<Job>().ToTable("Job");

            modelBuilder.Entity<Template>().ToTable("Template");

            modelBuilder.Entity<ProjectAttribute>().ToTable("ProjectAttribute");
            //  modelBuilder.Entity<SandActivity>().ToTable("SandActivity");
            modelBuilder.Entity<Sand>().ToTable("Sand");

            // modelBuilder.Entity<WellReserve>().ToTable("WellReserve");

            modelBuilder.Entity<Attachment>().ToTable("Attachment");

            modelBuilder.Entity<PeriodPrice>().ToTable("PeriodPrice");
            modelBuilder.Entity<Price>().ToTable("Price");
            modelBuilder.Entity<Area>().ToTable("Area");
            //modelBuilder.Entity<JobProductive>().ToTable("JobProductive");

            modelBuilder.Entity<Resource>().ToTable("Resource");
            modelBuilder.Entity<ResourceLibrary>().ToTable("ResourceLibrary");
            modelBuilder.Entity<ResourceTask>().ToTable("ResourceTask");

            modelBuilder.Entity<Rigg>().ToTable("Rigg");
            modelBuilder.Entity<RiggRate>().ToTable("RiggRate");

            modelBuilder.Entity<WellProperties>().ToTable("WellProperties");



            //Preset well scenario
            modelBuilder.Entity<PresetWellScenario>().ToTable("PresetWellScenario");
            modelBuilder.Entity<PresetWellScenarioNode>().ToTable("PresetDecisionNode");



            var presetDecisionEdge = modelBuilder.Entity<PresetWellScenarioEdge>();
            presetDecisionEdge.HasOne(x => x.From)
                .WithMany(x => x.OutEdges)
                .HasForeignKey(x => x.FromId)
                .OnDelete(DeleteBehavior.Restrict);

            presetDecisionEdge.HasOne(x => x.To)
                .WithMany(x => x.InEdges)
                .HasForeignKey(x => x.ToId)
                .OnDelete(DeleteBehavior.Restrict);
            presetDecisionEdge.ToTable("PresetDecisionEdge");

            //Well scenario
            var wellScenarioTab = modelBuilder.Entity<WellScenarioTab>();
            wellScenarioTab.HasIndex(x => new { x.TabId, x.WellName });
            wellScenarioTab.ToTable("WellScenarioTab");

            modelBuilder.Entity<WellScenario>().ToTable("WellScenario").HasIndex(x => x.WellName);
            modelBuilder.Entity<WellScenarioNode>().ToTable("WellScenarioNode");

            var decisionEdge = modelBuilder.Entity<WellScenarioEdge>();
            decisionEdge.HasOne(x => x.From)
                .WithMany(x => x.OutEdges)
                .HasForeignKey(x => x.FromId)
                .OnDelete(DeleteBehavior.Restrict);

            decisionEdge.HasOne(x => x.To)
                .WithMany(x => x.InEdges)
                .HasForeignKey(x => x.ToId)
                .OnDelete(DeleteBehavior.Restrict);
            decisionEdge.ToTable("WellScenarioEdge");

            var decisionResultGroup = modelBuilder.Entity<DecisionResultGroup>();
            decisionResultGroup.HasOne(x => x.WellScenarioTab)
                .WithMany()
                .HasForeignKey(x => x.WellScenarioRevId)
                .OnDelete(DeleteBehavior.Restrict);
            decisionResultGroup.ToTable("DecisionResultGroup");

            var decisionResult = modelBuilder.Entity<DecisionResult>();
            decisionResult.HasOne("surflex.netcore22.Models.DecisionResultGroup", "DecisionGroup")
                    .WithMany("Decisions")
                    .HasForeignKey("DecisionGroupId")
                    .OnDelete(DeleteBehavior.Restrict);

            decisionResult.HasOne("surflex.netcore22.Models.DecisionOption", "DecisionOption")
                .WithMany()
                .HasForeignKey("DecisionOptionId")
                .OnDelete(DeleteBehavior.Restrict);
            decisionResult.ToTable("DecisionResult");

            modelBuilder.Entity<DecisionOption>().ToTable("DecisionOption");
            modelBuilder.Entity<DecisionOptionNode>().ToTable("DecisionOptionNode");

            //production
            modelBuilder.Entity<Production>().ToTable("Production");
            modelBuilder.Entity<ProductionProfile>().ToTable("ProductionProfile");
            modelBuilder.Entity<ProductionParam>().ToTable("ProductionParam");
            modelBuilder.Entity<ProjectActivity>().ToTable("ProjectActivity");

            modelBuilder.Entity<ProjectSpace>().ToTable("ProjectSpace");
            modelBuilder.Entity<ProjectWell>().ToTable("ProjectWell");
            modelBuilder.Entity<ProjectDrilled>().ToTable("ProjectDrilled");


            modelBuilder.Entity<WellActivity>().ToTable("WellActivity");
            modelBuilder.Entity<WellSpace>().ToTable("WellSpace");
            modelBuilder.Entity<WellDrilled>().ToTable("WellDrilled");
            modelBuilder.Entity<WellUndrilled>().ToTable("WellUndrilled");


            //authen
            modelBuilder.Entity<Role>().ToTable("Role");

            //modelBuilder.Entity<RoleModule>().ToTable("RoleModule");
            modelBuilder.Entity<RoleAuthorize>().ToTable("RoleAuthorize");
            modelBuilder.Entity<ProjectAuthorize>().ToTable("ProjectAuthorize");

            modelBuilder.Entity<UserAuthen>().ToTable("UserAuthen");
            modelBuilder.Entity<UserActivity>().ToTable("UserActivity");

            modelBuilder.Entity<SessionLogg>().ToTable("SessionLogg");


            modelBuilder.Entity<Api>().ToTable("Api");
            modelBuilder.Entity<PageApi>().ToTable("PageApi");


            modelBuilder.Entity<User>().ToTable("User");

            modelBuilder.Entity<Module>().ToTable("Module");
            modelBuilder.Entity<Page>().ToTable("Page");
            //   
            modelBuilder.Entity<ProjectLocation>().ToTable("ProjectLocation");

            modelBuilder.Entity<ModulePage>().ToTable("ModulePage");
            // modelBuilder.Entity<ModulePage>()
            //     .HasOne(bc => bc.Module)
            //     .WithMany(b => b.ModulePages)
            //     .HasForeignKey(bc => bc.ModuleId);
            // modelBuilder.Entity<ModulePage>()
            //     .HasOne(bc => bc.Page)
            //     .WithMany(c => c.ModulePages)
            //     .HasForeignKey(bc => bc.PageId);

            modelBuilder.Entity<RoleModule>().ToTable("RoleModule");
            // modelBuilder.Entity<RoleModule>()
            //     .HasOne(bc => bc.Module)
            //     .WithMany(b => b.RoleModules)
            //     .HasForeignKey(bc => bc.ModuleId);
            // modelBuilder.Entity<RoleModule>()
            //     .HasOne(bc => bc.Role)
            //     .WithMany(c => c.RoleModules)
            //     .HasForeignKey(bc => bc.RoleId);

            modelBuilder.Entity<__EFLoggingEvent>().ToTable("__EFLoggingEvent");


            // keep this the last line
            modelBuilder.HasDefaultSchema(DEFAULT_SCHEMA);
        }

        public NorthwindContext(DbContextOptions<NorthwindContext> options)
            : base(options)
        { }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(@"Server=(localdb)\mssqllocaldb;Database=EFProviders.InMemory;Trusted_Connection=True;ConnectRetryCount=0");
            }
        }
    }
}