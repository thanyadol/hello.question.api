using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class Linked
    {
        public int Year { get; set; }
        public List<Item> Items { get; set; }
        public Item Item { get; set; }
    }

    public class Item
    {
        public Item()
        {

        }
        public Item(int order, string id, string title)
        {
            this.Order = order;
            this.Id = id;
            this.Title = title;
            this.Type = "UNDRILLED_CALCULATE_METHOD";

            this.Value = title;
        }

        public Item(int order, string id, string title, string type, string description)
        {
            this.Order = order;
            this.Id = id;
            this.Title = title;
            this.Type = type;
            this.Description = description;
            // this.SubTitle = sub;

            this.Value = title;
        }

        public string Description { get; set; }

        public string Type { get; set; }
        // public string DocumentType { get; set; }
        public string Id { get; set; }
        public string Value { get; set; }
        public decimal DecimalValue { get; set; }

        public int Order { get; set; }

        public string Title { get; set; }

        public string SubTitle { get; set; }
    }
}