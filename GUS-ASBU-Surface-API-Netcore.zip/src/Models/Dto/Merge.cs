using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class Merge
    {
        public string Id { get; set; }
        public string Project { get; set; }

        public string Platform { get; set; }

        public string Name { get; set; }


    }
}