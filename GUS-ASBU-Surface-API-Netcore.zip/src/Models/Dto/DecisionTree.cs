﻿using System; 

using System.Collections.Generic;

namespace surflex.netcore22.Models
{
    public class DecisionTreeDto
    {
        public Guid TabId { get; set; }

        public Guid WellScenarioId { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }
    }

    public class DecisionNodeDto
    {
        public Guid Id { get; set; }

        public Guid TreeId { get; set; }

        public string Name { get; set; }

        public string Code { get; set; }

        public string Type { get; set; }

        public decimal X { get; set; }

        public decimal Y { get; set; }

        public decimal? AdditionalCost { get; set; }

        public decimal? TotalCost { get; set; }

        public decimal? TotalInMBOE { get; set; }

        public decimal? GasInMMScf { get; set; }

        public decimal? LiquidInMBOE { get; set; }

        public decimal? INV { get; set; }

        public decimal? NPV { get; set; }

        public decimal? DPI { get; set; }
    }

    public class DecisionEdgeDto
    {
        public Guid Id { get; set; }

        public string Name { get; set; }

        public string Payoff1 { get; set; }

        public string Payoff2 { get; set; }

        public string Probability { get; set; }

        public Guid FromId { get; set; }

        public Guid ToId { get; set; }

        public Guid? ActivityId { get; set; }
    }

    public class DecisionResultDto
    {
        public Guid? Id { get; set; }

        public string WellName { get; set; }

        public Guid? RevId { get; set; }

        public Guid? TabId { get; set; }

        public Guid? WellScenarioId { get; set; }
        
        public string Name { get; set; }

        public string ProblemType { get; set; }

        public ICollection<DecisionResultOptionDto> Options { get; set; }

        public string Remark { get; set; }

        public string By { get; set; }

        public string Status { get; set; }

        public bool HasPublishedVersion { get; set; }

        public DateTime? Created { get; set; }
    }

    public class DecisionResultOptionDto
    {
        public Guid Id { get; set; }
        
        public DecisionResultOptionNodeDto Root { get; set; }

        public int Order { get; set; }

        public bool IsChosen { get; set; }

        public string Remark { get; set; }

        public decimal Inv { get; set; }

        public decimal Npv { get; set; }

        public decimal Dpi { get; set; }

        public decimal TotalBranchCost { get; set; }
    }

    public class DecisionResultOptionNodeDto
    {
        public Guid Id { get; set; }

        public Guid? DecisionOptionId { get; set; }

        public Guid? ParentId { get; set; }

        public string Name { get; set; }

        public decimal Inv { get; set; }

        public decimal Npv { get; set; }

        public decimal Dpi { get; set; }

        public decimal TotalBranchCost { get; set; }

        public ICollection<DecisionResultOptionNodeDto> Scenarios = new HashSet<DecisionResultOptionNodeDto>();

        public string Reason { get; set; }
    }
}
