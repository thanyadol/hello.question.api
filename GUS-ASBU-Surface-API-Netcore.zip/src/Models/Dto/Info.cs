using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class Info
    {

        public Info(string action, string by, DateTime date)
        {
            By = by;
            Activity = action;
            Date = date;
        }

        public string Method { get; set; }
        public string By { get; set; }

        public DateTime? Date { get; set; }

        public string Activity { get; set; }


    }
}