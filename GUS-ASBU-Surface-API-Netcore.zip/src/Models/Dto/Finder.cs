using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class Finder
    {
        public string FileName { get; set; }
        public string Path { get; set; }

        public string Extension { get; set; }

        public string Size { get; set; }


    }
}