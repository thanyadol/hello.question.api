using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace surflex.netcore22.Models
{
    public class Token
    {

        public Token()
        {
            //azure or middlewere
            this.Type = "Azure";
        }


        public string ExpiredOn { get; set; }
        public string AccessToken { get; set; }


        public string RefreshToken { get; set; }

        public string AppID { get; set; }

        public string IDToken { get; set; }


        public string Type { get; set; }

    }
}