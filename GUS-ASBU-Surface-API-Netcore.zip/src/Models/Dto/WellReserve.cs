using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

//util
using surflex.netcore22.Helpers;

namespace surflex.netcore22.Models
{
    public partial class WellReserve
    {

        public WellReserve()
        {
            // this.Id = Guid.NewGuid().ToString();
            //this.Date = Utility.CurrentSEAsiaStandardTime();

            //this.Select = "TCRS";
        }

        public WellReserve(decimal planned, decimal drilled, decimal undrilled)
        {
            // this.Id = Guid.NewGuid().ToString();
            //this.Date = Utility.CurrentSEAsiaStandardTime();

            this.Planned = planned;
            this.Drilled = drilled;
            this.Undrilled = undrilled;

            //this.ProductiveUndrilled = uncalculate;
            //this.Select = "TCRS";
        }

        [NotMapped]
        public string Type { get; set; }



        //  [NotMapped]
        //  public string SandId { get; set; }

        //for dev check
        [NotMapped]
        public string WellName { get; set; }

        [NotMapped]
        public string Project { get; set; }

        [NotMapped]
        public string Platform { get; set; }

        [NotMapped]
        public string Status { get; set; }

        [NotMapped]
        [JsonIgnore]
        public Nullable<decimal> ActualTVD { get; set; }

        [NotMapped]
        [JsonIgnore]
        public Nullable<decimal> PlannedTVD { get; set; }



        public Nullable<decimal> Value { get; set; }


        [NotMapped]
        public Nullable<decimal> DepthCalculatedStart { get; set; }

        [NotMapped]
        public Info DrilledDetail { get; set; }

        [NotMapped]
        public Info UndrilledDetail { get; set; }

        [NotMapped]
        public Nullable<decimal> Planned { get; set; }

        [NotMapped]
        public Nullable<decimal> Drilled { get; set; }

        [NotMapped]
        public Nullable<decimal> Undrilled { get; set; }

        // [NotMapped]
        //  public Nullable<decimal> ProductiveUndrilled { get; set; }


        [NotMapped]
        public DateTime UpdatedDate { get; set; }

        [NotMapped]
        public DateTime CreatedDate { get; set; }

        [NotMapped]
        public Nullable<decimal> LiquidInMBOE { get; set; }
        [NotMapped]
        public Nullable<decimal> PlannedLiquidRatio { get; set; }


        [NotMapped]
        public Nullable<decimal> PlannedFreeGas { get; set; }


        [NotMapped]
        public Nullable<decimal> TruncatedWellReserveInMBOE { get; set; }

        [NotMapped]
        public Nullable<decimal> PlannedSolGas { get; set; }



        [NotMapped]
        public Nullable<decimal> PlannedOil { get; set; }



        [NotMapped]
        public Nullable<decimal> PlannedCondy { get; set; }



        [NotMapped]
        public Nullable<decimal> GasInMMSCF { get; set; }

    }
}