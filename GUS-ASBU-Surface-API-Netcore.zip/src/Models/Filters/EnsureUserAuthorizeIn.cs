using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using surflex.netcore22.Models;
using surflex.netcore22.Services;

using surflex.netcore22.Helpers;
using surflex.netcore22.Exceptions;
using surflex.netcore22.Extensions;

namespace surflex.netcore22.Model.Filters
{
    /* public abstract class ActionFilterAttribute : Attribute, IActionFilter, IFilterMetadata, 
                IAsyncActionFilter, IResultFilter, IAsyncResultFilter, IOrderedFilter
    {

    }*/

    /* 
    public class AsyncActionFilterExample : IAsyncActionFilter
    {
        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            // execute any code before the action executes
            var result = await next();
            // execute any code after the action executes
        }
    }*/

    public class EnsureUserAuthorizeInAsync : IAsyncActionFilter
    {
        private readonly IHttpService _httpService;
        private readonly IRoleService _roleService;
        private readonly ILoggService _loggService;
        private readonly IApiService _apiService;
        // private readonly Models.Cache _cachingService;

        public EnsureUserAuthorizeInAsync(IHttpService httpService, IRoleService roleService, ILoggService loggService, IApiService apiService) //, Models.Cache cachingService)
        {
            _httpService = httpService ?? throw new ArgumentNullException(nameof(httpService));

            //_sessionLoggService = sessionLoggService ?? throw new ArgumentNullException(nameof(sessionLoggService));
            _roleService = roleService ?? throw new ArgumentNullException(nameof(roleService));
            _loggService = loggService ?? throw new ArgumentNullException(nameof(loggService));
            _apiService = apiService ?? throw new ArgumentNullException(nameof(apiService));

            // _cachingService = cachingService;
        }


        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            //var 

            if (!context.HttpContext.User.Identity.IsAuthenticated)
            {
                throw new UserAuthenNotFoundException();
            }

            var current = await _httpService.GetHttpCurrentUserAsync();
            var url = context.HttpContext.Request.Path;

            //caching data
            //  _cachingService.Users.Remove(current.Id);
            // _cachingService.Users.Add(current.Id, current);

            //var cai = context.HttpContext.User.Identity.Name;
            // var id = Utility.ToUniqeIdentity(cai);

            //get lastest token session
            var token = new Token();
            try
            {

                var logg = await _loggService.GetRecentlyAsync(current.Id);
                token.AccessToken = logg.Token;

            }
            catch (SessionLoggNotFoundException) { throw new SessionLoggNotFoundException($"Session log with user id {current.Id} not found"); }

            var authorize = await _roleService.AuthorizeAsync(token);
            //check origin
            /* var valid = authorize.Roles.Select(c
                        => c.Modules.Select(x =>
                                x.Pages.Select(y =>
                                    y.APIs.Where(z => url.Value.Contains(z.Url)))));
            */

            //  var pageees = authorize.Modules.SelectMany(c => c.Pages);
            var apis = await _apiService.ListAsync();
            var ee = apis.Where(c => url.Value.Contains(c.Endpoint)).FirstOrDefault();
            if (ee == null)
            {
                throw new ApiNotFoundException();
            }

            if (ee.IsRequireAuthentication)
            {
                //no op
            }
            // /api/1.0/user/authen/post
            var tempp = authorize.Modules.SelectMany(c => c.Pages);

            //remove api version string

            var uri = url.Value;
            try
            {
                var index = url.Value.IndexOfNth("/", 3);
                uri = uri.Substring(index + 1);
            }
            catch (IndexOutOfRangeException) { throw new ApiNotValidException(); }
            catch (ArgumentException) { throw new ApiNotValidException(); }

            //exactly matched
            var valid = tempp.SelectMany(c => c.APIs).Where(x => x.Endpoint == uri);
            if (!valid.Any())
            {
                throw new ApiNotPermissionException();
            }

            //return;

            // next() calls the action method.
            var resultContext = await next();
            // resultContext.Result is set.
            // Do something after the action executes.
        }
    }

    public class EnsureUserAuthorizeIn : ActionFilterAttribute
    {
        private readonly IHttpService _httpService;
        private readonly IRoleService _roleService;
        private readonly ILoggService _loggService;

        //     private readonly User httpCurrentUser;

        public EnsureUserAuthorizeIn()
        {
            // compie erroe ??? what ???
        }

        public EnsureUserAuthorizeIn(IHttpService httpService, IRoleService roleService, ILoggService loggService)
        {
            _httpService = httpService ?? throw new ArgumentNullException(nameof(httpService));

            //_sessionLoggService = sessionLoggService ?? throw new ArgumentNullException(nameof(sessionLoggService));
            _roleService = roleService ?? throw new ArgumentNullException(nameof(roleService));

            // _httpService = httpService;
            // _roleService = roleService;
            _loggService = loggService;

        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {

        }

    }
}

