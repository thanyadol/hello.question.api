using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

//util
using surflex.netcore22.Helpers;

namespace surflex.netcore22.Models
{
    public class WellReserveParams
    {

        public WellReserveParams()
        {
            DerivedReserves = new List<WellProductiveReserve>();
        }

        public string Type { get; set; }

        //for dev check
        public string WellName { get; set; }
        public string Project { get; set; }

        public string Platform { get; set; }

        public string Status { get; set; }

        [JsonIgnore]
        public Nullable<decimal> ActualTVD { get; set; }

        [JsonIgnore]
        public Nullable<decimal> PlannedTVD { get; set; }

        public Nullable<decimal> Value { get; set; }
        public Nullable<decimal> DepthCalculatedStart { get; set; }

        public Info DrilledDetail { get; set; }
        public Info UndrilledDetail { get; set; }

        public Nullable<decimal> Planned { get; set; }
        public Nullable<decimal> Drilled { get; set; }
        public Nullable<decimal> Undrilled { get; set; }

        //
        //  public Nullable<decimal> ProductiveUndrilled { get; set; }

        public DateTime UpdatedDate { get; set; }
        public DateTime CreatedDate { get; set; }

        public Nullable<decimal> LiquidInMBOE { get; set; }

        public Nullable<decimal> PlannedLiquidRatio { get; set; }



        public Nullable<decimal> PlannedFreeGas { get; set; }
        public Nullable<decimal> TruncatedWellReserveInMBOE { get; set; }
        public Nullable<decimal> PlannedSolGas { get; set; }

        public Nullable<decimal> PlannedOil { get; set; }

        public Nullable<decimal> PlannedCondy { get; set; }
        public Nullable<decimal> GasInMMSCF { get; set; }


        //for project reserve

        public Nullable<decimal> SolOilGOR { get; set; }
        public Nullable<decimal> CondyFreeCGR { get; set; }
        public List<WellProductiveReserve> DerivedReserves { get; set; }
        public WellReserve RLLCPPlannedReserve { get; set; }
    }
}