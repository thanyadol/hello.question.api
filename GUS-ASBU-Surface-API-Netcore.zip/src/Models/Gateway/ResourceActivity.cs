using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class ResourceActivity
    {
        public string Id { get; set; }

        public string ResourceId { get; set; }
        public string LibraryId { get; set; }


        //library
        public string Name { get; set; }
        public string ValueType { get; set; }

        public string Formular { get; set; }
        public string ResourceType { get; set; }
        public string QueryParam { get; set; }

        public Nullable<decimal> Value { get; set; }

        public string PlannerType { get; set; }

        //refrenece key to platform
        public string Section { get; set; }
        public string Type { get; set; }


        public DateTime Created { get; set; }

    }
}