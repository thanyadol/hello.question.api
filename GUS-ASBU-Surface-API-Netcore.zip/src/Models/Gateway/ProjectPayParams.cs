using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class ProjectPayParams
    {

        public ProjectPayParams()
        {
            WellPays = new List<WellPay>();

            //mock
            UntruncatedNewPayTrend = new List<decimal>();
            TruncatedNewPayTrend = new List<decimal>();
            ActualNewPayTrend = new List<decimal>();
            ActualPDVATrend = new List<decimal>();
            TotalNewPayPDVATrend = new List<decimal>();
            TotalPayTrend = new List<decimal>();

            UntruncatedGasTrend = new List<decimal>();
            UntruncatedLiquidTrend = new List<decimal>();
            UntruncatedReserveTrend = new List<decimal>();
            TruncatedGasTrend = new List<decimal>();
            TruncatedLiquidTrend = new List<decimal>();
            TruncatedReserveTrend = new List<decimal>();
            ActualReserveNewPayTrend = new List<decimal>();
            ActualReservePDVATrend = new List<decimal>();

            TotalReserveNewPayPDVATrend = new List<decimal>();
            ActualReserveTrend = new List<decimal>();
            ActualGasTrend = new List<decimal>();
            ActualLiquidTrend = new List<decimal>();
        }

        public string Id { get; set; }

        public List<WellProperties> Properties { get; set; }



        public List<WellPay> WellPays { get; set; }

        public string ProjectName { get; set; }
        public string PlatformName { get; set; }

        public int RLLCPProjectId { get; set; }


        //cumulative
        public List<decimal> UntruncatedNewPayTrend { get; set; }

        public List<decimal> TruncatedNewPayTrend { get; set; }

        public List<decimal> ActualNewPayTrend { get; set; }

        public List<decimal> ActualPDVATrend { get; set; }


        public List<decimal> TotalNewPayPDVATrend { get; set; }


        //no plot
        public List<decimal> TotalPayTrend { get; set; }

        public List<decimal> UntruncatedGasTrend { get; set; }
        public List<decimal> UntruncatedLiquidTrend { get; set; }
        public List<decimal> UntruncatedReserveTrend { get; set; }
        public List<decimal> TruncatedGasTrend { get; set; }
        public List<decimal> TruncatedLiquidTrend { get; set; }
        public List<decimal> TruncatedReserveTrend { get; set; }
        public List<decimal> ActualReserveNewPayTrend { get; set; }
        public List<decimal> ActualReservePDVATrend { get; set; }

        public List<decimal> TotalReserveNewPayPDVATrend { get; set; }
        public List<decimal> ActualReserveTrend { get; set; }
        public List<decimal> ActualGasTrend { get; set; }
        public List<decimal> ActualLiquidTrend { get; set; }


        public decimal UntruncatedNewPayDiffPercentage { get; set; }


        public decimal TruncatedNewPayDiffPercentage { get; set; }


        //rigg

        public decimal AFEDayPredictDiffPercentage { get; set; }


        public decimal UntruncatedReserveDiffPercentage { get; set; }
        public decimal TruncatedReserveDiffPercentage { get; set; }

        public decimal ActualNewOilPay { get; set; }
        public decimal ActualNewGasPay { get; set; }
        public decimal ActualOilFraction { get; set; }
        public decimal PredrilledUntruncateNewPay { get; set; }
        public decimal PredrilledTruncateNewPay { get; set; }
        public decimal ActualNewPDVAPay { get; set; }

        public decimal ActualAFEDays { get; set; }
        public decimal AFEDays { get; set; }
        public decimal ActualAFEDaysWell { get; set; }
        public decimal ActualRatioInMBOERD { get; set; }

        public decimal RiggEfficiencyInMBOERD { get; set; }

    }


    public class WellPay
    {
        public WellPay()
        {
            //var rand = new Random();

            // ActualTotalPay = new decimal(rand.NextDouble() * 100);
            // ActualNewPay = new decimal(rand.NextDouble() * 100);
            // ActualPDVAPay = new decimal(rand.NextDouble() * 100);
            // ActualNewPDVAPay = new decimal(rand.NextDouble() * 100);

            // PredrilledNewOilPay = new decimal(rand.NextDouble() * 100);
            // ActualNewOilPay = new decimal(rand.NextDouble() * 100);
            // ActualPDVAOilPay = new decimal(rand.NextDouble() * 100);
            // ActualNewPDVAOilPay = new decimal(rand.NextDouble() * 100);

            // PredrilledNewGasPay = new decimal(rand.NextDouble() * 100);
            // ActualNewGasPay = new decimal(rand.NextDouble() * 100);
            // ActualPDVAGasPay = new decimal(rand.NextDouble() * 100);
            // ActualNewPDVAGasPay = new decimal(rand.NextDouble() * 100);

            // //tcrs 
            // SWMUntruncatedNewPay = new decimal(rand.NextDouble() * 100);
            // SWMTruncatedNewPay = new decimal(rand.NextDouble() * 100);
        }


        public string WellName { get; set; }

        public WellProperties Property { get; set; }



        //TCRS
        public string WellCategoryClassification { get; set; }


        public decimal SWMUntruncatedNewPay { get; set; }
        public decimal SWMTruncatedNewPay { get; set; }


        public decimal ActualOilFraction { get; set; }


        //

        public decimal ActualTotalPay { get; set; }

        public decimal ActualNewPay { get; set; }

        public decimal ActualPDVAPay { get; set; }


        public decimal ActualNewPDVAPay { get; set; }



        public decimal PredrilledNewOilPay { get; set; }   //TCRS

        public decimal ActualNewOilPay { get; set; }

        public decimal ActualPDVAOilPay { get; set; }


        public decimal ActualNewPDVAOilPay { get; set; }



        public decimal PredrilledNewGasPay { get; set; }  //TCRS

        public decimal ActualNewGasPay { get; set; }

        public decimal ActualPDVAGasPay { get; set; }


        public decimal ActualNewPDVAGasPay { get; set; }



        //for summary
        public decimal TruncatedGasInBCF { get; set; }
        public decimal TruncatedLiquidInMBBL { get; set; }

        public decimal UntruncatedGasInBCF { get; set; }
        public decimal UntruncatedLiquidInMBBL { get; set; }


        public decimal TruncatedReserveMBOE { get; set; }
        public decimal UntruncatedReserveMBOE { get; set; }


        public decimal ActualGasInBCF { get; set; }
        public decimal ActualLiquidInMBBL { get; set; }


        public decimal ActualReserveInMBOE { get; set; }

        public decimal ActualReserveNewPayInMBOE { get; set; }

        public decimal ActualReservePDVAInMBOE { get; set; }

        public decimal TotalReserveNewPayPDVAInMBOE { get; set; }


        ////////////////////
        //rigg effecian cy
        public decimal AFEDays { get; set; }
        public decimal ActualAFEDays { get; set; }

        // public decimal ActualAFEDaysWell { get; set; }
        //public decimal AFEDaysWell { get; set; }

        public decimal PredrilledRatioInMBOERD { get; set; }

        public decimal ActualRatioInMBOERD { get; set; }


        public decimal PredrilledUntruncateNewPay { get; set; }

        public decimal PredrilledTruncateNewPay { get; set; }
        public bool IsTakeRft { get; set; }


        //formock
        private int GetDecimalScale(Random r)
        {
            for (int i = 0; i <= 28; i++)
            {
                if (r.NextDouble() >= 0.1)
                    return i;
            }
            return 0;
        }

        private decimal NextDecimal(Random r)
        {
            var s = GetDecimalScale(r);

            int maxValue = 2;
            decimal fraction = 1000000000000000000m;

            var a = (int)(maxValue * r.NextDouble());
            var b = (int)(maxValue * r.NextDouble());
            var c = (int)(maxValue * r.NextDouble());

            var n = false; //r.NextDouble() >= 0.5;

            //var sevenItems = new byte[] { 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20 };

            return new Decimal(a, b, c, n, 0x00) / fraction;
        }

    }
}
