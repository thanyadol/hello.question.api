using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using surflex.netcore22.APIs.Gateway;

namespace surflex.netcore22.Models
{
    public class ProductionVolumn
    {
        public ProductionVolumn()
        {
            Slope = new List<string>();
        }

        public string Id { get; set; }
        public decimal TotalValue { get; set; }

        public decimal? PlateauVolumn { get; set; }
        public decimal? RampVolumn { get; set; }
        public decimal? DeclineValue { get; set; }

        public List<string> Slope { get; set; }

        public int CurrentDay { get; set; }

        public int Month { get; set; }
        public int Year { get; set; }
        public DateTime? CurrentDate { get; set; }

        public PeriodPrice PeriodPrice { get; set; }

        public LocationValuePair Revenue { get; set; }
        public LocationValuePair Cost { get; set; }

        public string[] PlotDates { get; set; }
        public decimal[] PlotValues { get; set; }
    }
}