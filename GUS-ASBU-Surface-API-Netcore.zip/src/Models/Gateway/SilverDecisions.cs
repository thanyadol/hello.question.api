﻿using Newtonsoft.Json;
using surflex.netcore22.Extensions;
using surflex.netcore22.Helpers;
using System; 

using System.Collections.Generic;

namespace surflex.netcore22.Models
{
    public class SilverDecisions
    {
        public enum DecisionNodeType
        {
            DECISION = 0,
            CHANCE = 1,
            TERMINAL = 2
        }

        public class SavedObject
        {
            public string Title { get; set; }

            public string Description { get; set; }

            public Data Data { get; set; }
        }

        public class Data
        {
            public string Code { get; set; }

            public List<Node> Trees { get; set; }
        }

        public class Node
        {
            [JsonProperty("$id")]
            public Guid? Id { get; set; }

            public string Name { get; set; }

            public string Code { get; set; }

            [JsonIgnore]
            public DecisionNodeType TypeEnum { get; set; }

            public string Type
            {
                get { return TypeEnum.ToString().ToLower(); }
                set { TypeEnum = EnumExtensions.ParseEnum<DecisionNodeType>(value?.ToUpper()); }
            }

            public List<Edge> ChildEdges { get; set; }

            [JsonProperty("surfaceAdditionalUSD")]
            public decimal? AdditionalCost { get; set; }

            [JsonProperty("surfaceTotalUSD")]
            public decimal? TotalCost { get; set; }

            [JsonProperty("surfaceInv")]
            public decimal? INV { get; set; }

            [JsonProperty("surfaceNpv")]
            public decimal? NPV { get; set; }

            [JsonProperty("surfaceDpi")]
            public decimal? DPI { get; set; }

            [JsonProperty("surfaceGasInMMScf")]
            public decimal? GasInMMScf { get; set; }

            [JsonProperty("surfaceLiquidInMBOE")]
            public decimal? LiquidInMBOE { get; set; }

            [JsonProperty("surfaceTotalInMBOE")]
            public decimal? TotalInMBOE { get; set; }

            public Location Location { get; set; }

            [JsonIgnore]
            public bool HasChildEdge
            {
                get { return ChildEdges != null && ChildEdges.Count > 0; }
            }
        }

        public class Edge
        {
            [JsonProperty("$id")]
            public Guid? Id { get; set; }

            public string Name { get; set; }

            [JsonProperty("surfaceActivityId")]
            public string ActivityId2
            {
                get { return ActivityId?.ToString() ?? "other"; }
                set
                {
                    if (value == "other" || value == null)
                    {
                        ActivityId = null;
                    }
                    else
                    {
                        ActivityId = new Guid(value);
                    }
                }
            }

            [JsonIgnore]
            public Guid? ActivityId { get; set; }

            [JsonProperty("payoff")]
            public List<string> EnteredPayoff { get; private set; }

            [JsonProperty("probability")]
            public string EnteredProbability { get; set; }

            [JsonIgnore]
            public string ComputedPayoff1
            {
                get
                {
                    if (Computed?.Payoff != null && Computed?.Payoff.Count > 0)
                    {
                        return Computed.Payoff[0];
                    }
                    else if (EnteredPayoff != null && EnteredPayoff.Count > 0)
                    {
                        return EnteredPayoff[0];
                    }
                    else
                    {
                        return "0";
                    }
                }
            }

            [JsonIgnore]
            public string ComputedPayoff2
            {
                get
                {
                    if (Computed?.Payoff != null && Computed?.Payoff.Count > 1)
                    {
                        return Computed.Payoff[1];
                    }
                    else if (EnteredPayoff != null && EnteredPayoff.Count > 1)
                    {
                        return EnteredPayoff[1];
                    }
                    else
                    {
                        return "0";
                    }
                }
            }

            [JsonIgnore]
            public string ComputedProbability
            {
                get
                {
                    if (Computed?.Probability != null)
                    {
                        return Computed.Probability;
                    }
                    else if (EnteredProbability != null)
                    {
                        return EnteredProbability;
                    }
                    else
                    {
                        return "0";
                    }
                }
            }

            [JsonIgnore]
            public decimal ParsedPayoff1
            {
                get
                {
                    return Utility.TryParseFractionalDecimal(ComputedPayoff1);
                }
            }

            [JsonIgnore]
            public decimal ParsedPayoff2
            {
                get
                {
                    return Utility.TryParseFractionalDecimal(ComputedPayoff2);
                }
            }

            [JsonIgnore]
            public decimal ParsedProbability
            {
                get
                {
                    return Utility.TryParseFractionalDecimal(ComputedProbability);
                }
            }

            public Node ChildNode { get; set; }

            public ComputedEdge Computed { get; set; }

            public void AddPayoff(string payoff1, string payoff2)
            {
                EnteredPayoff = new List<string> { payoff1, payoff2 };
            }
        }

        public class Location
        {
            public decimal X { get; set; }

            public decimal Y { get; set; }
        }

        public class ComputedEdge
        {
            public List<string> Payoff { get; set; }

            public string Probability { get; set; }
        }
    }
}
