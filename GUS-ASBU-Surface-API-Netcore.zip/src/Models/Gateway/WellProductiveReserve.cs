using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

//util
using surflex.netcore22.Helpers;

namespace surflex.netcore22.Models
{
    public class WellProductiveReserve
    {
        public string WellName { get; set; }

        public string Type { get; set; }

        public decimal? GasInMMscf { get; set; }


        public decimal? OilInMSTB { get; set; }


        public decimal? CondensateInMSTB { get; set; }
        public decimal? SolGasInMMscf { get; set; }

        public decimal? PlannedSolGas { get; set; }
    }
}