using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using surflex.netcore22.Models;

namespace surflex.netcore22.APIs.Gateway
{
    public class TemplateValidateParams
    {
        public string TemplateId { get; set; }

        public string TemplateName { get; set; }
        public string Extensions { get; set; }
        public string SheetName { get; set; }

        public List<LocationTextPair> Items { get; set; }

        public string Id { get; set; }
    }
}