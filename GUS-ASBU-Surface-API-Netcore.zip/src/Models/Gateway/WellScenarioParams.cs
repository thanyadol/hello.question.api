﻿
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace surflex.netcore22.Models
{
    public abstract class BaseWellScenarioParams
    {

        public Guid? Id;

        public string Name;

        // 
        public string Status;


        public SilverDecisions.SavedObject Trees;

        public string By { get; set; }

        public DateTime Created { get; set; }

        public DateTime Updated { get; set; }
    }

    public class PresetWellScenarioParams : BaseWellScenarioParams
    {

    }

    public class WellScenarioParams : BaseWellScenarioParams
    {
        public Guid? RevId;

        public Guid? TabId;

        public Guid? MasterVersionId;

        public Guid? ResourceId;

        public string WellName;

        [JsonProperty("newTd")]
        public decimal? NewTD;

        public decimal? MotorDepth;

        public decimal? CurrentDepth;

        public decimal? TrippedDepth;

        [JsonProperty("currentRop")]
        public decimal? CurrentROP;

        [JsonProperty("newRop")]
        public decimal? NewROP;

        [JsonProperty("motorRop")]
        public decimal? MotorROP;

        public string Case;

        [JsonProperty("tihRate")]
        public decimal? TIH;

        [JsonProperty("tohRate")]
        public decimal? TOH;

        public decimal? RigRate;

        public IEnumerable<DecisionResultOptionNodeDto> Scenarios;
    }
}
