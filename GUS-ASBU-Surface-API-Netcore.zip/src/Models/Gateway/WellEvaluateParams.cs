using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using surflex.netcore22.Models;
using System.ComponentModel.DataAnnotations;

namespace surflex.netcore22.APIs.Gateway
{
    public class WellEvaluateParams
    {
        public WellEvaluateParams()
        {
            //   LiquidProductionRevenues = new List<LocationValuePair>();
            // GasProductionRevenues = new List<LocationValuePair>();

            //  GasProductions = new List<ProductionVolumn>();
            //LiquidProductions = new List<ProductionVolumn>();

            // OPEXProductionCosts = new List<ProductionVolumn>();
        }

        public string Id { get; set; }

        /* 
                //datetime now year
                public LocationValuePair CurrentYear { get; set; }
                public LocationValuePair CurrentYearSummary { get; set; }

                //node ration
                public LocationValuePair TangibleCost { get; set; }

                //node ration
                public LocationValuePair IntangibleCost { get; set; }


                //from project attribute
                public LocationValuePair FECost { get; set; }
                public LocationValuePair ITTPCost { get; set; }

                public LocationValuePair AbandonmentCost { get; set; }

                //from production profile
                public List<LocationValuePair> GasProductionRevenues { get; set; }

                //from production profile
                public List<LocationValuePair> LiquidProductionRevenues { get; set; }

                public List<LocationValuePair> OPEXVolumnCosts { get; set; }

                public List<ProductionVolumn> GasProductions { get; set; }

                //from production profile
                public List<ProductionVolumn> LiquidProductions { get; set; }

                public List<ProductionVolumn> OPEXProductionCosts { get; set; }*/

        //output

        public decimal? NPV { get; set; }


        public decimal? INV { get; set; }


        public decimal? DPI { get; set; }

        //public string Base64EvaluatedFile { get; set; }



        public decimal? ActualDPI { get; set; }

        public decimal? PlannedDPI { get; set; }


        //output
        //public Attachment EvaluatedAttachment { get; set; }
        //  public Template TemplateType { get; set; }
        //public string WorkSheet { get; set; }
        public string Project { get; set; }
        public int RLLCPProjectId { get; set; }

        public string WellName { get; set; }

        public string WellStatus { get; set; }
        public string Platform { get; set; }

        public string PriceStructure { get; set; }

        // public Price UsedGasPrice { get; set; }
        // public Price UsedOilPrice { get; set; }

        public WellReserve Reserve { get; set; }

        public ProjectAttribute ProjectAtrributed { get; set; }


        public Production ProductionProfile { get; set; }


        public IEnumerable<WellReserveParams> Reserves { get; set; }

        public decimal? TotalBranchCost { get; set; }
    }

    public class LocationValuePair
    {

        public LocationValuePair(string col, int row, decimal? value)
        {
            this.Column = col;
            this.Row = row;
            this.Value = value.GetValueOrDefault();

        }

        // public LocationValuePair(string col, int row, string text)
        // {
        //     this.Column = col;
        //     this.Row = row;
        //     this.Text = text;

        // }

        public string Column { get; set; }
        public int Row { get; set; }
        public decimal Value { get; set; }

        //public string Text { get; set; }

    };



    public class LocationDatePair
    {

        public LocationDatePair(string col, int row, DateTime date)
        {
            this.Column = col;
            this.Row = row;
            this.Date = date;

        }

        // public LocationValuePair(string col, int row, string text)
        // {
        //     this.Column = col;
        //     this.Row = row;
        //     this.Text = text;

        // }

        public string Column { get; set; }
        public int Row { get; set; }
        public DateTime Date { get; set; }

        //public string Text { get; set; }

    };
}