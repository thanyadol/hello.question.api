using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using surflex.netcore22.Extensions;
using surflex.netcore22.Helpers;

namespace surflex.netcore22.Models
{
    public class WellProductive
    {
        public WellProductive()
        {
        }

        public WellProductive(string name)
        {
            this.Status = WellStatus.PLANNED.GetDescription();
            // this.Activity = "";
            this.Name = name;
        }

        public string RiggName { get; set; }

        public string RLLCPId { get; set; }
        public string Id { get; set; }

        public string Name { get; set; }

        public string Code { get; set; }

        public string Activity { get; set; }

        public string Phase { get; set; }

        public string WellPhase { get; set; }


        public string Status { get; set; }
        public DateTime Created { get; set; }


        public JobProductive Job { get; set; }

        //public IEnumerable<User> Users { get; set; }
        //public IEnumerable<Well> Wells { get; set; }

    }
}