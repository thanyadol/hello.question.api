using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using surflex.netcore22.APIs.Gateway;

namespace surflex.netcore22.Models
{
    public partial class ProjectEvaluateParams //: ProjectDrilled
    {

        public string Id { get; set; }

        public string AttachmentId { get; set; }
        public string TemplateId { get; set; } //CTEP, COTL



        public decimal? ActualDPI { get; set; }

        public decimal? PlannedDPI { get; set; }



        // public Template _Template { get; set; }

        public Attachment Attachment { get; set; }

        //   public ProjectAttribute _Attribute { get; set; }


        public string ProjectId { get; set; }


        public string ProjectName { get; set; }


        public string PlatformName { get; set; }


        public DateTime? ActivityDate { get; set; }


        //public string[] Sheets { get; set; }

        //[StringLength(50)]
        public int RLLCPProjectId { get; set; }



        ///both CTEP Profile view  *******************************************

        // public Production _ProductionRates { get; set; }
        //   public IEnumerable<WellReserveParams> _CompoundedReserve { get; set; }
        // public /* LocationCollectionPair<Price>*/  IEnumerable<Price> _Prices { get; set; }

        //  public /* LocationCollectionPair<ProductionProfileParams>*/ IEnumerable<ProductionProfileParams> _Productions { get; set; }


        // public LocationTextPair ApplicableModel { get; set; }
        // public LocationTextPair Project { get; set; }
        //   public  /* LocationValuePair*/ Job _RiggCost { get; set; }

        //   public /* LocationValuePair*/ ProjectWell _DrillingCost { get; set; } //wellcost

        // public List<LocationCollectionPair<ProductionProfileParams>> OilProductions { get; set; }

        //  public List<LocationCollectionPair<ProductionProfileParams>> SolGasProductions { get; set; }

        //public List<LocationCollectionPair<ProductionProfileParams>> GasProductions { get; set; }

        // public List<LocationCollectionPair<ProductionProfileParams>> CondensateProductions { get; set; }



        // COTL Reserve view *******************************************


        /* 
                public LocationValuePair DrillingCost { get; set; } //wellcost
                public LocationValuePair DrillingYear { get; set; } //wellcost

                public LocationValuePair RiggCost { get; set; } //wellcost
                public LocationValuePair RiggYear { get; set; } //wellcost



                public LocationValuePair TotalPlannedWell { get; set; }
                public LocationDatePair OilOnlineDate { get; set; } //project start date
                public LocationDatePair GasOnlineDate { get; set; } //start date


                public LocationValuePair GasHoldupPercentage { get; set; }
                public LocationValuePair OilHoldupPercentage { get; set; }


                public LocationValuePair OilReserve { get; set; }
                public LocationValuePair SolGasReserve { get; set; }
                public LocationValuePair GasReserve { get; set; }
                public LocationValuePair CondensateReserve { get; set; }

                public List<LocationTextPair> Prices { get; set; }*/


        // both OUT

        public decimal NPV { get; set; }


        public decimal NPI { get; set; }


        //public decimal IRR { get; set; }
        public decimal DPI { get; set; }


        public decimal DA { get; set; }



    }



    public class LocationCollectionPair<T>
    {
        public LocationCollectionPair(string col, int row)
        {
            this.Column = col;
            this.Row = row;
            // this.Value = value.GetValueOrDefault();

        }

        public string Column { get; set; }
        public int Row { get; set; }
        public string Direction { get; set; }


        public List<T> Collection { get; set; }
    }


    public class LocationTextPair
    {

        public LocationTextPair(string col, int row, string text)
        {
            this.Column = col;
            this.Row = row;
            this.Text = text;

        }
        public string Column { get; set; }
        public int Row { get; set; }

        public string Text { get; set; }
    }


}