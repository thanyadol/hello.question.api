using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Model
{
    public class JobDrilledRate
    {

        public string Id { get; set; }
        public string JobId { get; set; }

        public string WellBoreId { get; set; }
        public string WellName { get; set; }

        public string Description { get; set; }
        public Nullable<Decimal> RateInDay { get; set; }
        public Nullable<Decimal> RateInDepth { get; set; }

        public Nullable<Decimal> RateInHour { get; set; }

        public Nullable<DateTime> StartDate { get; set; }
        public Nullable<DateTime> EndDate { get; set; }


    }
}