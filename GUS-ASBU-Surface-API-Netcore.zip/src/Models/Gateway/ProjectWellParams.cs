using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace surflex.netcore22.Models
{
    public partial class ProjectWell
    {


        [NotMapped]
        //refrenece key to platform
        public string By { get; set; }


        [NotMapped]
        public string Description { get; set; }


        [NotMapped]
        public string Status { get; set; }


        [NotMapped]
        public Nullable<DateTime> Created { get; set; }


        //move to gget way

        [NotMapped]
        public List<WellProperties> Properties { get; set; }

        [NotMapped]
        public string ActivityType { get; set; }


        [NotMapped]
        public bool IsPublisher { get; set; }


        [NotMapped]
        public Nullable<DateTime> ActivityDate { get; set; }



        [NotMapped]
        public string ProjectId { get; set; }



        [NotMapped]
        public string ProjectName { get; set; }


        [NotMapped]
        public int RLLCPReferenceId { get; set; }



        [NotMapped]
        public List<JobProductive> Productives { get; set; }



        [NotMapped]
        public int? TotalPlannedWell { get; set; }


        [NotMapped]
        public int? CompletedProductiveWell { get; set; }

        [NotMapped]
        public Decimal? TotalPlannedAFEDays { get; set; }

        [NotMapped]
        public Decimal? TotalProductiveAFEDays { get; set; }


        [NotMapped]
        public decimal? TotalPlannedAFECost { get; set; }


        [NotMapped]
        public decimal? TotalProductiveAFECost { get; set; }



        [NotMapped]
        public decimal? TotalDrilledReserve { get; set; }


        [NotMapped]
        public decimal? TotalUndrilledReserve { get; set; }


        [NotMapped]
        public decimal? TotalPlannedReserve { get; set; }
    }

    public class ProjectWellParams : ProjectWell
    {

        public ProjectWellParams()
        {
        }

    }
}
