using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class SimpleWellPlanned
    {
        public string Name { get; set; }
        public bool IsSORUpdated { get; set; }
    }

    public class WellPlanned
    {
        public string Id { get; set; }

        public string Name { get; set; }

        //refrenece key to platform
        public string ProjectId { get; set; }
        public int RLLCPProjectId { get; set; }
        //public string UIDMId { get; set; }

        public string RLLCPId { get; set; }

        public string Asset { get; set; }

        public string Project { get; set; }

        public string ProjectStatus { get; set; }

        public string Platform { get; set; }

        public string Phase { get; set; }

        public string WellPhase { get; set; }
        public string OperationArea { get; set; }

        //public string JobId { get; set; }

        public string Activity { get; set; }
        public string Status { get; set; }
        public DateTime Created { get; set; }


      //  public bool IsSORUpdated { get; set; }


        public Nullable<DateTime> StartDate { get; set; }

        public Nullable<DateTime> EndDate { get; set; }

        //public IEnumerable<User> Users { get; set; }


        //public JobProductive Job { get; set; }

        //public IEnumerable<User> Users { get; set; }
        //public IEnumerable<Well> Wells { get; set; }

    }
}