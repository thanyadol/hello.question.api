using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace surflex.netcore22.Models
{
    public class WellJobProductive
    {

        public int Id { get; set; }

        public string Name { get; set; }

        public string Code { get; set; }


        public string WellPhase { get; set; }

        public string PhaseFirst { get; set; }

        public string PhaseSecond { get; set; }

        /* 
        public string JobType { get; set; }

        
        public string JobCategory { get; set; }*/


        public Nullable<decimal> ActualTVDEndCalculateDepth { get; set; }

        public Nullable<decimal> ActualTVDStartCalculateDepth { get; set; }

        public Nullable<decimal> PlannedMDStartDepth { get; set; }

        public Nullable<decimal> PlannedMDEndDepth { get; set; }



        public Nullable<decimal> PlannedAFECost { get; set; }
        //md

        public Nullable<decimal> ActualMDEndCalculateDepth { get; set; }


        public Nullable<decimal> ActualMDStartCalculateDepth { get; set; }


        public Nullable<DateTime> StartDate { get; set; }


        public Nullable<DateTime> EndDate { get; set; }


    }
}