using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.APIs.Gateway
{
    public class WellAnalogy
    {
        public string WellName { get; set; }
        public Nullable<int> GasAnalogyDataSetID { get; set; }
        public string GasAnalogyDataSetName { get; set; }
        public Nullable<int> GasAnalogyScenarioID { get; set; }
        public string GasAnalogyScenarioName { get; set; }

        public Nullable<int> OilAnalogyDataSetID { get; set; }
        public string OilAnalogyDataSetName { get; set; }
        public Nullable<int> OilAnalogyScenarioID { get; set; }
        public string OilAnalogyScenarioName { get; set; }

        public Nullable<decimal> GasArea { get; set; }
        public Nullable<decimal> OilArea { get; set; }
    }
}