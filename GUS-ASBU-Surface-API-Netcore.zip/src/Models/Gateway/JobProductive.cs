using System; 

using System.ComponentModel.DataAnnotations.Schema;

namespace surflex.netcore22.Models
{
    public class JobProductive
    {
        public string Id { get; set; }


        public string JobReportId { get; set; }

        //public string RLLCPId { get; set; }

        public string Name { get; set; }

        public string WellId { get; set; }
        public string Type { get; set; }


        public Nullable<DateTime> StartDate { get; set; }

        //null able !important
        public Nullable<DateTime> EndDate { get; set; }

        public Nullable<DateTime> Date { get; set; }

        //TargetDepthTVDCalculate
        public Decimal PlannedTVD { get; set; }
        public Decimal ActualTVD { get; set; }

        //AFTAmountCalculate
        public Decimal PlannedCostAFE { get; set; }

        //DurationMLTotalCalculate
        public Decimal PlannedAFEDays { get; set; }

        public Decimal PlannedMD { get; set; }

        public Decimal ActualMD { get; set; }

        public Decimal WellRkb { get; set; }
        public Decimal TvdRkb { get; set; }

        [NotMapped]
        public Nullable<DateTime> JobReportStartDate { get; set; }

        [NotMapped]
        public Nullable<DateTime> JobReportEndDate { get; set; }



        //CostToDateCalculate
        public Decimal ActualCostAFE { get; set; }

        //DurationTimeLogToCumulative
        public Decimal ActualAFEDays { get; set; }

        public Decimal PlannedTVDSS { get; set; }
        public Decimal ActualTVDSS { get; set; }


        public string Activity { get; set; } //%COM-PROD%

        public string Status { get; set; }

    }
}