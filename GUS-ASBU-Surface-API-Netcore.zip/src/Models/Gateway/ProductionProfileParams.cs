

using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using surflex.netcore22.APIs.Gateway;

namespace surflex.netcore22.Models
{

    //separate oil /gas record
    public class ProductionProfileParams
    {

        public ProductionProfileParams()
        {
            RampupProductionFormula = "((InitailRate * ((CurrentDay - 1) - ShiftDay + RampTerm1Day))  / (2 * RampDay)) *(RampTerm2Day - RampTerm3Day)";
            PlateauProductionFormula = "InitailRate * (PlateauTerm1Day - PlateauTerm2Day)";
            DeclineProductionFormula = "(max(AbandonRate, min(InitailRate, (InitailRate * (exp (-DeclineRate * (CurrentDay - 1 - ShiftDay -RampDay - PlateauDay)))))) - max(AbandonRate, min(InitailRate, (InitailRate * (exp (-DeclineRate * (CurrentDay - ShiftDay -RampDay - PlateauDay)))))) ) / DeclineRate ";

            PeriodPlots = new List<ProductionVolumn>();
            this.CurrentDay = 1;
        }


        public string Id { get; set; }

        public WellProductiveReserve UndrilledReserve { get; set; }

        public Platform Platform { get; set; }

        public WellReserve Reserve { get; set; }  //FIXED, VARIABLE

        public ProjectAttribute SelectedAttribute { get; set; }
        public ProductionProfile PickedProfileRate { get; set; }

        //calculate
        public decimal? PlateauResereve { get; set; }

        public decimal? CalculatedRate { get; set; }

        public decimal? DeclineResereve { get; set; }

        public decimal? DeclineRate { get; set; }


        public decimal? CGR { get; set; }

        public decimal? GOR { get; set; }

        public decimal PlateauDay { get; set; }

        public string RampupProductionFormula { get; set; }
        public string PlateauProductionFormula { get; set; }
        public string DeclineProductionFormula { get; set; }

        public string ApplicableModel { get; set; }

        public string PeriodType { get; set; }
        public int CurrentDay { get; set; }
        public int ContinueDay { get; set; }
        public DateTime ContunueDate { get; set; }

        public DateTime SelectedStartDate { get; set; }


        public List<ProductionVolumn> Plots { get; set; }

        public List<ProductionVolumn> PeriodPlots { get; set; }

        public string[] PlotDates { get; set; }
        public decimal[] PlotValues { get; set; }


        public string ProjectName { get; set; }

        public string WellName { get; set; }
        public string PlatformName { get; set; }

    }

}