using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using surflex.netcore22.Models;

namespace surflex.netcore22.APIs.Gateway
{
    public class WellDecisionParams
    {
        public string Id { get; set; }
        //[Author("AuthorName")]
        public decimal? PlannedTD { get; set; }
        public decimal? CurrentDepth { get; set; }
        public decimal? CurrentROP { get; set; }

        public decimal? NewROP { get; set; }

        public decimal? MotorROP { get; set; }


        public decimal? NewTD { get; set; }
        public decimal? TrippedDepth { get; set; }
        public decimal? MotorDepth { get; set; }
        public Nullable<decimal> ActualMDStartCalculateDepth { get; set; }

        //UIDM
        public Nullable<decimal> StartDepthOfProductionSection { get; set; }
        public decimal? TIHRate { get; set; }
        public decimal? TOHRate { get; set; }

        // public decimal? ActualEndDepthOfProduction { get; set; }


        public string WellName { get; set; } //with suffix
        public string RiggName { get; set; } //with suffix

        public string ResourceId { get; set; } //with suffix

        public WellJobProductive ActualJobProductive { get; set; }
        public RiggRate CalculatedRiggRate { get; set; }

        public Template UsedTemplate { get; set; }
        public decimal? RigRate { get; set; } //sum of hour

        //public decimal? TotalTime { get; set; }

        // public decimal? TotalCost { get; set; }
        public DateTime CalculatedTimestamp { get; set; }

        public List<Resource> Resources { get; set; }

        public string ValidateFormular { get; set; }
        public decimal? ValidateValue { get; set; }

        public List<ResourceActivity> GroupedActivities;


        public List<string> RequiredParameters;


        public FluentValidation.Results.ValidationResult ValidationResult;
        public WellDecisionParams()
        {
            Resources = new List<Resource>();
            RequiredParameters = new List<string>();
        }
    }

}