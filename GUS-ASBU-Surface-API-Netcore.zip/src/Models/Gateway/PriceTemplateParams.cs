using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using surflex.netcore22.APIs.Gateway;

namespace surflex.netcore22.Models
{


    public class PriceTemplateParams
    {

        public PriceTemplateParams()
        {
            Prices = new List<Price>();
        }

        //[NotMapped]
        public string Id { get; set; }

        public Template Template { get; set; }
        // new Item(100, "UEWWWESSD", "Edited Price", "PRICE", "Price Template" ),
        //new Item(100, "AYMO0HID2P", "Montly Price", "PRICE", "Price Template" ),

        public string Sheet { get; set; }


        public string Structure { get; set; }


        public bool HasHeader { get; set; }

        public List<PriceLocationValuePair> Structures { get; set; }


        public List<Price> Prices { get; set; }

    }


    public class PriceLocationValuePair : LocationTextPair
    {

        public string HcType { get; set; }

        public PriceLocationValuePair(string col, int row, string text, string hc)
         : base(col, row, text)
        {
            HcType = hc;
        }
    }
}