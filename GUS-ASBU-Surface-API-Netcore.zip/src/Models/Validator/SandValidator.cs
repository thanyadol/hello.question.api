using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

//validator
using FluentValidation;
using surflex.netcore22.Models;
using surflex.netcore22.Models.Constants;

using DRILLED = surflex.netcore22.Models.Constants.Drilled;


namespace surflex.netcore22.Validator
{
    public class SandValidator : AbstractValidator<Sand>
    {
        //private readonly string[] GAS_CONTACT_CATEGORY = new string[] { "GAS", "GWC", "GOC", "GOW" };
        //  private readonly string[] GlobalConstants.OIL_CONTACT_CATEGORY = new string[] { "OWC", "GOC", "GOW", "OIL" };


        public SandValidator()
        {

            RuleFor(x => x.PayClassification).NotNull().NotEmpty().NotEqual("");
            RuleFor(x => x.OpenWorksContactCategory).NotNull().NotEmpty().NotEqual("");


            // string[] category = new string[] { "GAS", "GWC", "OIL", "OWC", "GOC", "GOW" };


            RuleFor(x => x.FVFProfileBoProfileId).NotNull().NotEmpty().NotEqual(0)
                .When(x => DRILLED.OIL_CONTACT_CATEGORY.Contains(x.OpenWorksContactCategory?.Replace("AZI", "").Trim()));

            RuleFor(x => x.FVFProfileBgProfileId).NotNull().NotEmpty().NotEqual(0)
                .When(x => DRILLED.GAS_CONTACT_CATEGORY.Contains(x.OpenWorksContactCategory?.Replace("AZI", "").Trim()));



            //oil
            RuleFor(x => x.AnalogyOilAreaSetId).NotNull()
                .When(x => DRILLED.OIL_CONTACT_CATEGORY.Contains(x.OpenWorksContactCategory));
            RuleFor(x => x.AnalogyOilAreaScenarioId).NotNull()
                .When(x => DRILLED.OIL_CONTACT_CATEGORY.Contains(x.OpenWorksContactCategory));

            //gas
            RuleFor(x => x.AnalogyGasAreaSetId).NotNull()
                .When(x => DRILLED.GAS_CONTACT_CATEGORY.Contains(x.OpenWorksContactCategory));
            RuleFor(x => x.AnalogyGasAreaScenarioId).NotNull()
                .When(x => DRILLED.GAS_CONTACT_CATEGORY.Contains(x.OpenWorksContactCategory));

            //net
            RuleFor(x => x.NetGasVT).NotEmpty()
                .When(x => DRILLED.GAS_CONTACT_CATEGORY.Contains(x.OpenWorksContactCategory));

            RuleFor(x => x.NetOilVT).NotEmpty()
                .When(x => DRILLED.OIL_CONTACT_CATEGORY.Contains(x.OpenWorksContactCategory));

            //both
            RuleFor(x => x.AvgSw).NotEmpty();
            RuleFor(x => x.AvgPor).NotEmpty();
            RuleFor(x => x.TopTVDSS).NotEmpty();

            //pressure
            RuleFor(x => x.PressureRFTInPSI).NotEmpty()
                .When(x => !DRILLED.PAY_CLASSIFICATION.Contains(x.PayClassification));
            RuleFor(x => x.PressureEstimatedInitialInPSI).NotEmpty()
                .When(x => !DRILLED.PAY_CLASSIFICATION.Contains(x.PayClassification));

            //both
            RuleFor(x => x.DiscountFactorMechanical).NotEmpty();
            RuleFor(x => x.DiscountFactorCO2).NotEmpty();
            RuleFor(x => x.DiscountFactorCementQuality).NotEmpty();
            RuleFor(x => x.DiscountFactorBC).NotEmpty();


        }
    }
}