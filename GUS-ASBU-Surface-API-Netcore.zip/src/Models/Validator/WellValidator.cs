using System; 

using System.Collections.Generic;
//using Well = surflex.netcore22.APIs.Model.Well;

//validator
using FluentValidation;
using surflex.netcore22.APIs.Gateway;

//extension
using surflex.netcore22.Extensions;
using surflex.netcore22.Models;

namespace surflex.netcore22.Validator
{
    public class WellValidator : AbstractValidator<WellEvaluateParams>
    {
        public WellValidator()
        {
            RuleFor(x => x.WellStatus).Custom((b, context) =>
            {
                bool flage = Enum.TryParse(b?.ToUpper(), out WellStatus outer);
                if (flage == false)
                {
                    context.AddFailure("well status is not valid");
                }

            });

        }


    }
}