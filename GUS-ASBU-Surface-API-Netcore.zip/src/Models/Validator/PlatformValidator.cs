using System; 

using System.Collections.Generic;
//using Platform = surflex.netcore22.APIs.Model.Platform;

//validator
using FluentValidation;

//extension
using surflex.netcore22.Extensions;

namespace surflex.netcore22.Validator
{
    public class PlatformValidator : AbstractValidator<Models.Platform>
    {
        public PlatformValidator()
        {
            RuleFor(x => x.Name).NotEmpty().WithMessage("'Platform Name' must not be empty ");
            RuleFor(x => x.WellType).NotNull().NotNull();

            //oil or gase
            RuleFor(x => x.WellType)
                 .In("Oil", "Gas", "OIL", "GAS");

            RuleFor(x => x.PipelinePressure).NotNull();
            RuleFor(x => x.BcPos).NotNull();
            RuleFor(x => x.BcCompressionRatio).NotNull();
            // RuleFor(x => x.GasPipelineCoeff).NotEmpty();
            // RuleFor(x => x.OilPipelineCoeff).NotEmpty();

            RuleFor(x => x.CGR).NotNull()
                .When(x => x.WellType?.ToUpper() == "GAS");

            RuleFor(x => x.GOR).NotNull()
                .When(x => x.WellType?.ToUpper() == "OIL");
            //RuleFor(x => x.pil).NotEmpty();

        }
    }
}