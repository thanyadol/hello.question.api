using System; 

using System.Collections.Generic;
using Platform = surflex.netcore22.APIs.Model.PlatformAsync;

//validator
using FluentValidation;

//extension
using surflex.netcore22.Extensions;
using surflex.netcore22.APIs.Gateway;
using System.Linq;

using PRICE = surflex.netcore22.Models.Constants.Price;

namespace surflex.netcore22.Validator
{
    public class TemplateValidator : AbstractValidator<TemplateValidateParams>
    {
        private readonly string[] FILE_TYPE = new string[] { ".xls", ".xlsx" };
        private readonly string WELL_DPI_TEMPLATE_SHEET_PITA3 = "PITA III";
        private readonly string WELL_DPI_TEMPLATE_SHEET_THAI3 = "THAI III (PITA IV) for no SRB";

        private readonly string DRILLED_TRIP_RATE_SHEET = "(1)3-String Monobore";
        //private readonly string PRICE_SHEET = "Price";
        private readonly string DPI = "DPI";

        public TemplateValidator()
        {

            RuleSet("CTEP", () =>
            {
                RuleFor(x => x.SheetName == WELL_DPI_TEMPLATE_SHEET_PITA3).NotNull();
                RuleFor(x => FILE_TYPE.Contains(x.Extensions)).NotNull();

                RuleFor(x => x.Items.Where(c => c.Column == "A" && c.Row == 1).FirstOrDefault().Text).Equal("Economic Evaluation for Thai-I (PITA III)");
                RuleFor(x => x.Items.Where(c => c.Column == "A" && c.Row == 32).FirstOrDefault().Text).Equal(DPI);

            });


            RuleSet("COTL", () =>
            {
                RuleFor(x => x.SheetName == WELL_DPI_TEMPLATE_SHEET_THAI3).NotNull();
                RuleFor(x => FILE_TYPE.Contains(x.Extensions)).NotNull();

                RuleFor(x => x.Items.Where(c => c.Column == "A" && c.Row == 1).FirstOrDefault().Text).Equal("Economic Evaluation for Thai-III (PITA IV)");
                RuleFor(x => x.Items.Where(c => c.Column == "A" && c.Row == 32).FirstOrDefault().Text).Equal(DPI);

            });


            RuleSet("PRICE", () =>
            {
                RuleFor(x => PRICE.STRUCTURE.Contains(x.SheetName)).NotNull();
                RuleFor(x => FILE_TYPE.Contains(x.Extensions)).NotNull();

                RuleFor(x => x.Items.Where(c => c.Column == "A" && c.Row == 0).FirstOrDefault().Text).Equal("Year");
                RuleFor(x => x.Items.Where(c => c.Column == "B" && c.Row == 0).FirstOrDefault().Text).Equal("Month");

            });

            RuleSet("DRILLED_TRIP_RATE", () =>
            {
                RuleFor(x => x.SheetName == DRILLED_TRIP_RATE_SHEET).NotNull();
                RuleFor(x => FILE_TYPE.Contains(x.Extensions)).NotNull();
            });

        }
    }
}