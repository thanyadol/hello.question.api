using System; 

using System.Collections.Generic;
//using Platform = surflex.netcore22.APIs.Model.Platform;

//validator
using FluentValidation;
using surflex.netcore22.APIs.Gateway;

//extension
using surflex.netcore22.Extensions;
using surflex.netcore22.Models;
using surflex.netcore22.Services;

namespace surflex.netcore22.Validator
{

    public class WellDecisionValidator : AbstractValidator<WellDecisionParams>
    {


        //private readonly IResourceService _resourceService;
        public WellDecisionValidator() //ResourceActivity activity)
        {
            /* string formular = activity.Formular.ToUpper(); //.FirstOrDefault<string>(s => message.Contains(s));

            switch (formular)
            {
                case string a when a.Contains("ROP"):
                    RuleFor(x => x.ROP).NotNull().GreaterThan(0);
                    break;
                case string a when a.Contains("RIGG"):
                  
                    break;
                case string a when a.Contains("WELL"):


                    
                    break;
            }*/

            RuleFor(x => x.RiggName).NotNull().NotEmpty().When(c => RIGBeCompatibleValid(c, c.RiggName));
            RuleFor(x => x.WellName).NotNull().NotEmpty();

            RuleFor(x => x.CurrentROP).NotNull().NotEmpty().GreaterThan(0).When(c => CROPBeCompatibleValid(c, c.CurrentROP));
            RuleFor(x => x.NewROP).NotNull().NotEmpty().GreaterThan(0).When(c => NROPBeCompatibleValid(c, c.NewROP));
            RuleFor(x => x.MotorROP).NotNull().NotEmpty().GreaterThan(0).When(c => MROPBeCompatibleValid(c, c.MotorROP));


            RuleFor(x => x.TIHRate).NotNull().GreaterThan(0).When(c => TIHBeCompatibleValid(c, c.TIHRate));
            RuleFor(x => x.TOHRate).NotNull().GreaterThan(0).When(c => TOHBeCompatibleValid(c, c.TOHRate));

            RuleFor(x => x.CurrentDepth).NotNull().When(c => CDBeCompatibleValid(c, c.CurrentDepth));
            RuleFor(x => x.NewTD).NotNull().When(c => NTDBeCompatibleValid(c, c.NewTD));
            //RuleFor(x => x.TrippedDepth).NotNull().When(c => TDBeCompatibleValid(c, c.TrippedDepth));
            RuleFor(x => x.MotorDepth).NotNull().When(c => MDBeCompatibleValid(c, c.MotorDepth));

            //RuleFor(x => x.ValidateValue).NotNull().Must(BeCompatibleValid);

        }


        /* private bool BeCompatibleValid(WellDecisionParams param, decimal? value)
        {
            return value == null;
        }*/


        private bool CROPBeCompatibleValid(WellDecisionParams param, decimal? rop)
        {
            if (param.ValidateFormular.ToUpper().Contains("CURRENTROP"))

                return true;
            else
                return false;
        }


        private bool NROPBeCompatibleValid(WellDecisionParams param, decimal? rop)
        {
            if (param.ValidateFormular.ToUpper().Contains("NEWROP"))

                return true;
            else
                return false;
        }

        private bool MROPBeCompatibleValid(WellDecisionParams param, decimal? rop)
        {
            if (param.ValidateFormular.ToUpper().Contains("MOTORROP"))

                return true;
            else
                return false;
        }

        private bool RIGBeCompatibleValid(WellDecisionParams param, string rigg)
        {
            if (param.ValidateFormular.ToUpper().Contains("RIGRATE"))

                return true;
            else
                return false;
        }

        private bool TIHBeCompatibleValid(WellDecisionParams param, decimal? tih)
        {
            if (param.ValidateFormular.ToUpper().Contains("TIHRATE"))

                return true;
            else
                return false;
        }

        private bool TOHBeCompatibleValid(WellDecisionParams param, decimal? toh)
        {
            if (param.ValidateFormular.ToUpper().Contains("TOHRATE"))

                return true;
            else
                return false;
        }


        private bool CDBeCompatibleValid(WellDecisionParams param, decimal? cd)
        {
            if (param.ValidateFormular.ToUpper().Contains("CURRENTDEPTH"))

                return true;
            else
                return false;
        }


        private bool NTDBeCompatibleValid(WellDecisionParams param, decimal? td)
        {
            if (param.ValidateFormular.ToUpper().Contains("NEWTD"))

                return true;
            else
                return false;
        }

        /* private bool TDBeCompatibleValid(WellDecisionParams param, decimal? td)
        {
            if (param.ValidateFormular.ToUpper().Contains("TRIPPED"))

                return true;
            else
                return false;
        }*/

        private bool MDBeCompatibleValid(WellDecisionParams param, decimal? md)
        {
            if (param.ValidateFormular.ToUpper().Contains("MOTORDEPTH"))

                return true;
            else
                return false;
        }
    }
}