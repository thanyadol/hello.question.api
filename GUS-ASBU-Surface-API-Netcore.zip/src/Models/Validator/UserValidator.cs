using System; 

using System.Collections.Generic;

//validator
using FluentValidation;
using surflex.netcore22.Models;

namespace surflex.netcore22.Validator
{
    public class UserValidator : AbstractValidator<User>
    {
        public UserValidator()
        {
            RuleFor(c => c.Id).NotNull();
        }
    }
}