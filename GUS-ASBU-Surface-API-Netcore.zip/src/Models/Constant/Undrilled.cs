


namespace surflex.netcore22.Models.Constants
{
    public static class Undrilled
    {
        public readonly static Item[] METHOD = new Item[]
        {
                new Item (0, "9THBSGYW6M", "Manual"),
                new Item (1, "JL80QDRDJ2", "Deterministic Approach - Marker"),
                new Item (2, "YSPNJF63CA", "Deterministic Approach - Hand Pick"),
                new Item (3, "TEV8GMNGMX", "Deterministic Approach - Depth Interval"),
                new Item (4, "F8R96ZW3L3", "S-Curve"),
            //new Item (5, "L2OG3MUHY7", "Deteministic Approach - Hand Pick"),
        };

    }
}



