
using surflex.netcore22.Extensions;

namespace surflex.netcore22.Models.Constants
{
    public static class Resource
    {

        public readonly static Item[] TYPE = new Item[]
        {
                new Item (0, "TIME", "TIME", "TIME", ""),
                new Item (1, "COST", "COST", "COST", "" ),
                new Item (2, "TANGIBLE",  "TANGIBLE", "TANGIBLE", "" ),
                new Item (3, "OPEX",  "OPEX", "OPEX",  "" ),
        };


    }
}
