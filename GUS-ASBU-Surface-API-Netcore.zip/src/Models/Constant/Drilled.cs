


namespace surflex.netcore22.Models.Constants
{
    public static class Drilled
    {



        public readonly static string[] GAS_CONTACT_CATEGORY = new string[] { "GAS", "GWC", "GOC", "GOW" };
        public readonly static string[] OIL_CONTACT_CATEGORY = new string[] { "OWC", "GOC", "GOW", "OIL" };

        public readonly static string[] PAY_CLASSIFICATION = new string[] { "New", "Accelerated", "Depleted" };

    }

}