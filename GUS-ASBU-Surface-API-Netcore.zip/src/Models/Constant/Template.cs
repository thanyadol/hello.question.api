
namespace surflex.netcore22.Models.Constants
{
    public static class Template
    {

        public static readonly Item[] TYPE = new Item[]
        {
                new Item (0, "9THBSGYW6M", "CTEP", "MASTER_PROJECT", "Master Project DPI Calculate Template"),
                new Item (1, "F8R96ZW3L3", "COTL", "MASTER_PROJECT", "Master Project DPI Calculate Template" ),
                new Item (2, "TEV8GMNGMX",  "CTEP", "WELL_DECISION", "Well Decision Making DPI Template" ),
                new Item (3, "YSPNJF63CA",  "COTL", "WELL_DECISION",  "Well Decision Making DPI Template" ),
             //   new Item (100, "UEWWWESSD", "Edited Price", "PRICE", "Old (Yearly)" ),
                new Item (101, "AYMO0HID2P", "Monthly Price", "PRICE", "New (Monthly)" ),
                new Item (4, "HRTDLLOD34W", "Drill Trip Rate",  "DRILLED_TRIP_RATE", "Drill Trip Rate"),
        };
    }

}