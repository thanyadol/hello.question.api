


using System.Collections.Generic;

namespace surflex.netcore22.Models.Constants
{
    public static class Production
    {

        public static Item[] APPLICABLE_MODEL = new Item[]
        {
                new Item(0, "GAS", "Gas" ),
                new Item(1, "OIL", "Oil" ),
                new Item(2, "SEPARATE","Separate" ),
        };

        public readonly static decimal LOWER_BOUNDARY = 0.5m;
    }
}
