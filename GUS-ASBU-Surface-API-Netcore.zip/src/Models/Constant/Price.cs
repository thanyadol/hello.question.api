


namespace surflex.netcore22.Models.Constants
{
    public static class Price
    {        ///caegory type of reserve

        public readonly static string[] STRUCTURE = { "Low", "Mid", "High", "Sensitivity" };


    }

}