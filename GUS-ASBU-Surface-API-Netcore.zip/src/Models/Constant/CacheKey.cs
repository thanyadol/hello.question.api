
namespace surflex.netcore22.Models.Constants
{
    public static class CacheKeys
    {
        public static string JobProductives { get { return "_JobProductives_"; } }

        public static string PlannedReserves { get { return "_PlannedReserves_"; } }


        public static string ProjectProductive { get { return "_ProjectProductive_"; } }
    }
}