



namespace surflex.netcore22.Models.Constants
{
    public static class Well
    {

        public readonly static string[] COST_TYPE = new string[]
        {
                    "PROD","INTPROD" ,"3HOLD"
        };
    }



}





