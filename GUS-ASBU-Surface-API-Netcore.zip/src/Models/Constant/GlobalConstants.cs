﻿using System.Collections.Generic;
using System.ComponentModel;

namespace surflex.netcore22.Models.Constants
{
    public class GlobalConstants
    {
        public readonly static string STATUS_ACTIVE = "ACTIVE";
        public readonly static string STATUS_INACTIVE = "INACTIVE";
        public readonly static string STATUS_SAVED = "SAVE";
        public readonly static string STATUS_PUBLISHED = "PUBLISH";
        public readonly static string STATUS_ARCHIVED = "ARCHIVE";

        public readonly static string DECISION_TREE_NODE_TYPE_DECISION = "DECISION";
        public readonly static string DECISION_TREE_NODE_TYPE_CHANCE = "CHANCE";
        public readonly static string DECISION_TREE_NODE_TYPE_TERMINAL = "TERMINAL";


        // public readonly static string[] PROJECT_LOCATION = { "NORTH", "SOUTH", "CENTRAL", "NONE" };

        public readonly static Item[] PROJECT_LOCATION = new Item[]
         {
            //    new Item (0, "NONE", "NONE", "NONE", ""),
                new Item (1, "NORTH", "NORTH", "NORTH", "" ),
                new Item (2, "SOUTH",  "SOUTH", "SOUTH", "" ),
               /// new Item (3, "CENTRAL",  "CENTRAL", "CENTRAL",  "" ),
         };


        public readonly static string CENTRAL_LOCATION_ID = "CENTRAL";

        public enum AttachmentSource
        {
            [Description("DB")]
            DB,

            [Description("STORAGE_FILE")]
            STORAGE_FILE
        }

        public const string RIGG_TEMPLATE_ID = "HRTDLLOD34W";
        public const string CTEP_TEMPLATE_TYPE_ID = "9THBSGYW6M";
        public const string COTL_TEMPLATE_TYPE_ID = "F8R96ZW3L3";
        public const string MONTHLY_PRICE_TEMPLATE_ID = "AYMO0HID2P";


        public static string PRICE_STRUCTURE_YEAR_ID = "UEWWWESSD";
        public static string PRICE_STRUCTURE_MONTH_ID = "AYMO0HID2P";



    }
}
