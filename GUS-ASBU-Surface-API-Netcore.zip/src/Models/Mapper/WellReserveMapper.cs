using System; 



//model apis
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;
using surflex.netcore22.Models;

namespace surflex.netcore22.Models
{
    public class WellReserveMapper : IMapper<WellReserveAsync, WellReserve>
    {
        public WellReserve Mapp(WellReserveAsync entity)
        {

            var reserve = new WellReserve()
            {
                //UdvWellId = entity.UdvWellId,
                //ArchivedId = entity.ArchiveId,

                // Id = entity.Id.ToString(),

                //wellname
                // WellName = entit.Name,

                Drilled = null,
                Undrilled = null,

                //TotalOilEquivalentWithoutBC
                TruncatedWellReserveInMBOE = entity.TruncatedWellReserveInMBOE.GetValueOrDefault(),


                CreatedDate = entity.CreatedDate.GetValueOrDefault(),
                UpdatedDate = entity.UpdatedDate.GetValueOrDefault(),

                PlannedFreeGas = entity.FreeGas,
                PlannedSolGas = entity.SolGas,
                PlannedCondy = entity.Condy,
                PlannedOil = entity.Oil,

                //ActualTVD = entity.
            };

            return reserve;
        }

        public WellReserveAsync Reverse(WellReserve source)
        {
            var destination = new WellReserveAsync()
            {
                //UdvWellId = source.UdvWellId,
                //ArchivedId = source.ArchiveId,

                // Id = Convert.ToInt32(source.Id),

                //wellname
                //Name = source.WellName,

                //Drilled = null,
                //Undrilled = null,

                //TotalOilEquivalentWithoutBC
                TruncatedWellReserveInMBOE = source.TruncatedWellReserveInMBOE.GetValueOrDefault(),

                CreatedDate = source.CreatedDate,


                //UpdatedDate = entity.UpdatedDate.GetValueOrDefault(),
            };

            return destination;
        }

        public WellReserve Mutate(WellReserve source)
        {
            throw new NotImplementedException();
        }

    }
}