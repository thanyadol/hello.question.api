using System; 



//model apis
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;
using surflex.netcore22.Models;

namespace surflex.netcore22.Models
{
    public class ProjectMapper : IMapper<ProjectAsync, Project>
    {
        public Project Mapp(ProjectAsync entity)
        {

            var project = new Project()
            {
                Id = entity.Id.ToString(),
                Name = entity.Name,
                Status = entity.Status,
                Created = entity.CreatedDate,

                PlatformName = entity.Platform,

                RLLCPReferenceId = entity.Id,
            };

            return project;
        }

        public ProjectAsync Reverse(Project source)
        {
            var destination = new ProjectAsync()
            {
                Id = Convert.ToInt16(source.Id),
                Name = source.Name,
                Status = source.Status,
                CreatedDate = source.Created.GetValueOrDefault()

                // EndDate = currentSource.EndDate
            };

            return destination;
        }

        public Project Mutate(Project source)
        {
            throw new NotImplementedException();
        }

    }
}