using System; 

using System.Collections.Generic;


//model apis
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;
using surflex.netcore22.Models;

namespace surflex.netcore22.Models
{
    public class ProductionMapper : IMapper<ProductionProfileParams, ProductionProfileParams>
    {
        public ProductionProfileParams Mapp(ProductionProfileParams entity)
        {

            throw new NotImplementedException();
        }

        public ProductionProfileParams Reverse(ProductionProfileParams source)
        {
            throw new NotImplementedException();
        }

        public ProductionProfileParams Mutate(ProductionProfileParams source)
        {
            var mutated = new ProductionProfileParams();

            mutated.Id = Guid.NewGuid().ToString();

            mutated.Platform = source.Platform;

            mutated.Reserve = source.Reserve;

            mutated.SelectedAttribute = source.SelectedAttribute;
            mutated.PickedProfileRate = source.PickedProfileRate;

            //calculate
            mutated.PlateauResereve = source.PlateauResereve;

            mutated.DeclineResereve = source.PlateauResereve;

            mutated.DeclineRate = source.DeclineRate;
            mutated.PlateauDay = source.PlateauDay;

            mutated.RampupProductionFormula = source.RampupProductionFormula;
            mutated.PlateauProductionFormula = source.PlateauProductionFormula;
            mutated.DeclineProductionFormula = source.DeclineProductionFormula;

            mutated.ApplicableModel = source.ApplicableModel;

            //solved shallow deep problem
            mutated.PeriodPlots = source.PeriodPlots;
            mutated.Plots = source.Plots;

            return mutated;
        }

    }
}