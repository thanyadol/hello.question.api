using System; 



//model apis
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.Models;

namespace surflex.netcore22.Models
{
    public class WellPayMapper : IMapper<WellPayAsync, WellPay>
    {
        public WellPay Mapp(WellPayAsync entity)
        {


            var well = new WellPay()
            {
                WellName = entity.WellName,

                //WellCategoryClassification = words[0],

                SWMTruncatedNewPay = entity.PredrilledTruncatedNewPayFt,
                SWMUntruncatedNewPay = entity.PredrilledUntruncatedNewPayFt,

                PredrilledNewOilPay = entity.PredrilledNewOilPayFt,
                PredrilledNewGasPay = entity.PredrilledNewGasPayFt,

                TruncatedReserveMBOE = entity.TruncatedResvMboe,
                UntruncatedReserveMBOE = entity.UntruncatedResvMboe,

                //dedicate reserevce
                UntruncatedLiquidInMBBL = entity.UntruncatedLiqResvMbbl,
                UntruncatedGasInBCF = entity.UntruncatedGasResvBcf,

                TruncatedLiquidInMBBL = entity.TruncatedLiqResvMbbl,
                TruncatedGasInBCF = entity.TruncatedGasResvBcf,

                PredrilledUntruncateNewPay = entity.PredrilledUntruncatedNewPayFt,
                PredrilledTruncateNewPay = entity.PredrilledTruncatedNewPayFt,

            };

            string[] words = new string[] { };
            try
            {
                words = entity.WellDetResvWithKahCateCode.Split("_");
                well.WellCategoryClassification = words[0];
            }
            catch (NullReferenceException)
            {

            }

            return well;
        }

        public WellPayAsync Reverse(WellPay source)
        {
            throw new NotImplementedException();
        }

        public WellPay Mutate(WellPay source)
        {
            throw new NotImplementedException();
        }

    }
}