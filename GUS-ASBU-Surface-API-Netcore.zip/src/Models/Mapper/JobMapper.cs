using System; 



//model apis
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;
using surflex.netcore22.Models;


public class JobMapper : IMapper<JobAsync, Job>
{
    public Job Mapp(JobAsync entity)
    {
        var job = new Job
        {
            Id = entity.Id,
            WellName = entity.WellName,
            Type = entity.Type,
            StartDate = entity.StartDate,
            EndDate = entity.EndDate,

            TargetDepth = entity.TargetDepth,
            TotalDepthCalculate = entity.TotalDepthCalculate,
            TotalDepthTVDCalculate = entity.TotalDepthTVDCalculate,

            //for rig moved cost
            AFTAmountCalculate = entity.AFTAmountCalculate,
            TotalCostCalculate = entity.TotalCostCalculate,

        };

        return job;
    }

    public JobAsync Reverse(Job entity)
    {
        var job = new JobAsync
        {
            Id = entity.Id,
            WellName = entity.WellName,
        };

        return job;
    }

    public Job Mutate(Job source)
    {
        throw new NotImplementedException();
    }
}