using System; 



//model apis
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.Models;

namespace surflex.netcore22.Models
{
    public class WellPlannedMapper : IMapper<WellPlannedAsync, WellPlanned>
    {
        public WellPlanned Mapp(WellPlannedAsync entity)
        {
            var well = new WellPlanned()
            {
                Id = entity.Id.ToString(),
                Project = entity.Project,

                ProjectId = entity.ProjectId.ToString(),
                Name = entity.Name,
                RLLCPProjectId = entity.ProjectId, //.ToString(),

                RLLCPId = entity.Id.ToString(),
                Asset = entity.Asset,

                ProjectStatus = entity.ProjectStatus,
                OperationArea = entity.OperationArea,

                //Status = entity.ProjectStatus,
                StartDate = entity.StartDate,

                Platform = entity.Platform,

                Phase = entity.Phase,

                Activity = entity.Activity,
                Status = entity.Status,

                WellPhase = entity.WellPhase,

                // StartDate = entity.StartDate,
                EndDate = entity.EndDate,

            };

            return well;
        }

        public WellPlannedAsync Reverse(WellPlanned source)
        {
            var destination = new WellPlannedAsync()
            {
                Id = Convert.ToInt16(source.Id),
                Project = source.Project,

                ProjectId = Convert.ToInt16(source.ProjectId),
                Name = source.Name,

                Asset = source.Asset,

                Platform = source.Platform,

                ProjectStatus = source.ProjectStatus,
                OperationArea = source.OperationArea,

                Phase = source.Phase,
                Activity = source.Activity,
                Status = source.Status,

                StartDate = source.StartDate.GetValueOrDefault(),

                //Phase = source.Phase,

                //   Activity = source.Activity,
                //  Status = source.Status,

                WellPhase = source.WellPhase,

                // StartDate = entity.StartDate,
                EndDate = source.EndDate.GetValueOrDefault(),

                // EndDate = currentSource.EndDate
            };

            return destination;
        }

        public WellPlanned Mutate(WellPlanned source)
        {
            throw new NotImplementedException();
        }

    }
}