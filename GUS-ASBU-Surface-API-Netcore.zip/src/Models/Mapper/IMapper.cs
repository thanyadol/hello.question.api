namespace surflex.netcore22.Models
{
    public interface IMapper<TSource, TDestination>
    {
        TDestination Mapp(TSource entity);

        TSource Reverse(TDestination entity);

        //mutate the object with some default value
        TDestination Mutate(TDestination entity);
    }
}