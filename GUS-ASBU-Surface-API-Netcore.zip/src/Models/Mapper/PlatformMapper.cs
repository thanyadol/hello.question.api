using System; 



namespace surflex.netcore22.Models
{
    public class PlatformMapper : IMapper<surflex.netcore22.APIs.Model.PlatformAsync, surflex.netcore22.Models.Platform>
    {
        public surflex.netcore22.Models.Platform Mapp(surflex.netcore22.APIs.Model.PlatformAsync entity)
        {

            var Platform = new Platform()
            {
                Id = entity.Id.ToString(),
                Name = entity.Name,
                //Status = entity.Status,

                GOR = entity.GOR,
                CGR = entity.CGR,

                PipelinePressure = entity.PipelinePressure,
                BcPos = entity.BCPos,
                BcCompressionRatio = entity.BCCompressionRatio,
                OilPipelinePressureCoeff = entity.OilPipelineCoeff,
                GasPipelinePressureCoeff = entity.GasPipelineCoeff,

            };

            return Platform;
        }

        public surflex.netcore22.APIs.Model.PlatformAsync Reverse(surflex.netcore22.Models.Platform source)
        {
            var destination = new surflex.netcore22.APIs.Model.PlatformAsync()
            {
                //Id = source.Id,
                Name = source.Name,
                //Status = source.Status,
                //CreatedDate = source.Created.GetValueOrDefault()

                GOR = source.GOR,
                CGR = source.CGR
            };

            return destination;
        }

        public Platform Mutate(Platform source)
        {
            throw new NotImplementedException();
        }

    }
}