using System; 



//model apis
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;
using surflex.netcore22.Models;

namespace surflex.netcore22.Models
{
    public class WellProductiveMapper : IMapper<WellProductiveAsync, WellProductive>
    {
        public WellProductive Mapp(WellProductiveAsync entity)
        {
            var well = new WellProductive()
            {
                Id = entity.Id.ToString(),

                //RLLCPId = entity.Id,

                Name = entity.Name,
                Status = entity.Status,
                Code = entity.Code,
                // EndDate = currentSource.EndDate

                RiggName = entity.RiggName,

            };

            return well;
        }

        public WellProductiveAsync Reverse(WellProductive source)
        {
            var destination = new WellProductiveAsync()
            {
                Id = Convert.ToInt16(source.Id),

                Name = source.Name,
                Code = source.Code,
                Status = source.Status,


                RiggName = source.RiggName,

            };

            return destination;
        }

        public WellProductive Mutate(WellProductive source)
        {
            throw new NotImplementedException();
        }

    }



    public class WellJobProductiveMapper : IMapper<WellJobProductiveAsync, WellJobProductive>
    {
        public WellJobProductive Mapp(WellJobProductiveAsync entity)
        {
            var well = new WellJobProductive()
            {
                Id = entity.Id,

                //RLLCPId = entity.Id,
                ActualTVDEndCalculateDepth = entity.ActualTVDEndCalculateDepth,
                ActualTVDStartCalculateDepth = entity.ActualTVDStartCalculateDepth,

                //MD
                ActualMDEndCalculateDepth = entity.ActualMDEndCalculateDepth,
                ActualMDStartCalculateDepth = entity.ActualMDStartCalculateDepth,


                PlannedMDEndDepth = entity.PlannedMDEndDepth,
                PlannedMDStartDepth = entity.PlannedMDStartDepth,


                PhaseFirst = entity.PhaseFirst,
                PhaseSecond = entity.PhaseSecond,
                WellPhase = entity.WellPhase,

                PlannedAFECost = entity.PlannedAFECost,

                StartDate = entity.StartDate,
                EndDate = entity.EndDate,



                Name = entity.Name,
                //  Status = entity.Status,
                Code = entity.Code,
                // EndDate = currentSource.EndDate

            };

            return well;
        }

        public WellJobProductiveAsync Reverse(WellJobProductive source)
        {
            var destination = new WellJobProductiveAsync()
            {
                Id = source.Id,

                Name = source.Name,
                Code = source.Code,
                //Status = source.Status,


                //RLLCPId = entity.Id,
                ActualTVDEndCalculateDepth = source.ActualTVDEndCalculateDepth,
                ActualTVDStartCalculateDepth = source.ActualTVDStartCalculateDepth,

                //md
                ActualMDEndCalculateDepth = source.ActualMDEndCalculateDepth,
                ActualMDStartCalculateDepth = source.ActualMDStartCalculateDepth,

                PlannedMDEndDepth = source.PlannedMDEndDepth,
                PlannedMDStartDepth = source.PlannedMDStartDepth,

                WellPhase = source.WellPhase,

                PlannedAFECost = source.PlannedAFECost,

                PhaseFirst = source.PhaseFirst,
                PhaseSecond = source.PhaseSecond,

                StartDate = source.StartDate,
                EndDate = source.EndDate,

            };

            return destination;
        }

        public WellJobProductive Mutate(WellJobProductive source)
        {
            throw new NotImplementedException();
        }

    }
}