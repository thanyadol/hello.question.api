﻿using AutoMapper;

namespace surflex.netcore22.Models.Mapper
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            //Preset well scenario
            CreateMap<PresetWellScenarioParams, PresetWellScenario>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Name))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.Status))
                .ForMember(dest => dest.By, opt => opt.MapFrom(src => src.By))
                .ForMember(dest => dest.Created, opt => opt.MapFrom(src => src.Created))
                .ForMember(dest => dest.Updated, opt => opt.MapFrom(src => src.Updated))
                .ReverseMap();

            CreateMap<DecisionTreeDto, PresetWellScenario>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.WellScenarioId))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Name))
                .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.Description))
                .ReverseMap();

            CreateMap<DecisionNodeDto, PresetWellScenarioNode>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Name))
                .ForMember(dest => dest.ResourceId, opt => opt.MapFrom(src => src.TreeId))
                .ForMember(dest => dest.Type, opt => opt.MapFrom(src => src.Type))
                .ForMember(dest => dest.X, opt => opt.MapFrom(src => src.X))
                .ForMember(dest => dest.Y, opt => opt.MapFrom(src => src.Y))
                .ReverseMap();

            CreateMap<DecisionEdgeDto, PresetWellScenarioEdge>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
                .ForMember(dest => dest.ActivityId, opt => opt.MapFrom(src => src.ActivityId))
                .ForMember(dest => dest.Label, opt => opt.MapFrom(src => src.Name))
                .ForMember(dest => dest.Payoff1, opt => opt.MapFrom(src => src.Payoff1))
                .ForMember(dest => dest.Payoff2, opt => opt.MapFrom(src => src.Payoff2))
                .ForMember(dest => dest.Probability, opt => opt.MapFrom(src => src.Probability))
                .ForMember(dest => dest.ToId, opt => opt.MapFrom(src => src.ToId))
                .ForMember(dest => dest.FromId, opt => opt.MapFrom(src => src.FromId))
                .ReverseMap();

            //Well scenario
            CreateMap<DecisionResultDto, WellScenarioTab>()
                .ForMember(dest => dest.RevId, opt => opt.MapFrom(src => src.RevId))
                .ForMember(dest => dest.TabId, opt => opt.MapFrom(src => src.TabId))
                .ForMember(dest => dest.WellScenarioId, opt => opt.MapFrom(src => src.WellScenarioId))
                .ForMember(dest => dest.WellName, opt => opt.MapFrom(src => src.WellName))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.Status))
                .ForMember(dest => dest.By, opt => opt.MapFrom(src => src.By))
                .ForMember(dest => dest.Created, opt => opt.MapFrom(src => src.Created))
                .ForMember(dest => dest.Updated, opt => opt.MapFrom(src => src.Created))
                .ReverseMap();
            
            CreateMap<WellScenarioParams, WellScenarioTab>()
                .ForMember(dest => dest.RevId, opt => opt.MapFrom(src => src.RevId))
                .ForMember(dest => dest.TabId, opt => opt.MapFrom(src => src.TabId))
                .ForMember(dest => dest.WellScenarioId, opt => opt.MapFrom(src => src.Id))
                .ForMember(dest => dest.MasterVersionId, opt => opt.MapFrom(src => src.MasterVersionId))
                .ForMember(dest => dest.WellName, opt => opt.MapFrom(src => src.WellName))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.Status))
                .ForMember(dest => dest.By, opt => opt.MapFrom(src => src.By))
                .ForMember(dest => dest.Created, opt => opt.MapFrom(src => src.Created))
                .ForMember(dest => dest.Updated, opt => opt.MapFrom(src => src.Updated))
                .ReverseMap();

            CreateMap<WellScenarioTab, WellScenarioParams>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.WellScenario.Id))
                .ForMember(dest => dest.ResourceId, opt => opt.MapFrom(src => src.WellScenario.ResourceId))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.WellScenario.Name))
                .ForMember(dest => dest.TrippedDepth, opt => opt.MapFrom(src => src.WellScenario.TrippedDepth))
                .ForMember(dest => dest.CurrentDepth, opt => opt.MapFrom(src => src.WellScenario.CurrentDepth))
                .ForMember(dest => dest.MotorDepth, opt => opt.MapFrom(src => src.WellScenario.MotorDepth))
                .ForMember(dest => dest.NewTD, opt => opt.MapFrom(src => src.WellScenario.NewTD))
                .ForMember(dest => dest.CurrentROP, opt => opt.MapFrom(src => src.WellScenario.CurrentROP))
                .ForMember(dest => dest.NewROP, opt => opt.MapFrom(src => src.WellScenario.NewROP))
                .ForMember(dest => dest.MotorROP, opt => opt.MapFrom(src => src.WellScenario.MotorROP))
                .ForMember(dest => dest.Case, opt => opt.MapFrom(src => src.WellScenario.Case))
                .ForMember(dest => dest.TIH, opt => opt.MapFrom(src => src.WellScenario.TIH))
                .ForMember(dest => dest.TOH, opt => opt.MapFrom(src => src.WellScenario.TOH))
                .ForMember(dest => dest.RigRate, opt => opt.MapFrom(src => src.WellScenario.RigRate));

            CreateMap<WellScenarioParams, WellScenario>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
                .ForMember(dest => dest.ResourceId, opt => opt.MapFrom(src => src.ResourceId))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Name))
                .ForMember(dest => dest.WellName, opt => opt.MapFrom(src => src.WellName))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.Status))
                .ForMember(dest => dest.TrippedDepth, opt => opt.MapFrom(src => src.TrippedDepth))
                .ForMember(dest => dest.CurrentDepth, opt => opt.MapFrom(src => src.CurrentDepth))
                .ForMember(dest => dest.MotorDepth, opt => opt.MapFrom(src => src.MotorDepth))
                .ForMember(dest => dest.NewTD, opt => opt.MapFrom(src => src.NewTD))
                .ForMember(dest => dest.CurrentROP, opt => opt.MapFrom(src => src.CurrentROP))
                .ForMember(dest => dest.NewROP, opt => opt.MapFrom(src => src.NewROP))
                .ForMember(dest => dest.MotorROP, opt => opt.MapFrom(src => src.MotorROP))
                .ForMember(dest => dest.Case, opt => opt.MapFrom(src => src.Case))
                .ForMember(dest => dest.TIH, opt => opt.MapFrom(src => src.TIH))
                .ForMember(dest => dest.TOH, opt => opt.MapFrom(src => src.TOH))
                .ForMember(dest => dest.RigRate, opt => opt.MapFrom(src => src.RigRate))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.Status))
                .ForMember(dest => dest.By, opt => opt.MapFrom(src => src.By))
                .ForMember(dest => dest.Created, opt => opt.MapFrom(src => src.Created))
                .ForMember(dest => dest.Updated, opt => opt.MapFrom(src => src.Updated))
                .ReverseMap();

            CreateMap<DecisionTreeDto, WellScenario>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.WellScenarioId))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Name))
                .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.Description))
                .ReverseMap();

            CreateMap<DecisionNodeDto, WellScenarioNode>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
                .ForMember(dest => dest.ResourceId, opt => opt.MapFrom(src => src.TreeId))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Name))
                .ForMember(dest => dest.Type, opt => opt.MapFrom(src => src.Type))
                .ForMember(dest => dest.X, opt => opt.MapFrom(src => src.X))
                .ForMember(dest => dest.Y, opt => opt.MapFrom(src => src.Y))
                .ForMember(dest => dest.AdditionalCost, opt => opt.MapFrom(src => src.AdditionalCost))
                .ForMember(dest => dest.TotalCost, opt => opt.MapFrom(src => src.TotalCost))
                .ForMember(dest => dest.TotalInMBOE, opt => opt.MapFrom(src => src.TotalInMBOE))
                .ForMember(dest => dest.GasInMMScf, opt => opt.MapFrom(src => src.GasInMMScf))
                .ForMember(dest => dest.LiquidInMBOE, opt => opt.MapFrom(src => src.LiquidInMBOE))
                .ForMember(dest => dest.INV, opt => opt.MapFrom(src => src.INV))
                .ForMember(dest => dest.NPV, opt => opt.MapFrom(src => src.NPV))
                .ForMember(dest => dest.DPI, opt => opt.MapFrom(src => src.DPI))
                .ReverseMap();

            CreateMap<DecisionEdgeDto, WellScenarioEdge>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
                .ForMember(dest => dest.ActivityId, opt => opt.MapFrom(src => src.ActivityId))
                .ForMember(dest => dest.Label, opt => opt.MapFrom(src => src.Name))
                .ForMember(dest => dest.Payoff1, opt => opt.MapFrom(src => src.Payoff1))
                .ForMember(dest => dest.Payoff2, opt => opt.MapFrom(src => src.Payoff2))
                .ForMember(dest => dest.Probability, opt => opt.MapFrom(src => src.Probability))
                .ForMember(dest => dest.ToId, opt => opt.MapFrom(src => src.ToId))
                .ForMember(dest => dest.FromId, opt => opt.MapFrom(src => src.FromId))
                .ReverseMap();

            //Decision
            CreateMap<DecisionOption, DecisionResultOptionDto>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
                .ForMember(dest => dest.Order, opt => opt.MapFrom(src => src.Order))
                .ForMember(dest => dest.Inv, opt => opt.MapFrom(src => src.Inv))
                .ForMember(dest => dest.Npv, opt => opt.MapFrom(src => src.Npv))
                .ForMember(dest => dest.Dpi, opt => opt.MapFrom(src => src.Dpi))
                .ForMember(dest => dest.TotalBranchCost, opt => opt.MapFrom(src => src.TotalBranchCost));

            CreateMap<DecisionOptionNode, DecisionResultOptionNodeDto>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
                .ForMember(dest => dest.DecisionOptionId, opt => opt.MapFrom(src => src.DecisionOptionId))
                .ForMember(dest => dest.ParentId, opt => opt.MapFrom(src => src.ParentId))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Name))
                .ForMember(dest => dest.Inv, opt => opt.MapFrom(src => src.Inv))
                .ForMember(dest => dest.Npv, opt => opt.MapFrom(src => src.Npv))
                .ForMember(dest => dest.Dpi, opt => opt.MapFrom(src => src.Dpi))
                .ForMember(dest => dest.TotalBranchCost, opt => opt.MapFrom(src => src.TotalBranchCost));
        }
    }
}
