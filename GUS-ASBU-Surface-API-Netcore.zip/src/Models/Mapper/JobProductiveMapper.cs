using System; 



//model apis
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.Models;

namespace surflex.netcore22.Models
{
    public class JobProductiveMapper : IMapper<JobProductiveAsync, JobProductive>
    {
        public JobProductive Mapp(JobProductiveAsync entity)
        {
            var job = new JobProductive
            {
                Id = entity.Id,
                JobReportId = entity.JobReportId,
                Name = entity.WellName,
                Type = entity.Type,
                StartDate = entity.StartDate,
                EndDate = entity.EndDate,

                //TargetDepthTVDCalculate = entity.TargetDepthTVDCalculate,
                //AFTAmountCalculate = entity.AFTAmountCalculate,
                //DurationMLTotalCalculate = entity.DurationMLTotalCalculate,
                //JobReportStartDate = entity.JobReportStartDate,
                //JobReportEndDate = entity.JobReportEndDate,
                //CostToDateCalculate = entity.CostToDateCalculate,
                //TargetDepth = entity.TargetDepth,
                //DurationTimeLogToCumulative = entity.DurationTimeLogToCumulative,

                JobReportStartDate = entity.JobReportStartDate,
                JobReportEndDate = entity.JobReportEndDate,

                //TargetDepthTVDCalculate
                PlannedTVD = entity.TargetDepthTVDCalculate,
                ActualTVD = entity.TotalDepthTVDCalculate,


                //AFTAmountCalculate
                PlannedCostAFE = entity.AFTAmountCalculate,

                //DurationMLTotalCalculate
                PlannedAFEDays = entity.DurationMLTotalCalculate,

                //CostToDateCalculate
                ActualCostAFE = entity.CostToDateCalculate,

                //DurationTimeLogToCumulative
                ActualAFEDays = entity.DurationTimeLogToCumulative,

                //Planned MD
                PlannedMD = entity.TargetDepth,
                ActualMD = entity.TotalDepthCalculate,

                Activity = entity.Activity,
                Status = entity.Status,

                WellRkb = entity.Rkb,
                TvdRkb = entity.CurrentRkb
            };

            return job;
        }

        public JobProductiveAsync Reverse(JobProductive entity)
        {
            var job = new JobProductiveAsync
            {
                Id = entity.Id,
                JobReportId = entity.JobReportId,
                WellName = entity.Name,
                Type = entity.Type,
                StartDate = entity.StartDate,
                //EndDate = entity.EndDate,

                //TargetDepthTVDCalculate = entity.TargetDepthTVDCalculate,
                //AFTAmountCalculate = entity.AFTAmountCalculate,
                //DurationMLTotalCalculate = entity.DurationMLTotalCalculate,
                //JobReportStartDate = entity.JobReportStartDate,
                //JobReportEndDate = entity.JobReportEndDate,
                //CostToDateCalculate = entity.CostToDateCalculate,
                //TargetDepth = entity.TargetDepth,
                //DurationTimeLogToCumulative = entity.DurationTimeLogToCumulative,

                JobReportStartDate = entity.JobReportStartDate,
                JobReportEndDate = entity.JobReportEndDate,

                //TargetDepthTVDCalculate
                /* PlannedTVD = entity.TargetDepthTVDCalculate,

                //AFTAmountCalculate
                PlannedCostAFE = entity.AFTAmountCalculate,

                //DurationMLTotalCalculate
                PlannedAFEDays = entity.DurationMLTotalCalculate,

                //CostToDateCalculate
                ActualCostAFE = entity.CostToDateCalculate,

                //DurationTimeLogToCumulative
                ActualAFEDays = entity.DurationTimeLogToCumulative,

                //Planned MD
                PlannedMD = entity.TargetDepth,

                //Actual MD
                ActualMD = entity.TotalDepthCalculate,*/

                Activity = entity.Activity,
                Status = entity.Status,

                Rkb = entity.WellRkb,
                CurrentRkb = entity.TvdRkb

            };

            return job;
        }


        public JobProductive Mutate(JobProductive source)
        {
            throw new NotImplementedException();
        }
    }

}