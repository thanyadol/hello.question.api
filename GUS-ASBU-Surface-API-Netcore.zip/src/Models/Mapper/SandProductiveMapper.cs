using System; 



//model apis
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;
using surflex.netcore22.Models;

namespace surflex.netcore22.Models
{
    public class SandMapper : IMapper<SandAsync, Sand>
    {
        public Sand Mapp(SandAsync entity)
        {

            var drilled = new Sand()
            {
                //Id = entity.Id.ToString(),

                TopMD = Convert.ToDecimal(entity.TopMd),
                BaseMD = Convert.ToDecimal(entity.BaseMd),
                //Usi = entity.WellName

                Iwd = entity.Uwi,
                Name = entity.SandName,

                WellName = entity.WellName,
                TopTVDSS = Convert.ToDecimal(entity.TopTvdss),
                BaseTVDSS = Convert.ToDecimal(entity.BaseTvdss),

                GocTVDSS = Convert.ToDecimal(entity.GocTvdss),
                HwcTVDSS = Convert.ToDecimal(entity.HcwcTvdss),

                GrossSandMT = Convert.ToDecimal(entity.GrossSandMT),
                GrossSandVT = Convert.ToDecimal(entity.GrossSandVT),

                NetGasVT = Convert.ToDecimal(entity.NetGasVT),
                NetOilVT = Convert.ToDecimal(entity.NetOilVT),

                ///Rt = Convert.ToDecimal(entity.Vsh),
                Vsh = Convert.ToDecimal(entity.Vsh),
                AvgSw = Convert.ToDecimal(entity.Sw),
                AvgPor = Convert.ToDecimal(entity.Por),
                TG = Convert.ToDecimal(entity.Tg),

                MaximumResistivity = Convert.ToDecimal(entity.Rt),
                GrossIntervalFrom = Convert.ToDecimal(entity.TopMd),
                GrossIntervalTo = Convert.ToDecimal(entity.BaseMd),
                //MW

                //BG

                Fluid = entity.Fluid,

                Remarks = entity.Remark,
                EstPhase = entity.EstPhase,
                AZI = entity.Azi,

                DataSource = entity.DataSource,
                CreatedDate = entity.CreatedDate.GetValueOrDefault(),

                SORUpdatedDate = entity.UpdatedDate.GetValueOrDefault(),

                Pos = entity.Pos.GetValueOrDefault()


                // EndDate = currentSource.EndDate

            };

            return drilled;
        }

        public SandAsync Reverse(Sand source)
        {
            var destination = new SandAsync()
            {
                Id = Convert.ToInt16(source.Id),

                TopMd = source.TopMD,
                BaseMd = source.BaseMD.ToString(),
                //Usi = source.WellName

                //wd = source.Uwi,
                SandName = source.Name,

                WellName = source.WellName,
                TopTvdss = source.TopTVDSS.ToString(),
                BaseTvdss = source.BaseTVDSS.ToString(),

                GocTvdss = source.GocTVDSS,
                HcwcTvdss = source.HwcTVDSS.ToString(),

                GrossSandMT = source.GrossSandMT.ToString(),
                GrossSandVT = source.GrossSandVT.ToString(),

                NetGasVT = source.NetGasVT.ToString(),
                NetOilVT = source.NetOilVT.ToString(),

                Vsh = source.Vsh.ToString(),
                Sw = source.AvgSw.ToString(),
                Por = source.AvgPor.ToString(),


                Tg = source.TG.ToString(),

                //MW

                //BG
                Fluid = source.Fluid,

                Remark = source.Remarks,
                EstPhase = source.EstPhase,
                Azi = source.AZI,

                DataSource = source.DataSource,
                CreatedDate = source.CreatedDate,

                UpdatedDate = source.SORUpdatedDate,

                Pos = source.Pos,



                // EndDate = currentSource.EndDate
            };

            return destination;
        }


        public Sand Mutate(Sand entity)
        {

            var drilled = entity;

            entity.OilP1DNWithBC = null;
            drilled.OilP1DNWithoutBC = null;
            drilled.LookupRenderingOilBCIncremental = null;
            drilled.InPlaceByVolumetricOOIP = null;
            drilled.DiscountFactorOilDepletion = null;
            drilled.RecoveryEfficiencyOil = null;
            drilled.FVFProfileBoValue = null;
            //entity.RecoveryEfficiencyOil = null;

            //gas
            drilled.FreeGasP1DNWithBC = null;
            drilled.FreeGasP1DNWithoutBC = null;
            drilled.InPlaceByVolumetricOGIP = null;
            drilled.DiscountFactorGasDepletion = null;
            drilled.RecoveryEfficiencyGas = null;
            drilled.FVFProfileBgValue = null;
            //entity.RecoveryEfficiencyGil = pp.GilRecoveryDF;

            drilled.CondensateP1DNWithBC = null;
            drilled.SolutionGasP1DNWithBC = null;

            drilled.HCGasWithBC = null;
            drilled.HCLiquidWithBC = null;

            return drilled;
        }


    }
}