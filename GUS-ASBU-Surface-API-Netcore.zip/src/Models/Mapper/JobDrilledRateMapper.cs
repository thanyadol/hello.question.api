using System; 



//model apis
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;
using surflex.netcore22.Model;
using surflex.netcore22.Models;


public class JobDrilledRateMapper : IMapper<JobDrilledAsync, JobDrilledRate>
{
    public JobDrilledRate Mapp(JobDrilledAsync entity)
    {
        var job = new JobDrilledRate
        {
            Id = entity.Id,
            WellName = entity.WellName,
            // Type = entity.Type,
            StartDate = entity.StartDate,
            EndDate = entity.EndDate,

            RateInDay = entity.RateInDay,
            RateInDepth = entity.RateInDepth,
            RateInHour = entity.RateInHour

        };

        return job;
    }

    public JobDrilledAsync Reverse(JobDrilledRate source)
    {
        var job = new JobDrilledAsync
        {
            Id = source.Id,
            WellName = source.WellName,
            // Type = source.Type,
            StartDate = source.StartDate,
            EndDate = source.EndDate,

            RateInDay = source.RateInDay,
            RateInDepth = source.RateInDepth,
            RateInHour = source.RateInHour

        };

        return job;
    }

    public JobDrilledRate Mutate(JobDrilledRate source)
    {
        throw new NotImplementedException();
    }
}