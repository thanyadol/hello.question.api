using System; 

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace surflex.netcore22.Models
{
    public abstract class BaseWellScenarioEdge
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        public Guid? ActivityId { get; set; }
        
        [StringLength(255)]
        public string Label { get; set; }

        [StringLength(50)]
        public string Payoff1 { get; set; }

        [StringLength(50)]
        public string Payoff2 { get; set; }

        [StringLength(50)]
        public string Probability { get; set; }
        
        public DateTime Created { get; set; }
    }

    public class PresetWellScenarioEdge : BaseWellScenarioEdge
    {
        public Guid FromId { get; set; }
        public PresetWellScenarioNode From { get; set; }

        public Guid ToId { get; set; }
        public PresetWellScenarioNode To { get; set; }
    }

    public class WellScenarioEdge : BaseWellScenarioEdge
    {
        public Guid FromId { get; set; }
        public WellScenarioNode From { get; set; }

        public Guid ToId { get; set; }
        public WellScenarioNode To { get; set; }
    }
}