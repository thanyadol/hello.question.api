using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace surflex.netcore22.Models
{
    public abstract class BaseWellScenarioNode
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        [StringLength(255)]
        public string Name { get; set; }

        [StringLength(50)]
        public string Type { get; set; }

        [Column(TypeName = "decimal(38, 4)")]
        public decimal X { get; set; }

        [Column(TypeName = "decimal(38, 4)")]
        public decimal Y { get; set; }
        
        public DateTime Created { get; set; }
    }

    public class PresetWellScenarioNode : BaseWellScenarioNode
    {
        public Guid ResourceId { get; set; }

        [ForeignKey("ResourceId")]
        public virtual PresetWellScenario Resource { get; set; }

        [InverseProperty("To")]
        public List<PresetWellScenarioEdge> InEdges { get; set; }

        [InverseProperty("From")]
        public List<PresetWellScenarioEdge> OutEdges { get; set; }
    }

    public class WellScenarioNode : BaseWellScenarioNode
    {
        public Guid ResourceId { get; set; }

        [ForeignKey("ResourceId")]
        public virtual WellScenario Resource { get; set; }

        [InverseProperty("To")]
        public List<WellScenarioEdge> InEdges { get; set; }

        [InverseProperty("From")]
        public List<WellScenarioEdge> OutEdges { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? AdditionalCost { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? TotalCost { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? TotalInMBOE { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? GasInMMScf { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? LiquidInMBOE { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? INV { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? NPV { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? DPI { get; set; }
    }
}