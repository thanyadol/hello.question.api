using System; 

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace surflex.netcore22.Models
{
    public abstract class BaseWellScenario
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        [StringLength(50)]
        public string Name { get; set; }

        [StringLength(255)]
        public string Description { get; set; }

        [StringLength(50)]
        public string Status { get; set; }

        [StringLength(255)]
        public string By { get; set; }

        [Column(TypeName = "datetime")]
        public DateTime? Created { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? Updated { get; set; }
    }

    public class PresetWellScenario : BaseWellScenario
    {

    }

    public class WellScenario : BaseWellScenario
    {
        [StringLength(255)]
        public string WellName { get; set; }

        public Guid ResourceId { get; set; }

        [ForeignKey("ResourceId")]
        public virtual PresetWellScenario Resource { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? NewTD { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? MotorDepth { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? CurrentDepth { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? TrippedDepth { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? CurrentROP { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? NewROP { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? MotorROP { get; set; }

        [StringLength(50)]
        public string Case { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? TIH { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? TOH { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? RigRate { get; set; }
    }

    public class WellScenarioTab
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid RevId { get; set; }

        public Guid TabId { get; set; }

        public Guid? MasterVersionId { get; set; }

        [ForeignKey("MasterVersionId")]
        public virtual WellScenarioTab MasterVersion { get; set; }

        public Guid WellScenarioId { get; set; }

        [ForeignKey("WellScenarioId")]
        public virtual WellScenario WellScenario { get; set; }

        [StringLength(255)]
        public string WellName { get; set; }

        [StringLength(50)]
        public string Status { get; set; }

        public bool IsDeleted { get; set; }

        [StringLength(255)]
        public string By { get; set; }

        [Column(TypeName = "datetime")]
        public DateTime? Created { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? Updated { get; set; }
    }
}