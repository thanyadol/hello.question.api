using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace surflex.netcore22.Models
{
    public class DecisionResultGroup
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        public Guid WellScenarioId { get; set; }

        [ForeignKey("WellScenarioId")]
        public virtual WellScenario WellScenario { get; set; }

        public Guid WellScenarioRevId { get; set; }

        public virtual WellScenarioTab WellScenarioTab { get; set; }

        [InverseProperty("DecisionGroup")]
        public virtual List<DecisionResult> Decisions { get; set; }

        [StringLength(1000)]
        public string Remark { get; set; }

        [StringLength(255)]
        public string By { get; set; }

        [Column(TypeName = "datetime")]
        public DateTime? Created { get; set; }
    }

    public class DecisionResult
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        public Guid DecisionGroupId { get; set; }

        [ForeignKey("DecisionGroupId")]
        public virtual DecisionResultGroup DecisionGroup { get; set; }

        public Guid DecisionOptionId { get; set; }

        [ForeignKey("DecisionOptionId")]
        public virtual DecisionOption DecisionOption { get; set; }

        public bool IsChosen { get; set; }

        [StringLength(1000)]
        public string Remark { get; set; }

        [Column(TypeName = "datetime")]
        public DateTime? Created { get; set; }
    }
    
    public class DecisionOption
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        public Guid WellScenarioId { get; set; }

        [ForeignKey("WellScenarioId")]
        public virtual WellScenario WellScenario { get; set; }

        public int Order { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? Inv { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? Npv { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? Dpi { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? TotalBranchCost { get; set; }

        [Column(TypeName = "datetime")]
        public DateTime? Created { get; set; }
    }
    
    public class DecisionOptionNode
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        public Guid DecisionOptionId { get; set; }

        [ForeignKey(nameof(DecisionOptionId))]
        public virtual DecisionOption DecisionOption { get; set; }

        public Guid? ParentId { get; set; }

        [ForeignKey("ParentId")]
        public virtual DecisionOptionNode Parent { get; set; }

        [StringLength(255)]
        public string Name { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal Inv { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal Npv { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal Dpi { get; set; }

        [Column(TypeName = "decimal(38, 18)")]
        public decimal? TotalBranchCost { get; set; }

        [Column(TypeName = "datetime")]
        public DateTime? Created { get; set; }
    }
}