using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace surflex.netcore22.Models
{
    [Serializable]
    public class WellDrilled
    {
        public WellDrilled()
        {
            //defualt
            Sands = new List<Sand>();
        }

        [Key]
        //  [StringLength(50)]
        public Guid Id { get; set; }

        [ForeignKey("WellSpace")]
        // [StringLength(50)]
        public Guid WellSpaceId { get; set; }

        [NotMapped]
        public string WellName { get; set; }

        [NotMapped]
        public string WellId { get; set; }



        [StringLength(50)]
        public string Key { get; set; }

        [StringLength(50)]
        public string Rev { get; set; }

        //for undrilled
        // public string CalculatedSelect { get; set; }

        //public string Value { get; set; }

        // public string Key { get; set; }

        //refrenece key to platform, COMPLETED, DRILLING, PLANNED
        //public string Rev { get; set; }

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<Decimal> CalculatedWellReserve { get; set; }

        [NotMapped]
        public string ActivityType { get; set; }

        [NotMapped]
        public Nullable<DateTime> ActivityDate { get; set; }

        [NotMapped]
        public bool IsPublisher { get; set; }



        public string Datasource { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> SORUpdatedDate { get; set; }

        //Type == "SAND"
        public string WellType { get; set; }

        //TYPE
        // public string Header { get; set; }
        [NotMapped]
        public string By { get; set; }

        [StringLength(10)]
        public string Status { get; set; }


        //[NotMapped]
        public int TotalCalculateRecord { get; set; }

        //[NotMapped]
        public string CalculatedTimestamp { get; set; }

        //[NotMapped]
        public int CompleteCalculatedRecord { get; set; }

        //public int Version { get; set; }
        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Created { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> StartDate { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> FinishDate { get; set; }


        [NotMapped]
        public List<Sand> Sands { get; set; }


        [NotMapped]
        public string PlatformName { get; set; }


        [NotMapped]
        public string ProjectName { get; set; }


        //  for platform ignored
        [Column(TypeName = "decimal(36, 18)")]
        public decimal? GOR { get; set; }

        [Column(TypeName = "decimal(36, 18)")]
        public decimal? CGR { get; set; }

        [Column(TypeName = "decimal(36, 18)")]
        public decimal? PipelinePressure { get; set; }

        [Column(TypeName = "decimal(36, 18)")]
        public decimal? BcPos { get; set; }

        [Column(TypeName = "decimal(36, 18)")]
        public decimal? BcCompressionRatio { get; set; }

        [Column(TypeName = "decimal(36, 18)")]
        public decimal? OilPipelinePressureCoeff { get; set; }

        [Column(TypeName = "decimal(36, 18)")]
        public decimal? GasPipelinePressureCoeff { get; set; }

    }
}

