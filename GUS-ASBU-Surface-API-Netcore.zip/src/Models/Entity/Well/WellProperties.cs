using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public partial class WellProperties
    {
        [Key]
        [StringLength(50)]
        public string Id { get; set; }

        [StringLength(50)]
        public string WellId { get; set; }

        [StringLength(50)]
        public string ProjectWellId { get; set; }

        [NotMapped]
        public string Name { get; set; }


        [StringLength(10)]
        public string FaultBlock { get; set; }


        public int? BatchNumber { get; set; }

        public int DrillingOrder { get; set; }
        public int? ChartOrder { get; set; }


        [StringLength(50)]
        public string Type { get; set; }


        [StringLength(50)]
        public string By { get; set; }


        [StringLength(1000)]
        public string Description { get; set; }

        // [StringLength(1000)]
        public bool IsIncludeToCalculated { get; set; }

        [Column(TypeName = "datetime")]
        public DateTime? Created { get; set; }

        [NotMapped]
        public bool IsSynceDatasource { get; set; }

        [NotMapped]
        public string Datasource { get; set; }

        [NotMapped]
        public DateTime? DatasourceDate { get; set; }

        [NotMapped]
        public DateTimeOffset DatasourceDateOffset { get; set; }

    }
}