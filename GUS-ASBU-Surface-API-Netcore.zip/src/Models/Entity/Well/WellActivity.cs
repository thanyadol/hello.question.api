using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class WellActivity
    {
        public WellActivity(Guid id, string disc, string action, string by)
        {
            this.WellSpaceId = id;
            this.Discriminator = disc.ToUpper();
            this.Action = action.ToUpper();
            this.By = by;

            Date = Helpers.Utility.CurrentSEAsiaStandardTime();
        }

        public WellActivity()
        {

        }


        [Key]
        // [StringLength(50)]
        public Guid Id { get; set; }

        [ForeignKey("WellSpace")]
        public Guid WellSpaceId { get; set; }

        [StringLength(50)]
        public string Discriminator { get; set; }  //SUMMARY



        [StringLength(50)]
        public string Action { get; set; } //SAVED, PUBLISHED

        [StringLength(50)]
        public string By { get; set; }



        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }

    }
}