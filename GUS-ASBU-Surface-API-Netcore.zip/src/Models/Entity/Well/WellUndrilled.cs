using System;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace surflex.netcore22.Models
{
    [Serializable]
    public class WellUndrilled
    {
        [Key]
        // [StringLength(50)]
        public Guid Id { get; set; }


        [ForeignKey("WellSpace")]
        //  [StringLength(50)]
        public Guid WellSpaceId { get; set; }

        //default
        //[NotMapped]
        public string CalculatedTimestamp { get; set; }


        public WellUndrilled()
        {
            this.IsValidate = false;
        }

        [StringLength(50)]
        public string WellName { get; set; }

        [StringLength(50)]
        public string UndrilledMethod { get; set; }

        [NotMapped]
        public string WellId { get; set; }


        [NotMapped]
        public string By { get; set; }

        [NotMapped]
        public bool IsPublisher { get; set; }


        [NotMapped]
        public string ProjectName { get; set; }

        [NotMapped]
        public Nullable<Decimal> CalculatedWellReserve { get; set; }


        public bool IsCalculatedReserve { get; set; }

        [Column(TypeName = "decimal(18, 10)")]
        public Nullable<decimal> LiquidInMBOE { get; set; }

        [Column(TypeName = "decimal(18, 10)")]
        public Nullable<decimal> GasInMMScf { get; set; }

        [Column(TypeName = "decimal(18, 10)")]
        public Nullable<decimal> TotalInMBOE { get; set; }

        [NotMapped]
        //is valid
        public bool IsValidate { get; set; }


        public string Datasource { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Created { get; set; }

        [StringLength(10)]
        public string Status { get; set; }

        [NotMapped]
        [Column(TypeName = "datetime")]
        public Nullable<DateTime> UpdatedDate { get; set; }

        [NotMapped]
        [Column(TypeName = "datetime")]
        public Nullable<DateTime> StartDate { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> FinishDate { get; set; }

        [NotMapped]
        public string ActivityType { get; set; }


        // [NotMapped]
        // public decimal PlannedLiquidRatio { get; set; }


        [NotMapped]
        public Nullable<DateTime> ActivityDate { get; set; }



        [StringLength(50)]
        public string Key { get; set; }

        [StringLength(50)]
        public string Rev { get; set; }
    }
}