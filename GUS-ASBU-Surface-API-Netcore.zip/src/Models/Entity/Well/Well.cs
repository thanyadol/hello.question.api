using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class Well
    {
        [StringLength(50)]
        public string Id { get; set; }

        [StringLength(100)]
        public string Name { get; set; }

        [StringLength(50)]
        public string ProjectId { get; set; }

        [StringLength(10)]
        public string Status { get; set; }


        //[NotMapped]
        //public string Phase { get; set; }

        [NotMapped]
        public string Activity { get; set; }

        [StringLength(50)]
        public string By { get; set; }

        //UIDM reference id
        //  public string UIDMReferenceId { get; set; }

        [NotMapped]
        public string RLLCPReferenceId { get; set; }

        [Column(TypeName = "datetime")]
        public DateTime? Created { get; set; }

    }
}