using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class WellSpace
    {
        [Key]
        //  [StringLength(50)]
        public Guid Id { get; set; }

        [StringLength(50)]

        [ForeignKey("Well")]
        public String WellId { get; set; }

        [NotMapped]
        public string WellName { get; set; }

        [StringLength(50)]
        //refrenece key to platform
        public string By { get; set; }

        [StringLength(1000)]
        public string Description { get; set; }

        //[StringLength(10)]
        //public string Status { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Created { get; set; }



        [NotMapped]
        public string ActivityType { get; set; }


        [NotMapped]
        public bool IsPublisher { get; set; }

        [NotMapped]
        public Nullable<DateTime> ActivityDate { get; set; }


    }
}