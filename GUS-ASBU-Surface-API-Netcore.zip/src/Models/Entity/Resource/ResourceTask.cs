using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class ResourceTask
    {
        [Key]
        [StringLength(50)]

        public string Id { get; set; }


        [StringLength(50)]
        [ForeignKey("Resource")]
        public string ResourceId { get; set; }


        [StringLength(50)]
        [ForeignKey("ResourceLibrary")]
        public string LibraryId { get; set; }



        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Created { get; set; }

    }
}