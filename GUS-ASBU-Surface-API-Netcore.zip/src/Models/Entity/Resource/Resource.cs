using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class Resource
    {
        [StringLength(50)]
        public string Id { get; set; }

        [StringLength(500)]
        public string Name { get; set; }


        [StringLength(10)]
        public string Type { get; set; }

        [StringLength(1000)]
        public string Description { get; set; }


        [StringLength(50)]
        public string Key { get; set; }



        [StringLength(50)]
        public string Rev { get; set; }


        [StringLength(50)]
        public string By { get; set; }


        [StringLength(10)]
        public string Status { get; set; }


        [Column(TypeName = "datetime")]

        public Nullable<DateTime> Created { get; set; }


        [NotMapped]
        public List<ResourceActivity> Tasks { get; set; }


        [NotMapped]
        public decimal? TotalCost { get; set; }


        [NotMapped]
        public decimal? TotalTime { get; set; }

    }
}