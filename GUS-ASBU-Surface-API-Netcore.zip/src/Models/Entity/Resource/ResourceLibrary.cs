using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class ResourceLibrary
    {
        [Key]
        [StringLength(50)]
        public string Id { get; set; }



        //[NotMapped]
        [StringLength(550)]
        public string Formular { get; set; }

        //[NotMapped]
        [StringLength(50)]
        public string ResourceType { get; set; }



        //[NotMapped]
        [StringLength(500)]
        public string QueryParam { get; set; }



        [StringLength(50)]
        public string Key { get; set; }


        [StringLength(50)]
        public string Rev { get; set; }


        [StringLength(100)]
        public string Name { get; set; }

        [StringLength(20)]
        public string ValueType { get; set; }

        [Column(TypeName = "decimal(28,10)")]
        public Nullable<decimal> Value { get; set; }

        [StringLength(20)]
        public string PlannerType { get; set; }

        //refrenece key to platform

        [StringLength(20)]
        public string Section { get; set; }


        [StringLength(20)]
        public string Type { get; set; }


        public bool IsReadonly { get; set; }


        [StringLength(500)]
        public string Description { get; set; }


        [StringLength(50)]
        public string By { get; set; }


        [StringLength(10)]
        public string Status { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Created { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> StartDate { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> FinishDate { get; set; }


    }
}