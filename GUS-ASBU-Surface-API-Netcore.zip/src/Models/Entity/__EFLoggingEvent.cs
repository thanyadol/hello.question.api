using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class __EFLoggingEvent
    {
        [Key]
        public Guid Id { get; set; }
        //public string UserId { get; set; }
        [MaxLength(128)]
        public string Level { get; set; }

        public DateTimeOffset TimeStamp { get; set; }


        public string CAI { get; set; }
        public string Message { get; set; }

        public string MessageTemplate { get; set; }


        public string Exception { get; set; }

        //  public string LogEvent { get; set; }

        // public Guid EventId { get; set; }
        [MaxLength(20)]
        public string Type { get; set; }

        // public Guid ActionId { get; set; }

        //public string ActionName { get; set; }
        public string ErrorCode { get; set; }

        public Guid RequestId { get; set; }

        [MaxLength(500)]
        public string RequestPath { get; set; }

        [MaxLength(500)]
        public string RequestScheme { get; set; }

        [MaxLength(50)]
        public string By { get; set; }

        public DateTime Date { get; set; }
    }
}