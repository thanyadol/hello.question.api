using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class Platform
    {
        [StringLength(50)]
        public string Id { get; set; }

        //  [StringLength(50)]
        // public Guid WellDrilledId { get; set; }


        [StringLength(100)]
        public string Name { get; set; }

        [NotMapped]
        public string WellType { get; set; }

        //refrenece key to platform
        [StringLength(20)]
        public string Country { get; set; }

        [StringLength(100)]
        public string Description { get; set; }

        [StringLength(10)]
        public string Status { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Created { get; set; }

        [NotMapped]
        public decimal? GOR { get; set; }

        [NotMapped]
        public decimal? CGR { get; set; }

        [NotMapped]
        public decimal? PipelinePressure { get; set; }
        [NotMapped]
        public decimal? BcPos { get; set; }
        [NotMapped]
        public decimal? BcCompressionRatio { get; set; }
        [NotMapped]
        public decimal? OilPipelinePressureCoeff { get; set; }
        [NotMapped]
        public decimal? GasPipelinePressureCoeff { get; set; }

    }
}