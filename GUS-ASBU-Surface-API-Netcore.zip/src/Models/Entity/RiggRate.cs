using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class RiggRate
    {
        [Key]
        [StringLength(50)]
        public string Id { get; set; }

        [ForeignKey("Rigg")]
        [StringLength(50)]
        public string RiggId { get; set; }

        [NotMapped]
        public string RiggName { get; set; }

        [StringLength(50)]
        public string TemplateId { get; set; }

        //public string Name { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        public decimal TIH { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal TOH { get; set; }

        [StringLength(10)]
        //PRICE, DRILLING
        public string Type { get; set; }

        [StringLength(50)]
        public string By { get; set; }

        [StringLength(100)]
        public string Activity { get; set; }

        // public string Status { get; set; }
        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Created { get; set; }

    }
}