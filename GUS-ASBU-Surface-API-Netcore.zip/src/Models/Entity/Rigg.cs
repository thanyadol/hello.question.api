using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class Rigg
    {
        public Rigg()
        {

        }

        public Rigg(string name) //, string ti, string to)
        {
            this.Name = name;
            //this.TIHRate = ti;
            //this.TOHRate = to;
        }

        [Key]
        [StringLength(50)]
        public string Id { get; set; }

        [StringLength(100)]
        public string Name { get; set; }
        //  public string TIHRate { get; set; }
        //  public string TOHRate { get; set; }
        //PRICE, DRILLING
        [StringLength(10)]
        public string Type { get; set; }

        [NotMapped]
        public List<RiggRate> RiggRates { get; set; }

        [StringLength(50)]
        public string By { get; set; }

        [StringLength(1000)]
        public string Description { get; set; }

        [StringLength(10)]
        public string Status { get; set; }

        [Column(TypeName = "datetime")]
        public DateTime? Created { get; set; }

    }
}