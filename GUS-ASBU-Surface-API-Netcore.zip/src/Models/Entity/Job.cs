using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{

    //a history
    public class Job
    {
        [StringLength(50)]
        public string Id { get; set; }
        [StringLength(50)]
        public string WellId { get; set; }

        //refrenece key to platform, COMPLETED, DRILLING, PLANNED
        [StringLength(10)]
        public string Status { get; set; }
        [StringLength(10)]
        public string Type { get; set; }
        //public string End { get; set; }
        [StringLength(10)]
        public string Activity { get; set; }

        [NotMapped]
        public Nullable<decimal> TargetDepth { get; set; }
        [NotMapped]
        public Nullable<decimal> TotalDepthCalculate { get; set; }
        [NotMapped]
        public Nullable<decimal> TotalDepthTVDCalculate { get; set; }

        //for rig moved cost
        [NotMapped]
        public Nullable<decimal> AFTAmountCalculate { get; set; }



        [NotMapped]
        public Nullable<decimal> TotalCostCalculate { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Created { get; set; }

        [NotMapped]
        public string WellName { get; set; }

        [NotMapped]
        public Nullable<DateTime> StartDate { get; set; }
        [NotMapped]
        public Nullable<DateTime> EndDate { get; set; }
    }
}