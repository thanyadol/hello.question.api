

using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class Production
    {

        [StringLength(50)]
        public string Id { get; set; }

        // public decimal Value { get; set; }
        [StringLength(100)]
        public string Name { get; set; }


        [StringLength(100)]
        public string Asset { get; set; }


        [StringLength(50)]
        public string Condition { get; set; }


        //[IgnorDataMember]
        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Created { get; set; }


        [StringLength(50)]
        public string By { get; set; }


        [StringLength(50)]
        public string Key { get; set; }



        [StringLength(50)]
        public string Rev { get; set; }



        [StringLength(10)]
        public string Status { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> StartDate { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> FinishDate { get; set; }


        [NotMapped]
        public ProductionProfile GasProfile { get; set; } //OVERALL

        [NotMapped]
        public ProductionProfile OilProfile { get; set; } //OVERALL


        // [StringLength(50)]
        public bool IsGasModelApplicable { get; set; }
        public bool IsOilModelApplicable { get; set; }
        public bool IsSeparateModelApplicable { get; set; }



    }

}