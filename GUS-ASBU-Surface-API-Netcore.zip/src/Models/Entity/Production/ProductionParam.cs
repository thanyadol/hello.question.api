

using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class ProductionParam
    {

        [StringLength(50)]
        public string Id { get; set; }
        // public decimal Value { get; set; }

        [StringLength(50)]
        public string ProductionProfileId { get; set; }
        // public decimal Value { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? Value { get; set; }

        [StringLength(10)]
        public string Name { get; set; }


        [NotMapped]
        public Dictionary<string, decimal?> Params { get; set; }


    }

}