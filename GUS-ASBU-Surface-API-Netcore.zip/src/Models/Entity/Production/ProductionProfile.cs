

using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using surflex.netcore22.APIs.Gateway;

namespace surflex.netcore22.Models
{

    //separate oil /gas record
    public partial class ProductionProfile
    {
        public ProductionProfile()
        {
            Params = new List<ProductionParam>();
            Value = null;
        }

        [NotMapped]
        public List<ProductionParam> Params { get; set; }  //FIXED, VARIABLE


        [Key]
        [StringLength(50)]
        public string Id { get; set; }

        [StringLength(50)]
        public string ProductionId { get; set; } //OVERALL



        [StringLength(50)]
        public string EVFormulaForIPCDRATE { get; set; }

        //rate for oil
        [Column(TypeName = "decimal(18,1)")]
        public decimal? Value { get; set; }  //FIXED, VARIABLE



        [Column(TypeName = "decimal(18,2)")]
        public decimal? AbandonmentRate { get; set; }  //FIXED, VARIABLE

        [Column(TypeName = "decimal(18,2)")]
        public decimal? HoldupPercentage { get; set; }  //FIXED, VARIABLE


        //[NotMapped]
        //  public decimal? Reserve { get; set; }  //FIXED, VARIABLE

        [NotMapped]
        public decimal? OilReserve { get; set; }  //FIXED, VARIABLE

        [NotMapped]
        public decimal? GasReserve { get; set; }  //FIXED, VARIABLE

        //  [NotMapped]
        //    public int WellCount { get; set; }  //FIXED, VARIABLE



        [StringLength(10)]
        public string ValueType { get; set; }


        [StringLength(10)]
        public string ApplicableModel { get; set; }



        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Created { get; set; }


        [StringLength(50)]
        public string By { get; set; }
    }

}