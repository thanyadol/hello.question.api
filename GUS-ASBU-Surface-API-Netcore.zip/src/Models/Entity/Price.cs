

using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class Price
    {
        public Price()
        {
            Prices = new List<PeriodPrice>();
        }

        [Key]
        //[StringLength(50)]
        public Guid Id { get; set; }
        // public decimal Value { get; set; }
        [StringLength(100)]
        public string Name { get; set; }

        [StringLength(10)]
        public string HcType { get; set; }


        [StringLength(50)]
        public string AreaId { get; set; } //OVERALL

        public string Unit { get; set; }


        public string Type { get; set; }

        [StringLength(1000)]
        public string Description { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Created { get; set; }


        [StringLength(50)]
        public string By { get; set; }

        //LOW, MID, HIGHT, SENSITIVITY
        [StringLength(100)]
        public string Structure { get; set; }


        [StringLength(10)]
        public string Status { get; set; }
        //    public Nullable<DateTime> StartDate { get; set; }
        //   public Nullable<DateTime> FinishDate { get; set; }


        [StringLength(50)]
        public string TemplateId { get; set; }

        [NotMapped]
        public List<PeriodPrice> Prices { get; set; }
    }

}