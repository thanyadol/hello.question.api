using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class Area
    {
        public Area()
        {

        }

        public Area(string name, string hctype, string type)
        {
            this.Name = name;
            this.HcType = hctype;
            this.Type = type;
        }

        [Key]
        [StringLength(50)]
        public string Id { get; set; }

        [StringLength(100)]
        public string Name { get; set; }


        [StringLength(10)]
        public string HcType { get; set; }


        [StringLength(10)]
        public string Type { get; set; }


        [StringLength(50)]
        public string By { get; set; }


        [StringLength(50)]
        public string Description { get; set; }

        [StringLength(10)]
        public string Status { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Created { get; set; }

    }
}