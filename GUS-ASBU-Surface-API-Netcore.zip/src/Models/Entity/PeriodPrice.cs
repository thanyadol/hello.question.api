

using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class PeriodPrice
    {
  
        [Key]
        public Guid Id { get; set; }
        //public decimal Value { get; set; }

 
        [ForeignKey("Price")]
        public Guid PriceId { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal Value { get; set; }

        // public decimal Year { get; set; }

        //LOW, MID, HIGHT, SENSITIVITY
        public int Year { get; set; }

        public int? Month { get; set; }

        [NotMapped]
        public DateTime? CurrentDate { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Created { get; set; }

        [StringLength(50)]
        public string By { get; set; }

    }

}