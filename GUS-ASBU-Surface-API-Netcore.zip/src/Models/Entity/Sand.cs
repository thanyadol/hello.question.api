
using System; 

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace surflex.netcore22.Models
{
    [Serializable]
    public class Sand
    {
        //[Key]
        // [StringLength(50)]
        [ForeignKey("WellDrilled")]
        public Guid WellDrilledId { get; set; }

        [Key]
        // [StringLength(50)]
        public Guid Id { get; set; }

        public Sand()
        {
            this.IsValidate = false;
        }

        [NotMapped]

        public string WellName { get; set; }


        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> TopMD { get; set; }


        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> BaseMD { get; set; }


        [Column(TypeName = "decimal(18, 2)")]
        public decimal? Pos { get; set; }

        //TCRS
        [StringLength(50)]
        public string Usi { get; set; }

        [StringLength(20)]
        public string Iwd { get; set; }

        //Ow GAS / OIL
        [StringLength(10)]
        public string OpenWorksContactCategory { get; set; }

        [StringLength(20)]
        public string Name { get; set; }

        [StringLength(5)]
        public string SandReserveCategory { get; set; }

        [StringLength(10)]
        public string Status { get; set; }


        [NotMapped]
        public bool IsTCRSCompletedCalculated { get; set; }


        /*
        * from TCRS
        *
         */

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> OilP1DNWithoutBC { get; set; } //in MSTB

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> OilP1DNWithBC { get; set; } //in MSTB

        [Column(TypeName = "decimal(36, 18)")]                                                     // public Nullable<decimal> OilP1DNwoBC { get; set; } //in MSTB
        public Nullable<decimal> CondensateP1DNWithBC { get; set; } //in MSTB

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> FreeGasP1DNWithoutBC { get; set; } //in MMSCF

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> FreeGasP1DNWithBC { get; set; } //in MMSCF

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> SolutionGasP1DNWithBC { get; set; } //in MMSCF

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> HCLiquidWithBC { get; set; } // in MSTB

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> HCGasWithBC { get; set; } // in MSTB

        [StringLength(20)]
        public string PayClassification { get; set; } // in MSTB

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> PressureRFTInPSI { get; set; } //in psi

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> PressureRFTInPPG { get; set; } //in PPG

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> PressureEstimatedInitialInPSI { get; set; } //in psi

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> PressureEstimatedInitialInPPG { get; set; } //in PPG

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> PressurePPi { get; set; }


        public string FVFProfileBoProfile { get; set; }
        public string FVFProfileBgProfile { get; set; }

        //id
        public Nullable<int> FVFProfileBoProfileId { get; set; }
        public Nullable<int> FVFProfileBgProfileId { get; set; }

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> FVFProfileBoValue { get; set; }

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> FVFProfileBgValue { get; set; }


        public Nullable<int> AnalogyOilAreaScenarioId { get; set; }
        public Nullable<int> AnalogyGasAreaScenarioId { get; set; }


        public Nullable<int> AnalogyOilAreaSetId { get; set; }
        public Nullable<int> AnalogyGasAreaSetId { get; set; }

        [StringLength(500)]
        public string AnalogyOilAreaName { get; set; }

        [StringLength(500)]
        public string AnalogyOilAreaDiscountFactor { get; set; }

        [StringLength(500)]
        public string AnalogyGasAreaName { get; set; }

        [StringLength(500)]
        public string AnalogyGasAreaDiscountFactor { get; set; }

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> AnalogyOilArea { get; set; } //Acres

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> AnalogyGasArea { get; set; } //Acres


        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> DiscountFactorOilDepletion { get; set; } //FRACTION

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> DiscountFactorGasDepletion { get; set; } //FRACTION

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> DiscountFactorMechanical { get; set; } //FRACTION

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> DiscountFactorCementQuality { get; set; } //FRACTION

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> DiscountFactorCO2 { get; set; } //FRACTION

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> DiscountFactorBC { get; set; } //FRACTION

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> InPlaceByVolumetricOOIP { get; set; } //MSTB

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> InPlaceByVolumetricOGIP { get; set; } //MMSCF


        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> RecoveryEfficiencyOil { get; set; } //fraction

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> RecoveryEfficiencyGas { get; set; } //fraction


        /*
        * from OpenWorks
        *
         */

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> GrossIntervalFrom { get; set; } //(MD ft)

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> GrossIntervalTo { get; set; } //(MD ft)

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> TopTVDSS { get; set; }  //(TVDSS ft)

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> BaseTVDSS { get; set; }  //(TVDSS ft)



        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> GocTVDSS { get; set; }  //(TVDSS ft)

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> HwcTVDSS { get; set; }  //(TVDSS ft)

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> GrossSandMT { get; set; }// MT(ft)

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> GrossSandVT { get; set; } //(ft)

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> NetGasVT { get; set; } //(VT ft)

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> NetOilVT { get; set; } //(VT ft)

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> MaximumResistivity { get; set; }

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> Vsh { get; set; }

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> AvgPor { get; set; } //(fraction)

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> AvgSw { get; set; } //(fraction)

        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> TG { get; set; }  //(U)


        [StringLength(10)]
        public string Fluid { get; set; }


        [StringLength(1000)]
        public string Remarks { get; set; }


        [StringLength(10)]
        public string AZI { get; set; }


        /*
        * from TCRS
        *
        */


        [StringLength(10)]
        public string LookupRenderingOilRF { get; set; }//(%)  


        [StringLength(10)]
        public string LookupRenderingGasRF { get; set; }//(%)


        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> LookupRenderingOilBCIncremental { get; set; }//(MSTB)  


        [Column(TypeName = "decimal(36, 18)")]
        public Nullable<decimal> LookupRenderingGasBCIncremental { get; set; }//(MMSCF)  


        [StringLength(10)]
        public string EstPhase { get; set; }


        //is valid
        public bool IsValidate { get; set; }


        [StringLength(1000)]
        public string ErrorMessage { get; set; }


        [StringLength(20)]
        public string DataSource { get; set; }

        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }

        [Column(TypeName = "datetime")]
        public DateTime? SORUpdatedDate { get; set; }
    }
}