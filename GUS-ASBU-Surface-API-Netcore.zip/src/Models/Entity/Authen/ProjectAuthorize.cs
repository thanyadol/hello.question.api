using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace surflex.netcore22.Models
{
    public class ProjectAuthorize
    {
        [Key]
        public Guid Id { get; set; }

        //  [StringLength(100)]
        [ForeignKey("Project")]
        [StringLength(50)]
        public string ProjectId { get; set; }

        [ForeignKey("User")]
        [StringLength(50)]
        public string UserId { get; set; }




        [NotMapped]
        public string ProjectName { get; set; }

        [NotMapped]
        public string LocationId { get; set; }

        [NotMapped]
        public string DisplayName { get; set; }
        [NotMapped]
        public string Email { get; set; }


        [NotMapped]
        public string CAI { get; set; }

        [NotMapped]
        public string EntityState { get; set; }

        [StringLength(10)]
        public string Status { get; set; } //ACTIVE, ARCHIVED


        [StringLength(50)]
        public string By { get; set; }


        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }


        //for page not maaped
        //  [NotMapped]
        //  [ForeignKey("Role")]
        //[NotMapped]
        [JsonIgnore]
        public virtual Project Project { get; set; }

        //  [NotMapped]
        // [ForeignKey("User")]
        //  [NotMapped]
        [JsonIgnore]
        public virtual User User { get; set; }

    }
}