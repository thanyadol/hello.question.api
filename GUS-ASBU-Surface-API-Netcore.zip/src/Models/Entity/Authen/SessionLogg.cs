using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class SessionLogg
    {


        [Key]
        // [StringLength(50)]
        public Guid Id { get; set; }



        [StringLength(1000)]
        public string Token { get; set; }  //LOGIN or ADMIN



        [StringLength(50)]
        public string UserId { get; set; } //SAVED, PUBLISHED

        [StringLength(10)]
        public string CAI { get; set; }


        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }


        [Column(TypeName = "datetime")]
        public DateTime? TokenExpiredDate { get; set; }

    }
}