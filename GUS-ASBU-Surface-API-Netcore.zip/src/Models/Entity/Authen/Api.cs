using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class Api
    {

        [Key]
        //   [StringLength(50)]
        public Guid Id { get; set; }


        [StringLength(500)]
        public string Url { get; set; }


        [StringLength(500)]
        public string Endpoint { get; set; }

        [StringLength(500)]
        public string Params { get; set; }



        [StringLength(10)]
        public string Type { get; set; }  //POST GET PUT


        // [StringLength(10)]
        // public string Status { get; set; }


        public bool IsRequireAuthentication { get; set; }


        [StringLength(500)]
        public string Description { get; set; }


        [Column(TypeName = "datetime")]
        public DateTime? Created { get; set; }


    }
}