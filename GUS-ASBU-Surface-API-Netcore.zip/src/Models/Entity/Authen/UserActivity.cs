using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class UserActivity
    {


        [Key]
        // [StringLength(50)]
        public Guid Id { get; set; }



        [StringLength(50)]
        public string Discriminator { get; set; }  //LOGIN or ADMIN



        [StringLength(50)]
        public string Action { get; set; } //SAVED, PUBLISHED

        [StringLength(50)]
        public string By { get; set; }



        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }

    }
}