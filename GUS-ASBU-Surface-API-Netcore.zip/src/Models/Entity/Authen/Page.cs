using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace surflex.netcore22.Models
{
    public class Page
    {
        [Key]
        public virtual Guid Id { get; set; }

        [ForeignKey("Page")]
        public Guid? Parent { get; set; }


        [StringLength(100)]
        public string Title { get; set; }

        [StringLength(20)]
        public string Sub { get; set; }

        [StringLength(100)]
        public string Url { get; set; }

        [StringLength(100)]
        public string Params { get; set; }

        public int Order { get; set; }


        [StringLength(10)]
        public string Type { get; set; }  //dev, eng, addmin, support, staff, outsource


        [StringLength(500)]
        public string Description { get; set; }

        //  public bool IsEnabled { get; set; }

        public bool IsRequireAuthentication { get; set; }


        [Column(TypeName = "datetime")]
        public DateTime? Created { get; set; }


        //   [InverseProperty("From")]
        // [NotMapped]
        //  [JsonProperty(PropertyName = "apis")]
        public virtual ICollection<PageApi> PageApis { get; set; }

        [NotMapped]
        public IEnumerable<Api> APIs { get; set; }


        [NotMapped]
        public string Permission { get; set; }

        //  [NotMapped]
        // [JsonIgnore]
        // public virtual ICollection<ModulePage> ModulePages { get; set; }

    }
}