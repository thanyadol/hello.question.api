using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace surflex.netcore22.Models
{
    public class RoleModule
    {
        [Key]
        public Guid Id { get; set; }

        //  [StringLength(100)]
        [ForeignKey("Role")]
        public Guid RoleId { get; set; }

        [ForeignKey("Module")]
        public Guid ModuleId { get; set; }


        [StringLength(50)]
        public string By { get; set; }

        public bool IsEnabled { get; set; }


        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }


        [StringLength(10)]
        public string ProjectPermission { get; set; }  //READ, WRITE, FULL, NONE


        [StringLength(10)]
        public string RolePermission { get; set; }  //READ, WRITE, FULL, NONE




        //for page not maaped
        [JsonIgnore]
        // [NotMapped]
        public virtual Role Role { get; set; }

        // [NotMapped]
        [JsonIgnore]
        public virtual Module Module { get; set; }

    }
}