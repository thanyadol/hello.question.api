using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace surflex.netcore22.Models
{
    public class RoleAuthorize
    {
        [Key]
        public Guid Id { get; set; }


        // [Key]
        //[Column(Order = 1)]
        [ForeignKey("Role")]
        public virtual Guid RoleId { get; set; }

        //[Key]
        //  [Column(Order = 2)]
        [ForeignKey("User")]
        [StringLength(50)]
        public virtual string UserId { get; set; }


        [NotMapped]
        public string RoleName { get; set; }


        [NotMapped]
        public string CAI { get; set; }



        [NotMapped]
        public string DisplayName { get; set; }


        [NotMapped]
        public string LocationId { get; set; }

        [NotMapped]
        public string EntityState { get; set; }

        [StringLength(10)]
        public string Status { get; set; } //ACTIVE, ARCHIVED

        [StringLength(50)]
        public string By { get; set; }


        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }


        //for page not maaped
        //  [NotMapped]
        //  [ForeignKey("Role")]
        //[NotMapped]
        [JsonIgnore]
        public virtual Role Role { get; set; }

        //  [NotMapped]
        // [ForeignKey("User")]
        //  [NotMapped]
        [JsonIgnore]
        public virtual User User { get; set; }


        [NotMapped]
        public IEnumerable<RoleModule> Modules { get; set; }


    }
}