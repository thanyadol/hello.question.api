using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class UserAuthen
    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("User")]
        [StringLength(50)]
        public string UserId { get; set; }


        [NotMapped]
        public string UserName { get; set; }
        [NotMapped]
        public string Email { get; set; }

        [NotMapped]
        //[StringLength(50)]
        public string CAI { get; set; }

        public bool IsEnabled { get; set; } //ACTIVE, ARCHIVED

        public string Status { get; set; } //ACTIVE, ARCHIVED

        [StringLength(50)]
        public string By { get; set; }


        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }


        [Column(TypeName = "datetime")]
        public DateTime? ExpiredDate { get; set; }

    }
}