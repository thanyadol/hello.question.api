using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace surflex.netcore22.Models
{
    public class Role
    {
        public Role()
        {
            //this.Users = new HashSet<User>();
        }

        [Key]
        public virtual Guid Id { get; set; }

        [StringLength(100)]
        public string Name { get; set; }


        [StringLength(50)]
        public string LocationId { get; set; }

        [StringLength(50)]
        public string By { get; set; }


        [StringLength(10)]
        public string Type { get; set; }  //dev, eng, addmin, support, staff, outsource


        [StringLength(500)]
        public string Description { get; set; }



        [Column(TypeName = "datetime")]
        public DateTime? Created { get; set; }

        // [NotMapped]
        //  [NotMapped]
        //  [JsonIgnore]
        //  public virtual ICollection<User> Users { get; set; }
        // [NotMapped]
        // public virtual ICollection<RoleAuthorize> Authorizes { get; set; }



        [NotMapped]
        public IEnumerable<Module> Modules { get; set; }



        // [NotMapped]
        public virtual ICollection<RoleModule> RoleModules { get; set; }



    }
}