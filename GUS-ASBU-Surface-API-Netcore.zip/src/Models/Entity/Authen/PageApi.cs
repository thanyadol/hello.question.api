using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace surflex.netcore22.Models
{
    public class PageApi
    {

        public Guid Id { get; set; }

        //  [StringLength(100)]
        [ForeignKey("Page")]
        public Guid PageId { get; set; }

        [ForeignKey("Api")]
        public Guid ApiId { get; set; }


        [StringLength(50)]
        public string By { get; set; }

        [StringLength(50)]
        public string WorkFlow { get; set; }


        public bool IsEnabled { get; set; }

        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }


        //for page not maaped
        //  [NotMapped]
        [JsonIgnore]
        public virtual Page Page { get; set; }

        //   [NotMapped]
        [JsonIgnore]
        public virtual Api Api { get; set; }




    }
}