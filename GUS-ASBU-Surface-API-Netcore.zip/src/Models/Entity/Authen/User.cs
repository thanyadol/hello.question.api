using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class User
    {

        public User()
        {
            //  this.Roles = new HashSet<Role>();
        }

        public Guid ADId { get; set; }

        [Key]
        [StringLength(50)]
        public virtual string Id { get; set; }

        [StringLength(50)]
        public string By { get; set; }

        [StringLength(50)]
        public string CAI { get; set; }
        //public Clan Clan { get; set; }

        [StringLength(100)]
        public string DisplayName { get; set; }

        [StringLength(100)]
        public string GivenName { get; set; }

        [StringLength(100)]
        public string AccountName { get; set; }

        [StringLength(200)]
        public string Name { get; set; }

        //[StringLength(20)]
        //public string Mobile { get; set; }

        [StringLength(50)]
        public string Unique { get; set; }

        [NotMapped]
        public int[] Base64EncryptionKey { get; set; }


        [StringLength(100)]
        public string Email { get; set; }

        // public string Asset { get; set; }
        //  [StringLength(10)]
        // public string Status { get; set; }

        [StringLength(50)]
        public string EmployeeId { get; set; }
        public bool IsADEnable { get; set; }

        [StringLength(50)]
        public string ADGroup { get; set; }

        // public string Role { get; set; }

        //  [NotMapped]
        // public IEnumerable<string> Assets { get; set; } = new string[] { };


        public virtual ICollection<RoleAuthorize> RoleAuthorizes { get; set; }

        public virtual ICollection<UserAuthen> UserAuthens { get; set; }


        [Column(TypeName = "datetime")]
        public DateTime? Created { get; set; }

        // gatway
        [NotMapped]
        public UserAuthen Authen { get; set; }


        [NotMapped]
        public SessionLogg LastLogin { get; set; }


        [NotMapped]
        public IEnumerable<Project> Projects { get; set; }



        // [NotMapped]
        //public IEnumerable<Models.Role> Roles { get; set; }


        //public virtual UserAuthen Authens { get; set; }

        [NotMapped]
        public string Token { get; set; }




        [NotMapped]
        public DateTime? TokenExpiredDate { get; set; }


        // [NotMapped]
        //  public IEnumerable<Role> Roles { get; set; }

        [NotMapped]

        public IEnumerable<Page> Pages { get; set; }


        // [NotMapped]
        //public virtual ICollection<RoleAuthorize> Authorizes { get; set; }

        [NotMapped]
        public virtual ICollection<Module> Modules { get; set; }

        // [NotMapped]
        // public DateTime? ExpiredDate { get; set; }


    }
}