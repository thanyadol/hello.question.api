using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class Template
    {
        [Key]
        [StringLength(50)]
        public string Id { get; set; }

        [StringLength(50)]
        public string AttachmentId { get; set; }

        [StringLength(500)]
        public string Name { get; set; }




        [NotMapped]
        public string Level { get; set; }



        [NotMapped]
        public string TemplateTypeDisplay { get; set; }



        [NotMapped]
        public string LastActiveTemplateIdForRollback { get; set; }

        [StringLength(1000)]
        public string Description { get; set; }

        [StringLength(50)]
        public string TemplateTypeId { get; set; }

        [StringLength(10)]
        public string Status { get; set; }


        [Column(TypeName = "datetime")]
        public DateTime? Created { get; set; }

        [StringLength(50)]

        public string Key { get; set; }

        [StringLength(50)]

        public string Rev { get; set; }

        [StringLength(50)]

        public string By { get; set; }


        [Column(TypeName = "datetime")]
        public DateTime? StartDate { get; set; }



        [Column(TypeName = "datetime")]
        public Nullable<DateTime> FinishDate { get; set; }

    }
}