using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public partial class ProjectWell
    {
        [StringLength(50)]
        public string Id { get; set; }


        [StringLength(50)]
        public string Key { get; set; }

        [StringLength(50)]
        public string Rev { get; set; }


        [StringLength(50)]
        public string ProjectSpaceId { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> StartDate { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> FinishDate { get; set; }
    }
}