using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class ProjectActivity
    {
        public ProjectActivity(string id, string type, string action, string by)
        {
            this.ProjectSpaceId = id;
            this.Discriminator = type.ToUpper();
            this.Action = action.ToUpper();
            this.By = by;
        }

        public ProjectActivity()
        {

        }


        [Key]
        [StringLength(50)]
        public string Id { get; set; }

        [StringLength(50)]
        public string ProjectSpaceId { get; set; }

        [StringLength(50)]
        public string Discriminator { get; set; }  //SUMMARY



        [StringLength(50)]
        public string Action { get; set; } //SAVED, PUBLISHED

        [StringLength(50)]
        public string By { get; set; }



        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }

    }
}