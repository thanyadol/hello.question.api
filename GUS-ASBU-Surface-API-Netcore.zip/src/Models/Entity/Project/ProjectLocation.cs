using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models

{
    public class ProjectLocation
    {
        [Key]
        public virtual Guid Id { get; set; }


        //  [Column(Order = 0)]
        [ForeignKey("Project")]

        [StringLength(50)]
        public virtual string ProjectId { get; set; }

        // [Key]
        // [Column(Order = 1)]
        //   [ForeignKey("Page")]
        [StringLength(50)]
        public virtual string LocationId { get; set; }


        [StringLength(50)]
        public string By { get; set; }


        [StringLength(10)]
        public string Status { get; set; }



        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }



        //for page not maaped
        [NotMapped]
        public virtual string LocationName { get; set; }

        [NotMapped]
        public virtual string ProjectName { get; set; }

        [NotMapped]
        public virtual string Name { get; set; }

        [NotMapped]
        public virtual int RLLCPProjectId { get; set; }


        [NotMapped]
        public virtual int RLLCReferenceId { get; set; }




    }
}