using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace surflex.netcore22.Models
{
    public class Project
    {
        [Key]
        [StringLength(50)]
        public string Id { get; set; }


        [StringLength(20)]
        public string Name { get; set; }

        //refrenece key to platform
        // public string PlatformId { get; set; }

        [NotMapped]
        public string PlatformName { get; set; }

        public Nullable<int> RLLCPReferenceId { get; set; }


        public string Status { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Created { get; set; }

        // [JsonIgnore]
        public virtual ICollection<ProjectAuthorize> ProjectAuthorizes { get; set; }

        ///////gateway



        public string Description { get; set; }

        [NotMapped]
        public string LocationId { get; set; }




        // [NotMapped]
        // public IEnumerable<User> Users { get; set; }

        [NotMapped]
        public ProjectLocation CurrentLocation { get; set; }


        [NotMapped]
        public bool IsPersistedSURFACE { get; set; }

        [NotMapped]
        public string Permission { get; set; }

    }


}