using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class ProjectAttribute
    {
        [Key]
        [StringLength(50)]
        public string Id { get; set; }

        [ForeignKey("Project")]
        [StringLength(50)]
        public string ProjectId { get; set; }


        /* 
        [StringLength(50)]
        public string OilPriceAreaId { get; set; }


        [StringLength(50)]
        public string GasPriceAreaId { get; set; }



        public Nullable<int> FEYear { get; set; }
        public Nullable<int> ITTPYear { get; set; }
        public Nullable<int> AbandonYear { get; set; }


        [Column(TypeName = "decimal(18,2)")]
        public Nullable<decimal> AbandonCost { get; set; }*/



        [NotMapped]
        public string ProjectName { get; set; }


        //  [NotMapped]
        // public int RLLCPProjectId { get; set; }


        //refrenece key to platform
        public Nullable<int> BgProfileId { get; set; }

        public Nullable<int> BoProfileId { get; set; }


        /* [Column(TypeName = "decimal(18,2)")]
        public Nullable<decimal> FECost { get; set; }


        [Column(TypeName = "decimal(18,2)")]
        public Nullable<decimal> ITTPCost { get; set; }*/


        public Nullable<int> TotalPlannedWell { get; set; }


        // public string DPICalculateTemplateId { get; set; }
        //  [StringLength(50)]
        // public string MasterDPICalculateTemplateId { get; set; }

        // [StringLength(50)]
        // public string WellDPICalculateTemplateId { get; set; }


        //profile genrator
        [StringLength(50)]
        public string ProductionProfileId { get; set; }

        [StringLength(50)]
        public string ApplicableModelId { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> OilProjectStartDate { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> GasProjectStartDate { get; set; }



        [Column(TypeName = "datetime")]
        public Nullable<DateTime> ProjectCutOffDate { get; set; }



        public Nullable<int> RampUpDay { get; set; }
        public Nullable<int> ShiftStartDay { get; set; }


        // [NotMapped]
        // public Nullable<Decimal> PlannedDPI { get; set; }


        [StringLength(1000)]
        public string Description { get; set; }


        [StringLength(10)]
        public string Status { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Created { get; set; }


        [StringLength(50)]
        public string By { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> StartDate { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> FinishDate { get; set; }

    }
}