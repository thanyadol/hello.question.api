using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public partial class ProjectDrilled
    {
        //[StringLength(50)]
        public Guid? Id { get; set; }


        [ForeignKey("Attachment")]
        [StringLength(50)]
        public string AttachmentId { get; set; }


        // [ForeignKey("Template")]
        // [StringLength(50)]
        //public string TemplateId { get; set; } //CTEP, COTL

        //[ForeignKey("Template")]
        [StringLength(50)]
        public string TemplateTypeId { get; set; } //CTEP, COTL

        [ForeignKey("ProjectSpace")]
        [StringLength(50)]
        public string ProjectSpaceId { get; set; }

        [Column(TypeName = "decimal(28,10)")]
        public decimal? ActualDPI { get; set; }

        [Column(TypeName = "decimal(28,10)")]
        public decimal? PlannedDPI { get; set; }



        [NotMapped]
        public Template Template { get; set; }


        [NotMapped]
        public Attachment Attachment { get; set; }


        [NotMapped]
        public string AttachmentName { get; set; }


        [NotMapped]
        public bool IsPublisher { get; set; } //SAVED, PUBLISHED


        [StringLength(10)]
        public string Type { get; set; } //CTEP, COTL


        [NotMapped]
        public string ActivityType { get; set; } //SAVED, PUBLISHED


        [NotMapped]
        public string By { get; set; }

        [NotMapped]
        public string ProjectId { get; set; }


        [NotMapped]
        public string ProjectName { get; set; }




        [NotMapped]
        public DateTime? ActivityDate { get; set; }



        [StringLength(50)]
        public string Key { get; set; }


        [StringLength(50)]
        public string Rev { get; set; }


        [StringLength(10)]
        public string Status { get; set; }



        [Column(TypeName = "datetime")]
        public Nullable<DateTime> StartDate { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> FinishDate { get; set; }
    }
}