using System; 

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Models
{
    public class ProjectSpace
    {
        [Key]
        [StringLength(50)]
        public string Id { get; set; }

        [StringLength(50)]
        public string ProjectId { get; set; }

        [NotMapped]
        public string ProjectName { get; set; }

        [StringLength(50)]
        //refrenece key to platform
        public string By { get; set; }

        [StringLength(1000)]
        public string Description { get; set; }

        //[StringLength(10)]
        // public string Status { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Created { get; set; }



        [NotMapped]
        public string ActivityType { get; set; }


        [NotMapped]
        public bool IsPublisher { get; set; }

        [NotMapped]
        public DateTimeOffset? ActivityDate { get; set; }


    }
}