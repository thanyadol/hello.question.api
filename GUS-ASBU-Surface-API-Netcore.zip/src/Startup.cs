﻿using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

using Microsoft.EntityFrameworkCore;
//using System.IO;
//using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using System.Text;
using System.Configuration;


using Microsoft.Extensions.DependencyInjection.Extensions;
//using Microsoft.AspNetCore.Identity;

//DI
using surflex.netcore22.Services;
//using surflex.netcore22.Controllers;

//logging
using Microsoft.Extensions.Logging;

//model
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;

using Swashbuckle.AspNetCore.Swagger;

//apis
using surflex.netcore22.APIs.Model;
using surflex.netcore22.APIs;
//using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.Extensions;

//validator
using FluentValidation;
using surflex.netcore22.Validator;
using Microsoft.AspNetCore.Mvc.Authorization;
using AutoMapper;
using System.Reflection;
using surflex.netcore22.Models.Mapper;
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.Model;
using surflex.netcore22.Model.Filters;
using Serilog.Core;
using Example.Api.Providers;
// using surflex.netcore22.Services;
// using surflex.netcore22.Repositories;

namespace surflex.netcore22
{
    public class Startup
    {
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public IConfiguration _configuration { get; }
        public IHostingEnvironment _environment { get; }

        private readonly ILoggerFactory _loggerFactory;

        public Startup(IHostingEnvironment environment, IConfiguration configuration,
          ILoggerFactory loggerFactory)
        {
            _configuration = configuration;
            _environment = environment;
            _loggerFactory = loggerFactory;
        }

        // This method gets called by the runtime. Use this method to add services to the 
        //container.
        public void ConfigureServices(IServiceCollection services)
        {

            if ((_configuration["AppSettings:AuthenticationMode"] == "Anonymous"))
            {
                services.AddMvc(opts =>
                {
                    //global filter
                    opts.Filters.Add(new AllowAnonymousFilter());
                });
            }
            else
            {
                // ...
                services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
            }


            //services.Configure<IISOptions>(options => { options.ForwardWindowsAuthentication = true; }); 

            //live
            services.AddDbContext<NorthwindContext>(options =>
                options.UseSqlServer(this._configuration.GetConnectionString("NorthwindConnection"),
                    x => x.MigrationsHistoryTable("__EFMigrationsHistory", "dbo")));

            //rllcp
            services.AddDbContext<IceteaContext>(options =>
                options.UseOracle(this._configuration.GetConnectionString("IceteaConnection")));


            //uidm
            services.AddDbContext<IcebergContext>(options =>
                options.UseOracle(this._configuration.GetConnectionString("IcebergConnection")));

            //in memory
            //services.AddDbContext<NorthwindContext>(opt =>
            //opt.UseInMemoryDatabase("Northwind"));

            //services.AddIdentity<IdentityUser, IdentityRole>();
            //services.AddIdentity<ApplicationUser, IdentityRole>();

            //for http request information
            services.AddHttpContextAccessor();

            services.AddScoped<IHttpService, HttpService>();
            //windows authen
            //services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            // Mappers
            //services.TryAddSingleton<IMapper<IEnumerable<WellPlannedAsync>, IEnumerable<WellPlanned>>,
            //EnumerableMapper<WellPlannedAsync, WellPlanned>>();

            // Mappers
            services.TryAddSingleton<IMapper<ProjectAsync, Project>, ProjectMapper>();
            services.TryAddSingleton<IMapper<APIs.Gateway.JobProductiveAsync, JobProductive>, JobProductiveMapper>();

            services.TryAddSingleton<IMapper<JobAsync, Job>, JobMapper>();
            services.TryAddSingleton<IMapper<JobDrilledAsync, JobDrilledRate>, JobDrilledRateMapper>();

            services.TryAddSingleton<IMapper<APIs.Gateway.WellPlannedAsync, WellPlanned>, WellPlannedMapper>();
            services.TryAddSingleton<IMapper<APIs.Gateway.WellPayAsync, WellPay>, WellPayMapper>();

            services.TryAddSingleton<IMapper<APIs.Model.WellProductiveAsync, WellProductive>, WellProductiveMapper>();
            services.TryAddSingleton<IMapper<APIs.Model.WellJobProductiveAsync, WellJobProductive>, WellJobProductiveMapper>();

            services.TryAddSingleton<IMapper<APIs.Model.WellReserveAsync, WellReserve>, WellReserveMapper>();
            services.TryAddSingleton<IMapper<APIs.Model.SandAsync, Sand>, SandMapper>();
            services.TryAddSingleton<IMapper<surflex.netcore22.APIs.Model.PlatformAsync, surflex.netcore22.Models.Platform>, PlatformMapper>();

            services.TryAddSingleton<IMapper<IEnumerable<APIs.Gateway.JobProductiveAsync>, IEnumerable<JobProductive>>, EnumerableMapper<APIs.Gateway.JobProductiveAsync, JobProductive>>();


            //enum map
            services.TryAddSingleton<IMapper<IEnumerable<APIs.Gateway.WellPlannedAsync>, IEnumerable<WellPlanned>>, EnumerableMapper<APIs.Gateway.WellPlannedAsync, WellPlanned>>();
            services.TryAddSingleton<IMapper<IEnumerable<APIs.Gateway.WellPayAsync>, IEnumerable<WellPay>>, EnumerableMapper<APIs.Gateway.WellPayAsync, WellPay>>();

            services.TryAddSingleton<IMapper<IEnumerable<APIs.Model.ProjectAsync>, IEnumerable<Project>>, EnumerableMapper<APIs.Model.ProjectAsync, Project>>();
            services.TryAddSingleton<IMapper<IEnumerable<APIs.Model.WellProductiveAsync>, IEnumerable<WellProductive>>, EnumerableMapper<APIs.Model.WellProductiveAsync, WellProductive>>();
            services.TryAddSingleton<IMapper<IEnumerable<APIs.Model.SandAsync>, IEnumerable<Sand>>, EnumerableMapper<APIs.Model.SandAsync, Sand>>();
            services.TryAddSingleton<IMapper<IEnumerable<APIs.Model.JobAsync>, IEnumerable<Job>>, EnumerableMapper<APIs.Model.JobAsync, Job>>();

            services.TryAddSingleton<IMapper<IEnumerable<APIs.Model.JobDrilledAsync>, IEnumerable<JobDrilledRate>>, EnumerableMapper<APIs.Model.JobDrilledAsync, JobDrilledRate>>();

            //services.TryAddSingleton<IMapper<WellPlannedAsync, WellPlanned>, NinjaEntityToNinjaMapper>();
            //services.TryAddSingleton<IMapper<IEnumerable<WellPlannedAsync>, IEnumerable<WellPlanned>>, EnumerableMapper<WellPlannedAsync, WellPlanned>>();
            services.TryAddSingleton<IMapper<ProductionProfileParams, ProductionProfileParams>, ProductionMapper>();

            // Auto Mapper
            services.AddAutoMapper(typeof(MappingProfile));

            //services.AddSingleton<IUserStore>();
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IUserService, UserService>();

            services.AddScoped<IUserAuthenRepository, UserAuthenRepository>();

            services.AddScoped<IRoleRepository, RoleRepository>();
            services.AddTransient<IRoleService, RoleService>();
            services.AddScoped<IRoleUserService, RoleUserService>();

            services.AddScoped<IPageRepository, PageRepository>();
            services.AddScoped<IPageService, PageService>();

            services.AddScoped<IApiRepository, ApiRepository>();
            services.AddScoped<IApiService, ApiService>();

            services.AddScoped<IModuleService, ModuleService>();

            services.AddScoped<ILoggService, LoggService>();


            services.AddScoped<IPageApiRepository, PageApiRepository>();
            services.AddScoped<IProjectAuthorizeRepository, ProjectAuthorizeRepository>();
            services.AddScoped<IRoleAuthorizeRepository, RoleAuthorizeRepository>();

            //services.AddScoped<IRolePageRepository, RolePageRepository>();
            services.AddScoped<ISessionLoggRepository, SessionLoggRepository>();
            services.AddScoped<IUserActivityRepository, UserActivityRepository>();
            services.AddScoped<IRoleModuleRepository, RoleModuleRepository>();
            services.AddScoped<IModuleRepository, ModuleRepository>();
            services.AddScoped<IModulePageRepository, ModulePageRepository>();

            services.AddScoped<IWellRepository, WellRepository>();
            services.AddScoped<IWellScenarioRepository, WellScenarioRepository>();
            //services.AddScoped<IWellReserveRepository, WellReserveRepository>();
            services.AddScoped<IWellPropertiesRepository, WellPropertiesRepository>();

            services.AddScoped<IWellSpaceRepository, WellSpaceRepository>();
            services.AddScoped<IWellDrilledRepository, WellDrilledRepository>();
            services.AddScoped<IWellUndrilledRepository, WellUndrilledRepository>();
            services.AddScoped<IWellActivityRepository, WellActivityRepository>();


            services.AddTransient<IWellService, WellService>();
            services.AddScoped<IWellResourceService, WellResourceService>();

            // services.AddScoped<IWellAttachmentPriceService, WellAttachmentPriceService>();

            services.AddScoped<IProjectRepository, ProjectRepository>();
            services.AddScoped<IProjectActivityRepository, ProjectActivityRepository>();
            services.AddScoped<IProjectWellRepository, ProjectWellRepository>();
            services.AddScoped<IProjectSpaceRepository, ProjectSpaceRepository>();
            services.AddScoped<IProjectDrilledRepository, ProjectDrilledRepository>();
            services.AddScoped<IProjectLocationRepository, ProjectLocationRepository>();


            services.AddTransient<IProjectService, ProjectService>();
            services.AddScoped<IProjectWellService, ProjectWellService>();
            services.AddScoped<IProjectUserService, ProjectUserService>();

            services.AddScoped<IProjectAttributeRepository, ProjectAttributeRepository>();

            services.AddScoped<ITemplateRepository, TemplateRepository>();
            services.AddScoped<ITemplateService, TemplateService>();

            services.AddScoped<IAttachmentRepository, DbAttachmentRepository>();
            //services.AddScoped<IAttachmentService, DbAttachmentService>();
            services.AddScoped<IAttachmentService, FileSystemAttachmentService>();

            services.AddScoped<ISandRepository, SandRepository>();
            services.AddScoped<ISandService, SandService>();
            //  services.AddScoped<ISandProductionService, SandProductionService>();

            services.AddTransient<IJobService, JobService>();
            services.AddScoped<IJobRepository, JobRepository>();

            services.AddScoped<IPeriodPriceRepository, PeriodPriceRepository>();
            services.AddScoped<IPriceGroupRepository, PriceGroupRepository>();
            services.AddScoped<IPriceService, PriceService>();

            services.AddScoped<IAreaService, AreaService>();
            services.AddScoped<IAreaRepository, AreaRepository>();


            services.AddScoped<IPathFinderService, PathFinderService>();

            services.AddScoped<IResourceTaskRepository, ResourceTaskRepository>();
            services.AddScoped<IResourceLibraryRepository, ResourceLibraryRepository>();
            services.AddScoped<IResourceRepository, ResourceRepository>();
            services.AddScoped<IResourceService, ResourceService>();

            //services.AddScoped<IScenarioRepository, ScenarioRepository>();
            //services.AddScoped<IScenarioService, ScenarioService>();

            services.AddScoped<IRiggRepository, RiggRepository>();
            services.AddScoped<IRiggRateRepository, RiggRateRepository>();
            services.AddScoped<IRiggService, RiggService>();

            services.AddScoped<IDecisionService, DecisionService>();
            services.AddScoped<IDecisionRepository, DecisionRepository>();

            services.AddTransient<IWorkUnitService, WorkUnitService>();
            // services.AddScoped<IServiceFactory, ServiceFactory>();

            //services.TryAddSingleton<IMapper<IEnumerable<NinjaEntity>, IEnumerable<Ninja>>, EnumerableMapper<NinjaEntity, Ninja>>();

            //http client factory
            //Set 5 min as the lifetime for the HttpMessageHandler objects in the pool used for the Catalog Typed Client 
            services.AddHttpClient<IClientService, ClientService>()
            .SetHandlerLifetime(TimeSpan.FromMinutes(5));


            services.AddScoped<IEntityService, EntityService>();

            //apis
            /* services.AddScoped<APIs.Service.IProjectService, APIs.Service.ProjectService>();
            services.AddScoped<APIs.Service.IJobService, APIs.Service.JobService>();
            services.AddScoped<APIs.Service.IWellService, APIs.Service.WellService>();*/

            //apis
            services.AddScoped<APIs.Repository.IProjectRepository, APIs.Repository.ProjectRepository>();
            services.AddScoped<APIs.Repository.IJobRepository, APIs.Repository.JobRepository>();
            services.AddScoped<APIs.Repository.IWellRepository, APIs.Repository.WellRepository>();
            services.AddScoped<APIs.Repository.ISandRepository, APIs.Repository.SandRepository>();

            services.AddScoped<NorthwindContext>();
            services.AddApiVersioning();

            //validator
            services.AddScoped<AbstractValidator<Sand>, SandValidator>();
            services.AddScoped<AbstractValidator<Models.Platform>, PlatformValidator>();
            services.AddScoped<AbstractValidator<TemplateValidateParams>, TemplateValidator>();
            services.AddScoped<AbstractValidator<WellDecisionParams>, WellDecisionValidator>();
            services.AddScoped<AbstractValidator<WellEvaluateParams>, WellValidator>();

            services.AddScoped<IProductionRepository, ProductionRepository>();
            services.AddScoped<IProductionProfileRepository, ProductionProfileRepository>();
            services.AddScoped<IProductionParamRepository, ProductionParamRepository>();
            services.AddScoped<IProductionService, ProductionService>();

            //serilog custome sink
            services.AddScoped<EntityLogEventSink>();

            //parameterize
            /*services.AddTransient<NorthwindContext>(provider =>
            {
                //resolve another classes from DI
                var anyOtherClass = provider.GetService<AnyOtherClass>();

                //pass any parameters
                return new NorthwindContext(foo, bar);
            });*/

            //services.TryAddSingleton<NorthwindContext>();

            //services.AddScoped<IBlogService, BlogService>();

            //tokening
            // configure strongly typed settings objects
            string SecretKey = _configuration["AppSettings:SecretKey"];
            var key = Encoding.ASCII.GetBytes(SecretKey);
            services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(x =>
            {
                x.RequireHttpsMetadata = false;
                x.SaveToken = true;
                x.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = false,
                    ValidateAudience = false
                };
            });


            //enable CORES
            if (_environment.IsDevelopment())
            {
                services.AddCors(o => o.AddPolicy("AllowCores", builder =>
                {
                    builder.AllowAnyOrigin()
                        .AllowAnyMethod()
                        .AllowAnyHeader();
                }));
            }
            else
            {
                services.AddCors(o => o.AddPolicy("AllowCores", builder =>
                {
                    builder.WithOrigins(
                            _configuration.GetValue<string>("AppSettings:HostName", string.Empty)
                        )
                        .AllowAnyMethod()
                        .AllowAnyHeader()
                        .AllowCredentials();
                }));
            }


            // Add application services.
            //services.AddTransient<IEmailSender, AuthMessageSender>();
            //services.AddTransient<ISmsSender, AuthMessageSender>();

            // Adds Swagger
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Swashbuckle.AspNetCore.Swagger.Info
                {
                    Version = "v1",
                    Title = "Surface-API-Netcore",
                    Description = "A simple example ASP.NET Core Web API",
                    TermsOfService = "None",
                    Contact = new Contact
                    {
                        Name = "thanyadol",
                        Email = string.Empty,
                        Url = "https://twitter.com/thanyadol"
                    },
                    License = new License
                    {
                        Name = "Use under LICX",
                        Url = "https://example.com/license"
                    }
                });
            });


            //uncomment this to apply global fileert
            /* *services.AddMvc(
            config =>
            {
                config.Filters.Add(new GlobalFilterExample());
            });*/

            //servicetype di filter
            //services.AddScoped<ActionFilterExample>();
            services.AddScoped<EnsureUserAuthorizeIn>();
            services.AddScoped<EnsureUserAuthorizeInAsync>();

            //singletton memcache
            //services.AddScoped<Models.Cache>();


        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment _environment)
        {

            var logger = _loggerFactory.CreateLogger<Startup>();

            if (_environment.IsDevelopment())
            {
                // Development service configuration
                app.UseDeveloperExceptionPage();
            }

            if (_environment.IsProduction() || _environment.IsStaging() || _environment.IsEnvironment("Staging_2"))
            {
                // Non-development service configuration
                app.UseHsts();
                app.UseExceptionHandler("/Error");
            }

            logger.LogInformation($"Environment: {_environment.EnvironmentName}");


            //app.ConfigureExceptionHandler();
            app.ConfigureCustomExceptionMiddleware();

            // Configuration is available during startup.
            // Examples:
            //   _config["key"]
            //   _config["subsection:suboption1"]

            //for dependency injection service
            app.ApplicationServices.GetService<IDisposable>();

            //if (!(_configuration["AppSettings:AuthenticationMode"] == "Anonymous"))
            //{
            app.UseAuthentication();
            // }

            //Add our new middleware to the pipeline
            app.UseMiddleware<LoggingMiddleware>();


            app.UseHttpsRedirection();
            app.UseMvc();

            // Adds Swagger
            if (_configuration.GetValue<bool>("AppSettings:Swagger:IsEnabled", false) == true)
            {
                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("/swagger/v1/swagger.json", "SURFACE-LIVE-API V1");
                });
            }
        }
    }
}
