using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Authentication;

//logg
using Serilog;

//services
using surflex.netcore22.Models;
using surflex.netcore22.Services;
using surflex.netcore22.Exceptions;
using surflex.netcore22.APIs.Gateway;
using FluentValidation;
using surflex.netcore22.Validator;

namespace surflex.netcore22.Controllers
{
    [Authorize]
    [ApiVersion("1.0")]
    [Route("api/{version:apiVersion}/[controller]")]
    [ApiController]
    public class ResourceController : ControllerBase
    {
        private readonly IResourceService _resourceService;

        public ResourceController(IResourceService resourceService) //, AbstractValidator<WellDecisionValidator> decisionParamsValidator)
        {
            _resourceService = resourceService ?? throw new ArgumentNullException(nameof(resourceService));
            //    _decisionParamsValidator = decisionParamsValidator ?? throw new ArgumentNullException(nameof(decisionParamsValidator));
        }

        [EnableCors("AllowCores")]
        [Route("list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Resource>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListAsync()
        {
            var resources = await _resourceService.ListAsync();
            return Ok(resources);
        }

        [EnableCors("AllowCores")]
        [Route("get")]
        [HttpGet]
        [ProducesResponseType(typeof(Resource), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Resource), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAsync(string id)
        {
            var resource = await _resourceService.GetAsync(id);
            return Ok(resource);

        }

        [EnableCors("AllowCores")]
        [Route("post")]
        [HttpPost]
        [ProducesResponseType(typeof(Resource), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateAsync([FromBody]Resource resource)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _resourceService.CreateAsync(resource);

            return CreatedAtAction(
                nameof(CreateAsync),
                entity
            );
        }

        [EnableCors("AllowCores")]
        [Route("put")]
        [HttpPost]
        [ProducesResponseType(typeof(Resource), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UpdateAsync([FromBody]Resource resource)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _resourceService.UpdateAsync(resource);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("calculate")]
        [HttpPost]
        [ProducesResponseType(typeof(WellDecisionParams), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CalculateBatchResourceAsync([FromBody]WellDecisionParams paramds)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _resourceService.CalculateBatchResourceAsync(paramds);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("validate")]
        [HttpPost]
        [ProducesResponseType(typeof(WellDecisionParams), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> ValidateBatchResourceAsync([FromBody]WellDecisionParams paramds)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _resourceService.ValidateBatchResourceAsync(paramds);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("library/init")]
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<ResourceLibrary>), StatusCodes.Status200OK)]
        public async Task<IActionResult> InitialLibraryAsync([FromBody]List<ResourceLibrary> resources)
        {
            var entity = await _resourceService.InitialLibraryAsync(resources);
            return Ok(entity);
        }



        [EnableCors("AllowCores")]
        [Route("library/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<ResourceLibrary>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListLibraryAsync(bool archive = false)
        {
            var resources = await _resourceService.ListLibraryAsync(archive);
            return Ok(resources);
        }



        [EnableCors("AllowCores")]
        [Route("library/get")]
        [HttpGet]
        [ProducesResponseType(typeof(ResourceLibrary), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ResourceLibrary), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetLibraryAsync(string id)
        {
            var resource = await _resourceService.GetLibraryAsync(id);
            return Ok(resource);
        }



        [EnableCors("AllowCores")]
        [Route("tangible/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<ResourceLibrary>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(IEnumerable<ResourceLibrary>), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> ListTangibleAsync()
        {
            var resource = await _resourceService.ListTangibleAsync();
            return Ok(resource);
        }

        [EnableCors("AllowCores")]
        [Route("opex/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<ResourceLibrary>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(IEnumerable<ResourceLibrary>), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> ListOpexCPPAsync()
        {
            var resource = await _resourceService.ListOpexCPPAsync();
            return Ok(resource);
        }

        [EnableCors("AllowCores")]
        [Route("type")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<ResourceLibrary>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(IEnumerable<ResourceLibrary>), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> ListTypeAsync()
        {
            var resource = await _resourceService.ListTypeAsync();
            return Ok(resource);
        }


        [EnableCors("AllowCores")]
        [Route("library/post")]
        [HttpPost]
        [ProducesResponseType(typeof(ResourceLibrary), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateAsync([FromBody]ResourceLibrary resource)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _resourceService.CreateAsync(resource);

            return CreatedAtAction(
                nameof(CreateAsync),
                entity
            );
        }


        [EnableCors("AllowCores")]
        [Route("library/put")]
        [HttpPost]
        [ProducesResponseType(typeof(ResourceLibrary), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UpdateAsync([FromBody]ResourceLibrary resource)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _resourceService.UpdateAsync(resource);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("task/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<ResourceTask>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListTaskAsync(string id = null, string type = null)
        {
            var resources = await _resourceService.ListTaskAsync(id, type);
            return Ok(resources);

        }

        [EnableCors("AllowCores")]
        [Route("task/get")]
        [HttpGet]
        [ProducesResponseType(typeof(ResourceTask), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ResourceTask), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetTaskAsync(string id)
        {
            var resource = await _resourceService.GetTaskAsync(id);

            if (resource == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(resource);
            }
        }

        [EnableCors("AllowCores")]
        [Route("task/post")]
        [HttpPost]
        [ProducesResponseType(typeof(ResourceTask), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateAsync([FromBody]ResourceTask resource)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _resourceService.CreateAsync(resource);

            return CreatedAtAction(
                nameof(CreateAsync),
                entity
            );
        }



        [EnableCors("AllowCores")]
        [Route("task/delete")]
        [HttpPost]
        [ProducesResponseType(typeof(ResourceTask), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> DeleteAsync(string id)
        {

            // var entity = await _resourceService.CreateAsync(resource);

            //throw new NotImplementedException();
            var entity = await _resourceService.DeleteAsync(id);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("task/put")]
        [HttpPost]
        [ProducesResponseType(typeof(ResourceTask), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UpdateAsync([FromBody]ResourceTask resource)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _resourceService.UpdateAsync(resource);
            return Ok(entity);
        }


    }
}
