using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Authentication;

//logg
using Serilog;

//services
using surflex.netcore22.Models;
using surflex.netcore22.Services;
using surflex.netcore22.Exceptions;
using surflex.netcore22.Model.Filters;
// using surflex.netcore22.Models.Constants;


//using GLOBAL = surflex.netcore22.Models.Constants.GlobalConstants;

namespace surflex.netcore22.Controllers
{
    [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
    [Authorize]
    [ApiVersion("1.0")]
    [Route("api/{version:apiVersion}/[controller]")]
    [ApiController]
    public class PriceController : ControllerBase
    {
        private readonly IPriceService _priceService;

        public PriceController(IPriceService priceService)
        {
            _priceService = priceService ?? throw new ArgumentNullException(nameof(priceService));

        }

        [EnableCors("AllowCores")]
        [Route("list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<PeriodPrice>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListAsync()
        {
            var prices = await _priceService.ListAsync();
            return Ok(prices);
        }

        [EnableCors("AllowCores")]
        [Route("get")]
        [HttpGet]
        [ProducesResponseType(typeof(PeriodPrice), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(PeriodPrice), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAsync(Guid id)
        {
            var price = await _priceService.GetAsync(id);

            if (price == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(price);
            }
        }



        [EnableCors("AllowCores")]
        [Route("template/validate")]
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<Attachment>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> ValidateMonthlyTemplateAsync([FromBody]Attachment attachment)
        {
            await _priceService.ValidateMonthlyTemplateAsync(attachment);
            attachment.Value = null;

            return Ok(attachment);
        }

        [EnableCors("AllowCores")]
        [Route("post")]
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<Price>), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateAsync([FromBody]Template template)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            //check template type year or monthh
            /* if (template.TemplateTypeId == GLOBAL.PRICE_STRUCTURE_YEAR_ID) //year template !!!! see global constant
            {
                var entity = await _priceService.CreateYearlyAsync(template);
                return Ok(entity);
            }

            if (template.TemplateTypeId == GLOBAL.PRICE_STRUCTURE_MONTH_ID) //month !!!! see global constant
            {
                var entity = await _priceService.CreateMonthlyAsync(template);
                return Ok(entity);
            }*/

            var entity = await _priceService.CreateMonthlyAsync(template);
            return Ok(entity);

            // return NotFound();
        }




    }
}
