using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

//service
using surflex.netcore22.Models;
using surflex.netcore22.Services;

//util
using surflex.netcore22.Helpers;
using System.IO;

namespace surflex.netcore22.Controllers
{
    ////[Authorize]
    [Route("api/[controller]")]
    [ApiController]
    [ApiVersionNeutral]
    public class HelloController : ControllerBase
    {

        [EnableCors("AllowCores")]
        [Route("")]
        [HttpGet]
        public ActionResult<string> Index()
        {
            return "Hello World with .NET Framework CORE Web API at " + Utility.CurrentSEAsiaStandardTime();
        }

        //[AllowAnonymous]
        [EnableCors("AllowCores")]
        [Route("health")]
        [HttpGet]
        public ActionResult<Health> Health()
        {
            return new Health("Ok");
        }

        //[AllowAnonymous]
        [EnableCors("AllowCores")]
        [Route("throw")]
        [HttpGet]
        public ActionResult<Health> Throw()
        {
            throw new IOException();
        }
    }
}