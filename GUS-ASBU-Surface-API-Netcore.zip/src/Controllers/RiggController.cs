using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Authentication;

//logg
using Serilog;

//services
using surflex.netcore22.Models;
using surflex.netcore22.Services;
using surflex.netcore22.Exceptions;
using surflex.netcore22.Model.Filters;

namespace surflex.netcore22.Controllers
{

    [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
    [Authorize]
    [ApiVersion("1.0")]
    [Route("api/{version:apiVersion}/[controller]")]
    [ApiController]
    public class RiggController : ControllerBase
    {
        private readonly IRiggService _riggService;

        public RiggController(IRiggService riggService)
        {
            _riggService = riggService ?? throw new ArgumentNullException(nameof(riggService));

        }

        [EnableCors("AllowCores")]
        [Route("list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Rigg>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListAsync()
        {
            var riggs = await _riggService.ListAsync();
            return Ok(riggs);
        }

        [EnableCors("AllowCores")]
        [Route("get")]
        [HttpGet]
        [ProducesResponseType(typeof(Rigg), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Rigg), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAsync(string id)
        {
            var rigg = await _riggService.GetAsync(id);

            if (rigg == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(rigg);
            }
        }

        /* [EnableCors("AllowCores")]
        [Route("post")]
        [HttpPost]
        [ProducesResponseType(typeof(Rigg), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateAsync([FromBody]Rigg rigg)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var createRigg = await _riggService.CreateAsync(rigg);

            return CreatedAtAction(
                nameof(CreateAsync),
                createRigg
            );
        }*/

        [EnableCors("AllowCores")]
        [Route("post")]
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<Rigg>), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BatchCreateAsync([FromBody]Template template)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _riggService.BatchCreateAsync(template);
            return Ok(entity);
        }

        [EnableCors("AllowCores")]
        [Route("template/validate")]
        [HttpPost]
        [ProducesResponseType(typeof(FluentValidation.Results.ValidationResult), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> ValidateRateTemplateAsync([FromBody]Attachment atttach)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var result = await _riggService.ValidateRateTemplateAsync(atttach);
            return Ok(result);
        }


        /* [EnableCors("AllowCores")]
        [Route("extract")]
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<Rigg>), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> ExtractAsync([FromBody]Attachment attachment)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _riggService.ExtractAsync(attachment);

            return Ok(entity);
        }*/

        /* 
        [EnableCors("AllowCores")]
        [Route("put")]
        [HttpPut]
        [ProducesResponseType(typeof(Rigg), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UpdateAsync([FromBody]Rigg rigg)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var updatedRigg = await _riggService.UpdateAsync(rigg);
                return Ok(updatedRigg);
            }
            catch (RiggNotFoundException)
            {
                return NotFound();
            }
        }*/


        [EnableCors("AllowCores")]
        [Route("rate/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<RiggRate>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListRateAsync(string id = null)
        {
            var riggs = await _riggService.ListRateAsync(id);
            return Ok(riggs);
        }

    }
}
