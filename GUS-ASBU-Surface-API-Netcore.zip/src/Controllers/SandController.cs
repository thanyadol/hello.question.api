using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Authentication;

//logg
using Serilog;

//service
using surflex.netcore22.Models;
using surflex.netcore22.Services;


//DTO
using Usi = surflex.netcore22.APIs.Model.Usi;

using FluentValidation.Results;
using surflex.netcore22.APIs.Model;
using surflex.netcore22.Model.Filters;

namespace surflex.netcore22.Controllers
{
    [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
    [Authorize]
    [ApiVersion("1.0")]
    [Route("api/{version:apiVersion}/[controller]")]
    [ApiController]
    public class SandController : ControllerBase
    {

        //private readonly string DRILLED = "DRILLED";
        // private readonly string UNDRILLED = "UNDRILLED";

        private readonly ISandService _sandService;
        // private readonly ISandProductionService _sandProductioService;

        public SandController(ISandService sandService) //, ISandProductionService sandProductioService)
        {
            _sandService = sandService ?? throw new ArgumentNullException(nameof(sandService));
            // _sandProductioService = sandProductioService ?? throw new ArgumentNullException(nameof(sandProductioService));
        }

        [EnableCors("AllowCores")]
        [Route("list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Sand>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListAsync()
        {
            var sands = await _sandService.ListAsync();
            return Ok(sands);
        }

        [EnableCors("AllowCores")]
        [Route("get")]
        [HttpGet]
        [ProducesResponseType(typeof(Sand), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Sand), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAsync(Guid id)
        {
            var sand = await _sandService.GetAsync(id);

            if (sand == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(sand);
            }
        }



        [EnableCors("AllowCores")]
        [Route("rules")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<string>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetRulesAsync()
        {
            var res = await _sandService.GetRulesAsync();
            return Ok(res);
        }

        [EnableCors("AllowCores")]
        [Route("info")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Usi>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetSandInfoAsync(string usi)
        {
            var sand = await _sandService.GetSandInfoAsync(usi);
            return Ok(sand);
        }



        [EnableCors("AllowCores")]
        [Route("fvfprofile")]
        [HttpGet]
        //fomular volumn factor
        public async Task<IActionResult> ListFactorProfileAsync(string type)
        {
            var sand = await _sandService.ListFactorProfileAsync(type);
            return Ok(sand);
        }


        [EnableCors("AllowCores")]
        [Route("analogy")]
        [HttpGet]
        public async Task<IActionResult> ListAnalogyAsync(string type)
        {
            IEnumerable<Analogy> sands;
            //list
            sands = await _sandService.ListAnalogyAsync(type);
            return Ok(sands);
        }

        [EnableCors("AllowCores")]
        [Route("depletion")]
        [HttpGet]
        public async Task<IActionResult> ListDepletionTypeAsync()
        {
            var sand = await _sandService.ListDepletionTypeAsync();
            return Ok(sand);
        }


        [EnableCors("AllowCores")]
        [Route("category")]
        [HttpGet]
        public async Task<IActionResult> ListCategoryAsync()
        {
            var sand = await _sandService.ListCategoryAsync();
            return Ok(sand);
        }

    }
}
