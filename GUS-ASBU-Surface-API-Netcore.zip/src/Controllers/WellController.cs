using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Authentication;

//logg
using Serilog;

//service
using surflex.netcore22.Models;
using surflex.netcore22.Services;
using surflex.netcore22.Exceptions;

//apis
using surflex.netcore22.APIs;
using Analogy = surflex.netcore22.APIs.Model.Analogy;
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.Model.Filters;

namespace surflex.netcore22.Controllers
{
    [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
    [ApiVersion("1.0")]
    [Route("api/{version:apiVersion}/[controller]")]
    [ApiController]
    public class WellController : ControllerBase
    {
        private readonly IWellService _wellService;
        //private readonly IclientService _clientService;
        private readonly IJobService _jobService;


        public WellController(IWellService wellService, IJobService jobService)//, IclientService IclientService)
        {
            _wellService = wellService ?? throw new ArgumentNullException(nameof(wellService));
            _jobService = jobService ?? throw new ArgumentNullException(nameof(jobService));


        }


        [EnableCors("AllowCores")]
        [Route("job/productive")]
        [HttpGet]
        [ProducesResponseType(typeof(JobProductive), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetProductiveAsync(string name)
        {
            var entity = await _jobService.GetProductiveAsync(name);

            return Ok(entity);
        }

        [EnableCors("AllowCores")]
        [Route("list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<WellPlanned>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListPlannedAsync(int id, bool status = false)
        {

            var wells = await _wellService.ListPlannedAsync(id, status);

            return Ok(wells);
        }

        [EnableCors("AllowCores")]
        [Route("planned/get")]
        [HttpGet]
        [ProducesResponseType(typeof(WellReserve), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(WellReserve), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetPlannedReserveAsync(string name)
        {
            var well = await _wellService.GetPlannedReserveAsync(name);
            return Ok(well);
        }

        [EnableCors("AllowCores")]
        [Route("get")]
        [HttpGet]
        [ProducesResponseType(typeof(Well), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Well), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAsync(string name)
        {
            var well = await _wellService.GetAsync(name);
            return Ok(well);
        }


        [EnableCors("AllowCores")]
        [Route("status")]
        [HttpGet]
        [ProducesResponseType(typeof(WellProductive), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(WellProductive), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetProductiveStatusAsync(string name)
        {
            var well = await _wellService.GetProductiveStatusAsync(name);
            return Ok(well);
        }



        [EnableCors("AllowCores")]
        [Route("sor")]
        [HttpPost]
        [ProducesResponseType(typeof(SimpleWellPlanned), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SimpleWellPlanned), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> ListSORNotificationAsync(IEnumerable<SimpleWellPlanned> wells)
        {
            var well = await _wellService.ListSORNotificationAsync(wells);
            return Ok(well);
        }



        [EnableCors("AllowCores")]
        [Route("analogy")]
        [HttpGet]
        [ProducesResponseType(typeof(Dictionary<string, Analogy>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Dictionary<string, Analogy>), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetUDVAnalogyAsync(string name)
        {
            var entity = await _wellService.GetUDVAnalogyAsync(name);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("dpi/init")]
        [HttpGet]
        [ProducesResponseType(typeof(Well), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> InitialDecisionParamsAsync(string name)
        {
            //throw new NotImplementedException();
            var inited = await _wellService.InitialDecisionParamsAsync(name);
            return Ok(inited);
        }

        //scenario   
        [EnableCors("AllowCores")]
        [Route("scenario/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<PresetWellScenario>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListScenarioAsync()
        {
            var scenarios = await _wellService.ListScenarioAsync();
            return Ok(scenarios);
        }

        [EnableCors("AllowCores")]
        [Route("publish")]
        [HttpPost]
        [ProducesResponseType(typeof(Well), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> PublishAsync(Guid id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _wellService.PublishAsync(id);
            return Ok(entity);
        }

        [EnableCors("AllowCores")]
        [Route("scenario/post")]
        [HttpPost]
        [ProducesResponseType(typeof(PresetWellScenario), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateAsync([FromBody]PresetWellScenario scenario)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var createScenario = await _wellService.CreateAsync(scenario);

            return CreatedAtAction(
                nameof(CreateAsync),
                createScenario
            );
        }


        [EnableCors("AllowCores")]
        [Route("scenario/put")]
        [HttpPost]
        [ProducesResponseType(typeof(PresetWellScenario), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UpdateAsync([FromBody]PresetWellScenario scenario)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var entity = await _wellService.UpdateAsync(scenario);
                return Ok(entity);
            }
            catch (WellScenarioNotFoundException)
            {
                return NotFound();
            }
        }



        [EnableCors("AllowCores")]
        [Route("dpi/evaluate/batch")]
        [HttpPost]
        [ProducesResponseType(typeof(WellEvaluateParams), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> EvaluateBranchDPIAsync(IEnumerable<WellEvaluateParams> parameters)
        {
            var entities = await _wellService.EvaluateBranchDPIAsync(parameters);

            return Ok(entities);
        }

        //drilled , undrilled


        [EnableCors("AllowCores")]
        [Route("drilled/post")]
        [HttpPost]
        [ProducesResponseType(typeof(WellDrilled), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BatchCreateDrilledAsync(WellDrilled drilled)
        {
            if (String.IsNullOrEmpty(drilled.ProjectName))
            {
                return BadRequest(ModelState);
            }

            var entity = await _wellService.BatchCreateDrilledAsync(drilled);

            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("undrilled/post")]
        [HttpPost]
        [ProducesResponseType(typeof(WellUndrilled), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BatchCreateUnrilledAsync(WellUndrilled drilled)
        {
            if (String.IsNullOrEmpty(drilled.ProjectName))
            {
                return BadRequest(ModelState);
            }

            ////short validate
            if (String.IsNullOrEmpty(drilled.UndrilledMethod))
            {
                return BadRequest(ModelState);
            }

            var entity = await _wellService.BatchCreateUnrilledAsync(drilled);

            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("drilled/calculate")]
        [HttpPost]
        [ProducesResponseType(typeof(WellDrilled), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CalculateDrilledAsync(WellDrilled drilled)
        {
            //short validate
            if (String.IsNullOrEmpty(drilled.WellName))
            {
                return BadRequest(ModelState);
            }


            var entity = await _wellService.CalculateDrilledAsync(drilled);

            return Ok(entity);
        }

        [EnableCors("AllowCores")]
        [Route("undrilled/calculate")]
        [HttpPost]
        [ProducesResponseType(typeof(WellUndrilled), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CalculateUndrilledAsync(WellUndrilled drilled)
        {
            var entity = await _wellService.CalculateUndrilledAsync(drilled);

            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("drilled/synce")]
        [HttpGet]
        [ProducesResponseType(typeof(WellDrilled), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> SynceDrilledAsync(string name, string project, string platform)
        {
            if (String.IsNullOrEmpty(name))
            {
                return BadRequest(ModelState);
            }

            var entity = await _wellService.SynceDrilledAsync(name, project, platform);

            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("undrilled/synce")]
        [HttpGet]
        [ProducesResponseType(typeof(WellUndrilled), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> SynceUndrilledAsync(string name, string project, string platform)
        {
            if (String.IsNullOrEmpty(name))
            {
                return BadRequest(ModelState);
            }

            var entity = await _wellService.SynceUndrilledAsync(name, project, platform);

            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("drilled/merge")]
        [HttpPost]
        [ProducesResponseType(typeof(WellDrilled), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> MergeDrilledAsync(WellDrilled drilled)
        {
            var entity = await _wellService.MergeDrilledAsync(drilled);

            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("dpi/simple")]
        [HttpPost]
        [ProducesResponseType(typeof(WellEvaluateParams), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> EvaluateSimpleDPIAsync(WellEvaluateParams parameters)
        {
            if (String.IsNullOrEmpty(parameters.WellName))
            {
                return BadRequest(ModelState);
            }

            var entity = await _wellService.EvaluateSimpleDPIAsync(parameters);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("drilled/recent")]
        [HttpGet]
        [ProducesResponseType(typeof(WellDrilled), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetDrilledRecentlyAsync(string name)
        {
            var entity = await _wellService.GetDrilledRecentlyAsync(name);

            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("undrilled/recent")]
        [HttpGet]
        [ProducesResponseType(typeof(WellDrilled), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetUndrilledRecentlyAsync(string name)
        {
            var entity = await _wellService.GetUndrilledRecentlyAsync(name);

            return Ok(entity);
        }

        [EnableCors("AllowCores")]
        [Route("undrilled/method")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Item>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListUndrilledMethodAsync()
        {
            var sands = await _wellService.ListUndrilledMethodAsync();
            return Ok(sands);
        }


        [EnableCors("AllowCores")]
        [Route("reserve")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<WellReserveParams>), StatusCodes.Status200OK)]
        public async Task<IActionResult> EvaluatedReserveAsync(string name, string status = "Drilling")
        {
            var sands = await _wellService.EvaluatedReserveAsync(name, status);
            return Ok(sands);
        }

    }
}

