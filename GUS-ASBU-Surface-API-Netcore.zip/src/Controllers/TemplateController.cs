using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Authentication;

//logg
using Serilog;

//services
using surflex.netcore22.Models;
using surflex.netcore22.Services;
using surflex.netcore22.Exceptions;

namespace surflex.netcore22.Controllers
{
    [Authorize]
    [ApiVersion("1.0")]
    [Route("api/{version:apiVersion}/[controller]")]
    [ApiController]
    public class TemplateController : ControllerBase
    {
        private readonly ITemplateService _templateService;
        private readonly IAreaService _areaService;


        public TemplateController(ITemplateService templateService, IAreaService areaService)
        {
            _templateService = templateService ?? throw new ArgumentNullException(nameof(templateService));
            _areaService = areaService ?? throw new ArgumentNullException(nameof(areaService));

        }

        [EnableCors("AllowCores")]
        [Route("list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Template>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListAsync(string status = null)
        {
            var templates = await _templateService.ListAsync(status);
            return Ok(templates);
        }


        [EnableCors("AllowCores")]
        [Route("type")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Template>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListTypeAsync()
        {
            var templates = await _templateService.ListTypeAsync();
            return Ok(templates);
        }


        [EnableCors("AllowCores")]
        [Route("recent")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Template>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetCurrentlyAsync(string id)
        {
            var templates = await _templateService.GetCurrentlyAsync(id);
            return Ok(templates);
        }


        [EnableCors("AllowCores")]
        [Route("attach")]
        [HttpGet]
        [ProducesResponseType(typeof(Attachment), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAttachedAsync(string id)
        {
            var attachment = await _templateService.GetAttachedAsync(id);
            return Ok(attachment);
        }

        [EnableCors("AllowCores")]
        [Route("get")]
        [HttpGet]
        [ProducesResponseType(typeof(Template), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Template), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAsync(string id)
        {
            var template = await _templateService.GetAsync(id);
            return Ok(template);

        }

        [EnableCors("AllowCores")]
        [Route("post")]
        [HttpPost]
        [ProducesResponseType(typeof(Template), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateAsync([FromBody]Template template)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var createTemplate = await _templateService.CreateAsync(template);

            return CreatedAtAction(
                nameof(CreateAsync),
                createTemplate
            );
        }



        [EnableCors("AllowCores")]
        [Route("area")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Template>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListAreaAsync()
        {
            var templates = await _areaService.ListAsync();
            return Ok(templates);
        }

    }
}
