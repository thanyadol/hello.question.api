﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Authentication;

//logg
using Serilog;

//service
using surflex.netcore22.Models;
using surflex.netcore22.Services;
using surflex.netcore22.Exceptions;
using System.Security.Claims;
using surflex.netcore22.Model.Filters;

namespace surflex.netcore22.Controllers
{
    // [Authorize]
    //[ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
    [AllowAnonymous]
    [ApiVersion("1.0")]
    [Route("api/{version:apiVersion}/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        //   private readonly IHttpContextAccessor _httpContextAccessor;
        // private readonly UserManager<ApplicationUser> _userManager;


        public UserController(IUserService userService)// IHttpContextAccessor httpContextAccessor)
        {

            // _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
            _userService = userService ?? throw new ArgumentNullException(nameof(userService));


            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }

        //Windows
        [AllowAnonymous]
        [EnableCors("AllowCores")]
        [Route("authen")]
        [HttpPost]
        [ProducesResponseType(typeof(User), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> AuthenHTTPGETAsync()
        {
            //var accessToken = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];

            var user = await _userService.AuthenAsync();
            return Ok(user);

        }


        /*[AllowAnonymous]
        [EnableCors("AllowCores")]
        [Route("authen")]
        [HttpPost]
        [ProducesResponseType(typeof(User), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> AuthenHTTPPOSTAsync([FromBody]Token token)
        {
            var user = await _userService.AuthenAsync(token);
            return Ok(user);

        }*/

        // [AllowAnonymous]
        [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
        [EnableCors("AllowCores")]
        [Route("authen/post")]
        [HttpPost]
        [ProducesResponseType(typeof(UserAuthen), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateAsync([FromBody]UserAuthen authen)
        {
            //var accessToken = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];

            var user = await _userService.CreateAsync(authen);
            return Ok(user);

        }



        // [AllowAnonymous]
        [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
        [EnableCors("AllowCores")]
        [Route("authen/recent")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<User>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> ListAuthenAsync()
        {
            //var accessToken = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];

            var user = await _userService.ListAuthenAsync();
            return Ok(user);

        }



        // [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
        [EnableCors("AllowCores")]
        [Route("list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<User>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListAsync(bool responsibility = false)
        {
            if (responsibility == true)
            {
                //IQueryCollection query = Request?.Query;
                var users = await _userService.ListResponsibilityAsync();//query);
                return Ok(users);
            }
            else

            {
                //IQueryCollection query = Request?.Query;
                var users = await _userService.ListAuthenAsync();//query);
                return Ok(users);
            }

        }
        [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
        [EnableCors("AllowCores")]
        [Route("synce")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<User>), StatusCodes.Status200OK)]
        public async Task<IActionResult> SynceAsync()
        {
            //IQueryCollection query = Request?.Query;
            var users = await _userService.SynceAsync();//query);
            return Ok(users);
        }



        [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
        [EnableCors("AllowCores")]
        [Route("register")]
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<User>), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BatchRegisterAsync([FromBody]List<User> users)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _userService.BatchRegisterAsync(users);
            return Ok(entity);
        }

        [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
        [EnableCors("AllowCores")]
        [Route("remove")]
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<User>), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BatchRemoveAsync([FromBody]List<User> users)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _userService.BatchRemoveAsync(users);
            return Ok(entity);
        }



    }
}
