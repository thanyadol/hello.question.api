using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Authentication;

//logg
using Serilog;

//services
using surflex.netcore22.Models;
using surflex.netcore22.Services;
using surflex.netcore22.Exceptions;
using System.IO;
using System.Net.Http;
using surflex.netcore22.Model.Filters;

namespace surflex.netcore22.Controllers
{
    //[Authorize]
    [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
    [ApiVersion("1.0")]
    [Route("api/{version:apiVersion}/[controller]")]
    [ApiController]
    public class AttachmentController : ControllerBase
    {
        private readonly IAttachmentService _attachmentService;

        public AttachmentController(IAttachmentService attachmentService)
        {
            _attachmentService = attachmentService ?? throw new ArgumentNullException(nameof(attachmentService));

        }

        [EnableCors("AllowCores")]
        [Route("list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Attachment>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListAsync()
        {
            var attachments = await _attachmentService.ListAsync();
            return Ok(attachments);
        }

        [EnableCors("AllowCores")]
        [Route("get")]
        [HttpGet]
        [ProducesResponseType(typeof(Attachment), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Attachment), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAsync(string id)
        {
            //change to encrypted
            var attach = await _attachmentService.GetAsync(id);
            if (attach == null)
            {
                throw new AttachmentNotFoundException();
            }

            attach = await _attachmentService.AesEncryptAsync(attach);
            return Ok(attach);
        }

        [EnableCors("AllowCores")]
        [Route("post")]
        [HttpPost]
        [ProducesResponseType(typeof(Attachment), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateAsync([FromBody]Attachment attachment)
        {
            Log.Information("CreateAsync Attachment.Path {0}", attachment.Path);
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _attachmentService.CreateAsync(attachment);

            return CreatedAtAction(
                nameof(CreateAsync),
                entity
            );
        }


    }
}
