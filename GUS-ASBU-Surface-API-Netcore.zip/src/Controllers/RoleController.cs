using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Authentication;

//logg
using Serilog;

//service
using surflex.netcore22.Models;
using surflex.netcore22.Services;
using surflex.netcore22.Exceptions;
using System.Security.Claims;
using surflex.netcore22.Model.Filters;
//using surflex.netcore22.Model.Filters;

namespace surflex.netcore22.Controllers
{

    [ApiVersion("1.0")]
    [Route("api/{version:apiVersion}/[controller]")]
    [ApiController]
    public class RoleController : ControllerBase
    {
        // private readonly IApiService _apiService;
        private readonly IRoleService _rollService;
        private readonly IRoleUserService _rollUserService;
        //   private readonly IHttpContextAccessor _httpContextAccessor;
        // private readonly UserManager<ApplicationUser> _userManager;

        public RoleController(IRoleService rollService, IRoleUserService rollUserService)//, IApiService apiService)// IHttpContextAccessor httpContextAccessor)
        {
            //_apiService = apiService ?? throw new ArgumentNullException(nameof(apiService));

            _rollService = rollService ?? throw new ArgumentNullException(nameof(rollService));
            _rollUserService = rollUserService ?? throw new ArgumentNullException(nameof(rollUserService));


            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();

        }



        ////[Authorize]
        //[AllowAnonymous]
        [EnableCors("AllowCores")]
        [Route("authorize")]
        [HttpPost]
        [ProducesResponseType(typeof(User), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> AuthorizeAsync([FromBody]Token token)
        {
            //var accessToken = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];

            var user = await _rollService.AuthorizeAsync(token);
            return Ok(user);
        }

        [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
        [EnableCors("AllowCores")]
        [Route("list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Role>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> ListAsync()
        {
            //var accessToken = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];

            var user = await _rollService.ListAsync();
            return Ok(user);
        }


        [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
        [EnableCors("AllowCores")]
        [Route("authorize/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<RoleAuthorize>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> ListAuthorizeAsync()
        {
            //var accessToken = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];

            var user = await _rollService.ListAuthorizeAsync();
            return Ok(user);
        }


        [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
        [EnableCors("AllowCores")]
        [Route("authorize/recent")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<RoleAuthorize>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> ListRecentlyAuthorizeAsync(string id = null)
        {
            //var accessToken = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];

            var user = await _rollUserService.ListRecentlyAuthorizeAsync(id);
            return Ok(user);
        }


        [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
        [EnableCors("AllowCores")]
        [Route("authorize/post")]
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<RoleAuthorize>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BatchCreateAsynce([FromBody]IEnumerable<RoleAuthorize> rolls)
        {
            //var accessToken = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];

            var user = await _rollUserService.BatchCreateAsynce(rolls);
            return Ok(user);
        }


    }
}