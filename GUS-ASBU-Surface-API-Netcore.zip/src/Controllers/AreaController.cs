using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Authentication;

//logg
using Serilog;

//services
using surflex.netcore22.Models;
using surflex.netcore22.Services;
using surflex.netcore22.Exceptions;

namespace surflex.netcore22.Controllers
{
    [Authorize]
    [ApiVersion("1.0")]
    [Route("api/{version:apiVersion}/[controller]")]
    [ApiController]
    public class AreaController : ControllerBase
    {
        private readonly IAreaService _areaService;

        public AreaController(IAreaService areaService)
        {
            _areaService = areaService ?? throw new ArgumentNullException(nameof(areaService));

        }

        [EnableCors("AllowCores")]
        [Route("list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Area>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListAsync()
        {
            var areas = await _areaService.ListAsync();
            return Ok(areas);
        }

        [EnableCors("AllowCores")]
        [Route("get")]
        [HttpGet]
        [ProducesResponseType(typeof(Area), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Area), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAsync(string id)
        {
            var area = await _areaService.GetAsync(id);

            if (area == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(area);
            }
        }

        [EnableCors("AllowCores")]
        [Route("location/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Item>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> ListLocationAsync()
        {
            //var accessToken = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];

            var user = await _areaService.ListLocationAsync();
            return Ok(user);
        }


    }
}
