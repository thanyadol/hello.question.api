﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Serilog;
using surflex.netcore22.Exceptions;
using surflex.netcore22.Model.Filters;
using surflex.netcore22.Models;
using surflex.netcore22.Services;
using System; 

using System.Collections.Generic;
using System.Threading.Tasks;

namespace surflex.netcore22.Controllers
{
    [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
    [ApiVersion("1.0")]
    [Route("api/{version:apiVersion}/[controller]")]
    [ApiController]
    public class DecisionController : ControllerBase
    {
        private readonly IDecisionService _decisionService;

        public DecisionController(IDecisionService decisionService)
        {
            _decisionService = decisionService ?? throw new ArgumentNullException(nameof(decisionService));

            Log.Logger = new LoggerConfiguration()
                .WriteTo.Console()
                .CreateLogger();
        }

        ////[Authorize]
        [AllowAnonymous]
        [EnableCors("AllowCores")]
        [Route("template/get")]
        [HttpGet]
        [ProducesResponseType(typeof(PresetWellScenarioParams), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetTemplateAsync(Guid id)
        {
            try
            {
                var res = await _decisionService.GetTemplateTreeAsync(id);
                return Ok(res);
            }
            catch (WellScenarioNotFoundException ex)
            {
                Log.Error(ex, String.Empty);
                return NotFound(ex);
            }
            catch (Exception ex)
            {
                Log.Error(ex, String.Empty);
                return BadRequest(ex);
            }
        }

        ////[Authorize]
        [AllowAnonymous]
        [EnableCors("AllowCores")]
        [Route("template/update")]
        [HttpPost]
        [ProducesResponseType(typeof(PresetWellScenarioParams), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> UpdateTemplateAsync([FromBody]PresetWellScenarioParams tab)
        {
            try
            {
                var res = await _decisionService.UpdateTemplateTreeAsync(tab);
                return CreatedAtAction(nameof(UpdateTemplateAsync), res);
            }
            catch (WellScenarioNotFoundException ex)
            {
                Log.Error(ex, String.Empty);
                return NotFound(ex);
            }
            catch (Exception ex)
            {
                Log.Error(ex, String.Empty);
                return BadRequest(ex);
            }
        }

        ////[Authorize]
        [AllowAnonymous]
        [EnableCors("AllowCores")]
        [Route("tree/get")]
        [HttpGet]
        [ProducesResponseType(typeof(WellScenarioParams), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetTreeAsync(Guid tabId)
        {
            try
            {
                var res = await _decisionService.GetTreeByTabIdAsync(tabId);
                return Ok(res);
            }
            catch (WellScenarioNotFoundException ex)
            {
                Log.Error(ex, String.Empty);
                return NotFound(ex);
            }
            catch (Exception ex)
            {
                Log.Error(ex, String.Empty);
                return BadRequest(ex);
            }
        }

        ////[Authorize]
        [AllowAnonymous]
        [EnableCors("AllowCores")]
        [Route("tree/save")]
        [HttpPost]
        [ProducesResponseType(typeof(WellScenarioParams), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> SaveTreeAsync([FromBody]WellScenarioParams tab)
        {
            try
            {
                var res = await _decisionService.SaveTreeAsync(tab);
                return CreatedAtAction(nameof(SaveTreeAsync), res);
            }
            catch (WellScenarioNotFoundException ex)
            {
                Log.Error(ex, String.Empty);
                return NotFound(ex);
            }
            catch (Exception ex)
            {
                Log.Error(ex, String.Empty);
                return BadRequest(ex);
            }
        }

        ////[Authorize]
        [AllowAnonymous]
        [EnableCors("AllowCores")]
        [Route("get")]
        [HttpGet]
        [ProducesResponseType(typeof(DecisionResultDto), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetDecisionAsync(Guid tabId)
        {
            try
            {
                var res = await _decisionService.GetDecisionAsync(tabId);
                return Ok(res);
            }
            catch (WellScenarioNotFoundException ex)
            {
                Log.Error(ex, String.Empty);
                return NotFound(ex);
            }
            catch (Exception ex)
            {
                Log.Error(ex, String.Empty);
                return BadRequest(ex);
            }
        }

        ////[Authorize]
        [AllowAnonymous]
        [EnableCors("AllowCores")]
        [Route("get/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<DecisionResultDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetDecisionListAsync(string wellName)
        {
            try
            {
                var res = await _decisionService.GetDecisionListAsync(wellName);
                return Ok(res);
            }
            catch (WellScenarioNotFoundException ex)
            {
                Log.Error(ex, String.Empty);
                return NotFound(ex);
            }
            catch (Exception ex)
            {
                Log.Error(ex, String.Empty);
                return BadRequest(ex);
            }
        }

        ////[Authorize]
        [AllowAnonymous]
        [EnableCors("AllowCores")]
        [Route("save")]
        [HttpPost]
        [ProducesResponseType(typeof(DecisionResultDto), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> SaveDecisionAsync([FromBody]DecisionResultDto decision)
        {
            try
            {
                var res = await _decisionService.SaveDecisionAsync(decision);
                return Ok(res);
            }
            catch (WellScenarioNotFoundException ex)
            {
                Log.Error(ex, String.Empty);
                return NotFound(ex);
            }
            catch (Exception ex)
            {
                Log.Error(ex, String.Empty);
                return BadRequest(ex);
            }
        }

        ////[Authorize]
        [AllowAnonymous]
        [EnableCors("AllowCores")]
        [Route("publish")]
        [HttpPost]
        [ProducesResponseType(typeof(DecisionResultDto), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> PublishDecisionAsync([FromBody]DecisionResultDto decision)
        {
            try
            {
                var res = await _decisionService.PublishDecisionAsync(decision);
                return Ok(res);
            }
            catch (WellScenarioNotFoundException ex)
            {
                Log.Error(ex, String.Empty);
                return NotFound(ex);
            }
            catch (Exception ex)
            {
                Log.Error(ex, String.Empty);
                return BadRequest(ex);
            }
        }

        ////[Authorize]
        [AllowAnonymous]
        [EnableCors("AllowCores")]
        [Route("delete")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> DeleteDecisionAsync([FromBody]WellScenarioParams tab)
        {
            try
            {
                await _decisionService.DeleteDecisionAsync(tab.TabId.Value);
                return Ok();
            }
            catch (WellScenarioNotFoundException ex)
            {
                Log.Error(ex, String.Empty);
                return NotFound(ex);
            }
            catch (Exception ex)
            {
                Log.Error(ex, String.Empty);
                return BadRequest(ex);
            }
        }
    }
}
