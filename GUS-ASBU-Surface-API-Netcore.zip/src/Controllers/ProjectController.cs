using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


//service
using surflex.netcore22.Models;
using surflex.netcore22.Services;
using surflex.netcore22.Model.Filters;

namespace surflex.netcore22.Controllers
{
    [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
    [ApiVersion("1.0")]
    [Route("api/{version:apiVersion}/[controller]")]
    [ApiController]
    public class ProjectController : ControllerBase
    {
        private readonly IProjectService _projectService;
        private readonly IProjectWellService _projectWellService;
        private readonly IProjectUserService _projectUserService;
        public ProjectController(IProjectService projectService, IProjectWellService projectWellService, IProjectUserService projectUserService) //, IProjectAttributeService projectAttributeService)
        {
            _projectWellService = projectWellService ?? throw new ArgumentNullException(nameof(projectWellService));
            _projectUserService = projectUserService ?? throw new ArgumentNullException(nameof(projectUserService));

            _projectService = projectService ?? throw new ArgumentNullException(nameof(projectService));
            //  _projectAttributeService = projectAttributeService ?? throw new ArgumentNullException(nameof(projectAttributeService));

        }


        [EnableCors("AllowCores")]
        [Route("location/recent")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<ProjectLocation>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> ListRecentlyLocationAsync()
        {
            //var accessToken = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];

            var user = await _projectService.ListRecentlyLocationAsync();
            return Ok(user);
        }


        [EnableCors("AllowCores")]
        [Route("location/post")]
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<ProjectLocation>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateLocationAsync([FromBody]ProjectLocation located)
        {
            //var accessToken = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];

            var user = await _projectService.CreateAsync(located);
            return Ok(user);
        }



        [EnableCors("AllowCores")]
        [Route("list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Project>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListAsync(bool responsibility = false)
        {

            if (responsibility == true)
            {
                //var projects = await _projectService.ListActiveAsync();

                var projects = await _projectService.ListResponsibilityAsync();
                return Ok(projects);
            }
            else

            {
                //var projects = await _projectService.ListActiveAsync();

                var projects = await _projectService.ListAsync();
                return Ok(projects);
            }



        }



        [EnableCors("AllowCores")]
        [Route("synce")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Project>), StatusCodes.Status200OK)]
        public async Task<IActionResult> SynceAsync()
        {
            //var projects = await _projectService.ListActiveAsync();

            var projects = await _projectService.ListProductiveAsync();
            return Ok(projects);

        }

        [EnableCors("AllowCores")]
        [Route("get")]
        [HttpGet]
        [ProducesResponseType(typeof(Project), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Project), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAsync(string id)
        {
            var project = await _projectService.GetAsync(id);
            return Ok(project);
        }

        [EnableCors("AllowCores")]
        [Route("well/count")]
        [HttpGet]
        [ProducesResponseType(typeof(int), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(int), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetTotalPlannedWellAsync(string name)
        {
            var well = await _projectWellService.CountPlannedWellAsync(name);
            return Ok(well);
        }


        [EnableCors("AllowCores")]
        [Route("attribute/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<ProjectAttribute>), StatusCodes.Status200OK)]
        public async Task<IActionResult> LisAttributeAsync(string status = null)
        {
            //var projects = await _projectService.ListActiveAsync();

            var projects = await _projectService.ListAttributeAsync(status);
            return Ok(projects);

        }

        [EnableCors("AllowCores")]
        [Route("attribute/get")]
        [HttpGet]
        [ProducesResponseType(typeof(ProjectAttribute), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProjectAttribute), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetCurrentlyAttributeAsync(string name)
        {
            var entity = await _projectWellService.GetCurrentlyAttributeAsync(name);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("attribute/post")]
        [HttpPost]
        [ProducesResponseType(typeof(ProjectAttribute), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateAttributeAsync([FromBody]ProjectAttribute attr)
        {
            if (String.IsNullOrEmpty(attr.ProjectName))
            {
                return BadRequest(ModelState);
            }

            var entity = await _projectService.CreateAsync(attr);

            return CreatedAtAction(
                nameof(CreateAttributeAsync),
                entity
            );
        }


        [EnableCors("AllowCores")]
        [Route("well/recent")]
        [HttpGet]
        [ProducesResponseType(typeof(ProjectWell), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetWellRecentlyAsync(int id, string name)
        {
            var entity = await _projectService.GetWellRecentlyAsync(id, name, true);
            return Ok(entity);

        }

        [EnableCors("AllowCores")]
        [Route("well/publish")]
        [HttpPost]
        [ProducesResponseType(typeof(ProjectWell), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> PublishSpaceAsync(string id)
        {
            var entity = await _projectService.PublishSpaceAsync(id);
            return Ok(entity);

        }

        [EnableCors("AllowCores")]
        [Route("dpi/publish")]
        [HttpPost]
        [ProducesResponseType(typeof(ProjectWell), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> _PublishSpaceAsync(string id)
        {
            var entity = await _projectService.PublishSpaceAsync(id);
            return Ok(entity);

        }


        [EnableCors("AllowCores")]
        [Route("well/synce")]
        [HttpGet]
        [ProducesResponseType(typeof(ProjectWellParams), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> SynceWellAsync(int id, string name)
        {
            var entity = await _projectService.SynceWellAsync(id, name);
            return Ok(entity);

        }


        [EnableCors("AllowCores")]
        [Route("well/post")]
        [HttpPost]
        [ProducesResponseType(typeof(ProjectWell), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BatchCreateAsync(ProjectWell orm)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _projectService.BatchCreateAsync(orm);
            return Ok(entity);

        }



        [EnableCors("AllowCores")]
        [Route("planned")]
        [HttpGet]
        [ProducesResponseType(typeof(ProjectWell), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetPlannedWellAsync(string name, int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _projectService.GetPlannedWellAsync(name, id);
            return Ok(entity);
        }



        [EnableCors("AllowCores")]
        [Route("productive")]
        [HttpGet]
        [ProducesResponseType(typeof(ProjectWell), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetProductiveWellAsync(string name, int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _projectService.GetProductiveWellAsync(name, id);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("reserve")]
        [HttpGet]
        [ProducesResponseType(typeof(ProjectWellParams), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetReserveWellAsync(string name, int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _projectService.GetReserveWellAsync(name, id);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("dpi/init")]
        [HttpGet]
        [ProducesResponseType(typeof(ProjectWell), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> InitialReserveParamsAsync(string name, int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _projectService.InitialReserveParamsAsync(name, id);
            return Ok(entity);
        }


        /* [EnableCors("AllowCores")]
        [Route("dpi/product")]
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<ProductionProfileParams>), StatusCodes.Status200OK)]
        public async Task<IActionResult> EstimateMonthlyProductAsync([FromBody]WellEvaluateParams param)
        {
            var sands = await _projectWellService.EstimateMonthlyProductAsync(param);
            return Ok(sands);
        }*/

        [EnableCors("AllowCores")]
        [Route("dpi/evaluate")]
        [HttpPost]
        [ProducesResponseType(typeof(ProjectEvaluateParams), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> EvaluateMasterDPIAsync(ProjectEvaluateParams parameters)
        {
            if (String.IsNullOrEmpty(parameters.ProjectName))
            {
                return BadRequest(ModelState);
            }

            var entity = await _projectService.EvaluateMasterDPIAsync(parameters);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("dpi/post")]
        [HttpPost]
        [ProducesResponseType(typeof(ProjectDrilled), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BatchCreateAsync(ProjectDrilled drilled)
        {

            var entity = await _projectService.BatchCreateAsync(drilled);
            return Ok(entity);
        }

        [EnableCors("AllowCores")]
        [Route("dpi/recent")]
        [HttpGet]
        [ProducesResponseType(typeof(ProjectDrilled), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetDrilledRecentlyAsync(string name)
        {
            if (String.IsNullOrEmpty(name))
            {
                return BadRequest(ModelState);
            }

            var entity = await _projectWellService.GetDrilledRecentlyAsync(name);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("dpi/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<ProjectDrilled>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> ListDrilledAsync()
        {
            var entity = await _projectService.ListDrilledAsync();
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("dpi/template/validate")]
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<Attachment>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> ValidateMasterDPITemplateAsync([FromBody]Attachment attachment)
        {
            await _projectService.ValidateMasterDPITemplateAsync(attachment);
            attachment.Value = null;

            return Ok(true);
        }


        [EnableCors("AllowCores")]
        [Route("dpi/validate")]
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<Attachment>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> ValidateMasterDPIAsync([FromBody]Attachment attachment)
        {
            await _projectService.ValidateMasterDPIAsync(attachment);
            attachment.Value = null;

            return Ok(attachment);
        }


        [EnableCors("AllowCores")]
        [Route("well/pay")]
        [HttpGet]
        [ProducesResponseType(typeof(ProjectPayParams), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetPayAsync(string name, int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _projectService.GetPayAsync(name, id);
            return Ok(entity);
        }



        [EnableCors("AllowCores")]
        [Route("well/reserve")]
        [HttpGet]
        [ProducesResponseType(typeof(ProjectPayParams), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetReserveAsync(string name, int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _projectService.GetReserveAsync(name, id);
            return Ok(entity);
        }

        [EnableCors("AllowCores")]
        [Route("well/rig")]
        [HttpGet]
        [ProducesResponseType(typeof(ProjectPayParams), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetRiggAsync(string name, int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _projectService.GetRiggAsync(name, id);
            return Ok(entity);
        }


        ////[Authorize]
        //[AllowAnonymous]
        /* *[EnableCors("AllowCores")]
        [Route("authorize")]
        [HttpPost]
        [ProducesResponseType(typeof(User), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> AuthorizeAsync([FromBody]Token token)
        {
            //var accessToken = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];

            var user = await _projectService.AuthorizeAsync(token);
            return Ok(user);
        }*/


        ////[Authorize]
        //[AllowAnonymous]
        // [EnableCors("AllowCores")]
        // [Route("authorize/recent")]
        // [HttpGet]
        // [ProducesResponseType(typeof(IEnumerable<RoleAuthorize>), StatusCodes.Status200OK)]
        // [ProducesResponseType(StatusCodes.Status400BadRequest)]
        // public async Task<IActionResult> ListAuthorizeAsync()
        // {
        //     //var accessToken = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];

        //     var user = await _projectUserService.ListRecentlyAuthorizeAsync();
        //     return Ok(user);
        // }




        ////[Authorize]
        //[AllowAnonymous]
        [EnableCors("AllowCores")]
        [Route("authorize/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Project>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> ListAuthorizeAsync()
        {
            //var accessToken = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];

            var user = await _projectService.ListAuthorizeAsync();
            return Ok(user);
        }



        ////[Authorize]
        //[AllowAnonymous]
        [EnableCors("AllowCores")]
        [Route("authorize/post")]
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<ProjectAuthorize>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BatchCreateAsynce([FromBody]IEnumerable<ProjectAuthorize> rolls)
        {
            //var accessToken = _httpContextAccessor.HttpContext.Request.Headers["Authorization"];

            var user = await _projectUserService.BatchCreateAsynce(rolls);
            return Ok(user);
        }

    }
}
