using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Authentication;

//logg
using Serilog;

//services
using surflex.netcore22.Models;
using surflex.netcore22.Services;
using surflex.netcore22.Exceptions;
using surflex.netcore22.Model.Filters;

namespace surflex.netcore22.Controllers
{
    [Authorize]
    [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
    [ApiVersion("1.0")]
    [Route("api/{version:apiVersion}/[controller]")]
    [ApiController]
    public class ProductionController : ControllerBase
    {
        private readonly IProductionService _productionService;

        public ProductionController(IProductionService productionService)
        {
            _productionService = productionService ?? throw new ArgumentNullException(nameof(productionService));

        }

        [EnableCors("AllowCores")]
        [Route("list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Production>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListAsync(string status = null)
        {
            var productions = await _productionService.ListAsync(status);
            return Ok(productions);
        }

        [EnableCors("AllowCores")]
        [Route("get")]
        [HttpGet]
        [ProducesResponseType(typeof(Production), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Production), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAsync(string id)
        {
            var production = await _productionService.GetAsync(id);

            if (production == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(production);
            }
        }

        [EnableCors("AllowCores")]
        [Route("post")]
        [HttpPost]
        [ProducesResponseType(typeof(Production), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateAsync([FromBody]Production production)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var createProduction = await _productionService.CreateAsync(production);

            return CreatedAtAction(
                nameof(CreateAsync),
                createProduction
            );
        }


        /// prfile
        [EnableCors("AllowCores")]
        [Route("profile/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<ProductionProfile>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListProfileAsync()
        {
            var profiles = await _productionService.ListProfileAsync();
            return Ok(profiles);
        }

        [EnableCors("AllowCores")]
        [Route("profile/get")]
        [HttpGet]
        [ProducesResponseType(typeof(ProductionProfile), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProductionProfile), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetProfileAsync(string id)
        {
            var profile = await _productionService.GetProfileAsync(id);

            if (profile == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(profile);
            }
        }



        //params
        [EnableCors("AllowCores")]
        [Route("params/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<ProductionParam>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListParamsAsync(string id = null)
        {
            var profiles = await _productionService.ListParamsAsync(id);
            return Ok(profiles);
        }

        [EnableCors("AllowCores")]
        [Route("params/get")]
        [HttpGet]
        [ProducesResponseType(typeof(ProductionParam), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProductionParam), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetParamsAsync(string id)
        {
            var profile = await _productionService.GetParamsAsync(id);

            if (profile == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(profile);
            }
        }



        //params
        [EnableCors("AllowCores")]
        [Route("model/applicable")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Item>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListApplicableModelAsync()
        {
            var profiles = await _productionService.ListApplicableModelAsync();
            return Ok(profiles);
        }


        //params
        [EnableCors("AllowCores")]
        [Route("model/available")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Item>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAvailableApplicableModel(string id)
        {
            var profiles = await _productionService.GetAvailableApplicableModel(id);
            return Ok(profiles);
        }


    }
}
