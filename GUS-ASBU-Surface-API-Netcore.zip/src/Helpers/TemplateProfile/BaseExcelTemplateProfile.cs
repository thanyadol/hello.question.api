﻿using FluentValidation;
using surflex.netcore22.Exceptions;
using surflex.netcore22.Helpers.DataHandler;
using System; 

using System.Collections.Generic;
using System.Linq;

namespace surflex.netcore22.Helpers.TemplateProfile
{
    public class BaseExcelTemplateProfile : IExcelProfile
    {
        public static Dictionary<string, string> LABELS = new Dictionary<string, string>
        {
        };

        public static Dictionary<string, string> ADDRESSES = new Dictionary<string, string>
        {
        };

        protected ICollection<IExcelProfileDefinition> Definitions;

        protected ICollection<Range> CellsData;

        public IExcelEngine DataEngine { get; set; }

        public BaseExcelTemplateProfile()
        {

        }

        public BaseExcelTemplateProfile(IExcelEngine excel)
        {
            DataEngine = excel;
        }

        public virtual ICollection<Range> GetData() => CellsData;

        public virtual IExcelProfileDefinition GetDefinition(string definition)
        {
            return Definitions.FirstOrDefault(x => x.Key == definition);
        }

        public virtual ICollection<IExcelProfileDefinition> GetDefinitions()
        {
            return Definitions;
        }

        public virtual ICollection<IExcelProfileDefinition> GetDefinitions(string definition)
        {
            throw new NotImplementedException();
        }

        public virtual void ClearDefinitions()
        {
            Definitions = new HashSet<IExcelProfileDefinition>();
        }

        public virtual void SetInstance(IExcelEngine excel)
        {
            DataEngine = excel;
        }

        public virtual void Execute()
        {
            var errors = new List<string>();
            foreach (var definition in Definitions)
            {
                try
                {
                    if (definition.Mode != ExcelProfileDefinitionMode.Validate && errors.Count > 0)
                        throw new ExcelValidationException(errors);

                    definition.Execute(DataEngine);
                }
                catch (ExcelValidationException ex)
                {
                    errors.Add(ex.Message);
                }
            }
            if (errors.Count > 0)
                throw new ExcelValidationException(errors);
        }

        public virtual void AddDefinition(ExcelTemplateProfileDefinition definition)
        {
            if (Definitions == null) Definitions = new HashSet<IExcelProfileDefinition>();

            Definitions.Add(definition);
        }

        protected virtual void AddDefinition(string sheetName, string cellRange, string label, string key, ExcelValidation validation = null, ExcelProfileDefinitionMode? mode = null)
        {
            var definition = new ExcelTemplateProfileDefinition
            {
                Mode = mode ?? ExcelProfileDefinitionMode.Validate,
                SheetName = sheetName,
                CellRange = cellRange,
                Label = label,
                Key = key,
                Validation = validation ?? new ExcelValidation(),
            };

            definition.Validation.SheetName = sheetName;
            definition.Validation.Label = label;
            definition.Validation.CellRange = cellRange;

            AddDefinition(definition);
        }

        protected virtual void AddDefinition(string sheetName, string cellRange, string label)
        {
            AddDefinition(sheetName, cellRange, label, null, null, null);
        }

        protected virtual void AddDefinition(string sheetName, string cellRange, string label, ExcelValidation validation = null)
        {
            AddDefinition(sheetName, cellRange, label, null, validation, null);
        }

        protected virtual void AddDefinition(string sheetName, string cellRange, string label, ExcelProfileDefinitionMode? mode = null)
        {
            AddDefinition(sheetName, cellRange, label, null, null, mode);
        }

        protected virtual void AddDefinition(string sheetName, string cellRange, string label, string key)
        {
            AddDefinition(sheetName, cellRange, label, key, null, null);
        }

        protected virtual void AddDefinition(string sheetName, string cellRange, string label, string key, ExcelProfileDefinitionMode? mode = null)
        {
            AddDefinition(sheetName, cellRange, label, key, null, mode);
        }

        public virtual string GetVersion()
        {
            return "base";
        }

        ICollection<IProfileDefinition> IDataProfile.GetDefinitions() => (ICollection<IProfileDefinition>)GetDefinitions();

        IProfileDefinition IDataProfile.GetDefinition(string definition) => GetDefinition(definition);
    }

    public class ExcelTemplateProfileDefinition : IExcelProfileDefinition
    {
        public IExcelEngine DataEngine { get; set; }

        public ExcelProfileDefinitionMode Mode { get; set; } = ExcelProfileDefinitionMode.Read;

        public string Key { get; set; }

        public string Label { get; set; }

        public string Description { get; set; }

        public string SheetName { get; set; }

        public string CellRange { get; set; }

        public ICollection<IExcelProfileDefinitionProperties> Datasource { get; set; }

        public IExcelRange Results { get; set; }

        public IExcelValidation<IExcelRange> Validation { get; set; }

        public ExcelTemplateProfileDefinition()
        {
        }

        public ExcelTemplateProfileDefinition(IExcelEngine excel)
        {
            DataEngine = excel;
        }

        public void Execute(IExcelEngine excel)
        {
            DataEngine = excel;
            Execute();
        }

        public void Execute()
        {
            if (DataEngine == null) throw new InvalidOperationException("Excel engine is not initialized.");

            if (Mode == ExcelProfileDefinitionMode.Recalculate)
            {
                Recalculate();
            }
            else if (Mode == ExcelProfileDefinitionMode.Validate)
            {
                Validate();
            }
            else if (Mode == ExcelProfileDefinitionMode.Read)
            {
                Read();
            }
            else if (Mode == ExcelProfileDefinitionMode.Write)
            {
                Write();
            }
            else if (Mode == ExcelProfileDefinitionMode.WriteFirstHorizontal || Mode == ExcelProfileDefinitionMode.WriteFirstVertical1Criteria)
            {
                WriteFrist1Criteria();
            }
            else if (Mode == ExcelProfileDefinitionMode.WriteHorizontal || Mode == ExcelProfileDefinitionMode.WriteVertical1Criteria)
            {
                Write1Criteria();
            }
            else if (Mode == ExcelProfileDefinitionMode.WriteVertical2Criterion)
            {
                Write2Criterion();
            }
            else if (Mode == ExcelProfileDefinitionMode.AppendFormula)
            {
                AppendFormula();
            }
            else if (Mode == ExcelProfileDefinitionMode.AppendFormula1Criteria)
            {
                AppendFormula1Criteria();
            }
            else if (Mode == ExcelProfileDefinitionMode.Clear)
            {
                Clear();
            }
            else if (Mode == ExcelProfileDefinitionMode.Clear1Criteria)
            {
                Clear1Criteria();
            }
        }

        public virtual void Recalculate()
        {
            DataEngine.Calculate();
        }

        public virtual void Validate()
        {
            Read(true);
        }

        public virtual void Read(bool withValidation = false)
        {
            if (DataEngine == null) throw new InvalidOperationException("Excel engine is not initialized.");

            var workSheet = DataEngine.GetWorksheet(SheetName);
            if (workSheet == null) throw new InvalidOperationException("Given worksheet cannot be found.");

            Results = workSheet.GetRange(CellRange);

            if (withValidation) Validation?.Validate(Results);
        }

        public virtual void Write()
        {
            if (DataEngine == null) throw new InvalidOperationException("Excel engine is not initialized.");

            var workSheet = DataEngine.GetWorksheet(SheetName);
            if (workSheet == null) throw new InvalidOperationException("Given worksheet cannot be found.");

            foreach (var data in Datasource)
            {
                if (string.IsNullOrEmpty(data.RangeAddress))
                    throw new ArgumentNullException("Target cell address is not configured.");

                workSheet.Write(data.RangeAddress, data.Value);
            }
        }

        public virtual void WriteFrist1Criteria()
        {
            if (DataEngine == null) throw new InvalidOperationException("Excel engine is not initialized.");

            var workSheet = DataEngine.GetWorksheet(SheetName);
            if (workSheet == null) throw new InvalidOperationException("Given worksheet cannot be found.");

            foreach (var data in Datasource)
            {
                if (string.IsNullOrEmpty(data.ColumnCriteriaText) || string.IsNullOrEmpty(data.ColumnCriteriaRangeAddress) ||
                    string.IsNullOrEmpty(data.RowCriteriaText) || string.IsNullOrEmpty(data.RowCriteriaRangeAddress))
                    throw new ArgumentNullException("Reference cell addresses are not configured.");

                var matchedColumn = workSheet.FindFirst(data.ColumnCriteriaText, data.ColumnCriteriaRangeAddress);
                if (matchedColumn == null) throw new InvalidOperationException(string.Format("Cannot find a reference cell for \"{0}\" that is \"{1}\" from \"{2}\".", data.ColumnCriteriaLabel, data.ColumnCriteriaText, data.ColumnCriteriaRangeAddress));

                var matchedRow = workSheet.FindFirst(data.RowCriteriaText, data.RowCriteriaRangeAddress);
                if (matchedRow == null) throw new InvalidOperationException(string.Format("Cannot find a reference cell for \"{0}\" that is \"{1}\" from \"{2}\".", data.RowCriteriaLabel, data.RowCriteriaText, data.RowCriteriaRangeAddress));

                var address = string.Format("{0}{1}", ExcelUtility.GetExcelColumnName(matchedColumn.Column), matchedRow.Row);
                workSheet.Write(address, data.Value);
            }
        }

        public virtual void Write1Criteria()
        {
            if (DataEngine == null) throw new InvalidOperationException("Excel engine is not initialized.");

            var workSheet = DataEngine.GetWorksheet(SheetName);
            if (workSheet == null) throw new InvalidOperationException("Given worksheet cannot be found.");

            foreach (var data in Datasource)
            {
                if (string.IsNullOrEmpty(data.ColumnCriteriaRangeAddress) || string.IsNullOrEmpty(data.RowCriteriaRangeAddress))
                    throw new ArgumentNullException("Reference cell addresses are not configured.");

                var matchedColumns = workSheet.Find(data.ColumnCriteriaIncludedText, data.ColumnCriteriaExcludedText, data.ColumnCriteriaRangeAddress);
                if (matchedColumns == null || matchedColumns?.Count() == 0) throw new InvalidOperationException(string.Format("Cannot find a reference cell for \"{0}\" that is \"{1}\" from \"{2}\".", data.ColumnCriteriaLabel, data.ColumnCriteriaText, data.ColumnCriteriaRangeAddress));

                var _matchedColumns = matchedColumns.GroupBy(x => x.Column).Select(group => group.FirstOrDefault());

                var matchedRows = workSheet.Find(data.RowCriteriaIncludedText, data.RowCriteriaExcludedText, data.RowCriteriaRangeAddress);
                if (matchedRows == null || matchedRows?.Count() == 0) throw new InvalidOperationException(string.Format("Cannot find a reference cell for \"{0}\" that is \"{1}\" from \"{2}\".", data.RowCriteriaLabel, data.RowCriteriaText, data.RowCriteriaRangeAddress));

                var _matchedRows = matchedRows.GroupBy(x => x.Row).Select(group => group.FirstOrDefault());

                foreach (var row in _matchedRows)
                {
                    foreach (var cell in _matchedColumns)
                    {
                        var address = string.Format("{0}{1}", ExcelUtility.GetExcelColumnName(cell.Column), row.Row);
                        workSheet.Write(address, data.Value);
                    }
                }
            }
        }

        public virtual void Write2Criterion()
        {
            throw new NotImplementedException(nameof(Write2Criterion));
        }

        public virtual void AppendFormula()
        {
            if (DataEngine == null) throw new InvalidOperationException("Excel engine is not initialized.");

            var workSheet = DataEngine.GetWorksheet(SheetName);
            if (workSheet == null) throw new InvalidOperationException("Given worksheet cannot be found.");

            foreach (var data in Datasource)
            {
                if (string.IsNullOrEmpty(data.RangeAddress))
                    throw new ArgumentNullException("Target cell address is not configured.");

                workSheet.AppendFormula(data.RangeAddress, data.Formula);
            }
        }

        public virtual void AppendFormula1Criteria()
        {
            if (DataEngine == null) throw new InvalidOperationException("Excel engine is not initialized.");

            var workSheet = DataEngine.GetWorksheet(SheetName);
            if (workSheet == null) throw new InvalidOperationException("Given worksheet cannot be found.");

            foreach (var data in Datasource)
            {
                if (string.IsNullOrEmpty(data.ColumnCriteriaRangeAddress) || string.IsNullOrEmpty(data.RowCriteriaRangeAddress))
                    throw new ArgumentNullException("Reference cell addresses are not configured.");

                var matchedColumns = workSheet.Find(data.ColumnCriteriaIncludedText, data.ColumnCriteriaExcludedText, data.ColumnCriteriaRangeAddress);
                if (matchedColumns == null || matchedColumns?.Count() == 0) throw new InvalidOperationException(string.Format("Cannot find a reference cell for \"{0}\" that is \"{1}\" from \"{2}\".", data.ColumnCriteriaLabel, data.ColumnCriteriaText, data.ColumnCriteriaRangeAddress));

                var _matchedColumns = matchedColumns.GroupBy(x => x.Column).Select(group => group.FirstOrDefault());

                var matchedRows = workSheet.Find(data.RowCriteriaIncludedText, data.RowCriteriaExcludedText, data.RowCriteriaRangeAddress);
                if (matchedRows == null || matchedRows?.Count() == 0) throw new InvalidOperationException(string.Format("Cannot find a reference cell for \"{0}\" that is \"{1}\" from \"{2}\".", data.RowCriteriaLabel, data.RowCriteriaText, data.RowCriteriaRangeAddress));

                var _matchedRows = matchedRows.GroupBy(x => x.Row).Select(group => group.FirstOrDefault());

                foreach (var row in _matchedRows)
                {
                    foreach (var cell in _matchedColumns)
                    {
                        var address = string.Format("{0}{1}", ExcelUtility.GetExcelColumnName(cell.Column), row.Row);
                        workSheet.AppendFormula(address, data.Formula);
                    }
                }
            }
        }

        public virtual void Clear()
        {
            if (DataEngine == null) throw new InvalidOperationException("Excel engine is not initialized.");

            var workSheet = DataEngine.GetWorksheet(SheetName);
            if (workSheet == null) throw new InvalidOperationException("Given worksheet cannot be found.");

            foreach (var data in Datasource)
            {
                if (string.IsNullOrEmpty(data.RangeAddress))
                    throw new ArgumentNullException("Target cell address is not configured.");

                workSheet.Clear(data.RangeAddress);
            }
        }

        public virtual void Clear1Criteria()
        {
            if (DataEngine == null) throw new InvalidOperationException("Excel engine is not initialized.");

            var workSheet = DataEngine.GetWorksheet(SheetName);
            if (workSheet == null) throw new InvalidOperationException("Given worksheet cannot be found.");

            foreach (var data in Datasource)
            {
                if (string.IsNullOrEmpty(data.ColumnCriteriaRangeAddress) || string.IsNullOrEmpty(data.RowCriteriaRangeAddress))
                    throw new ArgumentNullException("Reference cell addresses are not configured.");

                var matchedColumns = workSheet.Find(data.ColumnCriteriaIncludedText, data.ColumnCriteriaExcludedText, data.ColumnCriteriaRangeAddress);
                if (matchedColumns == null || matchedColumns?.Count() == 0) throw new InvalidOperationException(string.Format("Cannot find a reference cell for \"{0}\" that is \"{1}\" from \"{2}\".", data.ColumnCriteriaLabel, data.ColumnCriteriaText, data.ColumnCriteriaRangeAddress));

                var _matchedColumns = matchedColumns.GroupBy(x => x.Column).Select(group => group.FirstOrDefault());

                var matchedRows = workSheet.Find(data.RowCriteriaIncludedText, data.RowCriteriaExcludedText, data.RowCriteriaRangeAddress);
                if (matchedRows == null || matchedRows?.Count() == 0) throw new InvalidOperationException(string.Format("Cannot find a reference cell for \"{0}\" that is \"{1}\" from \"{2}\".", data.RowCriteriaLabel, data.RowCriteriaText, data.RowCriteriaRangeAddress));

                var _matchedRows = matchedRows.GroupBy(x => x.Row).Select(group => group.FirstOrDefault());

                foreach (var row in _matchedRows)
                {
                    foreach (var cell in _matchedColumns)
                    {
                        var address = string.Format("{0}{1}", ExcelUtility.GetExcelColumnName(cell.Column), row.Row);
                        workSheet.Clear(address);
                    }
                }
            }
        }
    }

    public class ExcelProfileDefinitionProperties : IExcelProfileDefinitionProperties
    {
        private ICollection<string> _columnCriteriaIncludedText = new List<string>();

        private ICollection<string> _columnCriteriaExcludedText = new List<string>();

        private ICollection<string> _rowCriteriaIncludedText = new List<string>();

        private ICollection<string> _rowCriteriaExcludedText = new List<string>();

        public string RangeAddress { get; set; }

        public string ColumnCriteriaLabel { get; set; }

        public string ColumnCriteriaText { get; set; }

        public ICollection<string> ColumnCriteriaIncludedText
        {
            get
            {
                if (string.IsNullOrEmpty(ColumnCriteriaLabel))
                {
                    return _columnCriteriaIncludedText;
                }
                else
                {
                    return ColumnCriteriaText == null ? new List<string>() : new List<string>() { ColumnCriteriaText };
                }
            }

            set => _columnCriteriaIncludedText = value;
        }

        public ICollection<string> ColumnCriteriaExcludedText
        {
            get => _columnCriteriaExcludedText;
            set => _columnCriteriaExcludedText = value;
        }

        public string ColumnCriteriaRangeAddress { get; set; }
        
        public string RowCriteriaLabel { get; set; }

        public string RowCriteriaText { get; set; }

        public ICollection<string> RowCriteriaIncludedText
        {
            get
            {
                if (string.IsNullOrEmpty(ColumnCriteriaLabel))
                {
                    return _rowCriteriaIncludedText;
                }
                else
                {
                    return RowCriteriaText == null ? new List<string>() : new List<string>() { RowCriteriaText };
                }
            }

            set => _rowCriteriaIncludedText = value;
        }

        public ICollection<string> RowCriteriaExcludedText
        {
            get => _rowCriteriaExcludedText;
            set => _rowCriteriaExcludedText = value;
        }

        public string RowCriteriaRangeAddress { get; set; }
        
        public object Value { get; set; }

        public string Formula { get; set; }
    }

    public class ValidateRangeObject
    {
        public IExcelRange Range { get; internal set; }

        public string SheetName { get; internal set; }
    }

    public class ExcelValidation : AbstractValidator<ValidateRangeObject>, IExcelValidation<IExcelRange>
    {
        public string SheetName { get; set; }
        public string Label { get; set; }
        public string CellRange { get; set; }

        public bool IsRequired { get; set; } = true;
        public bool IsAllRequired { get; set; } = false;

        public bool IsValid { get; set; } = true;
        public bool IsAllValid { get; set; } = false;

        public ExcelCellType Type { get; set; } = ExcelCellType.Any;

        public ICollection<string> Contains { get; set; } = new HashSet<string>();

        public ICollection<string> PossibleValues { get; set; } = new HashSet<string>();

        public ExcelValidation()
        {
        }

        public ExcelValidation(string sheetName = null, string label = null, bool? isRequired = null, bool? isAllRequired = null, bool? isValid = null, bool? isAllValid = null, string contain = null, string possibleValue = null,
            ExcelCellType? type = null, ICollection<string> contains = null, ICollection<string> possibleValues = null) : base()
        {
            if (sheetName != null)
            {
                SheetName = sheetName;
            }

            if (label != null)
            {
                Label = label;
            }

            if (isRequired != null)
            {
                IsRequired = isRequired.Value;
            }

            if (isAllRequired != null)
            {
                IsAllRequired = isAllRequired.Value;
            }

            if (isValid != null)
            {
                IsValid = isValid.Value;
            }

            if (isAllValid != null)
            {
                IsAllValid = isAllValid.Value;
            }

            if (type != null)
            {
                Type = type.Value;
            }

            if (contains?.Count > 0)
            {
                Contains = new HashSet<string>(contains);
            }

            if (possibleValues?.Count > 0)
            {
                PossibleValues = new HashSet<string>(possibleValues);
            }

            if (contain != null)
            {
                Contains.Add(contain);
            }

            if (possibleValue != null)
            {
                PossibleValues.Add(possibleValue);
            }
        }

        public void Validate(IExcelRange range)
        {
            var data = new ValidateRangeObject() { Range = range };
            Validate(data);
        }

        public new void Validate(ValidateRangeObject data)
        {
            if (IsRequired)
            {
                RuleFor(d => d.Range).NotNull().NotEmpty().WithMessage("Required field missing.");
            }

            if (IsAllRequired)
            {
                RuleForEach(d => d.Range).Must(cell => cell.RawValue != null && cell.Value.Length > 0).WithMessage("Required fields missing.");
            }

            if (IsValid)
            {
                RuleFor(d => d.Range.Any(cell => !ExcelUtility.IsError(cell.Value))).Must(x => x).WithMessage("Field content or formula calculation does not valid.");
            }

            if (IsAllValid)
            {
                RuleForEach(d => d.Range).Must(cell => !ExcelUtility.IsError(cell.Value)).WithMessage("Some field contents or formula calculations do not valid.");
            }

            if (Type == ExcelCellType.DateTime)
            {
                RuleForEach(d => d.Range).Must(cell => cell.RawValue != null && cell.RawValue.GetType() == typeof(DateTime)).WithMessage("Field needs to be in DateTime format.");
            }
            else if (Type == ExcelCellType.Numeric)
            {
                RuleForEach(d => d.Range).Must(cell => cell.RawValue != null && (cell.RawValue.GetType() == typeof(decimal) ||
                    cell.RawValue.GetType() == typeof(double) ||
                    cell.RawValue.GetType() == typeof(float) ||
                    cell.RawValue.GetType() == typeof(int))).WithMessage("Field needs to be in numeric format.");
            }
            else if (Type == ExcelCellType.Percent)
            {
                RuleForEach(d => d.Range).Must(cell => cell.RawValue != null && (cell.RawValue.GetType() == typeof(decimal) ||
                    cell.RawValue.GetType() == typeof(double) ||
                    cell.RawValue.GetType() == typeof(float) ||
                    cell.RawValue.GetType() == typeof(int)) &&
                    cell.Value.EndsWith('%')).WithMessage("Field needs to be in percent format.");
            }
            else if (Type == ExcelCellType.Text)
            {
                RuleForEach(d => d.Range).Must(cell => cell.RawValue != null && cell.RawValue.GetType() == typeof(string)).WithMessage("Field needs to be in text format.");
            }

            if (Contains?.Count > 0)
            {
                RuleFor(d => d.Range).Must(range => range != null && range.Any(cell => Contains.Any(val => cell.Value != null && cell.Value.Trim().Contains(val)))).WithMessage("Field content does not contain the expected value.");
            }

            if (PossibleValues?.Count > 0)
            {
                RuleFor(d => d.Range).Must(range => range != null && range.Any(cell => PossibleValues.Any(val => cell.Value?.Trim() == val))).WithMessage("Field content does not equal with the expected value.");
            }

            var result = base.Validate(data);

            if (result != null && result?.Errors?.Count > 0)
            {
                var message = string.Format("-{0} in Sheet {1} Cell {2}", Label, SheetName, CellRange);

                throw new ExcelValidationException(message);
            }
        }
    }

}
