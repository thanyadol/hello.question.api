﻿using surflex.netcore22.Helpers.DataHandler;
using surflex.netcore22.Models;
using System; 

using System.Collections.Generic;
using System.Linq;

namespace surflex.netcore22.Helpers.TemplateProfile
{
    public class DPITemplateCOTLProfile : BaseExcelTemplateProfile, IDPITemplateProfile
    {
        public static readonly Dictionary<string, string> SHEET_NAMES = new Dictionary<string, string>
        {
            { "ECON", "Econ" },
            { "COST", "Cost" },
            { "PROD_RSV", "Prod - RSV" },
            { "PRICE_DECK", "Pricedeck" },
        };

        public static readonly Dictionary<string, string> ADMIN_PAGE_VALIDATION_ADDRESSES = new Dictionary<string, string> {
            { "ECON_NPV", "B5" },
            { "ECON_DPI", "B6" },
            { "ECON_NPI", "B9" },
            { "ECON_DISCOUNTED_ABANDONMENT", "B10" },

            { "COST_CAPEX", "B2" },
            { "COST_RIG_MOVE", "B:B" },
            { "COST_WELL_DEVELOPMENT", "B:B" },

            { "PROD_RSV_TOTAL_LIQUID_HC", "I7" },
            { "PROD_RSV_TOTAL_GAS", "I8" },
            { "PROD_RSV_NUMBER_OF_WELL", "B12" },
            { "PROD_RSV_METHOD_SELECTION", "B18" },
            { "PROD_RSV_OIL_ONLINE_DATE", "B21" },
            { "PROD_RSV_GAS_ONLINE_DATE", "B22" },

            { "PRICE_DECK_LOW_CASE", "P1" },
            { "PRICE_DECK_MID_CASE", "AD1" },
            { "PRICE_DECK_HIGH_CASE", "AR1" },
            { "PRICE_DECK_B832_GAS", "X4,AL4,AZ4" },
            { "PRICE_DECK_TAN", "Z5,AN5,BB5" },
            { "PRICE_DECK_BEN", "AA5,AO5,BC5" },
        };

        public static readonly Dictionary<string, string> ADMIN_PAGE_VALIDATION_LABELS = new Dictionary<string, string> {
            { "ECON_NPV", "NPV" },
            { "ECON_DPI", "DPI" },
            { "ECON_NPI", "NPI" },
            { "ECON_DISCOUNTED_ABANDONMENT", "Discounted abandonment" },

            { "COST_CAPEX", "CAPEX" },
            { "COST_RIG_MOVE", "Rig Move" },
            { "COST_WELL_DEVELOPMENT", "Well Development" },

            { "PROD_RSV_TOTAL_LIQUID_HC", "Total Liquid HC" },
            { "PROD_RSV_TOTAL_GAS", "Total Gas" },
            { "PROD_RSV_NUMBER_OF_WELL", "Number of well" },
            { "PROD_RSV_METHOD_SELECTION", "Method Selection" },
            { "PROD_RSV_OIL_ONLINE_DATE", "Oil online date (1-Mmm-YY)" },
            { "PROD_RSV_GAS_ONLINE_DATE", "Gas online date (1-Mmm-YY)" },

            { "PRICE_DECK_LOW_CASE", "Low Case" },
            { "PRICE_DECK_MID_CASE", "Mid Case" },
            { "PRICE_DECK_HIGH_CASE", "High Case" },
            { "PRICE_DECK_B832_GAS", "B832 Gas" },
            { "PRICE_DECK_TAN", "Tan" },
            { "PRICE_DECK_BEN", "Ben" },
        };

        public static readonly Dictionary<string, string> PROJECT_SETUP_VALIDATION_ADDRESSES = new Dictionary<string, string> {
            { "ECON_NPV", "C5" },
            { "ECON_DPI", "C6" },
            { "ECON_NPI", "C9" },
            { "ECON_DISCOUNTED_ABANDONMENT", "C10" },

            { "PROD_RSV_PROJECT_NAME", "C2" },
            { "PROD_RSV_PRICE_CASE", "C13" },
            { "PROD_RSV_OIL_INITIAL_RATE", "N8:N11" },
            { "PROD_RSV_GAS_INITIAL_RATE", "O8:O11" },
            { "PROD_RSV_OIL_ABANDON_RATE", "N16" },
            { "PROD_RSV_GAS_ABANDON_RATE", "N17" },
            { "PROD_RSV_OIL_SALE_POINT", "C37" },
            { "PROD_RSV_GAS_BTU", "C38" },
            { "PROD_RSV_FUEL_AND_FLARE", "C39" },
        };

        public static readonly Dictionary<string, string> PROJECT_SETUP_VALIDATION_LABELS = new Dictionary<string, string> {
            { "ECON_NPV", "NPV" },
            { "ECON_DPI", "DPI" },
            { "ECON_NPI", "NPI" },
            { "ECON_DISCOUNTED_ABANDONMENT", "Discounted abandonment" },

            { "PROD_RSV_PROJECT_NAME", "Project name" },
            { "PROD_RSV_PRICE_CASE", "Price Case" },
            { "PROD_RSV_OIL_INITIAL_RATE", "Oil Initial Rate" },
            { "PROD_RSV_GAS_INITIAL_RATE", "Gas Initial Rate" },
            { "PROD_RSV_OIL_ABANDON_RATE", "Oil Abandon rate" },
            { "PROD_RSV_GAS_ABANDON_RATE", "Gas Abandon rate" },
            { "PROD_RSV_OIL_SALE_POINT", "Oil Sale Point" },
            { "PROD_RSV_GAS_BTU", "Gas BTU" },
            { "PROD_RSV_FUEL_AND_FLARE", "Fuel and Flare" },
        };

        public static readonly Dictionary<string, string> PROJECT_SETUP_WRITE_ADDRESSES = new Dictionary<string, string> {
            { "PROD_RSV_PRICE_CASE", "C13" },
            { "PROD_RSV_NUMBER_OF_WELL", "C12" },
            { "PROD_RSV_MODEL_SELECTION", "C18" },
            { "PROD_RSV_OIL_RESERVES", "C7" },
            { "PROD_RSV_SOLUTION_GAS_RESERVES", "C8" },
            { "PROD_RSV_GAS_RESERVES", "C9" },
            { "PROD_RSV_CONDENSATE_RESERVES", "C10" },
            { "PROD_RSV_OIL_ONLINE_DATE", "C21" },
            { "PROD_RSV_GAS_ONLINE_DATE", "C22" },
            { "PROD_RSV_INITIAL_GAS_RATE", "F26" },
            { "PROD_RSV_INITIAL_OIL_RATE", "C26" },
            { "PROD_RSV_GAS_ABANDONMENT_RATE", "F27" },
            { "PROD_RSV_OIL_ABANDONMENT_RATE", "C27" },
            { "PROD_RSV_OIL_PERCENT_HOLD", "C28" },
            { "PROD_RSV_GAS_PERCENT_HOLD", "F28" },

            { "COST_WELL_DEVELOPMENT", "B:B" },
            { "COST_RIG_MOVE", "B:B" },
            { "COST_YEAR", "C:C" },
            { "COST_TOTAL_COST", "D:D" },
            { "COST_INVESTMENTS", "B5:B26" },
            { "COST_ABANDONMENTS", "B31:B36" },
            { "COST_EXTRA_OPEX", "B41:B46" },

            { "PRICE_DECK_PRICE_CASE", "D1" },
            { "PRICE_DECK_YEAR", "A:A" },
            { "PRICE_DECK_LOW_B832_GAS", "X4" },
            { "PRICE_DECK_LOW_B832_OIL_TANTAWAN", "Z5" },
            { "PRICE_DECK_LOW_B832_OIL_BENCHAMAS", "AA5" },
            { "PRICE_DECK_MID_B832_GAS", "AL4" },
            { "PRICE_DECK_MID_B832_OIL_TANTAWAN", "AN5" },
            { "PRICE_DECK_MID_B832_OIL_BENCHAMAS", "AO5" },
            { "PRICE_DECK_HIGH_B832_GAS", "AZ4" },
            { "PRICE_DECK_HIGH_B832_OIL_TANTAWAN", "BB5" },
            { "PRICE_DECK_HIGH_B832_OIL_BENCHAMAS", "BC5" },
        };

        public static readonly Dictionary<string, string> PROJECT_SETUP_WRITE_LABELS = new Dictionary<string, string> {
            { "PROD_RSV_PRICE_CASE", "Pricedeck" },

            { "COST_WELL_DEVELOPMENT", "Well Development" },
            { "COST_RIG_MOVE", "Rig Move" },
            { "COST_INITIAL_COMPLETION", "Initial Completion" },
            { "COST_WELL_P_AND_A", "Well P&A for new WHP" },
            { "COST_WHP_P_AND_A", "WHP P&A for new WHP" },
            { "COST_YEAR", "Year" },
            { "COST_TOTAL_COST", "Total cost ($MM)" },
            { "COST_INVESTMENTS", "Investment" },
            { "COST_ABANDONMENTS", "Abandonment" },
            { "COST_EXTRA_OPEX", "Extra OPEX" },

            { "PRICE_DECK_PRICE_CASE", "Selected Case" },
            { "PRICE_DECK_YEAR", string.Empty },
            { "PRICE_DECK_LOW_B832_GAS", "B832 Gas" },
            { "PRICE_DECK_LOW_B832_OIL_TANTAWAN", "Tan" },
            { "PRICE_DECK_LOW_B832_OIL_BENCHAMAS", "Ben" },
            { "PRICE_DECK_MID_B832_GAS", "B832 Gas" },
            { "PRICE_DECK_MID_B832_OIL_TANTAWAN", "Tan" },
            { "PRICE_DECK_MID_B832_OIL_BENCHAMAS", "Ben" },
            { "PRICE_DECK_HIGH_B832_GAS", "B832 Gas" },
            { "PRICE_DECK_HIGH_B832_OIL_TANTAWAN", "Tan" },
            { "PRICE_DECK_HIGH_B832_OIL_BENCHAMAS", "Ben" },
        };

        public static readonly Dictionary<string, string> PROJECT_SETUP_RESULT_ADDRESSES = new Dictionary<string, string> {
            { "RESULT_NPV", "C5" },
            { "RESULT_INV", "C9:C10" },
            { "RESULT_DPI", "C6" },
        };

        public static readonly Dictionary<string, string> PROJECT_SETUP_RESULT_LABELS = new Dictionary<string, string> {
            { "RESULT_NPV", "NPV" },
            { "RESULT_INV", "INV" },
            { "RESULT_DPI", "DPI" },
        };

        public DPITemplateCOTLProfile() : base()
        {
            Definitions = new HashSet<IExcelProfileDefinition>();
        }

        public DPITemplateCOTLProfile(IExcelEngine excel) : base(excel)
        {
            Definitions = new HashSet<IExcelProfileDefinition>();
        }

        public virtual void AddAdminPageValidate()
        {
            // Econ Sheet
            AddDefinition(SHEET_NAMES["ECON"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["ECON_NPV"],
                ADMIN_PAGE_VALIDATION_LABELS["ECON_NPV"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["ECON_NPV"]));
            AddDefinition(SHEET_NAMES["ECON"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["ECON_DPI"],
                ADMIN_PAGE_VALIDATION_LABELS["ECON_DPI"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["ECON_DPI"]));
            AddDefinition(SHEET_NAMES["ECON"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["ECON_NPI"],
                ADMIN_PAGE_VALIDATION_LABELS["ECON_NPI"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["ECON_NPI"]));
            AddDefinition(SHEET_NAMES["ECON"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["ECON_DISCOUNTED_ABANDONMENT"],
                ADMIN_PAGE_VALIDATION_LABELS["ECON_DISCOUNTED_ABANDONMENT"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["ECON_DISCOUNTED_ABANDONMENT"]));

            // Cost Sheet
            AddDefinition(SHEET_NAMES["COST"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["COST_CAPEX"],
                ADMIN_PAGE_VALIDATION_LABELS["COST_CAPEX"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["COST_CAPEX"]));
            AddDefinition(SHEET_NAMES["COST"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["COST_RIG_MOVE"],
                ADMIN_PAGE_VALIDATION_LABELS["COST_RIG_MOVE"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["COST_RIG_MOVE"]));
            AddDefinition(SHEET_NAMES["COST"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["COST_WELL_DEVELOPMENT"],
                ADMIN_PAGE_VALIDATION_LABELS["COST_WELL_DEVELOPMENT"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["COST_WELL_DEVELOPMENT"]));

            // Prod - RSV Sheet
            AddDefinition(SHEET_NAMES["PROD_RSV"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["PROD_RSV_TOTAL_LIQUID_HC"],
                ADMIN_PAGE_VALIDATION_LABELS["PROD_RSV_TOTAL_LIQUID_HC"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["PROD_RSV_TOTAL_LIQUID_HC"]));
            AddDefinition(SHEET_NAMES["PROD_RSV"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["PROD_RSV_TOTAL_GAS"],
                ADMIN_PAGE_VALIDATION_LABELS["PROD_RSV_TOTAL_GAS"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["PROD_RSV_TOTAL_GAS"]));
            AddDefinition(SHEET_NAMES["PROD_RSV"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["PROD_RSV_NUMBER_OF_WELL"],
                ADMIN_PAGE_VALIDATION_LABELS["PROD_RSV_NUMBER_OF_WELL"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["PROD_RSV_NUMBER_OF_WELL"]));
            AddDefinition(SHEET_NAMES["PROD_RSV"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["PROD_RSV_METHOD_SELECTION"],
                ADMIN_PAGE_VALIDATION_LABELS["PROD_RSV_METHOD_SELECTION"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["PROD_RSV_METHOD_SELECTION"]));
            AddDefinition(SHEET_NAMES["PROD_RSV"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["PROD_RSV_OIL_ONLINE_DATE"],
                ADMIN_PAGE_VALIDATION_LABELS["PROD_RSV_OIL_ONLINE_DATE"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["PROD_RSV_OIL_ONLINE_DATE"]));
            AddDefinition(SHEET_NAMES["PROD_RSV"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["PROD_RSV_GAS_ONLINE_DATE"],
                ADMIN_PAGE_VALIDATION_LABELS["PROD_RSV_GAS_ONLINE_DATE"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["PROD_RSV_GAS_ONLINE_DATE"]));

            // Price Deck sheet
            AddDefinition(SHEET_NAMES["PRICE_DECK"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["PRICE_DECK_LOW_CASE"],
                ADMIN_PAGE_VALIDATION_LABELS["PRICE_DECK_LOW_CASE"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["PRICE_DECK_LOW_CASE"]));
            AddDefinition(SHEET_NAMES["PRICE_DECK"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["PRICE_DECK_MID_CASE"],
                ADMIN_PAGE_VALIDATION_LABELS["PRICE_DECK_MID_CASE"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["PRICE_DECK_MID_CASE"]));
            AddDefinition(SHEET_NAMES["PRICE_DECK"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["PRICE_DECK_HIGH_CASE"],
                ADMIN_PAGE_VALIDATION_LABELS["PRICE_DECK_HIGH_CASE"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["PRICE_DECK_HIGH_CASE"]));
            AddDefinition(SHEET_NAMES["PRICE_DECK"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["PRICE_DECK_B832_GAS"],
                ADMIN_PAGE_VALIDATION_LABELS["PRICE_DECK_B832_GAS"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["PRICE_DECK_B832_GAS"]));
            AddDefinition(SHEET_NAMES["PRICE_DECK"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["PRICE_DECK_TAN"],
                ADMIN_PAGE_VALIDATION_LABELS["PRICE_DECK_TAN"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["PRICE_DECK_TAN"]));
            AddDefinition(SHEET_NAMES["PRICE_DECK"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["PRICE_DECK_BEN"],
                ADMIN_PAGE_VALIDATION_LABELS["PRICE_DECK_BEN"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["PRICE_DECK_BEN"]));
        }

        public virtual void AddProjectSetUpValidate()
        {
            // Prod - RSV Sheet
            AddDefinition(SHEET_NAMES["PROD_RSV"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["PROD_RSV_PROJECT_NAME"],
                PROJECT_SETUP_VALIDATION_LABELS["PROD_RSV_PROJECT_NAME"],
                new ExcelValidation(type: ExcelCellType.Text));
            AddDefinition(SHEET_NAMES["PROD_RSV"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["PROD_RSV_PRICE_CASE"],
                PROJECT_SETUP_VALIDATION_LABELS["PROD_RSV_PRICE_CASE"],
                new ExcelValidation(type: ExcelCellType.Text));
            AddDefinition(SHEET_NAMES["PROD_RSV"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["PROD_RSV_OIL_INITIAL_RATE"],
                PROJECT_SETUP_VALIDATION_LABELS["PROD_RSV_OIL_INITIAL_RATE"],
                new ExcelValidation(type: ExcelCellType.Numeric));
            AddDefinition(SHEET_NAMES["PROD_RSV"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["PROD_RSV_GAS_INITIAL_RATE"],
                PROJECT_SETUP_VALIDATION_LABELS["PROD_RSV_GAS_INITIAL_RATE"],
                new ExcelValidation(type: ExcelCellType.Numeric));
            AddDefinition(SHEET_NAMES["PROD_RSV"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["PROD_RSV_OIL_ABANDON_RATE"],
                PROJECT_SETUP_VALIDATION_LABELS["PROD_RSV_OIL_ABANDON_RATE"],
                new ExcelValidation(type: ExcelCellType.Numeric));
            AddDefinition(SHEET_NAMES["PROD_RSV"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["PROD_RSV_GAS_ABANDON_RATE"],
                PROJECT_SETUP_VALIDATION_LABELS["PROD_RSV_GAS_ABANDON_RATE"],
                new ExcelValidation(type: ExcelCellType.Numeric));
            AddDefinition(SHEET_NAMES["PROD_RSV"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["PROD_RSV_OIL_SALE_POINT"],
                PROJECT_SETUP_VALIDATION_LABELS["PROD_RSV_OIL_SALE_POINT"],
                new ExcelValidation(type: ExcelCellType.Text));
            AddDefinition(SHEET_NAMES["PROD_RSV"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["PROD_RSV_GAS_BTU"],
                PROJECT_SETUP_VALIDATION_LABELS["PROD_RSV_GAS_BTU"],
                new ExcelValidation(type: ExcelCellType.Numeric));
            AddDefinition(SHEET_NAMES["PROD_RSV"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["PROD_RSV_FUEL_AND_FLARE"],
                PROJECT_SETUP_VALIDATION_LABELS["PROD_RSV_FUEL_AND_FLARE"],
                new ExcelValidation(type: ExcelCellType.Percent));
        }

        public virtual void AddProdRSVDefinition(COTLProdRSV model)
        {
            var properties = new HashSet<IExcelProfileDefinitionProperties>();

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["PROD_RSV_NUMBER_OF_WELL"],
                Value = model.NumberOfWells,
            });
            properties.Add(new ExcelProfileDefinitionProperties
            {
                RangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["PROD_RSV_MODEL_SELECTION"],
                Value = model.ModelSelection,
            });
            properties.Add(new ExcelProfileDefinitionProperties
            {
                RangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["PROD_RSV_OIL_RESERVES"],
                Value = model.OilReserves,
            });
            properties.Add(new ExcelProfileDefinitionProperties
            {
                RangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["PROD_RSV_SOLUTION_GAS_RESERVES"],
                Value = model.SolutionGasReserves,
            });
            properties.Add(new ExcelProfileDefinitionProperties
            {
                RangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["PROD_RSV_GAS_RESERVES"],
                Value = model.GasReserves,
            });
            properties.Add(new ExcelProfileDefinitionProperties
            {
                RangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["PROD_RSV_CONDENSATE_RESERVES"],
                Value = model.CondensateReserves,
            });
            properties.Add(new ExcelProfileDefinitionProperties
            {
                RangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["PROD_RSV_OIL_ONLINE_DATE"],
                Value = model.OilOnlineDate,
            });
            //Gas online date
            if (model.GasOnlineDate.HasValue)
            {
                properties.Add(new ExcelProfileDefinitionProperties
                {
                    RangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["PROD_RSV_GAS_ONLINE_DATE"],
                    Value = model.GasOnlineDate.Value,
                });
            }
            properties.Add(new ExcelProfileDefinitionProperties
            {
                RangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["PROD_RSV_INITIAL_GAS_RATE"],
                Value = model.InitialGasRate,
            });
            properties.Add(new ExcelProfileDefinitionProperties
            {
                RangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["PROD_RSV_INITIAL_OIL_RATE"],
                Value = model.InitialOilRate,
            });
            properties.Add(new ExcelProfileDefinitionProperties
            {
                RangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["PROD_RSV_GAS_ABANDONMENT_RATE"],
                Value = model.GasAbandonmentRate,
            });
            properties.Add(new ExcelProfileDefinitionProperties
            {
                RangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["PROD_RSV_OIL_ABANDONMENT_RATE"],
                Value = model.OilAbandonmentRate,
            });
            properties.Add(new ExcelProfileDefinitionProperties
            {
                RangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["PROD_RSV_OIL_PERCENT_HOLD"],
                Value = model.OilPercentHold,
            });
            properties.Add(new ExcelProfileDefinitionProperties
            {
                RangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["PROD_RSV_GAS_PERCENT_HOLD"],
                Value = model.GasPercentHold,
            });

            Definitions.Add(new DPITemplateCOTLProfileDefinition
            {
                Mode = ExcelProfileDefinitionMode.Write,
                Key = "PROD_RSV_MAPPING",
                Label = "Prod - RSV Mapping",
                Datasource = properties,
                SheetName = SHEET_NAMES["PROD_RSV"],
            });
        }

        /// <summary>
        /// Add drilling cost data.
        /// </summary>
        /// <param name="model"></param>
        public virtual void AddDrillingCostDefinition(ProjectWell model)
        {
            if (model == null)
                throw new ArgumentNullException("The queried drilling data is missing.");

            if (model.StartDate == null)
                throw new ArgumentNullException("The queried drilling cost date is missing.");

            if (model.TotalProductiveAFECost == null)
                throw new ArgumentNullException("The queried drilling cost value is missing.");

            var properties = new HashSet<IExcelProfileDefinitionProperties>();

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_WELL_DEVELOPMENT"],
                RowCriteriaText = PROJECT_SETUP_WRITE_LABELS["COST_WELL_DEVELOPMENT"],
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_WELL_DEVELOPMENT"],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_YEAR"],
                ColumnCriteriaText = PROJECT_SETUP_WRITE_LABELS["COST_YEAR"],
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_YEAR"],
                Value = DateTimeUtility.GetYear(model.StartDate.Value),
            });

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_WELL_DEVELOPMENT"],
                RowCriteriaText = PROJECT_SETUP_WRITE_LABELS["COST_WELL_DEVELOPMENT"],
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_WELL_DEVELOPMENT"],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_TOTAL_COST"],
                ColumnCriteriaText = PROJECT_SETUP_WRITE_LABELS["COST_TOTAL_COST"],
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_TOTAL_COST"],
                Value = model.TotalProductiveAFECost.Value,
            });

            Definitions.Add(new DPITemplateCOTLProfileDefinition
            {
                Mode = ExcelProfileDefinitionMode.WriteFirstHorizontal,
                Key = "COST_MAPPING",
                Label = "Cost Mapping",
                Datasource = properties,
                SheetName = SHEET_NAMES["COST"],
            });
        }

        /// <summary>
        /// Add rig move cost data.
        /// </summary>
        /// <param name="model"></param>
        public virtual void AddRigMoveCostDefinition(Job model)
        {
            if (model == null)
                throw new ArgumentNullException("The queried drilling data is missing.");

            if (model.StartDate == null)
                throw new ArgumentNullException("The queried drilling cost date is missing.");

            if (model.TotalCostCalculate == null)
                throw new ArgumentNullException("The queried drilling cost value is missing.");

            var properties = new HashSet<IExcelProfileDefinitionProperties>();

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_RIG_MOVE"],
                RowCriteriaText = PROJECT_SETUP_WRITE_LABELS["COST_RIG_MOVE"],
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_RIG_MOVE"],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_YEAR"],
                ColumnCriteriaText = PROJECT_SETUP_WRITE_LABELS["COST_YEAR"],
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_YEAR"],
                Value = DateTimeUtility.GetYear(model.StartDate.Value),
            });

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_RIG_MOVE"],
                RowCriteriaText = PROJECT_SETUP_WRITE_LABELS["COST_RIG_MOVE"],
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_RIG_MOVE"],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_TOTAL_COST"],
                ColumnCriteriaText = PROJECT_SETUP_WRITE_LABELS["COST_TOTAL_COST"],
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_TOTAL_COST"],
                Value = model.TotalCostCalculate.Value,
            });

            Definitions.Add(new DPITemplateCOTLProfileDefinition
            {
                Mode = ExcelProfileDefinitionMode.WriteFirstHorizontal,
                Key = "RIG_MOVE_MAPPING",
                Label = "Rig Move Mapping",
                Datasource = properties,
                SheetName = SHEET_NAMES["COST"],
            });
        }

        public virtual void AddCostDefinition(COTLCost model)
        {
            var properties = new HashSet<IExcelProfileDefinitionProperties>();

            // Well
            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_WELL_DEVELOPMENT"],
                RowCriteriaText = PROJECT_SETUP_WRITE_LABELS["COST_WELL_DEVELOPMENT"],
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_WELL_DEVELOPMENT"],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_YEAR"],
                ColumnCriteriaText = PROJECT_SETUP_WRITE_LABELS["COST_YEAR"],
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_YEAR"],
                Value = DateTimeUtility.GetYear(model.Year),
            });

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_WELL_DEVELOPMENT"],
                RowCriteriaText = PROJECT_SETUP_WRITE_LABELS["COST_WELL_DEVELOPMENT"],
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_WELL_DEVELOPMENT"],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_TOTAL_COST"],
                ColumnCriteriaText = PROJECT_SETUP_WRITE_LABELS["COST_TOTAL_COST"],
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_TOTAL_COST"],
                Value = model.DrillingCostInMM,
            });


            // Mob and Demob
            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_RIG_MOVE"],
                RowCriteriaText = PROJECT_SETUP_WRITE_LABELS["COST_RIG_MOVE"],
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_RIG_MOVE"],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_YEAR"],
                ColumnCriteriaText = PROJECT_SETUP_WRITE_LABELS["COST_YEAR"],
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_YEAR"],
                Value = DateTimeUtility.GetYear(model.Year),
            });

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_RIG_MOVE"],
                RowCriteriaText = PROJECT_SETUP_WRITE_LABELS["COST_RIG_MOVE"],
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_RIG_MOVE"],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_TOTAL_COST"],
                ColumnCriteriaText = PROJECT_SETUP_WRITE_LABELS["COST_TOTAL_COST"],
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_TOTAL_COST"],
                Value = model.RigMoveCostInMM,
            });

            Definitions.Add(new DPITemplateCOTLProfileDefinition
            {
                Mode = ExcelProfileDefinitionMode.WriteFirstHorizontal,
                Key = "COST_MAPPING",
                Label = "Cost Mapping",
                Datasource = properties,
                SheetName = SHEET_NAMES["COST"],
            });
        }

        /// <summary>
        /// Add price case definitions by level, hc type, and area.
        /// </summary>
        /// <param name="level"></param>
        /// <param name="hcType"></param>
        /// <param name="area"></param>
        /// <param name="prices"></param>
        public virtual void AddPriceCaseDefinition(string level, string hcType, string area, IEnumerable<PeriodPrice> prices)
        {
            level = level?.ToUpper();
            hcType = hcType?.ToUpper();
            area = area?.ToUpper();

            if (!(new string[] { "LOW", "MID", "HIGH" }).Any(x => x == level))
                return;

            if (!(new string[] { "GAS", "OIL" }).Any(x => x == hcType))
                return;

            if (!(new string[] { "B8/32 GAS", "B8/32 OIL TAN", "B8/32 OIL BEN" }).Any(x => x == area))
                return;

            var properties = new HashSet<IExcelProfileDefinitionProperties>();

            foreach (var price in prices)
            {
                if (area == "B8/32 GAS" && hcType == "GAS")
                    AddPriceCaseDefinition(properties, price, $"PRICE_DECK_{level}_B832_GAS");

                if (area == "B8/32 OIL TAN" && hcType == "OIL")
                    AddPriceCaseDefinition(properties, price, $"PRICE_DECK_{level}_B832_OIL_TANTAWAN");

                if (area == "B8/32 OIL BEN" && hcType == "OIL")
                    AddPriceCaseDefinition(properties, price, $"PRICE_DECK_{level}_B832_OIL_BENCHAMAS");
            }

            if (properties.Count == 0)
                return;

            Definitions.Add(new DPITemplateCOTLProfileDefinition
            {
                Mode = ExcelProfileDefinitionMode.WriteFirstHorizontal,
                Key = $"PRICE_DECK_{level}_{hcType}_{area}_MAPPING",
                Label = $"PeriodPrice Deck {level} {hcType} {area} Mapping",
                Datasource = properties,
                SheetName = SHEET_NAMES["PRICE_DECK"],
            });
        }

        private void AddPriceCaseDefinition(ICollection<IExcelProfileDefinitionProperties> properties, PeriodPrice model, string key)
        {
            if (model == null)
                throw new ArgumentNullException("The queried price is missing.");

            if (model.CurrentDate == null)
                throw new ArgumentNullException("The queried price date is missing.");

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["PRICE_DECK_YEAR"],
                RowCriteriaText = DateTimeUtility.GetShortenDate(model.CurrentDate.Value),
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["PRICE_DECK_YEAR"],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS[key],
                ColumnCriteriaText = PROJECT_SETUP_WRITE_LABELS[key],
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES[key],
                Value = model.Value,
            });
        }

        public virtual void AddPriceCaseDefinition(IEnumerable<COTLPriceCase> models)
        {
            var properties = new HashSet<IExcelProfileDefinitionProperties>();

            foreach (var model in models)
            {
                // Low
                AddPriceCaseDefinition(properties, model, model.LowB832Gas, "PRICE_DECK_LOW_B832_GAS");
                AddPriceCaseDefinition(properties, model, model.LowB832OilBenchamas, "PRICE_DECK_LOW_B832_OIL_BENCHAMAS");
                AddPriceCaseDefinition(properties, model, model.LowB832OilTantawan, "PRICE_DECK_LOW_B832_OIL_TANTAWAN");

                // Mid
                AddPriceCaseDefinition(properties, model, model.MidB832Gas, "PRICE_DECK_MID_B832_GAS");
                AddPriceCaseDefinition(properties, model, model.MidB832OilBenchamas, "PRICE_DECK_MID_B832_OIL_BENCHAMAS");
                AddPriceCaseDefinition(properties, model, model.MidB832OilTantawan, "PRICE_DECK_MID_B832_OIL_TANTAWAN");

                // High
                AddPriceCaseDefinition(properties, model, model.HighB832Gas, "PRICE_DECK_HIGH_B832_GAS");
                AddPriceCaseDefinition(properties, model, model.HighB832OilBenchamas, "PRICE_DECK_HIGH_B832_OIL_BENCHAMAS");
                AddPriceCaseDefinition(properties, model, model.HighB832OilTantawan, "PRICE_DECK_HIGH_B832_OIL_TANTAWAN");
            }

            Definitions.Add(new DPITemplateCOTLProfileDefinition
            {
                Mode = ExcelProfileDefinitionMode.WriteFirstHorizontal,
                Key = "PRICE_DECK_MAPPING",
                Label = "Price Deck Mapping",
                Datasource = properties,
                SheetName = SHEET_NAMES["PRICE_DECK"],
            });
        }

        private void AddPriceCaseDefinition(ICollection<IExcelProfileDefinitionProperties> properties, COTLPriceCase model, object value, string key)
        {
            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["PRICE_DECK_YEAR"],
                RowCriteriaText = DateTimeUtility.GetShortenDate(model.Year),
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["PRICE_DECK_YEAR"],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS[key],
                ColumnCriteriaText = PROJECT_SETUP_WRITE_LABELS[key],
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES[key],
                Value = value,
            });
        }

        /// <summary>
        /// Add Well DPI division by given well amount.
        /// </summary>
        /// <param name="wellAmount"></param>
        public virtual void AddWellDPIDividingDefinition(int wellAmount)
        {
            var properties = new HashSet<IExcelProfileDefinitionProperties>();

            AddWellDPIDividingDefinition(properties, wellAmount, "COST_INVESTMENTS");
            AddWellDPIDividingDefinition(properties, wellAmount, "COST_ABANDONMENTS");
            AddWellDPIDividingDefinition(properties, wellAmount, "COST_EXTRA_OPEX");

            Definitions.Add(new DPITemplateCOTLProfileDefinition
            {
                Mode = ExcelProfileDefinitionMode.AppendFormula1Criteria,
                Key = "WELL_DPI_DIVIDING",
                Label = "Well DPI dividing",
                Datasource = properties,
                SheetName = SHEET_NAMES["COST"],
            });
        }

        private void AddWellDPIDividingDefinition(ICollection<IExcelProfileDefinitionProperties> properties, int wellAmount, string key)
        {
            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS[key],
                RowCriteriaIncludedText = null,
                RowCriteriaExcludedText = key?.ToUpper() == "COST_INVESTMENTS" ? new string[] { PROJECT_SETUP_WRITE_LABELS["COST_RIG_MOVE"], PROJECT_SETUP_WRITE_LABELS["COST_WELL_DEVELOPMENT"] } : null,
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES[key],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_TOTAL_COST"],
                ColumnCriteriaIncludedText = null,
                ColumnCriteriaExcludedText = null,
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_TOTAL_COST"],
                Formula = $"=((value)/{wellAmount})",
            });
        }

        /// <summary>
        /// Clear values.
        /// </summary>
        public virtual void AddClearValuesDefinition()
        {
            var properties = new HashSet<IExcelProfileDefinitionProperties>();

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_INVESTMENTS"],
                RowCriteriaIncludedText = null,
                RowCriteriaExcludedText = new string[] { PROJECT_SETUP_WRITE_LABELS["COST_INITIAL_COMPLETION"], PROJECT_SETUP_WRITE_LABELS["COST_WELL_DEVELOPMENT"] },
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_INVESTMENTS"],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_TOTAL_COST"],
                ColumnCriteriaIncludedText = null,
                ColumnCriteriaExcludedText = null,
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_TOTAL_COST"],
            });

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_ABANDONMENTS"],
                RowCriteriaIncludedText = null,
                RowCriteriaExcludedText = new string[] { PROJECT_SETUP_WRITE_LABELS["COST_WELL_P_AND_A"], PROJECT_SETUP_WRITE_LABELS["COST_WHP_P_AND_A"] },
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_ABANDONMENTS"],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["COST_TOTAL_COST"],
                ColumnCriteriaIncludedText = null,
                ColumnCriteriaExcludedText = null,
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["COST_TOTAL_COST"],
            });

            Definitions.Add(new DPITemplateCOTLProfileDefinition
            {
                Mode = ExcelProfileDefinitionMode.Clear1Criteria,
                Key = "WELL_DPI_CLEAR_VECTOR",
                Label = "Well DPI clear vector value",
                Datasource = properties,
                SheetName = SHEET_NAMES["COST"],
            });
        }

        /// <summary>
        /// Add price case type where case is LOW, MID, or HIGH.
        /// </summary>
        /// <param name="caseType"></param>
        public virtual void AddPriceCaseTypeDefinition(string caseType)
        {
            var cases = new string[] { "low", "mid", "high" };

            caseType = cases.Any(c => c == caseType?.ToLower()) ? caseType.ToUpper() : throw new ArgumentException();

            AddPriceCaseTypeProdRsvDefinition(caseType);

            AddPriceCaseTypePricedeckDefinition(caseType);
        }

        private void AddPriceCaseTypeProdRsvDefinition(string caseType)
        {
            var properties = new HashSet<IExcelProfileDefinitionProperties>();

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["PROD_RSV_PRICE_CASE"],
                Value = caseType,
            });

            Definitions.Add(new DPITemplateCOTLProfileDefinition
            {
                Mode = ExcelProfileDefinitionMode.Write,
                Key = "PRICE_CASE_SETTING_PROD_RSV",
                Label = "Price Case Setting Prod Rsv",
                Datasource = properties,
                SheetName = SHEET_NAMES["PROD_RSV"],
            });
        }

        private void AddPriceCaseTypePricedeckDefinition(string caseType)
        {
            var properties = new HashSet<IExcelProfileDefinitionProperties>();

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["PRICE_DECK_PRICE_CASE"],
                Value = caseType,
            });

            Definitions.Add(new DPITemplateCOTLProfileDefinition
            {
                Mode = ExcelProfileDefinitionMode.Write,
                Key = "PRICE_CASE_SETTING_PRICE_DECK",
                Label = "Price Case Setting Price Deck",
                Datasource = properties,
                SheetName = SHEET_NAMES["PRICE_DECK"],
            });
        }

        /// <summary>
        /// Add DPI reading action. Call GetReadDPI() next in order to get the DPI.
        /// </summary>
        public virtual void AddDPIReadDefinition()
        {
            // Recalculate
            AddDefinition(SHEET_NAMES["ECON"],
                null,
                null,
                ExcelProfileDefinitionMode.Recalculate);

            // Extract
            AddDefinition(SHEET_NAMES["ECON"],
                PROJECT_SETUP_RESULT_ADDRESSES["RESULT_NPV"],
                PROJECT_SETUP_RESULT_LABELS["RESULT_NPV"],
                "RESULT_NPV_VALUE",
                new ExcelValidation(type: ExcelCellType.Numeric, isValid: true));
            AddDefinition(SHEET_NAMES["ECON"],
                PROJECT_SETUP_RESULT_ADDRESSES["RESULT_INV"],
                PROJECT_SETUP_RESULT_LABELS["RESULT_INV"],
                "RESULT_INV_VALUE",
                new ExcelValidation(type: ExcelCellType.Numeric, isValid: true));
            AddDefinition(SHEET_NAMES["ECON"],
                PROJECT_SETUP_RESULT_ADDRESSES["RESULT_DPI"],
                PROJECT_SETUP_RESULT_LABELS["RESULT_DPI"],
                "RESULT_DPI_VALUE",
                new ExcelValidation(type: ExcelCellType.Numeric, isValid: true));
        }

        /// <summary>
        /// Get read DPI.
        /// </summary>
        /// <returns></returns>
        public virtual ProjectDPIResult GetReadDPI()
        {
            var keys = new string[] { "RESULT_NPV_VALUE", "RESULT_INV_VALUE", "RESULT_DPI_VALUE" };
            var definitions = Definitions.Where(definition => keys.Contains(definition.Key));
            if (definitions == null || definitions?.Count() == 0) throw new InvalidOperationException("No data definition has been loaded or executed.");

            var result = new ProjectDPIResult();

            foreach (var definition in definitions)
            {
                var sum = definition.Results?.Sum(val =>
                {
                    try
                    {
                        return Convert.ToDecimal(val.RawValue);
                    }
                    catch (Exception)
                    {
                        throw new InvalidOperationException("Failed to get DPI. There is an error in the calculation.");
                    }
                });

                if (sum == null) continue;

                if (definition.Key == "RESULT_NPV_VALUE")
                {
                    result.NPV = sum.Value;
                }
                else if (definition.Key == "RESULT_INV_VALUE")
                {
                    result.INV = sum.Value;
                }
                else if (definition.Key == "RESULT_DPI_VALUE")
                {
                    result.DPI = sum.Value;
                }
            }

            return result;
        }

        public override void Execute()
        {
            base.Execute();
        }

        public override string GetVersion()
        {
            return "Project DPI Template COTL v1.0.00";
        }
    }

    public class DPITemplateCOTLProfileDefinition : ExcelTemplateProfileDefinition
    {
    }

    public class COTLProdRSV
    {
        private DateTime? oilOnlineDate = null;
        private DateTime? gasOnlineDate = null;
        private string modelSelection = "";

        public object NumberOfWells { get; set; }
        public string ModelSelection
        {
            get
            {
                if (modelSelection != null && modelSelection.ToLower().Contains("separate"))
                {
                    return "SEPARATE PROFILE";
                }

                return modelSelection?.ToUpper();
            }
            set => modelSelection = value;
        }
        public object OilReserves { get; set; }
        public object SolutionGasReserves { get; set; }
        public object GasReserves { get; set; }
        public object CondensateReserves { get; set; }
        public DateTime? OilOnlineDate
        {
            get
            {
                if (oilOnlineDate != null)
                {
                    var date = oilOnlineDate.Value;
                    return new DateTime(date.Year, date.Month, 1);
                }

                return null;
            }
            set => oilOnlineDate = value ?? null;
        }
        public DateTime? GasOnlineDate
        {
            get
            {
                if (gasOnlineDate != null && modelSelection?.ToLower() != "separate")
                {
                    var date = gasOnlineDate.Value;
                    return new DateTime(date.Year, date.Month, 1);
                }
                return null;
            }
            set => gasOnlineDate = value ?? null;
        }
        public object InitialGasRate { get; set; }
        public object InitialOilRate { get; set; }
        public object GasAbandonmentRate { get; set; }
        public object OilAbandonmentRate { get; set; }
        public object OilPercentHold { get; set; }
        public object GasPercentHold { get; set; }
    }

    public class COTLCost
    {
        public DateTime Year { get; set; }

        public object DrillingCostInMM { get; set; }
        public object RigMoveCostInMM { get; set; }
    }

    public class COTLPriceCase
    {
        public DateTime Year { get; set; }

        public object LowB832Gas { get; set; }
        public object LowB832OilTantawan { get; set; }
        public object LowB832OilBenchamas { get; set; }

        public object MidB832Gas { get; set; }
        public object MidB832OilTantawan { get; set; }
        public object MidB832OilBenchamas { get; set; }

        public object HighB832Gas { get; set; }
        public object HighB832OilTantawan { get; set; }
        public object HighB832OilBenchamas { get; set; }
    }
}
