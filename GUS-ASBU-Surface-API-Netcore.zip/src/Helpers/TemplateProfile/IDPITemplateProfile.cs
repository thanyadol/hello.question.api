﻿using surflex.netcore22.Helpers.DataHandler;
using surflex.netcore22.Models;
using System.Collections.Generic;

namespace surflex.netcore22.Helpers.TemplateProfile
{
    public interface IDPITemplateProfile : IExcelProfile
    {
        void AddDrillingCostDefinition(ProjectWell model);

        void AddRigMoveCostDefinition(Job model);

        void AddPriceCaseDefinition(string level, string hcType, string area, IEnumerable<PeriodPrice> prices);

        void AddWellDPIDividingDefinition(int wellAmount);

        void AddClearValuesDefinition();

        void AddPriceCaseTypeDefinition(string caseType);

        void AddDPIReadDefinition();

        ProjectDPIResult GetReadDPI();
    }

    public class ProjectDPIResult
    {
        public decimal NPV { get; set; } = 0M;

        public decimal INV { get; set; } = 0M;

        public decimal DPI { get; set; } = 0M;
    }
}
