﻿using surflex.netcore22.Helpers.DataHandler;
using surflex.netcore22.Models;
using System; 

using System.Collections.Generic;
using System.Linq;

namespace surflex.netcore22.Helpers.TemplateProfile
{
    public class DPITemplateCTEPProfile : BaseExcelTemplateProfile, IDPITemplateProfile
    {
        public static readonly Dictionary<string, string> SHEET_NAMES = new Dictionary<string, string>
        {
            { "SCALAR_INPUT", "Scalar Input" },
            { "VECTOR_INPUT", "Vector Input" },
            { "RESULT", "Result" },
        };

        public static readonly Dictionary<string, string> ADMIN_PAGE_VALIDATION_ADDRESSES = new Dictionary<string, string> {
            { "SCALAR_PARAMETERS", "A6" },
            { "SCALAR_IN_USE_OR_ACTIVE", "I6" },
            { "SCALAR_INDEX", "K6" },
            { "SCALAR_MID", "N6" },

            { "VECTOR_PARAMETERS", "A6" },
            { "VECTOR_DEVELOPMENT_WELL_COST", "B:B" },
            { "VECTOR_RIG_MOVE", "B:B" },
            { "VECTOR_PRODUCTION_PROFILE", "A:A" },
            { "VECTOR_PRICE_DECK", "A:A" },

            { "RESULT_NPV", "A6" },
            { "RESULT_INVESTMENT", "A7" },
            { "RESULT_DPI", "A8" },
        };

        public static readonly Dictionary<string, string> ADMIN_PAGE_VALIDATION_LABELS = new Dictionary<string, string> {
            { "SCALAR_PARAMETERS", "Parameters" },
            { "SCALAR_IN_USE_OR_ACTIVE", "In Use/Active" },
            { "SCALAR_INDEX", "Index" },
            { "SCALAR_MID", "Mid" },

            { "VECTOR_PARAMETERS", "Parameters" },
            { "VECTOR_DEVELOPMENT_WELL_COST", "Development Well Cost" },
            { "VECTOR_RIG_MOVE", "Rig Move" },
            { "VECTOR_PRODUCTION_PROFILE", "Production Profile" },
            { "VECTOR_PRICE_DECK", "Price Deck" },

            { "RESULT_NPV", "NPV" },
            { "RESULT_INVESTMENT", "INVESTMENT" },
            { "RESULT_DPI", "DPI" },
        };

        public static readonly Dictionary<string, string> PROJECT_SETUP_VALIDATION_ADDRESSES = new Dictionary<string, string> {
            { "SCALAR_START_YEAR", "I8" },
            { "SCALAR_CURRENT_YEAR", "I9" },
            { "SCALAR_DISCOUNT_YEAR", "I10" },
            { "SCALAR_INFLATION_RATE", "I13" },
            { "SCALAR_WORKING_INTEREST", "I16" },
            { "SCALAR_COMPANY", "I17" },
            { "SCALAR_CONTRACT_END_DATE", "I18" },
            { "SCALAR_RESERVES_CASE", "I30" },
            { "SCALAR_G_AND_A", "I40" },
            { "SCALAR_NUMBER_OF_YEAR_ABANDONMENT_WHP", "I43" },
            { "SCALAR_NUMBER_OF_YEAR_ABANDONMENT_WELL", "I44" },
            { "SCALAR_ABANDONMENT_COST", "N46" },
            { "SCALAR_YEAR_AFTER_LAST_PROD_WHP", "I47" },
            { "SCALAR_YEAR_AFTER_LAST_PROD_WELL", "I48" },
            { "SCALAR_PRICE_CASE", "I53" },
            { "SCALAR_CTEP_PRICE", "I54" },
            { "SCALAR_GAS_CALOEIFIC", "I57" },
            { "SCALAR_OPEX", "I63" },
            { "SCALAR_FUEL_OWN_USED", "I64" },

            { "RESULT_NPV", "I6" },
            { "RESULT_INVESTMENT", "I7" },
            { "RESULT_DPI", "I8" },
        };

        public static readonly Dictionary<string, string> PROJECT_SETUP_VALIDATION_LABELS = new Dictionary<string, string> {
            { "SCALAR_START_YEAR", "Start year" },
            { "SCALAR_CURRENT_YEAR", "Current year" },
            { "SCALAR_DISCOUNT_YEAR", "Discount year" },
            { "SCALAR_INFLATION_RATE", "Inflation rate" },
            { "SCALAR_WORKING_INTEREST", "Working interest" },
            { "SCALAR_COMPANY", "Company" },
            { "SCALAR_CONTRACT_END_DATE", "Contract end date" },
            { "SCALAR_RESERVES_CASE", "Reserves case" },
            { "SCALAR_G_AND_A", "G&A" },
            { "SCALAR_NUMBER_OF_YEAR_ABANDONMENT_WHP", "Number of years for abandonment spending - WHP" },
            { "SCALAR_NUMBER_OF_YEAR_ABANDONMENT_WELL", "Number of years for abandonment spending - Well" },
            { "SCALAR_ABANDONMENT_COST", "Abandonment Cost (Decommissioning cost) - Well" },
            { "SCALAR_YEAR_AFTER_LAST_PROD_WHP", "Year after last production for WHP abandonment" },
            { "SCALAR_YEAR_AFTER_LAST_PROD_WELL", "Year after last production for Well abandonment" },
            { "SCALAR_PRICE_CASE", "Price case" },
            { "SCALAR_CTEP_PRICE", "CTEP price" },
            { "SCALAR_GAS_CALOEIFIC", "Gas Calorific Value" },
            { "SCALAR_OPEX", "OPEX" },
            { "SCALAR_FUEL_OWN_USED", "Fuel Own Used" },

            { "RESULT_NPV", "NPV" },
            { "RESULT_INVESTMENT", "INVESTMENT" },
            { "RESULT_DPI", "DPI" },
        };

        public static readonly Dictionary<string, string> PROJECT_SETUP_WRITE_ADDRESSES = new Dictionary<string, string> {
            { "SCALAR_ABANDONMENT_COST_WHP", "N45" },
            { "SCALAR_ABANDONMENT_COST_WELL", "N46" },
            { "SCALAR_PRICE_CASE", "K53" },

            { "VECTOR_YEARS", "J6:AI6" },
            { "VECTOR_COSTS", "B8:B12,B18:B19,B22,B27" },
            { "VECTOR_COSTS_BREAKDOWN", "B8:B12" },
            { "VECTOR_RIG_MOVE_COSTS", "B17" },
            { "VECTOR_WELL_ABANDONMENT", "B18" },
            { "VECTOR_ASSET_ENGINEERING_COST", "B22" },

            { "VECTOR_DEVELOPMENT_WELL_COST", "B:B" },
            { "VECTOR_DEVELOPMENT_WELL_COST_CRITERIA1", "6:6" },

            { "VECTOR_RIG_MOVE", "B:B" },
            { "VECTOR_RIG_MOVE_CRITERIA1", "6:6" },

            { "VECTOR_PRODUCTION_PROFILE_DATE", "H:H" },
            { "VECTOR_PRODUCTION_PROFILE_P10_OIL", "J263" },
            { "VECTOR_PRODUCTION_PROFILE_P10_SOLUTION_GAS", "K263" },
            { "VECTOR_PRODUCTION_PROFILE_P10_GAS", "L263" },
            { "VECTOR_PRODUCTION_PROFILE_P10_CONDENSATE", "M263" },
            { "VECTOR_PRODUCTION_PROFILE_P50_OIL", "O263" },
            { "VECTOR_PRODUCTION_PROFILE_P50_SOLUTION_GAS", "P263" },
            { "VECTOR_PRODUCTION_PROFILE_P50_GAS", "Q263" },
            { "VECTOR_PRODUCTION_PROFILE_P50_CONDENSATE", "R263" },
            { "VECTOR_PRODUCTION_PROFILE_P90_OIL", "T263" },
            { "VECTOR_PRODUCTION_PROFILE_P90_SOLUTION_GAS", "U263" },
            { "VECTOR_PRODUCTION_PROFILE_P90_GAS", "V263" },
            { "VECTOR_PRODUCTION_PROFILE_P90_CONDENSATE", "W263" },
            { "VECTOR_PRODUCTION_PROFILE_EV_OIL", "Y263" },
            { "VECTOR_PRODUCTION_PROFILE_EV_SOLUTION_GAS", "Z263" },
            { "VECTOR_PRODUCTION_PROFILE_EV_GAS", "AA263" },
            { "VECTOR_PRODUCTION_PROFILE_EV_CONDENSATE", "AB263" },

            { "VECTOR_PRICE_DECK_TYPE", "K554:BD556" },
            { "VECTOR_PRICE_DECK_YEAR_MONTH", "I593:J868" },
            { "VECTOR_PRICE_DECK_YEAR", "I593:I868" },
            { "VECTOR_PRICE_DECK_MONTH", "J593:J868" },
        };

        public static readonly Dictionary<string, string> PROJECT_SETUP_WRITE_LABELS = new Dictionary<string, string> {
            { "SCALAR_ABANDONMENT_COST_WHP", "Abandonment Cost (Decommissioning cost) - WHP" },
            { "SCALAR_ABANDONMENT_COST_WELL", "Abandonment Cost (Decommissioning cost) - Well" },
            { "SCALAR_PRICE_CASE", "Price Case" },

            { "VECTOR_YEARS", "Years" },
            { "VECTOR_COSTS", "Cost Parameters" },
            { "VECTOR_COSTS_BREAKDOWN", "Project Cost Breakdown" },
            { "VECTOR_RIG_MOVE_COSTS", "Rig Move" },
            { "VECTOR_WELL_ABANDONMENT", "Well abandoned during the project" },
            { "VECTOR_ASSET_ENGINEERING_COST", "Asset Engineering Cost" },

            { "VECTOR_PARAMETERS", "Parameters" },

            { "VECTOR_DEVELOPMENT_WELL_COST", "Development Well Cost" },
            { "VECTOR_DEVELOPMENT_WELL_COST_CRITERIA1", "Year" },

            { "VECTOR_RIG_MOVE", "Rig Move" },
            { "VECTOR_RIG_MOVE_CRITERIA1", "Year" },

            { "VECTOR_PRODUCTION_PROFILE", "Production Profile" },
            { "VECTOR_PRODUCTION_PROFILE_DATE", "Date" },
            { "VECTOR_PRODUCTION_PROFILE_P10_OIL", "Oil" },
            { "VECTOR_PRODUCTION_PROFILE_P10_SOLUTION_GAS", "Solution Gas" },
            { "VECTOR_PRODUCTION_PROFILE_P10_GAS", "Gas" },
            { "VECTOR_PRODUCTION_PROFILE_P10_CONDENSATE", "Condensate" },
            { "VECTOR_PRODUCTION_PROFILE_P50_OIL", "Oil" },
            { "VECTOR_PRODUCTION_PROFILE_P50_SOLUTION_GAS", "Solution Gas" },
            { "VECTOR_PRODUCTION_PROFILE_P50_GAS", "Gas" },
            { "VECTOR_PRODUCTION_PROFILE_P50_CONDENSATE", "Condensate" },
            { "VECTOR_PRODUCTION_PROFILE_P90_OIL", "Oil" },
            { "VECTOR_PRODUCTION_PROFILE_P90_SOLUTION_GAS", "Solution Gas" },
            { "VECTOR_PRODUCTION_PROFILE_P90_GAS", "Gas" },
            { "VECTOR_PRODUCTION_PROFILE_P90_CONDENSATE", "Condensate" },
            { "VECTOR_PRODUCTION_PROFILE_EV_OIL", "Oil" },
            { "VECTOR_PRODUCTION_PROFILE_EV_SOLUTION_GAS", "Solution Gas" },
            { "VECTOR_PRODUCTION_PROFILE_EV_GAS", "Gas" },
            { "VECTOR_PRODUCTION_PROFILE_EV_CONDENSATE", "Condensate" },

            { "VECTOR_PRICE_DECK", "Price Deck" },
            { "VECTOR_PRICE_DECK_YEAR_MONTH", "YearMonth" },
            { "VECTOR_PRICE_DECK_YEAR", "Year" },
            { "VECTOR_PRICE_DECK_MONTH", "Month" },

            { "VECTOR_PRICE_DECK_LOW_CONTRACT1", "P10Contract 1" },
            { "VECTOR_PRICE_DECK_LOW_CTEP", "P10CTEP" },
            { "VECTOR_PRICE_DECK_LOW_PAILIN", "P10Pailin" },
            { "VECTOR_PRICE_DECK_LOW_CONDENSATE_DOMESTIC", "P10CondensateDomestic" },
            { "VECTOR_PRICE_DECK_LOW_PATTANI_DOMESTIC", "P10Pattani OilDomestic" },
            { "VECTOR_PRICE_DECK_LOW_PATTANI_EXPORT", "P10Pattani OilExport" },
            { "VECTOR_PRICE_DECK_LOW_B832_GAS", "P10B832 Gas" },
            { "VECTOR_PRICE_DECK_LOW_ARTHIT", "P10Arthit" },
            { "VECTOR_PRICE_DECK_LOW_B832_OIL_TANTAWAN", "P10B832 OilTantawan" },
            { "VECTOR_PRICE_DECK_LOW_B832_OIL_BENCHAMAS", "P10B832 OilBenchamas" },

            { "VECTOR_PRICE_DECK_MID_CONTRACT1", "P50Contract 1" },
            { "VECTOR_PRICE_DECK_MID_CTEP", "P50CTEP" },
            { "VECTOR_PRICE_DECK_MID_PAILIN", "P50Pailin" },
            { "VECTOR_PRICE_DECK_MID_CONDENSATE_DOMESTIC", "P50CondensateDomestic" },
            { "VECTOR_PRICE_DECK_MID_PATTANI_DOMESTIC", "P50Pattani OilDomestic" },
            { "VECTOR_PRICE_DECK_MID_PATTANI_EXPORT", "P50Pattani OilExport" },
            { "VECTOR_PRICE_DECK_MID_B832_GAS", "P50B832 Gas" },
            { "VECTOR_PRICE_DECK_MID_ARTHIT", "P50Arthit" },
            { "VECTOR_PRICE_DECK_MID_B832_OIL_TANTAWAN", "P50B832 OilTantawan" },
            { "VECTOR_PRICE_DECK_MID_B832_OIL_BENCHAMAS", "P50B832 OilBenchamas" },

            { "VECTOR_PRICE_DECK_HIGH_CONTRACT1", "P90Contract 1" },
            { "VECTOR_PRICE_DECK_HIGH_CTEP", "P90CTEP" },
            { "VECTOR_PRICE_DECK_HIGH_PAILIN", "P90Pailin" },
            { "VECTOR_PRICE_DECK_HIGH_CONDENSATE_DOMESTIC", "P90CondensateDomestic" },
            { "VECTOR_PRICE_DECK_HIGH_PATTANI_DOMESTIC", "P90Pattani OilDomestic" },
            { "VECTOR_PRICE_DECK_HIGH_PATTANI_EXPORT", "P90Pattani OilExport" },
            { "VECTOR_PRICE_DECK_HIGH_B832_GAS", "P90B832 Gas" },
            { "VECTOR_PRICE_DECK_HIGH_ARTHIT", "P90Arthit" },
            { "VECTOR_PRICE_DECK_HIGH_B832_OIL_TANTAWAN", "P90B832 OilTantawan" },
            { "VECTOR_PRICE_DECK_HIGH_B832_OIL_BENCHAMAS", "P90B832 OilBenchamas" },
        };

        public static readonly Dictionary<string, string> PROJECT_SETUP_RESULT_ADDRESSES = new Dictionary<string, string> {
            { "RESULT_NPV", "I6" },
            { "RESULT_INV", "I7" },
            { "RESULT_DPI", "I8" },
        };

        public static readonly Dictionary<string, string> PROJECT_SETUP_RESULT_LABELS = new Dictionary<string, string> {
            { "RESULT_NPV", "NPV" },
            { "RESULT_INV", "INV" },
            { "RESULT_DPI", "DPI" },
        };

        public DPITemplateCTEPProfile() : base()
        {
            Definitions = new HashSet<IExcelProfileDefinition>();
        }

        public DPITemplateCTEPProfile(IExcelEngine excel) : base(excel)
        {
            Definitions = new HashSet<IExcelProfileDefinition>();
        }

        public virtual void AddAdminPageValidate()
        {
            // Scalar Input Sheet
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["SCALAR_PARAMETERS"],
                ADMIN_PAGE_VALIDATION_LABELS["SCALAR_PARAMETERS"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["SCALAR_PARAMETERS"]));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["SCALAR_IN_USE_OR_ACTIVE"],
                ADMIN_PAGE_VALIDATION_LABELS["SCALAR_IN_USE_OR_ACTIVE"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["SCALAR_IN_USE_OR_ACTIVE"]));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["SCALAR_INDEX"],
                ADMIN_PAGE_VALIDATION_LABELS["SCALAR_INDEX"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["SCALAR_INDEX"]));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["SCALAR_MID"],
                ADMIN_PAGE_VALIDATION_LABELS["SCALAR_MID"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["SCALAR_MID"]));

            // Vector Input Sheet
            AddDefinition(SHEET_NAMES["VECTOR_INPUT"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["VECTOR_PARAMETERS"],
                ADMIN_PAGE_VALIDATION_LABELS["VECTOR_PARAMETERS"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["VECTOR_PARAMETERS"]));
            AddDefinition(SHEET_NAMES["VECTOR_INPUT"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["VECTOR_DEVELOPMENT_WELL_COST"],
                ADMIN_PAGE_VALIDATION_LABELS["VECTOR_DEVELOPMENT_WELL_COST"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["VECTOR_DEVELOPMENT_WELL_COST"]));
            AddDefinition(SHEET_NAMES["VECTOR_INPUT"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["VECTOR_RIG_MOVE"],
                ADMIN_PAGE_VALIDATION_LABELS["VECTOR_RIG_MOVE"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["VECTOR_RIG_MOVE"]));
            AddDefinition(SHEET_NAMES["VECTOR_INPUT"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["VECTOR_PRODUCTION_PROFILE"],
                ADMIN_PAGE_VALIDATION_LABELS["VECTOR_PRODUCTION_PROFILE"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["VECTOR_PRODUCTION_PROFILE"]));
            AddDefinition(SHEET_NAMES["VECTOR_INPUT"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["VECTOR_PRICE_DECK"],
                ADMIN_PAGE_VALIDATION_LABELS["VECTOR_PRICE_DECK"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["VECTOR_PRICE_DECK"]));

            // Result Sheet
            AddDefinition(SHEET_NAMES["RESULT"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["RESULT_NPV"],
                ADMIN_PAGE_VALIDATION_LABELS["RESULT_NPV"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["RESULT_NPV"]));
            AddDefinition(SHEET_NAMES["RESULT"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["RESULT_INVESTMENT"],
                ADMIN_PAGE_VALIDATION_LABELS["RESULT_INVESTMENT"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["RESULT_INVESTMENT"]));
            AddDefinition(SHEET_NAMES["RESULT"],
                ADMIN_PAGE_VALIDATION_ADDRESSES["RESULT_DPI"],
                ADMIN_PAGE_VALIDATION_LABELS["RESULT_DPI"],
                new ExcelValidation(possibleValue: ADMIN_PAGE_VALIDATION_LABELS["RESULT_DPI"]));
        }

        public virtual void AddProjectSetUpValidate()
        {
            // Scalar Input Sheet
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["SCALAR_START_YEAR"],
                PROJECT_SETUP_VALIDATION_LABELS["SCALAR_START_YEAR"],
                new ExcelValidation(type: ExcelCellType.Numeric));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["SCALAR_CURRENT_YEAR"],
                PROJECT_SETUP_VALIDATION_LABELS["SCALAR_CURRENT_YEAR"],
                new ExcelValidation(type: ExcelCellType.Numeric));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["SCALAR_DISCOUNT_YEAR"],
                PROJECT_SETUP_VALIDATION_LABELS["SCALAR_DISCOUNT_YEAR"],
                new ExcelValidation(type: ExcelCellType.Numeric));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["SCALAR_INFLATION_RATE"],
                PROJECT_SETUP_VALIDATION_LABELS["SCALAR_INFLATION_RATE"],
                new ExcelValidation(type: ExcelCellType.Percent));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["SCALAR_WORKING_INTEREST"],
                PROJECT_SETUP_VALIDATION_LABELS["SCALAR_WORKING_INTEREST"],
                new ExcelValidation(type: ExcelCellType.Percent));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["SCALAR_COMPANY"],
                PROJECT_SETUP_VALIDATION_LABELS["SCALAR_COMPANY"],
                new ExcelValidation(type: ExcelCellType.Text, possibleValue: "CTEP"));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["SCALAR_CONTRACT_END_DATE"],
                PROJECT_SETUP_VALIDATION_LABELS["SCALAR_CONTRACT_END_DATE"],
                new ExcelValidation(type: ExcelCellType.DateTime));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["SCALAR_RESERVES_CASE"],
                PROJECT_SETUP_VALIDATION_LABELS["SCALAR_RESERVES_CASE"],
                new ExcelValidation(type: ExcelCellType.Text));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["SCALAR_G_AND_A"],
                PROJECT_SETUP_VALIDATION_LABELS["SCALAR_G_AND_A"],
                new ExcelValidation(type: ExcelCellType.Percent));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["SCALAR_NUMBER_OF_YEAR_ABANDONMENT_WHP"],
                PROJECT_SETUP_VALIDATION_LABELS["SCALAR_NUMBER_OF_YEAR_ABANDONMENT_WHP"],
                new ExcelValidation(type: ExcelCellType.Numeric));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["SCALAR_NUMBER_OF_YEAR_ABANDONMENT_WELL"],
                PROJECT_SETUP_VALIDATION_LABELS["SCALAR_NUMBER_OF_YEAR_ABANDONMENT_WELL"],
                new ExcelValidation(type: ExcelCellType.Numeric));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["SCALAR_ABANDONMENT_COST"],
                PROJECT_SETUP_VALIDATION_LABELS["SCALAR_ABANDONMENT_COST"],
                new ExcelValidation(type: ExcelCellType.Numeric));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["SCALAR_YEAR_AFTER_LAST_PROD_WHP"],
                PROJECT_SETUP_VALIDATION_LABELS["SCALAR_YEAR_AFTER_LAST_PROD_WHP"],
                new ExcelValidation(type: ExcelCellType.Numeric));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["SCALAR_YEAR_AFTER_LAST_PROD_WELL"],
                PROJECT_SETUP_VALIDATION_LABELS["SCALAR_YEAR_AFTER_LAST_PROD_WELL"],
                new ExcelValidation(type: ExcelCellType.Numeric));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["SCALAR_PRICE_CASE"],
                PROJECT_SETUP_VALIDATION_LABELS["SCALAR_PRICE_CASE"],
                new ExcelValidation(type: ExcelCellType.Text));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["SCALAR_CTEP_PRICE"],
                PROJECT_SETUP_VALIDATION_LABELS["SCALAR_CTEP_PRICE"],
                new ExcelValidation(type: ExcelCellType.Text));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["SCALAR_GAS_CALOEIFIC"],
                PROJECT_SETUP_VALIDATION_LABELS["SCALAR_GAS_CALOEIFIC"],
                new ExcelValidation(type: ExcelCellType.Numeric));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["SCALAR_OPEX"],
                PROJECT_SETUP_VALIDATION_LABELS["SCALAR_OPEX"],
                new ExcelValidation(type: ExcelCellType.Numeric));
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["SCALAR_FUEL_OWN_USED"],
                PROJECT_SETUP_VALIDATION_LABELS["SCALAR_FUEL_OWN_USED"],
                new ExcelValidation(type: ExcelCellType.Percent));
        }

        /// <summary>
        /// Add drilling cost data.
        /// </summary>
        /// <param name="model"></param>
        public virtual void AddDrillingCostDefinition(ProjectWell model)
        {
            if (model == null)
                throw new ArgumentNullException("The queried drilling data is missing.");

            if (model.StartDate == null)
                throw new ArgumentNullException("The queried drilling cost date is missing.");

            if (model.TotalProductiveAFECost == null)
                throw new ArgumentNullException("The queried drilling cost value is missing.");

            var properties = new HashSet<IExcelProfileDefinitionProperties>();

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["VECTOR_DEVELOPMENT_WELL_COST"],
                RowCriteriaText = PROJECT_SETUP_WRITE_LABELS["VECTOR_DEVELOPMENT_WELL_COST"],
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_DEVELOPMENT_WELL_COST"],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["VECTOR_DEVELOPMENT_WELL_COST_CRITERIA1"],
                ColumnCriteriaText = DateTimeUtility.GetYear(model.StartDate.Value),
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_DEVELOPMENT_WELL_COST_CRITERIA1"],
                Value = model.TotalProductiveAFECost.Value,
            });

            Definitions.Add(new DPITemplateCTEPProfileDefinition
            {
                Mode = ExcelProfileDefinitionMode.WriteFirstHorizontal,
                Key = "DEVELOPMENT_WELL_COST_MAPPING",
                Label = "Development Well Cost Mapping",
                Datasource = properties,
                SheetName = SHEET_NAMES["VECTOR_INPUT"],
            });
        }

        public virtual void AddDrillingCostDefinition(IEnumerable<CTEPDrillingCost> models)
        {
            var properties = new HashSet<IExcelProfileDefinitionProperties>();

            foreach (var model in models)
            {
                properties.Add(new ExcelProfileDefinitionProperties
                {
                    RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["VECTOR_DEVELOPMENT_WELL_COST"],
                    RowCriteriaText = PROJECT_SETUP_WRITE_LABELS["VECTOR_DEVELOPMENT_WELL_COST"],
                    RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_DEVELOPMENT_WELL_COST"],
                    ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["VECTOR_DEVELOPMENT_WELL_COST_CRITERIA1"],
                    ColumnCriteriaText = DateTimeUtility.GetYear(model.Year),
                    ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_DEVELOPMENT_WELL_COST_CRITERIA1"],
                    Value = model.Value,
                });
            }

            Definitions.Add(new DPITemplateCTEPProfileDefinition
            {
                Mode = ExcelProfileDefinitionMode.WriteFirstHorizontal,
                Key = "DEVELOPMENT_WELL_COST_MAPPING",
                Label = "Development Well Cost Mapping",
                Datasource = properties,
                SheetName = SHEET_NAMES["VECTOR_INPUT"],
            });
        }

        /// <summary>
        /// Add rig move cost data.
        /// </summary>
        /// <param name="model"></param>
        public virtual void AddRigMoveCostDefinition(Job model)
        {
            if (model == null)
                throw new ArgumentNullException("The queried drilling data is missing.");

            if (model.StartDate == null)
                throw new ArgumentNullException("The queried drilling cost date is missing.");

            if (model.TotalCostCalculate == null)
                throw new ArgumentNullException("The queried drilling cost value is missing.");

            var properties = new HashSet<IExcelProfileDefinitionProperties>();

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["VECTOR_RIG_MOVE"],
                RowCriteriaText = PROJECT_SETUP_WRITE_LABELS["VECTOR_RIG_MOVE"],
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_RIG_MOVE"],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["VECTOR_RIG_MOVE_CRITERIA1"],
                ColumnCriteriaText = DateTimeUtility.GetYear(model.StartDate.Value),
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_RIG_MOVE_CRITERIA1"],
                Value = model.TotalCostCalculate.Value,
            });

            Definitions.Add(new DPITemplateCTEPProfileDefinition
            {
                Mode = ExcelProfileDefinitionMode.WriteFirstHorizontal,
                Key = "RIG_MOVE_MAPPING",
                Label = "Rig Move Mapping",
                Datasource = properties,
                SheetName = SHEET_NAMES["VECTOR_INPUT"],
            });
        }

        public virtual void AddRigMoveCostDefinition(IEnumerable<CTEPRigMoveCost> models)
        {
            var properties = new HashSet<IExcelProfileDefinitionProperties>();

            foreach (var model in models)
            {
                properties.Add(new ExcelProfileDefinitionProperties
                {
                    RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["VECTOR_RIG_MOVE"],
                    RowCriteriaText = PROJECT_SETUP_WRITE_LABELS["VECTOR_RIG_MOVE"],
                    RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_RIG_MOVE"],
                    ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["VECTOR_RIG_MOVE_CRITERIA1"],
                    ColumnCriteriaText = DateTimeUtility.GetYear(model.Year),
                    ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_RIG_MOVE_CRITERIA1"],
                    Value = model.Value,
                });
            }

            Definitions.Add(new DPITemplateCTEPProfileDefinition
            {
                Mode = ExcelProfileDefinitionMode.WriteFirstHorizontal,
                Key = "RIG_MOVE_MAPPING",
                Label = "Rig Move Mapping",
                Datasource = properties,
                SheetName = SHEET_NAMES["VECTOR_INPUT"],
            });
        }

        /// <summary>
        /// Add production profile to all phases for oil.
        /// </summary>
        /// <param name="oils"></param>
        public virtual void AddProductionProfileOilDefinition(IEnumerable<ProductionVolumn> oils, DateTime? endDate)
        {
            AddProductionProfileDefinition("P10", oils, null, null, null, endDate);
            AddProductionProfileDefinition("P50", oils, null, null, null, endDate);
            AddProductionProfileDefinition("P90", oils, null, null, null, endDate);
            AddProductionProfileDefinition("EV", oils, null, null, null, endDate);
        }

        /// <summary>
        /// Add production profile to all phases for solution gas.
        /// </summary>
        /// <param name="solutionGases"></param>
        public virtual void AddProductionProfileSolutionGasDefinition(IEnumerable<ProductionVolumn> solutionGases, DateTime? endDate)
        {
            AddProductionProfileDefinition("P10", null, solutionGases, null, null, endDate);
            AddProductionProfileDefinition("P50", null, solutionGases, null, null, endDate);
            AddProductionProfileDefinition("P90", null, solutionGases, null, null, endDate);
            AddProductionProfileDefinition("EV", null, solutionGases, null, null, endDate);
        }

        /// <summary>
        /// Add production profile to all phases for gas.
        /// </summary>
        /// <param name="gases"></param>
        public virtual void AddProductionProfileGasDefinition(IEnumerable<ProductionVolumn> gases, DateTime? endDate)
        {
            AddProductionProfileDefinition("P10", null, null, gases, null, endDate);
            AddProductionProfileDefinition("P50", null, null, gases, null, endDate);
            AddProductionProfileDefinition("P90", null, null, gases, null, endDate);
            AddProductionProfileDefinition("EV", null, null, gases, null, endDate);
        }

        /// <summary>
        /// Add production profile to all phases for condensate.
        /// </summary>
        /// <param name="condensates"></param>
        public virtual void AddProductionProfileCondensateDefinition(IEnumerable<ProductionVolumn> condensates, DateTime? endDate)
        {
            AddProductionProfileDefinition("P10", null, null, null, condensates, endDate);
            AddProductionProfileDefinition("P50", null, null, null, condensates, endDate);
            AddProductionProfileDefinition("P90", null, null, null, condensates, endDate);
            AddProductionProfileDefinition("EV", null, null, null, condensates, endDate);
        }
        
        private void AddProductionProfileDefinition(string level, IEnumerable<ProductionVolumn> oils, IEnumerable<ProductionVolumn> solutionGases,
            IEnumerable<ProductionVolumn> gases, IEnumerable<ProductionVolumn> condensates, DateTime? endDate)
        {
            var properties = new HashSet<IExcelProfileDefinitionProperties>();

            // Oil
            if (oils != null)
            {
                foreach (var oil in oils)
                {
                    AddProductionProfileDefinition(properties, oil, $"VECTOR_PRODUCTION_PROFILE_{level}_OIL", endDate);
                }
            }

            // Solution Gas
            if (solutionGases != null)
            {
                foreach (var solutionGas in solutionGases)
                {
                    AddProductionProfileDefinition(properties, solutionGas, $"VECTOR_PRODUCTION_PROFILE_{level}_SOLUTION_GAS", endDate);
                }
            }

            // Gas
            if (gases != null)
            {
                foreach (var gas in gases)
                {
                    AddProductionProfileDefinition(properties, gas, $"VECTOR_PRODUCTION_PROFILE_{level}_GAS", endDate);
                }
            }

            // Condensate
            if (condensates != null)
            {
                foreach (var condensate in condensates)
                {
                    AddProductionProfileDefinition(properties, condensate, $"VECTOR_PRODUCTION_PROFILE_{level}_CONDENSATE", endDate);
                }
            }

            Definitions.Add(new DPITemplateCTEPProfileDefinition
            {
                Mode = ExcelProfileDefinitionMode.WriteFirstVertical1Criteria,
                Key = $"PRODUCTION_PROFILE_{level}_MAPPING",
                Label = $"Production Profile {level} Mapping",
                Datasource = properties,
                SheetName = SHEET_NAMES["VECTOR_INPUT"],
            });
        }

        private void AddProductionProfileDefinition(ICollection<IExcelProfileDefinitionProperties> properties, ProductionVolumn model, string key, DateTime? endDate)
        {
            if (model == null)
                throw new ArgumentNullException("The queried production profile is missing.");

            if (model.CurrentDate == null)
                throw new ArgumentNullException("The queried production profile date is missing.");

            //if (model.TotalValue == null)
            //throw new ArgumentNullException("The queried production profile cost value is missing.");

            var date = model.CurrentDate.Value;
            if (endDate.HasValue && date > endDate.Value)
                return;

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["VECTOR_PRODUCTION_PROFILE_DATE"],
                RowCriteriaText = DateTimeUtility.GetShortenDate(date),
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_PRODUCTION_PROFILE_DATE"],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS[key],
                ColumnCriteriaText = PROJECT_SETUP_WRITE_LABELS[key],
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES[key],
                Value = model.TotalValue / DateTime.DaysInMonth(date.Year, date.Month),
            });
        }
        
        /// <summary>
        /// Add price case definitions by level, hc type, and area.
        /// </summary>
        /// <param name="level"></param>
        /// <param name="hcType"></param>
        /// <param name="area"></param>
        /// <param name="prices"></param>
        public virtual void AddPriceCaseDefinition(string level, string hcType, string area, IEnumerable<PeriodPrice> prices)
        {
            level = level?.ToUpper();
            hcType = hcType?.ToUpper();
            area = area?.ToUpper();

            if (!(new string[] { "LOW", "MID", "HIGH" }).Any(x => x == level))
                return;

            if (!(new string[] { "GAS", "OIL" }).Any(x => x == hcType))
                return;

            if (!(new string[] {
                "C1", "CTEP", "PAILIN", "CONDENSATE_DOMESTIC", "PATTANI OIL DOMESTIC", "PATTANI OIL EXPORT",
                "B8/32 GAS", "ARTHIT", "B8/32 OIL TAN", "B8/32 OIL BEN"
            }).Any(x => x == area))
                return;

            var properties = new HashSet<IExcelProfileDefinitionProperties>();

            foreach (var price in prices)
            {
                if (area == "C1" && hcType == "GAS")
                    AddPriceCaseDefinition(properties, price, $"VECTOR_PRICE_DECK_{level}_CONTRACT1");

                if (area == "CTEP" && hcType == "GAS")
                    AddPriceCaseDefinition(properties, price, $"VECTOR_PRICE_DECK_{level}_CTEP");

                if (area == "PAILIN" && hcType == "GAS")
                    AddPriceCaseDefinition(properties, price, $"VECTOR_PRICE_DECK_{level}_PAILIN");

                if (area == "CONDENSATE_DOMESTIC" && hcType == "OIL")
                    AddPriceCaseDefinition(properties, price, $"VECTOR_PRICE_DECK_{level}_CONDENSATE_DOMESTIC");

                if (area == "PATTANI OIL DOMESTIC" && hcType == "OIL")
                    AddPriceCaseDefinition(properties, price, $"VECTOR_PRICE_DECK_{level}_PATTANI_DOMESTIC");

                if (area == "PATTANI OIL EXPORT" && hcType == "OIL")
                    AddPriceCaseDefinition(properties, price, $"VECTOR_PRICE_DECK_{level}_PATTANI_EXPORT");

                if (area == "B8/32 GAS" && hcType == "GAS")
                    AddPriceCaseDefinition(properties, price, $"VECTOR_PRICE_DECK_{level}_B832_GAS");

                if (area == "ARTHIT" && hcType == "GAS")
                    AddPriceCaseDefinition(properties, price, $"VECTOR_PRICE_DECK_{level}_ARTHIT");

                if (area == "B8/32 OIL TAN" && hcType == "OIL")
                    AddPriceCaseDefinition(properties, price, $"VECTOR_PRICE_DECK_{level}_B832_OIL_TANTAWAN");

                if (area == "B8/32 OIL BEN" && hcType == "OIL")
                    AddPriceCaseDefinition(properties, price, $"VECTOR_PRICE_DECK_{level}_B832_OIL_BENCHAMAS");
            }

            if (properties.Count == 0)
                return;

            Definitions.Add(new DPITemplateCTEPProfileDefinition
            {
                Mode = ExcelProfileDefinitionMode.WriteVertical2Criterion,
                Key = $"PRICE_DECK_{level}_{hcType}_{area}_MAPPING",
                Label = $"Price Deck {level} {hcType} {area} Mapping",
                Datasource = properties,
                SheetName = SHEET_NAMES["VECTOR_INPUT"],
                RangeX = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_PRICE_DECK_TYPE"],
                RangeY = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_PRICE_DECK_YEAR_MONTH"],
            });
        }

        private void AddPriceCaseDefinition(ICollection<IExcelProfileDefinitionProperties> properties, PeriodPrice model, string key)
        {
            if (model == null)
                throw new ArgumentNullException("The queried price is missing.");

            if (model.CurrentDate == null)
                throw new ArgumentNullException("The queried price date is missing.");

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["VECTOR_PRICE_DECK_YEAR_MONTH"],
                RowCriteriaText = $"{DateTimeUtility.GetYear(model.CurrentDate.Value)}{DateTimeUtility.GetShortenMonth(model.CurrentDate.Value)?.ToUpper()}",
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS[key],
                ColumnCriteriaText = PROJECT_SETUP_WRITE_LABELS[key],
                Value = model.Value,
            });
        }

        /// <summary>
        /// Add Well DPI division by given well amount.
        /// </summary>
        /// <param name="wellAmount"></param>
        public virtual void AddWellDPIDividingDefinition(int wellAmount)
        {
            AddWellDPIDividingScalarDefinition(wellAmount);

            AddWellDPIDividingVectorDefinition(wellAmount);
        }

        private void AddWellDPIDividingScalarDefinition(int wellAmount)
        {
            var properties = new HashSet<IExcelProfileDefinitionProperties>();

            AddWellDPIDividingScalarDefinition(properties, wellAmount, "SCALAR_ABANDONMENT_COST_WHP");
            AddWellDPIDividingScalarDefinition(properties, wellAmount, "SCALAR_ABANDONMENT_COST_WELL");

            Definitions.Add(new DPITemplateCTEPProfileDefinition
            {
                Mode = ExcelProfileDefinitionMode.AppendFormula,
                Key = "WELL_DPI_DIVIDING_SCALAR",
                Label = "Well DPI dividing scalar",
                Datasource = properties,
                SheetName = SHEET_NAMES["SCALAR_INPUT"],
            });
        }

        private void AddWellDPIDividingScalarDefinition(ICollection<IExcelProfileDefinitionProperties> properties, int wellAmount, string key)
        {
            properties.Add(new ExcelProfileDefinitionProperties
            {
                RangeAddress = PROJECT_SETUP_WRITE_ADDRESSES[key],
                Formula = $"=((value)/{wellAmount})",
            });
        }

        private void AddWellDPIDividingVectorDefinition(int wellAmount)
        {
            var properties = new HashSet<IExcelProfileDefinitionProperties>();

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["VECTOR_COSTS"],
                RowCriteriaIncludedText = null,
                RowCriteriaExcludedText = null,
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_COSTS"],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["VECTOR_YEARS"],
                ColumnCriteriaIncludedText = null,
                ColumnCriteriaExcludedText = null,
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_YEARS"],
                Formula = $"=((value)/{wellAmount})",
            });

            Definitions.Add(new DPITemplateCTEPProfileDefinition
            {
                Mode = ExcelProfileDefinitionMode.AppendFormula1Criteria,
                Key = "WELL_DPI_DIVIDING_VECTOR",
                Label = "Well DPI dividing vector",
                Datasource = properties,
                SheetName = SHEET_NAMES["VECTOR_INPUT"],
            });
        }

        /// <summary>
        /// Clear values.
        /// </summary>
        public virtual void AddClearValuesDefinition()
        {
            var properties = new HashSet<IExcelProfileDefinitionProperties>();

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["VECTOR_COSTS_BREAKDOWN"],
                RowCriteriaIncludedText = null,
                RowCriteriaExcludedText = null,
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_COSTS_BREAKDOWN"],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["VECTOR_YEARS"],
                ColumnCriteriaIncludedText = null,
                ColumnCriteriaExcludedText = null,
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_YEARS"],
            });

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["VECTOR_RIG_MOVE_COSTS"],
                RowCriteriaIncludedText = null,
                RowCriteriaExcludedText = null,
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_RIG_MOVE_COSTS"],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["VECTOR_YEARS"],
                ColumnCriteriaIncludedText = null,
                ColumnCriteriaExcludedText = null,
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_YEARS"],
            });

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["VECTOR_WELL_ABANDONMENT"],
                RowCriteriaIncludedText = null,
                RowCriteriaExcludedText = null,
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_WELL_ABANDONMENT"],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["VECTOR_YEARS"],
                ColumnCriteriaIncludedText = null,
                ColumnCriteriaExcludedText = null,
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_YEARS"],
            });

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RowCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["VECTOR_ASSET_ENGINEERING_COST"],
                RowCriteriaIncludedText = null,
                RowCriteriaExcludedText = null,
                RowCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_ASSET_ENGINEERING_COST"],
                ColumnCriteriaLabel = PROJECT_SETUP_WRITE_LABELS["VECTOR_YEARS"],
                ColumnCriteriaIncludedText = null,
                ColumnCriteriaExcludedText = null,
                ColumnCriteriaRangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["VECTOR_YEARS"],
            });

            Definitions.Add(new DPITemplateCTEPProfileDefinition
            {
                Mode = ExcelProfileDefinitionMode.Clear1Criteria,
                Key = "WELL_DPI_CLEAR_VECTOR",
                Label = "Well DPI clear vector value",
                Datasource = properties,
                SheetName = SHEET_NAMES["VECTOR_INPUT"],
            });
        }

        /// <summary>
        /// Add price case type where case is LOW, MID, or HIGH.
        /// </summary>
        /// <param name="caseType"></param>
        public virtual void AddPriceCaseTypeDefinition(string caseType)
        {
            int caseNum;

            switch (caseType?.ToLower())
            {
                case "low":
                    caseNum = 1;
                    break;
                case "mid":
                    caseNum = 2;
                    break;
                case "high":
                    caseNum = 3;
                    break;
                default:
                    throw new ArgumentException($"Unknown price case: {caseType}.");
            }

            var properties = new HashSet<IExcelProfileDefinitionProperties>();

            properties.Add(new ExcelProfileDefinitionProperties
            {
                RangeAddress = PROJECT_SETUP_WRITE_ADDRESSES["SCALAR_PRICE_CASE"],
                Value = caseNum,
            });

            Definitions.Add(new DPITemplateCTEPProfileDefinition
            {
                Mode = ExcelProfileDefinitionMode.Write,
                Key = "PRICE_CASE_SETTING",
                Label = "Price Case Setting",
                Datasource = properties,
                SheetName = SHEET_NAMES["SCALAR_INPUT"],
            });
        }

        /// <summary>
        /// Add end date reading action. Call GetReadEndDate() next in order to get the date.
        /// </summary>
        public virtual void AddEndDateReadDefinition()
        {
            // Extract
            AddDefinition(SHEET_NAMES["SCALAR_INPUT"],
                PROJECT_SETUP_VALIDATION_ADDRESSES["SCALAR_CONTRACT_END_DATE"],
                PROJECT_SETUP_VALIDATION_LABELS["SCALAR_CONTRACT_END_DATE"],
                "SCALAR_CONTRACT_END_DATE_VALUE",
                new ExcelValidation(type: ExcelCellType.DateTime, isValid: true));
        }

        /// <summary>
        /// Get read end date.
        /// </summary>
        /// <returns></returns>
        public virtual DateTime? GetReadEndDate()
        {
            var keys = new string[] { "SCALAR_CONTRACT_END_DATE_VALUE" };
            var definition = Definitions.FirstOrDefault(d => keys.Contains(d.Key));
            if (definition == null) throw new InvalidOperationException("No read definition has been loaded or executed.");

            var val = definition.Results.FirstOrDefault();
            DateTime? result = null;

            try
            {
                if (val?.RawValue != null)
                    result = Convert.ToDateTime(val.RawValue);
            }
            catch (Exception)
            {
                throw new InvalidOperationException("Failed on reading. Contract end date is invalid.");
            }

            return result;
        }

        /// <summary>
        /// Add DPI reading action. Call GetReadDPI() next in order to get the DPI.
        /// </summary>
        public virtual void AddDPIReadDefinition()
        {
            // Recalculate
            AddDefinition(SHEET_NAMES["RESULT"],
                null,
                null,
                ExcelProfileDefinitionMode.Recalculate);

            // Extract
            AddDefinition(SHEET_NAMES["RESULT"],
                PROJECT_SETUP_RESULT_ADDRESSES["RESULT_NPV"],
                PROJECT_SETUP_RESULT_LABELS["RESULT_NPV"],
                "RESULT_NPV_VALUE",
                new ExcelValidation(type: ExcelCellType.Numeric, isValid: true));
            AddDefinition(SHEET_NAMES["RESULT"],
                PROJECT_SETUP_RESULT_ADDRESSES["RESULT_INV"],
                PROJECT_SETUP_RESULT_LABELS["RESULT_INV"],
                "RESULT_INV_VALUE",
                new ExcelValidation(type: ExcelCellType.Numeric, isValid: true));
            AddDefinition(SHEET_NAMES["RESULT"],
                PROJECT_SETUP_RESULT_ADDRESSES["RESULT_DPI"],
                PROJECT_SETUP_RESULT_LABELS["RESULT_DPI"],
                "RESULT_DPI_VALUE",
                new ExcelValidation(type: ExcelCellType.Numeric, isValid: true));
        }

        /// <summary>
        /// Get read DPI.
        /// </summary>
        /// <returns></returns>
        public virtual ProjectDPIResult GetReadDPI()
        {
            var keys = new string[] { "RESULT_NPV_VALUE", "RESULT_INV_VALUE", "RESULT_DPI_VALUE" };
            var definitions = Definitions.Where(definition => keys.Contains(definition.Key));
            if (definitions == null || definitions?.Count() == 0) throw new InvalidOperationException("No read definition has been loaded or executed.");

            var result = new ProjectDPIResult();

            foreach (var definition in definitions)
            {
                var sum = definition.Results?.Sum(val => Convert.ToDecimal(val.RawValue));

                if (sum == null) continue;

                if (definition.Key == "RESULT_NPV_VALUE")
                {
                    result.NPV = sum.Value;
                }
                else if (definition.Key == "RESULT_INV_VALUE")
                {
                    result.INV = sum.Value;
                }
                else if (definition.Key == "RESULT_DPI_VALUE")
                {
                    result.DPI = sum.Value;
                }
            }

            return result;
        }

        public override void Execute()
        {
            base.Execute();
        }

        public override string GetVersion()
        {
            return "Project DPI Template CTEP v1.0.00";
        }
    }

    public class DPITemplateCTEPProfileDefinition : ExcelTemplateProfileDefinition
    {
        public string RangeX { get; set; }

        public string RangeY { get; set; }

        public override void Write2Criterion()
        {
            if (DataEngine == null) throw new InvalidOperationException("Excel engine is not initialized.");

            var workSheet = DataEngine.GetWorksheet(SheetName);
            if (workSheet == null) throw new InvalidOperationException("Given worksheet cannot be found.");

            var rangeX = workSheet.GetMergedValueByColumn(RangeX);

            var rangeY = workSheet.GetMergedValueByRow(RangeY);

            foreach (var data in Datasource)
            {
                if (string.IsNullOrEmpty(data.ColumnCriteriaText) || string.IsNullOrEmpty(data.RowCriteriaText))
                    throw new ArgumentNullException("Reference cell criterion are not configured.");

                var matchedColumn = rangeX.Where(cell => cell.Value == data.ColumnCriteriaText).FirstOrDefault();
                if (matchedColumn == null) throw new InvalidOperationException(string.Format("Cannot find \"{0}\": \"{1}\" from \"{2}\".", data.ColumnCriteriaLabel, data.ColumnCriteriaText, RangeX));

                var matchedRow = rangeY.Where(cell => cell.Value == data.RowCriteriaText).FirstOrDefault();
                if (matchedRow == null) throw new InvalidOperationException(string.Format("Cannot find \"{0}\": \"{1}\" from \"{2}\".", data.RowCriteriaLabel, data.RowCriteriaText, RangeY));

                var address = string.Format("{0}{1}", ExcelUtility.GetExcelColumnName(matchedColumn.Column), matchedRow.Row);
                workSheet.Write(address, data.Value);
            }
        }

    }

    public class CTEPDrillingCost
    {
        public DateTime Year { get; set; }

        public object Value { get; set; }
    }

    public class CTEPRigMoveCost
    {
        public DateTime Year { get; set; }

        public object Value { get; set; }
    }
}
