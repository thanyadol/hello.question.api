﻿using surflex.netcore22.Models;
using surflex.netcore22.Models.Constants;
using System; 

using System.Collections.Generic;
using System.Linq;

namespace surflex.netcore22.Helpers
{
    public class DecisionTraveller
    {
        #region Json structure to Entry
        /// <summary>
        /// Extract decision node from a Silver Decision's save format as DTO.
        /// </summary>
        /// <param name="savedObject"></param>
        public static ExtractedResult ExtractFromSavedObject(Guid id, SilverDecisions.SavedObject savedObject)
        {
            if (savedObject == null) throw new ArgumentNullException();
            if (savedObject.Data == null) throw new ArgumentNullException();
            //if (savedObject.Data.Trees == null || savedObject.Data.Trees.Count == 0) throw new ArgumentNullException();

            var tree = new DecisionTreeDto()
            {
                WellScenarioId = id,
                Name = savedObject.Title,
                Description = savedObject.Description
            };

            return NodeTraverse(savedObject.Data.Trees, tree);
        }

        /// <summary>
        /// Main function to traverse across all nodes.
        /// </summary>
        /// <param name="nodes"></param>
        /// <param name="tree"></param>
        /// <returns></returns>
        private static ExtractedResult NodeTraverse(List<SilverDecisions.Node> nodes, DecisionTreeDto tree)
        {
            var results = new ExtractedResult(tree);

            //Loop trough all root nodes
            foreach (SilverDecisions.Node root in nodes ?? new List<SilverDecisions.Node>())
            {
                var fromNode = ExtractNode(root, tree);
                results.nodes.Add(fromNode);

                NodeTraverse(fromNode, root.ChildEdges, tree, results);
            }

            return results;
        }

        /// <summary>
        /// Recursive function used in node traversal.
        /// </summary>
        /// <param name="node"></param>
        /// <param name="tree"></param>
        /// <param name="result"></param>
        private static void NodeTraverse(DecisionNodeDto fromNode, List<SilverDecisions.Edge> edges, DecisionTreeDto tree,
            ExtractedResult results)
        {
            if (edges == null) return;

            foreach (SilverDecisions.Edge edge in edges)
            {
                var toNode = ExtractNode(edge.ChildNode, tree);
                results.nodes.Add(toNode);

                var extractedEdge = ExtractEdge(edge, fromNode, toNode);
                results.edges.Add(extractedEdge);

                if (edge.ChildNode.HasChildEdge)
                {
                    NodeTraverse(toNode, edge.ChildNode.ChildEdges, tree, results);
                }
            }
        }

        private static DecisionNodeDto ExtractNode(SilverDecisions.Node node, DecisionTreeDto tree)
        {
            return new DecisionNodeDto()
            {
                Id = Guid.NewGuid(),
                TreeId = tree.WellScenarioId,
                Name = node.Name,
                Code = node.Code,
                Type = node.Type.ToUpper(),
                AdditionalCost = node.AdditionalCost,
                TotalCost = node.TotalCost,
                INV = node.INV,
                NPV = node.NPV,
                DPI = node.DPI,
                TotalInMBOE = node.TotalInMBOE,
                LiquidInMBOE = node.LiquidInMBOE,
                GasInMMScf = node.GasInMMScf,
                X = node.Location != null ? node.Location.X : 0,
                Y = node.Location != null ? node.Location.Y : 0
            };
        }

        private static DecisionEdgeDto ExtractEdge(SilverDecisions.Edge edge, DecisionNodeDto from, DecisionNodeDto to)
        {
            return new DecisionEdgeDto()
            {
                Id = Guid.NewGuid(),
                ActivityId = edge.ActivityId,
                Name = edge.Name,
                Payoff1 = edge.ComputedPayoff1,
                Payoff2 = edge.ComputedPayoff2,
                Probability = edge.ComputedProbability,
                FromId = from.Id,
                ToId = to.Id
            };
        }

        public class ExtractedResult
        {
            public DecisionTreeDto tree;
            public List<DecisionNodeDto> nodes;
            public List<DecisionEdgeDto> edges;

            public ExtractedResult()
            {
                tree = new DecisionTreeDto();
                nodes = new List<DecisionNodeDto>();
                edges = new List<DecisionEdgeDto>();
            }

            public ExtractedResult(DecisionTreeDto tree)
            {
                this.tree = tree;
                nodes = new List<DecisionNodeDto>();
                edges = new List<DecisionEdgeDto>();
            }
        }
        #endregion

        #region Entry to Json structure
        /// <summary>
        /// Construct Silver Decision's structure from DTO.
        /// </summary>
        /// <param name="nodes"></param>
        /// <param name="edges"></param>
        public static SilverDecisions.SavedObject BuildFromEntity(DecisionTreeDto tree, IEnumerable<DecisionNodeDto> nodes, IEnumerable<DecisionEdgeDto> edges)
        {
            var rootNodes = BuildNodes(nodes, edges);

            var savedObject = new SilverDecisions.SavedObject()
            {
                Title = tree.Name,
                Description = tree.Description,
                Data = new SilverDecisions.Data()
                {
                    Code = null,
                    Trees = rootNodes
                }
            };

            return savedObject;
        }

        private static List<SilverDecisions.Node> BuildNodes(IEnumerable<DecisionNodeDto> nodes, IEnumerable<DecisionEdgeDto> edges)
        {
            var hashNodes = new HashSet<SilverDecisions.Node>();

            foreach (var entryNode in nodes)
            {
                var node = new SilverDecisions.Node()
                {
                    Id = entryNode.Id,
                    Name = entryNode.Name,
                    Code = null,
                    Type = entryNode.Type,
                    ChildEdges = new List<SilverDecisions.Edge>(),
                    AdditionalCost = IsTerminalNode(entryNode.Type) ? entryNode.AdditionalCost : null,
                    DPI = IsTerminalNode(entryNode.Type) ? entryNode.DPI : null,
                    INV = IsTerminalNode(entryNode.Type) ? entryNode.INV : null,
                    NPV = IsTerminalNode(entryNode.Type) ? entryNode.NPV : null,
                    TotalInMBOE = IsTerminalNode(entryNode.Type) ? entryNode.TotalInMBOE : null,
                    TotalCost = IsTerminalNode(entryNode.Type) ? entryNode.TotalCost : null,
                    LiquidInMBOE = IsTerminalNode(entryNode.Type) ? entryNode.LiquidInMBOE : null,
                    GasInMMScf = IsTerminalNode(entryNode.Type) ? entryNode.GasInMMScf : null,
                    Location = new SilverDecisions.Location()
                    {
                        X = entryNode.X,
                        Y = entryNode.Y
                    }
                };
                hashNodes.Add(node);
            }

            foreach (var entryEdge in edges)
            {
                var edge = new SilverDecisions.Edge()
                {
                    Id = entryEdge.Id,
                    ActivityId = entryEdge.ActivityId,
                    Name = entryEdge.Name,
                    EnteredProbability = entryEdge.Probability,
                    ChildNode = hashNodes.FirstOrDefault(node => node.Id == entryEdge.ToId)
                };
                edge.AddPayoff(entryEdge.Payoff1, entryEdge.Payoff2);

                var parent = hashNodes.FirstOrDefault(node => node.Id == entryEdge.FromId);
                if (parent != null)
                {
                    parent.ChildEdges.Add(edge);
                }
            }

            return hashNodes.Where(node => !edges.Any(edge => edge.ToId == node.Id)).ToList();
        }
        #endregion

        public static bool IsTerminalNode(string status)
        {
            return status == GlobalConstants.DECISION_TREE_NODE_TYPE_TERMINAL;
        }
    }
}