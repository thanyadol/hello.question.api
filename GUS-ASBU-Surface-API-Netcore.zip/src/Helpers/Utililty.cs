using System; 

using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;

//apis
//using surflex.netcore22.APIs;

namespace surflex.netcore22.Helpers
{
    public static class Utility
    {


        /// <summary>
        /// create sha256 for well id
        /// </summary>
        /// <returns>
        /// list of well 
        /// </returns>
        /// <exception cref="System.Exception">Thrown when ??</exception>
        /// <param name="id">wellid</param>
        ///
        public static string ToSHA256(string id)
        {
            var crypt = new SHA1Managed();
            string hash = String.Empty;
            byte[] crypto = crypt.ComputeHash(Encoding.ASCII.GetBytes(id));
            foreach (byte theByte in crypto)
            {
                hash += theByte.ToString("x2");
            }

            return hash;
        }

        /// <summary>
        /// get enumdrscription string
        /// </summary>
        /// <returns>
        /// list of well 
        /// </returns>
        /// <exception cref="System.Exception">Thrown when ??</exception>
        /// <param name="enumerationValue">enum</param>
        ///
     /*    public static string ParseEnumDescription<T>(this T enumerationValue)
       where T : struct
        {
            Type type = enumerationValue.GetType();
            if (!type.IsEnum)
            {
                throw new ArgumentException("EnumerationValue must be of Enum type", "enumerationValue");
            }

            //Tries to find a DescriptionAttribute for a potential friendly name
            //for the enum
            MemberInfo[] memberInfo = type.GetMember(enumerationValue.ToString());
            if (memberInfo != null && memberInfo.Length > 0)
            {
                object[] attrs = memberInfo[0].GetCustomAttributes(typeof(DescriptionAttribute), false);

                if (attrs != null && attrs.Length > 0)
                {
                    //Pull out the description value
                    return ((DescriptionAttribute)attrs[0]).Description;
                }
            }
            //If we have no description attribute, just return the ToString of the enum
            return enumerationValue.ToString();
        }*/

        public static double ToUnixTimestamp(DateTime dateTime)
        {
            return (TimeZoneInfo.ConvertTimeToUtc(dateTime) -
                   new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc)).TotalSeconds;
        }

        public static DateTime CurrentSEAsiaStandardTime()
        {
            DateTime dt = DateTime.UtcNow.ToLocalTime();

            /* try
            {
                dt = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZoneById("SE Asia Standard Time"));
            }
            catch (TimeZoneNotFoundException)
            { }*/

            return dt;
        }

        public static string ToUniqeIdentity(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw new NullReferenceException();
            }

            return ToSHA256(name.ToUpper());
        }


        public static string ToPlaformIdentity(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw new NullReferenceException();
            }

            string[] words = name.Split("_");
            return words[0];
        }

        // Return the column number for this column name.
        public static int ParseExcelColumnToIndex(string col_name)
        {
            int result = 0;

            // Process each letter.
            for (int i = 0; i < col_name.Length; i++)
            {
                result *= 26;
                char letter = col_name[i];

                // See if it's out of bounds.
                if (letter < 'A') letter = 'A';
                if (letter > 'Z') letter = 'Z';

                // Add in the value of this letter.
                result += (int)letter - (int)'A' + 1;
            }
            return result;
        }

        // Return the column name for this column number.
        public static string ParseExcelIndexToColumn(int col_num)
        {
            // See if it's out of bounds.
            if (col_num < 1) return "A";

            // Calculate the letters.
            string result = "";
            while (col_num > 0)
            {
                // Get the least significant digit.
                col_num -= 1;
                int digit = col_num % 26;

                // Convert the digit into a letter.
                result = (char)((int)'A' + digit) + result;

                col_num = (int)(col_num / 26);
            }

            return result;
        }


        public static decimal ParseMMSCFtoBBL(decimal mmscf)
        {
            var a = 6;
            var b = 10;

            var result = mmscf * (decimal)Math.Pow(b, a);

            return result;
        }

        public static decimal ParseMBOEToMMSCF(decimal mmscf)
        {
            var a = 6;
            // var b = 1000;

            return (mmscf * a);
        }

        public static decimal ParseMMSCFtoMBOE(decimal mmscf)
        {
            var a = 6;
            // var b = 1000;

            return (mmscf / a);
        }


        //BCF to MBOE
        public static decimal ParseBCFtoMBOE(decimal boe)
        {
            var a = 1000;
            var b = 6;

            return ((boe * a) / b);
        }

        public static decimal ParseMMSCFtoMMBTU(decimal mmscf)
        {
            var b = 1000;

            return (mmscf * b);
        }

        public static decimal ParseMMBTUToMMSCF(decimal mmbtu)
        {
            var b = 1000;

            return (mmbtu / b);
        }

        public static decimal ParseMMSCFToSCF(decimal mmbtu)
        {
            var b = 1000000;

            return (mmbtu / b);
        }


        public static decimal ParseBCFToMMSCF(decimal bcf)
        {
            var b = 1000;

            return (bcf * b);
        }



        public static decimal ParseMBOEToBOE(decimal mboe)
        {
            var b = 1000;

            return (mboe * b);
        }


        public static bool EnforceIsContainedAZI(string category)
        {
            if (String.IsNullOrEmpty(category)) return true;

            return category.Contains("AZI");
        }

        public static decimal ParenthesToNegative(string parenthis)
        {
            // using System.Globalization
            double d = double.Parse(parenthis, NumberStyles.AllowParentheses |
                                                  NumberStyles.AllowThousands |
                                                  NumberStyles.AllowDecimalPoint);

            return Convert.ToDecimal(d);
        }

        public static int ParseMonthMMMToInt(string month)
        {
            return DateTime.ParseExact(month, "MMM", CultureInfo.CurrentCulture).Month;
        }

        public static decimal TryParseFractionalDecimal(string value)
        {
            decimal parsed;

            if (decimal.TryParse(value, out parsed))
            {
                return parsed;
            }

            string[] split = value.Split(new char[] { ' ', '/' });

            if (split.Length == 2 || split.Length == 3)
            {
                decimal a, b;

                if (decimal.TryParse(split[0], out a) && decimal.TryParse(split[1], out b))
                {
                    if (split.Length == 2)
                    {
                        return a / b;
                    }

                    decimal c;

                    if (decimal.TryParse(split[2], out c))
                    {
                        return a + b / c;
                    }
                }
            }

            throw new FormatException("Not a valid fraction.");
        }
    }
}