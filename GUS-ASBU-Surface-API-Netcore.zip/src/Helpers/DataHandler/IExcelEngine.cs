﻿using System; 

using System.Collections;
using System.Collections.Generic;
using System.IO;

namespace surflex.netcore22.Helpers.DataHandler
{
    public interface IExcelEngine : IDataEngine, IDisposable
    {
        void Open(Stream stream);

        void Open(FileInfo fileInfo);

        void Open(string filePath);

        IExcelWorksheet GetWorksheet(string sheetName);

        void Save();
        
        void SaveAs(Stream stream);

        void Calculate();

        bool IsLoaded { get; }
    }

    public interface IExcelWorksheet
    {
        IExcelRange GetRange(string address);

        IExcelCell GetCell(string address);

        IExcelRange GetMergedValueByRow(string address);

        IExcelRange GetMergedValueByColumn(string address);

        IExcelCell FindFirst(string find);

        IExcelCell FindFirst(string find, string address);

        IExcelRange Find(string find);

        IExcelRange Find(string find, string address);

        IExcelRange Find(IEnumerable<string> include, IEnumerable<string> exclude, string address);

        void Write(string address, object value);

        void Write(int row, int column, object value);

        void Write(int row, int column, string value);

        IExcelRange AppendFormula(string address, string formula);

        void Clear(string address);

        void Clear(int row, int column);
    }

    public interface IExcelCell
    {
        int Row { get; }

        int Column { get; }

        string Address { get; }

        string Value { get; }

        object RawValue { get; }
    }

    public interface IExcelRange : IEnumerable<IExcelCell>, IEnumerable, IData
    {
        void Add(IExcelCell cell);
    }

    public interface IExcelValidation<T> : IDataValidation<T> where T : IExcelRange
    {
        string SheetName { get; set; }

        string Label { get; set; }

        string CellRange { get; set; }

        bool IsRequired { get; set; }

        bool IsAllRequired { get; set; }

        bool IsValid { get; set; }

        bool IsAllValid { get; set; }

        ExcelCellType Type { get; set; }

        ICollection<string> Contains { get; set; }

        ICollection<string> PossibleValues { get; set; }
    }

    public enum ExcelCellType
    {
        Any = 0,
        Numeric = 1,
        Text = 2,
        DateTime = 3,
        Percent = 4,
    }
}
