﻿using System; 

using System.Collections.Generic;
using System.IO;

namespace surflex.netcore22.Helpers.DataHandler
{
    public interface IDataHandler : IDisposable
    {
        void Load(IDataProfile profile, string path);

        void Load(IDataProfile profile, Stream stream);

        void Load(IDataProfile profile);

        void Load(Stream stream);

        void Save();

        void SaveAs(string path);

        void SaveAs(Stream stream);

        void Execute();

        IDataProfile GetProfile();
    }

    public interface IDataEngine
    {
    }

    public interface IData
    {
    }

    public interface IDataProfile
    {
        ICollection<IProfileDefinition> GetDefinitions();

        IProfileDefinition GetDefinition(string definition);

        void ClearDefinitions();

        void Execute();

        string GetVersion();
    }

    public interface IProfileDefinition
    {
        void Execute();
    }

    public interface IProfileDefinitionProperties
    {
        object Value { get; set; }
    }

    public interface IDataValidation<T> where T : IData
    {
        void Validate(T data);
    }

}
