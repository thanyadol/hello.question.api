﻿
using System; 

using System.IO;

namespace surflex.netcore22.Helpers.DataHandler
{
    public class ExcelTemplateHandler : IExcelTemplateHandler
    {
        public IExcelEngine DataEngine { get; set; }

        private IExcelProfile Profile;

        public ExcelTemplateHandler()
        {
            DataEngine = new ExcelEngine();
        }

        public void Load(IDataProfile profile, string path)
        {
            using (var stream = File.OpenRead(path))
            {
                Load(profile, stream);
            }
        }

        public void Load(IDataProfile profile, Stream stream)
        {
            Profile = profile as IExcelProfile;
            
            DataEngine = new ExcelEngine(stream);

            Profile.DataEngine = DataEngine;
        }

        public void Load(IDataProfile profile)
        {
            Profile = profile as IExcelProfile;

            Profile.DataEngine = DataEngine ?? null;
        }

        public void Load(Stream stream)
        {
            DataEngine = new ExcelEngine(stream);

            if (Profile != null)
                Profile.DataEngine = DataEngine;
        }

        public void Save()
        {
            if (DataEngine == null) throw new InvalidOperationException("Workbook hasn't been loaded or failed on loading.");

            DataEngine.Save();
        }

        public void SaveAs(string path)
        {
            if (DataEngine == null) throw new InvalidOperationException("Workbook hasn't been loaded or failed on loading.");

            using (var stream = File.Create(path))
            {
                SaveAs(stream);
            }
        }

        public void SaveAs(Stream stream)
        {
            if (DataEngine == null) throw new InvalidOperationException("Workbook hasn't been loaded or failed on loading.");

            DataEngine.SaveAs(stream);
        }

        public IDataProfile GetProfile()
        {
            if (Profile == null) throw new InvalidOperationException("Profile hasn't been loaded or failed on loading.");
            if (DataEngine == null || DataEngine?.IsLoaded == false) throw new InvalidOperationException("Workbook hasn't been loaded or failed on loading.");

            return Profile;
        }
        
        public void Execute()
        {
            if (DataEngine == null || DataEngine.IsLoaded == false) throw new InvalidOperationException("Workbook hasn't been loaded or failed on loading.");
            if (Profile == null) throw new InvalidOperationException("Profile hasn't been loaded or failed on loading.");

            Profile.Execute();
        }

        private void Close()
        {
            if (DataEngine != null)
            {
                DataEngine.Dispose();
            }
        }

        #region IDisposable Support
        private bool disposedValue = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    Close();
                }
                
                disposedValue = true;
            }
        }
        
        public void Dispose()
        {
            Dispose(true);
        }
        #endregion

    }



}
