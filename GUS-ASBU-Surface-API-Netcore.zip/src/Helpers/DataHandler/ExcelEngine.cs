﻿using Aspose.Cells;
using System; 

using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace surflex.netcore22.Helpers.DataHandler
{
    public class ExcelEngine : IExcelEngine
    {
        public Workbook Excel;

        private Stream FileStream;

        //public string LicensePath = "Aspose.Total.lic";

        public bool IsLoaded { get => FileStream != null; }

        public ExcelEngine()
        {
            ApplyLicense();
            Open();
        }

        public ExcelEngine(Stream stream) : this()
        {
            ApplyLicense();
            Open(stream);
        }

        public ExcelEngine(FileInfo fileInfo) : this()
        {
            ApplyLicense();
            Open(fileInfo);
        }

        public ExcelEngine(string filePath) : this()
        {
            ApplyLicense();
            Open(filePath);
        }

        public void Open()
        {
            Excel = new Workbook();
        }

        public void Open(Stream stream)
        {
            FileStream = stream;
            Excel = new Workbook(stream);
        }

        public bool ApplyLicense() //string path)
        {
            string path = "Aspose.Cells.lic";
            var license = new Aspose.Cells.License();

            try
            {
                license.SetLicense(path);
                return true;
            }
            catch (FileNotFoundException ex)
            {
                throw new FileNotFoundException("License : " + ex.Message);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void Open(FileInfo fileInfo)
        {
            var stream = new MemoryStream();

            var fileStream = fileInfo.Open(FileMode.OpenOrCreate, FileAccess.ReadWrite);
            fileStream.CopyTo(stream);
            fileStream.Close();

            Open(stream);
        }

        public void Open(string filePath)
        {
            var stream = new MemoryStream();

            var fileStream = File.Open(filePath, FileMode.OpenOrCreate, FileAccess.ReadWrite);
            fileStream.CopyTo(stream);
            fileStream.Close();

            Open(stream);
        }

        public IExcelWorksheet GetWorksheet(string sheetName)
        {
            try
            {
                return new Worksheet(this, Excel.Worksheets[sheetName]);
            }
            catch (NullReferenceException)
            {
                throw new InvalidOperationException(string.Format("Cannot find the given worksheet \"{0}\".", sheetName));
            }
        }

        public object Read(string sheetName, string address)
        {
            return GetWorksheet(sheetName)?.GetRange(address);
        }

        public void Save()
        {
            if (IsLoaded)
            {
                Excel.Save(FileStream, saveFormat: SaveFormat.Auto);
            }
            else
            {
                throw new InvalidOperationException("Saving target file is not specified.");
            }
        }

        public void SaveAs(Stream stream)
        {
            Excel.Save(stream, saveFormat: SaveFormat.Auto);
        }

        public void Calculate()
        {
            Excel.Settings.CreateCalcChain = false;

            Excel.CalculateFormula(true);
        }

        private void Close()
        {
            if (Excel != null)
            {
                Excel.Dispose();
            }
        }

        #region IDisposable Support
        private bool disposedValue = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    Close();
                }

                disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
        }
        #endregion
    }

    public class Worksheet : IExcelWorksheet
    {
        public string SheetName;

        private ExcelEngine DataEngine;

        private Aspose.Cells.Worksheet Sheet;

        internal Worksheet(Aspose.Cells.Worksheet sheet)
        {
            Sheet = sheet;
            SheetName = sheet.Name;
        }

        internal Worksheet(ExcelEngine excel, Aspose.Cells.Worksheet workSheet) : this(workSheet)
        {
            DataEngine = excel;
        }

        private Cell CreateCell(Aspose.Cells.Cell cell)
        {
            return cell == null ? null : new Cell()
            {
                Column = cell.Column + 1,
                Row = cell.Row + 1,
                Address = $"{ExcelUtility.GetExcelColumnName(cell.Column + 1)}{cell.Row + 1}",
                RawValue = cell.Value,
                Value = cell.DisplayStringValue,
            };
        }

        private IExcelRange ProjectCellIntoRange(string address, Range range)
        {
            var _range = Sheet.Cells.CreateRange(address);

            foreach (var cell in _range)
            {
                range.Add(CreateCell(cell as Aspose.Cells.Cell));
            }

            return range;
        }

        public IExcelRange GetRange(string address)
        {
            var range = new Range();

            string[] addresses;
            if (address.Contains(','))
            {
                addresses = address.Split(',');
            }
            else
            {
                addresses = new string[] { address };
            }

            foreach (var _address in addresses)
            {
                var _range = ProjectCellIntoRange(_address, range);

                if (_range != null)
                {
                    foreach (var cell in _range)
                    {
                        range.Add(cell);
                    };
                }
            }

            return range;
        }

        public IExcelRange GetRange(int row, int column)
        {
            throw new NotImplementedException(nameof(GetRange));
        }

        public IExcelRange GetRange(int fromRow, int fromColumn, int toRow, int toColumn)
        {
            throw new NotImplementedException(nameof(GetRange));
        }

        public IExcelCell GetCell(string address)
        {
            var cell = Sheet.Cells[address];
            return CreateCell(cell);
        }

        public IExcelCell GetCell(int row, int column)
        {
            throw new NotImplementedException(nameof(GetCell));
        }

        private void WriteByCellRange(string address, object value)
        {
            var range = Sheet.Cells.CreateRange(address);

            foreach (var cell in range)
            {
                var _cell = cell as Aspose.Cells.Cell;

                if (_cell == null)
                    continue;

                _cell.Value = value;

                if (value?.GetType() == typeof(DateTime))
                {
                    Style style = _cell.GetStyle();
                    style.Custom = "d-mmm-yy";
                    _cell.SetStyle(style);
                }
            }
        }

        public IExcelRange GetMergedValueByRow(string address)
        {
            var range = new Range();

            var cellRange = Sheet.Cells.CreateRange(address);

            for (int row = 0; row < cellRange.RowCount; row++)
            {
                var value = "";

                for (int column = 0; column < cellRange.ColumnCount; column++)
                {
                    var cell = cellRange.GetCellOrNull(row, column);

                    if (cell != null && cell.IsMerged)
                    {
                        cell = cell.GetMergedRange()?.GetCellOrNull(0, 0);
                    }

                    value = $"{value}{cell?.DisplayStringValue}";
                }

                range.Add(new Cell()
                {
                    Column = cellRange.FirstColumn + 1,
                    Row = cellRange.FirstRow + row + 1,
                    Address = $"{ExcelUtility.GetExcelColumnName(cellRange.FirstColumn + 1)}{cellRange.FirstRow + row + 1}",
                    RawValue = value,
                    Value = value,
                });
            }

            return range;
        }

        public IExcelRange GetMergedValueByColumn(string address)
        {
            var range = new Range();

            var cellRange = Sheet.Cells.CreateRange(address);

            for (int column = 0; column < cellRange.ColumnCount; column++)
            {
                var value = "";

                for (int row = 0; row < cellRange.RowCount; row++)
                {
                    var cell = cellRange.GetCellOrNull(row, column);

                    if (cell != null && cell.IsMerged)
                    {
                        cell = cell.GetMergedRange()?.GetCellOrNull(0, 0);
                    }

                    value = $"{value}{cell?.DisplayStringValue}";
                }

                range.Add(new Cell()
                {
                    Column = cellRange.FirstColumn + column + 1,
                    Row = cellRange.FirstRow + 1,
                    Address = $"{ExcelUtility.GetExcelColumnName(cellRange.FirstColumn + column + 1)}{cellRange.FirstRow + 1}",
                    RawValue = value,
                    Value = value,
                });
            }

            return range;
        }

        public void Write(string address, object value)
        {
            string[] addresses;
            if (address.Contains(','))
            {
                addresses = address.Split(',');
            }
            else
            {
                addresses = new string[] { address };
            }

            foreach (var _address in addresses)
            {
                WriteByCellRange(_address, value);
            }
        }

        public void Write(int row, int column, object value)
        {
            throw new NotImplementedException(nameof(Write));
        }

        public void Write(int row, int column, string value)
        {
            throw new NotImplementedException(nameof(Write));
        }

        public IExcelCell FindFirst(string find)
        {
            throw new NotImplementedException(nameof(FindFirst));
        }

        private IExcelCell FindFirstByCellRange(string find, string address)
        {
            var range = Sheet.Cells.CreateRange(address);

            foreach (var cell in range)
            {
                var _cell = cell as Aspose.Cells.Cell;

                if (_cell == null)
                    continue;

                if (_cell.DisplayStringValue?.Trim()?.ToLower() == find?.Trim()?.ToLower() ||
                        _cell.StringValue?.Trim()?.ToLower() == find?.Trim()?.ToLower() ||
                        _cell.StringValueWithoutFormat?.Trim()?.ToLower() == find?.Trim()?.ToLower())
                    return CreateCell(_cell);
            }

            return null;
        }

        public IExcelCell FindFirst(string find, string address)
        {
            string[] addresses;
            if (address.Contains(','))
            {
                addresses = address.Split(',');
            }
            else
            {
                addresses = new string[] { address };
            }

            foreach (var _address in addresses)
            {
                var matched = FindFirstByCellRange(find, _address);

                if (matched != null)
                    return matched;
            }

            return null;
        }

        public IExcelRange Find(string find)
        {
            throw new NotImplementedException(nameof(Find));
        }

        private IExcelRange FindByCellRange(string find, string address, Range range = null)
        {
            if (range == null)
            {
                range = new Range();
            }

            var _range = Sheet.Cells.CreateRange(address);

            foreach (var cell in _range)
            {
                var _cell = cell as Aspose.Cells.Cell;

                if (_cell == null)
                    continue;

                if (_cell.DisplayStringValue?.Trim()?.ToLower() == find?.Trim()?.ToLower() ||
                        _cell.StringValue?.Trim()?.ToLower() == find?.Trim()?.ToLower() ||
                        _cell.StringValueWithoutFormat?.Trim()?.ToLower() == find?.Trim()?.ToLower())
                    range.Add(CreateCell(_cell));
            }

            return range;
        }

        private IExcelRange FindByCellRange(IEnumerable<string> include, IEnumerable<string> exclude, string address, Range range = null)
        {
            if (range == null)
            {
                range = new Range();
            }

            var _range = Sheet.Cells.CreateRange(address);

            foreach (var cell in _range)
            {
                var _cell = cell as Aspose.Cells.Cell;

                if (_cell == null)
                    continue;

                if (include?.Count() > 0 && !(include.Any(find => _cell.DisplayStringValue?.Trim()?.ToLower().IndexOf(find?.Trim()?.ToLower()) >= 0) ||
                    include.Any(find => _cell.StringValue?.Trim()?.ToLower().IndexOf(find?.Trim()?.ToLower()) >= 0) ||
                    include.Any(find => _cell.StringValueWithoutFormat?.Trim()?.ToLower().IndexOf(find?.Trim()?.ToLower()) >= 0)))
                    continue;

                if (exclude?.Count() > 0 && (exclude.Any(find => _cell.DisplayStringValue?.Trim()?.ToLower().IndexOf(find?.Trim()?.ToLower()) >= 0) ||
                    exclude.Any(find => _cell.StringValue?.Trim()?.ToLower().IndexOf(find?.Trim()?.ToLower()) >= 0) ||
                    exclude.Any(find => _cell.StringValueWithoutFormat?.Trim()?.ToLower().IndexOf(find?.Trim()?.ToLower()) >= 0)))
                    continue;

                range.Add(CreateCell(_cell));
            }

            return range;
        }

        public IExcelRange Find(string find, string address)
        {
            string[] addresses;
            if (address.Contains(','))
            {
                addresses = address.Split(',');
            }
            else
            {
                addresses = new string[] { address };
            }

            var range = new Range();

            foreach (var _address in addresses)
            {
                FindByCellRange(find, _address, range);
            }

            return range;
        }

        public IExcelRange Find(IEnumerable<string> include, IEnumerable<string> exclude, string address)
        {
            string[] addresses;
            if (address.Contains(','))
            {
                addresses = address.Split(',');
            }
            else
            {
                addresses = new string[] { address };
            }

            var range = new Range();

            foreach (var _address in addresses)
            {
                FindByCellRange(include, exclude, _address, range);
            }

            return range;
        }

        /// <summary>
        /// Append formula into the given cell. The "value" label will be replaced with exist formula or value.
        /// </summary>
        /// <param name="address"></param>
        /// <param name="formula"></param>
        public IExcelRange AppendFormula(string address, string formula)
        {
            string[] addresses;
            if (address.Contains(','))
            {
                addresses = address.Split(',');
            }
            else
            {
                addresses = new string[] { address };
            }

            var range = new Range();

            foreach (var _address in addresses)
            {
                AppendFormula(_address, formula, range);
            }

            return range;
        }

        public IExcelRange AppendFormula(string address, string formula, Range range = null)
        {
            if (range == null)
            {
                range = new Range();
            }

            var _range = Sheet.Cells.CreateRange(address);

            foreach (var cell in _range)
            {
                var _cell = cell as Aspose.Cells.Cell;

                if (_cell == null || _cell?.Value == null)
                {
                    continue;
                }

                if (_cell.IsFormula)
                {
                    var prevFormula = $"{_cell.Formula}";

                    if (prevFormula.IndexOf('=') == 0)
                        prevFormula = prevFormula.Substring(1);

                    var newFormula = $"{formula.Replace("value", prevFormula)}";

                    if (newFormula.IndexOf('=') != 0)
                        newFormula = $"={newFormula}";

                    _cell.Formula = newFormula;
                }
                else
                {
                    decimal tryParsed;

                    if (!Decimal.TryParse(_cell.StringValueWithoutFormat, out tryParsed))
                        continue;

                    var value = $"{_cell.StringValueWithoutFormat}";

                    var newFormula = $"{formula.Replace("value", value)}";

                    if (newFormula.IndexOf('=') != 0)
                        newFormula = $"={newFormula}";

                    _cell.Formula = newFormula;
                }

                _cell.Calculate(true, null);

                range.Add(CreateCell(_cell));
            }

            return range;
        }

        public void Clear(string address)
        {
            string[] addresses;
            if (address.Contains(','))
            {
                addresses = address.Split(',');
            }
            else
            {
                addresses = new string[] { address };
            }

            foreach (var _address in addresses)
            {
                ClearByCellRange(_address);
            }
        }

        public void Clear(int row, int column)
        {
            throw new NotImplementedException(nameof(Clear));
        }

        private void ClearByCellRange(string address)
        {
            var range = Sheet.Cells.CreateRange(address);

            foreach (var cell in range)
            {
                var _cell = cell as Aspose.Cells.Cell;

                if (_cell == null)
                    continue;

                _cell.Value = null;
            }
        }
    }

    public class Range : IExcelRange
    {
        private ICollection<IExcelCell> Cells = new HashSet<IExcelCell>();

        public IExcelCell this[string address] { get { return Cells.FirstOrDefault(x => x.Address == address); } }

        public void Add(IExcelCell cell)
        {
            Cells.Add(cell);
        }

        public void Dispose()
        {
        }

        public IEnumerator<IExcelCell> GetEnumerator() => Cells.GetEnumerator();

        IEnumerator IEnumerable.GetEnumerator() => Cells.GetEnumerator();
    }

    public class Cell : IExcelCell
    {
        public int Column { get; set; }

        public int Row { get; set; }

        public string Address { get; set; }

        public string Value { get; set; }

        public object RawValue { get; set; }
    }
}
