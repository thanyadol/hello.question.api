﻿using System.Collections.Generic;

namespace surflex.netcore22.Helpers.DataHandler
{
    public interface IExcelTemplateHandler : IDataHandler
    {
        IExcelEngine DataEngine { get; set; }
    }

    public interface IExcelProfile : IDataProfile
    {
        IExcelEngine DataEngine { get; set; }

        new ICollection<IExcelProfileDefinition> GetDefinitions();

        new IExcelProfileDefinition GetDefinition(string definition);
    }

    public interface IExcelProfileDefinition : IProfileDefinition
    {
        IExcelEngine DataEngine { get; set; }

        string Key { get; set; }

        string Label { get; set; }

        string Description { get; set; }

        string SheetName { get; set; }

        string CellRange { get; set;  }

        ExcelProfileDefinitionMode Mode { get; set; }

        ICollection<IExcelProfileDefinitionProperties> Datasource { get; set; }

        IExcelRange Results { get; set; }

        IExcelValidation<IExcelRange> Validation { get; set; }

        void Execute(IExcelEngine excel);
    }

    public interface IExcelProfileDefinitionProperties : IProfileDefinitionProperties
    {
        string RangeAddress { get; set; }

        string ColumnCriteriaLabel { get; set; }

        string ColumnCriteriaText { get; set; }

        ICollection<string> ColumnCriteriaIncludedText { get; set; }

        ICollection<string> ColumnCriteriaExcludedText { get; set; }

        string ColumnCriteriaRangeAddress { get; set; }
        
        string RowCriteriaLabel { get; set; }

        string RowCriteriaText { get; set; }

        ICollection<string> RowCriteriaIncludedText { get; set; }

        ICollection<string> RowCriteriaExcludedText { get; set; }

        string RowCriteriaRangeAddress { get; set; }
        
        string Formula { get; set; }
    }

    public enum ExcelProfileDefinitionMode
    {
        Recalculate = 0,
        Validate = 1,
        Read = 2,
        Write = 3,
        WriteFirstHorizontal = 4,
        WriteFirstVertical1Criteria = 5,
        WriteHorizontal = 6,
        WriteVertical1Criteria = 7,
        WriteVertical2Criterion = 8,
        AppendFormula = 9,
        AppendFormula1Criteria = 10,
        Clear = 11,
        Clear1Criteria = 12,
    }
}
