﻿using System; 

using System.Linq;
using System.Text.RegularExpressions;

namespace surflex.netcore22.Helpers
{
    public class ExcelUtility
    {
        /// <summary>
        /// Extract excel range address into int.
        /// </summary>
        /// <param name="address"></param>
        /// <returns>fromRow, fromCol, toRow, toCol respectively</returns>
        public static (int?, int?, int?, int?) ExtractRange(string address)
        {
            if (string.IsNullOrEmpty(address)) throw new ArgumentNullException(nameof(address));

            var cells = address.Split(':');

            int? fromRow = null;
            int? fromCol = null;
            int? toRow = null;
            int? toCol = null;

            (fromRow, fromCol) = DoExtractRange(cells[0]);
            
            if (cells.Length > 1)
                (toRow, toCol) = DoExtractRange(cells[0]);

            return (fromRow, fromCol, toRow, toCol);
        }


        /// <summary>
        /// Internal method to extract cell address.
        /// </summary>
        /// <param name="address"></param>
        /// <returns>row, column respectively</returns>
        private static (int, int) DoExtractRange(string address)
        {
            if (string.IsNullOrEmpty(address)) throw new ArgumentNullException(nameof(address));

            var matched = Regex.Match(address, "(?<column>[A-Za-z]*)(?<row>[0-9]*)");
            if (matched == null) throw new ArgumentException("Invalid address pattern is given.");

            var rowLetter = matched.Groups.FirstOrDefault(x => x.Name == "row")?.Value;
            if (rowLetter == null) throw new ArgumentException("Invalid address pattern is given.");

            var columnLetter = matched.Groups.FirstOrDefault(x => x.Name == "column")?.Value;
            if (columnLetter == null) throw new ArgumentException("Invalid address pattern is given.");

            return (int.Parse(rowLetter), GetExcelColumnNumber(columnLetter));
        }


        /// <summary>
        /// Convert Excel column name into number/index. Column number start from 1. A equal to 1
        /// </summary>
        /// <param name="columnName">Column name
        /// <returns>Excel column in numeric</returns>
        public static int GetExcelColumnNumber(string columnName)
        {
            if (string.IsNullOrEmpty(columnName))
                throw new ArgumentNullException("Invalid column name parameter");

            columnName = columnName.ToUpperInvariant();

            int sum = 0;

            char ch;
            for (int i = 0; i < columnName.Length; i++)
            {
                ch = columnName[i];

                if (char.IsDigit(ch))
                    throw new ArgumentNullException("Invalid column name parameter on character " + ch);

                sum *= 26;
                sum += (ch - 'A' + 1);
                //sum += (columnName[i] - 'A');
            }

            return sum;
        }

        /// <summary>
        /// Convert Excel column index into name. Column start from 1
        /// </summary>
        /// <param name="columnNumber">Column name/number
        /// <returns>Column name</returns>
        public static string GetExcelColumnName(int columnNumber)
        {
            int dividend = columnNumber;
            string columnName = String.Empty;
            int modulo;

            while (dividend > 0)
            {
                modulo = (dividend - 1) % 26;
                columnName = Convert.ToChar(65 + modulo).ToString() + columnName;
                dividend = (int)((dividend - modulo) / 26);
            }

            return columnName;
        }

        /// <summary>
        /// Check if cell is error
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool IsError(string value)
        {
            var errorList = new string[] { "#DIV/0!", "#N/A", "#NAME?", "#NULL!", "#NUM!", "#REF!", "#VALUE!" };
            return errorList.Any(x => x == value);
    }
    }
}
