﻿using System; 


namespace surflex.netcore22.Helpers
{
    public class DateTimeUtility
    {
        /// <summary>
        /// Get year in string from datetime.
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        public static string GetYear(DateTime dateTime)
        {
            if (dateTime == null) throw new ArgumentNullException(nameof(dateTime));

            return dateTime.ToString("yyyy");
        }

        /// <summary>
        /// Get shorten date in string format 1-Jan-20 from datetime.
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        public static string GetShortenDate(DateTime dateTime)
        {
            if (dateTime == null) throw new ArgumentNullException(nameof(dateTime));


            return dateTime.ToString("d-MMM-y");
        }

        /// <summary>
        /// Get shorten month in string format Jan from datetime.
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        public static string GetShortenMonth(DateTime dateTime)
        {
            if (dateTime == null) throw new ArgumentNullException(nameof(dateTime));

            return dateTime.ToString("MMM");
        }
    }
}
