using System; 


//model
using surflex.netcore22.Models;

namespace surflex.netcore22.Exceptions
{
    public class SessionLoggNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Session not found";
        public string rev { get; }
        public string value { get; }

        public SessionLoggNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public SessionLoggNotFoundException(SessionLogg logg)
            : this(string.Format("Session of user id = {0} not found", logg.CAI))
        {
        }

        public SessionLoggNotFoundException(string message)
            : base(message)
        {
        }

        public SessionLoggNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }

}