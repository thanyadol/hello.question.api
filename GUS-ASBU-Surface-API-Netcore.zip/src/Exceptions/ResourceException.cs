using System; 


//model
using surflex.netcore22.Models;

namespace surflex.netcore22.Exceptions
{

    public class ResourceNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Time/Cost not found";
        public string rev { get; }
        public string value { get; }

        public ResourceNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public ResourceNotFoundException(Resource resource)
            : this(string.Format("Time/Cost with id = {0} not found", resource.Id.ToString()))
        {
        }

        public ResourceNotFoundException(string message)
            : base(message)
        {
        }

        public ResourceNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }

    public class ResourceNotValidException : Exception
    {

        private const string DEFAULT_MESSAGE = "Time/Cost not valid";
        public string rev { get; }
        public string value { get; }

        public ResourceNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public ResourceNotValidException(Resource resource)
            : this(string.Format("Time/Cost with id = {0} not valid", resource.Id.ToString()))
        {
        }

        public ResourceNotValidException(string message)
            : base(message)
        {
        }

        public ResourceNotValidException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }

}