using System; 


//model
using surflex.netcore22.Models;

namespace surflex.netcore22.Exceptions
{
    public class ProductionNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Production profile not found";
        public string rev { get; }
        public string value { get; }

        public ProductionNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public ProductionNotFoundException(Production production)
            : this(string.Format("Production profile with id = {0} not found", production.Id.ToString()))
        {
        }

        public ProductionNotFoundException(string message)
            : base(message)
        {
        }

        public ProductionNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }

    public class ProductionNotValidException : Exception
    {

        private const string DEFAULT_MESSAGE = "Production profile not valid";
        public string rev { get; }
        public string value { get; }

        public ProductionNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public ProductionNotValidException(Production production)
            : this(string.Format("Production profile with id = {0} not valid", production.Id.ToString()))
        {
        }

        public ProductionNotValidException(string message)
            : base(message)
        {
        }

        public ProductionNotValidException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }
}