using System; 


//model
using surflex.netcore22.Models;

namespace surflex.netcore22.Exceptions
{
    public class PriceNotFoundException : Exception
    {
        private const string DEFAULT_MESSAGE = "Price not found";
        public string rev { get; }
        public string value { get; }

        public PriceNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public PriceNotFoundException(Price price)
            : this(string.Format("Price with id = {0} not found", price.Id.ToString()))
        {
        }

        public PriceNotFoundException(string message)
            : base(message)
        {
        }

        public PriceNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }

    public class PriceNotValidException : Exception
    {

        private const string DEFAULT_MESSAGE = "Price not valid";
        public string rev { get; }
        public string value { get; }

        public PriceNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public PriceNotValidException(Price price)
            : this(string.Format("Price with id = {0} not valid", price.Id.ToString()))
        {
        }

        public PriceNotValidException(string message)
            : base(message)
        {
        }

        public PriceNotValidException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }

}