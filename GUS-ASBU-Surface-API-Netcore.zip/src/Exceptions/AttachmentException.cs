using System; 


//model
using surflex.netcore22.Models;

namespace surflex.netcore22.Exceptions
{

    public class AttachmentNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Attachment not found";
        public string rev { get; }
        public string value { get; }

        public AttachmentNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public AttachmentNotFoundException(Attachment attach)
            : this(string.Format("Attachment with id = {0} not found", attach.Id.ToString()))
        {
        }

        public AttachmentNotFoundException(string message)
            : base(message)
        {
        }

        public AttachmentNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }

    public class AttachmentNotValidException : Exception
    {

        private const string DEFAULT_MESSAGE = "Attachment not valid";
        public string rev { get; }
        public string value { get; }

        public AttachmentNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public AttachmentNotValidException(Attachment attach)
            : this(string.Format("Attachment with id = {0} not valid", attach.Id.ToString()))
        {
        }

        public AttachmentNotValidException(string message)
            : base(message)
        {
        }

        public AttachmentNotValidException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }
}