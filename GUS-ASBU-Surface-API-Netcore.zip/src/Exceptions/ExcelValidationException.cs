using System; 

using System.Collections.Generic;

namespace surflex.netcore22.Exceptions
{
    public class ExcelValidationException : Exception
    {
        public ExcelValidationException() : base()
        {
        }

        public ExcelValidationException(string message) : base(message)
        {
        }

        public ExcelValidationException(IEnumerable<string> messages)
            : base($"Validation Failed.\r\n{ string.Join("\r\n", messages)}")
        {
        }

        public ExcelValidationException(string message, Exception inner) : base(message, inner)
        {
        }
    }
}