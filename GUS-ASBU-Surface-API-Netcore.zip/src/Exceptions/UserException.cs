using System; 


//model
using surflex.netcore22.Models;

namespace surflex.netcore22.Exceptions
{
    public class UserNotFoundException : Exception
    {
        private const string DEFAULT_MESSAGE = "User not found";
        public string rev { get; }
        public string value { get; }

        public UserNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public UserNotFoundException(User user)
            : this(string.Format("User with id = {0} not found", user.Id.ToString()))
        {
        }

        public UserNotFoundException(string message)
            : base(message)
        {
        }

        public UserNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }

    public class UserAuthenNotFoundException : Exception
    {
        private const string DEFAULT_MESSAGE = "User authentication not found";
        public string rev { get; }
        public string value { get; }

        public UserAuthenNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public UserAuthenNotFoundException(User user)
            : this(string.Format("User with id = {0} not found an authentication", user.CAI))
        {
        }

        public UserAuthenNotFoundException(string message)
            : base(message)
        {
        }

        public UserAuthenNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }


    public class UserNotValidException : Exception
    {

        private const string DEFAULT_MESSAGE = "User not valid";
        public string rev { get; }
        public string value { get; }

        public UserNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public UserNotValidException(User user)
            : this(string.Format("User with id = {0} not valid", user.Id.ToString()))
        {
        }

        public UserNotValidException(string message)
            : base(message)
        {
        }

        public UserNotValidException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }

}