using System; 


//model
using surflex.netcore22.Models;

namespace surflex.netcore22.Exceptions
{

    public class JobNotFoundException : Exception
    {
        private const string DEFAULT_MESSAGE = "Job not found";
        public string rev { get; }
        public string value { get; }

        public JobNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public JobNotFoundException(Job job)
            : this(string.Format("Job of well = {0} not found", job.WellName))
        {
        }

        public JobNotFoundException(string message)
            : base(message)
        {
        }

        public JobNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }



    public class JobNotProductiveException : Exception
    {

        private const string DEFAULT_MESSAGE = "Job not productive";
        public string rev { get; }
        public string value { get; }

        public JobNotProductiveException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public JobNotProductiveException(Job job)
            : this(string.Format("Job of well = {0} not productive", job.WellName))
        {
        }

        public JobNotProductiveException(string message)
            : base(message)
        {
        }

        public JobNotProductiveException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }



}