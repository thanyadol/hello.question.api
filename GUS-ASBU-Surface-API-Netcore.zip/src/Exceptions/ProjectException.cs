using System; 


//model
using surflex.netcore22.Models;

namespace surflex.netcore22.Exceptions
{
    public class ProjectNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Project not found";
        public string rev { get; }
        public string value { get; }

        public ProjectNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public ProjectNotFoundException(Project project)
            : this(string.Format("Project with name = {0} not found", project.Name))
        {
        }

        public ProjectNotFoundException(string message)
            : base(message)
        {
        }

        public ProjectNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }

    public class ProjectNotValidException : Exception
    {
        private const string DEFAULT_MESSAGE = "Project not valid";
        public string rev { get; }
        public string value { get; }

        public ProjectNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public ProjectNotValidException(Project project)
            : this(string.Format("Project with name = {0} not valid", project.Name))
        {
        }

        public ProjectNotValidException(string message)
            : base(message)
        {
        }

        public ProjectNotValidException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }

    public class ProjectAttributeNotFoundException : Exception
    {
        private const string DEFAULT_MESSAGE = "Project setup not found";
        public string rev { get; }
        public string value { get; }

        public ProjectAttributeNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public ProjectAttributeNotFoundException(ProjectAttribute project)
            : this(string.Format("Project setup with name = {0} not found", project.ProjectName))
        {
        }

        public ProjectAttributeNotFoundException(string message)
            : base(message)
        {
        }

        public ProjectAttributeNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }

    public class ProjectWellNotFoundException : Exception
    {
        private const string DEFAULT_MESSAGE = "Well setup not found";
        public string rev { get; }
        public string value { get; }

        public ProjectWellNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public ProjectWellNotFoundException(ProjectWell project)
            : this(string.Format("Well setup with project name = {0} not found", project.ProjectName))
        {
        }

        public ProjectWellNotFoundException(string message)
            : base(message)
        {
        }

        public ProjectWellNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }


    public class ProjectDrilledNotFoundException : Exception
    {
        private const string DEFAULT_MESSAGE = "Project DPI planner setup not found";
        public string rev { get; }
        public string value { get; }

        public ProjectDrilledNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public ProjectDrilledNotFoundException(ProjectDrilled project)
            : this(string.Format("Project DPI planner with name = {0} not found", project.ProjectName))
        {
        }

        public ProjectDrilledNotFoundException(string message)
            : base(message)
        {
        }

        public ProjectDrilledNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }

    public class ProjectAuthorizeNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Project authorize  not found";
        public string rev { get; }
        public string value { get; }

        public ProjectAuthorizeNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public ProjectAuthorizeNotFoundException(ProjectAuthorize project)
            : this(string.Format("Project authorize with user id = {0} not found", project.UserId))
        {
        }

        public ProjectAuthorizeNotFoundException(string message)
            : base(message)
        {
        }

        public ProjectAuthorizeNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }




    public class ProjectLocationNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Project location  not found";
        public string rev { get; }
        public string value { get; }

        public ProjectLocationNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public ProjectLocationNotFoundException(ProjectLocation project)
            : this(string.Format("Project location with name = {0} not found", project.ProjectName))
        {
        }

        public ProjectLocationNotFoundException(string message)
            : base(message)
        {
        }

        public ProjectLocationNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }
    public class ProjectActivityNotFoundException : Exception
    {
        private const string DEFAULT_MESSAGE = "Project activity not found";
        public string rev { get; }
        public string value { get; }

        public ProjectActivityNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }
    }
}