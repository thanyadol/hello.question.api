using System; 


//model
using surflex.netcore22.Models;

namespace surflex.netcore22.Exceptions
{

    public class ConfigurationNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Configuration not found";
        public string rev { get; }
        public string value { get; }

        public ConfigurationNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        /* 
        public ConfigurationNotFoundException(Configuration config)
       : this(string.Format("Configuration with id = {0} not found", config.Id.ToString()))
        {
        }*/

        public ConfigurationNotFoundException(string message)
            : base(message)
        {
        }

        public ConfigurationNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }

    public class ConfigurationNotValidException : Exception
    {

        private const string DEFAULT_MESSAGE = "Configuration not valid";
        public string rev { get; }
        public string value { get; }

        public ConfigurationNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }

        /* public ConfigurationNotValidException(Configuration config)
            : this(string.Format("Configuration with id = {0} not valid", config.Id.ToString()))
        {
        }*/

        public ConfigurationNotValidException(string message)
            : base(message)
        {
        }

        public ConfigurationNotValidException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }
}