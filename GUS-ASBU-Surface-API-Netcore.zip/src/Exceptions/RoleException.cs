using System; 


//model
using surflex.netcore22.Models;

namespace surflex.netcore22.Exceptions
{

    public class RoleNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Role  not found";
        public string rev { get; }
        public string value { get; }

        public RoleNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public RoleNotFoundException(Role role)
            : this(string.Format("Role with name = {0} not found", role.Name))
        {
        }

        public RoleNotFoundException(string message)
            : base(message)
        {
        }

        public RoleNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }


    public class RoleAuthorizeNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Role authorize  not found";
        public string rev { get; }
        public string value { get; }

        public RoleAuthorizeNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public RoleAuthorizeNotFoundException(RoleAuthorize role)
            : this(string.Format("Role authorize with user id = {0} not found", role.UserId))
        {
        }

        public RoleAuthorizeNotFoundException(string message)
            : base(message)
        {
        }

        public RoleAuthorizeNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }

    public class RoleNotValidException : Exception
    {

        private const string DEFAULT_MESSAGE = "Role not valid";
        public string rev { get; }
        public string value { get; }

        public RoleNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public RoleNotValidException(Role role)
                : this(string.Format("Role with name = {0} not valid", role.Name))
        {
        }

        public RoleNotValidException(string message)
            : base(message)
        {
        }

        public RoleNotValidException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }

}