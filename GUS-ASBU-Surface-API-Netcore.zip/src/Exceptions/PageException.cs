using System; 


//model
using surflex.netcore22.Models;

namespace surflex.netcore22.Exceptions
{

    public class PageNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Page not found";
        public string rev { get; }
        public string value { get; }

        public PageNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public PageNotFoundException(Page page)
            : this(string.Format("Page with url = {0} not found", page.Url))
        {
        }

        public PageNotFoundException(string message)
            : base(message)
        {
        }

        public PageNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }



}