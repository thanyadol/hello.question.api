using System; 


//model
using surflex.netcore22.Models;

namespace surflex.netcore22.Exceptions
{

    public class ApiNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Api not found";
        public string rev { get; }
        public string value { get; }

        public ApiNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public ApiNotFoundException(Api api)
            : this(string.Format("Api with endpoint = {0} not found", api.Endpoint))
        {
        }

        public ApiNotFoundException(string message)
            : base(message)
        {
        }

        public ApiNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }

    public class ApiNotValidException : Exception
    {

        private const string DEFAULT_MESSAGE = "Api not valid";
        public string rev { get; }
        public string value { get; }

        public ApiNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public ApiNotValidException(Api api)
            : this(string.Format("Api with endpoint = {0} not valid", api.Endpoint))
        {
        }

        public ApiNotValidException(string message)
            : base(message)
        {
        }

        public ApiNotValidException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }


    public class ApiNotPermissionException : Exception
    {

        private const string DEFAULT_MESSAGE = "Api not permission";
        public string rev { get; }
        public string value { get; }

        public ApiNotPermissionException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public ApiNotPermissionException(Api api)
            : this(string.Format("Api with id = {0} not permission", api.Id.ToString()))
        {
        }

        public ApiNotPermissionException(string message)
            : base(message)
        {
        }

        public ApiNotPermissionException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }


}