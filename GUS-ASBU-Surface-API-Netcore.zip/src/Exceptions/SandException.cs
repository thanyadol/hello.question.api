using System; 


//model
using surflex.netcore22.Models;

namespace surflex.netcore22.Exceptions
{
    public class SandNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Sand  not found";
        public string rev { get; }
        public string value { get; }

        public SandNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public SandNotFoundException(Sand sand)
            : this(string.Format("Sand with name = {0} not found", sand.Name))
        {
        }

        public SandNotFoundException(string message)
            : base(message)
        {
        }

        public SandNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }

    public class SandNotValidException : Exception
    {

        private const string DEFAULT_MESSAGE = "Sand not valid";
        public string rev { get; }
        public string value { get; }

        public SandNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public SandNotValidException(Sand sand)
                : this(string.Format("Sand with name = {0} not valid", sand.Name))
        {
        }

        public SandNotValidException(string message)
            : base(message)
        {
        }

        public SandNotValidException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }

    public class SandNotCalculateException : Exception
    {
        private const string DEFAULT_MESSAGE = "Sand not calculated";
        public string rev { get; }
        public string value { get; }

        public SandNotCalculateException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public SandNotCalculateException(Sand sand)
                : this(string.Format("Sand with name = {0} not calculated", sand.Name))
        {
        }

        public SandNotCalculateException(string message)
            : base(message)
        {
        }

        public SandNotCalculateException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }



}