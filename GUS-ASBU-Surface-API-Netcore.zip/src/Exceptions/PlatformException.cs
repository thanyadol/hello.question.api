using System; 


//model
using surflex.netcore22.Models;

namespace surflex.netcore22.Exceptions
{

    public class PlatformNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Platform not found";
        public string rev { get; }
        public string value { get; }

        public PlatformNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public PlatformNotFoundException(Platform platform)
            : this(string.Format("Platform with name = {0} not found", platform.Name))
        {
        }

        public PlatformNotFoundException(string message)
            : base(message)
        {
        }

        public PlatformNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }

    public class PlatformNotValidException : Exception
    {

        private const string DEFAULT_MESSAGE = "Platform not valid";
        public string rev { get; }
        public string value { get; }

        public PlatformNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public PlatformNotValidException(Platform platform)
           : this(string.Format("Platform with name = {0} not valid", platform.Name))
        {
        }

        public PlatformNotValidException(string message)
            : base(message)
        {
        }

        public PlatformNotValidException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }
}