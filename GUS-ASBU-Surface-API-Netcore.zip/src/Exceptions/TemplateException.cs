using System; 


//model
using surflex.netcore22.Models;

namespace surflex.netcore22.Exceptions
{

    public class TemplateNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Template not found";
        public string rev { get; }
        public string value { get; }

        public TemplateNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public TemplateNotFoundException(Template template)
            : this(string.Format("Template with id = {0} not found", template.Id.ToString()))
        {
        }

        public TemplateNotFoundException(string message)
            : base(message)
        {
        }

        public TemplateNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }

    public class TemplateNotValidException : Exception
    {

        private const string DEFAULT_MESSAGE = "Template not valid";
        public string rev { get; }
        public string value { get; }

        public TemplateNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public TemplateNotValidException(Template template)
            : this(string.Format("Template with id = {0} not valid", template.Id.ToString()))
        {
        }

        public TemplateNotValidException(string message)
            : base(message)
        {
        }

        public TemplateNotValidException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }
}