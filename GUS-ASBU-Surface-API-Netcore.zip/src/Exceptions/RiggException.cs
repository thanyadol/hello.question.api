using System; 


//model
using surflex.netcore22.Models;

namespace surflex.netcore22.Exceptions
{

    public class RiggNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Drilled trip rate  not found";
        public string rev { get; }
        public string value { get; }

        public RiggNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public RiggNotFoundException(Rigg rigg)
            : this(string.Format("Drilled trip rate with name = {0} not found", rigg.Name))
        {
        }

        public RiggNotFoundException(string message)
            : base(message)
        {
        }

        public RiggNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }

    public class RiggNotValidException : Exception
    {

        private const string DEFAULT_MESSAGE = "Drilled trip rate not valid";
        public string rev { get; }
        public string value { get; }

        public RiggNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public RiggNotValidException(Rigg rigg)
                : this(string.Format("Drilled trip rate with name = {0} not valid", rigg.Name))
        {
        }

        public RiggNotValidException(string message)
            : base(message)
        {
        }

        public RiggNotValidException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }

}