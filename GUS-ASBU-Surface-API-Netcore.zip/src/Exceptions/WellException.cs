using System; 

using surflex.netcore22.APIs.Gateway;

//model
using surflex.netcore22.Models;

namespace surflex.netcore22.Exceptions
{
    public class WellNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Well not found";
        public string rev { get; }
        public string value { get; }

        public WellNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public WellNotFoundException(Well well)
            : this(string.Format("Well with name = {0} not found", well.Name))
        {
        }

        public WellNotFoundException(string message)
            : base(message)
        {
        }

        public WellNotFoundException(string message, Exception inner)
             : base(message, inner)
        {
        }

    }

    public class WellNotValidException : Exception
    {

        private const string DEFAULT_MESSAGE = "Well not valid";
        public string rev { get; }
        public string value { get; }

        public WellNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public WellNotValidException(Well well)
            : this(string.Format("Well with id = {0} not valid", well.Id.ToString()))
        {
        }

        public WellNotValidException(string message)
            : base(message)
        {
        }

        public WellNotValidException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }

    public class WellNotProductiveException : Exception
    {

        private const string DEFAULT_MESSAGE = "Well not productive";
        public string rev { get; }
        public string value { get; }

        public WellNotProductiveException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public WellNotProductiveException(Well well)
            : this(string.Format("Well with name = {0} not productive", well.Name))
        {
        }

        public WellNotProductiveException(string message)
            : base(message)
        {
        }

        public WellNotProductiveException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }


    public class WellNotPlannedException : Exception
    {
        private const string DEFAULT_MESSAGE = "Well not planned";
        public string rev { get; }
        public string value { get; }

        public WellNotPlannedException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public WellNotPlannedException(Well well)
            : this(string.Format("Well with name = {0} not planned", well.Name))
        {
        }

        public WellNotPlannedException(string message)
            : base(message)
        {
        }

        public WellNotPlannedException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }


    public class WellAnalogyNotFoundException : Exception
    {
        private const string DEFAULT_MESSAGE = "Well analogy not found";
        public string rev { get; }
        public string value { get; }

        public WellAnalogyNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public WellAnalogyNotFoundException(WellAnalogy well)
            : this(string.Format("Well analogy with name = {0} not found", well.WellName))
        {
        }

        public WellAnalogyNotFoundException(string message)
            : base(message)
        {
        }

        public WellAnalogyNotFoundException(string message, Exception inner)
             : base(message, inner)
        {
        }
    }


    public class WellScenarioNotFoundException : Exception
    {
        private const string DEFAULT_MESSAGE = "Well scenario not found";
        public string rev { get; }
        public string value { get; }

        public WellScenarioNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public WellScenarioNotFoundException(WellScenario well)
            : this(string.Format("Well scenario with name = {0} not found", well.Name))
        {
        }

        public WellScenarioNotFoundException(string message)
            : base(message)
        {
        }

        public WellScenarioNotFoundException(string message, Exception inner)
             : base(message, inner)
        {
        }

    }


    public class WellPropertiesNotFoundException : Exception
    {
        private const string DEFAULT_MESSAGE = "Well setup not found";
        public string rev { get; }
        public string value { get; }

        public WellPropertiesNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public WellPropertiesNotFoundException(WellProperties well)
            : this(string.Format("Well setup with name = {0} not found", well.Name))
        {
        }

        public WellPropertiesNotFoundException(string message)
            : base(message)
        {
        }

        public WellPropertiesNotFoundException(string message, Exception inner)
             : base(message, inner)
        {
        }
    }

    public class WellPropertiesNotValidException : Exception
    {
        private const string DEFAULT_MESSAGE = "Well setup not valid";
        public string rev { get; }
        public string value { get; }

        public WellPropertiesNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public WellPropertiesNotValidException(WellProperties well)
            : this(string.Format("Well setup with name = {0} not valid", well.Name))
        {
        }

        public WellPropertiesNotValidException(string message)
            : base(message)
        {
        }

        public WellPropertiesNotValidException(string message, Exception inner)
             : base(message, inner)
        {
        }
    }


    public class WellDrilledNotFoundException : Exception
    {
        private const string DEFAULT_MESSAGE = "Drilled reserve not found";
        public string rev { get; }
        public string value { get; }

        public WellDrilledNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public WellDrilledNotFoundException(WellDrilled well)
            : this(string.Format("Drilled reserve with well = {0} not found", well.WellName))
        {
        }

        public WellDrilledNotFoundException(string message)
            : base(message)
        {
        }

        public WellDrilledNotFoundException(string message, Exception inner)
             : base(message, inner)
        {
        }
    }


    public class WellUndrilledNotFoundException : Exception
    {
        private const string DEFAULT_MESSAGE = "Undrilled reserve not found";
        public string rev { get; }
        public string value { get; }

        public WellUndrilledNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public WellUndrilledNotFoundException(WellDrilled well)
            : this(string.Format("Undrilled reserve with well = {0} not found", well.WellName))
        {
        }

        public WellUndrilledNotFoundException(string message)
            : base(message)
        {
        }

        public WellUndrilledNotFoundException(string message, Exception inner)
             : base(message, inner)
        {
        }
    }

    public class WellActivityNotFoundException : Exception
    {
        private const string DEFAULT_MESSAGE = "Well activity not found";
        public string rev { get; }
        public string value { get; }

        public WellActivityNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }
    }

}