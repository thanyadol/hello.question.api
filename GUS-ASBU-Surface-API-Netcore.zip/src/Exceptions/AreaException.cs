using System; 


//model
using surflex.netcore22.Models;

namespace surflex.netcore22.Exceptions
{
    public class AreaNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Area not found";
        public string rev { get; }
        public string value { get; }

        public AreaNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public AreaNotFoundException(Area area)
            : this(string.Format("Area with id = {0} not found", area.Id.ToString()))
        {
        }

        public AreaNotFoundException(string message)
            : base(message)
        {
        }

        public AreaNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }

}