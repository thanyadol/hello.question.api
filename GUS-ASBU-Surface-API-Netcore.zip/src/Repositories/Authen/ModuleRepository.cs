using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace surflex.netcore22.Repositories
{
    public interface IModuleRepository
    {
        Task<IEnumerable<Module>> ListAsync();

        //   Task<Module> GetLastestByWellAsync(Guid id);
        //Task<ModuleAsync> GetProductiveCostAsync(string name);
        Task<Module> GetAsync(Guid id);
        Task<Module> CreateAsync(Module module);
        Task<Module> UpdateAsync(Module module);
        Task<Module> DeleteAsync(Guid id);

        Task<IEnumerable<Module>> ListRecentlyAsync();

    }

    public class ModuleRepository : IModuleRepository
    {
        //private readonly IModuleMappingService _ModuleMappingService;
        //private readonly ITableStorageRepository<ModuleEntity> _ModuleEntityTableStorageRepository;

        private readonly NorthwindContext _context;
        // private readonly IEntityService _entityService;

        public ModuleRepository(NorthwindContext context) //, IEntityService entityService) //IModuleMappingService ModuleMappingService, ITableStorageRepository<ModuleEntity> ModuleEntityTableStorageRepository)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            //_ModuleMappingService = ModuleMappingService ?? throw new ArgumentNullException(nameof(ModuleMappingService));
            //_ModuleEntityTableStorageRepository = ModuleEntityTableStorageRepository ?? throw new ArgumentNullException(nameof(ModuleEntityTableStorageRepository));

            //_entityService = entityService ?? throw new ArgumentNullException(nameof(entityService));


            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<Module> GetAsync(Guid id)
        {
            //var entityToCreate = _ModuleMappingService.Map(Module);
            //var createdEntity = await _ModuleEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createModule = _ModuleMappingService.Map(createdEntity);

            var roles = await _context.Modules.FindAsync(id);
            //_context.SaveChanges();

            return roles;
        }


        public async Task<Module> CreateAsync(Module role)
        {
            //var entityToCreate = _ModuleMappingService.Map(Module);
            //var createdEntity = await _ModuleEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createModule = _ModuleMappingService.Map(createdEntity);

            var entity = await _context.Modules.AddAsync(role);
            _context.SaveChanges();

            return entity.Entity;
        }


        public async Task<Module> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _ModuleEntityTableStorageRepository.DeleteOneAsync(roleName, ModuleKey);
            var entity = await _context.Modules.FindAsync(id);
            _context.Modules.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<Module>> ListAsync()
        {
            //var entities = await _ModuleEntityTableStorageRepository.ReadAllAsync();
            //var Module = _ModuleMappingService.Map(entities);
            //return Module;

            var entities = await _context.Modules.ToListAsync();
            //var Module = _context.Modules.ToList();
            return entities;
        }



        public async Task<IEnumerable<Module>> ListRecentlyAsync()
        {
            var entity = await _context.Modules
                                .Include(x => x.ModulePages)
                                .ThenInclude(x => x.Page).ThenInclude(x => x.PageApis)
                                .ThenInclude(x => x.Api)//.ThenInclude(x => x.PageApis)
                                .Where(c => c.ModulePages.Any(i => i.IsEnabled == true))
                                .ToListAsync();

            //set module 
            entity.Select(c =>
            {
                c.Pages = c.ModulePages.Select(m => m.Page).ToList();
                /* c.Pages.Select(

                       m =>
                       {
                           m.APIs = m.PageApis.Select(l => l.Api).ToList();
                           return m;
                       });*/
                return c;
            }).ToList();

            var temp = new List<Module>();
            foreach (var p in entity)
            {
                p.Pages = p.Pages.Select(

                       m =>
                       {
                           m.APIs = m.PageApis.Select(l => l.Api).ToList();
                           return m;
                       });

                temp.Add(p);
            }

            return temp;
        }



        public async Task<Module> UpdateAsync(Module module)
        {
            //var entityToUpdate = _ModuleMappingService.Map(Module);
            //var updatedEntity = await _ModuleEntityTableStorageRepository.InsertOrMergeAsync(entityToUpdate);
            //var deletedEntity = await _ModuleEntityTableStorageRepository.DeleteOneAsync(roleName, ModuleKey);

            var entity = await _context.Modules.FindAsync(module.Id);
            _context.Modules.Update(module);

            _context.SaveChanges();
            return entity;
        }

    }
}