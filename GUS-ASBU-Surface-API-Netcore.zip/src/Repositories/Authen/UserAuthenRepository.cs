using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;
using surflex.netcore22.Extensions;

namespace surflex.netcore22.Repositories
{

    public interface IUserAuthenRepository
    {
        Task<IEnumerable<UserAuthen>> ListAsync();

        //Task<IEnumerable<UserAuthen>> HierarchyAsync(UserListQuery query);

        //Task<IEnumerable<UserAuthen>> ListUserAuthenAsync(string project);
        //Task<UserAuthen> PutTokenAsynce(UserAuthen user, string secret);

        //Task<UserAuthen> PutProjectAsync(UserAuthen authorize);
        // Task<UserAuthen> GetByUniqueAsync(string unique);
        Task<UserAuthen> GetAsync(Guid id);
        Task<UserAuthen> CreateAsync(UserAuthen authorize);
        Task<UserAuthen> UpdateAsync(UserAuthen authorize);
        Task<UserAuthen> DeleteAsync(Guid id);
        Task<IEnumerable<UserAuthen>> ListRecentlyAsync();

    }

    public class UserAuthenRepository : IUserAuthenRepository
    {
        //private readonly IUserMappingService _UserMappingService;
        //private readonly ITableStorageRepository<UserEntity> _UserEntityTableStorageRepository;

        private readonly NorthwindContext _context;

        public UserAuthenRepository(NorthwindContext context) //IUserMappingService UserMappingService, ITableStorageRepository<UserEntity> UserEntityTableStorageRepository)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            //_UserMappingService = UserMappingService ?? throw new ArgumentNullException(nameof(UserMappingService));
            //_UserEntityTableStorageRepository = UserEntityTableStorageRepository ?? throw new ArgumentNullException(nameof(UserEntityTableStorageRepository));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<UserAuthen> CreateAsync(UserAuthen authorize)
        {
            //var entityToCreate = _UserMappingService.Map(UserAuthen);
            //var createdEntity = await _UserEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createUser = _UserMappingService.Map(createdEntity);

            var entity = await _context.UserAuthens.AddAsync(authorize);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<UserAuthen> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _UserEntityTableStorageRepository.DeleteOneAsync(userName, UserKey);
            var entity = await _context.UserAuthens.FindAsync(id);
            _context.UserAuthens.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<UserAuthen>> ListAsync()
        {
            //return await HierarchyAsync();

            return await _context.UserAuthens.ToListAsync();
        }



        public async Task<UserAuthen> UpdateAsync(UserAuthen authorize)
        {
            var entty = await _context.UserAuthens.FindAsync(authorize.Id);
            _context.UserAuthens.Update(authorize);
            _context.SaveChanges();

            return entty;
        }

        // public async Task<UserAuthen> PutProjectAsync(UserAuthen UserAuthen)
        // {

        //     //var assinedRecord = await _context.UserAuthens.FindAsync(UserAuthen.Id);
        //     var entity = await _context.UserAuthens.AddAsync(UserAuthen);
        //     _context.SaveChanges();

        //     return entity.Entity;
        // }

        public async Task<UserAuthen> GetAsync(Guid id)
        {
            var user = await _context.UserAuthens.FindAsync(id);
            return user;
        }


        public async Task<IEnumerable<UserAuthen>> ListRecentlyAsync()
        {
            var entity = await (from u in _context.Users
                                join ua in _context.UserAuthens on u.Id equals ua.UserId
                                where ua.Status == RecordStatus.ACTIVE.GetDescription()
                                select new UserAuthen()
                                {
                                    Id = ua.Id,

                                    //Location = .LocationId,

                                    UserId = u.Id,
                                    UserName = u.DisplayName,

                                    CAI = u.CAI,
                                    Email = u.Email,


                                    ExpiredDate = ua.ExpiredDate,
                                    Status = ua.Status,
                                    Date = ua.Date,

                                }).ToListAsync();

            return entity;

        }



    }
}