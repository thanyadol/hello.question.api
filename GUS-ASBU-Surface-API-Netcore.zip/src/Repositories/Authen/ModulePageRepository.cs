using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace surflex.netcore22.Repositories
{
    public interface IModulePageRepository
    {
        Task<IEnumerable<ModulePage>> ListAsync();

        Task<ModulePage> GetAsync(Guid id);
        Task<ModulePage> CreateAsync(ModulePage page);
        Task<ModulePage> UpdateAsync(ModulePage page);
        Task<ModulePage> DeleteAsync(Guid id);

        //  Task<IEnumerable<ModulePage>> ListRecentlyAsync();

    }

    public class ModulePageRepository : IModulePageRepository
    {

        private readonly NorthwindContext _context;
        // private readonly IEntityService _entityService;

        public ModulePageRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<ModulePage> GetAsync(Guid id)
        {
            //var entityToCreate = _RoleMappingService.Map(ModulePage);
            //var createdEntity = await _RoleEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createRole = _RoleMappingService.Map(createdEntity);

            var roles = await _context.ModulePages.FindAsync(id);
            //_context.SaveChanges();

            return roles;
        }


        public async Task<ModulePage> CreateAsync(ModulePage page)
        {
            //var entityToCreate = _RoleMappingService.Map(ModulePage);
            //var createdEntity = await _RoleEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createRole = _RoleMappingService.Map(createdEntity);

            var entity = await _context.ModulePages.AddAsync(page);
            _context.SaveChanges();

            return entity.Entity;
        }


        public async Task<ModulePage> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _RoleEntityTableStorageRepository.DeleteOneAsync(roleName, RoleKey);
            var entity = await _context.ModulePages.FindAsync(id);
            _context.ModulePages.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<ModulePage>> ListAsync()
        {
            //var entities = await _RoleEntityTableStorageRepository.ReadAllAsync();
            //var ModulePage = _RoleMappingService.Map(entities);
            //return ModulePage;

            var entities = await _context.ModulePages.ToListAsync();
            //var ModulePage = _context.ModulePages.ToList();
            return entities;
        }


        public async Task<IEnumerable<ModulePage>> ListRecentlyAsync()
        {
            var entity = await (from p in _context.Modules
                                join ps in _context.ModulePages on p.Id equals ps.ModuleId
                                join a in _context.Pages on ps.PageId equals a.Id
                                //join a in _context.Pages on ps.PageId equals a.Id

                                // where a.IsEnabled == true && 
                                where ps.IsEnabled == true
                                select new ModulePage()
                                {
                                    Id = ps.Id,

                                    ModuleId = p.Id,
                                    PageId = a.Id,

                                    //   Module = p,
                                    // Page = a

                                }).ToListAsync();

            return entity;
        }

        public async Task<ModulePage> UpdateAsync(ModulePage page)
        {
            //var entityToUpdate = _RoleMappingService.Map(ModulePage);
            //var updatedEntity = await _RoleEntityTableStorageRepository.InsertOrMergeAsync(entityToUpdate);
            //var deletedEntity = await _RoleEntityTableStorageRepository.DeleteOneAsync(roleName, RoleKey);

            var entity = await _context.ModulePages.FindAsync(page.Id);
            _context.ModulePages.Update(page);

            _context.SaveChanges();
            return entity;
        }

    }
}