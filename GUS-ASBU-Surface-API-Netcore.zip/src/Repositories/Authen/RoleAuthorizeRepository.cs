using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;
using surflex.netcore22.Extensions;

namespace surflex.netcore22.Repositories
{
    public interface IRoleAuthorizeRepository
    {
        Task<IEnumerable<RoleAuthorize>> ListAsync();

        Task<RoleAuthorize> GetAsync(Guid id);
        Task<RoleAuthorize> CreateAsync(RoleAuthorize authen);
        Task<RoleAuthorize> UpdateAsync(RoleAuthorize authen);
        Task<RoleAuthorize> DeleteAsync(Guid id);
        Task<IEnumerable<RoleAuthorize>> ListRecentlyAsync();
    }

    public class RoleAuthorizeRepository : IRoleAuthorizeRepository
    {

        private readonly NorthwindContext _context;
        // private readonly IEntityService _entityService;

        public RoleAuthorizeRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<RoleAuthorize> GetAsync(Guid id)
        {
            //var entityToCreate = _RoleMappingService.Map(RoleAuthorize);
            //var createdEntity = await _RoleEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createRole = _RoleMappingService.Map(createdEntity);

            var roles = await _context.RoleAuthorizes.FindAsync(id);
            //_context.SaveChanges();

            return roles;
        }


        public async Task<RoleAuthorize> CreateAsync(RoleAuthorize authen)
        {
            //var entityToCreate = _RoleMappingService.Map(RoleAuthorize);
            //var createdEntity = await _RoleEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createRole = _RoleMappingService.Map(createdEntity);

            var entity = await _context.RoleAuthorizes.AddAsync(authen);
            _context.SaveChanges();

            return entity.Entity;
        }


        public async Task<RoleAuthorize> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _RoleEntityTableStorageRepository.DeleteOneAsync(roleName, RoleKey);
            var entity = await _context.RoleAuthorizes.FindAsync(id);
            _context.RoleAuthorizes.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<RoleAuthorize>> ListAsync()
        {
            //var entities = await _RoleEntityTableStorageRepository.ReadAllAsync();
            //var RoleAuthorize = _RoleMappingService.Map(entities);
            //return RoleAuthorize;

            var entities = await _context.RoleAuthorizes.ToListAsync();
            //var RoleAuthorize = _context.RoleAuthorizes.ToList();
            return entities;
        }

        public async Task<RoleAuthorize> UpdateAsync(RoleAuthorize authen)
        {
            //var entityToUpdate = _RoleMappingService.Map(RoleAuthorize);
            //var updatedEntity = await _RoleEntityTableStorageRepository.InsertOrMergeAsync(entityToUpdate);
            //var deletedEntity = await _RoleEntityTableStorageRepository.DeleteOneAsync(roleName, RoleKey);

            Log.Information("{RoleAuthorize.UpdateAsync {0} ", authen.UserId);

            var entity = await _context.RoleAuthorizes.FindAsync(authen.Id);
            _context.RoleAuthorizes.Update(authen);

            _context.SaveChanges();
            return entity;
        }


        public async Task<IEnumerable<RoleAuthorize>> ListRecentlyAsync()
        {
            var entity = await (from p in _context.Roles
                                join ps in _context.RoleAuthorizes on p.Id equals ps.RoleId
                                join u in _context.Users on ps.UserId equals u.Id
                                where ps.Status == RecordStatus.ACTIVE.GetDescription()
                                select new RoleAuthorize()
                                {
                                    Id = ps.Id,

                                    RoleId = p.Id,

                                    User = u,
                                    Role = p,

                                    RoleName = p.Name,
                                    LocationId = p.LocationId,

                                    UserId = u.Id,
                                    DisplayName = u.DisplayName,

                                    CAI = u.CAI,
                                    // Email = u.Email,

                                    Date = ps.Date,
                                    Status = ps.Status


                                }).ToListAsync();

            return entity;

        }

    }
}