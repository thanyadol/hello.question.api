using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;
using surflex.netcore22.Extensions;

namespace surflex.netcore22.Repositories
{

    public interface IUserRepository
    {
        Task<IEnumerable<User>> ListAsync();

        //Task<IEnumerable<User>> HierarchyAsync(UserListQuery query);

        //Task<IEnumerable<UserAuthen>> ListUserAuthenAsync(string project);
        //Task<User> PutTokenAsynce(User user, string secret);

        //Task<UserAuthen> PutProjectAsync(UserAuthen authorize);
        // Task<User> GetByUniqueAsync(string unique);
        Task<User> GetAsync(string id);
        Task<User> CreateAsync(User User);
        Task<User> UpdateAsync(User User);
        Task<User> DeleteAsync(string id);

        //Task<IEnumerable<User>> ListRecentlyAsync();
        // Task<IEnumerable<User>> GetRecentlyAsync(string id);

        Task<IEnumerable<User>> ListAuthenAsync();
        Task<IEnumerable<User>> ListAuthorizeAsync();
    }

    public class UserRepository : IUserRepository
    {
        //private readonly IUserMappingService _UserMappingService;
        //private readonly ITableStorageRepository<UserEntity> _UserEntityTableStorageRepository;

        private readonly NorthwindContext _context;

        public UserRepository(NorthwindContext context) //IUserMappingService UserMappingService, ITableStorageRepository<UserEntity> UserEntityTableStorageRepository)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            //_UserMappingService = UserMappingService ?? throw new ArgumentNullException(nameof(UserMappingService));
            //_UserEntityTableStorageRepository = UserEntityTableStorageRepository ?? throw new ArgumentNullException(nameof(UserEntityTableStorageRepository));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<User> CreateAsync(User user)
        {
            //var entityToCreate = _UserMappingService.Map(User);
            //var createdEntity = await _UserEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createUser = _UserMappingService.Map(createdEntity);

            var entity = await _context.Users.AddAsync(user);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<User> DeleteAsync(string id)
        {
            //var deletedEntity = await _UserEntityTableStorageRepository.DeleteOneAsync(userName, UserKey);
            var entity = await _context.Users.FindAsync(id);
            _context.Users.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        //user/authen/list
        public async Task<IEnumerable<User>> ListAuthenAsync()
        {
            var entity = await (from p in _context.Users
                                join pa in _context.UserAuthens on p.Id equals pa.UserId
                                where pa.Status == RecordStatus.ACTIVE.GetDescription()
                                //&& p.Id == id
                                //    join pl in _context.SessionLoggs on p.Id equals pl.UserId 
                                //    where pl.Date 
                                select new User()
                                {
                                    Id = p.Id,
                                    DisplayName = p.Name,
                                    CAI = p.CAI,
                                    Email = p.Email,
                                    EmployeeId = p.EmployeeId,
                                    IsADEnable = p.IsADEnable,

                                    AccountName = p.AccountName,
                                    Created = p.Created,
                                    ADId = p.ADId,

                                    Authen = pa,
                                    //  LastLogin = pl,

                                }).ToListAsync();

            return entity;
        }


        public async Task<IEnumerable<User>> ListAuthorizeAsync()
        {
            var entity = await _context.Users
                          .Include(x => x.UserAuthens)
                          //    .Where(
                          //       c => c.RoleAuthorizes.Any(i => i.Status == RecordStatus.ACTIVE.GetDescription())
                          //   )
                          .Include(x => x.RoleAuthorizes).ThenInclude(x => x.Role)
                          //   .Where(
                          //       c => c.RoleAuthorizes.Any(i => i.Status == RecordStatus.ACTIVE.GetDescription())
                          //   )
                          //  .Where(c => c.RoleAuthorizes.Any(i => i.Status == RecordStatus.ACTIVE.GetDescription()))
                          //    .Where(c => c.UserAuthens.Any(i => i.Status == RecordStatus.ACTIVE.GetDescription()))

                          .ToListAsync();

            //set role name
            entity.Select(c =>
            {
                c.RoleAuthorizes = c.RoleAuthorizes.Select(x => { x.RoleName = x.Role.Name; return x; })
                                                  .Where(i => i.Status == RecordStatus.ACTIVE.GetDescription())
                                                 .ToList();

                c.Authen = c.UserAuthens.Where(i => i.Status == RecordStatus.ACTIVE.GetDescription()).FirstOrDefault();

                return c;
            }).ToList();

            return entity;

            // //role
            // var entity = await (from p in _context.Users

            //                     join ps in _context.RoleAuthorizes on p.Id equals ps.UserId

            //                     where ps.Status == RecordStatus.ACTIVE.GetDescription()
            //                     //  join a in _context.Roles on ps.RoleId equals a.Id
            //                     //where a.IsEnabled == true // && ps.IsEnabled == true
            //                     //select ps into t
            //                     // into t
            //                     select new User()
            //                     {
            //                         Id = p.Id,
            //                         DisplayName = p.Name,
            //                         CAI = p.CAI,
            //                         Email = p.Email,
            //                         EmployeeId = p.EmployeeId,
            //                         IsADEnable = p.IsADEnable,

            //                         AccountName = p.AccountName,
            //                         Created = p.Created,
            //                         ADId = p.ADId,

            //                         // Authen = pa,
            //                         //LastLogin = pl,

            //                         //ExpiredDate = p.ExpiredDate,

            //                         //Roles = t.ToList(),

            //                     }).ToListAsync();

            //project
            // var query = from p in entity
            //             join ps in _context.ProjectAuthorizes on p.Id equals ps.UserId
            //             join a in _context.Projects on ps.ProjectId equals a.Id
            //             where ps.Status == RecordStatus.ACTIVE.GetDescription()
            //             //where a.IsEnabled == true // && ps.IsEnabled == true
            //             //select ps into t
            //             //into t
            //             select new User()
            //             {
            //                 Id = p.Id,
            //                 DisplayName = p.Name,
            //                 CAI = p.CAI,
            //                 Email = p.Email,
            //                 EmployeeId = p.EmployeeId,
            //                 IsADEnable = p.IsADEnable,

            //                 AccountName = p.AccountName,
            //                 Created = p.Created,
            //                 ADId = p.ADId,

            //                 // Authen = pa,
            //                 //LastLogin = pl,

            //                 //ExpiredDate = p.ExpiredDate,

            //                 //Roles = p.Roles,
            //                 // TeamProjects = t,

            //             };


            // return query;
        }

        /* public async Task<IEnumerable<User>> HierarchyAsync(UserListQuery query)
        {
            var entities = _context.Users.AsQueryable();

            if (query != null)
            {
                if (!string.IsNullOrEmpty(query.CAI))
                    entities = entities.Where(x => x.CAI.Contains(query.CAI));

                if (!string.IsNullOrEmpty(query.Name))
                    entities = entities.Where(x => x.CAI.Contains(query.Name));

                if (!string.IsNullOrEmpty(query.Unique))
                    entities = entities.Where(x => x.CAI.Contains(query.Unique));

                //int count = entities.Count();

                entities = entities.Skip(query.Limit * (query.Page - 1)).Take(query.Limit);
            }

            return await entities.ToListAsync();
        }*/

        /* 
        public async Task<IEnumerable<UserAuthen>> ListUserAuthenAsync(string projectid)
        {
            var entities = await (from up in _context.UserAuthens
                                  join u in _context.Users on up.UserId equals u.Id
                                  join j in _context.Projects on up.ProjectId equals j.Id
                                  where j.Id == projectid
                                  select new UserAuthen
                                  {
                                      Id = up.Id,
                                      UserId = u.Id,
                                      UserName = u.Name,
                                      CAI = u.CAI,

                                      ProjectId = j.Id,

                                      ProjectName = j.Name,

                                      Started = up.Started,
                                      Finished = up.Finished,

                                      By = up.By,

                                  }).ToListAsync();

            //var entities = await _context.UserAuthens.Where(c => c.ProjectId == projectid).ToListAsync();

            return entities;
        }*/

        public async Task<User> UpdateAsync(User User)
        {
            var updateUser = await _context.Users.FindAsync(User.Id);
            _context.Users.Update(User);
            _context.SaveChanges();

            return updateUser;
        }

        // public async Task<UserAuthen> PutProjectAsync(UserAuthen UserAuthen)
        // {

        //     //var assinedRecord = await _context.UserAuthens.FindAsync(UserAuthen.Id);
        //     var entity = await _context.UserAuthens.AddAsync(UserAuthen);
        //     _context.SaveChanges();

        //     return entity.Entity;
        // }

        public async Task<User> GetAsync(string id)
        {
            var user = await _context.Users.FindAsync(id);
            return user;
        }


        public async Task<IEnumerable<User>> ListAsync()
        {
            var user = await _context.Users.ToListAsync();
            return user;
        }

        /*public Task<User> ListPlannedProjectAsync(string projectId)
        {
            var entities = await _context.Users.ToListAsync();
            //var User = _context.Users.ToList();
            return entities;
        }*/

        /* 
        public async Task<IEnumerable<User>> ReadAllInClanAsync(string userName)
        {
            var entities = await _UserEntityTableStorageRepository.ReadPartitionAsync(userName);
            var User = _UserMappingService.Map(entities);
            return User;
        }

        public async Task<User> ReadOneAsync(string userName, string UserKey)
        {
            var entity = await _UserEntityTableStorageRepository.ReadOneAsync(userName, UserKey);
            var User = _UserMappingService.Map(entity);
            return User;
        }
        */

    }
}