using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace surflex.netcore22.Repositories
{
    public interface IRoleRepository
    {
        Task<IEnumerable<Role>> ListAsync();

        //   Task<Role> GetLastestByWellAsync(Guid id);
        //Task<RoleAsync> GetProductiveCostAsync(string name);
        Task<Role> GetAsync(Guid id);
        Task<Role> CreateAsync(Role Role);
        Task<Role> UpdateAsync(Role Role);
        Task<Role> DeleteAsync(Guid id);

        Task<IEnumerable<Role>> ListRecentlyAsync();

    }

    public class RoleRepository : IRoleRepository
    {
        //private readonly IRoleMappingService _RoleMappingService;
        //private readonly ITableStorageRepository<RoleEntity> _RoleEntityTableStorageRepository;

        private readonly NorthwindContext _context;
        // private readonly IEntityService _entityService;

        public RoleRepository(NorthwindContext context) //, IEntityService entityService) //IRoleMappingService RoleMappingService, ITableStorageRepository<RoleEntity> RoleEntityTableStorageRepository)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            //_RoleMappingService = RoleMappingService ?? throw new ArgumentNullException(nameof(RoleMappingService));
            //_RoleEntityTableStorageRepository = RoleEntityTableStorageRepository ?? throw new ArgumentNullException(nameof(RoleEntityTableStorageRepository));

            //_entityService = entityService ?? throw new ArgumentNullException(nameof(entityService));


            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<Role> GetAsync(Guid id)
        {
            //var entityToCreate = _RoleMappingService.Map(Role);
            //var createdEntity = await _RoleEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createRole = _RoleMappingService.Map(createdEntity);

            var roles = await _context.Roles.FindAsync(id);
            //_context.SaveChanges();

            return roles;
        }


        public async Task<Role> CreateAsync(Role role)
        {
            //var entityToCreate = _RoleMappingService.Map(Role);
            //var createdEntity = await _RoleEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createRole = _RoleMappingService.Map(createdEntity);

            var entity = await _context.Roles.AddAsync(role);
            _context.SaveChanges();

            return entity.Entity;
        }


        public async Task<Role> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _RoleEntityTableStorageRepository.DeleteOneAsync(roleName, RoleKey);
            var entity = await _context.Roles.FindAsync(id);
            _context.Roles.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<Role>> ListAsync()
        {
            //var entities = await _RoleEntityTableStorageRepository.ReadAllAsync();
            //var Role = _RoleMappingService.Map(entities);
            //return Role;

            var entities = await _context.Roles.ToListAsync();
            //var Role = _context.Roles.ToList();
            return entities;
        }


        public async Task<IEnumerable<Role>> ListRecentlyAsync()
        {

            var entity = await _context.Roles
              .Include(x => x.RoleModules)
                .ThenInclude(x => x.Module).ThenInclude(x => x.ModulePages)
               .ThenInclude(x => x.Page).ThenInclude(x => x.PageApis)
                  .Where(c => c.RoleModules.Any(i => i.IsEnabled == true))
              //   .Where(c => c.ModulePages.Any(i => i.IsEnabled == true))
              //    .Where(c => c.PageApis.Any(i => i.IsEnabled == true))
              .ToListAsync();

            //set module 
            entity.Select(c =>
            {
                c.Modules = c.RoleModules.Select(m => m.Module).ToList();
                c.Modules.Select(m => m.Pages = m.ModulePages.Select(l => l.Page).ToList());
                return c;
            }).ToList();

            // //set page 
            // entity.Select(c =>
            // {
            //     c.Modules.Select(x => x.Pages = x.ModulePages.Select(m => m.Page).ToList());

            //     return c;
            // }).ToList();

            //api
            //set page 


            return entity;
        }



        /* 
        public async Task<IEnumerable<Role>> ListRecentlyAsync()
        {
            var entity = await (from p in _context.Roles
                                join ps in _context.RolePages on p.Id equals ps.RoleId
                                join a in _context.Pages on ps.PageId equals a.Id
                                //where a.IsEnabled == true // && ps.IsEnabled == true
                                //select ps into t
                                into t
                                select new Role()
                                {
                                    Id = p.Id,
                                    Name = p.Name,
                                    LocationId = p.LocationId,
                                    Type = p.Type,

                                    Created = p.Created,

                                    Pages = t,

                                }).ToListAsync();

            return entity;
        }*/



        public async Task<Role> UpdateAsync(Role Role)
        {
            //var entityToUpdate = _RoleMappingService.Map(Role);
            //var updatedEntity = await _RoleEntityTableStorageRepository.InsertOrMergeAsync(entityToUpdate);
            //var deletedEntity = await _RoleEntityTableStorageRepository.DeleteOneAsync(roleName, RoleKey);

            var entity = await _context.Roles.FindAsync(Role.Id);
            _context.Roles.Update(Role);

            _context.SaveChanges();
            return entity;
        }

    }
}