using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace surflex.netcore22.Repositories
{
    public interface IPageRepository
    {
        Task<IEnumerable<Page>> ListAsync();

        //   Task<Page> GetLastestByWellAsync(Guid id);
        //Task<PageAsync> GetProductiveCostAsync(string name);
        Task<Page> GetAsync(Guid id);
        Task<Page> CreateAsync(Page page);
        Task<Page> UpdateAsync(Page page);
        Task<Page> DeleteAsync(Guid id);

        //ask<IEnumerable<Page>> ListRecentlyAsync();
        Task<IEnumerable<Page>> ListRecentlyAsync();

    }

    public class PageRepository : IPageRepository
    {
        //private readonly IPageMappingService _PageMappingService;
        //private readonly ITableStorageRepository<PageEntity> _PageEntityTableStorageRepository;

        private readonly NorthwindContext _context;
        // private readonly IEntityService _entityService;

        public PageRepository(NorthwindContext context) //, IEntityService entityService) //IPageMappingService PageMappingService, ITableStorageRepository<PageEntity> PageEntityTableStorageRepository)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            //_PageMappingService = PageMappingService ?? throw new ArgumentNullException(nameof(PageMappingService));
            //_PageEntityTableStorageRepository = PageEntityTableStorageRepository ?? throw new ArgumentNullException(nameof(PageEntityTableStorageRepository));

            //_entityService = entityService ?? throw new ArgumentNullException(nameof(entityService));


            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<Page> GetAsync(Guid id)
        {
            //var entityToCreate = _PageMappingService.Map(Page);
            //var createdEntity = await _PageEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createPage = _PageMappingService.Map(createdEntity);

            var groups = await _context.Pages.FindAsync(id);
            //_context.SaveChanges();

            return groups;
        }


        public async Task<Page> CreateAsync(Page page)
        {
            //var entityToCreate = _PageMappingService.Map(Page);
            //var createdEntity = await _PageEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createPage = _PageMappingService.Map(createdEntity);

            var entity = await _context.Pages.AddAsync(page);
            _context.SaveChanges();

            return entity.Entity;
        }


        public async Task<Page> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _PageEntityTableStorageRepository.DeleteOneAsync(groupName, PageKey);
            var entity = await _context.Pages.FindAsync(id);
            _context.Pages.Remove(entity);
            _context.SaveChanges();

            return entity;
        }

        public async Task<IEnumerable<Page>> ListAsync()
        {
            //var entities = await _PageEntityTableStorageRepository.ReadAllAsync();
            //var Page = _PageMappingService.Map(entities);
            //return Page;

            var entities = await _context.Pages.ToListAsync();
            //var Page = _context.Pages.ToList();
            return entities;
        }


        public async Task<IEnumerable<Page>> ListRecentlyAsync()
        {
            var entity = await _context.Pages
                .Include(x => x.PageApis)
                    // .ThenInclude(x => x.Module).ThenInclude(x => x.ModulePages)
                    .ThenInclude(x => x.Api)//.ThenInclude(x => x.PageApis)
                                            //.ThenInclude(x => x.Api)
                                            // .Where(c => c.PageApis.Any(i => i.IsEnabled == true))
                .ToListAsync();

            //set module 
            entity.Select(c =>
            {
                c.APIs = c.PageApis.Where(i => i.IsEnabled == true).Select(m => m.Api).ToList();
                return c;
            }).ToList();


            return entity;
        }

        public async Task<Page> UpdateAsync(Page Page)
        {
            //var entityToUpdate = _PageMappingService.Map(Page);
            //var updatedEntity = await _PageEntityTableStorageRepository.InsertOrMergeAsync(entityToUpdate);
            //var deletedEntity = await _PageEntityTableStorageRepository.DeleteOneAsync(groupName, PageKey);

            var updatePage = await _context.Pages.FindAsync(Page.Id);
            _context.Pages.Update(Page);

            _context.SaveChanges();
            return updatePage;
        }



    }
}