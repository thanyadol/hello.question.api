using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace surflex.netcore22.Repositories
{
    public interface IPageApiRepository
    {
        Task<IEnumerable<PageApi>> ListAsync();

        //   Task<PageApi> GetLastestByWellAsync(Guid id);
        //Task<PageApiAsync> GetProductiveCostAsync(string name);
        Task<PageApi> GetAsync(Guid id);
        Task<PageApi> CreateAsync(PageApi api);
        Task<PageApi> UpdateAsync(PageApi api);
        Task<PageApi> DeleteAsync(Guid id);

        Task<IEnumerable<PageApi>> ListRecentlyAsync();
    }

    public class PageApiRepository : IPageApiRepository
    {
        //private readonly IPageApiMappingService _PageApiMappingService;
        //private readonly ITableStorageRepository<PageApiEntity> _PageApiEntityTableStorageRepository;

        private readonly NorthwindContext _context;
        // private readonly IEntityService _entityService;

        public PageApiRepository(NorthwindContext context) //, IEntityService entityService) //IPageApiMappingService PageApiMappingService, ITableStorageRepository<PageApiEntity> PageApiEntityTableStorageRepository)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            //_PageApiMappingService = PageApiMappingService ?? throw new ArgumentNullException(nameof(PageApiMappingService));
            //_PageApiEntityTableStorageRepository = PageApiEntityTableStorageRepository ?? throw new ArgumentNullException(nameof(PageApiEntityTableStorageRepository));

            //_entityService = entityService ?? throw new ArgumentNullException(nameof(entityService));


            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<PageApi> GetAsync(Guid id)
        {
            //var entityToCreate = _PageApiMappingService.Map(PageApi);
            //var createdEntity = await _PageApiEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createPageApi = _PageApiMappingService.Map(createdEntity);

            var groups = await _context.PageApis.FindAsync(id);
            //_context.SaveChanges();

            return groups;
        }


        public async Task<PageApi> CreateAsync(PageApi group)
        {
            //var entityToCreate = _PageApiMappingService.Map(PageApi);
            //var createdEntity = await _PageApiEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createPageApi = _PageApiMappingService.Map(createdEntity);

            var entity = await _context.PageApis.AddAsync(group);
            _context.SaveChanges();

            return entity.Entity;
        }


        public async Task<PageApi> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _PageApiEntityTableStorageRepository.DeleteOneAsync(groupName, PageApiKey);
            var entity = await _context.PageApis.FindAsync(id);
            _context.PageApis.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<PageApi>> ListAsync()
        {
            //var entities = await _PageApiEntityTableStorageRepository.ReadAllAsync();
            //var PageApi = _PageApiMappingService.Map(entities);
            //return PageApi;

            var entities = await _context.PageApis.ToListAsync();
            //var PageApi = _context.PageApis.ToList();
            return entities;
        }


        public async Task<PageApi> UpdateAsync(PageApi api)
        {
            //var entityToUpdate = _PageApiMappingService.Map(PageApi);
            //var updatedEntity = await _PageApiEntityTableStorageRepository.InsertOrMergeAsync(entityToUpdate);
            //var deletedEntity = await _PageApiEntityTableStorageRepository.DeleteOneAsync(groupName, PageApiKey);

            var entity = await _context.PageApis.FindAsync(api.Id);
            _context.PageApis.Update(api);

            _context.SaveChanges();
            return entity;
        }


        public async Task<IEnumerable<PageApi>> ListRecentlyAsync()
        {
            var entity = await (from p in _context.Pages
                                join ps in _context.PageApis on p.Id equals ps.PageId
                                join a in _context.Apis on ps.ApiId equals a.Id
                                where ps.IsEnabled == true
                                select new PageApi()
                                {
                                    Id = ps.Id,

                                    PageId = p.Id,
                                    ApiId = ps.Id,

                                    Page = p,
                                    Api = a

                                }).ToListAsync();

            return entity;
        }

    }
}