using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace surflex.netcore22.Repositories
{
    public interface IUserActivityRepository
    {
        Task<IEnumerable<UserActivity>> ListAsync();

        // Task<UserActivity> GetRecentlyAsync(Guid id, string action);

        Task<UserActivity> GetAsync(Guid id);
        Task<UserActivity> CreateAsync(UserActivity activity);
        Task<UserActivity> UpdateAsync(UserActivity activity);
        //Task<UserActivity> DeleteAsync(string id);
    }
    /*
     * to controll the user activities
     *
     */

    public class UserActivityRepository : IUserActivityRepository
    {

        private readonly NorthwindContext _context;
        public UserActivityRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<UserActivity> CreateAsync(UserActivity activity)
        {

            var entity = await _context.UserActivities.AddAsync(activity);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<UserActivity> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _UserActivityEntityTableStorageRepository.DeleteOneAsync(UserActivityName, UserActivityKey);
            var entity = await _context.UserActivities.FindAsync(id);
            _context.UserActivities.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<UserActivity>> ListAsync()
        {

            var entities = await _context.UserActivities.ToListAsync();
            //var UserActivity = _context.UserActivities.ToList();
            return entities;
        }

        public async Task<UserActivity> UpdateAsync(UserActivity activity)
        {

            var entity = await _context.UserActivities.FindAsync(activity.Id);

            // activity.By = "admin";
            // activity.Date = Utility.CurrentSEAsiaStandardTime();

            _context.UserActivities.Update(activity);

            _context.SaveChanges();
            return entity;
        }



        public async Task<UserActivity> GetAsync(Guid id)
        {
            var entity = await _context.UserActivities.FindAsync(id);
            return entity;
        }


    }
}