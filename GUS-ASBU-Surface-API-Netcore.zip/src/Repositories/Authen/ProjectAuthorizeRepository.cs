using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;
using surflex.netcore22.Extensions;

namespace surflex.netcore22.Repositories
{
    public interface IProjectAuthorizeRepository
    {
        Task<IEnumerable<ProjectAuthorize>> ListAsync();

        Task<ProjectAuthorize> GetAsync(Guid id);
        Task<ProjectAuthorize> CreateAsync(ProjectAuthorize authen);
        Task<ProjectAuthorize> UpdateAsync(ProjectAuthorize authen);
        Task<ProjectAuthorize> DeleteAsync(Guid id);

        Task<IEnumerable<ProjectAuthorize>> ListRecentlyAsync();

    }

    public class ProjectAuthorizeRepository : IProjectAuthorizeRepository
    {

        private readonly NorthwindContext _context;
        // private readonly IEntityService _entityService;

        public ProjectAuthorizeRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));


            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<ProjectAuthorize> GetAsync(Guid id)
        {
            //var entityToCreate = _GroupMappingService.Map(ProjectAuthorize);
            //var createdEntity = await _GroupEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createGroup = _GroupMappingService.Map(createdEntity);

            var groups = await _context.ProjectAuthorizes.FindAsync(id);
            //_context.SaveChanges();

            return groups;
        }


        public async Task<ProjectAuthorize> CreateAsync(ProjectAuthorize authen)
        {
            //var entityToCreate = _GroupMappingService.Map(ProjectAuthorize);
            //var createdEntity = await _GroupEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createGroup = _GroupMappingService.Map(createdEntity);

            var createGroup = await _context.ProjectAuthorizes.AddAsync(authen);
            _context.SaveChanges();

            return createGroup.Entity;
        }


        public async Task<ProjectAuthorize> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _GroupEntityTableStorageRepository.DeleteOneAsync(groupName, GroupKey);
            var deletedGroup = await _context.ProjectAuthorizes.FindAsync(id);
            _context.ProjectAuthorizes.Remove(deletedGroup);
            _context.SaveChanges();
            return deletedGroup;
        }

        public async Task<IEnumerable<ProjectAuthorize>> ListAsync()
        {
            //var entities = await _GroupEntityTableStorageRepository.ReadAllAsync();
            //var ProjectAuthorize = _GroupMappingService.Map(entities);
            //return ProjectAuthorize;

            var entities = await _context.ProjectAuthorizes.ToListAsync();
            //var ProjectAuthorize = _context.ProjectAuthorizes.ToList();
            return entities;
        }

        public async Task<ProjectAuthorize> UpdateAsync(ProjectAuthorize authen)
        {
            //Log.Information("ProjectAuthorize.UpdateAsync.Id {0}", authen.Id);
            //Log.Information("ProjectAuthorize.UpdateAsync.ProjectId {0}", authen.ProjectId);

            var updateGroup = await _context.ProjectAuthorizes.FindAsync(authen.Id);
            _context.ProjectAuthorizes.Update(authen);

            _context.SaveChanges();
            return updateGroup;
        }

        public async Task<IEnumerable<ProjectAuthorize>> ListRecentlyAsync()
        {
            var entity = await (from p in _context.Projects
                                join ps in _context.ProjectAuthorizes on p.Id equals ps.ProjectId
                                join u in _context.Users on ps.UserId equals u.Id
                                where ps.Status == RecordStatus.ACTIVE.GetDescription()
                                select new ProjectAuthorize()
                                {
                                    Id = ps.Id,

                                    ProjectId = p.Id,

                                    ProjectName = p.Name,
                                    LocationId = p.LocationId,

                                    UserId = u.Id,
                                    DisplayName = u.DisplayName,

                                    CAI = u.CAI,
                                    Email = u.Email,

                                    Date = ps.Date,
                                    Status = ps.Status


                                }).ToListAsync();

            return entity;

        }

    }
}