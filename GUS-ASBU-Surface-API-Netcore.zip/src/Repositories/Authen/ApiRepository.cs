using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace surflex.netcore22.Repositories
{
    public interface IApiRepository
    {
        Task<IEnumerable<Api>> ListAsync();

        //   Task<Api> GetLastestByWellAsync(Guid id);
        //Task<ApiAsync> GetProductiveCostAsync(string name);
        Task<Api> GetAsync(Guid id);
        Task<Api> CreateAsync(Api api);
        Task<Api> UpdateAsync(Api api);
        Task<Api> DeleteAsync(Guid id);

    }

    public class ApiRepository : IApiRepository
    {
        //private readonly IApiMappingService _ApiMappingService;
        //private readonly ITableStorageRepository<ApiEntity> _ApiEntityTableStorageRepository;

        private readonly NorthwindContext _context;
        // private readonly IEntityService _entityService;

        public ApiRepository(NorthwindContext context) //, IEntityService entityService) //IApiMappingService ApiMappingService, ITableStorageRepository<ApiEntity> ApiEntityTableStorageRepository)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            //_ApiMappingService = ApiMappingService ?? throw new ArgumentNullException(nameof(ApiMappingService));
            //_ApiEntityTableStorageRepository = ApiEntityTableStorageRepository ?? throw new ArgumentNullException(nameof(ApiEntityTableStorageRepository));

            //_entityService = entityService ?? throw new ArgumentNullException(nameof(entityService));


            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<Api> GetAsync(Guid id)
        {
            //var entityToCreate = _ApiMappingService.Map(Api);
            //var createdEntity = await _ApiEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createApi = _ApiMappingService.Map(createdEntity);

            var groups = await _context.Apis.FindAsync(id);
            //_context.SaveChanges();

            return groups;
        }


        public async Task<Api> CreateAsync(Api group)
        {
            //var entityToCreate = _ApiMappingService.Map(Api);
            //var createdEntity = await _ApiEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createApi = _ApiMappingService.Map(createdEntity);

            var entity = await _context.Apis.AddAsync(group);
            _context.SaveChanges();

            return entity.Entity;
        }


        public async Task<Api> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _ApiEntityTableStorageRepository.DeleteOneAsync(groupName, ApiKey);
            var entity = await _context.Apis.FindAsync(id);
            _context.Apis.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<Api>> ListAsync()
        {
            //var entities = await _ApiEntityTableStorageRepository.ReadAllAsync();
            //var Api = _ApiMappingService.Map(entities);
            //return Api;

            var entities = await _context.Apis.ToListAsync();
            //var Api = _context.Apis.ToList();
            return entities;
        }

        public async Task<Api> UpdateAsync(Api api)
        {
            //var entityToUpdate = _ApiMappingService.Map(Api);
            //var updatedEntity = await _ApiEntityTableStorageRepository.InsertOrMergeAsync(entityToUpdate);
            //var deletedEntity = await _ApiEntityTableStorageRepository.DeleteOneAsync(groupName, ApiKey);

            var entity = await _context.Apis.FindAsync(api.Id);
            _context.Apis.Update(api);

            _context.SaveChanges();
            return entity;
        }

    }
}