using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace surflex.netcore22.Repositories
{
    public interface ISessionLoggRepository
    {
        Task<IEnumerable<SessionLogg>> ListAsync();

        // Task<SessionLogg> GetRecentlyAsync(Guid id, string action);

        Task<SessionLogg> GetAsync(Guid id);
        Task<SessionLogg> CreateAsync(SessionLogg logg);
        Task<SessionLogg> UpdateAsync(SessionLogg logg);
        //Task<SessionLogg> DeleteAsync(string id);
    }
    /*
     * to controll the user activities
     *
     */

    public class SessionLoggRepository : ISessionLoggRepository
    {

        private readonly NorthwindContext _context;
        public SessionLoggRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<SessionLogg> CreateAsync(SessionLogg logg)
        {

            var entity = await _context.SessionLoggs.AddAsync(logg);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<SessionLogg> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _SessionLoggEntityTableStorageRepository.DeleteOneAsync(SessionLoggName, SessionLoggKey);
            var entity = await _context.SessionLoggs.FindAsync(id);
            _context.SessionLoggs.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<SessionLogg>> ListAsync()
        {

            var entities = await _context.SessionLoggs.ToListAsync();
            //var SessionLogg = _context.SessionLoggs.ToList();
            return entities;
        }

        public async Task<SessionLogg> UpdateAsync(SessionLogg logg)
        {

            var entity = await _context.SessionLoggs.FindAsync(logg.Id);

            // logg.By = "admin";
            // logg.Date = Utility.CurrentSEAsiaStandardTime();

            _context.SessionLoggs.Update(logg);

            _context.SaveChanges();
            return entity;
        }



        public async Task<SessionLogg> GetAsync(Guid id)
        {
            var entity = await _context.SessionLoggs.FindAsync(id);
            return entity;
        }


    }
}