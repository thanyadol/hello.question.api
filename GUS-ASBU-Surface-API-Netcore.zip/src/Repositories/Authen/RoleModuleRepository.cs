using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace surflex.netcore22.Repositories
{
    public interface IRoleModuleRepository
    {
        Task<IEnumerable<RoleModule>> ListAsync();

        Task<RoleModule> GetAsync(Guid id);
        Task<RoleModule> CreateAsync(RoleModule authen);
        Task<RoleModule> UpdateAsync(RoleModule authen);
        Task<RoleModule> DeleteAsync(Guid id);

        Task<IEnumerable<RoleModule>> ListRecentlyAsync();

    }

    public class RoleModuleRepository : IRoleModuleRepository
    {

        private readonly NorthwindContext _context;
        // private readonly IEntityService _entityService;

        public RoleModuleRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<RoleModule> GetAsync(Guid id)
        {
            //var entityToCreate = _RoleMappingService.Map(RoleModule);
            //var createdEntity = await _RoleEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createRole = _RoleMappingService.Map(createdEntity);

            var roles = await _context.RoleModules.FindAsync(id);
            //_context.SaveChanges();

            return roles;
        }


        public async Task<RoleModule> CreateAsync(RoleModule authen)
        {
            //var entityToCreate = _RoleMappingService.Map(RoleModule);
            //var createdEntity = await _RoleEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createRole = _RoleMappingService.Map(createdEntity);

            var entity = await _context.RoleModules.AddAsync(authen);
            _context.SaveChanges();

            return entity.Entity;
        }


        public async Task<RoleModule> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _RoleEntityTableStorageRepository.DeleteOneAsync(roleName, RoleKey);
            var entity = await _context.RoleModules.FindAsync(id);
            _context.RoleModules.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<RoleModule>> ListAsync()
        {
            //var entities = await _RoleEntityTableStorageRepository.ReadAllAsync();
            //var RoleModule = _RoleMappingService.Map(entities);
            //return RoleModule;

            var entities = await _context.RoleModules.ToListAsync();
            //var RoleModule = _context.RoleModules.ToList();
            return entities;
        }


        public async Task<IEnumerable<RoleModule>> ListRecentlyAsync()
        {
            var entity = await (from p in _context.Roles
                                join ps in _context.RoleModules on p.Id equals ps.RoleId
                                join a in _context.Modules on ps.ModuleId equals a.Id
                                where ps.IsEnabled == true
                                select new RoleModule()
                                {
                                    Id = ps.Id,

                                    ModuleId = p.Id,
                                    RoleId = ps.Id,

                                    Module = a,
                                    Role = p

                                }).ToListAsync();

            return entity;
        }

        public async Task<RoleModule> UpdateAsync(RoleModule authen)
        {
            //var entityToUpdate = _RoleMappingService.Map(RoleModule);
            //var updatedEntity = await _RoleEntityTableStorageRepository.InsertOrMergeAsync(entityToUpdate);
            //var deletedEntity = await _RoleEntityTableStorageRepository.DeleteOneAsync(roleName, RoleKey);

            var entity = await _context.RoleModules.FindAsync(authen.Id);
            _context.RoleModules.Update(authen);

            _context.SaveChanges();
            return entity;
        }

    }
}