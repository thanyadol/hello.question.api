using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

using Serilog;
using Microsoft.EntityFrameworkCore;

namespace surflex.netcore22.Repositories
{
    public interface IRiggRateRepository
    {
        Task<IEnumerable<RiggRate>> ListAsync();

        //list by templateid
        Task<IEnumerable<RiggRate>> ListAsync(string id);
        //Task<RiggRate> GetRecentlyAsync(string id, string type);

        Task<RiggRate> GetAsync(string id);
        Task<RiggRate> CreateAsync(RiggRate rate);
        Task<RiggRate> UpdateAsync(RiggRate rate);
        Task<RiggRate> DeleteAsync(string id);
    }


    public class RiggRateRepository : IRiggRateRepository
    {

        private readonly NorthwindContext _context;
        public RiggRateRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<RiggRate> CreateAsync(RiggRate rate)
        {

            var entity = await _context.RiggRates.AddAsync(rate);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<RiggRate> DeleteAsync(string id)
        {
            //var deletedEntity = await _RiggRateEntityTableStorageRepository.DeleteOneAsync(RiggRateName, RiggRateKey);
            var entity = await _context.RiggRates.FindAsync(id);
            _context.RiggRates.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<RiggRate>> ListAsync()
        {

            var entities = await _context.RiggRates.ToListAsync();
            //var RiggRate = _context.RiggRates.ToList();
            return entities;
        }


        public async Task<IEnumerable<RiggRate>> ListAsync(string id)
        {
            var entities = await (from up in _context.RiggRates
                                  join u in _context.Riggs on up.RiggId equals u.Id
                                  where up.TemplateId == id
                                  select new RiggRate
                                  {
                                      Id = up.Id,
                                      RiggName = u.Name,
                                      RiggId = u.Id,
                                      TIH = up.TIH,
                                      TOH = up.TOH,
                                      Activity = up.Activity,

                                      Type = up.Type,

                                      Created = up.Created,

                                      TemplateId = id,


                                      By = up.By,

                                  }).ToListAsync();

            //var entities = await _context.UserAuthens.Where(c => c.ProjectId == projectid).ToListAsync();

            return entities;
        }


        public async Task<RiggRate> UpdateAsync(RiggRate rate)
        {

            var entity = await _context.RiggRates.FindAsync(rate.Id);

            // rate.By = "admin";
            // rate.Date = Utility.CurrentSEAsiaStandardTime();

            _context.RiggRates.Update(rate);

            _context.SaveChanges();
            return entity;
        }

        public async Task<RiggRate> GetAsync(string id)
        {
            var entity = await _context.RiggRates.FindAsync(id);
            return entity;
        }


    }
}