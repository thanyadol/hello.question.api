using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace surflex.netcore22.Repositories
{
    /*
     * to controll the user activities
     *
     */

    public interface IAreaRepository
    {
        Task<IEnumerable<Area>> ListAsync();

        //Task<Area> GetRecentlyAsync(string id, string type);

        Task<Area> GetAsync(string id);
        Task<Area> CreateAsync(Area area);
        Task<Area> UpdateAsync(Area area);
        //Task<Area> DeleteAsync(string id);
    }

    public class AreaRepository : IAreaRepository
    {

        private readonly NorthwindContext _context;
        public AreaRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<Area> CreateAsync(Area area)
        {

            var entity = await _context.Areas.AddAsync(area);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<Area> DeleteAsync(string id)
        {
            //var deletedEntity = await _AreaEntityTableStorageRepository.DeleteOneAsync(AreaName, AreaKey);
            var entity = await _context.Areas.FindAsync(id);
            _context.Areas.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<Area>> ListAsync()
        {

            var entities = await _context.Areas.ToListAsync();
            //var Area = _context.Areas.ToList();
            return entities;
        }

        public async Task<Area> UpdateAsync(Area area)
        {

            var entity = await _context.Areas.FindAsync(area.Id);

            // area.By = "admin";
            // area.Date = Utility.CurrentSEAsiaStandardTime();

            _context.Areas.Update(area);

            _context.SaveChanges();
            return entity;
        }

        public async Task<Area> GetAsync(string id)
        {
            var entity = await _context.Areas.FindAsync(id);
            return entity;
        }


    }
}