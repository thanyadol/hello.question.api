using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace surflex.netcore22.Repositories
{
    public interface IWellScenarioRepository
    {
        Task<IEnumerable<PresetWellScenario>> ListAsync();

        //Task<WellScenario> GetRecentlyAsync(string id, string type);

        Task<PresetWellScenario> GetAsync(Guid id);
        Task<PresetWellScenario> CreateAsync(PresetWellScenario scenario);
        Task<PresetWellScenario> UpdateAsync(PresetWellScenario scenario);
        //Task<WellScenario> DeleteAsync(string id);
    }

    /*
     * to controll the user activities
     *
     */

    public class WellScenarioRepository : IWellScenarioRepository
    {

        private readonly NorthwindContext _context;
        public WellScenarioRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<PresetWellScenario> CreateAsync(PresetWellScenario scenario)
        {

            var entity = await _context.PresetWellScenarios.AddAsync(scenario);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<PresetWellScenario> DeleteAsync(string id)
        {
            //var deletedEntity = await _ScenarioEntityTableStorageRepository.DeleteOneAsync(ScenarioName, ScenarioKey);
            var entity = await _context.PresetWellScenarios.FindAsync(id);
            _context.PresetWellScenarios.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<PresetWellScenario>> ListAsync()
        {

            var entities = await _context.PresetWellScenarios.ToListAsync();
            //var WellScenario = _context.WellScenarios.ToList();
            return entities;
        }

        public async Task<PresetWellScenario> UpdateAsync(PresetWellScenario scenario)
        {

            var entity = await _context.PresetWellScenarios.FindAsync(scenario.Id);

            // scenario.By = "admin";
            // scenario.Date = Utility.CurrentSEAsiaStandardTime();

            _context.PresetWellScenarios.Update(scenario);

            _context.SaveChanges();
            return entity;
        }

        public async Task<PresetWellScenario> GetAsync(Guid id)
        {
            var entity = await _context.PresetWellScenarios.FindAsync(id);
            return entity;
        }


    }
}