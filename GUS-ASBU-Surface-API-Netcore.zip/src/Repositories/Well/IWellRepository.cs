using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;
using surflex.netcore22.APIs.Model;
using surflex.netcore22.APIs.Gateway;

namespace surflex.netcore22.Repositories
{
    public interface IWellRepository
    {
        Task<IEnumerable<Well>> ListAsync();

        //Task<WellJobHistory> GetPlannedJobAsync(string id);

        //Task<IEnumerable<WellProductive>> ListPlannedProjectAsync(string id);

        Task<Well> GetAsync(string id);

        Task<Well> CreateAsync(Well Well);
        Task<Well> UpdateAsync(Well Well);
        Task<Well> DeleteAsync(string id);

        //Task<WellReserve> CreateWellReserveAsync(WellReserve well);
        // Task<WellReserve> GetRecentlyWellReserveAsync(string id);
        // Task<WellProductiveAsync> GetProductiveAsync(string name);

        //Task<bool> ListProductiveAsync(IEnumerable<WellPlannedAsync> wells);
        //    Task<IEnumerable<WellProductiveAsync>> ListProductiveAsync();





    }
}