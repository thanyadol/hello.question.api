using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

using Serilog;
using Microsoft.EntityFrameworkCore;
using surflex.netcore22.Extensions;

namespace surflex.netcore22.Repositories
{
    public interface IWellUndrilledRepository
    {
        Task<IEnumerable<WellUndrilled>> ListAsync();

        //Task<WellUndrilled> GetRecentlyAsync(string id, string type);

        Task<WellUndrilled> GetAsync(Guid id);
        Task<WellUndrilled> CreateAsync(WellUndrilled summ);
        Task<WellUndrilled> UpdateAsync(WellUndrilled summ);
        Task<WellUndrilled> DeleteAsync(Guid id);

        Task<WellUndrilled> GetRecentlyAsync(string id, string userid);
    }


    public class WellUndrilledRepository : IWellUndrilledRepository
    {
        // private readonly string SAVE = "SAVED";
        // private readonly string UPDATE = "UPDATED";
        // private readonly string PUBLISH = "PUBLISHED";

        private readonly NorthwindContext _context;
        public WellUndrilledRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<WellUndrilled> CreateAsync(WellUndrilled summ)
        {

            var entity = await _context.WellUndrilleds.AddAsync(summ);


            try
            {
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex.InnerException;
            }


            return entity.Entity;
        }

        public async Task<WellUndrilled> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _PropertiesEntityTableStorageRepository.DeleteOneAsync(PropertiesName, PropertiesKey);
            var entity = await _context.WellUndrilleds.FindAsync(id);
            _context.WellUndrilleds.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<WellUndrilled>> ListAsync()
        {

            var entities = await _context.WellUndrilleds.ToListAsync();
            return entities;
        }

        public async Task<WellUndrilled> UpdateAsync(WellUndrilled summ)
        {

            var entity = await _context.WellUndrilleds.FindAsync(summ.Id);

            // summ.By = "admin";
            // summ.Date = Utility.CurrentSEAsiaStandardTime();

            _context.WellUndrilleds.Update(summ);

            _context.SaveChanges();
            return entity;
        }

        public async Task<WellUndrilled> GetAsync(Guid id)
        {
            var entity = await _context.WellUndrilleds.FindAsync(id);
            return entity;
        }

        //
        // Summary:
        //     get recent saved sand by user and well
        //
        // Returns:
        //     Models.Entity.WellUndrilled object
        //
        // Type parameters:
        //   id:
        //     well id
        //   userid
        //     http request user id 
        //
        public async Task<WellUndrilled> GetRecentlyAsync(string id, string userid)
        {
            var entity = await (from p in _context.Wells
                                join ps in _context.WellSpaces on p.Id equals ps.WellId
                                join pw in _context.WellUndrilleds on ps.Id equals pw.WellSpaceId
                                join a in _context.WellActivities on ps.Id equals a.WellSpaceId
                                where (
                                    (p.Id == id && a.By == userid && (a.Action == ActivityAction.SAVED.GetDescription() || a.Action == ActivityAction.UPDATED.GetDescription()))
                                || (p.Id == id && a.Action == ActivityAction.PUBLISHED.GetDescription())
                                )

                                orderby a.Date descending
                                select new WellUndrilled()
                                {
                                    Id = pw.Id,
                                    WellSpaceId = ps.Id,

                                    WellId = p.Id,
                                    WellName = p.Name,

                                    By = a.By,

                                    Rev = pw.Rev,
                                    Key = pw.Key,

                                    // Created = ps.Created,

                                    StartDate = pw.StartDate,
                                    FinishDate = pw.FinishDate,

                                    UndrilledMethod = pw.UndrilledMethod,
                                    GasInMMScf = pw.GasInMMScf,
                                    LiquidInMBOE = pw.LiquidInMBOE,

                                    TotalInMBOE = pw.TotalInMBOE,
                                    IsCalculatedReserve = pw.IsCalculatedReserve,


                                    UpdatedDate = pw.UpdatedDate,
                                    Datasource = pw.Datasource,



                                    // Created = ps.Created,

                                    CalculatedTimestamp = pw.CalculatedTimestamp,
                                    CalculatedWellReserve = pw.CalculatedWellReserve,

                                    ActivityType = a.Action,
                                    ActivityDate = a.Date

                                }).ToListAsync();

            return entity.FirstOrDefault();
        }


    }
}