using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace surflex.netcore22.Repositories
{
    public interface IWellActivityRepository
    {
        Task<IEnumerable<WellActivity>> ListAsync();

        Task<WellActivity> GetRecentlyAsync(Guid id, string action);

        Task<WellActivity> GetAsync(Guid id);
        Task<WellActivity> CreateAsync(WellActivity activity);
        Task<WellActivity> UpdateAsync(WellActivity activity);
        //Task<WellActivity> DeleteAsync(string id);
    }
    /*
     * to controll the user activities
     *
     */

    public class WellActivityRepository : IWellActivityRepository
    {

        private readonly NorthwindContext _context;
        public WellActivityRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<WellActivity> CreateAsync(WellActivity activity)
        {

            var entity = await _context.WellActivities.AddAsync(activity);

            try
            {
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }


            return entity.Entity;
        }

        public async Task<WellActivity> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _WellActivityEntityTableStorageRepository.DeleteOneAsync(WellActivityName, WellActivityKey);
            var entity = await _context.WellActivities.FindAsync(id);
            _context.WellActivities.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<WellActivity>> ListAsync()
        {

            var entities = await _context.WellActivities.ToListAsync();
            //var WellActivity = _context.WellActivities.ToList();
            return entities;
        }

        public async Task<WellActivity> UpdateAsync(WellActivity activity)
        {

            var entity = await _context.WellActivities.FindAsync(activity.Id);

            // activity.By = "admin";
            // activity.Date = Utility.CurrentSEAsiaStandardTime();

            _context.WellActivities.Update(activity);

            _context.SaveChanges();
            return entity;
        }

        public async Task<WellActivity> GetRecentlyAsync(Guid id, string type)
        {
            var entities = await _context.WellActivities.Where(c => c.WellSpaceId == id && c.Discriminator == type)
                                .OrderByDescending(c => c.Date).FirstOrDefaultAsync();

            return entities;
        }

        public async Task<WellActivity> GetAsync(Guid id)
        {
            var entity = await _context.WellActivities.FindAsync(id);
            return entity;
        }


    }
}