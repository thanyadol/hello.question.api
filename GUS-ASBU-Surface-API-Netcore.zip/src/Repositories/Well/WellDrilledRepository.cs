using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

using Serilog;
using Microsoft.EntityFrameworkCore;
using surflex.netcore22.Extensions;

namespace surflex.netcore22.Repositories
{
    public interface IWellDrilledRepository
    {
        Task<IEnumerable<WellDrilled>> ListAsync();

        //Task<WellDrilled> GetRecentlyAsync(string id, string type);

        Task<WellDrilled> GetAsync(Guid id);
        Task<WellDrilled> CreateAsync(WellDrilled drilled);
        Task<WellDrilled> UpdateAsync(WellDrilled drilled);
        Task<WellDrilled> DeleteAsync(Guid id);

        Task<WellDrilled> GetRecentlyAsync(string id, string userid);
    }


    public class WellDrilledRepository : IWellDrilledRepository
    {
        // private readonly string SAVE = "SAVED";
        // private readonly string UPDATE = "UPDATED";
        // private readonly string PUBLISH = "PUBLISHED";

        private readonly NorthwindContext _context;
        public WellDrilledRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<WellDrilled> CreateAsync(WellDrilled drilled)
        {

            var entity = await _context.WellDrilleds.AddAsync(drilled);

            try
            {
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex.InnerException;
            }

            return entity.Entity;
        }

        public async Task<WellDrilled> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _PropertiesEntityTableStorageRepository.DeleteOneAsync(PropertiesName, PropertiesKey);
            var entity = await _context.WellDrilleds.FindAsync(id);
            _context.WellDrilleds.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<WellDrilled>> ListAsync()
        {

            var entities = await _context.WellDrilleds.ToListAsync();
            return entities;
        }

        public async Task<WellDrilled> UpdateAsync(WellDrilled drilled)
        {

            var entity = await _context.WellDrilleds.FindAsync(drilled.Id);

            // drilled.By = "admin";
            // drilled.Date = Utility.CurrentSEAsiaStandardTime();

            _context.WellDrilleds.Update(drilled);

            _context.SaveChanges();
            return entity;
        }

        public async Task<WellDrilled> GetAsync(Guid id)
        {
            var entity = await _context.WellDrilleds.FindAsync(id);
            return entity;
        }

        //
        // Summary:
        //     get recent saved sand by user and well
        //
        // Returns:
        //     Models.Entity.WellDrilled object
        //
        // Type parameters:
        //   id:
        //     well id
        //   userid
        //     http request user id 
        //
        public async Task<WellDrilled> GetRecentlyAsync(string id, string userid)
        {
            var entity = await (from p in _context.Wells
                                join ps in _context.WellSpaces on p.Id equals ps.WellId
                                join pw in _context.WellDrilleds on ps.Id equals pw.WellSpaceId
                                join a in _context.WellActivities on ps.Id equals a.WellSpaceId
                                where (
                                    (p.Id == id && a.By == userid && (a.Action == ActivityAction.SAVED.GetDescription()
                                            || a.Action == ActivityAction.UPDATED.GetDescription()))
                                || (p.Id == id && a.Action == ActivityAction.PUBLISHED.GetDescription())
                                )

                                orderby a.Date descending
                                select new WellDrilled()
                                {
                                    Id = pw.Id,
                                    WellSpaceId = ps.Id,

                                    WellId = p.Id,
                                    WellName = p.Name,

                                    By = a.By,

                                    Rev = pw.Rev,
                                    Key = pw.Key,

                                    // Created = ps.Created,

                                    CalculatedTimestamp = pw.CalculatedTimestamp,
                                    CalculatedWellReserve = pw.CalculatedWellReserve,
                                    TotalCalculateRecord = pw.TotalCalculateRecord,
                                    CompleteCalculatedRecord = pw.CompleteCalculatedRecord,

                                    //header
                                    BcCompressionRatio = pw.BcCompressionRatio,
                                    BcPos = pw.BcPos,
                                    WellType = pw.WellType,
                                    GasPipelinePressureCoeff = pw.GasPipelinePressureCoeff,
                                    OilPipelinePressureCoeff = pw.OilPipelinePressureCoeff,
                                    PipelinePressure = pw.PipelinePressure,

                                    GOR = pw.GOR,
                                    CGR = pw.CGR,


                                    SORUpdatedDate = pw.SORUpdatedDate,
                                    Datasource = pw.Datasource,


                                    StartDate = pw.StartDate,
                                    FinishDate = pw.FinishDate,

                                    ActivityType = a.Action,
                                    ActivityDate = a.Date

                                }).ToListAsync();

            return entity.FirstOrDefault(); ;
        }


    }
}