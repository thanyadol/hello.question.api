using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

using Serilog;
using Microsoft.EntityFrameworkCore;

namespace surflex.netcore22.Repositories
{
    public interface IWellPropertiesRepository
    {
        Task<IEnumerable<WellProperties>> ListAsync();

        //Task<WellProperties> GetRecentlyAsync(string id, string type);

        Task<WellProperties> GetAsync(string id);
        Task<WellProperties> CreateAsync(WellProperties properties);
        Task<WellProperties> UpdateAsync(WellProperties properties);
        Task<WellProperties> DeleteAsync(string id);

        Task<IEnumerable<WellProperties>> CreateRangeAsync(IEnumerable<WellProperties> properties);
    }


    public class WellPropertiesRepository : IWellPropertiesRepository
    {

        private readonly NorthwindContext _context;
        public WellPropertiesRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<WellProperties> CreateAsync(WellProperties properties)
        {

            var entity = await _context.WellPropertieses.AddAsync(properties);
            _context.SaveChanges();

            return entity.Entity;
        }


        public async Task<IEnumerable<WellProperties>> CreateRangeAsync(IEnumerable<WellProperties> properties)
        {
            await _context.WellPropertieses.AddRangeAsync(properties);
            _context.SaveChanges();

            return properties;
        }

        public async Task<WellProperties> DeleteAsync(string id)
        {
            //var deletedEntity = await _PropertiesEntityTableStorageRepository.DeleteOneAsync(PropertiesName, PropertiesKey);
            var entity = await _context.WellPropertieses.FindAsync(id);
            _context.WellPropertieses.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<WellProperties>> ListAsync()
        {

            //var entities = await _context.WellPropertieses.ToListAsync();

            var entities = await (from w in _context.Wells
                                  join p in _context.WellPropertieses on w.Id equals p.WellId
                                  //where p.Id == id
                                  select new WellProperties
                                  {
                                      Id = p.Id,
                                      WellId = w.Id,
                                      ProjectWellId = p.ProjectWellId,

                                      Name = w.Name,
                                      FaultBlock = p.FaultBlock,
                                      BatchNumber = p.BatchNumber,
                                      DrillingOrder = p.DrillingOrder,

                                      ChartOrder = p.ChartOrder,
                                      Type = p.Type,
                                      By = p.By,

                                      IsIncludeToCalculated = p.IsIncludeToCalculated,
                                      Created = p.Created,

                                      Description = p.Description,

                                      // Status = w.Status,
                                      Datasource = p.Datasource,
                                      DatasourceDate = p.DatasourceDate


                                  }).ToListAsync();

            return entities;
        }

        public async Task<WellProperties> UpdateAsync(WellProperties properties)
        {

            var entity = await _context.WellPropertieses.FindAsync(properties.Id);

            // properties.By = "admin";
            // properties.Date = Utility.CurrentSEAsiaStandardTime();

            _context.WellPropertieses.Update(properties);

            _context.SaveChanges();
            return entity;
        }

        public async Task<WellProperties> GetAsync(string id)
        {
            var entity = await _context.WellPropertieses.FindAsync(id);
            return entity;
        }


    }
}