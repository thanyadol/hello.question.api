using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

using Serilog;
using Microsoft.EntityFrameworkCore;

namespace surflex.netcore22.Repositories
{
    public interface IWellSpaceRepository
    {
        Task<IEnumerable<WellSpace>> ListAsync();

        //Task<WellSpace> GetRecentlyAsync(string id, string type);

        Task<WellSpace> GetAsync(Guid id);
        Task<WellSpace> CreateAsync(WellSpace space);
        Task<WellSpace> UpdateAsync(WellSpace space);
        Task<WellSpace> DeleteAsync(Guid id);
    }


    public class WellSpaceRepository : IWellSpaceRepository
    {

        private readonly NorthwindContext _context;
        public WellSpaceRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<WellSpace> CreateAsync(WellSpace space)
        {

            var entity = await _context.WellSpaces.AddAsync(space);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<WellSpace> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _PropertiesEntityTableStorageRepository.DeleteOneAsync(PropertiesName, PropertiesKey);
            var entity = await _context.WellSpaces.FindAsync(id);
            _context.WellSpaces.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<WellSpace>> ListAsync()
        {

            var entities = await _context.WellSpaces.ToListAsync();
            return entities;
        }

        public async Task<WellSpace> UpdateAsync(WellSpace space)
        {

            var entity = await _context.WellSpaces.FindAsync(space.Id);

            // space.By = "admin";
            // space.Date = Utility.CurrentSEAsiaStandardTime();

            _context.WellSpaces.Update(space);

            _context.SaveChanges();
            return entity;
        }

        public async Task<WellSpace> GetAsync(Guid id)
        {
            var entity = await _context.WellSpaces.FindAsync(id);
            return entity;
        }


    }
}