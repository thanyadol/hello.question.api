using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

//apis
using surflex.netcore22.APIs;
using surflex.netcore22.APIs.Model;
using surflex.netcore22.APIs.Gateway;

namespace surflex.netcore22.Repositories
{
    public class WellRepository : IWellRepository
    {
        //private readonly IWellMappingService _WellMappingService;
        //private readonly ITableStorageRepository<WellEntity> _WellEntityTableStorageRepository;

        private readonly NorthwindContext _context;
        //private readonly IEntityService _entityService;
        // private readonly IClientService _clientService;
        public WellRepository(NorthwindContext context) //, IEntityService entityService, IClientService clientService) //IWellMappingService WellMappingService, ITableStorageRepository<WellEntity> WellEntityTableStorageRepository)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            //_entityService = entityService ?? throw new ArgumentNullException(nameof(entityService));
            // _clientService = clientService ?? throw new ArgumentNullException(nameof(clientService));

            //_WellMappingService = WellMappingService ?? throw new ArgumentNullException(nameof(WellMappingService));
            //_WellEntityTableStorageRepository = WellEntityTableStorageRepository ?? throw new ArgumentNullException(nameof(WellEntityTableStorageRepository));

            // Log.Logger = new LoggerConfiguration()
            // .WriteTo.Console()
            // .CreateLogger();

        }

        public async Task<Well> CreateAsync(Well well)
        {
            //var entityToCreate = _WellMappingService.Map(Well);
            //var createdEntity = await _WellEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createWell = _WellMappingService.Map(createdEntity);

            var createWell = await _context.Wells.AddAsync(well);
            _context.SaveChanges();

            return createWell.Entity;
        }

        public async Task<Well> DeleteAsync(string id)
        {
            //var deletedEntity = await _WellEntityTableStorageRepository.DeleteOneAsync(wellName, WellKey);
            var deletedWell = await _context.Wells.FindAsync(id);
            _context.Wells.Remove(deletedWell);
            _context.SaveChanges();
            return deletedWell;
        }

        public async Task<IEnumerable<Well>> ListAsync()
        {
            //var entities = await _WellEntityTableStorageRepository.ReadAllAsync();
            //var Well = _WellMappingService.Map(entities);
            //return Well;

            var entities = await _context.Wells.ToListAsync();
            //var Well = _context.Wells.ToList();
            return entities;
        }

        /*   public async Task<IEnumerable<WellPlanned>> ListPlannedProjectAsync(string id)
          {
              var entities = await (from p in _context.Projects
                                    join w in _context.Wells on p.Id equals w.ProjectId
                                    join j in _context.Jobs on w.Id equals j.WellId
                                    where p.Id == id
                                    select new WellPlanned
                                    {
                                        Id = w.Id,
                                        Name = w.Name,
                                        Status = j.Status,

                                        ProjectId = p.Id,
                                        // UIDMId = w.UIDMReferenceId,
                                        RLLCPId = w.RLLCPReferenceId,

                                        //JobId = j.Id

                                    }).ToListAsync();

              return entities;
          }*/


        /* public async Task<WellReserve> CreateWellReserveAsync(WellReserve well)
        {
            var created = await _context.WellReserves.AddAsync(well);
            _context.SaveChanges();

            return created.Entity;
        }

        public async Task<WellReserve> GetRecentlyWellReserveAsync(string id)
        {
            var entity = await _context.WellReserves.Where(c => c.SandId == id).OrderByDescending(c => c.CreatedDate).FirstOrDefaultAsync();
            return entity;
        }*/


        public async Task<Well> UpdateAsync(Well Well)
        {
            //var entityToUpdate = _WellMappingService.Map(Well);
            //var updatedEntity = await _WellEntityTableStorageRepository.InsertOrMergeAsync(entityToUpdate);
            //var deletedEntity = await _WellEntityTableStorageRepository.DeleteOneAsync(wellName, WellKey);

            var updateWell = await _context.Wells.FindAsync(Well.Id);
            _context.Wells.Update(Well);

            _context.SaveChanges();

            /* try
            {
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.Information(ex.Message);
            }*/

            return updateWell;
        }

        public async Task<Well> GetAsync(string id)
        {
            var well = await _context.Wells.FindAsync(id);
            return well;
        }




        /* public async Task<Sand> GetRecentlySandAsync(string name)
        {
            try
            {


                var well = await this._context.Wells.Where(c => c.Name == name).FirstOrDefaultAsync(); ;
                var sand = await _context.Sands.Where(c => c.WellId == well.Id).OrderByDescending(c => c.Created).FirstOrDefaultAsync();
                return sand;
            }
            catch (Exception)
            {
                return null;
            }
        }*/



    }
}