using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Serilog;
using surflex.netcore22.Exceptions;
using surflex.netcore22.Helpers;
using surflex.netcore22.Models;
using surflex.netcore22.Models.Constants;
using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace surflex.netcore22.Repositories
{
    public interface IDecisionRepository
    {
        void BeginTransaction();

        void Commit();

        void Rollback();

        Task<PresetWellScenario> GetTemplateTreeAsync(Guid id);

        Task<List<PresetWellScenarioNode>> GetTemplateNodesAsync(Guid id);

        Task<List<PresetWellScenarioEdge>> GetTemplateEdgesAsync(Guid id);

        Task<PresetWellScenario> UpdateTemplateTreeAsync(PresetWellScenarioParams param);

        Task CreateTemplateNodesAndEdgesAsync(IEnumerable<PresetWellScenarioNode> nodes, IEnumerable<PresetWellScenarioEdge> edges);

        Task DeleteTemplateNodesAndEdgesAsync(Guid id);

        Task<IEnumerable<WellScenarioTab>> GetScenarioTabListAsync(string wellName, string by);

        Task<WellScenarioTab> GetLatestTreeAsync(Guid tabId, string by);

        Task<bool> CheckHasPublishedAsync(WellScenarioTab tab);

        Task<List<WellScenarioNode>> GetNodesAsync(Guid id);

        Task<List<WellScenarioEdge>> GetEdgesAsync(Guid id);

        Task<WellScenario> InsertTreeAsync(WellScenarioParams param);

        Task UpdateTreeAsync(WellScenario wellScenario);

        Task CreateNodesAndEdgesAsync(IEnumerable<WellScenarioNode> nodes, IEnumerable<WellScenarioEdge> edges);

        Task DeleteNodesAndEdgesAsync(Guid id);

        Task<IEnumerable<DecisionOption>> ListDecisionOptionsAsync(Guid id);

        Task<IEnumerable<DecisionOptionNode>> ListDecisionNodesAsync(Guid id);

        Task<IEnumerable<DecisionOptionNode>> ListDecisionOptionNodesAsync(IEnumerable<DecisionOption> entities);

        Task<DecisionResultGroup> GetDecisionResultAsync(Guid revId);
        
        Task<DecisionResultGroup> InsertDecisionResultGroupAsync(DecisionResultDto decision);

        Task InsertDecisionResultsAsync(IEnumerable<DecisionResultOptionDto> decisionOptions, DecisionResultGroup decisionGroup);

        Task<DecisionOption> InsertDecisionOptionAsync(WellScenario scenario, DecisionResultOptionDto option);

        Task<DecisionOptionNode> InsertDecisionOptionNodeAsync(DecisionOption option, DecisionResultOptionNodeDto node, DecisionOptionNode parent);

        Task RemoveScenarioTabAsync(Guid tabId, string by);

        Task<WellScenarioTab> InsertScenarioTabAsync(WellScenarioParams param);

        Task<WellScenarioTab> InsertScenarioTabAsync(DecisionResultDto decision);
    }

    public class DecisionRepository : IDecisionRepository, IDisposable
    {
        private readonly NorthwindContext _context;

        private readonly IMapper _mapper;

        private IDbContextTransaction _transaction;

        public DecisionRepository(NorthwindContext context, IMapper mapper)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();
        }

        public void BeginTransaction()
        {
            _transaction = _context.Database.BeginTransaction();
        }

        public void Commit()
        {
            _transaction?.Commit();
        }

        public void Rollback()
        {
            _transaction?.Rollback();
        }

        public void Dispose()
        {
            _transaction?.Dispose();
            _context.Dispose();
        }

        public async Task<PresetWellScenario> GetTemplateTreeAsync(Guid id)
        {
            var presetWellScenario = await _context.PresetWellScenarios.FindAsync(id);
            return presetWellScenario;
        }

        public async Task<List<PresetWellScenarioNode>> GetTemplateNodesAsync(Guid id)
        {
            return await _context.PresetDecisionNodes.Where(node => node.ResourceId == id).ToListAsync();
        }

        public async Task<List<PresetWellScenarioEdge>> GetTemplateEdgesAsync(Guid id)
        {
            var presetDecisionEdges = await (from edge in _context.PresetDecisionEdges
                                             from node in _context.PresetDecisionNodes
                                             where (node.Id == edge.FromId || node.Id == edge.ToId) && node.ResourceId == id
                                             select edge)
                                       .Distinct()
                                       .ToListAsync();

            return presetDecisionEdges;
        }

        public async Task<PresetWellScenario> UpdateTemplateTreeAsync(PresetWellScenarioParams param)
        {
            var id = param.Id ?? throw new ArgumentException(nameof(param.Id));

            var currentTime = Utility.CurrentSEAsiaStandardTime();

            var presetWellScenario = await GetTemplateTreeAsync(id);

            if (presetWellScenario == null)
            {
                throw new WellScenarioNotFoundException(id.ToString());
            }

            presetWellScenario.Name = param.Name;
            presetWellScenario.By = param.By;
            presetWellScenario.Updated = currentTime;
            param.Updated = currentTime;

            _context.SaveChanges();

            return presetWellScenario;
        }

        public async Task CreateTemplateNodesAndEdgesAsync(IEnumerable<PresetWellScenarioNode> nodes, IEnumerable<PresetWellScenarioEdge> edges)
        {
            await Task.Delay(0);
            _context.PresetDecisionNodes.AddRange(nodes);
            _context.PresetDecisionEdges.AddRange(edges);
            _context.SaveChanges();
        }

        public async Task DeleteTemplateNodesAndEdgesAsync(Guid id)
        {
            var nodes = await GetTemplateNodesAsync(id);
            var edges = await GetTemplateEdgesAsync(id);

            if (edges.Count > 0)
            {
                _context.RemoveRange(edges);
            }

            if (nodes.Count > 0)
            {
                _context.RemoveRange(nodes);
            }

            _context.SaveChanges();
        }

        public async Task<IEnumerable<WellScenarioTab>> GetScenarioTabListAsync(string wellName, string by)
        {
            if (string.IsNullOrEmpty(wellName)) throw new ArgumentNullException(nameof(wellName));

            return await _context.WellScenarioTabs
                .Include(x => x.WellScenario)
                .ThenInclude(x => x.Resource)
                .Where(x => x.WellName == wellName &&
                    ((x.By == by && x.Status == GlobalConstants.STATUS_SAVED) ||
                        x.Status == GlobalConstants.STATUS_PUBLISHED) && !x.IsDeleted)
                .GroupBy(x => x.TabId)
                .Select(grouped => grouped.OrderByDescending(x => x.Created).FirstOrDefault())
                .OrderBy(x => x.Status)
                .ThenBy(x => x.Created)
                .ToListAsync();
        }

        public async Task<WellScenarioTab> GetLatestTreeAsync(Guid tabId, string by)
        {
            var myVersion = await _context.WellScenarioTabs
                                .Include(x => x.WellScenario)
                                .ThenInclude(x => x.Resource)
                                .Where(x => x.TabId == tabId && x.By == by &&
                                    (x.Status == GlobalConstants.STATUS_SAVED ||
                                    x.Status == GlobalConstants.STATUS_PUBLISHED) &&
                                    !x.IsDeleted
                                ).OrderByDescending(x => x.Created).FirstOrDefaultAsync();

            var wellScenario = await _context.WellScenarioTabs
                                .Include(x => x.WellScenario)
                                .ThenInclude(x => x.Resource)
                                .Where(x => x.TabId == tabId && x.Status == GlobalConstants.STATUS_PUBLISHED && !x.IsDeleted)
                                .OrderByDescending(x => x.Updated).FirstOrDefaultAsync();

            if ((myVersion != null && wellScenario != null && myVersion.Created >= wellScenario.Created) ||
                (myVersion != null && wellScenario == null))
            {
                return myVersion;
            }
            else
            {
                return wellScenario;
            }
        }

        public async Task<bool> CheckHasPublishedAsync(WellScenarioTab tab)
        {
            return await _context.WellScenarioTabs
                .Where(x => x.TabId == tab.TabId && x.Created < tab.Created &&
                    !x.IsDeleted && x.Status == GlobalConstants.STATUS_PUBLISHED)
                .CountAsync() > 0;
        }

        public async Task<List<WellScenarioNode>> GetNodesAsync(Guid id)
        {
            return await _context.DecisionNodes.Where(node => node.ResourceId == id).ToListAsync();
        }

        public async Task<List<WellScenarioEdge>> GetEdgesAsync(Guid id)
        {
            var decisionEdges = await (from edge in _context.DecisionEdges
                                       from node in _context.DecisionNodes
                                       where (node.Id == edge.FromId || node.Id == edge.ToId) && node.ResourceId == id
                                       select edge)
                                       .Distinct()
                                       .ToListAsync();

            return decisionEdges;
        }

        public async Task<WellScenario> InsertTreeAsync(WellScenarioParams param)
        {
            var id = Guid.NewGuid();
            var currentTime = Utility.CurrentSEAsiaStandardTime();

            param.Id = id;
            param.Created = currentTime;
            param.Updated = currentTime;

            var wellScenario = _mapper.Map<WellScenario>(param);
            
            _context.Add(wellScenario);
            await _context.SaveChangesAsync();

            return wellScenario;
        }
        
        public async Task UpdateTreeAsync(WellScenario wellScenario)
        {
            _context.Update(wellScenario);

            await _context.SaveChangesAsync();
        }

        public async Task DeleteNodesAndEdgesAsync(Guid id)
        {
            var nodes = await GetNodesAsync(id);
            var edges = await GetEdgesAsync(id);

            _context.RemoveRange(edges);
            _context.RemoveRange(nodes);

            _context.SaveChanges();
        }

        public async Task CreateNodesAndEdgesAsync(IEnumerable<WellScenarioNode> nodes, IEnumerable<WellScenarioEdge> edges)
        {
            _context.DecisionNodes.AddRange(nodes);
            _context.DecisionEdges.AddRange(edges);
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<DecisionOption>> ListDecisionOptionsAsync(Guid id)
        {
            return await _context.DecisionOptions.Where(x => x.WellScenarioId == id).ToListAsync();
        }

        public async Task<IEnumerable<DecisionOptionNode>> ListDecisionOptionNodesAsync(IEnumerable<DecisionOption> entities)
        {
            var entityIds = entities.Select(x => x.Id);

            return await _context.DecisionOptionNodes.Where(x => entityIds.Contains(x.DecisionOptionId)).ToListAsync();
        }

        public async Task<IEnumerable<DecisionOptionNode>> ListDecisionNodesAsync(Guid id)
        {
            var entities = await ListDecisionOptionsAsync(id);
            var entityIds = entities.Select(x => x.Id);

            return await _context.DecisionOptionNodes.Where(x => entityIds.Contains(x.DecisionOptionId)).ToListAsync();
        }

        public async Task<DecisionResultGroup> GetDecisionResultAsync(Guid revId)
        {
            return await _context.DecisionResultGroups.Include(x => x.Decisions)
                .Where(x => x.WellScenarioRevId == revId)
                .OrderByDescending(x => x.Created).FirstOrDefaultAsync();
        }

        public async Task<DecisionResultGroup> InsertDecisionResultGroupAsync(DecisionResultDto decision)
        {
            var wellScenarioId = decision.WellScenarioId ?? throw new ArgumentNullException(nameof(decision.WellScenarioId));
            var revId = decision.RevId ?? throw new ArgumentNullException(nameof(decision.RevId));

            var currentTime = Utility.CurrentSEAsiaStandardTime();

            // Insert decision group
            var decisionGroup = new DecisionResultGroup()
            {
                Id = Guid.NewGuid(),
                WellScenarioId = wellScenarioId,
                WellScenarioRevId = revId,
                Remark = decision.Remark,
                By = decision.By,
                Created = currentTime,
            };

            await _context.AddAsync(decisionGroup);
            await _context.SaveChangesAsync();

            // Update model
            decision.Id = decisionGroup.Id;
            decision.Created = decisionGroup.Created;

            return decisionGroup;
        }

        public async Task InsertDecisionResultsAsync(IEnumerable<DecisionResultOptionDto> decisionOptions,
            DecisionResultGroup decisionGroup)
        {
            // Insert decision options
            foreach (var option in decisionOptions)
            {
                var entity = new DecisionResult()
                {
                    Id = Guid.NewGuid(),
                    DecisionGroupId = decisionGroup.Id,
                    DecisionOptionId = option.Id,
                    IsChosen = option.IsChosen,
                    Remark = option.Remark,
                    Created = decisionGroup.Created,
                };

                await _context.AddAsync(entity);
            }

            await _context.SaveChangesAsync();
        }

        public async Task<DecisionOption> InsertDecisionOptionAsync(WellScenario scenario, DecisionResultOptionDto option)
        {
            var entity = new DecisionOption()
            {
                Id = Guid.NewGuid(),
                WellScenarioId = scenario.Id,
                Order = option.Order,
                Inv = option.Inv,
                Npv = option.Npv,
                Dpi = option.Dpi,
                TotalBranchCost = option.TotalBranchCost,
                Created = scenario.Created,
            };

            await _context.AddAsync(entity);
            await _context.SaveChangesAsync();

            return entity;
        }

        public async Task<DecisionOptionNode> InsertDecisionOptionNodeAsync(DecisionOption option, DecisionResultOptionNodeDto node, DecisionOptionNode parent = null)
        {
            var entity = new DecisionOptionNode()
            {
                Id = Guid.NewGuid(),
                Name = node.Name,
                ParentId = parent?.Id,
                DecisionOptionId = option.Id,
                Inv = node.Inv,
                Npv = node.Npv,
                Dpi = node.Dpi,
                TotalBranchCost = node.TotalBranchCost,
                Created = option.Created,
            };

            await _context.AddAsync(entity);
            await _context.SaveChangesAsync();

            return entity;
        }
        
        public async Task RemoveScenarioTabAsync(Guid tabId, string by)
        {
            var mySavedVersions = await _context.WellScenarioTabs.Where(x => x.TabId == tabId && !x.IsDeleted && x.Status == GlobalConstants.STATUS_SAVED && x.By == by)
                .OrderByDescending(x => x.Created)
                .ToListAsync();

            var latestPublishedVersion = await _context.WellScenarioTabs.Where(x => x.TabId == tabId && !x.IsDeleted && x.Status == GlobalConstants.STATUS_PUBLISHED)
                .OrderByDescending(x => x.Created)
                .FirstOrDefaultAsync();

            List<WellScenarioTab> entities = null;

            if (mySavedVersions?.Count > 0 && mySavedVersions[0].Created > latestPublishedVersion?.Created)
            {
                // remove only my save versions
                entities = mySavedVersions;
            }
            else
            {
                // remove all versions
                entities = await _context.WellScenarioTabs.Where(x => x.TabId == tabId && !x.IsDeleted)
                    .OrderByDescending(x => x.Created)
                    .ToListAsync();
            }

            entities?.ForEach(x => x.IsDeleted = true);

            await _context.SaveChangesAsync();
        }

        public async Task<WellScenarioTab> InsertScenarioTabAsync(WellScenarioParams param)
        {
            param.MasterVersionId = param.RevId ?? null;
            param.RevId = Guid.NewGuid();
            param.TabId = param.TabId ?? Guid.NewGuid();
            param.Status = GlobalConstants.STATUS_SAVED;

            var entity = _mapper.Map<WellScenarioTab>(param);
            entity.IsDeleted = false;

            await _context.AddAsync(entity);
            await _context.SaveChangesAsync();

            return entity;
        }

        public async Task<WellScenarioTab> InsertScenarioTabAsync(DecisionResultDto decision)
        {
            var currentTime = Utility.CurrentSEAsiaStandardTime();

            var entity = _mapper.Map<WellScenarioTab>(decision);
            entity.MasterVersionId = decision.RevId ?? null;
            entity.RevId = Guid.NewGuid();
            entity.TabId = decision.TabId ?? Guid.NewGuid();
            entity.IsDeleted = false;
            entity.Created = currentTime;
            entity.Updated = currentTime;

            decision.RevId = entity.RevId;
            decision.TabId = entity.TabId;
            //decision.Created = wellScenario.Created;

            _context.Add(entity);
            await _context.SaveChangesAsync();

            return entity;
        }
    }
}