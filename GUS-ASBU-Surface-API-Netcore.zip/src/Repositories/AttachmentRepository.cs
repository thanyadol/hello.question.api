using Microsoft.EntityFrameworkCore;
using Serilog;
//model
using surflex.netcore22.Models;
using System; 

using System.Collections.Generic;
using System.Threading.Tasks;

namespace surflex.netcore22.Repositories
{
    public interface IAttachmentRepository
    {
        Task<IEnumerable<Attachment>> ListAsync();

        //Task<Attachment> GetRecentlyAsync(string id, string type);

        Task<Attachment> GetAsync(string id);
        Task<Attachment> CreateAsync(Attachment attachment);
        Task<Attachment> UpdateAsync(Attachment attachment);
        Task<Attachment> DeleteAsync(string id);
    }


    public class DbAttachmentRepository : IAttachmentRepository
    {
        private readonly NorthwindContext _context;
        public DbAttachmentRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public virtual async Task<Attachment> CreateAsync(Attachment attachment)
        {

            var entity = await _context.Attachments.AddAsync(attachment);
            _context.SaveChanges();

            return entity.Entity;
        }

        public virtual async Task<Attachment> DeleteAsync(string id)
        {
            //var deletedEntity = await _AttachmentEntityTableStorageRepository.DeleteOneAsync(AttachmentName, AttachmentKey);
            var entity = await _context.Attachments.FindAsync(id);
            _context.Attachments.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public virtual async Task<IEnumerable<Attachment>> ListAsync()
        {

            var entities = await _context.Attachments.ToListAsync();
            //var Attachment = _context.Attachments.ToList();
            return entities;
        }

        public virtual async Task<Attachment> UpdateAsync(Attachment attachment)
        {

            var entity = await _context.Attachments.FindAsync(attachment.Id);

            // attachment.By = "admin";
            // attachment.Date = Utility.CurrentSEAsiaStandardTime();

            var _entity = _context.Attachments.Update(attachment);

            _context.SaveChanges();
            return _entity.Entity;
        }

        public virtual async Task<Attachment> GetAsync(string id)
        {
            var entity = await _context.Attachments.FindAsync(id);
            return entity;
        }
    }
}