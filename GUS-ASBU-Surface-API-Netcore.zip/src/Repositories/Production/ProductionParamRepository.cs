using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

using Serilog;
using Microsoft.EntityFrameworkCore;

namespace surflex.netcore22.Repositories
{
    public interface IProductionParamRepository
    {
        Task<IEnumerable<ProductionParam>> ListAsync();

        Task<IEnumerable<ProductionParam>> ListAsync(string id);

        //Task<ProductionParam> GetRecentlyAsync(string id, string type);

        Task<ProductionParam> GetAsync(string id);
        Task<ProductionParam> CreateAsync(ProductionParam param);
        Task<ProductionParam> UpdateAsync(ProductionParam param);
        Task<ProductionParam> DeleteAsync(string id);
    }


    public class ProductionParamRepository : IProductionParamRepository
    {

        private readonly NorthwindContext _context;
        public ProductionParamRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<ProductionParam> CreateAsync(ProductionParam param)
        {

            var entity = await _context.ProductionProfileParams.AddAsync(param);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<ProductionParam> DeleteAsync(string id)
        {
            //var deletedEntity = await _ProductionProfileParamEntityTableStorageRepository.DeleteOneAsync(ProductionProfileParamName, ProductionProfileParamKey);
            var entity = await _context.ProductionProfileParams.FindAsync(id);
            _context.ProductionProfileParams.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<ProductionParam>> ListAsync()
        {

            var entities = await _context.ProductionProfileParams.ToListAsync();
            //var ProductionParam = _context.ProductionProfileParams.ToList();
            return entities;
        }

        public async Task<IEnumerable<ProductionParam>> ListAsync(string id)
        {

            var entities = await _context.ProductionProfileParams
                            .Where(c => c.ProductionProfileId == id).ToListAsync();
            //var ProductionParam = _context.ProductionProfileParams.ToList();
            return entities;
        }

        public async Task<ProductionParam> UpdateAsync(ProductionParam param)
        {

            var entity = await _context.ProductionProfileParams.FindAsync(param.Id);

            // param.By = "admin";
            // param.Date = Utility.CurrentSEAsiaStandardTime();

            _context.ProductionProfileParams.Update(param);

            _context.SaveChanges();
            return entity;
        }

        public async Task<ProductionParam> GetAsync(string id)
        {
            var entity = await _context.ProductionProfileParams.FindAsync(id);
            return entity;
        }


    }
}