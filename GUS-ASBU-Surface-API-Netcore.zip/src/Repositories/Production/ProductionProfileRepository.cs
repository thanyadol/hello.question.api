using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

using Serilog;
using Microsoft.EntityFrameworkCore;

namespace surflex.netcore22.Repositories
{
    public interface IProductionProfileRepository
    {
        Task<IEnumerable<ProductionProfile>> ListAsync();

        //Task<ProductionProfile> GetRecentlyAsync(string id, string type);

        Task<ProductionProfile> GetAsync(string id);
        Task<ProductionProfile> CreateAsync(ProductionProfile profile);
        Task<ProductionProfile> UpdateAsync(ProductionProfile profile);
        Task<ProductionProfile> DeleteAsync(string id);

    }


    public class ProductionProfileRepository : IProductionProfileRepository
    {

        private readonly NorthwindContext _context;
        public ProductionProfileRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<ProductionProfile> CreateAsync(ProductionProfile profile)
        {

            var entity = await _context.ProductionProfiles.AddAsync(profile);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<ProductionProfile> DeleteAsync(string id)
        {
            //var deletedEntity = await _ProductionProfileEntityTableStorageRepository.DeleteOneAsync(ProductionProfileName, ProductionProfileKey);
            var entity = await _context.ProductionProfiles.FindAsync(id);
            _context.ProductionProfiles.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<ProductionProfile>> ListAsync()
        {
            var entities = await (from p in _context.ProductionProfiles
                                  join rr in _context.ProductionProfileParams on p.Id equals rr.ProductionProfileId into yy
                                  from yr in yy.DefaultIfEmpty()
                                  select new ProductionProfile
                                  {
                                      Id = p.Id,

                                      AbandonmentRate = p.AbandonmentRate,
                                      ApplicableModel = p.ApplicableModel,

                                      Value = p.Value,
                                      ValueType = p.ValueType,
                                      EVFormulaForIPCDRATE = p.EVFormulaForIPCDRATE,

                                      HoldupPercentage = p.HoldupPercentage,

                                      ProductionId = p.ProductionId,


                                      Params = yy.ToList(),

                                      Created = p.Created,

                                      By = p.By,

                                  }).ToListAsync();

            return entities;
        }

        public async Task<ProductionProfile> UpdateAsync(ProductionProfile profile)
        {

            var entity = await _context.ProductionProfiles.FindAsync(profile.Id);

            // profile.By = "admin";
            // profile.Date = Utility.CurrentSEAsiaStandardTime();

            _context.ProductionProfiles.Update(profile);

            _context.SaveChanges();
            return entity;
        }

        public async Task<ProductionProfile> GetAsync(string id)
        {
            var entity = await _context.ProductionProfiles.FindAsync(id);
            return entity;
        }


    }
}