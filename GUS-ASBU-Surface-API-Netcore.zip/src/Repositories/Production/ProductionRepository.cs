using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

using Serilog;
using Microsoft.EntityFrameworkCore;

namespace surflex.netcore22.Repositories
{
    public interface IProductionRepository
    {
        Task<IEnumerable<Production>> ListAsync();

        //Task<Production> GetRecentlyAsync(string id, string type);

        Task<Production> GetAsync(string id);
        Task<Production> CreateAsync(Production production);
        Task<Production> UpdateAsync(Production production);
        Task<Production> DeleteAsync(string id);
    }


    public class ProductionRepository : IProductionRepository
    {

        private readonly NorthwindContext _context;
        public ProductionRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<Production> CreateAsync(Production production)
        {

            var entity = await _context.Productions.AddAsync(production);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<Production> DeleteAsync(string id)
        {
            //var deletedEntity = await _ProductionEntityTableStorageRepository.DeleteOneAsync(ProductionName, ProductionKey);
            var entity = await _context.Productions.FindAsync(id);
            _context.Productions.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<Production>> ListAsync()
        {
            /* var entities = await (from p in _context.Productions
                                      // join a in _context.Areas on p.AreaId equals a.Id
                                      //  where j.Id == projectid
                                  select new Production
                                  {
                                      Id = p.Id,

                                      AreaName = p.AreaName,

                                      Asset = p.Asset

                                      Name = p.Name,
                                      Condition = p.Condition,
                                      AreaId = p.AreaId,
                                      Description = p.Description,

                                      Status = p.Status,

                                      Created = p.Created,
                                      StartDate = p.StartDate,
                                      FinishDate = p.FinishDate,

                                      By = p.By,

                                  }).ToListAsync();*/

            var entities = await _context.Productions.ToListAsync();
            return entities;
        }

        public async Task<Production> UpdateAsync(Production production)
        {

            var entity = await _context.Productions.FindAsync(production.Id);

            // production.By = "admin";
            // production.Date = Utility.CurrentSEAsiaStandardTime();

            _context.Productions.Update(production);

            _context.SaveChanges();
            return entity;
        }

        public async Task<Production> GetAsync(string id)
        {
            var entity = await _context.Productions.FindAsync(id);
            return entity;
        }



    }
}