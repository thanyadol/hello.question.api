using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

using Serilog;
using Microsoft.EntityFrameworkCore;
using surflex.netcore22.Extensions;


namespace surflex.netcore22.Repositories
{
    public interface IProjectLocationRepository
    {
        Task<IEnumerable<ProjectLocation>> ListAsync();

        //Task<ProjectLocation> GetRecentlyAsync(Guid id, string type);

        Task<ProjectLocation> GetAsync(Guid id);
        Task<ProjectLocation> CreateAsync(ProjectLocation locate);
        Task<ProjectLocation> UpdateAsync(ProjectLocation locate);
        Task<ProjectLocation> DeleteAsync(Guid id);

        Task<IEnumerable<ProjectLocation>> ListRecentlyAsync();
    }


    public class ProjectLocationRepository : IProjectLocationRepository
    {

        private readonly NorthwindContext _context;
        public ProjectLocationRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<ProjectLocation> CreateAsync(ProjectLocation locate)
        {

            var entity = await _context.ProjectLocations.AddAsync(locate);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<ProjectLocation> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _PropertiesEntityTableStorageRepository.DeleteOneAsync(PropertiesName, PropertiesKey);
            var entity = await _context.ProjectLocations.FindAsync(id);
            _context.ProjectLocations.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<ProjectLocation>> ListAsync()
        {

            var entities = await _context.ProjectLocations.ToListAsync();
            return entities;
        }

        public async Task<ProjectLocation> UpdateAsync(ProjectLocation locate)
        {

            var entity = await _context.ProjectLocations.FindAsync(locate.Id);

            // properties.By = "admin";
            // properties.Date = Utility.CurrentSEAsiaStandardTime();

            _context.ProjectLocations.Update(locate);

            _context.SaveChanges();
            return entity;
        }

        public async Task<ProjectLocation> GetAsync(Guid id)
        {
            var entity = await _context.ProjectLocations.FindAsync(id);
            return entity;
        }

        public async Task<IEnumerable<ProjectLocation>> ListRecentlyAsync()
        {
            var entity = await (from u in _context.Projects
                                join ua in _context.ProjectLocations on u.Id equals ua.ProjectId
                                //join l in GLOBAL.PROJECT_LOCATION on l.Id
                                where ua.Status == RecordStatus.ACTIVE.GetDescription()
                                select new ProjectLocation()
                                {
                                    Id = ua.Id,

                                    //Location = .LocationId,

                                    ProjectId = u.Id,
                                    ProjectName = u.Name,
                                    RLLCPProjectId = u.RLLCPReferenceId.GetValueOrDefault(),

                                    LocationId = ua.LocationId,
                                    // LocationName = l.

                                    // ExpiredDate = ua.ExpiredDate,
                                    Status = ua.Status,
                                    Date = ua.Date,

                                }).ToListAsync();

            return entity;

        }


    }
}