using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

using Serilog;
using Microsoft.EntityFrameworkCore;

namespace surflex.netcore22.Repositories
{
    public interface IProjectActivityRepository
    {
        Task<IEnumerable<ProjectActivity>> ListAsync();

        //Task<ProjectActivity> GetRecentlyAsync(string id, string type);

        Task<ProjectActivity> GetAsync(string id);
        Task<ProjectActivity> CreateAsync(ProjectActivity activity);
        Task<ProjectActivity> UpdateAsync(ProjectActivity activity);
        Task<ProjectActivity> DeleteAsync(string id);
    }


    public class ProjectActivityRepository : IProjectActivityRepository
    {

        private readonly NorthwindContext _context;
        public ProjectActivityRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<ProjectActivity> CreateAsync(ProjectActivity activity)
        {

            var entity = await _context.ProjectActivities.AddAsync(activity);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<ProjectActivity> DeleteAsync(string id)
        {
            //var deletedEntity = await _PropertiesEntityTableStorageRepository.DeleteOneAsync(PropertiesName, PropertiesKey);
            var entity = await _context.ProjectActivities.FindAsync(id);
            _context.ProjectActivities.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<ProjectActivity>> ListAsync()
        {

            var entities = await _context.ProjectActivities.ToListAsync();
            return entities;
        }

        public async Task<ProjectActivity> UpdateAsync(ProjectActivity activity)
        {

            var entity = await _context.ProjectActivities.FindAsync(activity.Id);

            // properties.By = "admin";
            // properties.Date = Utility.CurrentSEAsiaStandardTime();

            _context.ProjectActivities.Update(activity);

            _context.SaveChanges();
            return entity;
        }

        public async Task<ProjectActivity> GetAsync(string id)
        {
            var entity = await _context.ProjectActivities.FindAsync(id);
            return entity;
        }


    }
}