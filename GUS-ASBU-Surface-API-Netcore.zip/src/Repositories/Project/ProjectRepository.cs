using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;

//apsi
using surflex.netcore22.APIs.Model;
using surflex.netcore22.APIs;
using surflex.netcore22.Extensions;

namespace surflex.netcore22.Repositories
{

    public interface IProjectRepository
    {
        Task<IEnumerable<Project>> ListAsync();
        //Task<ProjectSummary> GetWithSummaryAsync(string id);
        // Task<IEnumerable<Project>> ReadAllInClanAsync(string clanName);
        Task<Project> GetAsync(string id);
        Task<Project> CreateAsync(Project Project);
        Task<Project> UpdateAsync(Project Project);
        Task<Project> DeleteAsync(string id);

        //Task<IEnumerable<ProjectAsync>> ListPlannedAsync();
        //Task<IEnumerable<ProjectAsync>> ListProductiveAsync(string[] wells);//(IEnumerable<WellProductiveAsync> wells)

        Task<IEnumerable<Project>> ListAuthorizeAsync();
        Task<IEnumerable<Project>> ListLocationAsync();

    }

    public class ProjectRepository : IProjectRepository
    {
        //private readonly IProjectMappingService _ProjectMappingService;
        //private readonly ITableStorageRepository<ProjectEntity> _ProjectEntityTableStorageRepository;

        //        private readonly string ACTIVE = "ACTIVE";

        private readonly NorthwindContext _context;

        //private readonly IEntityService _entityService;

        public ProjectRepository(NorthwindContext context) //, IEntityService entityService) //IProjectMappingService ProjectMappingService, ITableStorageRepository<ProjectEntity> ProjectEntityTableStorageRepository)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            // _entityService = entityService ?? throw new ArgumentNullException(nameof(entityService));

            //_ProjectMappingService = ProjectMappingService ?? throw new ArgumentNullException(nameof(ProjectMappingService));
            //_ProjectEntityTableStorageRepository = ProjectEntityTableStorageRepository ?? throw new ArgumentNullException(nameof(ProjectEntityTableStorageRepository));
        }

        public async Task<Project> CreateAsync(Project project)
        {
            //var entityToCreate = _ProjectMappingService.Map(Project);
            //var createdEntity = await _ProjectEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createProject = _ProjectMappingService.Map(createdEntity);

            var createProject = await _context.Projects.AddAsync(project);
            _context.SaveChanges();
            return createProject.Entity;
        }

        public async Task<Project> DeleteAsync(string id)
        {
            //var deletedEntity = await _ProjectEntityTableStorageRepository.DeleteOneAsync(clanName, ProjectKey);
            var deletedProject = await _context.Projects.FindAsync(id);
            _context.Projects.Remove(deletedProject);
            _context.SaveChanges();
            return deletedProject;
        }

        public async Task<IEnumerable<Project>> ListAsync()
        {
            //var entities = await _ProjectEntityTableStorageRepository.ReadAllAsync();
            //var Project = _ProjectMappingService.Map(entities);
            //return Project;

            //should move a status to ENUM
            var entities = await _context.Projects.ToListAsync();
            //var Project = _context.Projects.ToList();
            return entities;
        }

        public async Task<Project> UpdateAsync(Project Project)
        {
            //var entityToUpdate = _ProjectMappingService.Map(Project);
            //var updatedEntity = await _ProjectEntityTableStorageRepository.InsertOrMergeAsync(entityToUpdate);
            //var deletedEntity = await _ProjectEntityTableStorageRepository.DeleteOneAsync(clanName, ProjectKey);

            var updateProject = await _context.Projects.FindAsync(Project.Id);
            _context.Projects.Update(Project);
            _context.SaveChanges();
            return updateProject;
        }


        public async Task<Project> GetAsync(string id)
        {
            var project = await _context.Projects.FindAsync(id);
            return project;
        }



        public async Task<IEnumerable<Project>> ListAuthorizeAsync()
        {
            var entity = await _context.Projects
                           .Include(x => x.ProjectAuthorizes)
                           //    .IncludeFilter(x => x.ProjectAuthorizes.Where(i => i.Status == RecordStatus.ACTIVE.GetDescription()))
                           .ThenInclude(x => x.User)
                           //    .Where(c => c.ProjectAuthorizes.Any(i => i.Status == RecordStatus.ACTIVE.GetDescription()))
                           .ToListAsync();

            //set role name
            entity.Select(c =>
            {
                c.ProjectAuthorizes = c.ProjectAuthorizes.Where(i => i.Status == RecordStatus.ACTIVE.GetDescription()).Select(x =>
                {
                    x.DisplayName = x.User.DisplayName;
                    x.Email = x.User.Email;
                    x.CAI = x.User.CAI;

                    return x;
                }).Where(i => i.Status == RecordStatus.ACTIVE.GetDescription()).ToList();


                return c;
            }).ToList();

            return entity;
        }


        public async Task<IEnumerable<Project>> ListLocationAsync()
        {
            var entity = await (from p in _context.Projects
                                join ps in _context.ProjectLocations on p.Id equals ps.ProjectId
                                where ps.Status == RecordStatus.ACTIVE.GetDescription()
                                //  join a in _context.Users on ps.UserId equals a.Id
                                //&& ps.IsEnabled == true
                                //select ps into t
                                // into t
                                select new Project()
                                {
                                    Id = p.Id,

                                    Name = p.Name,
                                    RLLCPReferenceId = p.RLLCPReferenceId,

                                    Description = p.Description,

                                    Created = p.Created,

                                    LocationId = ps.LocationId,

                                    //Users = t,
                                    //AccessControl = ps,

                                }).ToListAsync();

            return entity;
        }


        /* public async Task<ProjectSummary> GetWithSummaryAsync(string id)
        {
            var entities = await (from p in _context.Platforms
                                  join j in _context.Projects on p.Id equals j.PlatformId
                                  where j.Id == id
                                  select new ProjectSummary
                                  {
                                      Id = j.Id,
                                      Name = j.Name,
                                      Description = j.Description,
                                      Created = j.Created,

                                      PlatformName = p.Name,
                                      Status = j.Status

                                  }).FirstOrDefaultAsync();

            //var wells = _context.Wells.Where(c => c.ProjectId == id);
            //entities.Wells = wells;

            //var entities = await _context.UserAuthens.Where(c => c.ProjectId == projectid).ToListAsync();
            return entities;
        }*/

        /* 
        public async Task<IEnumerable<Project>> ReadAllInClanAsync(string clanName)
        {
            var entities = await _ProjectEntityTableStorageRepository.ReadPartitionAsync(clanName);
            var Project = _ProjectMappingService.Map(entities);
            return Project;
        }

        public async Task<Project> ReadOneAsync(string clanName, string ProjectKey)
        {
            var entity = await _ProjectEntityTableStorageRepository.ReadOneAsync(clanName, ProjectKey);
            var Project = _ProjectMappingService.Map(entity);
            return Project;
        }
        */

    }




}