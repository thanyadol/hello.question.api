using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

using Serilog;
using Microsoft.EntityFrameworkCore;
using surflex.netcore22.Extensions;

namespace surflex.netcore22.Repositories
{
    public interface IProjectDrilledRepository
    {
        Task<IEnumerable<ProjectDrilled>> ListAsync();

        Task<IEnumerable<ProjectDrilled>> ListRecentlyAsync();


        //Task<ProjectDrilled> GetRecentlyAsync(Guid id, string type);

        Task<ProjectDrilled> GetAsync(Guid id);
        Task<ProjectDrilled> CreateAsync(ProjectDrilled summ);
        Task<ProjectDrilled> UpdateAsync(ProjectDrilled summ);
        Task<ProjectDrilled> DeleteAsync(Guid id);

        Task<ProjectDrilled> GetRecentlyAsync(string id, string userid);
    }


    public class ProjectDrilledRepository : IProjectDrilledRepository
    {
        // private readonly string SAVE = "SAVED";
        // private readonly string UPDATE = "UPDATED";
        // private readonly string PUBLISH = "PUBLISHED";

        private readonly NorthwindContext _context;
        public ProjectDrilledRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<ProjectDrilled> CreateAsync(ProjectDrilled summ)
        {

            var entity = await _context.ProjectDrilleds.AddAsync(summ);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<ProjectDrilled> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _PropertiesEntityTableStorageRepository.DeleteOneAsync(PropertiesName, PropertiesKey);
            var entity = await _context.ProjectDrilleds.FindAsync(id);
            _context.ProjectDrilleds.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<ProjectDrilled>> ListAsync()
        {

            var entities = await _context.ProjectDrilleds.ToListAsync();
            return entities;
        }

        public async Task<ProjectDrilled> UpdateAsync(ProjectDrilled summ)
        {

            var entity = await _context.ProjectDrilleds.FindAsync(summ.Id);

            // summ.By = "admin";
            // summ.Date = Utility.CurrentSEAsiaStandardTime();

            _context.ProjectDrilleds.Update(summ);

            _context.SaveChanges();
            return entity;
        }

        public async Task<ProjectDrilled> GetAsync(Guid id)
        {
            var entity = await _context.ProjectDrilleds.FindAsync(id);
            return entity;
        }

        //
        // Summary:
        //     get recent saved sand by user and well
        //
        // Returns:
        //     Models.Entity.ProjectDrilled object
        //
        // Type parameters:
        //   id:
        //     well id
        //   userid
        //     http request user id 
        //
        public async Task<ProjectDrilled> GetRecentlyAsync(string id, string userid)
        {
            var entity = await (from p in _context.Projects
                                join ps in _context.ProjectSpaces on p.Id equals ps.ProjectId
                                join pw in _context.ProjectDrilleds on ps.Id equals pw.ProjectSpaceId
                                join a in _context.ProjectActivities on ps.Id equals a.ProjectSpaceId
                                where (
                                    (p.Id == id && a.By == userid && (a.Action == ActivityAction.SAVED.GetDescription() || a.Action == ActivityAction.UPDATED.GetDescription()))
                                || (p.Id == id && a.Action == ActivityAction.PUBLISHED.GetDescription())
                                )

                                orderby a.Date descending
                                select new ProjectDrilled()
                                {
                                    Id = pw.Id,
                                    ProjectSpaceId = ps.Id,

                                    ProjectId = p.Id,
                                    ProjectName = p.Name,

                                    TemplateTypeId = pw.TemplateTypeId,
                                    ActualDPI = pw.ActualDPI,

                                    PlannedDPI = pw.PlannedDPI,

                                    AttachmentId = pw.AttachmentId,

                                    By = a.By,

                                    Rev = pw.Rev,
                                    Key = pw.Key,

                                    // Created = ps.Created,

                                    StartDate = pw.StartDate,
                                    FinishDate = pw.FinishDate,

                                    ActivityType = a.Action,
                                    ActivityDate = a.Date

                                }).ToListAsync();

            return entity.FirstOrDefault(); ;
        }


        //
        // Summary:
        //     get recent saved sand by user and well
        //
        // Returns:
        //     Models.Entity.ProjectDrilled object
        //
        // Type parameters:
        //   id:
        //     well id
        //   userid
        //     http request user id 
        //
        public async Task<IEnumerable<ProjectDrilled>> ListRecentlyAsync()
        {
            var entity = await (from p in _context.ProjectDrilleds
                                join t in _context.Templates on p.TemplateTypeId equals t.TemplateTypeId into yy
                                //  join a in _context.Attachments on p.AttachmentId equals a.Id
                                //orderby a.Date descending
                                from tt in yy.DefaultIfEmpty()
                                where tt.Status == RecordStatus.ACTIVE.GetDescription()
                                orderby tt.Created descending
                                select new ProjectDrilled()
                                {
                                    Id = p.Id,
                                    ProjectSpaceId = p.ProjectSpaceId,

                                    //ProjectId = p.Id,
                                    //ProjectName = p.Name,
                                    TemplateTypeId = p.TemplateTypeId,
                                    AttachmentId = p.AttachmentId,
                                    // TemplateId = tt.Id,

                                    PlannedDPI = p.PlannedDPI,
                                    ActualDPI = p.ActualDPI,

                                    //Attachment = a,

                                    Template = tt,

                                    By = p.By,

                                    Rev = p.Rev,
                                    Key = p.Key,

                                    // Created = ps.Created,

                                    StartDate = p.StartDate,
                                    FinishDate = p.FinishDate,

                                    //ActivityType = a.Action,
                                    //ActivityDate = a.Date

                                }).ToListAsync();

            return entity;
        }


    }
}