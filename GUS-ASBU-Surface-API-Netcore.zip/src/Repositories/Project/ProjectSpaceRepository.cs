using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

using Serilog;
using Microsoft.EntityFrameworkCore;

namespace surflex.netcore22.Repositories
{
    public interface IProjectSpaceRepository
    {
        Task<IEnumerable<ProjectSpace>> ListAsync();

        //Task<ProjectSpace> GetRecentlyAsync(string id, string type);

        Task<ProjectSpace> GetAsync(string id);
        Task<ProjectSpace> CreateAsync(ProjectSpace space);
        Task<ProjectSpace> UpdateAsync(ProjectSpace space);
        Task<ProjectSpace> DeleteAsync(string id);
    }


    public class ProjectSpaceRepository : IProjectSpaceRepository
    {

        private readonly NorthwindContext _context;
        public ProjectSpaceRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<ProjectSpace> CreateAsync(ProjectSpace space)
        {

            var entity = await _context.ProjectSpaces.AddAsync(space);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<ProjectSpace> DeleteAsync(string id)
        {
            //var deletedEntity = await _PropertiesEntityTableStorageRepository.DeleteOneAsync(PropertiesName, PropertiesKey);
            var entity = await _context.ProjectSpaces.FindAsync(id);
            _context.ProjectSpaces.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<ProjectSpace>> ListAsync()
        {

            var entities = await _context.ProjectSpaces.ToListAsync();
            return entities;
        }

        public async Task<ProjectSpace> UpdateAsync(ProjectSpace space)
        {

            var entity = await _context.ProjectSpaces.FindAsync(space.Id);

            // space.By = "admin";
            // space.Date = Utility.CurrentSEAsiaStandardTime();

            _context.ProjectSpaces.Update(space);

            _context.SaveChanges();
            return entity;
        }

        public async Task<ProjectSpace> GetAsync(string id)
        {
            var entity = await _context.ProjectSpaces.FindAsync(id);
            return entity;
        }


    }
}