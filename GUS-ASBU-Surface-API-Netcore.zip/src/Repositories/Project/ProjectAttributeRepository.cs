using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace surflex.netcore22.Repositories
{
    public interface IProjectAttributeRepository
    {
        Task<IEnumerable<ProjectAttribute>> ListAsync();

        //Task<ProjectAttribute> GetRecentlyAsync(string id, string type);

        Task<ProjectAttribute> GetAsync(string id);

        Task<ProjectAttribute> GetAsync(ProjectAttribute attribute);
        Task<ProjectAttribute> CreateAsync(ProjectAttribute attribute);
        Task<ProjectAttribute> UpdateAsync(ProjectAttribute attribute);
        Task<ProjectAttribute> DeleteAsync(string id);
    }
    /*
     * to controll the user activities
     *
     */

    public class ProjectAttributeRepository : IProjectAttributeRepository
    {

        private readonly NorthwindContext _context;
        public ProjectAttributeRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<ProjectAttribute> CreateAsync(ProjectAttribute attribute)
        {

            var entity = await _context.ProjectAttributes.AddAsync(attribute);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<ProjectAttribute> DeleteAsync(string id)
        {
            //var deletedEntity = await _ProjectAttributeEntityTableStorageRepository.DeleteOneAsync(ProjectAttributeName, ProjectAttributeKey);
            var entity = await _context.ProjectAttributes.FindAsync(id);
            _context.ProjectAttributes.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<ProjectAttribute>> ListAsync()
        {

            var entities = await _context.ProjectAttributes.ToListAsync();
            //var ProjectAttribute = _context.ProjectAttributes.ToList();
            return entities;
        }

        public async Task<ProjectAttribute> UpdateAsync(ProjectAttribute attribute)
        {

            var entity = await _context.ProjectAttributes.FindAsync(attribute.Id);

            // attribute.By = "admin";
            // attribute.Date = Utility.CurrentSEAsiaStandardTime();

            _context.ProjectAttributes.Update(attribute);

            _context.SaveChanges();
            return entity;
        }

        public async Task<ProjectAttribute> GetAsync(string id)
        {
            var entity = await _context.ProjectAttributes.FindAsync(id);
            return entity;
        }

        public async Task<ProjectAttribute> GetAsync(ProjectAttribute attr)
        {
            var entity = await _context.ProjectAttributes.Where(c => c.Status == "ACTIVE" && c.ProjectId == attr.ProjectId)
                                    .OrderByDescending(c => c.StartDate).FirstOrDefaultAsync();
            return entity;
        }


    }
}