using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

using Serilog;
using Microsoft.EntityFrameworkCore;
using surflex.netcore22.Extensions;

namespace surflex.netcore22.Repositories
{
    public interface IProjectWellRepository
    {
        Task<IEnumerable<ProjectWell>> ListAsync();

        //Task<ProjectWell> GetRecentlyAsync(string id, string type);

        Task<ProjectWell> GetAsync(string id);
        Task<ProjectWell> CreateAsync(ProjectWell summ);
        Task<ProjectWell> UpdateAsync(ProjectWell summ);
        Task<ProjectWell> DeleteAsync(string id);

        Task<ProjectWell> GetRecentlyAsync(string id, string userid);
    }


    public class ProjectWellRepository : IProjectWellRepository
    {
        // private readonly string SAVE = "SAVED";
        // private readonly string UPDATE = "UPDATED";
        // private readonly string PUBLISH = "PUBLISHED";

        private readonly NorthwindContext _context;
        public ProjectWellRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<ProjectWell> CreateAsync(ProjectWell summ)
        {

            var entity = await _context.ProjectWells.AddAsync(summ);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<ProjectWell> DeleteAsync(string id)
        {
            //var deletedEntity = await _PropertiesEntityTableStorageRepository.DeleteOneAsync(PropertiesName, PropertiesKey);
            var entity = await _context.ProjectWells.FindAsync(id);
            _context.ProjectWells.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<ProjectWell>> ListAsync()
        {

            var entities = await _context.ProjectWells.ToListAsync();
            return entities;
        }

        public async Task<ProjectWell> UpdateAsync(ProjectWell summ)
        {

            var entity = await _context.ProjectWells.FindAsync(summ.Id);

            // summ.By = "admin";
            // summ.Date = Utility.CurrentSEAsiaStandardTime();

            _context.ProjectWells.Update(summ);

            _context.SaveChanges();
            return entity;
        }

        public async Task<ProjectWell> GetAsync(string id)
        {
            var entity = await _context.ProjectWells.FindAsync(id);
            return entity;
        }

        //
        // Summary:
        //     get recent saved sand by user and well
        //
        // Returns:
        //     Models.Entity.ProjectWell object
        //
        // Type parameters:
        //   id:
        //     well id
        //   userid
        //     http request user id 
        //
        public async Task<ProjectWell> GetRecentlyAsync(string id, string userid)
        {
            var entity = await (from p in _context.Projects
                                join ps in _context.ProjectSpaces on p.Id equals ps.ProjectId
                                join pw in _context.ProjectWells on ps.Id equals pw.ProjectSpaceId
                                join a in _context.ProjectActivities on ps.Id equals a.ProjectSpaceId
                                where (
                                    (p.Id == id && a.By == userid && (a.Action == ActivityAction.SAVED.GetDescription() || a.Action == ActivityAction.UPDATED.GetDescription()))
                                || (p.Id == id && a.Action == ActivityAction.PUBLISHED.GetDescription())
                                )

                                orderby a.Date descending
                                select new ProjectWellParams()
                                {
                                    Id = pw.Id,
                                    ProjectSpaceId = ps.Id,

                                    ProjectId = p.Id,
                                    ProjectName = p.Name,

                                    By = a.By,

                                    Rev = pw.Rev,
                                    Key = pw.Key,

                                    Created = ps.Created,

                                    StartDate = pw.StartDate,
                                    FinishDate = pw.FinishDate,

                                    ActivityType = a.Action,
                                    ActivityDate = a.Date

                                }).ToListAsync();

            return entity.FirstOrDefault(); ;
        }


    }
}