using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;

namespace surflex.netcore22.Repositories
{

    public interface ISandRepository
    {
        Task<IEnumerable<Sand>> ListAsync();

        Task<Sand> GetAsync(Guid id);

        // Task<Sand> RecentAsync(string name);
        Task<Sand> CreateAsync(Sand Sand);
        Task<Sand> UpdateAsync(Sand Sand);
        //Task<Sand> DeleteAsync(string id);

        Task<IEnumerable<Sand>> CreateRangeAsync(IEnumerable<Sand> sands);


    }
    /*
     * to controll the user activities
     *
     */

    public class SandRepository : ISandRepository
    {

        //  private readonly IEntityService _entityService;
        // private readonly IClientService _clientService;
        private readonly NorthwindContext _context;
        public SandRepository(NorthwindContext context) //, IClientService clientService, IEntityService entityService)//, IActivityService activityService)
        {
            //_activityService = activityService ?? throw new ArgumentNullException(nameof(activityService));
            _context = context ?? throw new ArgumentNullException(nameof(context));

            //  _clientService = clientService ?? throw new ArgumentNullException(nameof(clientService));
            //  _entityService = entityService ?? throw new ArgumentNullException(nameof(entityService));
        }

        public async Task<Sand> CreateAsync(Sand sand)
        {
            var created = await _context.Sands.AddAsync(sand);
            _context.SaveChanges();
            return created.Entity;
        }


        public async Task<IEnumerable<Sand>> CreateRangeAsync(IEnumerable<Sand> sands)
        {
            await _context.Sands.AddRangeAsync(sands);
            _context.SaveChanges();

            return sands;
        }


        public async Task<Sand> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _SandEntityTableStorageRepository.DeleteOneAsync(SandName, SandKey);
            var deleted = await _context.Sands.FindAsync(id);
            _context.Sands.Remove(deleted);
            _context.SaveChanges();
            return deleted;
        }

        public async Task<IEnumerable<Sand>> ListAsync()
        {

            var entities = await _context.Sands.ToListAsync();
            //var Sand = _context.SandActivities.ToList();
            return entities;
        }

        public async Task<Sand> UpdateAsync(Sand sand)
        {
            await _context.Sands.FindAsync(sand.Id);
            var entity = _context.Sands.Update(sand);

            _context.SaveChanges();
            return entity.Entity;
        }

        public async Task<Sand> GetAsync(Guid id)
        {
            return await _context.Sands.FindAsync(id);
        }

        /* public async Task<Sand> GetAsync(string id)
        {
            //var sand = await _context.Sands.FindAsync(id);
            var entity = await (from s in _context.Sands
                                join w in _context.Wells on s.WellId equals w.Id
                                where s.Id == id
                                select new Sand()
                                {
                                    Id = s.Id,
                                    WellId = s.WellId,

                                    //By = a.By,
                                    WellReserve = s.WellReserve,
                                    Rev = s.Rev,
                                    Key = s.Key,
                                    Datasource = s.Datasource,
                                    Value = s.Value,
                                    Header = s.Header,

                                    Type = s.Type,
                                    IsPublisher = s.IsPublisher,

                                    //ActivityType = a.Type,


                                    Created = s.Created,
                                    Updated = s.Updated,

                                    CalculatedTimestamp = s.CalculatedTimestamp,

                                    WellName = w.Name,

                                    //ActivityType = a.Type,
                                    //ActivityDate = a.Date

                                }).FirstOrDefaultAsync();

            return entity; //.FirstOrDefault(); ;
        }

        //
        // Summary:
        //     get recent saved sand by user and well
        //
        // Returns:
        //     Models.Entity.Sand object
        //
        // Type parameters:
        //   id:
        //     well id
        //   userid
        //     http request user id 
        //
        public async Task<Sand> GetRecentlyAsync(string id, string type, string userid)
        {
            var entity = await (from s in _context.Sands
                                join a in _context.SandActivities on s.Id equals a.SandId
                                where (
                                    (s.WellId == id && a.By == userid && (a.Type == SAVE || a.Type == UPDATE))
                                || (s.WellId == id && a.Type == PUBLISH)
                                )
                                && s.Type == type

                                orderby a.Date descending
                                select new Sand()
                                {
                                    Id = s.Id,
                                    WellId = s.WellId,

                                    By = a.By,
                                    WellReserve = s.WellReserve,
                                    Rev = s.Rev,
                                    Key = s.Key,
                                    Datasource = s.Datasource,
                                    Value = s.Value,
                                    Header = s.Header,

                                    Created = s.Created,
                                    Updated = s.Updated,

                                    //ActivityType = a.Type,

                                    Type = s.Type,
                                    IsPublisher = s.IsPublisher,

                                    CalculatedTimestamp = s.CalculatedTimestamp,

                                    ActivityType = a.Type,
                                    ActivityDate = a.Date

                                }).ToListAsync();

            return entity.FirstOrDefault(); ;
        }


        //
        // Summary:
        //     get recent PUBLISH sand by  well
        //
        // Returns:
        //     Models.Entity.Sand object
        //
        // Type parameters:
        //   id:
        //     well id
        //
        /* public async Task<Sand> GetPUBLISHAsync(string id)
        {
            var entity = await (from s in _context.Sands
                                join a in _context.SandActivities on s.Id equals a.SandId
                                where s.WellId == id && a.Type == PUBLISH
                                orderby a.Date descending
                                select s).FirstOrDefaultAsync();

            return entity;
        }*/

        /*  public async Task<Sand> RecentAsync(string name)
         {
             var sand = await _context.Sands.Where(c => c.WellName == name)
                             .OrderByDescending(c => c.Created).FirstOrDefaultAsync();
             return sand;
         }*/




    }
}