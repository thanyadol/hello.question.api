using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

//apis
using surflex.netcore22.APIs;
using surflex.netcore22.APIs.Model;


using JobProductiveAsync = surflex.netcore22.APIs.Gateway.JobProductiveAsync;
using JobAsync = surflex.netcore22.APIs.Model.JobAsync;
using WellPlannedAsync = surflex.netcore22.APIs.Gateway.WellPlannedAsync;

namespace surflex.netcore22.Repositories
{
    public interface IJobRepository
    {
        Task<IEnumerable<Job>> ListAsync();

        //   Task<Job> GetLastestByWellAsync(string id);
        //Task<JobAsync> GetProductiveCostAsync(string name);
        Task<Job> GetAsync(string id);
        Task<Job> CreateAsync(Job Job);
        Task<Job> UpdateAsync(Job Job);
        Task<Job> DeleteAsync(string id);

    }

    public class JobRepository : IJobRepository
    {
        //private readonly IJobMappingService _JobMappingService;
        //private readonly ITableStorageRepository<JobEntity> _JobEntityTableStorageRepository;

        private readonly NorthwindContext _context;
        // private readonly IEntityService _entityService;

        public JobRepository(NorthwindContext context) //, IEntityService entityService) //IJobMappingService JobMappingService, ITableStorageRepository<JobEntity> JobEntityTableStorageRepository)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            //_JobMappingService = JobMappingService ?? throw new ArgumentNullException(nameof(JobMappingService));
            //_JobEntityTableStorageRepository = JobEntityTableStorageRepository ?? throw new ArgumentNullException(nameof(JobEntityTableStorageRepository));

            //_entityService = entityService ?? throw new ArgumentNullException(nameof(entityService));


            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<Job> GetAsync(string id)
        {
            //var entityToCreate = _JobMappingService.Map(Job);
            //var createdEntity = await _JobEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createJob = _JobMappingService.Map(createdEntity);

            var jobs = await _context.Jobs.FindAsync(id);
            //_context.SaveChanges();

            return jobs;
        }


        public async Task<Job> CreateAsync(Job job)
        {
            //var entityToCreate = _JobMappingService.Map(Job);
            //var createdEntity = await _JobEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createJob = _JobMappingService.Map(createdEntity);

            var createJob = await _context.Jobs.AddAsync(job);
            _context.SaveChanges();

            return createJob.Entity;
        }


        public async Task<Job> DeleteAsync(string id)
        {
            //var deletedEntity = await _JobEntityTableStorageRepository.DeleteOneAsync(jobName, JobKey);
            var deletedJob = await _context.Jobs.FindAsync(id);
            _context.Jobs.Remove(deletedJob);
            _context.SaveChanges();
            return deletedJob;
        }

        public async Task<IEnumerable<Job>> ListAsync()
        {
            //var entities = await _JobEntityTableStorageRepository.ReadAllAsync();
            //var Job = _JobMappingService.Map(entities);
            //return Job;

            var entities = await _context.Jobs.ToListAsync();
            //var Job = _context.Jobs.ToList();
            return entities;
        }

        public async Task<Job> UpdateAsync(Job Job)
        {
            //var entityToUpdate = _JobMappingService.Map(Job);
            //var updatedEntity = await _JobEntityTableStorageRepository.InsertOrMergeAsync(entityToUpdate);
            //var deletedEntity = await _JobEntityTableStorageRepository.DeleteOneAsync(jobName, JobKey);

            var updateJob = await _context.Jobs.FindAsync(Job.Id);
            _context.Jobs.Update(Job);

            _context.SaveChanges();
            return updateJob;
        }

        // public async Task<Job> GetLastestByWellAsync(string id)
        // {
        //     var entities = await (from w in _context.Wells
        //                           join j in _context.Jobs on w.Id equals j.WellId
        //                           where w.Id == id
        //                           select new Job
        //                           {
        //                               Id = j.Id,
        //                               WellId = w.Id,

        //                               Type = j.Type,
        //                               Activity = j.Activity,

        //                               Status = j.Status,
        //                               // End = j.End,

        //                           }).FirstOrDefaultAsync();

        //     return entities;
        // }


    }
}