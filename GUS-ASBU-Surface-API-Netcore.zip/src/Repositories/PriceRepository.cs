using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace surflex.netcore22.Repositories
{
    public interface IPriceGroupRepository
    {
        Task<IEnumerable<Price>> ListAsync();

        //Task<Price> GetRecentlyAsync(Guid id, string type);

        Task<Price> GetAsync(Guid id);
        Task<Price> CreateAsync(Price price);
        Task<Price> UpdateAsync(Price price);
        //Task<Price> DeleteAsync(Guid id);


    }

    /*
     * to controll the user activities
     *
     */

    public class PriceGroupRepository : IPriceGroupRepository
    {

        private readonly NorthwindContext _context;
        public PriceGroupRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<Price> CreateAsync(Price grouped)
        {

            var entity = await _context.PriceGroups.AddAsync(grouped);

            try
            {
                _context.SaveChanges();
                return entity.Entity;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<Price> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _PriceGroupEntityTableStorageRepository.DeleteOneAsync(PriceGroupName, PriceGroupKey);
            var entity = await _context.PriceGroups.FindAsync(id);
            _context.PriceGroups.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<Price>> ListAsync()
        {

            var entities = await _context.PriceGroups.ToListAsync();
            //var Price = _context.PriceGroups.ToList();
            return entities;
        }

        public async Task<Price> UpdateAsync(Price grouped)
        {

            var entity = await _context.PriceGroups.FindAsync(grouped.Id);

            // grouped.By = "admin";
            // grouped.Date = Utility.CurrentSEAsiaStandardTime();

            _context.PriceGroups.Update(grouped);

            _context.SaveChanges();
            return entity;
        }

        public async Task<Price> GetAsync(Guid id)
        {
            var entity = await _context.PriceGroups.FindAsync(id);
            return entity;
        }


    }
}