using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace surflex.netcore22.Repositories
{
    public interface ITemplateRepository
    {
        Task<IEnumerable<Template>> ListAsync();

        //Task<Template> GetRecentlyAsync(string id);
        //Task<Template> UpdateStatusAsync(string id, string status);

        Task<Template> GetAsync(string id);

        Task<Template> CreateAsync(Template template);
        Task<Template> UpdateAsync(Template template);
        Task<Template> DeleteAsync(string id);

        //  Task<Template> GetAsync(string id);
    }
    public class TemplateRepository : ITemplateRepository
    {

        private readonly NorthwindContext _context;
        public TemplateRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<Template> CreateAsync(Template template)
        {

            var entity = await _context.Templates.AddAsync(template);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<Template> DeleteAsync(string id)
        {
            //var deletedEntity = await _TemplateEntityTableStorageRepository.DeleteOneAsync(TemplateName, TemplateKey);
            var entity = await _context.Templates.FindAsync(id);
            _context.Templates.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<Template>> ListAsync()
        {
            var entities = await _context.Templates.ToListAsync();
            return entities;
        }

        public async Task<Template> UpdateAsync(Template template)
        {

            //var entity = await _context.Templates.AsNoTracking().Where(t => t.Id == template.Id).FirstOrDefaultAsync();
            //FindAsync(template.Id);

            // _context.Entry(template).State = EntityState.Modified;
            // _context.Templates.Update(template);
            // _context.SaveChanges();
            // return entity;

            var entity = await _context.Templates.FindAsync(template.Id);
            _context.Templates.Update(entity);
            _context.SaveChanges();

            return entity;
        }


        /* public async Task<Template> GetRecentlyAsync(string id)
        {
            var entities = await (from t in _context.Templates
                                  where t.Id == id && t.Status == "ACTIVE"
                                  join a in _context.Attachments on t.AttachmentId equals a.Id into ta
                                  from cj in ta.DefaultIfEmpty()
                                  select new Template
                                  {
                                      Id = t.Id,
                                      Name = ta.FirstOrDefault().Name,

                                      AttachmentName = ta.FirstOrDefault().Name,

                                      Type = t.Type,
                                      Created = t.Created,
                                      FinishDate = t.FinishDate,
                                      StartDate = t.StartDate,
                                      Status = t.Status,
                                      AttachmentId = ta.FirstOrDefault().Id,

                                  }).FirstOrDefaultAsync();

            //var entities = await _context.UserAuthens.Where(c => c.ProjectId == projectid).ToListAsync();

            return entities;
        }*/

        //default find asynce
        public async Task<Template> GetAsync(string id)
        {
            return await _context.Templates.FindAsync(id);
        }




    }
}