using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;
using surflex.netcore22.Helpers;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace surflex.netcore22.Repositories
{
    /*
     * to controll the user activities
     *
     */
    public interface IPeriodPriceRepository
    {
        Task<IEnumerable<PeriodPrice>> ListAsync();

        //Task<PeriodPrice> GetRecentlyAsync(Guid id, string type);

        Task<PeriodPrice> GetAsync(Guid id);
        Task<PeriodPrice> CreateAsync(PeriodPrice price);
        Task<PeriodPrice> UpdateAsync(PeriodPrice price);
        //Task<PeriodPrice> DeleteAsync(Guid id);

        Task<PeriodPrice> GetCurrentAsync(Guid id);
        Task<PeriodPrice> GetYearAsync(Guid id, int year);

        Task<IEnumerable<Price>> ListRecentlyAsync();
    }
    public class PeriodPriceRepository : IPeriodPriceRepository
    {

        private readonly NorthwindContext _context;
        public PeriodPriceRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<PeriodPrice> CreateAsync(PeriodPrice price)
        {

            var entity = await _context.Prices.AddAsync(price);

            try
            {
                _context.SaveChanges();
                return entity.Entity;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<PeriodPrice> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _PriceEntityTableStorageRepository.DeleteOneAsync(PriceName, PriceKey);
            var entity = await _context.Prices.FindAsync(id);
            _context.Prices.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<PeriodPrice>> ListAsync()
        {

            var entities = await _context.Prices.ToListAsync();
            //var PeriodPrice = _context.Prices.ToList();
            return entities;
        }

        public async Task<PeriodPrice> UpdateAsync(PeriodPrice price)
        {

            var entity = await _context.Prices.FindAsync(price.Id);

            // price.By = "admin";
            // price.Date = Utility.CurrentSEAsiaStandardTime();

            _context.Prices.Update(price);

            _context.SaveChanges();
            return entity;
        }

        public async Task<PeriodPrice> GetAsync(Guid id)
        {
            var entity = await _context.Prices.FindAsync(id);
            return entity;
        }

        //id = group id
        public async Task<PeriodPrice> GetCurrentAsync(Guid id)
        {
            DateTime current = Utility.CurrentSEAsiaStandardTime();

            var entity = await _context.Prices.Where(c => c.PriceId == id && c.Year == current.Year).FirstOrDefaultAsync();
            return entity;
        }


        public async Task<PeriodPrice> GetYearAsync(Guid id, int year)
        {
            //DateTime current = Utility.CurrentSEAsiaStandardTime();

            var entity = await _context.Prices.Where(c => c.PriceId == id && c.Year == year).FirstOrDefaultAsync();
            return entity;
        }



        //
        // Summary:
        //     get recent saved sand by user and well
        //
        // Returns:
        //     Models.Entity.WellUndrilled object
        //
        // Type parameters:
        //   id:
        //     well id
        //   userid
        //     http request user id 
        //
        public async Task<IEnumerable<Price>> ListRecentlyAsync()
        {
            var entity = await (from p in _context.PriceGroups
                                join ps in _context.Prices on p.Id equals ps.PriceId
                                into c
                                select new Price()
                                {
                                    Id = p.Id,

                                    Name = p.Name,

                                    HcType = p.HcType,
                                    Structure = p.Structure,
                                    Unit = p.Unit,
                                    Status = p.Status,

                                    By = p.By,
                                    TemplateId = p.TemplateId,
                                    AreaId = p.AreaId,

                                    Prices = c.ToList(),

                                }).ToListAsync();

            return entity;
        }

    }
}