using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace surflex.netcore22.Repositories
{
    /*
     * to controll the user activities
     *
     */
    public interface IResourceLibraryRepository
    {
        Task<IEnumerable<ResourceLibrary>> ListAsync();

        //Task<ResourceLibrary> GetRecentlyAsync(string id, string type);

        Task<ResourceLibrary> GetAsync(string id);
        Task<ResourceLibrary> CreateAsync(ResourceLibrary resource);
        Task<ResourceLibrary> UpdateAsync(ResourceLibrary resource);
        //Task<ResourceLibrary> DeleteAsync(string id);
    }

    public class ResourceLibraryRepository : IResourceLibraryRepository
    {

        private readonly NorthwindContext _context;
        public ResourceLibraryRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<ResourceLibrary> CreateAsync(ResourceLibrary resource)
        {

            var entity = await _context.ResourceLibraries.AddAsync(resource);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<ResourceLibrary> DeleteAsync(string id)
        {
            //var deletedEntity = await _ResourceLibraryEntityTableStorageRepository.DeleteOneAsync(ResourceLibraryName, ResourceLibraryKey);
            var entity = await _context.ResourceLibraries.FindAsync(id);
            _context.ResourceLibraries.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<ResourceLibrary>> ListAsync()
        {

            var entities = await _context.ResourceLibraries.ToListAsync();
            //var ResourceLibrary = _context.ResourceLibraries.ToList();
            return entities;
        }

        public async Task<ResourceLibrary> UpdateAsync(ResourceLibrary resource)
        {

            var entity = await _context.ResourceLibraries.FindAsync(resource.Id);

            // resource.By = "admin";
            // resource.Date = Utility.CurrentSEAsiaStandardTime();

            _context.ResourceLibraries.Update(resource);

            _context.SaveChanges();
            return entity;
        }

        public async Task<ResourceLibrary> GetAsync(string id)
        {
            var entity = await _context.ResourceLibraries.FindAsync(id);
            return entity;
        }


    }
}