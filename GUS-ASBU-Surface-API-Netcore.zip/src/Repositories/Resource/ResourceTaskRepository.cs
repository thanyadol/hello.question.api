using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace surflex.netcore22.Repositories
{
    public interface IResourceTaskRepository
    {
        //Task<IEnumerable<ResourceTask>> ListAsync();
        Task<IEnumerable<ResourceActivity>> ListAsync();

        //Task<ResourceTask> GetRecentlyAsync(string id, string type);

        Task<ResourceTask> GetAsync(string id);
        Task<ResourceTask> CreateAsync(ResourceTask resource);
        Task<ResourceTask> UpdateAsync(ResourceTask resource);
        Task<ResourceTask> DeleteAsync(string id);

        //Task<IEnumerable<ResourceTask>> ListAsync(string id);
    }

    /*
     * to controll the user activities
     *
     */

    public class ResourceTaskRepository : IResourceTaskRepository
    {

        private readonly NorthwindContext _context;
        public ResourceTaskRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<ResourceTask> CreateAsync(ResourceTask resource)
        {

            var entity = await _context.ResourceTasks.AddAsync(resource);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<ResourceTask> DeleteAsync(string id)
        {
            //var deletedEntity = await _ResourceTaskEntityTableStorageRepository.DeleteOneAsync(ResourceTaskName, ResourceTaskKey);
            var entity = await _context.ResourceTasks.FindAsync(id);
            _context.ResourceTasks.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<ResourceActivity>> ListAsync()
        {

            var entities = await (from t in _context.ResourceTasks
                                  join l in _context.ResourceLibraries on t.LibraryId equals l.Id
                                  //  where t.ResourceId == id
                                  select new ResourceActivity
                                  {
                                      Id = t.Id,
                                      Created = t.Created.GetValueOrDefault(),

                                      LibraryId = l.Id,
                                      ResourceId = t.ResourceId,

                                      Name = l.Name,
                                      ValueType = l.ValueType,
                                      Value = l.Value,

                                      PlannerType = l.PlannerType,

                                      Formular = l.Formular,
                                      QueryParam = l.QueryParam,

                                      ResourceType = l.ResourceType,

                                      Type = l.Type

                                      //JobId = j.Id

                                  }).ToListAsync();

            return entities;
        }

        public async Task<ResourceTask> UpdateAsync(ResourceTask resource)
        {

            var entity = await _context.ResourceTasks.FindAsync(resource.Id);

            // resource.By = "admin";
            // resource.Date = Utility.CurrentSEAsiaStandardTime();

            _context.ResourceTasks.Update(resource);

            _context.SaveChanges();
            return entity;
        }

        public async Task<ResourceTask> GetAsync(string id)
        {
            var entity = await _context.ResourceTasks.FindAsync(id);
            return entity;
        }



    }
}