using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace surflex.netcore22.Repositories
{

    public interface IResourceRepository
    {
        Task<IEnumerable<Resource>> ListAsync();

        //Task<Resource> GetRecentlyAsync(string id, string type);

        Task<Resource> GetAsync(string id);
        Task<Resource> CreateAsync(Resource resource);
        Task<Resource> UpdateAsync(Resource resource);
        //Task<Resource> DeleteAsync(string id);
    }

    /*
     * to controll the user activities
     *
     */

    public class ResourceRepository : IResourceRepository
    {

        private readonly NorthwindContext _context;
        public ResourceRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<Resource> CreateAsync(Resource resource)
        {

            var entity = await _context.Resources.AddAsync(resource);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<Resource> DeleteAsync(string id)
        {
            //var deletedEntity = await _ResourceEntityTableStorageRepository.DeleteOneAsync(ResourceName, ResourceKey);
            var entity = await _context.Resources.FindAsync(id);
            _context.Resources.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<Resource>> ListAsync()
        {

            var entities = await _context.Resources.ToListAsync();
            //var Resource = _context.Resources.ToList();
            return entities;
        }

        public async Task<Resource> UpdateAsync(Resource resource)
        {

            var entity = await _context.Resources.FindAsync(resource.Id);

            // resource.By = "admin";
            // resource.Date = Utility.CurrentSEAsiaStandardTime();

            _context.Resources.Update(resource);

            _context.SaveChanges();
            return entity;
        }

        public async Task<Resource> GetAsync(string id)
        {
            var entity = await _context.Resources.FindAsync(id);
            return entity;
        }


    }
}