using System; 

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//model
using surflex.netcore22.Models;

using Serilog;
using Microsoft.EntityFrameworkCore;

namespace surflex.netcore22.Repositories
{
    public interface IRiggRepository
    {
        Task<IEnumerable<Rigg>> ListAsync();

        //Task<Rigg> GetRecentlyAsync(string id, string type);

        Task<Rigg> GetAsync(string id);
        Task<Rigg> CreateAsync(Rigg rig);
        Task<Rigg> UpdateAsync(Rigg rig);
        Task<Rigg> DeleteAsync(string id);
    }


    public class RiggRepository : IRiggRepository
    {

        private readonly NorthwindContext _context;
        public RiggRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<Rigg> CreateAsync(Rigg rig)
        {

            var entity = await _context.Riggs.AddAsync(rig);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<Rigg> DeleteAsync(string id)
        {
            //var deletedEntity = await _RiggEntityTableStorageRepository.DeleteOneAsync(RiggName, RiggKey);
            var entity = await _context.Riggs.FindAsync(id);
            _context.Riggs.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<Rigg>> ListAsync()
        {

            var entities = await _context.Riggs.ToListAsync();
            //var Rigg = _context.Riggs.ToList();
            return entities;
        }

        public async Task<Rigg> UpdateAsync(Rigg rig)
        {

            var entity = await _context.Riggs.FindAsync(rig.Id);

            // rig.By = "admin";
            // rig.Date = Utility.CurrentSEAsiaStandardTime();

            _context.Riggs.Update(rig);

            _context.SaveChanges();
            return entity;
        }

        public async Task<Rigg> GetAsync(string id)
        {
            var entity = await _context.Riggs.FindAsync(id);
            return entity;
        }


    }
}