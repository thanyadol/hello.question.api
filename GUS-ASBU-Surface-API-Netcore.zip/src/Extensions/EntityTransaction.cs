
using System; 

using System.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

//model
using surflex.netcore22.Models;

using surflex.netcore22.Repositories;

namespace surflex.netcore22.Extensions
{

    public interface IEntityTransaction : IDisposable
    {
        void Commit();

        void Rollback();
    }

    public class EntityTransaction : IEntityTransaction
    {
        private readonly IDbContextTransaction _transaction;
        //private readonly NorthwindContext _context;

        public EntityTransaction(NorthwindContext context)
        {
            //_context = context ?? throw new ArgumentNullException(nameof(context));
            _transaction = context.Database.BeginTransaction();
        }

        public void Commit()
        {
            _transaction.Commit();
        }

        public void Rollback()
        {
            _transaction.Rollback();
        }

        public void Dispose()
        {
            _transaction.Dispose();
        }
    }
}