using System; 

using System.Collections.Generic;
using Microsoft.Extensions.Configuration;

namespace Example.Api.Providers
{

    public static class CustomConfigProviderExtensions
    {
        public static IConfigurationBuilder AddEncryptedProvider(this IConfigurationBuilder builder)
        {
            return builder.Add(new CustomConfigProvider());
        }
    }

}