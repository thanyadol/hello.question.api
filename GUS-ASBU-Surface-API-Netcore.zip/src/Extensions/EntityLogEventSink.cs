
using System;

using System.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using Serilog.Core;
using Serilog.Events;
using surflex.netcore22.Helpers;

//model
using surflex.netcore22.Models;

using surflex.netcore22.Repositories;

namespace surflex.netcore22.Extensions
{

    public class EntityLogEventSink : ILogEventSink
    {
        // private readonly IDbContextTransaction _transaction;
        private readonly NorthwindContext _context;
        private readonly string _connectStr;
        //private readonly IServiceScopeFactory _serviceScopeFactory;

        public EntityLogEventSink(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public EntityLogEventSink()//IServiceScopeFactory serviceScopeFactory)
        {
            //var connectionstring = "Data Source=BKKHQW12AHSA01;Initial Catalog=SURFACE_DEV;Integrated Security=True";
            var environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            Log.Information("Environment.GetEnvironmentVariable {0}", environment);

            if (!string.IsNullOrEmpty(environment))
            {
                var _config = new ConfigurationBuilder()
                                 .AddJsonFile($"appsettings.{environment}.json", optional: false)
                                 .Build();

                this._connectStr = _config["AppSettings:LoggingMiddleware:ConnectionString"];
            }
            else
            {
                //default
                var _config = new ConfigurationBuilder()
                                 .AddJsonFile($"appsettings.json", optional: false)
                                 .Build();
                this._connectStr = _config["AppSettings:LoggingMiddleware:ConnectionString"];
            }

        }

        //
        // Summary:
        //     Emit the provided log event to the sink.
        //
        // Parameters:
        //   logEvent:
        //     The log event to write.
        public void Emit(LogEvent logg)
        {


            var optionsBuilder = new DbContextOptionsBuilder<NorthwindContext>();
            optionsBuilder.UseSqlServer(_connectStr);

            //  var dbContext = new NorthwindContext(optionsBuilder.Options);

            // Or you can instantiate inside using
            using (var dbContext = new NorthwindContext(optionsBuilder.Options))
            {
                // var types =  logg.Properties["type"]
                var cai = logg.Properties["cai"].ToString().Trim('"');

                var events = new __EFLoggingEvent()
                {
                    Id = Guid.NewGuid(),
                    TimeStamp = logg.Timestamp,
                    Level = logg.Level.GetDescription().ToUpper(),
                    // MessageTemplate = logg.MessageTemplate.Text,
                    Exception = logg.Properties["trace"].ToString().Trim('"'),

                    RequestId = Guid.Parse(logg.Properties["requestId"].ToString().Trim('"')),
                    RequestPath = logg.Properties["requestPath"].ToString().Trim('"'),
                    RequestScheme = logg.Properties["requestScheme"].ToString().Trim('"'),
                    // RequestBody = logg.Properties["RequestBody"].ToString(),
                    CAI = cai,
                    Message = logg.RenderMessage(),
                    Type = logg.Properties["type"].ToString().Trim('"'),

                    Date = Utility.CurrentSEAsiaStandardTime()
                };

                var id = Utility.ToUniqeIdentity(cai);
                var user = dbContext.Users.Find(id);
                if (user != null)
                {
                    events.By = user.Id;
                }

                dbContext.__EFLoggingEvents.AddAsync(events);

                try
                {
                    dbContext.SaveChanges();
                }
                catch (DbUpdateException) { }

            }


        }

    }
}