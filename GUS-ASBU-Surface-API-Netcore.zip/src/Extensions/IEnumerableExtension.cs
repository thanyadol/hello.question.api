using System.Collections.Generic;
using System; 


namespace surflex.netcore22.Extensions
{
    public static class IEnumerableExtension
    {
        public static IEnumerable<T> Props<T>(this IEnumerable<T> self, Action<T> action)
        {
            foreach (var item in self)
            {
                action(item);
                yield return item;
            }
        }

        public static bool ContainSidetrack(this IEnumerable<string> self, string value)
        {
            foreach (var item in self)
            {
                var words = item.Split("-");
                if (value.Contains(words[0]) && value.Contains(words[1]))
                {
                    return true;
                }
            }

            return false;
        }
    }
}