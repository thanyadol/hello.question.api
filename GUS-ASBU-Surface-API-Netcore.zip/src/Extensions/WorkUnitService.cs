
using System; 

using surflex.netcore22.Models;

using surflex.netcore22.Repositories;

namespace surflex.netcore22.Extensions
{

    public interface IWorkUnitService : IDisposable
    {
        IEntityTransaction BeginTransaction();
        //  IActivityRepository SandActivities { get; }
        ISandRepository Sands { get; }
        //  IWellReserveRepository WellReserves { get; }

        IPeriodPriceRepository Prices { get; }
        IPriceGroupRepository PriceGroups { get; }


        //rigg
        IRiggRepository Riggs { get; }
        IRiggRateRepository RiggRates { get; }


        //rigg
        IProductionProfileRepository ProductionProfiles { get; }
        IProductionParamRepository ProductionParams { get; }

        IWellPropertiesRepository WellProperties { get; }

        IProjectWellRepository ProjectWells { get; }

        IProjectDrilledRepository ProjectDrilleds { get; }
        IProjectSpaceRepository ProjectSpaces { get; }

        IWellSpaceRepository WellSpaces { get; }
        IWellDrilledRepository WellDrilleds { get; }
        IWellUndrilledRepository WellUndrilleds { get; }


        //groups
        IRoleAuthorizeRepository RoleAuthorizes { get; }
        // IRoleRepository Roles { get; }
        IProjectAuthorizeRepository ProjectAuthorizes { get; }
        IProjectRepository Projects { get; }
        IUserAuthenRepository UserAuthens { get; }

        //apis
        IApiRepository Apis { get; }
        IPageApiRepository PageApis { get; }
    }

    public class WorkUnitService : IWorkUnitService
    {
        private readonly NorthwindContext _context;

        //  public IActivityRepository SandActivities { get; private set; }
        public ISandRepository Sands { get; private set; }
        // public IWellReserveRepository WellReserves { get; private set; }

        public IPeriodPriceRepository Prices { get; private set; }
        public IPriceGroupRepository PriceGroups { get; private set; }

        public IRiggRepository Riggs { get; private set; }
        public IRiggRateRepository RiggRates { get; private set; }

        public IProductionProfileRepository ProductionProfiles { get; private set; }
        public IProductionParamRepository ProductionParams { get; private set; }

        public IWellPropertiesRepository WellProperties { get; private set; }
        public IProjectWellRepository ProjectWells { get; private set; }
        public IProjectSpaceRepository ProjectSpaces { get; private set; }


        public IWellSpaceRepository WellSpaces { get; private set; }
        public IWellDrilledRepository WellDrilleds { get; private set; }
        public IWellUndrilledRepository WellUndrilleds { get; private set; }


        public IProjectDrilledRepository ProjectDrilleds { get; private set; }

        public IApiRepository Apis { get; private set; }
        public IPageApiRepository PageApis { get; private set; }

        public IRoleAuthorizeRepository RoleAuthorizes { get; private set; }

        //public IRoleRepository Roles { get; private set; }

        public IProjectAuthorizeRepository ProjectAuthorizes { get; private set; }

        public IProjectRepository Projects { get; private set; }

        public IUserAuthenRepository UserAuthens { get; private set; }

        public WorkUnitService(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            //    SandActivities = new ActivityRepository(_context);
            Sands = new SandRepository(_context);
            //  WellReserves = new WellReserveRepository(_context);

            Prices = new PeriodPriceRepository(_context);
            PriceGroups = new PriceGroupRepository(_context);


            Riggs = new RiggRepository(_context);
            RiggRates = new RiggRateRepository(_context);

            ProductionProfiles = new ProductionProfileRepository(_context);
            ProductionParams = new ProductionParamRepository(_context);

            WellProperties = new WellPropertiesRepository(_context);
            ProjectSpaces = new ProjectSpaceRepository(_context);
            ProjectWells = new ProjectWellRepository(_context);

            WellSpaces = new WellSpaceRepository(_context);
            WellDrilleds = new WellDrilledRepository(_context);
            WellUndrilleds = new WellUndrilledRepository(_context);

            ProjectDrilleds = new ProjectDrilledRepository(_context);

            RoleAuthorizes = new RoleAuthorizeRepository(_context);
            // Roles = new RoleRepository(_context);

            ProjectAuthorizes = new ProjectAuthorizeRepository(_context);
            Projects = new ProjectRepository(_context);

            UserAuthens = new UserAuthenRepository(_context);

            Apis = new ApiRepository(_context);
            PageApis = new PageApiRepository(_context);
        }

        public WorkUnitService()
            : this(new NorthwindContext())
        {

        }

        public int Save()
        {
            return _context.SaveChanges();
        }
        public void Dispose()
        {
            _context.Dispose();
        }

        public IEntityTransaction BeginTransaction()
        {
            return new EntityTransaction(_context);
        }
    }
}