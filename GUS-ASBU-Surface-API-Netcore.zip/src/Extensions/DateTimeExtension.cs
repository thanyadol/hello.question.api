using System; 

using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using Newtonsoft.Json;
namespace surflex.netcore22.Extensions

{



    public static class DateTimeExtensions
    {
        public static DateTimeOffset GetOffset(this DateTime localTime1)
        {
            localTime1 = DateTime.SpecifyKind(localTime1, DateTimeKind.Local);
            DateTimeOffset localTime2 = localTime1;
            return localTime2;
        }
    }
}