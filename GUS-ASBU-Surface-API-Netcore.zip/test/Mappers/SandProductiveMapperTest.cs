
using System; 

using System.Collections.Generic;
using System.Text;

using Xunit;
using Moq;

//model
using surflex.netcore22.Models;
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;

namespace surflex.netcore22.test
{

    public class SandMapperTest
    {
        protected SandMapper MapperUnderTest { get; }
        public SandMapperTest()
        {
            MapperUnderTest = new SandMapper();
        }

        public class Mapp : SandMapperTest
        {

            [Fact]
            [Trait("Category", "Mapper")]
            public void Should_return_a_mapped_formatted_Sand()
            {

                // Arrange
                var entity = new SandAsync()
                {
                    Pos = 1,
                    WellName = "LAWC-09",
                    TopMd = 9,
                    BaseMd = "9",
                    GrossSandMT = "27.0",
                    GrossSandVT = "23.0",
                    NetGasVT = "20",
                    NetOilVT = "23.00",
                };

                // Act
                var result = MapperUnderTest.Mapp(entity);

                // Assert
                Assert.Equal("LAWC-09", result.WellName);
                Assert.Equal(9m, result.TopMD);
                Assert.Equal(23m, result.GrossSandVT);
                // Assert.Equal("Hello", result.PlatformId);
                //  Assert.NotNull(result.Created);
            }
        }


        /* public class Reverse : SandMapperTest
                {
                    [Fact]
                    public void Should_return_a_reversed_formatted_Sand()
                    {
                        throw new NotImplementedException();
                    }
                }*/


        public class Mutate : SandMapperTest
        {

            [Fact]
            [Trait("Category", "Mapper")]
            public void Should_return_a_mutated_formatted_Sand()
            {
                //
                // Arrange
                var entity = new Sand()
                {
                    Pos = 1,
                    WellName = "LAWC-09",
                    TopMD = 10,
                    BaseMD = 12,
                    //Id = "1152",
                    Usi = null,
                    Iwd = null,
                    OpenWorksContactCategory = "O",
                    Name = "75-5",
                    SandReserveCategory = null,
                    Status = null,
                    OilP1DNWithoutBC = 0.000m,
                    OilP1DNWithBC = 0.000m,
                    CondensateP1DNWithBC = 2000,
                    FreeGasP1DNWithoutBC = 2000,
                    FreeGasP1DNWithBC = 2000,
                    SolutionGasP1DNWithBC = 0.0000m,
                    HCLiquidWithBC = 200,
                    HCGasWithBC = 200,
                    PayClassification = "New",
                    PressureRFTInPSI = 3000.0m,
                    PressureRFTInPPG = null,
                    PressureEstimatedInitialInPSI = 1500.0m,
                    PressureEstimatedInitialInPPG = null,
                    PressurePPi = 2.0m,
                    FVFProfileBoProfile = null,
                    FVFProfileBgProfile = null,
                    FVFProfileBoProfileId = 33,
                    FVFProfileBgProfileId = 7,
                    FVFProfileBoValue = 0.0m,
                    FVFProfileBgValue = null,
                    AnalogyOilAreaScenarioId = 6041,
                    AnalogyGasAreaScenarioId = 6041,
                    AnalogyOilAreaSetId = 743,
                    AnalogyGasAreaSetId = 743,
                    AnalogyOilAreaName = null,
                    AnalogyOilAreaDiscountFactor = null,
                    AnalogyGasAreaName = null,
                    AnalogyGasAreaDiscountFactor = null,
                    AnalogyOilArea = null,
                    AnalogyGasArea = null,
                    DiscountFactorOilDepletion = null,
                    DiscountFactorGasDepletion = null,
                    DiscountFactorMechanical = 100.0m,
                    DiscountFactorCementQuality = 100.0m,
                    DiscountFactorCO2 = 100.0m,
                    DiscountFactorBC = 100.0m,
                    InPlaceByVolumetricOOIP = 0.0m,
                    InPlaceByVolumetricOGIP = null,
                    RecoveryEfficiencyOil = 0.000m,
                    RecoveryEfficiencyGas = null,
                    GrossIntervalFrom = 10741.0m,
                    GrossIntervalTo = 10768.0m,
                    TopTVDSS = -7549.0m,
                    GocTVDSS = null,
                    HwcTVDSS = null,
                    GrossSandMT = 27.0m,
                    GrossSandVT = 23.0m,
                    NetGasVT = 999m,
                    NetOilVT = 23.00m,
                    MaximumResistivity = 14.00m,
                    Vsh = 15.00m,
                    AvgPor = 18.00m,
                    AvgSw = 71.00m,
                    TG = 232.00m,
                    Remarks = null,
                    AZI = "Y",
                    LookupRenderingOilRF = null,
                    LookupRenderingGasRF = null,
                    LookupRenderingOilBCIncremental = 0.0m,
                    LookupRenderingGasBCIncremental = null,
                    //  DataSource = "FELR",
                    CreatedDate = Convert.ToDateTime("2019-06-13T15:11:15.8077556+07:00"),
                    // UpdatedDate = Convert.ToDateTime("2019-06-13T15:11:15.8077556+07:00")
                };

                // Act
                var result = MapperUnderTest.Mutate(entity);

                // Assert
                Assert.Null(result.HCGasWithBC);
                Assert.Null(result.HCLiquidWithBC);
                Assert.Null(result.OilP1DNWithBC);
                Assert.Null(result.FreeGasP1DNWithBC);

                Assert.Equal(12, result.BaseMD);
                Assert.Equal(10, result.TopMD);
                Assert.Equal("LAWC-09", result.WellName);
                Assert.Equal(999, result.NetGasVT);

            }
        }
    }
}