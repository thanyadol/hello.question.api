
using System; 

using System.Collections.Generic;
using System.Text;

using Xunit;
using Moq;

//model
using surflex.netcore22.Models;
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.Helpers;

namespace surflex.netcore22.test
{

    public class WellHierarchyMapperTest
    {
        protected WellPlannedMapper MapperUnderTest { get; }
        public WellHierarchyMapperTest()
        {
            MapperUnderTest = new WellPlannedMapper();
        }

        public class Mapp : WellHierarchyMapperTest
        {

            [Fact]
            public void Should_return_a_well_formatted_JobProduct()
            {

                // Arrange
                var entity = new WellPlannedAsync()
                {
                    Id = 2019,
                    Name = "SAWH-19",
                    ProjectId = 162,
                    ProjectStatus = "Completed",
                    Project = "SAWH",
                    OperationArea = "SATUN",
                    Asset = "Satun-Funan Team,SPF Asset",
                    Created = Utility.CurrentSEAsiaStandardTime(),
                    //"code": null,
                    StartDate = Utility.CurrentSEAsiaStandardTime(),
                    //"planTdTvd": null
                };

                // Act
                var result = MapperUnderTest.Mapp(entity);

                // Assert
                Assert.Equal("2019", result.Id);
                Assert.Equal("SAWH-19", result.Name);
                //  Assert.NotNull(result.StartDate);
            }


            [Fact]
            public void Should_return_a_mapped_formatted_JobProductAsync()
            {

                // Arrange
                var entity = new WellPlanned()
                {
                    Id = "2019",
                    Name = "SAWH-19",
                    ProjectId = "162",
                    ProjectStatus = "Completed",
                    Project = "SAWH",
                    OperationArea = "SATUN",
                    Asset = "Satun-Funan Team,SPF Asset",
                    Created = Utility.CurrentSEAsiaStandardTime(),
                    //"code": null,
                    StartDate = Utility.CurrentSEAsiaStandardTime(),
                    //"planTdTvd": null
                };


                // Act
                var result = MapperUnderTest.Reverse(entity);

                // Assert
                Assert.Equal(2019, result.Id);
                Assert.Equal("SAWH-19", result.Name);
                Assert.NotNull(result.Project);
            }
        }


        public class Reverse : WellHierarchyMapperTest
        {

            [Fact]
            public void Should_return_a_reversed_formatted_JobProductAsync()
            {

                // Arrange
                var entity = new WellPlanned()
                {
                    Id = "2019",
                    Name = "SAWH-19",
                    ProjectId = "162",
                    ProjectStatus = "Completed",
                    Project = "SAWH",
                    OperationArea = "SATUN",
                    Asset = "Satun-Funan Team,SPF Asset",
                    Created = Utility.CurrentSEAsiaStandardTime(),
                    //"code": null,
                    StartDate = Utility.CurrentSEAsiaStandardTime(),
                    //"planTdTvd": null
                };


                // Act
                var result = MapperUnderTest.Reverse(entity);

                // Assert
                Assert.Equal(2019, result.Id);
                Assert.Equal("SAWH-19", result.Name);
                Assert.NotNull(result.Project);
            }
        }
    }
}