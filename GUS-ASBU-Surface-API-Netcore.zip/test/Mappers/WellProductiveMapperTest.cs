
using System; 

using System.Collections.Generic;
using System.Text;

using Xunit;
using Moq;

//model
using surflex.netcore22.Models;
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;
using surflex.netcore22.Helpers;

namespace surflex.netcore22.test
{
    public class WellProductiveMapperTest
    {
        protected WellProductiveMapper MapperUnderTest { get; }
        public WellProductiveMapperTest()
        {
            MapperUnderTest = new WellProductiveMapper();
        }

        public class Mapp : WellProductiveMapperTest
        {

            [Fact]
            public void Should_return_mapped_mapped_formatted_WellProduct()
            {

                // Arrange
                var entity = new WellProductiveAsync()
                {
                    Name = "SAWH-33",
                    Code = "SAWH-33",
                    StartDate = Utility.CurrentSEAsiaStandardTime(),
                    EndDate = Utility.CurrentSEAsiaStandardTime(),
                    WellPhase = "DRLG",
                    PhaseFirst = "INTCSG1",
                    PhaseSecond = "DRILL",
                    CasingSize = "8 1/2",
                    Activity = null,
                    Status = "Drilling",
                    PlanTdTvd = 8300
                };

                // Act
                var result = MapperUnderTest.Mapp(entity);

                // Assert
                //Assert.Equal("C0B063B0FEDC454687EE1D465B8D8774", result.Id);
                Assert.Equal("SAWH-33", result.Name);
                //    Assert.NotNull(result.Created);
            }


            /* [Fact]
            public void Should_return_a_reverse_formatted_WellProductAsync()
            {

                // Arrange
                var entity = new WellProductive()
                {

                };

                // Act
                var result = MapperUnderTest.Reverse(entity);

                // Assert
                Assert.Equal("C0B063B0FEDC454687EE1D465B8D8774", result.Id);
                Assert.Equal("Hello", result.WellName);
                Assert.NotNull(result.StartDate);
            }*/
        }
    }
}