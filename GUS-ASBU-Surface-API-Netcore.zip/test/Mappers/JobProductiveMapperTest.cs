
using System; 

using System.Collections.Generic;
using System.Text;

using Xunit;
using Moq;

//model
using surflex.netcore22.Models;
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.Helpers;

namespace surflex.netcore22.test
{

    public class JobProductiveMapperTest
    {
        protected JobProductiveMapper MapperUnderTest { get; }
        public JobProductiveMapperTest()
        {
            MapperUnderTest = new JobProductiveMapper();
        }

        public class Mapp : JobProductiveMapperTest
        {

            [Fact]
            public void Should_return_a_mapped_formatted_JobProduct()
            {

                // Arrange
                var entity = new JobProductiveAsync()
                {
                    Id = "C0B063B0FEDC454687EE1D465B8D8774",
                    WellName = "Hello",
                    Status = "ACTIVE",
                    Type = "Drill and Complete",
                    StartDate = Utility.CurrentSEAsiaStandardTime()
                };

                // Act
                var result = MapperUnderTest.Mapp(entity);

                // Assert
                Assert.Equal("C0B063B0FEDC454687EE1D465B8D8774", result.Id);
                Assert.Equal("Hello", result.Name);
                //  Assert.NotNull(result.StartDate);
            }

        }

        public class Reverse : JobProductiveMapperTest
        {

            [Fact]
            public void Should_return_a_reversed_formatted_JobProductAsync()
            {

                // Arrange
                var entity = new JobProductive()
                {
                    Id = "C0B063B0FEDC454687EE1D465B8D8774",
                    Name = "Hello",
                    Status = "ACTIVE",
                    Type = "Drill and Complete",
                    StartDate = Utility.CurrentSEAsiaStandardTime()
                };


                // Act
                var result = MapperUnderTest.Reverse(entity);

                // Assert
                Assert.Equal("C0B063B0FEDC454687EE1D465B8D8774", result.Id);
                Assert.Equal("Hello", result.WellName);
                //   Assert.NotNull(result.StartDate);
            }
        }
    }
}