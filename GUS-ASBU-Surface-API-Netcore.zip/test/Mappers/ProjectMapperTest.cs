
using System; 

using System.Collections.Generic;
using System.Text;

using Xunit;
using Moq;

//model
using surflex.netcore22.Models;
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.APIs.Model;

namespace surflex.netcore22.test
{

    public class ProjectMapperTest
    {
        protected ProjectMapper MapperUnderTest { get; }
        public ProjectMapperTest()
        {
            MapperUnderTest = new ProjectMapper();
        }

        public class Mapp : ProjectMapperTest
        {

            [Fact]
            public void Should_return_a_mapped_formatted_Project()
            {

                // Arrange
                var entity = new ProjectAsync()
                {
                    Id = 181,
                    Name = "Hello",
                    //PlatformId = "BEWE",
                    //Status = "ACTIVE",
                    // CreatedDate = Utility.ToSEAsiaStandardTime()
                };

                // Act
                var result = MapperUnderTest.Mapp(entity);

                // Assert
                Assert.Equal("181", result.Id);
                // Assert.Equal("Hello", result.PlatformId);
                //  Assert.NotNull(result.Created);
            }
        }


        public class Reverse : ProjectMapperTest
        {
            [Fact]
            public void Should_return_a_reversed_formatted_ProjectAsync()
            {

                // Arrange
                var entity = new Project()
                {
                    Id = "108",
                    Name = "Hello",
                    // PlatformId = "77ddc914-e682-4e72-89d3-c994efdf7d5b",
                    Description = "hello a project",
                    //Status = "ACTIVE",
                    // Created = Utility.ToSEAsiaStandardTime()
                };


                // Act
                var result = MapperUnderTest.Reverse(entity);

                // Assert
                Assert.Equal(108, result.Id);
                //Assert.Equal("Hello", result.Platform);
                // Assert.NotNull(result.CreatedDate);
            }
        }
    }
}