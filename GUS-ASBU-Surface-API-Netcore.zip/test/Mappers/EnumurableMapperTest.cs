
using System; 

using System.Collections.Generic;
using System.Text;

using Xunit;
using Moq;

//model
using surflex.netcore22.Models;
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.Helpers;

namespace surflex.netcore22.test
{

    public class EnumerableMapperTest
    {

        public class Mapp : EnumerableMapperTest
        {

            public class JobProductiveTest : Mapp
            {

                protected EnumerableMapper<JobProductiveAsync, JobProductive> MapperUnderTest { get; }
                protected Mock<IMapper<JobProductiveAsync, JobProductive>> jobProductiveMapperMock { get; }

                public JobProductiveTest()
                {
                    jobProductiveMapperMock = new Mock<IMapper<JobProductiveAsync, JobProductive>>();
                    MapperUnderTest = new EnumerableMapper<JobProductiveAsync, JobProductive>(jobProductiveMapperMock.Object);
                }


                [Fact]
                public void Should_delegate_mapping_to_the_single_entity_mapper()
                {
                    // Arrange
                    var job1 = new JobProductiveAsync()
                    {
                        Id = "C0B063B0FEDC454687EE1D465B8D8774",
                        WellName = "Hello",
                        Status = "ACTIVE",
                        Type = "Drill and Complete",
                        StartDate = Utility.CurrentSEAsiaStandardTime()
                    };

                    var job2 = new JobProductiveAsync()
                    {
                        Id = "C0B063B0FEDC454687EE1D465B8D8775",
                        WellName = "Hello",
                        Status = "ACTIVE",
                        Type = "Sidetrack and Complete",
                        StartDate = Utility.CurrentSEAsiaStandardTime()
                    };

                    var jobProductiveAsync = new List<JobProductiveAsync> { job1, job2 };

                    jobProductiveMapperMock
                        .Setup(x => x.Mapp(It.IsAny<JobProductiveAsync>()))
                        .Returns(new JobProductive())
                        .Verifiable();

                    // Act
                    var result = MapperUnderTest.Mapp(jobProductiveAsync);

                    // Assert
                    jobProductiveMapperMock.Verify(x => x.Mapp(job1), Times.Once);
                    jobProductiveMapperMock.Verify(x => x.Mapp(job2), Times.Once);

                }


                [Fact]
                public void Should_delegate_reversing_to_the_single_entity_reverse()
                {
                    // Arrange
                    // Arrange
                    var job1 = new JobProductive()
                    {
                        Id = "C0B063B0FEDC454687EE1D465B8D8774",
                        Name = "Hello",
                        Status = "ACTIVE",
                        Type = "Drill and Complete",
                        StartDate = Utility.CurrentSEAsiaStandardTime()
                    };

                    var job2 = new JobProductive()
                    {
                        Id = "C0B063B0FEDC454687EE1D465B8D8775",
                        Name = "Hello",
                        Status = "ACTIVE",
                        Type = "Sidetrack and Complete",
                        StartDate = Utility.CurrentSEAsiaStandardTime()
                    };

                    var jobProductive = new List<JobProductive> { job1, job2 };

                    jobProductiveMapperMock
                        .Setup(x => x.Reverse(It.IsAny<JobProductive>()))
                        .Returns(new JobProductiveAsync())
                        .Verifiable();

                    // Act
                    var result = MapperUnderTest.Reverse(jobProductive);

                    // Assert
                    jobProductiveMapperMock.Verify(x => x.Reverse(job1), Times.Once);
                    jobProductiveMapperMock.Verify(x => x.Reverse(job2), Times.Once);

                }
            }
        }
    }
}