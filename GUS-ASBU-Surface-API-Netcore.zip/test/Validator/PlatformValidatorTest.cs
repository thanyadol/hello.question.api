
using System; 

using System.Collections.Generic;
using System.Text;

using Xunit;
using Moq;

//model
using surflex.netcore22.Models;
using surflex.netcore22.APIs.Gateway;
using FluentValidation;

using Platform = surflex.netcore22.Models.Platform;
using surflex.netcore22.Validator;

namespace surflex.netcore22.test
{

    public class PlatformValidatorTest
    {
        protected PlatformValidator validateUnderTest { get; }
        public PlatformValidatorTest()
        {
            validateUnderTest = new PlatformValidator();
        }

        [Fact]
        [Trait("Category", "Validate")]
        public void Should_custom_validate_to_the_Platform_entity_for_valid_result()
        {
            // Arrange
            var platform = new Platform()
            {
                //id=0,
                Name = "SAWH",
                WellType = "Gas",
                BcPos = 100,
                BcCompressionRatio = 2.5M,
                PipelinePressure = 424.62M,
                OilPipelinePressureCoeff = 1.005440529079032M,
                GasPipelinePressureCoeff = 1.0084438298854284M,
                GOR = 0,
                CGR = 50.38M
            };

            // Act
            var result = validateUnderTest.Validate(platform);

            // Assert
            Assert.True(result.IsValid);
            Assert.True(result.Errors.Count == 0);

        }

        [Fact]
        [Trait("Category", "Validate")]
        public void Should_custom_validate_to_the_Platform_entity_for_ivalid_result_for_WellType()
        {
            // Arrange
            var platform = new Platform()
            {
                Name = "SAWH",
                WellType = null,
                BcPos = 100,
                BcCompressionRatio = 2.5M,
                PipelinePressure = 424.62M,
                OilPipelinePressureCoeff = 1.005440529079032M,
                GasPipelinePressureCoeff = 1.0084438298854284M,
                GOR = 0,
                CGR = 50.38M
            };

            // Act
            var result = validateUnderTest.Validate(platform);

            // Assert
            Assert.False(result.IsValid);
            Assert.False(result.Errors.Count == 0);
        }

    }

}