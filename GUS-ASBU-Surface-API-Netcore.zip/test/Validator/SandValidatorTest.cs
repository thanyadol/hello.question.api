
using System; 

using System.Collections.Generic;
using System.Text;

using Xunit;
using Moq;

//model
using surflex.netcore22.Models;
using surflex.netcore22.APIs.Gateway;
using FluentValidation;

using Platform = surflex.netcore22.APIs.Model.PlatformAsync;
using surflex.netcore22.Validator;
using FluentValidation.TestHelper;

namespace surflex.netcore22.test
{

    public class SandValidatorTest
    {
        protected SandValidator validateUnderTest { get; }
        public SandValidatorTest()
        {
            validateUnderTest = new SandValidator();
        }

        [Fact]
        [Trait("Category", "Validate")]
        public void Should_custom_validate_to_the_single_entity_for_valid_result()
        {
            // Arrange
            var reserve = new Sand()
            {
                Pos = 1,

                OpenWorksContactCategory = "GWC",
                Name = "56-4",
                SandReserveCategory = null,
                Status = null,

                /* OilP1DNWithoutBC = null,
                OilP1DNWithBC = null,
                CondensateP1DNWithBC = null,
                FreeGasP1DNWithoutBC = null,
                FreeGasP1DNWithBC = null,
                SolutionGasP1DNWithBC = null,
                HCLiquidWithBC = null,
                HCGasWithBC = null,*/

                PayClassification = "New",
                PressureRFTInPSI = 999,
                PressureRFTInPPG = 999,
                PressureEstimatedInitialInPSI = 999,
                PressureEstimatedInitialInPPG = 999,
                PressurePPi = null,
                //FVFProfileBoProfile = "South Arthit",
                //FVFProfileBgProfile = null,
                FVFProfileBoProfileId = null,
                FVFProfileBgProfileId = 37,
                // FVFProfileBoValue = null,
                // FVFProfileBgValue = null,
                AnalogyOilAreaScenarioId = null,
                AnalogyGasAreaScenarioId = 9,
                AnalogyOilAreaSetId = null,
                AnalogyGasAreaSetId = 9,
                //AnalogyOilAreaName = null,
                // AnalogyOilAreaDiscountFactor = null,
                // AnalogyGasAreaName = null,
                // AnalogyGasAreaDiscountFactor = null,
                //AnalogyOilArea = "",
                //AnalogyGasArea = "",
                //DiscountFactorOilDepletion = null,
                //DiscountFactorGasDepletion = null,
                DiscountFactorMechanical = 100,
                DiscountFactorCementQuality = 100,
                DiscountFactorCO2 = 100,
                DiscountFactorBC = 100,
                //InPlaceByVolumetricOOIP = null,
                //InPlaceByVolumetricOGIP = null,
                //RecoveryEfficiencyOil = null,
                //RecoveryEfficiencyGas = null,
                GrossIntervalFrom = 8832,
                GrossIntervalTo = 8875,
                TopTVDSS = -5643,
                BaseTVDSS = null,
                GocTVDSS = 0,
                HwcTVDSS = -5650,
                GrossSandMT = 43,
                GrossSandVT = 41,
                NetGasVT = 7,
                NetOilVT = 0,
                MaximumResistivity = 17,
                Vsh = 11,
                AvgPor = 24,
                AvgSw = 52,
                TG = 110,
                Remarks = "GWC@8840f Pressure 7.30ppg EWM.",
                AZI = "N",

            };

            // Act
            var result = validateUnderTest.Validate(reserve);

            // Assert
            Assert.True(result.IsValid);
            Assert.True(result.Errors.Count == 0);

        }

        [Fact]
        [Trait("Category", "Validate")]
        public void Should_not_have_error_when_OpenWorksContactCategory_is_specified()
        {
            // Arrange
            var reserve = new Sand()
            {
                Pos = 1,

                OpenWorksContactCategory = "GWC",
                Name = "56-4",
                SandReserveCategory = null,
                Status = null,

                /* OilP1DNWithoutBC = null,
                OilP1DNWithBC = null,
                CondensateP1DNWithBC = null,
                FreeGasP1DNWithoutBC = null,
                FreeGasP1DNWithBC = null,
                SolutionGasP1DNWithBC = null,
                HCLiquidWithBC = null,
                HCGasWithBC = null,*/

                PayClassification = "New",
                PressureRFTInPSI = 999,
                PressureRFTInPPG = 999,
                PressureEstimatedInitialInPSI = 999,
                PressureEstimatedInitialInPPG = 999,
                PressurePPi = null,
                //FVFProfileBoProfile = "South Arthit",
                //FVFProfileBgProfile = null,
                FVFProfileBoProfileId = null,
                FVFProfileBgProfileId = 37,
                // FVFProfileBoValue = null,
                // FVFProfileBgValue = null,
                AnalogyOilAreaScenarioId = null,
                AnalogyGasAreaScenarioId = 9,
                AnalogyOilAreaSetId = null,
                AnalogyGasAreaSetId = 9,
                //AnalogyOilAreaName = null,
                // AnalogyOilAreaDiscountFactor = null,
                // AnalogyGasAreaName = null,
                // AnalogyGasAreaDiscountFactor = null,
                //AnalogyOilArea = "",
                //AnalogyGasArea = "",
                //DiscountFactorOilDepletion = null,
                //DiscountFactorGasDepletion = null,
                DiscountFactorMechanical = 100,
                DiscountFactorCementQuality = 100,
                DiscountFactorCO2 = 100,
                DiscountFactorBC = 100,
                //InPlaceByVolumetricOOIP = null,
                //InPlaceByVolumetricOGIP = null,
                //RecoveryEfficiencyOil = null,
                //RecoveryEfficiencyGas = null,
                GrossIntervalFrom = 8832,
                GrossIntervalTo = 8875,
                TopTVDSS = -5643,
                BaseTVDSS = null,
                GocTVDSS = 0,
                HwcTVDSS = -5650,
                GrossSandMT = 43,
                GrossSandVT = 41,
                NetGasVT = 7,
                NetOilVT = 0,
                MaximumResistivity = 17,
                Vsh = 11,
                AvgPor = 24,
                AvgSw = 52,
                TG = 110,
                Remarks = "GWC@8840f Pressure 7.30ppg EWM.",
                AZI = "N",

            };

            validateUnderTest.ShouldNotHaveValidationErrorFor(x => x.OpenWorksContactCategory, reserve);
        }


        [Fact]
        [Trait("Category", "Validate")]
        public void Should_custom_validate_to_the_single_entity_for_invalid_result()
        {
            var reserve = new Sand()
            {
                Pos = 1,

                OpenWorksContactCategory = "OWC",
                Name = "56-4",
                SandReserveCategory = null,
                Status = null,

                PayClassification = "New",
                PressureRFTInPSI = 999,
                PressureRFTInPPG = 999,
                PressureEstimatedInitialInPSI = 999,
                PressureEstimatedInitialInPPG = 999,
                PressurePPi = null,

                FVFProfileBoProfileId = null,

                AnalogyOilAreaScenarioId = null,
                AnalogyGasAreaScenarioId = null,
                AnalogyOilAreaSetId = null,
                AnalogyGasAreaSetId = null,


                DiscountFactorMechanical = 100,
                DiscountFactorCementQuality = 100,
                DiscountFactorCO2 = 100,
                DiscountFactorBC = 100,

                GrossIntervalFrom = 8832,
                GrossIntervalTo = 8875,
                TopTVDSS = -5643,
                BaseTVDSS = null,
                GocTVDSS = 0,
                HwcTVDSS = -5650,
                GrossSandMT = 43,
                GrossSandVT = 41,
                NetGasVT = 7,
                NetOilVT = 0,
                MaximumResistivity = 17,
                Vsh = 11,
                AvgPor = 24,
                AvgSw = 52,
                TG = 110,
                Remarks = "GWC@8840f Pressure 7.30ppg EWM.",
                AZI = "N",

            };

            // Act
            var result = validateUnderTest.Validate(reserve);

            // Assert
            Assert.False(result.IsValid);
            Assert.NotNull(result.Errors);
        }



        [Fact]
        [Trait("Category", "Validate")]
        public void Should_have_error_when_AnalogyGasAreaScenarioId_is_not_specified()
        {
            // Arrange
            var reserve = new Sand()
            {
                Pos = 1,

                OpenWorksContactCategory = "GWC",
                Name = "56-4",
                SandReserveCategory = null,
                Status = null,

                /* OilP1DNWithoutBC = null,
                OilP1DNWithBC = null,
                CondensateP1DNWithBC = null,
                FreeGasP1DNWithoutBC = null,
                FreeGasP1DNWithBC = null,
                SolutionGasP1DNWithBC = null,
                HCLiquidWithBC = null,
                HCGasWithBC = null,*/

                PayClassification = "New",
                PressureRFTInPSI = 999,
                PressureRFTInPPG = 999,
                PressureEstimatedInitialInPSI = 999,
                PressureEstimatedInitialInPPG = 999,
                PressurePPi = null,
                //FVFProfileBoProfile = "South Arthit",
                //FVFProfileBgProfile = null,
                FVFProfileBoProfileId = null,
                FVFProfileBgProfileId = 37,
                // FVFProfileBoValue = null,
                // FVFProfileBgValue = null,
                AnalogyOilAreaScenarioId = null,
                AnalogyGasAreaScenarioId = null,
                AnalogyOilAreaSetId = null,
                AnalogyGasAreaSetId = null,
                //AnalogyOilAreaName = null,
                // AnalogyOilAreaDiscountFactor = null,
                // AnalogyGasAreaName = null,
                // AnalogyGasAreaDiscountFactor = null,
                //AnalogyOilArea = "",
                //AnalogyGasArea = "",
                //DiscountFactorOilDepletion = null,
                //DiscountFactorGasDepletion = null,
                DiscountFactorMechanical = 100,
                DiscountFactorCementQuality = 100,
                DiscountFactorCO2 = 100,
                DiscountFactorBC = 100,
                //InPlaceByVolumetricOOIP = null,
                //InPlaceByVolumetricOGIP = null,
                //RecoveryEfficiencyOil = null,
                //RecoveryEfficiencyGas = null,
                GrossIntervalFrom = 8832,
                GrossIntervalTo = 8875,
                TopTVDSS = -5643,
                BaseTVDSS = null,
                GocTVDSS = 0,
                HwcTVDSS = -5650,
                GrossSandMT = 43,
                GrossSandVT = 41,
                NetGasVT = 7,
                NetOilVT = 0,
                MaximumResistivity = 17,
                Vsh = 11,
                AvgPor = 24,
                AvgSw = 52,
                TG = 110,
                Remarks = "GWC@8840f Pressure 7.30ppg EWM.",
                AZI = "N",

            };

            validateUnderTest.ShouldHaveValidationErrorFor(x => x.AnalogyGasAreaScenarioId, reserve);
        }


        [Fact]
        [Trait("Category", "Validate")]
        public void Should_custom_validate_to_the_single_entity_for_PayClassification_case()
        {
            var reserve = new Sand()
            {
                Pos = 1,

                OpenWorksContactCategory = "OWC",
                Name = "56-4",
                SandReserveCategory = null,
                Status = null,

                PayClassification = "New",
                PressureRFTInPSI = null,
                PressureRFTInPPG = null,
                PressureEstimatedInitialInPSI = null,
                PressureEstimatedInitialInPPG = null,
                PressurePPi = null,

                FVFProfileBoProfileId = null,

                AnalogyOilAreaScenarioId = null,
                AnalogyGasAreaScenarioId = null,
                AnalogyOilAreaSetId = null,
                AnalogyGasAreaSetId = null,


                DiscountFactorMechanical = 100,
                DiscountFactorCementQuality = 100,
                DiscountFactorCO2 = 100,
                DiscountFactorBC = 100,

                GrossIntervalFrom = 8832,
                GrossIntervalTo = 8875,
                TopTVDSS = -5643,
                BaseTVDSS = null,
                GocTVDSS = 0,
                HwcTVDSS = -5650,
                GrossSandMT = 43,
                GrossSandVT = 41,
                NetGasVT = 7,
                NetOilVT = 0,
                MaximumResistivity = 17,
                Vsh = 11,
                AvgPor = 24,
                AvgSw = 52,
                TG = 110,
                Remarks = "GWC@8840f Pressure 7.30ppg EWM.",
                AZI = "N",

            };

            // Act
            var result = validateUnderTest.Validate(reserve);

            // Assert
            Assert.False(result.IsValid);
            Assert.NotNull(result.Errors);
        }



    }

}