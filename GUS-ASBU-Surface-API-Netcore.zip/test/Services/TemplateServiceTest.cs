using Microsoft.AspNetCore.Mvc;

using Microsoft.Extensions.Configuration;
using System; 

using System.Collections.Generic;
using System.Text;

//unittest
using Xunit;
using Moq;


//model
using surflex.netcore22;
//using hello.netcore_22.aws.Controllers;
using surflex.netcore22.Models;
using surflex.netcore22.Services;
using surflex.netcore22.Repositories;
using surflex.netcore22.Exceptions;
using System.Linq;


//apis
using surflex.netcore22.APIs;
using surflex.netcore22.APIs.Model;
using surflex.netcore22.Helpers;

namespace surflex.netcore22.test.Services
{
    public class TemplateServiceTest
    {
        protected TemplateService ServiceUnderTest { get; }
        protected Mock<ITemplateRepository> mockRepo { get; }

        protected Mock<IAttachmentService> mockAttachmentService { get; }

        private readonly string ACTIVE = "ACTIVE";

        //private readonly string HISTORY = "ARCHIVED";

        public TemplateServiceTest()
        {
            mockRepo = new Mock<ITemplateRepository>();
            mockAttachmentService = new Mock<IAttachmentService>();

            var mockConfigure = new ConfigurationBuilder()
             .AddJsonFile("appsetting.mock.json")
             .Build();

            ServiceUnderTest = new TemplateService(mockRepo.Object, mockAttachmentService.Object);
        }

        public class ListAsync : TemplateServiceTest
        {
            private Template[] templates;
            public ListAsync()
            {
                templates = new Template[]
                   {

                    new Template() {
                         Id =  "149cb6f6-4009-4796-a7f8-d0cb8913ea13",
                        AttachmentId =  "4cd4a3c2-36cd-4b2f-9f51-025eb56e1dab",
                        Name = "Master Project DPI Template",
                        Level =  null,
                        Description =  "masterrrrr",
                        TemplateTypeId = "9THBSGYW6M",
                        Status =  "ACTIVE",
                       // Created =  "2019-07-17T17:46:36.543",
                        Key =  null,
                        Rev =  "14a30c9d-80f7-4515-ac81-0b4a78755dff",
                        By = null,
                        StartDate = Utility.CurrentSEAsiaStandardTime(),
                        FinishDate = null
                    },
                    new Template()
                    {
                        Id = "B1DCA896686C21",
                        AttachmentId = "0647GGE647",
                        Name = "Well Decision Making DPI Template",
                        Level = null,
                        Description = "hello",
                        TemplateTypeId = "TEV8GMNGMX",
                        Status = "ARCHIVED",
                        //  Created = "2019-05-09T18:56:09",
                        Key = "1fd62b93-eb96-41e0-b1c1-96787dbd5888",
                        Rev = "43b38ce9-e9a3-45e8-87a1-0d548572f42e",
                        By = "admin",
                        StartDate = Utility.CurrentSEAsiaStandardTime(),
                        FinishDate = Utility.CurrentSEAsiaStandardTime(),
                    },
                            new Template()
                    {
                        Id = "b3403c0f-16e3-44ae-9389-795d00a1805e",
                        AttachmentId = "4cd4a3c2-36cd-4b2f-9f51-025eb56e1dab",
                        Name = "Well Decision Making DPI Template v2.0",
                        Level = null,
                        Description = "hello",
                        TemplateTypeId = "TEV8GMNGMX",
                        Status = "ACTIVE",
                        // Created = "2019-07-17T17:44:03.957",
                        Key = "1fd62b93-eb96-41e0-b1c1-96787dbd5888",
                        Rev =  "54d94c7a-05cf-4e37-b12a-c6ad0e518571",
                        By = null,
                        StartDate = Utility.CurrentSEAsiaStandardTime(),
                        FinishDate = null
                    }

                 };
            }

            [Fact]
            [Trait("Category", "Template")]
            public async void should_return_all_status_template()
            {
                // Arrange
                mockRepo
                    .Setup(x => x.ListAsync())
                                    .ReturnsAsync(templates);

                // Act
                var result = await ServiceUnderTest.ListAsync(null);

                // Assert
                Assert.Equal(templates.ToList(), result);
            }

            [Fact]
            [Trait("Category", "Template")]
            public async void should_return_ACTIVE_status_template()
            {
                // Arrange
                mockRepo
                    .Setup(x => x.ListAsync())
                                    .ReturnsAsync(templates);

                // Act
                var result = await ServiceUnderTest.ListAsync(ACTIVE);

                // Assert
                Assert.Equal(2, result.Count());
            }

            [Fact]
            [Trait("Category", "Template")]
            public async void should_throw_TemplateNotFoundException_when_template_is_null()
            {
                // Arrange
                mockRepo
                    .Setup(x => x.ListAsync())
                                    .ReturnsAsync(default(Template[]));

                // Act & Assert
                await Assert.ThrowsAsync<TemplateNotFoundException>(() => ServiceUnderTest.ListAsync(null));

            }


        }


        public class GetAsync : TemplateServiceTest
        {
            private Template[] templates;
            public GetAsync()
            {
                templates = new Template[]
                {

                    new Template() {
                         Id =  "149cb6f6-4009-4796-a7f8-d0cb8913ea13",
                        AttachmentId =  "4cd4a3c2-36cd-4b2f-9f51-025eb56e1dab",
                        Name = "Master Project DPI Template",
                        Level =  null,
                        Description =  "masterrrrr",
                        TemplateTypeId = "9THBSGYW6M",
                        Status =  "ACTIVE",
                       // Created =  "2019-07-17T17:46:36.543",
                        Key =  null,
                        Rev =  "14a30c9d-80f7-4515-ac81-0b4a78755dff",
                        By = null,
                        StartDate = Utility.CurrentSEAsiaStandardTime(),
                        FinishDate = null
                    },
                    new Template()
                    {
                        Id = "B1DCA896686C21",
                        AttachmentId = "0647GGE647",
                        Name = "Well Decision Making DPI Template",
                        Level = null,
                        Description = "hello",
                        TemplateTypeId = "TEV8GMNGMX",
                        Status = "ARCHIVED",
                        //  Created = "2019-05-09T18:56:09",
                        Key = "1fd62b93-eb96-41e0-b1c1-96787dbd5888",
                        Rev = "43b38ce9-e9a3-45e8-87a1-0d548572f42e",
                        By = "admin",
                        StartDate = Utility.CurrentSEAsiaStandardTime(),
                        FinishDate = Utility.CurrentSEAsiaStandardTime(),
                    },
                            new Template()
                    {
                        Id = "b3403c0f-16e3-44ae-9389-795d00a1805e",
                        AttachmentId = "4cd4a3c2-36cd-4b2f-9f51-025eb56e1dab",
                        Name = "Well Decision Making DPI Template v2.0",
                        Level = null,
                        Description = "hello",
                        TemplateTypeId = "TEV8GMNGMX",
                        Status = "ACTIVE",
                        // Created = "2019-07-17T17:44:03.957",
                        Key = "1fd62b93-eb96-41e0-b1c1-96787dbd5888",
                        Rev =  "54d94c7a-05cf-4e37-b12a-c6ad0e518571",
                        By = null,
                        StartDate = Utility.CurrentSEAsiaStandardTime(),
                        FinishDate = null
                    }

             };
            }

            [Fact]
            [Trait("Category", "Template")]
            public async void should_return_specific_id_template()
            {
                // Arrange
                var template = templates[2];
                var id = "b3403c0f-16e3-44ae-9389-795d00a1805e";

                mockRepo
                    .Setup(x => x.GetAsync(id))
                    .ReturnsAsync(templates[2]);

                // Act
                var result = await ServiceUnderTest.GetAsync(id);

                // template
                Assert.Same(template, result);
            }

            [Fact]
            [Trait("Category", "Template")]
            public async void should_throw_Null_when_template_does_not_exist()
            {
                // Arrange
                var id = "null";

                mockRepo
                    .Setup(x => x.GetAsync(id))
                    .ReturnsAsync(default(Template));

                // Act & Assert
                var result = await ServiceUnderTest.GetAsync(id);

                // await Assert.ThrowsAsync<TemplateNotFoundException>(() => ServiceUnderTest.GetAsync(id));
                // template
                Assert.Null(result);
            }
        }



        public class CreateAsync : TemplateServiceTest
        {
            private Template[] templates;
            public CreateAsync()
            {
                templates = new Template[]
                {
                    new Template() {
                         Id =  "149cb6f6-4009-4796-a7f8-d0cb8913ea13",
                        AttachmentId =  "4cd4a3c2-36cd-4b2f-9f51-025eb56e1dab",
                        Name = "Master Project DPI Template",
                        Level =  null,
                        Description =  "masterrrrr",
                        TemplateTypeId = "9THBSGYW6M",
                        Status =  "ACTIVE",
                       // Created =  "2019-07-17T17:46:36.543",
                        Key =  null,
                        Rev =  "14a30c9d-80f7-4515-ac81-0b4a78755dff",
                        By = null,
                        StartDate = Utility.CurrentSEAsiaStandardTime(),
                        FinishDate = null
                    },
                    new Template()
                    {
                        Id = "B1DCA896686C21",
                        AttachmentId = "0647GGE647",
                        Name = "Well Decision Making DPI Template",
                        Level = null,
                        Description = "hello",
                        TemplateTypeId = "TEV8GMNGMX",
                        Status = "ARCHIVED",
                        //  Created = "2019-05-09T18:56:09",
                        Key = "1fd62b93-eb96-41e0-b1c1-96787dbd5888",
                        Rev = "43b38ce9-e9a3-45e8-87a1-0d548572f42e",
                        By = "admin",
                        StartDate = Utility.CurrentSEAsiaStandardTime(),
                        FinishDate = Utility.CurrentSEAsiaStandardTime(),
                    },
                            new Template()
                    {
                        Id = "b3403c0f-16e3-44ae-9389-795d00a1805e",
                        AttachmentId = "4cd4a3c2-36cd-4b2f-9f51-025eb56e1dab",
                        Name = "Well Decision Making DPI Template v2.0",
                        Level = null,
                        Description = "hello",
                        TemplateTypeId = "TEV8GMNGMX",
                        Status = "ACTIVE",
                        // Created = "2019-07-17T17:44:03.957",
                        Key = "1fd62b93-eb96-41e0-b1c1-96787dbd5888",
                        Rev =  "54d94c7a-05cf-4e37-b12a-c6ad0e518571",
                        By = null,
                        StartDate = Utility.CurrentSEAsiaStandardTime(),
                        FinishDate = null
                    }
             };
            }

            [Fact]
            [Trait("Category", "Template")]
            public async void should_create_and_return_the_new_ACTIVE_Template()
            {
                // Arrange
                var template = templates[2];
                template.Id = null;
                //var id = "b3403c0f-16e3-44ae-9389-795d00a1805e";

                mockRepo
                    .Setup(x => x.CreateAsync(template))
                    .ReturnsAsync(template)
                    .Verifiable();

                mockRepo
                .Setup(x => x.GetAsync(It.IsAny<string>()))
                .ReturnsAsync(template)
                .Verifiable();

                /*  TemplateServiceMock
                     .Setup(x => x.IsTemplateExistsAsync(projectName))
                     .ReturnsAsync(true);*/

                // Act
                var result = await ServiceUnderTest.CreateAsync(template);

                // Assert
                Assert.Same(template, result);
                Assert.Same(template.Key, result.Key);
                Assert.Same(template.Rev, result.Rev);

                mockRepo.Verify(x => x.CreateAsync(template), Times.Once);
                mockRepo.Verify(x => x.UpdateAsync(template), Times.Never);
            }

            [Fact]
            [Trait("Category", "Template")]
            public async void should_create_and_return_the_updated_ACTIVE_Template()
            {
                // Arrange
                var template = templates[2];
                //template.Id = null;
                //var id = "b3403c0f-16e3-44ae-9389-795d00a1805e";


                mockRepo
                    .Setup(x => x.GetAsync(It.IsAny<string>()))
                    .ReturnsAsync(template)
                    .Verifiable();

                //new rev 
                mockRepo
                    .Setup(x => x.CreateAsync(template))
                    .ReturnsAsync(template)
                    .Verifiable();


                mockRepo
                    .Setup(x => x.UpdateAsync(template))
                    .ReturnsAsync(template)
                    .Verifiable();

                /*  TemplateServiceMock
                     .Setup(x => x.IsTemplateExistsAsync(projectName))
                     .ReturnsAsync(true);*/

                // Act
                var result = await ServiceUnderTest.CreateAsync(template);

                // Assert
                //Assert.Same(template, result);
                Assert.Same(template.Key, result.Key);
                //Assert.NotSame(template.Rev, result.Rev);

                mockRepo.Verify(x => x.CreateAsync(template), Times.Once);
            }

        }

        public class UpdateAsync : TemplateServiceTest
        {
            private Template[] templates;
            public UpdateAsync()
            {
                templates = new Template[]
                {
                    new Template() {
                         Id =  "149cb6f6-4009-4796-a7f8-d0cb8913ea13",
                        AttachmentId =  "4cd4a3c2-36cd-4b2f-9f51-025eb56e1dab",
                        Name = "Master Project DPI Template",
                        Level =  null,
                        Description =  "masterrrrr",
                        TemplateTypeId = "9THBSGYW6M",
                        Status =  "ACTIVE",
                       // Created =  "2019-07-17T17:46:36.543",
                        Key =  null,
                        Rev =  "14a30c9d-80f7-4515-ac81-0b4a78755dff",
                        By = null,
                        StartDate = Utility.CurrentSEAsiaStandardTime(),
                        FinishDate = null
                    },
                    new Template()
                    {
                        Id = "B1DCA896686C21",
                        AttachmentId = "0647GGE647",
                        Name = "Well Decision Making DPI Template",
                        Level = null,
                        Description = "hello",
                        TemplateTypeId = "TEV8GMNGMX",
                        Status = "ARCHIVED",
                        //  Created = "2019-05-09T18:56:09",
                        Key = "1fd62b93-eb96-41e0-b1c1-96787dbd5888",
                        Rev = "43b38ce9-e9a3-45e8-87a1-0d548572f42e",
                        By = "admin",
                        StartDate = Utility.CurrentSEAsiaStandardTime(),
                        FinishDate = Utility.CurrentSEAsiaStandardTime(),
                    },
                            new Template()
                    {
                        Id = "b3403c0f-16e3-44ae-9389-795d00a1805e",
                        AttachmentId = "4cd4a3c2-36cd-4b2f-9f51-025eb56e1dab",
                        Name = "Well Decision Making DPI Template v2.0",
                        Level = null,
                        Description = "hello",
                        TemplateTypeId = "TEV8GMNGMX",
                        Status = "ACTIVE",
                        // Created = "2019-07-17T17:44:03.957",
                        Key = "1fd62b93-eb96-41e0-b1c1-96787dbd5888",
                        Rev =  "54d94c7a-05cf-4e37-b12a-c6ad0e518571",
                        By = null,
                        StartDate = Utility.CurrentSEAsiaStandardTime(),
                        FinishDate = null
                    }
             };
            }

            [Fact]
            [Trait("Category", "Template")]
            public async void should_update_and_return_the_updated_Template()
            {
                // Arrange
                var template = templates[2];
                //template.Id = null;
                var id = "b3403c0f-16e3-44ae-9389-795d00a1805e";

                mockRepo
                    .Setup(x => x.GetAsync(id))
                    .ReturnsAsync(template)
                    .Verifiable();


                mockRepo
                    .Setup(x => x.UpdateAsync(template))
                    .ReturnsAsync(template)
                    .Verifiable();

                /*  TemplateServiceMock
                     .Setup(x => x.IsTemplateExistsAsync(projectName))
                     .ReturnsAsync(true);*/

                // Act
                var result = await ServiceUnderTest.UpdateAsync(template);

                // Assert
                Assert.Same(template, result);
            }

            [Fact]
            [Trait("Category", "Template")]
            public async void should_throw_TemplateNotFoundException_when_project_does_not_exist()
            {
                // Arrange
                var template = templates[2];
                template.Id = null;
                var id = "b3403c0f-16e3-44ae-9389-795d00a1805e";

                mockRepo
                .Setup(x => x.GetAsync(id))
                .ReturnsAsync(default(Template));

                //mockRepo
                // .Setup(x => x.UpdateAsync(template))
                // .ThrowsAsync(new TemplateNotFoundException());
                //.Verifiable();

                // Act & Assert
                await Assert.ThrowsAsync<TemplateNotFoundException>(() => ServiceUnderTest.UpdateAsync(template));


            }

        }

    }
}