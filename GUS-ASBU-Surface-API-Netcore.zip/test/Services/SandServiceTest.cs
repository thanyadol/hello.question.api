using Microsoft.AspNetCore.Mvc;

using Microsoft.Extensions.Configuration;
using System; 

using System.Collections.Generic;
using System.Text;

//unittest
using Xunit;
using Moq;


//model
using surflex.netcore22;
//using hello.Netcore_22.aws.Controllers;
using surflex.netcore22.Models;
using surflex.netcore22.Services;
using surflex.netcore22.Repositories;
using surflex.netcore22.Exceptions;
using System.Linq;

//apis
using surflex.netcore22.APIs;
using surflex.netcore22.APIs.Model;

using FluentValidation;
using surflex.netcore22.Helpers;
using FluentValidation.Results;
using surflex.netcore22.Validator;
using surflex.netcore22.APIs.Gateway;

namespace surflex.netcore22.test.Services
{
    public class SandServiceTest
    {
        protected SandService ServiceUnderTest { get; }
        protected Mock<ISandRepository> mockRepo { get; }

        protected AbstractValidator<Sand> mockSandValidator;

        protected Mock<IMapper<IEnumerable<SandAsync>, IEnumerable<Sand>>> mockCollectionMapper { get; }
        protected Mock<IMapper<SandAsync, Sand>> mockSandMapper;

        protected Mock<IProjectWellService> mockProjectWellService;

        protected Mock<IEntityService> mockEntityService;
        protected Mock<IClientService> mockClientService;

        public SandServiceTest()
        {

            mockRepo = new Mock<ISandRepository>();

            mockCollectionMapper = new Mock<IMapper<IEnumerable<SandAsync>, IEnumerable<Sand>>>();
            mockSandMapper = new Mock<IMapper<SandAsync, Sand>>();

            mockSandValidator = new SandValidator();

            mockEntityService = new Mock<IEntityService>();
            mockClientService = new Mock<IClientService>();

            mockProjectWellService = new Mock<IProjectWellService>();

            /* mockUserService
                .Setup(x => x.GetHttpUserAsync())
                .ReturnsAsync(new User { Id = "23a39bbf7c9ee44bda14dbd16bdb30d123c7e998" });
            */

            var mockConfigure = new ConfigurationBuilder()
                    .AddJsonFile("appsetting.mock.json")
                    .Build();

            ServiceUnderTest = new SandService(mockRepo.Object, mockSandMapper.Object, mockCollectionMapper.Object, mockSandValidator,
                                                 mockProjectWellService.Object, mockClientService.Object, mockEntityService.Object);

        }

        public class CreateAsync : SandServiceTest
        {
            private Well well;
            private Sand[] sands;

            public CreateAsync()
            {
                well = new Well()
                {
                    Id = Utility.ToUniqeIdentity("PLWA-17"),
                    Name = "PLWA-17",
                };

                sands = new Sand[] {

                    new Sand()
                    {
                            //WellDrilledId =  "00000000-0000-0000-0000-000000000000",
                            //Id =  "00000000-0000-0000-0000-000000000000",
                            WellName =  "PLWA-17",
                            TopMD =  9102,
                            BaseMD =  9108,
                            Pos =  1,
                            Usi =  "PLWA-17_09102_09108",
                            Iwd =  "703148011700",
                            OpenWorksContactCategory =  "OIL AZI",
                            Name =  "61-6",
                            SandReserveCategory =  null,
                            Status =  null,
                            IsTCRSCompletedCalculated =  false,
                            OilP1DNWithoutBC =  null,
                            OilP1DNWithBC =  null,
                            CondensateP1DNWithBC =  null,
                            FreeGasP1DNWithoutBC =  null,
                            FreeGasP1DNWithBC =  null,
                            SolutionGasP1DNWithBC =  null,
                            HCLiquidWithBC =  null,
                            HCGasWithBC =  null,
                            PayClassification =  "New",
                            PressureRFTInPSI =  null,
                            PressureRFTInPPG =  null,
                            PressureEstimatedInitialInPSI =  null,
                            PressureEstimatedInitialInPPG =  null,
                            PressurePPi =  null,
                            FVFProfileBoProfile =  "B8/32",
                            FVFProfileBgProfile =  null,
                            FVFProfileBoProfileId =  1,
                            FVFProfileBgProfileId =  null,
                            FVFProfileBoValue =  null,
                            FVFProfileBgValue =  null,
                            AnalogyOilAreaScenarioId =  11062,
                            AnalogyGasAreaScenarioId =  null,
                            AnalogyOilAreaSetId =  1335,
                            AnalogyGasAreaSetId =  null,
                            AnalogyOilAreaName =  "PLATONG_WEST PL_Oil_Area_Narrow",
                            AnalogyOilAreaDiscountFactor =  "DF0.8",
                            AnalogyGasAreaName =  null,
                            AnalogyGasAreaDiscountFactor =  null,
                            AnalogyOilArea =  43.081281085737224m,
                            AnalogyGasArea =  null,
                            DiscountFactorOilDepletion =  null,
                            DiscountFactorGasDepletion =  null,
                            DiscountFactorMechanical =  100,
                            DiscountFactorCementQuality =  100,
                            DiscountFactorCO2 =  100,
                            DiscountFactorBC =  100,
                            InPlaceByVolumetricOOIP =  null,
                            InPlaceByVolumetricOGIP =  null,
                            RecoveryEfficiencyOil =  null,
                            RecoveryEfficiencyGas =  null,
                            GrossIntervalFrom =  9102,
                            GrossIntervalTo =  9108,
                            TopTVDSS =  -6163,
                            BaseTVDSS =  -6167,
                            GocTVDSS =  0,
                            HwcTVDSS =  0,
                            GrossSandMT =  6,
                            GrossSandVT =  4,
                            NetGasVT =  0,
                            NetOilVT =  0,
                            MaximumResistivity =  14,
                            Vsh =  0,
                            AvgPor =  19.18m,
                            AvgSw =  0,
                            TG =  163,
                            Fluid =  null,
                            Remarks =  "High Sw. Oil?.",
                            AZI =  "Y",
                            LookupRenderingOilRF =  null,
                            LookupRenderingGasRF =  null,
                            LookupRenderingOilBCIncremental =  null,
                            LookupRenderingGasBCIncremental =  null,
                            EstPhase =  null,
                            IsValidate =  false,
                            ErrorMessage =  null,
                            DataSource =  "AM",
                           // CreatedDate =  "2019-08-27T15:42:31",
                            //UpdatedDate =  "2019-08-27T15:42:31"
                      },

                    new Sand()
                    {
                       // WellDrilledId =  "00000000-0000-0000-0000-000000000000",
                        //Id =  "00000000-0000-0000-0000-000000000000",
                        WellName =  "PLWA-17",
                        TopMD =  11570,
                        BaseMD =  11574,
                        Pos =  1,
                        Usi =  "PLWA-17_11570_11574",
                        Iwd =  "703148011700",
                        OpenWorksContactCategory =  "GAS AZI",
                        Name =  "79-3",
                        SandReserveCategory =  null,
                        Status =  null,
                        IsTCRSCompletedCalculated =  false,
                        OilP1DNWithoutBC =  null,
                        OilP1DNWithBC =  null,
                        CondensateP1DNWithBC =  null,
                        FreeGasP1DNWithoutBC =  null,
                        FreeGasP1DNWithBC =  null,
                        SolutionGasP1DNWithBC =  null,
                        HCLiquidWithBC =  null,
                        HCGasWithBC =  null,
                        PayClassification =  "New",
                        PressureRFTInPSI =  null,
                        PressureRFTInPPG =  null,
                        PressureEstimatedInitialInPSI =  null,
                        PressureEstimatedInitialInPPG =  null,
                        PressurePPi =  null,
                        FVFProfileBoProfile =  null,
                        FVFProfileBgProfile =  "DA",
                        FVFProfileBoProfileId =  null,
                        FVFProfileBgProfileId =  112,
                        FVFProfileBoValue =  null,
                        FVFProfileBgValue =  null,
                        AnalogyOilAreaScenarioId =  null,
                        AnalogyGasAreaScenarioId =  10948,
                        AnalogyOilAreaSetId =  null,
                        AnalogyGasAreaSetId =  1319,
                        AnalogyOilAreaName =  null,
                        AnalogyOilAreaDiscountFactor =  null,
                        AnalogyGasAreaName =  "PLATONG_WEST PL_WT_WTG_AREA_Narrow",
                        AnalogyGasAreaDiscountFactor =  "DF0.8",
                        AnalogyOilArea =  null,
                        AnalogyGasArea =  32.62884961758317m,
                        DiscountFactorOilDepletion =  null,
                        DiscountFactorGasDepletion =  null,
                        DiscountFactorMechanical =  100,
                        DiscountFactorCementQuality =  100,
                        DiscountFactorCO2 =  100,
                        DiscountFactorBC =  100,
                        InPlaceByVolumetricOOIP =  null,
                        InPlaceByVolumetricOGIP =  null,
                        RecoveryEfficiencyOil =  null,
                        RecoveryEfficiencyGas =  null,
                        GrossIntervalFrom =  11570,
                        GrossIntervalTo =  11574,
                        TopTVDSS =  -7930,
                        BaseTVDSS =  -7933,
                        GocTVDSS =  0,
                        HwcTVDSS =  0,
                        GrossSandMT =  4,
                        GrossSandVT =  3,
                        NetGasVT =  0,
                        NetOilVT =  0,
                        MaximumResistivity =  20,
                        Vsh =  0,
                        AvgPor =  15.01m,
                        AvgSw =  0,
                        TG =  337,
                        Fluid =  null,
                        Remarks =  "High Sw. Gas. Thin sand.",
                        AZI =  "Y",
                        LookupRenderingOilRF =  null,
                        LookupRenderingGasRF =  null,
                        LookupRenderingOilBCIncremental =  null,
                        LookupRenderingGasBCIncremental =  null,
                        EstPhase =  null,
                        IsValidate =  false,
                        ErrorMessage =  null,
                        DataSource =  "AM",
                        //CreatedDate =  "2019-08-27T15:42:31",
                        //UpdatedDate =  "2019-08-27T15:42:31"
                    }

                };




            }

            [Fact]
            [Trait("Category", "Sand")]
            public async void should_return_a_created_SAND_and_return_correctly()
            {
                //var id = "46cf564f-a064-4cda-8a28-c3bb81b7ef70";
                var sand = sands[0];


                mockRepo
                    .Setup(x => x.CreateAsync(sand)).ReturnsAsync(sand);

                // Act
                var result = await ServiceUnderTest.CreateAsync(sand);

                // Assert
                Assert.Same(sand, result);

            }


            [Fact]
            [Trait("Category", "Sand")]
            public async void should_throw_SandNotFoundException_when_created_fail()
            {
                //var id = "46cf564f-a064-4cda-8a28-c3bb81b7ef70";
                var sand = sands[0];


                mockRepo
                    .Setup(x => x.CreateAsync(sand)).ReturnsAsync(default(Sand));

                // Act
                // var result = await ServiceUnderTest.CreateAsync(sand);


                // Act & Assert
                await Assert.ThrowsAsync<SandNotFoundException>(() => ServiceUnderTest.CreateAsync(sand));

            }




        }


        public class UpdateAsync : SandServiceTest
        {
            private Well well;
            private Sand[] sands;

            public UpdateAsync()
            {
                well = new Well()
                {
                    Id = Utility.ToUniqeIdentity("PLWA-17"),
                    Name = "PLWA-17",
                };

                sands = new Sand[] {

                    new Sand()
                    {
                            //WellDrilledId =  "00000000-0000-0000-0000-000000000000",
                            //Id =  "00000000-0000-0000-0000-000000000000",
                            WellName =  "PLWA-17",
                            TopMD =  9102,
                            BaseMD =  9108,
                            Pos =  1,
                            Usi =  "PLWA-17_09102_09108",
                            Iwd =  "703148011700",
                            OpenWorksContactCategory =  "OIL AZI",
                            Name =  "61-6",
                            SandReserveCategory =  null,
                            Status =  null,
                            IsTCRSCompletedCalculated =  false,
                            OilP1DNWithoutBC =  null,
                            OilP1DNWithBC =  null,
                            CondensateP1DNWithBC =  null,
                            FreeGasP1DNWithoutBC =  null,
                            FreeGasP1DNWithBC =  null,
                            SolutionGasP1DNWithBC =  null,
                            HCLiquidWithBC =  null,
                            HCGasWithBC =  null,
                            PayClassification =  "New",
                            PressureRFTInPSI =  null,
                            PressureRFTInPPG =  null,
                            PressureEstimatedInitialInPSI =  null,
                            PressureEstimatedInitialInPPG =  null,
                            PressurePPi =  null,
                            FVFProfileBoProfile =  "B8/32",
                            FVFProfileBgProfile =  null,
                            FVFProfileBoProfileId =  1,
                            FVFProfileBgProfileId =  null,
                            FVFProfileBoValue =  null,
                            FVFProfileBgValue =  null,
                            AnalogyOilAreaScenarioId =  11062,
                            AnalogyGasAreaScenarioId =  null,
                            AnalogyOilAreaSetId =  1335,
                            AnalogyGasAreaSetId =  null,
                            AnalogyOilAreaName =  "PLATONG_WEST PL_Oil_Area_Narrow",
                            AnalogyOilAreaDiscountFactor =  "DF0.8",
                            AnalogyGasAreaName =  null,
                            AnalogyGasAreaDiscountFactor =  null,
                            AnalogyOilArea =  43.081281085737224m,
                            AnalogyGasArea =  null,
                            DiscountFactorOilDepletion =  null,
                            DiscountFactorGasDepletion =  null,
                            DiscountFactorMechanical =  100,
                            DiscountFactorCementQuality =  100,
                            DiscountFactorCO2 =  100,
                            DiscountFactorBC =  100,
                            InPlaceByVolumetricOOIP =  null,
                            InPlaceByVolumetricOGIP =  null,
                            RecoveryEfficiencyOil =  null,
                            RecoveryEfficiencyGas =  null,
                            GrossIntervalFrom =  9102,
                            GrossIntervalTo =  9108,
                            TopTVDSS =  -6163,
                            BaseTVDSS =  -6167,
                            GocTVDSS =  0,
                            HwcTVDSS =  0,
                            GrossSandMT =  6,
                            GrossSandVT =  4,
                            NetGasVT =  0,
                            NetOilVT =  0,
                            MaximumResistivity =  14,
                            Vsh =  0,
                            AvgPor =  19.18m,
                            AvgSw =  0,
                            TG =  163,
                            Fluid =  null,
                            Remarks =  "High Sw. Oil?.",
                            AZI =  "Y",
                            LookupRenderingOilRF =  null,
                            LookupRenderingGasRF =  null,
                            LookupRenderingOilBCIncremental =  null,
                            LookupRenderingGasBCIncremental =  null,
                            EstPhase =  null,
                            IsValidate =  false,
                            ErrorMessage =  null,
                            DataSource =  "AM",
                           // UpdatedDate =  "2019-08-27T15:42:31",
                            //UpdatedDate =  "2019-08-27T15:42:31"
                      },

                    new Sand()
                    {
                       // WellDrilledId =  "00000000-0000-0000-0000-000000000000",
                        //Id =  "00000000-0000-0000-0000-000000000000",
                        WellName =  "PLWA-17",
                        TopMD =  11570,
                        BaseMD =  11574,
                        Pos =  1,
                        Usi =  "PLWA-17_11570_11574",
                        Iwd =  "703148011700",
                        OpenWorksContactCategory =  "GAS AZI",
                        Name =  "79-3",
                        SandReserveCategory =  null,
                        Status =  null,
                        IsTCRSCompletedCalculated =  false,
                        OilP1DNWithoutBC =  null,
                        OilP1DNWithBC =  null,
                        CondensateP1DNWithBC =  null,
                        FreeGasP1DNWithoutBC =  null,
                        FreeGasP1DNWithBC =  null,
                        SolutionGasP1DNWithBC =  null,
                        HCLiquidWithBC =  null,
                        HCGasWithBC =  null,
                        PayClassification =  "New",
                        PressureRFTInPSI =  null,
                        PressureRFTInPPG =  null,
                        PressureEstimatedInitialInPSI =  null,
                        PressureEstimatedInitialInPPG =  null,
                        PressurePPi =  null,
                        FVFProfileBoProfile =  null,
                        FVFProfileBgProfile =  "DA",
                        FVFProfileBoProfileId =  null,
                        FVFProfileBgProfileId =  112,
                        FVFProfileBoValue =  null,
                        FVFProfileBgValue =  null,
                        AnalogyOilAreaScenarioId =  null,
                        AnalogyGasAreaScenarioId =  10948,
                        AnalogyOilAreaSetId =  null,
                        AnalogyGasAreaSetId =  1319,
                        AnalogyOilAreaName =  null,
                        AnalogyOilAreaDiscountFactor =  null,
                        AnalogyGasAreaName =  "PLATONG_WEST PL_WT_WTG_AREA_Narrow",
                        AnalogyGasAreaDiscountFactor =  "DF0.8",
                        AnalogyOilArea =  null,
                        AnalogyGasArea =  32.62884961758317m,
                        DiscountFactorOilDepletion =  null,
                        DiscountFactorGasDepletion =  null,
                        DiscountFactorMechanical =  100,
                        DiscountFactorCementQuality =  100,
                        DiscountFactorCO2 =  100,
                        DiscountFactorBC =  100,
                        InPlaceByVolumetricOOIP =  null,
                        InPlaceByVolumetricOGIP =  null,
                        RecoveryEfficiencyOil =  null,
                        RecoveryEfficiencyGas =  null,
                        GrossIntervalFrom =  11570,
                        GrossIntervalTo =  11574,
                        TopTVDSS =  -7930,
                        BaseTVDSS =  -7933,
                        GocTVDSS =  0,
                        HwcTVDSS =  0,
                        GrossSandMT =  4,
                        GrossSandVT =  3,
                        NetGasVT =  0,
                        NetOilVT =  0,
                        MaximumResistivity =  20,
                        Vsh =  0,
                        AvgPor =  15.01m,
                        AvgSw =  0,
                        TG =  337,
                        Fluid =  null,
                        Remarks =  "High Sw. Gas. Thin sand.",
                        AZI =  "Y",
                        LookupRenderingOilRF =  null,
                        LookupRenderingGasRF =  null,
                        LookupRenderingOilBCIncremental =  null,
                        LookupRenderingGasBCIncremental =  null,
                        EstPhase =  null,
                        IsValidate =  false,
                        ErrorMessage =  null,
                        DataSource =  "AM",
                        //UpdatedDate =  "2019-08-27T15:42:31",
                        //UpdatedDate =  "2019-08-27T15:42:31"
                    }

                };

            }

            [Fact]
            [Trait("Category", "Sand")]
            public async void should_return_a_updated_SAND_and_return_correctly()
            {
                //var id = "46cf564f-a064-4cda-8a28-c3bb81b7ef70";
                var sand = sands[0];



                mockRepo
                    .Setup(x => x.GetAsync(sand.Id)).ReturnsAsync(sand);

                mockRepo
                    .Setup(x => x.UpdateAsync(sand)).ReturnsAsync(sand);

                // Act
                var result = await ServiceUnderTest.UpdateAsync(sand);

                // Assert
                Assert.Same(sand, result);

            }


            [Fact]
            [Trait("Category", "Sand")]
            public async void should_throw_SandNotFoundException_when_updated_fail()
            {
                //var id = "46cf564f-a064-4cda-8a28-c3bb81b7ef70";
                var sand = sands[0];



                mockRepo
                    .Setup(x => x.GetAsync(sand.Id)).ReturnsAsync(sand);


                mockRepo
                    .Setup(x => x.UpdateAsync(sand)).ReturnsAsync(default(Sand));

                // Act
                //  var result = await ServiceUnderTest.UpdateAsync(sand);


                // Act & Assert
                await Assert.ThrowsAsync<SandNotFoundException>(() => ServiceUnderTest.UpdateAsync(sand));

            }

        }



        public class GetAsync : SandServiceTest
        {
            private Well well;
            private Sand[] sands;

            public GetAsync()
            {
                well = new Well()
                {
                    Id = Utility.ToUniqeIdentity("PLWA-17"),
                    Name = "PLWA-17",
                };

                sands = new Sand[] {

                    new Sand()
                    {
                            //WellDrilledId =  "00000000-0000-0000-0000-000000000000",
                            //Id =  "00000000-0000-0000-0000-000000000000",
                            WellName =  "PLWA-17",
                            TopMD =  9102,
                            BaseMD =  9108,
                            Pos =  1,
                            Usi =  "PLWA-17_09102_09108",
                            Iwd =  "703148011700",
                            OpenWorksContactCategory =  "OIL AZI",
                            Name =  "61-6",
                            SandReserveCategory =  null,
                            Status =  null,
                            IsTCRSCompletedCalculated =  false,
                            OilP1DNWithoutBC =  null,
                            OilP1DNWithBC =  null,
                            CondensateP1DNWithBC =  null,
                            FreeGasP1DNWithoutBC =  null,
                            FreeGasP1DNWithBC =  null,
                            SolutionGasP1DNWithBC =  null,
                            HCLiquidWithBC =  null,
                            HCGasWithBC =  null,
                            PayClassification =  "New",
                            PressureRFTInPSI =  null,
                            PressureRFTInPPG =  null,
                            PressureEstimatedInitialInPSI =  null,
                            PressureEstimatedInitialInPPG =  null,
                            PressurePPi =  null,
                            FVFProfileBoProfile =  "B8/32",
                            FVFProfileBgProfile =  null,
                            FVFProfileBoProfileId =  1,
                            FVFProfileBgProfileId =  null,
                            FVFProfileBoValue =  null,
                            FVFProfileBgValue =  null,
                            AnalogyOilAreaScenarioId =  11062,
                            AnalogyGasAreaScenarioId =  null,
                            AnalogyOilAreaSetId =  1335,
                            AnalogyGasAreaSetId =  null,
                            AnalogyOilAreaName =  "PLATONG_WEST PL_Oil_Area_Narrow",
                            AnalogyOilAreaDiscountFactor =  "DF0.8",
                            AnalogyGasAreaName =  null,
                            AnalogyGasAreaDiscountFactor =  null,
                            AnalogyOilArea =  43.081281085737224m,
                            AnalogyGasArea =  null,
                            DiscountFactorOilDepletion =  null,
                            DiscountFactorGasDepletion =  null,
                            DiscountFactorMechanical =  100,
                            DiscountFactorCementQuality =  100,
                            DiscountFactorCO2 =  100,
                            DiscountFactorBC =  100,
                            InPlaceByVolumetricOOIP =  null,
                            InPlaceByVolumetricOGIP =  null,
                            RecoveryEfficiencyOil =  null,
                            RecoveryEfficiencyGas =  null,
                            GrossIntervalFrom =  9102,
                            GrossIntervalTo =  9108,
                            TopTVDSS =  -6163,
                            BaseTVDSS =  -6167,
                            GocTVDSS =  0,
                            HwcTVDSS =  0,
                            GrossSandMT =  6,
                            GrossSandVT =  4,
                            NetGasVT =  0,
                            NetOilVT =  0,
                            MaximumResistivity =  14,
                            Vsh =  0,
                            AvgPor =  19.18m,
                            AvgSw =  0,
                            TG =  163,
                            Fluid =  null,
                            Remarks =  "High Sw. Oil?.",
                            AZI =  "Y",
                            LookupRenderingOilRF =  null,
                            LookupRenderingGasRF =  null,
                            LookupRenderingOilBCIncremental =  null,
                            LookupRenderingGasBCIncremental =  null,
                            EstPhase =  null,
                            IsValidate =  false,
                            ErrorMessage =  null,
                            DataSource =  "AM",
                           // GetdDate =  "2019-08-27T15:42:31",
                            //GetdDate =  "2019-08-27T15:42:31"
                      },

                    new Sand()
                    {
                       // WellDrilledId =  "00000000-0000-0000-0000-000000000000",
                        //Id =  "00000000-0000-0000-0000-000000000000",
                        WellName =  "PLWA-17",
                        TopMD =  11570,
                        BaseMD =  11574,
                        Pos =  1,
                        Usi =  "PLWA-17_11570_11574",
                        Iwd =  "703148011700",
                        OpenWorksContactCategory =  "GAS AZI",
                        Name =  "79-3",
                        SandReserveCategory =  null,
                        Status =  null,
                        IsTCRSCompletedCalculated =  false,
                        OilP1DNWithoutBC =  null,
                        OilP1DNWithBC =  null,
                        CondensateP1DNWithBC =  null,
                        FreeGasP1DNWithoutBC =  null,
                        FreeGasP1DNWithBC =  null,
                        SolutionGasP1DNWithBC =  null,
                        HCLiquidWithBC =  null,
                        HCGasWithBC =  null,
                        PayClassification =  "New",
                        PressureRFTInPSI =  null,
                        PressureRFTInPPG =  null,
                        PressureEstimatedInitialInPSI =  null,
                        PressureEstimatedInitialInPPG =  null,
                        PressurePPi =  null,
                        FVFProfileBoProfile =  null,
                        FVFProfileBgProfile =  "DA",
                        FVFProfileBoProfileId =  null,
                        FVFProfileBgProfileId =  112,
                        FVFProfileBoValue =  null,
                        FVFProfileBgValue =  null,
                        AnalogyOilAreaScenarioId =  null,
                        AnalogyGasAreaScenarioId =  10948,
                        AnalogyOilAreaSetId =  null,
                        AnalogyGasAreaSetId =  1319,
                        AnalogyOilAreaName =  null,
                        AnalogyOilAreaDiscountFactor =  null,
                        AnalogyGasAreaName =  "PLATONG_WEST PL_WT_WTG_AREA_Narrow",
                        AnalogyGasAreaDiscountFactor =  "DF0.8",
                        AnalogyOilArea =  null,
                        AnalogyGasArea =  32.62884961758317m,
                        DiscountFactorOilDepletion =  null,
                        DiscountFactorGasDepletion =  null,
                        DiscountFactorMechanical =  100,
                        DiscountFactorCementQuality =  100,
                        DiscountFactorCO2 =  100,
                        DiscountFactorBC =  100,
                        InPlaceByVolumetricOOIP =  null,
                        InPlaceByVolumetricOGIP =  null,
                        RecoveryEfficiencyOil =  null,
                        RecoveryEfficiencyGas =  null,
                        GrossIntervalFrom =  11570,
                        GrossIntervalTo =  11574,
                        TopTVDSS =  -7930,
                        BaseTVDSS =  -7933,
                        GocTVDSS =  0,
                        HwcTVDSS =  0,
                        GrossSandMT =  4,
                        GrossSandVT =  3,
                        NetGasVT =  0,
                        NetOilVT =  0,
                        MaximumResistivity =  20,
                        Vsh =  0,
                        AvgPor =  15.01m,
                        AvgSw =  0,
                        TG =  337,
                        Fluid =  null,
                        Remarks =  "High Sw. Gas. Thin sand.",
                        AZI =  "Y",
                        LookupRenderingOilRF =  null,
                        LookupRenderingGasRF =  null,
                        LookupRenderingOilBCIncremental =  null,
                        LookupRenderingGasBCIncremental =  null,
                        EstPhase =  null,
                        IsValidate =  false,
                        ErrorMessage =  null,
                        DataSource =  "AM",
                        //GetdDate =  "2019-08-27T15:42:31",
                        //GetdDate =  "2019-08-27T15:42:31"
                    }

                };




            }

            [Fact]
            [Trait("Category", "Sand")]
            public async void should_return_a_specific_SAND_with_GUID()
            {
                var id = Guid.NewGuid();
                var sand = sands[0];


                mockRepo
                    .Setup(x => x.GetAsync(id)).ReturnsAsync(sand);

                // Act
                var result = await ServiceUnderTest.GetAsync(id);

                // Assert
                Assert.Same(sand, result);

            }


            [Fact]
            [Trait("Category", "Sand")]
            public async void should_return_null_when_SAND_does_not_exist()
            {
                var id = Guid.NewGuid();
                var sand = sands[0];


                mockRepo
                    .Setup(x => x.GetAsync(id)).ReturnsAsync(default(Sand));

                // Act
                var result = await ServiceUnderTest.GetAsync(id);


                // Act & Assert
                Assert.Null(result);

            }
        }

        public class ListAsync : SandServiceTest
        {
            private Well well;
            private Sand[] sands;

            public ListAsync()
            {
                well = new Well()
                {
                    Id = Utility.ToUniqeIdentity("PLWA-17"),
                    Name = "PLWA-17",
                };

                sands = new Sand[] {

                    new Sand()
                    {
                            //WellDrilledId =  "00000000-0000-0000-0000-000000000000",
                            //Id =  "00000000-0000-0000-0000-000000000000",
                            WellName =  "PLWA-17",
                            TopMD =  9102,
                            BaseMD =  9108,
                            Pos =  1,
                            Usi =  "PLWA-17_09102_09108",
                            Iwd =  "703148011700",
                            OpenWorksContactCategory =  "OIL AZI",
                            Name =  "61-6",
                            SandReserveCategory =  null,
                            Status =  null,
                            IsTCRSCompletedCalculated =  false,
                            OilP1DNWithoutBC =  null,
                            OilP1DNWithBC =  null,
                            CondensateP1DNWithBC =  null,
                            FreeGasP1DNWithoutBC =  null,
                            FreeGasP1DNWithBC =  null,
                            SolutionGasP1DNWithBC =  null,
                            HCLiquidWithBC =  null,
                            HCGasWithBC =  null,
                            PayClassification =  "New",
                            PressureRFTInPSI =  null,
                            PressureRFTInPPG =  null,
                            PressureEstimatedInitialInPSI =  null,
                            PressureEstimatedInitialInPPG =  null,
                            PressurePPi =  null,
                            FVFProfileBoProfile =  "B8/32",
                            FVFProfileBgProfile =  null,
                            FVFProfileBoProfileId =  1,
                            FVFProfileBgProfileId =  null,
                            FVFProfileBoValue =  null,
                            FVFProfileBgValue =  null,
                            AnalogyOilAreaScenarioId =  11062,
                            AnalogyGasAreaScenarioId =  null,
                            AnalogyOilAreaSetId =  1335,
                            AnalogyGasAreaSetId =  null,
                            AnalogyOilAreaName =  "PLATONG_WEST PL_Oil_Area_Narrow",
                            AnalogyOilAreaDiscountFactor =  "DF0.8",
                            AnalogyGasAreaName =  null,
                            AnalogyGasAreaDiscountFactor =  null,
                            AnalogyOilArea =  43.081281085737224m,
                            AnalogyGasArea =  null,
                            DiscountFactorOilDepletion =  null,
                            DiscountFactorGasDepletion =  null,
                            DiscountFactorMechanical =  100,
                            DiscountFactorCementQuality =  100,
                            DiscountFactorCO2 =  100,
                            DiscountFactorBC =  100,
                            InPlaceByVolumetricOOIP =  null,
                            InPlaceByVolumetricOGIP =  null,
                            RecoveryEfficiencyOil =  null,
                            RecoveryEfficiencyGas =  null,
                            GrossIntervalFrom =  9102,
                            GrossIntervalTo =  9108,
                            TopTVDSS =  -6163,
                            BaseTVDSS =  -6167,
                            GocTVDSS =  0,
                            HwcTVDSS =  0,
                            GrossSandMT =  6,
                            GrossSandVT =  4,
                            NetGasVT =  0,
                            NetOilVT =  0,
                            MaximumResistivity =  14,
                            Vsh =  0,
                            AvgPor =  19.18m,
                            AvgSw =  0,
                            TG =  163,
                            Fluid =  null,
                            Remarks =  "High Sw. Oil?.",
                            AZI =  "Y",
                            LookupRenderingOilRF =  null,
                            LookupRenderingGasRF =  null,
                            LookupRenderingOilBCIncremental =  null,
                            LookupRenderingGasBCIncremental =  null,
                            EstPhase =  null,
                            IsValidate =  false,
                            ErrorMessage =  null,
                            DataSource =  "AM",
                           // ListdDate =  "2019-08-27T15:42:31",
                            //ListdDate =  "2019-08-27T15:42:31"
                      },

                    new Sand()
                    {
                       // WellDrilledId =  "00000000-0000-0000-0000-000000000000",
                        //Id =  "00000000-0000-0000-0000-000000000000",
                        WellName =  "PLWA-17",
                        TopMD =  11570,
                        BaseMD =  11574,
                        Pos =  1,
                        Usi =  "PLWA-17_11570_11574",
                        Iwd =  "703148011700",
                        OpenWorksContactCategory =  "GAS AZI",
                        Name =  "79-3",
                        SandReserveCategory =  null,
                        Status =  null,
                        IsTCRSCompletedCalculated =  false,
                        OilP1DNWithoutBC =  null,
                        OilP1DNWithBC =  null,
                        CondensateP1DNWithBC =  null,
                        FreeGasP1DNWithoutBC =  null,
                        FreeGasP1DNWithBC =  null,
                        SolutionGasP1DNWithBC =  null,
                        HCLiquidWithBC =  null,
                        HCGasWithBC =  null,
                        PayClassification =  "New",
                        PressureRFTInPSI =  null,
                        PressureRFTInPPG =  null,
                        PressureEstimatedInitialInPSI =  null,
                        PressureEstimatedInitialInPPG =  null,
                        PressurePPi =  null,
                        FVFProfileBoProfile =  null,
                        FVFProfileBgProfile =  "DA",
                        FVFProfileBoProfileId =  null,
                        FVFProfileBgProfileId =  112,
                        FVFProfileBoValue =  null,
                        FVFProfileBgValue =  null,
                        AnalogyOilAreaScenarioId =  null,
                        AnalogyGasAreaScenarioId =  10948,
                        AnalogyOilAreaSetId =  null,
                        AnalogyGasAreaSetId =  1319,
                        AnalogyOilAreaName =  null,
                        AnalogyOilAreaDiscountFactor =  null,
                        AnalogyGasAreaName =  "PLATONG_WEST PL_WT_WTG_AREA_Narrow",
                        AnalogyGasAreaDiscountFactor =  "DF0.8",
                        AnalogyOilArea =  null,
                        AnalogyGasArea =  32.62884961758317m,
                        DiscountFactorOilDepletion =  null,
                        DiscountFactorGasDepletion =  null,
                        DiscountFactorMechanical =  100,
                        DiscountFactorCementQuality =  100,
                        DiscountFactorCO2 =  100,
                        DiscountFactorBC =  100,
                        InPlaceByVolumetricOOIP =  null,
                        InPlaceByVolumetricOGIP =  null,
                        RecoveryEfficiencyOil =  null,
                        RecoveryEfficiencyGas =  null,
                        GrossIntervalFrom =  11570,
                        GrossIntervalTo =  11574,
                        TopTVDSS =  -7930,
                        BaseTVDSS =  -7933,
                        GocTVDSS =  0,
                        HwcTVDSS =  0,
                        GrossSandMT =  4,
                        GrossSandVT =  3,
                        NetGasVT =  0,
                        NetOilVT =  0,
                        MaximumResistivity =  20,
                        Vsh =  0,
                        AvgPor =  15.01m,
                        AvgSw =  0,
                        TG =  337,
                        Fluid =  null,
                        Remarks =  "High Sw. Gas. Thin sand.",
                        AZI =  "Y",
                        LookupRenderingOilRF =  null,
                        LookupRenderingGasRF =  null,
                        LookupRenderingOilBCIncremental =  null,
                        LookupRenderingGasBCIncremental =  null,
                        EstPhase =  null,
                        IsValidate =  false,
                        ErrorMessage =  null,
                        DataSource =  "AM",
                        //ListdDate =  "2019-08-27T15:42:31",
                        //ListdDate =  "2019-08-27T15:42:31"
                    }

                };




            }

            [Fact]
            [Trait("Category", "Sand")]
            public async void should_return_a_list_of_SAND()
            {
                mockRepo
                    .Setup(x => x.ListAsync()).ReturnsAsync(sands);

                // Act
                var result = await ServiceUnderTest.ListAsync();

                // Assert
                Assert.Equal(sands, result);

            }


            [Fact]
            [Trait("Category", "Sand")]
            public async void should_return_empty_when_SAND_does_not_exist_LIST()
            {

                //mockRepo
                //.Setup(x => x.ListAsync()).ReturnsAsync(default(Sand[]));

                // Act
                var result = await ServiceUnderTest.ListAsync();


                // Act & Assert
                Assert.Empty(result);

            }
        }


        public class CalculateP1DNAsync : SandServiceTest
        {
            private Well well;
            private Sand[] sands;

            private Models.Platform platform;

            public CalculateP1DNAsync()
            {
                well = new Well()
                {
                    Id = Utility.ToUniqeIdentity("PLWA-17"),
                    Name = "PLWA-17",
                };

                sands = new Sand[] {

                    new Sand()
                    {
                            //WellDrilledId =  "00000000-0000-0000-0000-000000000000",
                            //Id =  "00000000-0000-0000-0000-000000000000",
                            WellName =  "PLWA-17",
                            TopMD =  9102,
                            BaseMD =  9108,
                            Pos =  1,
                            Usi =  "PLWA-17_09102_09108",
                            Iwd =  "703148011700",
                            OpenWorksContactCategory =  "OIL AZI",
                            Name =  "61-6",
                            SandReserveCategory =  null,
                            Status =  null,
                            IsTCRSCompletedCalculated =  false,
                            OilP1DNWithoutBC =  null,
                            OilP1DNWithBC =  null,
                            CondensateP1DNWithBC =  null,
                            FreeGasP1DNWithoutBC =  null,
                            FreeGasP1DNWithBC =  null,
                            SolutionGasP1DNWithBC =  null,
                            HCLiquidWithBC =  null,
                            HCGasWithBC =  null,
                            PayClassification =  "New",
                            PressureRFTInPSI =  null,
                            PressureRFTInPPG =  null,
                            PressureEstimatedInitialInPSI =  null,
                            PressureEstimatedInitialInPPG =  null,
                            PressurePPi =  null,
                            FVFProfileBoProfile =  "B8/32",
                            FVFProfileBgProfile =  null,
                            FVFProfileBoProfileId =  1,
                            FVFProfileBgProfileId =  null,
                            FVFProfileBoValue =  null,
                            FVFProfileBgValue =  null,
                            AnalogyOilAreaScenarioId =  11062,
                            AnalogyGasAreaScenarioId =  null,
                            AnalogyOilAreaSetId =  1335,
                            AnalogyGasAreaSetId =  null,
                            AnalogyOilAreaName =  "PLATONG_WEST PL_Oil_Area_Narrow",
                            AnalogyOilAreaDiscountFactor =  "DF0.8",
                            AnalogyGasAreaName =  null,
                            AnalogyGasAreaDiscountFactor =  null,
                            AnalogyOilArea =  43.081281085737224m,
                            AnalogyGasArea =  null,
                            DiscountFactorOilDepletion =  null,
                            DiscountFactorGasDepletion =  null,
                            DiscountFactorMechanical =  100,
                            DiscountFactorCementQuality =  100,
                            DiscountFactorCO2 =  100,
                            DiscountFactorBC =  100,
                            InPlaceByVolumetricOOIP =  null,
                            InPlaceByVolumetricOGIP =  null,
                            RecoveryEfficiencyOil =  null,
                            RecoveryEfficiencyGas =  null,
                            GrossIntervalFrom =  9102,
                            GrossIntervalTo =  9108,
                            TopTVDSS =  -6163,
                            BaseTVDSS =  -6167,
                            GocTVDSS =  0,
                            HwcTVDSS =  0,
                            GrossSandMT =  6,
                            GrossSandVT =  4,
                            NetGasVT =  0,
                            NetOilVT =  0,
                            MaximumResistivity =  14,
                            Vsh =  0,
                            AvgPor =  19.18m,
                            AvgSw =  0,
                            TG =  163,
                            Fluid =  null,
                            Remarks =  "High Sw. Oil?.",
                            AZI =  "Y",
                            LookupRenderingOilRF =  null,
                            LookupRenderingGasRF =  null,
                            LookupRenderingOilBCIncremental =  null,
                            LookupRenderingGasBCIncremental =  null,
                            EstPhase =  null,
                            IsValidate =  false,
                            ErrorMessage =  null,
                            DataSource =  "AM",
                           // ListdDate =  "2019-08-27T15:42:31",
                            //ListdDate =  "2019-08-27T15:42:31"
                      },

                    new Sand()
                    {
                       // WellDrilledId =  "00000000-0000-0000-0000-000000000000",
                        //Id =  "00000000-0000-0000-0000-000000000000",
                        WellName =  "PLWA-17",
                        TopMD =  11570,
                        BaseMD =  11574,
                        Pos =  1,
                        Usi =  "PLWA-17_11570_11574",
                        Iwd =  "703148011700",
                        OpenWorksContactCategory =  "GAS AZI",
                        Name =  "79-3",
                        SandReserveCategory =  null,
                        Status =  null,
                        IsTCRSCompletedCalculated =  false,
                        OilP1DNWithoutBC =  null,
                        OilP1DNWithBC =  null,
                        CondensateP1DNWithBC =  null,
                        FreeGasP1DNWithoutBC =  null,
                        FreeGasP1DNWithBC =  null,
                        SolutionGasP1DNWithBC =  null,
                        HCLiquidWithBC =  null,
                        HCGasWithBC =  null,
                        PayClassification =  "New",
                        PressureRFTInPSI =  null,
                        PressureRFTInPPG =  null,
                        PressureEstimatedInitialInPSI =  null,
                        PressureEstimatedInitialInPPG =  null,
                        PressurePPi =  null,
                        FVFProfileBoProfile =  null,
                        FVFProfileBgProfile =  "DA",
                        FVFProfileBoProfileId =  null,
                        FVFProfileBgProfileId =  112,
                        FVFProfileBoValue =  null,
                        FVFProfileBgValue =  null,
                        AnalogyOilAreaScenarioId =  null,
                        AnalogyGasAreaScenarioId =  10948,
                        AnalogyOilAreaSetId =  null,
                        AnalogyGasAreaSetId =  1319,
                        AnalogyOilAreaName =  null,
                        AnalogyOilAreaDiscountFactor =  null,
                        AnalogyGasAreaName =  "PLATONG_WEST PL_WT_WTG_AREA_Narrow",
                        AnalogyGasAreaDiscountFactor =  "DF0.8",
                        AnalogyOilArea =  null,
                        AnalogyGasArea =  32.62884961758317m,
                        DiscountFactorOilDepletion =  null,
                        DiscountFactorGasDepletion =  null,
                        DiscountFactorMechanical =  100,
                        DiscountFactorCementQuality =  100,
                        DiscountFactorCO2 =  100,
                        DiscountFactorBC =  100,
                        InPlaceByVolumetricOOIP =  null,
                        InPlaceByVolumetricOGIP =  null,
                        RecoveryEfficiencyOil =  null,
                        RecoveryEfficiencyGas =  null,
                        GrossIntervalFrom =  11570,
                        GrossIntervalTo =  11574,
                        TopTVDSS =  -7930,
                        BaseTVDSS =  -7933,
                        GocTVDSS =  0,
                        HwcTVDSS =  0,
                        GrossSandMT =  4,
                        GrossSandVT =  3,
                        NetGasVT =  0,
                        NetOilVT =  0,
                        MaximumResistivity =  20,
                        Vsh =  0,
                        AvgPor =  15.01m,
                        AvgSw =  0,
                        TG =  337,
                        Fluid =  null,
                        Remarks =  "High Sw. Gas. Thin sand.",
                        AZI =  "Y",
                        LookupRenderingOilRF =  null,
                        LookupRenderingGasRF =  null,
                        LookupRenderingOilBCIncremental =  null,
                        LookupRenderingGasBCIncremental =  null,
                        EstPhase =  null,
                        IsValidate =  false,
                        ErrorMessage =  null,
                        DataSource =  "AM",
                        //ListdDate =  "2019-08-27T15:42:31",
                        //ListdDate =  "2019-08-27T15:42:31"
                    }

                };

                platform = new Models.Platform()
                {
                    GOR = 5,
                    CGR = 1,
                    PipelinePressure = 304,
                    BcPos = 0m,
                    BcCompressionRatio = 2.5m,
                    OilPipelinePressureCoeff = 1m,
                    GasPipelinePressureCoeff = 1m,

                    Name = "PLWA-17",
                    WellType = "Oil",
                };
            }

            [Fact]
            [Trait("Category", "Calculated")]
            public async void should_return_a_calculated_SAND_form_TCRS_if_calculate_COMPLETED()
            {
                var sand = sands[0];

                var product = new Product()
                {

                    PlatformName = platform.Name,
                    WellType = platform.WellType,  //platform

                    //fvf
                    BgProfileID = sand.FVFProfileBgProfileId.GetValueOrDefault(),
                    BoProfileID = sand.FVFProfileBoProfileId.GetValueOrDefault(),

                    //platform
                    PipelinePressure = platform.PipelinePressure.GetValueOrDefault(),
                    BcPos = platform.BcPos.GetValueOrDefault(),
                    BcCompressionRatio = platform.BcCompressionRatio.GetValueOrDefault(),
                    OilPipelinePressureCoeff = platform.OilPipelinePressureCoeff.GetValueOrDefault(),
                    GasPipelinePressureCoeff = platform.GasPipelinePressureCoeff.GetValueOrDefault(),

                    //analogy oil 
                    OilAnalogyDatasetId = sand.AnalogyOilAreaSetId.GetValueOrDefault(),
                    OilAnalogyScenarioId = sand.AnalogyOilAreaScenarioId.GetValueOrDefault(),

                    //analogy gas
                    GasAnalogyDatasetId = sand.AnalogyGasAreaSetId.GetValueOrDefault(),
                    GasAnalogyScenarioId = sand.AnalogyGasAreaScenarioId.GetValueOrDefault(),

                    NetGasPay = sand.NetGasVT,
                    NetOilPay = sand.NetOilVT,

                    //mocking
                    WaterSaturation = sand.AvgSw,
                    Porosity = sand.AvgPor,
                    SubseaDepth = Math.Abs(sand.TopTVDSS.GetValueOrDefault()),

                    //openworks
                    PressureRFT = sand.PressureRFTInPSI,
                    PressureInitial = sand.PressureEstimatedInitialInPSI,

                    //sand info
                    MechanicalDf = sand.DiscountFactorMechanical,
                    Co2Df = sand.DiscountFactorCO2,
                    CementQualityDf = sand.DiscountFactorCementQuality,
                    BcDf = sand.DiscountFactorBC,
                    DepletionCategory = sand.PayClassification,

                    //openworks
                    OpenworksReservesCategory = sand.OpenWorksContactCategory,

                    //snad info
                    GOR = platform.GOR.GetValueOrDefault(),
                    CGR = platform.CGR.GetValueOrDefault(),
                };

                mockClientService
                      .Setup(x => x.GetCalculatedProductAsync(It.IsAny<Product>())).ReturnsAsync(product);

                // Act
                var result = await ServiceUnderTest.CalculateP1DNAsync(sand, platform);


                var pressurePPi = product.PressureRFT / product.PressureInitial;

                var hCLiquidWithBC = (sand.CondensateP1DNWithBC + sand.OilP1DNWithBC) * sand.Pos;
                //var hCGasWithBC = Utility.ParseMMBTUToMMSCF(sand.SolutionGasP1DNWithBC.Value + sand.FreeGasP1DNWithBC.Value) * sand.Pos;

                //overide significant with pos
                //  var condensateP1DNWithBC = sand.CondensateP1DNWithBC * sand.Pos;
                var oilP1DNWithBC = sand.OilP1DNWithBC * sand.Pos;

                // Assert
                Assert.Equal(pressurePPi, result.PressurePPi);
                Assert.Equal(hCLiquidWithBC, result.HCLiquidWithBC);

                Assert.Equal(oilP1DNWithBC, result.OilP1DNWithBC);

                //flag
                Assert.True(result.IsTCRSCompletedCalculated);
            }

            [Fact]
            [Trait("Category", "Calculated")]
            public async void should_return_a_NULL_SAND_form_TCRS_if_calculate_FAIL()
            {
                var sand = sands[0];
                sand.PressureEstimatedInitialInPSI = 2;
                sand.PressureRFTInPSI = 1;

                var product = new Product()
                {

                    PlatformName = platform.Name,
                    WellType = platform.WellType,  //platform

                    //fvf
                    BgProfileID = sand.FVFProfileBgProfileId.GetValueOrDefault(),
                    BoProfileID = sand.FVFProfileBoProfileId.GetValueOrDefault(),

                    //platform
                    PipelinePressure = platform.PipelinePressure.GetValueOrDefault(),
                    BcPos = platform.BcPos.GetValueOrDefault(),
                    BcCompressionRatio = platform.BcCompressionRatio.GetValueOrDefault(),
                    OilPipelinePressureCoeff = platform.OilPipelinePressureCoeff.GetValueOrDefault(),
                    GasPipelinePressureCoeff = platform.GasPipelinePressureCoeff.GetValueOrDefault(),

                    //analogy oil 
                    OilAnalogyDatasetId = sand.AnalogyOilAreaSetId.GetValueOrDefault(),
                    OilAnalogyScenarioId = sand.AnalogyOilAreaScenarioId.GetValueOrDefault(),

                    //analogy gas
                    GasAnalogyDatasetId = sand.AnalogyGasAreaSetId.GetValueOrDefault(),
                    GasAnalogyScenarioId = sand.AnalogyGasAreaScenarioId.GetValueOrDefault(),

                    NetGasPay = sand.NetGasVT,
                    NetOilPay = sand.NetOilVT,

                    //mocking
                    WaterSaturation = sand.AvgSw,
                    Porosity = sand.AvgPor,
                    SubseaDepth = Math.Abs(sand.TopTVDSS.GetValueOrDefault()),

                    //openworks
                    PressureRFT = sand.PressureRFTInPSI,
                    PressureInitial = sand.PressureEstimatedInitialInPSI,

                    //sand info
                    MechanicalDf = sand.DiscountFactorMechanical,
                    Co2Df = sand.DiscountFactorCO2,
                    CementQualityDf = sand.DiscountFactorCementQuality,
                    BcDf = sand.DiscountFactorBC,
                    DepletionCategory = sand.PayClassification,

                    //openworks
                    OpenworksReservesCategory = sand.OpenWorksContactCategory,

                    //snad info
                    GOR = platform.GOR.GetValueOrDefault(),
                    CGR = platform.CGR.GetValueOrDefault(),
                };

                mockClientService
                    .Setup(x => x.GetCalculatedProductAsync(It.IsAny<Product>())).ThrowsAsync(new ClientNotSuccessException());

                // Act
                var result = await ServiceUnderTest.CalculateP1DNAsync(sand, platform);


                //var pressurePPi = product.PressureRFT / product.PressureInitial;

                //var hCLiquidWithBC = (sand.CondensateP1DNWithBC + sand.OilP1DNWithBC) * sand.Pos;
                //var hCGasWithBC = Utility.ParseMMBTUToMMSCF(sand.SolutionGasP1DNWithBC.Value + sand.FreeGasP1DNWithBC.Value) * sand.Pos;

                //overide significant with pos
                //  var condensateP1DNWithBC = sand.CondensateP1DNWithBC * sand.Pos;
                //var oilP1DNWithBC = sand.OilP1DNWithBC * sand.Pos;

                // Assert
                // Assert.Null(result.PressurePPi);
                Assert.Null(result.HCLiquidWithBC);

                Assert.Null(result.OilP1DNWithBC);

                //flag
                Assert.False(result.IsTCRSCompletedCalculated);
            }
        }

        public class ClearP1DNAsync : SandServiceTest
        {
            //private Well well;
            private Sand[] sands;

            //private Models.Platform platform;

            public ClearP1DNAsync()
            {

                sands = new Sand[] {

                    new Sand()
                    {
                            //WellDrilledId =  "00000000-0000-0000-0000-000000000000",
                            //Id =  "00000000-0000-0000-0000-000000000000",
                            WellName =  "PLWA-17",
                            TopMD =  9102,
                            BaseMD =  9108,
                            Pos =  1,
                            Usi =  "PLWA-17_09102_09108",
                            Iwd =  "703148011700",
                            OpenWorksContactCategory =  "OIL AZI",
                            Name =  "61-6",
                            SandReserveCategory =  null,
                            Status =  null,
                            IsTCRSCompletedCalculated =  false,
                            OilP1DNWithoutBC =  null,
                            OilP1DNWithBC =  null,
                            CondensateP1DNWithBC =  null,
                            FreeGasP1DNWithoutBC =  null,
                            FreeGasP1DNWithBC =  null,
                            SolutionGasP1DNWithBC =  null,
                            HCLiquidWithBC =  null,
                            HCGasWithBC =  null,
                            PayClassification =  "New",
                            PressureRFTInPSI =  null,
                            PressureRFTInPPG =  null,
                            PressureEstimatedInitialInPSI =  null,
                            PressureEstimatedInitialInPPG =  null,
                            PressurePPi =  null,
                            FVFProfileBoProfile =  "B8/32",
                            FVFProfileBgProfile =  null,
                            FVFProfileBoProfileId =  1,
                            FVFProfileBgProfileId =  null,
                            FVFProfileBoValue =  null,
                            FVFProfileBgValue =  null,
                            AnalogyOilAreaScenarioId =  11062,
                            AnalogyGasAreaScenarioId =  null,
                            AnalogyOilAreaSetId =  1335,
                            AnalogyGasAreaSetId =  null,
                            AnalogyOilAreaName =  "PLATONG_WEST PL_Oil_Area_Narrow",
                            AnalogyOilAreaDiscountFactor =  "DF0.8",
                            AnalogyGasAreaName =  null,
                            AnalogyGasAreaDiscountFactor =  null,
                            AnalogyOilArea =  43.081281085737224m,
                            AnalogyGasArea =  null,
                            DiscountFactorOilDepletion =  null,
                            DiscountFactorGasDepletion =  null,
                            DiscountFactorMechanical =  100,
                            DiscountFactorCementQuality =  100,
                            DiscountFactorCO2 =  100,
                            DiscountFactorBC =  100,
                            InPlaceByVolumetricOOIP =  null,
                            InPlaceByVolumetricOGIP =  null,
                            RecoveryEfficiencyOil =  null,
                            RecoveryEfficiencyGas =  null,
                            GrossIntervalFrom =  9102,
                            GrossIntervalTo =  9108,
                            TopTVDSS =  -6163,
                            BaseTVDSS =  -6167,
                            GocTVDSS =  0,
                            HwcTVDSS =  0,
                            GrossSandMT =  6,
                            GrossSandVT =  4,
                            NetGasVT =  0,
                            NetOilVT =  0,
                            MaximumResistivity =  14,
                            Vsh =  0,
                            AvgPor =  19.18m,
                            AvgSw =  0,
                            TG =  163,
                            Fluid =  null,
                            Remarks =  "High Sw. Oil?.",
                            AZI =  "Y",
                            LookupRenderingOilRF =  null,
                            LookupRenderingGasRF =  null,
                            LookupRenderingOilBCIncremental =  null,
                            LookupRenderingGasBCIncremental =  null,
                            EstPhase =  null,
                            IsValidate =  false,
                            ErrorMessage =  null,
                            DataSource =  "AM",
                           // ListdDate =  "2019-08-27T15:42:31",
                            //ListdDate =  "2019-08-27T15:42:31"
                      },

                    new Sand()
                    {
                       // WellDrilledId =  "00000000-0000-0000-0000-000000000000",
                        //Id =  "00000000-0000-0000-0000-000000000000",
                        WellName =  "PLWA-17",
                        TopMD =  11570,
                        BaseMD =  11574,
                        Pos =  1,
                        Usi =  "PLWA-17_11570_11574",
                        Iwd =  "703148011700",
                        OpenWorksContactCategory =  "GAS AZI",
                        Name =  "79-3",
                        SandReserveCategory =  null,
                        Status =  null,
                        IsTCRSCompletedCalculated =  false,
                        OilP1DNWithoutBC =  null,
                        OilP1DNWithBC =  null,
                        CondensateP1DNWithBC =  null,
                        FreeGasP1DNWithoutBC =  null,
                        FreeGasP1DNWithBC =  null,
                        SolutionGasP1DNWithBC =  null,
                        HCLiquidWithBC =  null,
                        HCGasWithBC =  null,
                        PayClassification =  "New",
                        PressureRFTInPSI =  null,
                        PressureRFTInPPG =  null,
                        PressureEstimatedInitialInPSI =  null,
                        PressureEstimatedInitialInPPG =  null,
                        PressurePPi =  null,
                        FVFProfileBoProfile =  null,
                        FVFProfileBgProfile =  "DA",
                        FVFProfileBoProfileId =  null,
                        FVFProfileBgProfileId =  112,
                        FVFProfileBoValue =  null,
                        FVFProfileBgValue =  null,
                        AnalogyOilAreaScenarioId =  null,
                        AnalogyGasAreaScenarioId =  10948,
                        AnalogyOilAreaSetId =  null,
                        AnalogyGasAreaSetId =  1319,
                        AnalogyOilAreaName =  null,
                        AnalogyOilAreaDiscountFactor =  null,
                        AnalogyGasAreaName =  "PLATONG_WEST PL_WT_WTG_AREA_Narrow",
                        AnalogyGasAreaDiscountFactor =  "DF0.8",
                        AnalogyOilArea =  null,
                        AnalogyGasArea =  32.62884961758317m,
                        DiscountFactorOilDepletion =  null,
                        DiscountFactorGasDepletion =  null,
                        DiscountFactorMechanical =  100,
                        DiscountFactorCementQuality =  100,
                        DiscountFactorCO2 =  100,
                        DiscountFactorBC =  100,
                        InPlaceByVolumetricOOIP =  null,
                        InPlaceByVolumetricOGIP =  null,
                        RecoveryEfficiencyOil =  null,
                        RecoveryEfficiencyGas =  null,
                        GrossIntervalFrom =  11570,
                        GrossIntervalTo =  11574,
                        TopTVDSS =  -7930,
                        BaseTVDSS =  -7933,
                        GocTVDSS =  0,
                        HwcTVDSS =  0,
                        GrossSandMT =  4,
                        GrossSandVT =  3,
                        NetGasVT =  0,
                        NetOilVT =  0,
                        MaximumResistivity =  20,
                        Vsh =  0,
                        AvgPor =  15.01m,
                        AvgSw =  0,
                        TG =  337,
                        Fluid =  null,
                        Remarks =  "High Sw. Gas. Thin sand.",
                        AZI =  "Y",
                        LookupRenderingOilRF =  null,
                        LookupRenderingGasRF =  null,
                        LookupRenderingOilBCIncremental =  null,
                        LookupRenderingGasBCIncremental =  null,
                        EstPhase =  null,
                        IsValidate =  false,
                        ErrorMessage =  null,
                        DataSource =  "AM",
                        //ListdDate =  "2019-08-27T15:42:31",
                        //ListdDate =  "2019-08-27T15:42:31"
                    }

                };
            }

            [Fact]
            [Trait("Category", "Sand")]
            public async void should_return_a_mutated_null_calculated_result_of_SAND()
            {
                var sand = sands[0];

                mockSandMapper
                    .Setup(x => x.Mutate(sand)).Returns(sand);

                // Act
                var result = await ServiceUnderTest.ClearP1DNAsync(sand);

                Assert.NotNull(result);

            }

        }

        ////////////////////////////////////////////
        public class SynceAsync : SandServiceTest
        {
            private Well well;
            private Sand[] sands;

            private Models.Platform platform;

            public SynceAsync()
            {
                well = new Well()
                {
                    Id = Utility.ToUniqeIdentity("PLWA-17"),
                    Name = "PLWA-17",
                };

                sands = new Sand[] {

                    new Sand()
                    {
                            //WellDrilledId =  "00000000-0000-0000-0000-000000000000",
                            //Id =  "00000000-0000-0000-0000-000000000000",
                            WellName =  "PLWA-17",
                            TopMD =  9102,
                            BaseMD =  9108,
                            Pos =  1,
                            Usi =  "PLWA-17_09102_09108",
                            Iwd =  "703148011700",
                            OpenWorksContactCategory =  "OIL AZI",
                            Name =  "61-6",
                            SandReserveCategory =  null,
                            Status =  null,
                            IsTCRSCompletedCalculated =  false,
                            OilP1DNWithoutBC =  null,
                            OilP1DNWithBC =  null,
                            CondensateP1DNWithBC =  null,
                            FreeGasP1DNWithoutBC =  null,
                            FreeGasP1DNWithBC =  null,
                            SolutionGasP1DNWithBC =  null,
                            HCLiquidWithBC =  null,
                            HCGasWithBC =  null,
                            PayClassification =  "New",
                            PressureRFTInPSI =  null,
                            PressureRFTInPPG =  null,
                            PressureEstimatedInitialInPSI =  null,
                            PressureEstimatedInitialInPPG =  null,
                            PressurePPi =  null,
                            FVFProfileBoProfile =  "B8/32",
                            FVFProfileBgProfile =  null,
                            FVFProfileBoProfileId =  1,
                            FVFProfileBgProfileId =  null,
                            FVFProfileBoValue =  null,
                            FVFProfileBgValue =  null,
                            AnalogyOilAreaScenarioId =  11062,
                            AnalogyGasAreaScenarioId =  null,
                            AnalogyOilAreaSetId =  1335,
                            AnalogyGasAreaSetId =  null,
                            AnalogyOilAreaName =  "PLATONG_WEST PL_Oil_Area_Narrow",
                            AnalogyOilAreaDiscountFactor =  "DF0.8",
                            AnalogyGasAreaName =  null,
                            AnalogyGasAreaDiscountFactor =  null,
                            AnalogyOilArea =  43.081281085737224m,
                            AnalogyGasArea =  null,
                            DiscountFactorOilDepletion =  null,
                            DiscountFactorGasDepletion =  null,
                            DiscountFactorMechanical =  100,
                            DiscountFactorCementQuality =  100,
                            DiscountFactorCO2 =  100,
                            DiscountFactorBC =  100,
                            InPlaceByVolumetricOOIP =  null,
                            InPlaceByVolumetricOGIP =  null,
                            RecoveryEfficiencyOil =  null,
                            RecoveryEfficiencyGas =  null,
                            GrossIntervalFrom =  9102,
                            GrossIntervalTo =  9108,
                            TopTVDSS =  -6163,
                            BaseTVDSS =  -6167,
                            GocTVDSS =  0,
                            HwcTVDSS =  0,
                            GrossSandMT =  6,
                            GrossSandVT =  4,
                            NetGasVT =  0,
                            NetOilVT =  0,
                            MaximumResistivity =  14,
                            Vsh =  0,
                            AvgPor =  19.18m,
                            AvgSw =  0,
                            TG =  163,
                            Fluid =  null,
                            Remarks =  "High Sw. Oil?.",
                            AZI =  "Y",
                            LookupRenderingOilRF =  null,
                            LookupRenderingGasRF =  null,
                            LookupRenderingOilBCIncremental =  null,
                            LookupRenderingGasBCIncremental =  null,
                            EstPhase =  null,
                            IsValidate =  false,
                            ErrorMessage =  null,
                            DataSource =  "AM",
                           // ListdDate =  "2019-08-27T15:42:31",
                            //ListdDate =  "2019-08-27T15:42:31"
                      },

                    new Sand()
                    {
                       // WellDrilledId =  "00000000-0000-0000-0000-000000000000",
                        //Id =  "00000000-0000-0000-0000-000000000000",
                        WellName =  "PLWA-17",
                        TopMD =  11570,
                        BaseMD =  11574,
                        Pos =  1,
                        Usi =  "PLWA-17_11570_11574",
                        Iwd =  "703148011700",
                        OpenWorksContactCategory =  "GAS AZI",
                        Name =  "79-3",
                        SandReserveCategory =  null,
                        Status =  null,
                        IsTCRSCompletedCalculated =  false,
                        OilP1DNWithoutBC =  null,
                        OilP1DNWithBC =  null,
                        CondensateP1DNWithBC =  null,
                        FreeGasP1DNWithoutBC =  null,
                        FreeGasP1DNWithBC =  null,
                        SolutionGasP1DNWithBC =  null,
                        HCLiquidWithBC =  null,
                        HCGasWithBC =  null,
                        PayClassification =  "New",
                        PressureRFTInPSI =  null,
                        PressureRFTInPPG =  null,
                        PressureEstimatedInitialInPSI =  null,
                        PressureEstimatedInitialInPPG =  null,
                        PressurePPi =  null,
                        FVFProfileBoProfile =  null,
                        FVFProfileBgProfile =  "DA",
                        FVFProfileBoProfileId =  null,
                        FVFProfileBgProfileId =  112,
                        FVFProfileBoValue =  null,
                        FVFProfileBgValue =  null,
                        AnalogyOilAreaScenarioId =  null,
                        AnalogyGasAreaScenarioId =  10948,
                        AnalogyOilAreaSetId =  null,
                        AnalogyGasAreaSetId =  1319,
                        AnalogyOilAreaName =  null,
                        AnalogyOilAreaDiscountFactor =  null,
                        AnalogyGasAreaName =  "PLATONG_WEST PL_WT_WTG_AREA_Narrow",
                        AnalogyGasAreaDiscountFactor =  "DF0.8",
                        AnalogyOilArea =  null,
                        AnalogyGasArea =  32.62884961758317m,
                        DiscountFactorOilDepletion =  null,
                        DiscountFactorGasDepletion =  null,
                        DiscountFactorMechanical =  100,
                        DiscountFactorCementQuality =  100,
                        DiscountFactorCO2 =  100,
                        DiscountFactorBC =  100,
                        InPlaceByVolumetricOOIP =  null,
                        InPlaceByVolumetricOGIP =  null,
                        RecoveryEfficiencyOil =  null,
                        RecoveryEfficiencyGas =  null,
                        GrossIntervalFrom =  11570,
                        GrossIntervalTo =  11574,
                        TopTVDSS =  -7930,
                        BaseTVDSS =  -7933,
                        GocTVDSS =  0,
                        HwcTVDSS =  0,
                        GrossSandMT =  4,
                        GrossSandVT =  3,
                        NetGasVT =  0,
                        NetOilVT =  0,
                        MaximumResistivity =  20,
                        Vsh =  0,
                        AvgPor =  15.01m,
                        AvgSw =  0,
                        TG =  337,
                        Fluid =  null,
                        Remarks =  "High Sw. Gas. Thin sand.",
                        AZI =  "Y",
                        LookupRenderingOilRF =  null,
                        LookupRenderingGasRF =  null,
                        LookupRenderingOilBCIncremental =  null,
                        LookupRenderingGasBCIncremental =  null,
                        EstPhase =  null,
                        IsValidate =  false,
                        ErrorMessage =  null,
                        DataSource =  "AM",
                        //ListdDate =  "2019-08-27T15:42:31",
                        //ListdDate =  "2019-08-27T15:42:31"
                    }

                };

                platform = new Models.Platform()
                {
                    GOR = 5,
                    CGR = 1,
                    PipelinePressure = 304,
                    BcPos = 0m,
                    BcCompressionRatio = 2.5m,
                    OilPipelinePressureCoeff = 1m,
                    GasPipelinePressureCoeff = 1m,

                    Name = "PLWA-17",
                    WellType = "Oil",
                };
            }

            [Fact]
            [Trait("Category", "SYNCE")]
            public async void should_return_a_SYNCE_SAND_form_UIDM_with_SOME_default_attributes()
            {
                var sand = sands[0];
                sand.Fluid = "Gas";

                var name = "PLWA-17";
                var project = "PLWA_18B";

                var analogy = new WellAnalogy()
                {
                    GasAnalogyDataSetID = 99,
                    GasArea = 9999m
                };

                var info = new Usi()
                {
                    Co2DF = 99m
                };

                // var usi = "PLWA-17_09102_09108";

                mockEntityService
                        .Setup(x => x.ListSandAsync(name)).ReturnsAsync(new SandAsync[] { new SandAsync() });

                mockCollectionMapper
                            .Setup(x => x.Mapp(It.IsAny<SandAsync[]>())).Returns(sands);

                mockClientService
                            .Setup(x => x.GetSandInfoAsync(It.IsAny<string>())).ReturnsAsync(info);

                mockProjectWellService
                                .Setup(x => x.GetCurrentlyAttributeAsync(project)).ThrowsAsync(new ProjectAttributeNotFoundException());


                // Act
                var result = await ServiceUnderTest.SynceAsync(name, project, analogy);
                var entity = result.FirstOrDefault();

                Assert.Equal(analogy.GasAnalogyDataSetID, entity.AnalogyGasAreaSetId);
                //  Assert.Null(entity.AnalogyOilArea);

                Assert.Equal(info.Co2DF, entity.DiscountFactorCO2);

                Assert.Equal(1, entity.FVFProfileBoProfileId);
            }


            [Fact]
            [Trait("Category", "SYNCE")]
            public async void should_return_a_SYNCE_SAND_form_UIDM_with_BOBG_Defaulr_from_TCRS()
            {
                var sand = sands[0];
                var name = "PLWA-17";
                var project = "PLWA_18B";

                var analogy = new WellAnalogy()
                {
                    GasAnalogyDataSetID = 99,
                    OilArea = 9999m
                };

                var info = new Usi()
                {
                    Co2DF = 99m
                };

                var attribute = new ProjectAttribute()
                {
                    BoProfileId = 8888,

                };

                var factors = new Factor[]
                {
                new Factor() {FVFProfileName = "8888", FVFProfileID  = 8888 },
                new Factor() {FVFProfileName = "7777", FVFProfileID  = 7777 },
                new Factor() {FVFProfileName = "6666", FVFProfileID  = 6666 }
                };

                //  var usi = "PLWA-17_09102_09108";

                mockEntityService.Setup(x => x.ListSandAsync(name)).ReturnsAsync(new SandAsync[] { new SandAsync() });

                mockCollectionMapper
                            .Setup(x => x.Mapp(It.IsAny<SandAsync[]>())).Returns(sands);

                mockClientService.Setup(x => x.GetSandInfoAsync(It.IsAny<string>())).ReturnsAsync(info);

                mockProjectWellService
                                .Setup(x => x.GetCurrentlyAttributeAsync(project)).ReturnsAsync(attribute);

                mockClientService
                            .Setup(x => x.ListFactorProfileAsync("bo")).ReturnsAsync(factors);


                // Act
                var result = await ServiceUnderTest.SynceAsync(name, project, analogy);
                var entity = result.FirstOrDefault();

                Assert.Equal(8888, entity.FVFProfileBoProfileId);

            }


            [Fact]
            [Trait("Category", "SYNCE")]
            public async void should_return_SandNotFoundException__if_UIDM_SAND_does_not_exist()
            {
                var sand = sands[0];
                var name = "PLWA-17";
                var project = "PLWA_18B";

                var analogy = new WellAnalogy()
                {
                    GasAnalogyDataSetID = 99,
                    OilArea = 9999m
                };

                var info = new Usi()
                {
                    Co2DF = 99m
                };

                var attribute = new ProjectAttribute()
                {
                    BoProfileId = 8888,

                };

                var factors = new Factor[]
                {
                new Factor() {FVFProfileName = "8888", FVFProfileID  = 8888 },
                new Factor() {FVFProfileName = "7777", FVFProfileID  = 7777 },
                new Factor() {FVFProfileName = "6666", FVFProfileID  = 6666 }
                };

                //var usi = "PLWA-17_09102_09108";

                // mockEntityService.Setup(x => x.ListSandAsync(name)).ReturnsAsync(new SandAsync[] { new SandAsync() });

                mockCollectionMapper
                            .Setup(x => x.Mapp(It.IsAny<SandAsync[]>())).Returns(sands);

                mockClientService.Setup(x => x.GetSandInfoAsync(It.IsAny<string>())).ReturnsAsync(info);


                mockProjectWellService
                                .Setup(x => x.GetCurrentlyAttributeAsync(project)).ReturnsAsync(attribute);

                mockClientService
                            .Setup(x => x.ListFactorProfileAsync("bo")).ReturnsAsync(factors);

                // Act
                //var result = await ServiceUnderTest.SynceAsync(name, project, analogy);
                // var entity = result.FirstOrDefault();

                // Act & Assert
                await Assert.ThrowsAsync<SandNotFoundException>(() => ServiceUnderTest.SynceAsync(name, project, analogy));
            }



        }
    }


}



