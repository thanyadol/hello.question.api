using Microsoft.AspNetCore.Mvc;

using Microsoft.Extensions.Configuration;
using System; 

using System.Collections.Generic;
using System.Text;

//unittest
using Xunit;
using Moq;


//model
using surflex.netcore22;
//using hello.netcore_22.aws.Controllers;
using surflex.netcore22.Models;
using surflex.netcore22.Services;
using surflex.netcore22.Repositories;
using surflex.netcore22.Exceptions;
using System.Linq;


//apis
using surflex.netcore22.APIs;
using surflex.netcore22.APIs.Model;
using surflex.netcore22.Extensions;
using System.Data;
using surflex.netcore22.Helpers;
using FluentValidation;
using surflex.netcore22.APIs.Gateway;
using surflex.netcore22.Validator;

namespace surflex.netcore22.test.Services
{
    public class PriceServiceTest
    {
        protected PriceService ServiceUnderTest { get; }
        protected Mock<IPriceRepository> mockRepo { get; }

        protected Mock<IPriceGroupRepository> mockGroupRepo { get; }

        protected Mock<IPathFinderService> mockPathFinder;
        protected Mock<IAreaService> mockAreaService;

        protected Mock<ITemplateService> mockTemplateService;

        protected Mock<IAttachmentService> mockAttachementService;
        protected Mock<IEntityTransaction> mockEntityTransaction;
        protected Mock<IWorkUnitService> mockWorkUnit;

        // protected TemplateValidator templateValidator;

        public PriceServiceTest()
        {
            mockRepo = new Mock<IPriceRepository>();
            mockGroupRepo = new Mock<IPriceGroupRepository>();
            mockPathFinder = new Mock<IPathFinderService>();
            mockAreaService = new Mock<IAreaService>();
            mockAttachementService = new Mock<IAttachmentService>();

            mockEntityTransaction = new Mock<IEntityTransaction>();
            mockWorkUnit = new Mock<IWorkUnitService>();

            mockTemplateService = new Mock<ITemplateService>();

            // templateValidator = new TemplateValidator();


            var mockConfigure = new ConfigurationBuilder()
             .AddJsonFile("appsetting.mock.json")
             .Build();

            ServiceUnderTest = new PriceService(mockRepo.Object, mockGroupRepo.Object, //mockPathFinder.Object,
                                                    mockAreaService.Object, mockWorkUnit.Object, mockAttachementService.Object,
                                                    mockTemplateService.Object);//, templateValidator);
        }

        public class ListAsync : PriceServiceTest
        {
            private Price[] prices;
            public ListAsync()
            {

                prices = new Price[]
              {

                    new Price() {
                            Id =  Guid.Parse("0002320b-b0e3-493c-82a6-6abfaec7c0ed"),
                            PriceId = Guid.Parse("41fabf2d-4432-4fa8-acb9-a7058cb506d9"),
                            Value = 137.0m,
                            Year =  2048,
                         Created = Utility.CurrentSEAsiaStandardTime()
                        },
                    new Price() {
                            Id =  Guid.Parse("0022509f-b9ff-4666-ad37-3decf8e34731"),
                            PriceId = Guid.Parse("4929e500-79d0-4d07-9d09-38dc0c01d8c7"),
                            Value = 29.0m,
                            Year =  2025,
                          Created = Utility.CurrentSEAsiaStandardTime()
                        },
                    new Price()  {
                            Id =  Guid.Parse("0027a390-16fb-4d70-b5c2-b6bcb79e6982"),
                            PriceId = Guid.Parse("6c7a7116-6c3b-4191-ab99-40184db473eb"),
                            Value = 89.0m,
                            Year =  2034,
                            Created = Utility.CurrentSEAsiaStandardTime()
                        }
              };
            }

            [Fact]
            [Trait("Category", "Price")]
            public async void should_return_all_status_price_in_a_row()
            {
                // Arrange
                mockRepo
                    .Setup(x => x.ListAsync())
                                    .ReturnsAsync(prices);

                // Act
                var result = await ServiceUnderTest.ListAsync();

                // Assert
                Assert.Equal(prices, result);
            }

            [Fact]
            [Trait("Category", "Price")]
            public async void should_return_ACTIVE_status_price_in_a_row()
            {
                // Arrange
                mockRepo
                    .Setup(x => x.ListAsync())
                                    .ReturnsAsync(prices);

                // Act
                var result = await ServiceUnderTest.ListAsync();

                // Assert
                Assert.Equal(prices, result);
            }

            [Fact]
            [Trait("Category", "Price")]
            public async void should_throw_PriceNotFoundException_when_price_is_null()
            {
                // Arrange
                mockRepo
                    .Setup(x => x.ListAsync())
                                    .ReturnsAsync(default(Price[]));

                // Act & Assert
                await Assert.ThrowsAsync<PriceNotFoundException>(() => ServiceUnderTest.ListAsync());

            }


        }



        public class CreateAsync : PriceServiceTest
        {
            private Price[] prices;
            public CreateAsync()
            {

                prices = new Price[]
                  {

                    new Price() {
                            Id =  Guid.Parse("0002320b-b0e3-493c-82a6-6abfaec7c0ed"),
                            PriceId = Guid.Parse("41fabf2d-4432-4fa8-acb9-a7058cb506d9"),
                            Value = 137.0m,
                            Year =  2048,
                         Created = Utility.CurrentSEAsiaStandardTime()
                        },
                    new Price() {
                            Id =  Guid.Parse("0022509f-b9ff-4666-ad37-3decf8e34731"),
                            PriceId = Guid.Parse("4929e500-79d0-4d07-9d09-38dc0c01d8c7"),
                            Value = 29.0m,
                            Year =  2025,
                          Created = Utility.CurrentSEAsiaStandardTime()
                        },
                    new Price()  {
                            Id =  Guid.Parse("0027a390-16fb-4d70-b5c2-b6bcb79e6982"),
                            PriceId = Guid.Parse("6c7a7116-6c3b-4191-ab99-40184db473eb"),
                            Value = 89.0m,
                            Year =  2034,
                            Created = Utility.CurrentSEAsiaStandardTime()
                        }
                  };

            }

            [Fact]
            [Trait("Category", "Price")]
            public async void should_create_and_return_the_new_Price()
            {
                // Arrange
                var price = prices[2];
                // price.Id = null;
                //var id = "b3403c0f-16e3-44ae-9389-795d00a1805e";

                mockRepo.Setup(x => x.CreateAsync(price))
                    .ReturnsAsync(price)
                    .Verifiable();

                /*  PriceServiceMock
                     .Setup(x => x.IsPriceExistsAsync(projectName))
                     .ReturnsAsync(true);*/

                // Act
                var result = await ServiceUnderTest.CreateAsync(price);

                // Assert
                Assert.Equal(price, result);

                mockRepo.Verify(x => x.CreateAsync(price), Times.Once);
            }

        }


        public class GetAsync : PriceServiceTest
        {
            private Price[] prices;
            public GetAsync()
            {
                prices = new Price[]
                {

                    new Price() {
                            Id =  Guid.Parse("0002320b-b0e3-493c-82a6-6abfaec7c0ed"),
                            PriceId = Guid.Parse("41fabf2d-4432-4fa8-acb9-a7058cb506d9"),
                            Value = 137.0m,
                            Year =  2048,
                         Created = Utility.CurrentSEAsiaStandardTime()
                        },
                    new Price() {
                            Id =  Guid.Parse("0022509f-b9ff-4666-ad37-3decf8e34731"),
                            PriceId = Guid.Parse("4929e500-79d0-4d07-9d09-38dc0c01d8c7"),
                            Value = 29.0m,
                            Year =  2025,
                          Created = Utility.CurrentSEAsiaStandardTime()
                        },
                    new Price()  {
                            Id =  Guid.Parse("0027a390-16fb-4d70-b5c2-b6bcb79e6982"),
                            PriceId = Guid.Parse("6c7a7116-6c3b-4191-ab99-40184db473eb"),
                            Value = 89.0m,
                            Year =  2034,
                            Created = Utility.CurrentSEAsiaStandardTime()
                        }
                };
            }

            [Fact]
            [Trait("Category", "Price")]
            public async void should_return_specific_id_price()
            {
                // Arrange
                var price = prices[2];
                var id = Guid.Parse("b3403c0f-16e3-44ae-9389-795d00a1805e");

                mockRepo
                    .Setup(x => x.GetAsync(id))
                    .ReturnsAsync(prices[2]);

                // Act
                var result = await ServiceUnderTest.GetAsync(id);

                // price
                Assert.Equal(price, result);
            }

            [Fact]
            [Trait("Category", "Price")]
            public async void should_throw_Null_when_price_does_not_exist()
            {
                // Arrange
                var id = Guid.NewGuid();

                mockRepo
                    .Setup(x => x.GetAsync(id))
                    .ReturnsAsync(default(Price));

                // Act & Assert
                var result = await ServiceUnderTest.GetAsync(id);

                // await Assert.ThrowsAsync<PriceNotFoundException>(() => ServiceUnderTest.GetAsync(id));
                // price
                Assert.Null(result);
            }
        }


        public class GetCurrentAsync : PriceServiceTest
        {
            private Price[] prices;
            private Price[] pricegroups;
            public GetCurrentAsync()
            {
                prices = new Price[]
                {

                    new Price() {
                            //Id =  "0002320b-b0e3-493c-82a6-6abfaec7c0ed",
                           // PriceId = "e90ea40d-1b93-4c13-88c6-11fa45c2a9db",
                            Value = 137.0m,
                            Year =  2048,
                         Created = Utility.CurrentSEAsiaStandardTime()
                        },
                    new Price() {
                            //Id =  "0022509f-b9ff-4666-ad37-3decf8e34731",
                           // PriceId = "c345135b-0a94-4de3-8ff9-71e6f5f92d50",
                            Value = 29.0m,
                            Year =  2025,
                          Created = Utility.CurrentSEAsiaStandardTime()
                        },
                    new Price()  {
                            //Id =  "0027a390-16fb-4d70-b5c2-b6bcb79e6982",
                           // PriceId = "c345135b-0a94-4de3-8ff9-71e6f5f92d50",
                            Value = 89.0m,
                            Year =  2034,
                            Created = Utility.CurrentSEAsiaStandardTime()
                        }
                };

                //price grouped
                pricegroups = new Price[]
                {
                        new Price()       {
                            Id =  Guid.Parse("e90ea40d-1b93-4c13-88c6-11fa45c2a9db"),
                            Name =  "CTEP",
                            HcType =  "Gas",
                            AreaId =  "b788aa1f1ccdbaa306579d269464183114734817",
                           Unit =  "$/MMBTU",
                           Description=  "hello world",
                           // "created": "2019-07-24T10:05:47.4238128+07:00",
                           // "by": null,
                            Structure=  "Low",
                           // "status": null,
                           TemplateId = "2b76066a-2bac-401f-9084-48d81addc0f7",
                            //"yearPrices": null
                        },
                        new Price()         {
                            Id =  Guid.Parse("e90ea40d-1b93-4c13-88c6-11fa45c2a9db"),
                            Name =  "PAILIN",
                            HcType =  "Gas",
                            AreaId =  "5276b83640750210b79e554915023111e06af1fb",
                           Unit =  "$/MMBTU",
                           Description=  "hello world",
                           // "created": "2019-07-24T10:05:47.8997893+07:00",
                          //  "by": null,
                            Structure=  "Low",
                           // "status": null,
                           TemplateId = "2b76066a-2bac-401f-9084-48d81addc0f7",
                            //"yearPrices": null
                        },
                        new Price()        {
                       Id =  Guid.Parse("e90ea40d-1b93-4c13-88c6-11fa45c2a9db"),
                            Name =  "B8/32",
                            HcType =  "Gas",
                            AreaId =  "d12acc25cc684a25d804e469dbbc685aaf84b99c",
                           Unit =  "$/MMBTU",
                           Description=  "hello world",
                            //"created": "2019-07-24T10:05:48.4113424+07:00",
                         //   "by": null,
                            Structure= "Low",
                           // "status": null,
                           TemplateId = "2b76066a-2bac-401f-9084-48d81addc0f7",
                            //"yearPrices": null
                        }



                };


            }

            [Fact]
            [Trait("Category", "CURRENT")]
            public async void should_return_specific_current_year_price()
            {
                // Arrange
                var price = prices[0];
                var groupid = Guid.Parse("e90ea40d-1b93-4c13-88c6-11fa45c2a9db");
                var areaid = "d12acc25cc684a25d804e469dbbc685aaf84b99c";
                var structurre = "Low";

                mockRepo
                    .Setup(x => x.GetCurrentAsync(groupid))
                    .ReturnsAsync(price);

                mockGroupRepo
                    .Setup(x => x.ListAsync())
                    .ReturnsAsync(pricegroups);

                // Act
                var result = await ServiceUnderTest.GetCurrentPriceAsync(areaid, structurre);

                // price
                Assert.Equal(price, result);
            }

            [Fact]
            [Trait("Category", "Price")]
            public async void should_throw_PriceGroupNotFoundException_when_area_or_structure_does_not_exist()
            {
                // Arrange
                var id = "hello";
                var structurre = "NA";

                //  mockRepo
                //  .Setup(x => x.GetCurrentAsync(groupid))
                //.ReturnsAsync(prices[2]);

                mockGroupRepo
                    .Setup(x => x.ListAsync())
                    .ReturnsAsync(pricegroups);

                // Act
                // var result = await ServiceUnderTest.GetCurrentPriceAsync(id, structurre);

                await Assert.ThrowsAsync<PriceGroupNotFoundException>(() => ServiceUnderTest.GetCurrentPriceAsync(id, structurre));
            }
        }


        public class UpdateAsync : PriceServiceTest
        {
            private Price[] prices;
            public UpdateAsync()
            {
                prices = new Price[]
                       {

                    new Price() {
                            Id =  Guid.Parse("0002320b-b0e3-493c-82a6-6abfaec7c0ed"),
                            PriceId = Guid.Parse("41fabf2d-4432-4fa8-acb9-a7058cb506d9"),
                            Value = 137.0m,
                            Year =  2048,
                         Created = Utility.CurrentSEAsiaStandardTime()
                        },
                    new Price() {
                            Id =  Guid.Parse("0022509f-b9ff-4666-ad37-3decf8e34731"),
                            PriceId = Guid.Parse("4929e500-79d0-4d07-9d09-38dc0c01d8c7"),
                            Value = 29.0m,
                            Year =  2025,
                          Created = Utility.CurrentSEAsiaStandardTime()
                        },
                    new Price()  {
                            Id =  Guid.Parse("0027a390-16fb-4d70-b5c2-b6bcb79e6982"),
                            PriceId = Guid.Parse("6c7a7116-6c3b-4191-ab99-40184db473eb"),
                            Value = 89.0m,
                            Year =  2034,
                            Created = Utility.CurrentSEAsiaStandardTime()
                        }
                       };
            }

            [Fact]
            [Trait("Category", "Price")]
            public async void should_update_and_return_the_updated_Price()
            {
                // Arrange
                var price = prices[2];
                //price.//Id = null;
                var id = Guid.Parse("0027a390-16fb-4d70-b5c2-b6bcb79e6982");

                mockRepo
                    .Setup(x => x.GetAsync(id))
                    .ReturnsAsync(price)
                    .Verifiable();


                mockRepo
                    .Setup(x => x.UpdateAsync(price))
                    .ReturnsAsync(price)
                    .Verifiable();

                /*  PriceServiceMock
                     .Setup(x => x.IsPriceExistsAsync(projectName))
                     .ReturnsAsync(true);*/

                // Act
                var result = await ServiceUnderTest.UpdateAsync(price);

                // Assert
                Assert.Equal(price, result);
            }

            [Fact]
            [Trait("Category", "Price")]
            public async void should_throw_PriceNotFoundException_when_project_does_not_exist()
            {
                // Arrange
                var price = prices[2];
                price.Id = Guid.Empty;
                var id = Guid.Parse("b3403c0f-16e3-44ae-9389-795d00a1805e");

                mockRepo
                .Setup(x => x.GetAsync(id))
                .ReturnsAsync(default(Price));

                //mockRepo
                // .Setup(x => x.UpdateAsync(price))
                // .ThrowsAsync(new PriceNotFoundException());
                //.Verifiable();

                // Act & Assert
                await Assert.ThrowsAsync<PriceNotFoundException>(() => ServiceUnderTest.UpdateAsync(price));


            }

        }

        public class GetGroupedAsync : PriceServiceTest
        {
            //  private Price[] prices;
            private Price[] pricegroups;
            public GetGroupedAsync()
            {
                //price grouped
                pricegroups = new Price[]
                {
                    new Price()
                        {
                        //Id = "c345135b-0a94-4de3-8ff9-71e6f5f92d50",
                        Name = "CTEP",
                        HcType = "Gas",
                        AreaId = "b788aa1f1ccdbaa306579d269464183114734817",
                        Unit = "$/MMBTU",
                        Description = "hello world",
                        // "created": "2019-07-24T10:05:47.4238128+07:00",
                        // "by": null,
                        Structure = "Low",
                        // "status": null,
                        TemplateId = "2b76066a-2bac-401f-9084-48d81addc0f7",
                        //"yearPrices": null
                    },
                    new Price()
                    {
                        //Id = "c5ab2063-3593-47bf-9a72-9d5cc843bfc4",
                        Name = "PAILIN",
                        HcType = "Gas",
                        AreaId = "5276b83640750210b79e554915023111e06af1fb",
                        Unit = "$/MMBTU",
                        Description = "hello world",
                        // "created": "2019-07-24T10:05:47.8997893+07:00",
                        //  "by": null,
                        Structure = "Low",
                        // "status": null,
                        TemplateId = "2b76066a-2bac-401f-9084-48d81addc0f7",
                        //"yearPrices": null
                        },
                        new Price()
                    {
                        //Id = "e90ea40d-1b93-4c13-88c6-11fa45c2a9db",
                        Name = "B8/32",
                        HcType = "Gas",
                        AreaId = "d12acc25cc684a25d804e469dbbc685aaf84b99c",
                        Unit = "$/MMBTU",
                        Description = "hello world",
                        //"created": "2019-07-24T10:05:48.4113424+07:00",
                        //   "by": null,
                        Structure = "Low",
                        // "status": null,
                        TemplateId = "2b76066a-2bac-401f-9084-48d81addc0f7",
                        //"yearPrices": null
                    }
                };
            }

            [Fact]
            [Trait("Category", "Price")]
            public async void should_return_specific_id_price_group()
            {
                // Arrange
                var price = pricegroups[2];
                var id = Guid.Parse("e90ea40d-1b93-4c13-88c6-11fa45c2a9db");

                mockGroupRepo
                    .Setup(x => x.GetAsync(id))
                    .ReturnsAsync(price);

                // Act
                var result = await ServiceUnderTest.GetGroupedAsync(id);

                // price
                Assert.Equal(price, result);
            }

            [Fact]
            [Trait("Category", "Price")]
            public async void should_throw_Null_when_price_group_does_not_exist()
            {
                // Arrange
                var id = Guid.Empty;

                mockGroupRepo
                    .Setup(x => x.GetAsync(id))
                    .ReturnsAsync(default(Price));

                // Act & Assert
                var result = await ServiceUnderTest.GetGroupedAsync(id);

                // await Assert.ThrowsAsync<PriceNotFoundException>(() => ServiceUnderTest.GetAsync(id));
                // price
                Assert.Null(result);
            }

        }

        public class CreateGroupedAsync : PriceServiceTest
        {
            //vprivate Price[] prices;
            private Price[] pricegroups;
            public CreateGroupedAsync()
            {
                //price grouped
                pricegroups = new Price[]
                {
                    new Price()
                        {
                        //Id = "c345135b-0a94-4de3-8ff9-71e6f5f92d50",
                        Name = "CTEP",
                        HcType = "Gas",
                        AreaId = "b788aa1f1ccdbaa306579d269464183114734817",
                        Unit = "$/MMBTU",
                        Description = "hello world",
                        // "created": "2019-07-24T10:05:47.4238128+07:00",
                        // "by": null,
                        Structure = "Low",
                        // "status": null,
                        TemplateId = "2b76066a-2bac-401f-9084-48d81addc0f7",
                        //"yearPrices": null
                    },
                    new Price()
                    {
                        //Id = "c5ab2063-3593-47bf-9a72-9d5cc843bfc4",
                        Name = "PAILIN",
                        HcType = "Gas",
                        AreaId = "5276b83640750210b79e554915023111e06af1fb",
                        Unit = "$/MMBTU",
                        Description = "hello world",
                        // "created": "2019-07-24T10:05:47.8997893+07:00",
                        //  "by": null,
                        Structure = "Low",
                        // "status": null,
                        TemplateId = "2b76066a-2bac-401f-9084-48d81addc0f7",
                        //"yearPrices": null
                        },
                        new Price()
                    {
                        //Id = "e90ea40d-1b93-4c13-88c6-11fa45c2a9db",
                        Name = "B8/32",
                        HcType = "Gas",
                        AreaId = "d12acc25cc684a25d804e469dbbc685aaf84b99c",
                        Unit = "$/MMBTU",
                        Description = "hello world",
                        //"created": "2019-07-24T10:05:48.4113424+07:00",
                        //   "by": null,
                        Structure = "Low",
                        // "status": null,
                        TemplateId = "2b76066a-2bac-401f-9084-48d81addc0f7",
                        //"yearPrices": null
                    }
                };
            }

            [Fact]
            [Trait("Category", "Price")]
            public async void should_overloading_create__price_group_and_return()
            {
                // Arrange
                var price = pricegroups[2];
                // var id = "e90ea40d-1b93-4c13-88c6-11fa45c2a9db";

                mockGroupRepo
                    .Setup(x => x.CreateAsync(price))
                    .ReturnsAsync(price);

                // Act
                var result = await ServiceUnderTest.CreateAsync(price);

                // price
                Assert.Equal(price, result);
            }

            [Fact]
            [Trait("Category", "Price")]
            public async void should_overloading_throw_Null_when_price_create_fail()
            {
                // Arrange
                var price = pricegroups[2];

                mockGroupRepo
                    .Setup(x => x.CreateAsync(price))
                    .ReturnsAsync(default(Price));

                // Act & Assert
                //var result = await ServiceUnderTest.CreateAsync(default(Price));

                await Assert.ThrowsAsync<PriceGroupNotFoundException>(() => ServiceUnderTest.CreateAsync(price));
                // price
                //Assert.Null(result);
            }

        }

        /* 
        public class ExtractAsync : PriceServiceTest
        {
            private Price[] prices;
            private Price[] pricegroups;

            private Attachment attachement;
            public ExtractAsync()
            {
                //var xlsx = "../Mocks/0647GGE647.xlsx";
                //byte[] bytes = System.IO.File.ReadAllBytes(xlsx);
                var base64 = "UEsDBBQABgAIAAAAIQAhjEY6cwEAAIwFAAATAAgCW0NvbnRlbnRfVHlwZXNdLnhtbCCiBAIooAACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADEVMluwjAQvVfqP0S+VomBQ1VVBA5dji0S9ANMPCEWiW15Bgp/34lZVFUsQiD1kiix5232TH+4aupkCQGNs7noZh2RgC2cNnaWi6/Je/okEiRltaqdhVysAcVwcH/Xn6w9YMLVFnNREflnKbGooFGYOQ+WV0oXGkX8GWbSq2KuZiB7nc6jLJwlsJRSiyEG/Vco1aKm5G3FvzdKpsaK5GWzr6XKhfK+NoUiFiqXVv8hSV1ZmgK0KxYNQ2foAyiNFQA1deaDYcYwBiI2hkIe5AxQ42WkW1cZV0ZhWBmPD2z9CEO7ctzVtu6TjyMYDclIBfpQDXuXq1p+uzCfOjfPToNcGk2MKGuUsTvdJ/jjZpTx1b2xkNZfBL5QR++fdBDfdZDxeX0UEeaMcaR1DXjr44+g55grFUCPibtodnMBv7FP6eDWHgXnkadHgMtT2LVqW516BoJABvbNeujS7xl59FwdO7SzTYM+wC3jLB38AAAA//8DAFBLAwQUAAYACAAAACEAtVUwI/QAAABMAgAACwAIAl9yZWxzLy5yZWxzIKIEAiigAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKySTU/DMAyG70j8h8j31d2QEEJLd0FIuyFUfoBJ3A+1jaMkG92/JxwQVBqDA0d/vX78ytvdPI3qyCH24jSsixIUOyO2d62Gl/pxdQcqJnKWRnGs4cQRdtX11faZR0p5KHa9jyqruKihS8nfI0bT8USxEM8uVxoJE6UchhY9mYFaxk1Z3mL4rgHVQlPtrYawtzeg6pPPm3/XlqbpDT+IOUzs0pkVyHNiZ9mufMhsIfX5GlVTaDlpsGKecjoieV9kbMDzRJu/E/18LU6cyFIiNBL4Ms9HxyWg9X9atDTxy515xDcJw6vI8MmCix+o3gEAAP//AwBQSwMEFAAGAAgAAAAhAEqppmH6AAAARwMAABoACAF4bC9fcmVscy93b3JrYm9vay54bWwucmVscyCiBAEooAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALySzWrEMAyE74W+g9G9cZL+UMo6eymFvbbbBzCxEodNbGOpP3n7mpTuNrCkl9CjJDTzMcxm+zn04h0jdd4pKLIcBLram861Cl73T1f3IIi1M7r3DhWMSLCtLi82z9hrTk9ku0AiqThSYJnDg5RUWxw0ZT6gS5fGx0FzGmMrg64PukVZ5vmdjL81oJppip1REHfmGsR+DMn5b23fNF2Nj75+G9DxGQvJiQuToI4tsoJp/F4WWQIFeZ6hXJPhw8cDWUQ+cRxXJKdLuQRT/DPMYjK3a8KQ1RHNC8dUPjqlM1svJXOzKgyPfer6sSs0zT/2clb/6gsAAP//AwBQSwMEFAAGAAgAAAAhAIQ6sgh1AwAACwgAAA8AAAB4bC93b3JrYm9vay54bWysVdlu2zgUfR9g/kHgOyNSpmRZiFJYizEB2kGQpu1LgIKR6IiIRHooKnYm6L/PpbxlmYc0rWGT4uLDc+49lzr9sOla716YXmqVInpCkCdUpWupblP05WqBY+T1lquat1qJFD2IHn04+/OP07U2dzda33kAoPoUNdauEt/vq0Z0vD/RK6FgZalNxy0Mza3fr4zgdd8IYbvWDwiJ/I5LhbYIiXkLhl4uZSUKXQ2dUHYLYkTLLdDvG7nq92hd9Ra4jpu7YYUr3a0A4ka20j6MoMjrquT8VmnDb1qQvaGhtzHwjeBHCTTB/iRYenVUJyuje720JwDtb0m/0k+JT+mzEGxex+BtSMw34l66HB5YmeidrKIDVnQEo+SX0ShYa/RKAsF7J1p44Bags9OlbMXXrXU9vlr9zTuXqRZ5Le9tWUsr6hRNYajX4tmEGVbZIFtYDch0QpB/drDzhfFqseRDa6/AyHt4qIwomgWh2wnGmLdWGMWtyLWy4MOdrl/13IidNxoc7l2KfwZpBBQW+Au0QsurhN/0F9w23mDaFOXJ9Zce5F835t/NdaHXqtVQX9dPjMlfV8FPWJNXTq8Pgrekts8vxQM3k+ztd2GNB8/nxUdIwWd+DwmBtNe7ej2HiNPJd1WZhH5/jAgLFlFeYBJkMWYsKnEcLjIcZCUr5iQs5mX2A8SYKKk0H2yzy7WDTtHEufPl0ie+SRGjboWSZJD1kcYj2X2w6180+7UfTrC71b5Kse6PrnBDb/NNqlqvU4RpAKIeng/X4+I3WdsGbMUCBlu2c38JedsAYzqN3CS43zFL0WM8y+dFTHM8j0mJWTYrcZYXES4m0zybBxErCRkZ+U8ojfcnUBt7T42evzBgGbin3dXqYgx3k0ncEea8pk7S082f3S4I0WE3PB92B2PG92dUvK2gIFw3pm5GSTBDXqVVNRgDxs9hZczwceoTVwNvcz0okMwcnNjYj70dezCuBOGUkfmUzBgm5STELJ4FOGaTAOesCMpwWhZlFrrMuzdL8jvu17F+kv0ry0lquLFXhld38KK7FMuM92DVMVY+8H1KNgvjjEyAIlvQBWZ0RnCWRQyHxWISTmmRl+HiSNbFavnO2y32x38LbgeofFf04zhx7WI3e5hcbid2DnhW1cllMabxf/++lefaMSn+Pihn/wEAAP//AwBQSwMEFAAGAAgAAAAhAE+3EuOzBAAAZhIAAA0AAAB4bC9zdHlsZXMueG1sxFhbb9s2FH4fsP8gKMDQDlN0sWRLru3Mlwgo0BUFkgF7KBDQEu0QpUSPolN5Q//7DkndnMaJkzmbXyxS5He+8/GcQ4qjizKjxh3mBWH52HTPHdPAecJSkq/H5u/XsRWaRiFQniLKcjw2d7gwLyY//jAqxI7iq1uMhQEQeTE2b4XYDG27SG5xhopztsE5vFkxniEBTb62iw3HKC3kpIzanuP07QyR3NQIwyw5BiRD/Mt2YyUs2yBBloQSsVNYppElw/frnHG0pEC1dH2UGKXb555R8tqI6v3OTkYSzgq2EueAa7PViiT4e7qRHdkoaZEA+WVIbmA73p7vJX8hkm9zfEfk8pmTUb7N4kwURsK2uYDlbLoM/eZ9Ojb9nmnoRZmzFGS6efOzcfbL2Zlz7jg3b9/J5uc3dcdn3fHTn1sm3ln67+JCDfv15q1pT0Z2ZXMyWrG8Ne2DSlL/4Zecfc1j+UrzkaMmo+Iv4w5R6HElRsIo44aAuAE+qidHGdYj5oiSJSdy2AplhO50tyc7VKhV4zICC68IaQv/kx1HUmjZTzlB9EHudpfmUjpTS6IgHpPkSVCFXYBghNImGHwIBtkxGUHeCMzzGBpG9Xy924D0OaS4llCNe2L0mqOd6wXHTygYJalksZ53FxxKjiAyXC3n3POjaDBw5W8QRj2JvaxGkzzFJYYA7vvKZMcLiELN9QnG9wnw9XJsxurnKNWfY0uZBJGXjKdQP+ucC8FB3TUZUbwS4AEn61v5L9hG+sOEgBozGaUErVmOqEyiekZ3JtRdKLFjM8Mp2WYAq2Pivg7SyJ6NI+cBm2eQ2XfjVU0cCa5UVaK+CpuXqv+cFa5FfbbH/0UYNTaOZKfj+umwPpAQJ7BSZRHkZIIpvZLZ88eqScweZFC56myEUHdkDZZ7onyEklc96iTUDWC7N0nvnnqWe3CWgTYbupO7nsLWLTDQtmaqarTtKSXrPMPdCZ84EzgR6mCmqtMh9t5j7O2uFlqZjihu8CJVjHL1sDwdTeUx4yFNQTU9G2h3ZIJu1aqFUceAQx4fwgbIU2IDXBsLT2DL3VQeXk7pBah5aoVAuXrtToENcK1C8syn4uLhlT2hQiDMq8VQg/0K6genVR8YHq3+UXl1uJLc0/swWrdAduD2UqmRuE6Xj9tsiXmsPhXbJNL1sx5zwvDpnyB8Dkk1uI+9J5WqxlB/O1vU3gbVFGtDfkOMzTnLMlQjghLLLaFwWJbFVx2O74//KCWknSjrTNDfFfXOWBnQE4ymLMgqx4dbAgb+voxn00EYLqywt4gsfz6dW+H00rX82XR+OZ0tvCgKvqmzeEMDHEvLds9VJoX8HFe7ceMqBECKV2hLxXXzcmy2z7+pIy9wqUZ9IndMKIix2T5/kOdqty8Z4FJ8KOAYDP/GlhNJfjaIFpexZ4XOLLT8Hg6sKJgtrMCfzxaLOHI8Z/6tcynwL64E1B0GnBNcf1hQuDjglbMV+au2b2x2Gpq+0g9od7lHXt+ZBq5jxT0H5O6j0Ar7vcCKA9db9P3ZZRCD8NWtSekGL7w6cGzX1ZcQknwwFCTDlOT1WtUr1O2FRYLmI07Y9UrY7QXR5B8AAAD//wMAUEsDBBQABgAIAAAAIQATxCwTwgAAAEIBAAAjAAAAeGwvd29ya3NoZWV0cy9fcmVscy9zaGVldDIueG1sLnJlbHOEj8FqwzAQRO+F/IPYeyQ7h1CKJV9KIdcm/QBFXtui9kpotyX5++jYhEKOw2PeMF1/WRf1i4VjIgutbkAhhTREmix8nT62r6BYPA1+SYQWrsjQu81L94mLl1riOWZW1UJsYRbJb8ZwmHH1rFNGqmRMZfVSY5lM9uHbT2h2TbM35a8D3J1THQYL5TC0oE7XXJefu9M4xoDvKfysSPLPhMklkmA5okg9yFXty4RiQetH9ph3+hwJjOvM3XN3AwAA//8DAFBLAwQUAAYACAAAACEAO20yS8EAAABCAQAAIwAAAHhsL3dvcmtzaGVldHMvX3JlbHMvc2hlZXQxLnhtbC5yZWxzhI/BisIwFEX3A/5DeHuT1oUMQ1M3IrhV5wNi+toG25eQ9xT9e7McZcDl5XDP5Tab+zypG2YOkSzUugKF5GMXaLDwe9otv0GxOOrcFAktPJBh0y6+mgNOTkqJx5BYFQuxhVEk/RjDfsTZsY4JqZA+5tlJiXkwyfmLG9Csqmpt8l8HtC9Ote8s5H1Xgzo9Uln+7I59Hzxuo7/OSPLPhEk5kGA+okg5yEXt8oBiQet39p5rfQ4Epm3My/P2CQAA//8DAFBLAwQUAAYACAAAACEAABsLetEBAADDAwAAGAAAAHhsL3dvcmtzaGVldHMvc2hlZXQyLnhtbJyTTY/aMBCG75X6HyzfE4cEdpeIsIJFqBwqVduPu3EmiUXsiWyzgKr+905CYStxQSslkie2n3c+3syej6Zlb+C8RlvwUZxwBlZhqW1d8J8/1tETZz5IW8oWLRT8BJ4/zz9/mh3Q7XwDEBgRrC94E0KXC+FVA0b6GDuwtFOhMzJQ6GrhOweyHC6ZVqRJ8iCM1JafCbm7h4FVpRWsUO0N2HCGOGhloPx9ozt/oRl1D85It9t3kULTEWKrWx1OA5Qzo/JNbdHJbUt1H0djqdjR0ZPSm11khu83SkYrhx6rEBNZnHO+LX8qpkKqK+m2/rswo7Fw8Kb7Ab6j0o+lNJpcWek7LPsg7OEK69vl8r0uC/57vFxkyWS5jtL0JY3G62QaLSeLlyhLV4/jJJsukuzpD5/PSk0T7qtiDqqCL0ZczGeDeX5pOPj/1qz34hZx129sSCPpj4qbs+vBi98cK6GS+za84uEL6LoJZPwJZdiPOC9PK/CKvEWYOJ1cRVcySKJ2soav0tXaetZCNZx65MydMUlM64Bdf/eRkFsMAc0lasj9QFNOYupHhRguwT/udwj7jqHTpD4YuuAduuCkDqSQ991zm3Log7j+fvO/AAAA//8DAFBLAwQUAAYACAAAACEAwRcQvk4HAADGIAAAEwAAAHhsL3RoZW1lL3RoZW1lMS54bWzsWc2LGzcUvxf6Pwxzd/w1448l3uDPbJPdJGSdlBy1tuxRVjMykrwbEwIlOfVSKKSll0JvPZTSQAMNvfSPCSS06R/RJ83YI63lJJtsSlp2DYtH/r2np/eefnrzdPHSvZh6R5gLwpKWX75Q8j2cjNiYJNOWf2s4KDR8T0iUjBFlCW75Cyz8S9uffnIRbckIx9gD+URsoZYfSTnbKhbFCIaRuMBmOIHfJozHSMIjnxbHHB2D3pgWK6VSrRgjkvhegmJQe30yISPsDZVKf3upvE/hMZFCDYwo31eqsSWhsePDskKIhehS7h0h2vJhnjE7HuJ70vcoEhJ+aPkl/ecXty8W0VYmROUGWUNuoP8yuUxgfFjRc/LpwWrSIAiDWnulXwOoXMf16/1av7bSpwFoNIKVprbYOuuVbpBhDVD61aG7V+9Vyxbe0F9ds7kdqo+F16BUf7CGHwy64EULr0EpPlzDh51mp2fr16AUX1vD10vtXlC39GtQRElyuIYuhbVqd7naFWTC6I4T3gyDQb2SKc9RkA2r7FJTTFgiN+VajO4yPgCAAlIkSeLJxQxP0AiyuIsoOeDE2yXTCBJvhhImYLhUKQ1KVfivPoH+piOKtjAypJVdYIlYG1L2eGLEyUy2/Cug1TcgL549e/7w6fOHvz1/9Oj5w1+yubUqS24HJVNT7tWPX//9/RfeX7/+8OrxN+nUJ/HCxL/8+cuXv//xOvWw4twVL7598vLpkxffffXnT48d2tscHZjwIYmx8K7hY+8mi2GBDvvxAT+dxDBCxJJAEeh2qO7LyAJeWyDqwnWw7cLbHFjGBbw8v2vZuh/xuSSOma9GsQXcY4x2GHc64Kqay/DwcJ5M3ZPzuYm7idCRa+4uSqwA9+czoFfiUtmNsGXmDYoSiaY4wdJTv7FDjB2ru0OI5dc9MuJMsIn07hCvg4jTJUNyYCVSLrRDYojLwmUghNryzd5tr8Ooa9U9fGQjYVsg6jB+iKnlxstoLlHsUjlEMTUdvotk5DJyf8FHJq4vJER6iinz+mMshEvmOof1GkG/CgzjDvseXcQ2kkty6NK5ixgzkT122I1QPHPaTJLIxH4mDiFFkXeDSRd8j9k7RD1DHFCyMdy3CbbC/WYiuAXkapqUJ4j6Zc4dsbyMmb0fF3SCsItl2jy22LXNiTM7OvOpldq7GFN0jMYYe7c+c1jQYTPL57nRVyJglR3sSqwryM5V9ZxgAWWSqmvWKXKXCCtl9/GUbbBnb3GCeBYoiRHfpPkaRN1KXTjlnFR6nY4OTeA1AuUf5IvTKdcF6DCSu79J640IWWeXehbufF1wK35vs8dgX9497b4EGXxqGSD2t/bNEFFrgjxhhggKDBfdgogV/lxEnatabO6Um9ibNg8DFEZWvROT5I3Fz4myJ/x3yh53AXMGBY9b8fuUOpsoZedEgbMJ9x8sa3pontzAcJKsc9Z5VXNe1fj/+6pm014+r2XOa5nzWsb19vVBapm8fIHKJu/y6J5PvLHlMyGU7ssFxbtCd30EvNGMBzCo21G6J7lqAc4i+Jo1mCzclCMt43EmPycy2o/QDFpDZd3AnIpM9VR4MyagY6SHdSsVn9Ct+07zeI+N005nuay6mqkLBZL5eClcjUOXSqboWj3v3q3U637oVHdZlwYo2dMYYUxmG1F1GFFfDkIUXmeEXtmZWNF0WNFQ6pehWkZx5QowbRUVeOX24EW95YdB2kGGZhyU52MVp7SZvIyuCs6ZRnqTM6mZAVBiLzMgj3RT2bpxeWp1aaq9RaQtI4x0s40w0jCCF+EsO82W+1nGupmH1DJPuWK5G3Iz6o0PEWtFIie4gSYmU9DEO275tWoItyojNGv5E+gYw9d4Brkj1FsXolO4dhlJnm74d2GWGReyh0SUOlyTTsoGMZGYe5TELV8tf5UNNNEcom0rV4AQPlrjmkArH5txEHQ7yHgywSNpht0YUZ5OH4HhU65w/qrF3x2sJNkcwr0fjY+9AzrnNxGkWFgvKweOiYCLg3LqzTGBm7AVkeX5d+JgymjXvIrSOZSOIzqLUHaimGSewjWJrszRTysfGE/ZmsGh6y48mKoD9r1P3Tcf1cpzBmnmZ6bFKurUdJPphzvkDavyQ9SyKqVu/U4tcq5rLrkOEtV5Srzh1H2LA8EwLZ/MMk1ZvE7DirOzUdu0MywIDE/UNvhtdUY4PfGuJz/IncxadUAs60qd+PrK3LzVZgd3gTx6cH84p1LoUEJvlyMo+tIbyJQ2YIvck1mNCN+8OSct/34pbAfdStgtlBphvxBUg1KhEbarhXYYVsv9sFzqdSoP4GCRUVwO0+v6AVxh0EV2aa/H1y7u4+UtzYURi4tMX8wXteH64r5c2Xxx7xEgnfu1yqBZbXZqhWa1PSgEvU6j0OzWOoVerVvvDXrdsNEcPPC9Iw0O2tVuUOs3CrVyt1sIaiVlfqNZqAeVSjuotxv9oP0gK2Ng5Sl9ZL4A92q7tv8BAAD//wMAUEsDBBQABgAIAAAAIQDOJAvUkxAAAJWQAAAYAAAAeGwvd29ya3NoZWV0cy9zaGVldDEueG1spN1bc9pKEsDx963a70DxHmMwTmJXnFNthEDc77c3guWYim28oFzObu133xZIxJqR/gnZqnNSTv9mhCxNdwRuyR/++vH0mPvmb3frzfNNvnh2ns/5z6vN3fr5801+PHLfvM/ndsHy+W75uHn2b/J/+7v8Xx//+Y8P3zfbL7sH3w9yuoXn3U3+IQherguF3erBf1ruzjYv/rPK/Wb7tAz0r9vPhd3L1l/e7Sc9PRZK5+dvC0/L9XP+sIXr7e9sY3N/v175zmb19cl/Dg4b2fqPy0D3f/ewftnFW3ta/c7mnpbbL19f3qw2Ty+6iU/rx3Xw936j+dzT6tr7/LzZLj896vf9o1hernI/tvpfSf+/iF9mH7de6Wm92m52m/vgTLdcOOyz/e1fFa4Ky9VxS/b3/1ubKZYLW//bOjyBPzdV+rNdKl4et1X6ubGLP9zY2+PGwsO1vf66vrvJ/+ei7N6WrqTy5rJSlTflyyvnzdX7t+U3VxW3Wr5w3r0/L779b/7jh7u1nuHwu8pt/fubvBSvpVu6yhc+ftivoMna/7579XUuWH4a+o/+KvD1VYr5XLhAP202X8KBnobOdZu7/YBwm8tVsP7mV/zHx5t8R3dv96/9q+iX+gKF4yu8/jp+NXe/pHvb3J1/v/z6GAw23+v++vNDoC97qd9ouFKu7/52/N1Kl6i+8FnpMtzqavOom9A/c0/rMNd0iS1/HHZ1fRc86FfFs2L5/K2Ozn3yd4G7DreYz62+7oLN0zQas9+/w6b2e+ksg+XHD9vN95yuHx29e1mG2Vi8Lutf0vdFdyIcLOHo/Rx9nZ0enW8fzz8Uvum3vIpG3B5G6FI4jigmR1QOIy72s0vnxXKSHYMvk1w1+G2SXYPfJblm8Psk1+OdD78x3bWrJHtJLhnfesNg4/tuGlxKbrxl8EWS2wYbR61jsHHUugYbR61nsHHU+gYbR21gsHHUhkm+MI7ayGDjqI0NNo7axGDjqE0NNo7azGDjqM0NNo7awmDjqEmULKVooV8Yh02OqXJYbRfGcZMoUeL5ZePASZQpRzeOnESpcnTj0EmUK0c3jp1EyXJ04+CJkS1l4+iJkS5l4/CJkS9l8/gZCVM2j5+RMWXz+Bkpc2kevyhnytH5uTSPX5Q0l7H/PH4FrZ3HAqql7oQCGo6+yb99VR6N09I4jHi3L/9hzW2agZYZaJuBjhnomoGeGeibgYEZGJqBkRkYm4GJGZiagZkZmJuBhRkQsSK3VqRiRRwrUrUirhWpWZG6FfGsiHUOxTqJYp1FsU6jROfx/XEt6OXMfv3sr2kSqzC8Hvn9f8bD0frPuF65H/+VNrL/NhqiNe44xCgAlWjIoUAY2eMQVgldwhphndAjbBA2CVuEbcL9JaSehNTD16WZPcI+4YBwSDgiHBNOCKeEM8I54YJQBDVe+annRXDRC656wWUvuO4FF77gyhdc+oJrX3DxC65+weUvuP4lKwESRa98UtELRxtFz7hkuY2GUNGLhqQXPcIqoUtYI6wTeoQNwiZhi7BN2CHsEvYI+4QDwiHhiHBMOCGcEs4I54QLQhHUeOVnFD2c66Dishdc94ILX3DlCy59wbUvuPgFV7/g8hdc/5KVAImipx/1nHClF442ip7xPuw2GkJFLxqSXvQIq4QuYY2wTugRNgibhC3CNmGHsEvYI+wTDgiHhCPCMeGEcEo4I5wTLghFUOOVn1H0cK6DistecN0LLnzBlS+49AXXvuDiF1z9gstfcP1LVgIkip5+YHJC0QtHG0XP+HDpNhryuugZny9VoiHpRY+wSugS1gjrhB5hg7BJ2CJsE3YIu4Q9wj7hgHBIOCIcE04Ip4QzwjnhglAENV75GUUP5zqouOwF173gwhdc+YJLX3DtCy5+wdUvuPwF179kJUCi6L07qeiFo42iZ3wifhsNoaIXDUkveoRVQpewRlgn9AgbhE3CFmGbsEPYJewR9gkHhEPCEeGYcEI4JZwRzgkXhCKo8crPKHo410HFZS+47gUXvuDKF1z6gmtfcPELrn7B5S+4/iUrARJFL2weev2DjEOPxNk7vd4OHtarL7ebQ4tDSp9C2FJwaFMIN6K1UD/n/dmFYDYqRGP0w4vjGPMKMBqSXgwJq4QuYY2wTugRNgibhC3CNmGHsEvYI+wTDgiHhCPCMeGEcEo4I5wTLghFUG9RK6gOKi57wXUvuPAFV77g0hdc+4KLX3D1Cy5/wfUvWQmQKIZXJ10BhqOTvQVF46eyt4chP5sLKoeA/hAy7DYL2w0cK1K1Iq4VqVmRuhXxrEjDijStSMuKtK1Ix4p0rUjPivStyMCKDK3IyIqMrcjEikytyMyKzK3IwoqI2KHopL46h2KfVrHPq9gnVuwzK/apFfvcin1yxT67Yp9esc+v2CdY7DMsiVOcyJqwr+GUnsZw+C+6IfabDNstoR0iHpN+uYBaRXVRa6h1VA+1gdpEbaG2UTuoXdQeah91gDpEHaGOUSeoU9QZ6hx1gar9i1FipL9rumWuMDvMnBDauoi7ximhjYs4m5NC2xZxNqeFcF4IJ4ZwZkhmaiTLY9i3ekLL96HNNfyuj2+UzL6JsC6GJRTLYzQmozySVuPtp851UWuodVQPtYHaRG2htlE7qF3UHmofdYA6RB2hjlEnqFPUGeocdYGq5ZGWrHZ3I1eYHWZOCC2P+NqcEloecTYnhZZHnM1poeURZ3NiaHnE2ZmpkSyPYYvtCeXx0JGbKI9mh4Vemv+6PEZjMsojaTXefkZ5pLk1nFtH9VAbqE3UFmobtYPaRe2h9lEHqEPUEeoYdYI6RZ2hzlEXqFoeadlpeUSuMDvMnBBaHvG1OSW0POJsTgotjzib00LLI87mxNDyiLMzUyNZHsPm6RPKY9Rr/frq0ezFCD+nN68ezY/i4zEZ5ZE6uqs410WtodZRPdQGahO1hdpG7aB2UXuofdQB6hB1hDpGnaBOUWeoc9QFqpZHvgmBucLsMHNCaHnEXeOU0PKIszkptDzibE4LLY84mxNDyyPOzkyNZHkMm6FPKI9R7/Tr8mh2bRSjMdS2EY/JKI/UoV3FuS5qDbWO6qE2UJuoLdQ2age1i9pD7aMOUIeoI9Qx6gR1ijpDnaMuULU88u0KzBVmh5kTQssj7hqnhJZHnM1JoeURZ3NaaHnE2ZwYWh5xdmZqJMtj2Db9f7d3hM/M+GV/RzyIGjziMRllk3q8qzjXRa2h1lE91AZqE7WF2kbtoHZRe6h91AHqEHWEOkadoE5RZ6hz1AWqlk2+4YG5wuwwc0Jo2cRd45TQsomzOSm0bOJsTgstmzibE0PLJs7OTI1k2Qwbr0+4qjz0aeufP9vfjMdM3BYPY161gkQR/ZDg2Atih6p2yLVDNTtUt0OeHWrYoaYdatmhth3q2KGuHerZob4dGtihoR0a2aGxHZrYoakdmtmhuR1a2CEtAsc2/fhE6sdtdqySEnNSYimnXLPZ3l7KSde8tcelnHbNUHtcyonXXLTHpZx6zTp7XPLkJ/Mr7PE9Ib+ilmB6fkYxGoM/EqXWYifeQurFSRXVRa2h1lE91AZqE7WF2kbtoHZRe6h91AHqEHWEOkadoE5RZ6hz1AWqVh7uwmeuMHM+6NOu8LU5I/RZVzibc0KfdIWzOSuE00JLHm6cE0MLIc7OTI1keQy7fk8oj1GTMHaMRGOwPFKzsVMkraK6qDXUOqqH2kBtorZQ26gd1C5qD7WPOkAdoo5Qx6gT1CnqDHWOukDV8sh9+cwVZs4HLY/42pwRWh5xNueElkeczVmh5RFnc15oQx3O5szQhrqM2cnyGPZkn1Aeoxbu1+XR6hiJxmB5PLaChw+QNJ+/ViStorqoNdQ6qofaQG2itlDbqB3ULmoPtY86QB2ijlDHqBPUKeoMdY66QNXySEtW38IiV5gdZk4IfbuLr80poW+CcTYnhb41xtmcFnr1iLM5MfTqEWdnpkaiPJZOux1jP/wXT++Ix9CPROMx6Z/to1ZRXdQaah3VQ22gNlFbqG3UDmoXtYfaRx2gDlFHqGPUCeoUdYY6R12g6mNv+XYM5gqzw8wJIZwRwikhnBPCSSGcFfrgXTxqnBf6SF6czZmhD+vNmJ0sj2HP8u9fPZaiFmfqGInHYHmkVmkn3kL6Z4+oLmoNtY7qoTZQm6gt1DZqB7WL2kPtow5Qh6gj1DHqBHWKOkOdoy5QtTzy7RjMFWbOB6nybM4ILY+455wTWh5xNmeFlkeczXmh5RFnc2ZoecyYnSyP5u0Yf/RAkFLU+YxPBIkHUcdIPCbjqhJv08C5LmoNtY7qoTZQm6gt1DZqB7WL2kPtow5Qh6gj1DHqBHWKOkOdoy5QtWzybRrMFWaHucrMGaFlE/ecc0LLJs7mrNCyibM5L7Rs4mzODC2bGbOTZfO02zRKh9bnRMeI+RshojGvOkaiyOuOETtUtUOuHarZobod8uxQww417VDLDrXtUMcOde1Qzw717dDADg3t0MgOje3QxA5N7dDMDs3t0MIOaRE4dr7/7BhJiVVSYk5KLOWU63tE+zVSTrq+G7THpZx2fd9nj0s58fp7VuxxKadef9eKPS558pP5dVqffymlz9/Kr5Q+f/NXrsTbybj8wD5/nOui1lDrqB5qA7WJ2kJto3ZQu6g91D7qAHWIOkIdo05Qp6gz1DnqAlUrD/f5M1eYHeYqM2eEXn7gnnNO6OUHzuas0MsPnM15oZcfOJszQy8/MmYny6PZ58+/VjL8/ZW/+t0s8Rj6kWg8JqM8Yj8/znVRa6h1VA+1gdpEbaG2UTuoXdQeah91gDpEHaGOUSeoU9QZ6hx1garlkfv5mSvMDnOVmTNCyyPuOeeElkeczVmh5RFnc15oecTZnBlaHjNmJ8vjaf38paiZmTpG4jFYHun57U68hYzP/Gmui3NrqHVUD7WB2kRtobZRO6hd1B5qH3WAOkQdoY5RJ6hT1BnqHHWBquWRFqXcMleYOR/0M398bc4ILY84m3NCyyPO5qzQ8oizOS+0POJszgwtjxmzk+XxtNsxSim3Y5jPGInH4I9E8XaMeAsZ5ZHmuji3hlpH9VAbqE3UFmobtYPaRe2h9lEHqEPUEeoYdYI6RZ2hzlEXqFoe+XYM5gqzw1xl5ozQ8si3YzBzUugnh7hxTgv9PJFvx2DmzNDymLHxZHk87XaMUsrtGOYzRuIxWB7xdox4Cxnlkea6OLeGWkf1UBuoTdQWahu1g9pF7aH2UQeoQ9QR6hh1gjpFnaHOUReoWh75dgzmCrPDXGXmjNDyyLdjMHNSaHnEjXNaaHnE2ZwY+kMYnJ2ZGsnyaN6O8WcdI1HnM3eMRIOwYwRv0yjhbRqoLmoNtY7qoTZQm6gt1DZqB7WL2kPtow5Qh6gj1DHqBHWKOkOdoy5QtWzybRrMFWaHucrMGaFlE/ecc0LfdONszgp9042zOS/0TTfO5szQq8qM2YeyWdg9+H7gLIPlxw8vy89+e7n9vH7e5R79e318yPmZXpJu15/DIrr/Oti87L/Szzk/bYJg8xT/7cFf3vn6G2TOz7Rm3m82QfwX7SkItzv0g68vuc127T8Hy2C9eb7Jv2y2wXa5DvK5B43/e6Pw6Lysb/Klc/2s85u/Ddar15Ht9fruJr/17orhM0oK3zfbL/ud//g/AAAA//8DAFBLAwQUAAYACAAAACEALCsZHvUAAADUAQAAFAAAAHhsL3NoYXJlZFN0cmluZ3MueG1sbJFBS8NAEIXvgv9hWbzajVWkyGaLKYqFRAsmB49LsiYDyWzMTKv9967oQTY9vu/NvDcwev019OLgJgKPqbxaJFI4rH0D2KayKh8vV1IQW2xs79Gl8uhIrs35mSZiEXaRUtkxj3dKUd25wdLCjw6D8+6nwXKQU6tonJxtqHOOh14tk+RWDRZQitrvkUNvEmr2CB97t/kjN9JoAqPZvDk7acVGqx/9yyoEjlnuP2O0KR92MbtQRZGVVYx399t8+xzTbKWul7NUj81xHptl+Sy0t+yxFS/Qn0w+ZRTQxLNP0HYxe3VIwHAA/neKCl8x3wAAAP//AwBQSwMEFAAGAAgAAAAhABP1xTRbAQAAdgIAABEACAFkb2NQcm9wcy9jb3JlLnhtbCCiBAEooAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIySUU+DMBSF3038D6Tv0LK5MRtgiTN7cskSMRrfmvYOiNCStsr49xa2IYs++Nb2nPvdc28ar4915X2BNqWSCQoDgjyQXIlS5gl6ybb+CnnGMilYpSQkqAOD1untTcwbypWGvVYNaFuC8RxJGsqbBBXWNhRjwwuomQmcQzrxoHTNrLvqHDeMf7Ac8IyQJa7BMsEswz3Qb0YiOiMFH5HNp64GgOAYKqhBWoPDIMQ/Xgu6Nn8WDMrEWZe2a9xM57hTtuAncXQfTTka27YN2vkQw+UP8dvu6XkY1S9lvysOKI0Fp1wDs0qne6aZ9fZFKTvWMhvjidbvsWLG7tzKDyWIhy7NCuaMQlXexp2sK26VzGP82+maDDOdOoHwXEp6mumivM43j9kWpTMS3vsk8sMoIxGdr+gieu+DXNX3qU8P9TnOf4irjNzRGaGL5YR4AaRD7uufkn4DAAD//wMAUEsDBBQABgAIAAAAIQDP4Ee0wgEAACwVAAAnAAAAeGwvcHJpbnRlclNldHRpbmdzL3ByaW50ZXJTZXR0aW5nczIuYmlu7FTNStxQGD0zse3opg4U3HRRpCtx6AyTqd1VmaR2StKEJDO4cTF0UgiMyZBERKWC+Bo+SJcuXfYBunYhxQdwo+emM9iWoYzgRvju5bvfzz05N/eQfDYifEGKBBntK3K8gss8QlzEOauqYuADpo3SnPb0J9wX2psS1LxcSCoD+ufYKpfpt8oaVwsh2XKu6VSW+xVLY7jyZZryNxybHV//k8nofO4u4xyvtdXq++3Do/+d8qTYnC+4HuAVheIRKjD5rmZ59XOCfDv4pLCL+I5D1PEOOv+SOhpcN1CDibdoslajGVjjrBHTZN1kVGeuM2/Qt5k10Sqyb2T0TN+wLHTjKA0zFbn9UZj60UEIywwC04OTRmGc9/MoieE6XuBtdAJ4YZYMd4saQ2ekogbayTBJ7WQQ/o7+vt1qFejphj25++nCaPklIb9oGu265FT0iz375OrZx6Wz1vEP1qzxHip3XAqr8pWxV/k6rafyRfD+CfvMLnbYA1Rn6bLfqG7gos8owx73UwwI/hfpcC+eEdsmxz5G5Pf5hDpPdbKcNRmigCggCogCooAoIAqIAqKAKCAKiAKigCggCsyiwC0AAAD//wMAUEsDBBQABgAIAAAAIQCWloHThwAAAOgDAAAnAAAAeGwvcHJpbnRlclNldHRpbmdzL3ByaW50ZXJTZXR0aW5nczEuYmluCmbIY0hkSGfIZChhUGAwZDBiIA0wsjCz3WHgYXZ+38DKyMDI8IornyMFSPMznGBgAtIQ0ochFWh+CZAsItF8bMoZoYIgmgmIQfR/IEBX6+LpF6rEsAHoOgaGg1NlfuOzmg1qDkgNyN2jYOSFACmxvgEYPMG+IV6gUBJgWDDoAwsAAAD//wMAUEsDBBQABgAIAAAAIQD7970ijgEAACsDAAAQAAgBZG9jUHJvcHMvYXBwLnhtbCCiBAEooAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJySQW/bMAyF7wP2HwzdGzlZUQyBrKJIW/SwYgGSdmdNpmOhtiSIrJH014+2UddZDwN2I/kenj+TUtfHtsk6SOiCL8RykYsMvA2l84dCPO3vL76LDMn40jTBQyFOgOJaf/2itilESOQAM47wWIiaKK6lRFtDa3DBsmelCqk1xG06yFBVzsJtsK8teJKrPL+ScCTwJZQXcQoUY+K6o/8NLYPt+fB5f4oMrNVNjI2zhvgv9aOzKWCoKLs7WmiUnIuK6XZgX5Ojk86VnLdqZ00DGw7WlWkQlPwYqAcw/dK2xiXUqqN1B5ZCytC98dpWIvttEHqcQnQmOeOJsXrb2Ax1E5GS/hXSC9YAhEqyYRwO5dw7r92lXg0GLs6NfcAIwsI54t5RA/iz2ppE/yIeGEbeEWeb+JBzvAl015MvP5EPy2CGv766CW00/sTCVP1w/gWf4j7cGoL3RZ8P1a42CUq+zXSIaaAeeMep6UM2tfEHKN89n4X+WTyPb18vrxb5t5wvPpsp+fHK9R8AAAD//wMAUEsBAi0AFAAGAAgAAAAhACGMRjpzAQAAjAUAABMAAAAAAAAAAAAAAAAAAAAAAFtDb250ZW50X1R5cGVzXS54bWxQSwECLQAUAAYACAAAACEAtVUwI/QAAABMAgAACwAAAAAAAAAAAAAAAACsAwAAX3JlbHMvLnJlbHNQSwECLQAUAAYACAAAACEASqmmYfoAAABHAwAAGgAAAAAAAAAAAAAAAADRBgAAeGwvX3JlbHMvd29ya2Jvb2sueG1sLnJlbHNQSwECLQAUAAYACAAAACEAhDqyCHUDAAALCAAADwAAAAAAAAAAAAAAAAALCQAAeGwvd29ya2Jvb2sueG1sUEsBAi0AFAAGAAgAAAAhAE+3EuOzBAAAZhIAAA0AAAAAAAAAAAAAAAAArQwAAHhsL3N0eWxlcy54bWxQSwECLQAUAAYACAAAACEAE8QsE8IAAABCAQAAIwAAAAAAAAAAAAAAAACLEQAAeGwvd29ya3NoZWV0cy9fcmVscy9zaGVldDIueG1sLnJlbHNQSwECLQAUAAYACAAAACEAO20yS8EAAABCAQAAIwAAAAAAAAAAAAAAAACOEgAAeGwvd29ya3NoZWV0cy9fcmVscy9zaGVldDEueG1sLnJlbHNQSwECLQAUAAYACAAAACEAABsLetEBAADDAwAAGAAAAAAAAAAAAAAAAACQEwAAeGwvd29ya3NoZWV0cy9zaGVldDIueG1sUEsBAi0AFAAGAAgAAAAhAMEXEL5OBwAAxiAAABMAAAAAAAAAAAAAAAAAlxUAAHhsL3RoZW1lL3RoZW1lMS54bWxQSwECLQAUAAYACAAAACEAziQL1JMQAACVkAAAGAAAAAAAAAAAAAAAAAAWHQAAeGwvd29ya3NoZWV0cy9zaGVldDEueG1sUEsBAi0AFAAGAAgAAAAhACwrGR71AAAA1AEAABQAAAAAAAAAAAAAAAAA3y0AAHhsL3NoYXJlZFN0cmluZ3MueG1sUEsBAi0AFAAGAAgAAAAhABP1xTRbAQAAdgIAABEAAAAAAAAAAAAAAAAABi8AAGRvY1Byb3BzL2NvcmUueG1sUEsBAi0AFAAGAAgAAAAhAM/gR7TCAQAALBUAACcAAAAAAAAAAAAAAAAAmDEAAHhsL3ByaW50ZXJTZXR0aW5ncy9wcmludGVyU2V0dGluZ3MyLmJpblBLAQItABQABgAIAAAAIQCWloHThwAAAOgDAAAnAAAAAAAAAAAAAAAAAJ8zAAB4bC9wcmludGVyU2V0dGluZ3MvcHJpbnRlclNldHRpbmdzMS5iaW5QSwECLQAUAAYACAAAACEA+/e9Io4BAAArAwAAEAAAAAAAAAAAAAAAAABrNAAAZG9jUHJvcHMvYXBwLnhtbFBLBQYAAAAADwAPABIEAAAvNwAAAAA=";
                //Convert.ToBase64String(bytes);

                prices = new Price[]
                {

                    new Price() {
                            //Id =  "0002320b-b0e3-493c-82a6-6abfaec7c0ed",
                           // PriceId = "e90ea40d-1b93-4c13-88c6-11fa45c2a9db",
                            Value = 137.0m,
                            Year =  2048,
                         Created = Utility.CurrentSEAsiaStandardTime()
                        },
                    new Price() {
                            //Id =  "0022509f-b9ff-4666-ad37-3decf8e34731",
                           // PriceId = "c345135b-0a94-4de3-8ff9-71e6f5f92d50",
                            Value = 29.0m,
                            Year =  2025,
                          Created = Utility.CurrentSEAsiaStandardTime()
                        },
                    new Price()  {
                            //Id =  "0027a390-16fb-4d70-b5c2-b6bcb79e6982",
                           // PriceId = "c345135b-0a94-4de3-8ff9-71e6f5f92d50",
                            Value = 89.0m,
                            Year =  2034,
                            Created = Utility.CurrentSEAsiaStandardTime()
                        }
                };

                //price grouped
                pricegroups = new Price[]
                {
                        new Price()       {
                            //Id =  "c345135b-0a94-4de3-8ff9-71e6f5f92d50",
                            Name =  "CTEP",
                            HcType =  "Gas",
                            AreaId =  "b788aa1f1ccdbaa306579d269464183114734817",
                           Unit =  "$/MMBTU",
                           Description=  "hello world",
                           // "created": "2019-07-24T10:05:47.4238128+07:00",
                           // "by": null,
                            Structure=  "Low",
                           // "status": null,
                           TemplateId = "2b76066a-2bac-401f-9084-48d81addc0f7",
                            //"yearPrices": null
                        },
                        new Price()         {
                            //Id =  "c5ab2063-3593-47bf-9a72-9d5cc843bfc4",
                            Name =  "PAILIN",
                            HcType =  "Gas",
                            AreaId =  "5276b83640750210b79e554915023111e06af1fb",
                           Unit =  "$/MMBTU",
                           Description=  "hello world",
                           // "created": "2019-07-24T10:05:47.8997893+07:00",
                          //  "by": null,
                            Structure=  "Low",
                           // "status": null,
                           TemplateId = "2b76066a-2bac-401f-9084-48d81addc0f7",
                            //"yearPrices": null
                        },
                        new Price()        {
                            //Id =  "e90ea40d-1b93-4c13-88c6-11fa45c2a9db",
                            Name =  "B8/32",
                            HcType =  "Gas",
                            AreaId =  "d12acc25cc684a25d804e469dbbc685aaf84b99c",
                           Unit =  "$/MMBTU",
                           Description=  "hello world",
                            //"created": "2019-07-24T10:05:48.4113424+07:00",
                         //   "by": null,
                            Structure= "Low",
                           // "status": null,
                           TemplateId = "2b76066a-2bac-401f-9084-48d81addc0f7",
                            //"yearPrices": null
                        }
                };


                attachement = new Attachment()
                {
                    //Id = "0647GGE647",
                    Value = base64,
                    Name = "hello.xlsx",
                    Title = "hello",
                    Size = 189,
                    Extension = ".xlsx",
                    // "status": null,
                    //"description": null,
                    Checksum = "0647GGE647",
                    Storage = "LOCAL",
                };

            }

            //Fact]
            [Fact(Skip = "It s not easy to mock excel sheet (should integreate or refactor)")]
            [Trait("Category", "Hello")]
            public async void should_extrac_attachement_sheet_PRICE_and_return_data_table()
            {
                // Arrange
                //var price = prices[0];
                //var path = @"./";

                string SHEET_NAME = "Price";

                //mocl path finder
                //mockPathFinder
                // .Setup(x => x.FindAsync(attachement.Id + attachement.Extension))
                //.ReturnsAsync(path + attachement.Id + attachement.Extension);

                mockAttachementService.Setup(x => x.GetWorkbookAsync(attachement, SHEET_NAME))
                       .ReturnsAsync(It.IsAny<OfficeOpenXml.ExcelWorksheet>());


                // Act
                var result = await ServiceUnderTest.ExtractAsync(It.IsAny<OfficeOpenXml.ExcelWorksheet>());

                // price
                Assert.IsType<DataTable>(result);
            }

        }*/

        /* 
        public class TransformAsync : PriceServiceTest
        {
            //private Price[] prices;
            private Price[] pricegroups;

            // private Attachment attachement;
            public TransformAsync()
            {
                //price grouped
                pricegroups = new Price[]
                {
                        new Price()       {
                            //Id =  "c345135b-0a94-4de3-8ff9-71e6f5f92d50",
                            Name =  "CTEP",
                            HcType =  "Gas",
                            AreaId =  "b788aa1f1ccdbaa306579d269464183114734817",
                           Unit =  "$/MMBTU",
                           Description=  "hello world",
                           // "created": "2019-07-24T10:05:47.4238128+07:00",
                           // "by": null,
                            Structure=  "Low",
                           // "status": null,
                           TemplateId = "2b76066a-2bac-401f-9084-48d81addc0f7",
                            //"yearPrices": null
                        },
                        new Price()         {
                            //Id =  "c5ab2063-3593-47bf-9a72-9d5cc843bfc4",
                            Name =  "PAILIN",
                            HcType =  "Gas",
                            AreaId =  "5276b83640750210b79e554915023111e06af1fb",
                           Unit =  "$/MMBTU",
                           Description=  "hello world",
                           // "created": "2019-07-24T10:05:47.8997893+07:00",
                          //  "by": null,
                            Structure=  "Low",
                           // "status": null,
                           TemplateId = "2b76066a-2bac-401f-9084-48d81addc0f7",
                            //"yearPrices": null
                        },
                        new Price()        {
                            //Id =  "e90ea40d-1b93-4c13-88c6-11fa45c2a9db",
                            Name =  "B8/32",
                            HcType =  "Gas",
                            AreaId =  "d12acc25cc684a25d804e469dbbc685aaf84b99c",
                           Unit =  "$/MMBTU",
                           Description=  "hello world",
                            //"created": "2019-07-24T10:05:48.4113424+07:00",
                         //   "by": null,
                            Structure= "Low",
                           // "status": null,
                           TemplateId = "2b76066a-2bac-401f-9084-48d81addc0f7",
                            //"yearPrices": null
                        }
                };
            }

            [Fact]
            [Trait("Category", "Price")]
            public async void should_transform_table_and_return_list_of_grouped_price()
            {
                //mock table
                DataTable table = new DataTable("MyTable");
                DataColumn yearColumn = new DataColumn("Year", typeof(string));
                DataColumn unitColumn = new DataColumn("Unit", typeof(string));
                DataColumn listColumn = new DataColumn("2015", typeof(decimal));

                table.Columns.Add(yearColumn);
                table.Columns.Add(unitColumn);
                table.Columns.Add(listColumn);

                DataRow newRow = table.NewRow();
                newRow["Year"] = "Low";
                table.Rows.Add(newRow);

                newRow = table.NewRow();
                newRow["Year"] = "CTEP";
                newRow["Unit"] = "$/MMBTU";
                newRow["2015"] = 11.00;
                table.Rows.Add(newRow);

                newRow = table.NewRow();
                newRow["Year"] = "CTEP";
                newRow["Unit"] = "$/MMBTU";
                newRow["2015"] = 1.00;
                table.Rows.Add(newRow);

                // Act
                var result = await ServiceUnderTest.TransformAsync(table);

                // price
                Assert.NotNull(result);

            }

        }*/
        /* *
        public class LoadAsync : PriceServiceTest
        {
            private Price[] prices;
            private Price[] pricegroups;

            private Area area;
            public LoadAsync()
            {
                prices = new Price[]
                {

                        new Price() {
                                //Id =  "0002320b-b0e3-493c-82a6-6abfaec7c0ed",
                               // PriceId = "41fabf2d-4432-4fa8-acb9-a7058cb506d9",
                                Value = 137.0m,
                                Year =  2048,
                               // Created = Utility.CurrentSEAsiaStandardTime()
                            },
                        new Price() {
                                //Id =  "0022509f-b9ff-4666-ad37-3decf8e34731",
                               // PriceId = "4929e500-79d0-4d07-9d09-38dc0c01d8c7",
                                Value = 29.0m,
                                Year =  2025,
                                //Created = Utility.CurrentSEAsiaStandardTime()
                            },
                        new Price()  {
                                //Id =  "0027a390-16fb-4d70-b5c2-b6bcb79e6982",
                               // PriceId = "6c7a7116-6c3b-4191-ab99-40184db473eb",
                                Value = 89.0m,
                                Year =  2034,
                                //Created = Utility.CurrentSEAsiaStandardTime()
                            }

                };

                //price grouped
                pricegroups = new Price[]
                {
                        new Price()       {
                            //Id =  "c345135b-0a94-4de3-8ff9-71e6f5f92d50",
                            Name =  "CTEP",
                            HcType =  "Gas",
                            AreaId =  "b788aa1f1ccdbaa306579d269464183114734817",
                           Unit =  "$/MMBTU",
                           Description=  "hello world",
                           // "created": "2019-07-24T10:05:47.4238128+07:00",
                           // "by": null,
                            Structure=  "Low",
                           // "status": null,
                           TemplateId = "2b76066a-2bac-401f-9084-48d81addc0f7",
                           Prices = prices.ToList()
                        },
                        new Price()         {
                            //Id =  "c5ab2063-3593-47bf-9a72-9d5cc843bfc4",
                            Name =  "PAILIN",
                            HcType =  "Gas",
                            AreaId =  "5276b83640750210b79e554915023111e06af1fb",
                           Unit =  "$/MMBTU",
                           Description=  "hello world",
                           // "created": "2019-07-24T10:05:47.8997893+07:00",
                          //  "by": null,
                            Structure=  "Low",
                           // "status": null,
                           TemplateId = "2b76066a-2bac-401f-9084-48d81addc0f7",
                            Prices = prices.ToList()
                        },
                        new Price()        {
                            //Id =  "e90ea40d-1b93-4c13-88c6-11fa45c2a9db",
                            Name =  "B8/32",
                            HcType =  "Gas",
                            AreaId =  "d12acc25cc684a25d804e469dbbc685aaf84b99c",
                            Unit =  "$/MMBTU",
                            Description=  "hello world",
                                //"created": "2019-07-24T10:05:48.4113424+07:00",
                            //   "by": null,
                                Structure= "Low",
                            // "status": null,
                            TemplateId = "2b76066a-2bac-401f-9084-48d81addc0f7",
                            Prices = prices.ToList()
                        }
                };

                area = new Area()
                {
                    //Id = "d12acc25cc684a25d804e469dbbc685aaf84b99c",
                    Name = "DPS"
                };
            }

            [Fact]
            [Trait("Category", "Price")]
            public async void should_load_group_and_yearprice_and_complete_with_transaction()
            {
                var price = prices[0];
                var pricegroup = pricegroups[0];
                //arrange
                var id = "2b76066a-2bac-401f-9084-48d81addc0f7";

                //transction
                mockWorkUnit
                  .Setup(x => x.BeginTransaction()).Returns(mockEntityTransaction.Object);


                mockWorkUnit
                    .Setup(x => x.Prices.CreateAsync(It.IsAny<Price>())).ReturnsAsync(price);

                mockWorkUnit
                    .Setup(x => x.PriceGroups.CreateAsync(It.IsAny<Price>())).ReturnsAsync(pricegroup);

                //area
                mockAreaService
                    .Setup(x => x.EnforceAreaCreateAsync(It.IsAny<Area>())).ReturnsAsync(area);

                // Act
                var result = await ServiceUnderTest.CreateYearlyAsync(pricegroups, id);

                // price
                Assert.NotNull(result);
                Assert.Equal(3, result.Count());

            }
        }*/

    }
}