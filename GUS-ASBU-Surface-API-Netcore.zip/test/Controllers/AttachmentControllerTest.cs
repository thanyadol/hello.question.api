
using System; 

using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

//log
using Serilog;

//moq
using Xunit;
using Moq;

//model
//service
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using surflex.netcore22.Services;
using surflex.netcore22.Controllers;
using surflex.netcore22.Exceptions;
using Microsoft.AspNetCore.Http;

namespace surflex.netcore22.test.Controllers
{
    public class AttachmentControllerTest
    {
        protected AttachmentController ControllerUnderTest { get; set; }

        protected Mock<IAttachmentService> mockService { get; set; }
        //protected Mock<IAreaService> mockAreaService { get; set; }
        public AttachmentControllerTest()
        {
            mockService = new Mock<IAttachmentService>();
            //mockAreaService = new Mock<IAreaService>();

            ControllerUnderTest = new AttachmentController(mockService.Object); //// mockAreaService.Object);

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();
        }

        public class GetAsync : AttachmentControllerTest
        {
            private Attachment[] attachments;
            public GetAsync()
            {
                attachments = new Attachment[]
                    {

                        new Attachment() {
                            Id  ="33b14107-9e9b-4cc8-8ddd-d9544630bf3f",
                            Value = "1AAAA=",
                            Name = "Data Preparation.xlsx",
                            Title =null,
                            Size =  165187.0m,
                            Extension = "xlsx",
                            Status = "AVAILABLE",
                            Description =  "hello this is a new attachemnt from dev",
                            By = "1bab2e6ace440ed2a24173052ffd33ef53f5f1eb",
                            Checksum = "test",
                            //"type": null,
                            //"storage": "LOCAL",
                            // "date": "2019-07-23T09:48:11.123"
                        },
                        new Attachment()  {
                            Id  ="4cd4a3c2-36cd-4b2f-9f51-025eb56e1dab",
                            Value = "2AAAA=",
                            Name = "world",
                            Title ="world",
                            Size =  189.0m,
                            Extension =  ".xls",
                            Status = "AVAILABLE",
                            Description =  "hello this is a new attachemnt from dev",
                            By = "6f7d123e25fc2d9a22c8618e1747d73fb479667f",
                            Checksum =  "61BF7032197943A552FDD9F9B3B1DCA896686C21",
                            //"type": null,
                            //"storage": "LOCAL",
                            // "date": "2019-07-17T17:26:42.937"
                        },
                        new Attachment()  {
                            Id  ="778d9fb2-5345-432f-92ab-9aeba21cd065",
                            Value ="3AAAA=",
                            Name = "Edited Price Attachment",
                            Title ="Edited Price Attachment",
                            Size =  15.0m,
                            Extension =  ".xlsx",
                            Status = "AVAILABLE",
                            Description =  "hello this is a new attachemnt from dev",
                            By = "6f7d123e25fc2d9a22c8618e1747d73fb479667f",
                            Checksum =  "61BF7032197943A552FDD9F9B3B1DCA896686C21",
                            //"type": null,
                            //"storage": "LOCAL",
                            //  "date": "2019-07-18T11:24:08.06"
                    },


                };



            }


            [Fact]
            [Trait("Category", "Attachment")]
            public async Task should_return_the_OkObjectResult_of_a_specific_id_attachment()
            {
                // Arrange
                var attachment = attachments[2];
                var id = "33b14107-9e9b-4cc8-8ddd-d9544630bf3f";
                //setup DI
                mockService.Setup(repo => repo.GetAsync(id))
                            .ReturnsAsync(attachment);

                // Act
                var result = await ControllerUnderTest.GetAsync(id);

                // Assert
                var okResult = Assert.IsType<OkObjectResult>(result);
                var entity = Assert.IsType<Attachment>(okResult.Value);

                Assert.Same(attachment, entity);
            }


            [Fact]
            [Trait("Category", "Attachment")]
            public async Task should_return_NotFoundResult_if_the_attachment_does_not_exist()
            {
                // Arrange

                var id = "33b14107-9e9b-4cc8-8ddd-d9544630bf3f";
                //setup DI
                mockService.Setup(repo => repo.GetAsync(id))
                            .ThrowsAsync(new AttachmentNotFoundException());

                // Act & Assert
                await Assert.ThrowsAsync<AttachmentNotFoundException>(() => ControllerUnderTest.GetAsync(id));

                // Act
                //var result = await ControllerUnderTest.GetAsync(id);

                // Assert
                //var notFoundResult = Assert.IsType<NotFoundResult>(result);
            }



        }


        public class CreateAsync : AttachmentControllerTest
        {
            private Attachment[] attachments;
            public CreateAsync()
            {
                attachments = new Attachment[]
                    {

                        new Attachment() {
                            Id  ="33b14107-9e9b-4cc8-8ddd-d9544630bf3f",
                            Value = "1AAAA=",
                            Name = "Data Preparation.xlsx",
                            Title =null,
                            Size =  165187.0m,
                            Extension = "xlsx",
                            Status = "AVAILABLE",
                            Description =  "hello this is a new attachemnt from dev",
                            By = "1bab2e6ace440ed2a24173052ffd33ef53f5f1eb",
                            Checksum = "test",
                            //"type": null,
                            //"storage": "LOCAL",
                            // "date": "2019-07-23T09:48:11.123"
                        },
                        new Attachment()  {
                            Id  ="4cd4a3c2-36cd-4b2f-9f51-025eb56e1dab",
                            Value = "2AAAA=",
                            Name = "world",
                            Title ="world",
                            Size =  189.0m,
                            Extension =  ".xls",
                            Status = "AVAILABLE",
                            Description =  "hello this is a new attachemnt from dev",
                            By = "6f7d123e25fc2d9a22c8618e1747d73fb479667f",
                            Checksum =  "61BF7032197943A552FDD9F9B3B1DCA896686C21",
                            //"type": null,
                            //"storage": "LOCAL",
                            // "date": "2019-07-17T17:26:42.937"
                        },
                        new Attachment()  {
                            Id  ="778d9fb2-5345-432f-92ab-9aeba21cd065",
                            Value ="3AAAA=",
                            Name = "Edited Price Attachment",
                            Title ="Edited Price Attachment",
                            Size =  15.0m,
                            Extension =  ".xlsx",
                            Status = "AVAILABLE",
                            Description =  "hello this is a new attachemnt from dev",
                            By = "6f7d123e25fc2d9a22c8618e1747d73fb479667f",
                            Checksum =  "61BF7032197943A552FDD9F9B3B1DCA896686C21",
                            //"type": null,
                            //"storage": "LOCAL",
                            //  "date": "2019-07-18T11:24:08.06"
                    },


                };

            }

            [Fact]
            [Trait("Category", "Attachment")]
            public async Task should_return_the_OkObjectResult_of_a_created_attachment()
            {
                var attachment = attachments[2];

                //setup DI
                mockService.Setup(repo => repo.CreateAsync(attachment))
                            .ReturnsAsync(attachment);

                // Act
                var result = await ControllerUnderTest.CreateAsync(attachment);

                // Assert
                var okResult = Assert.IsType<CreatedAtActionResult>(result);
                var entity = Assert.IsType<Attachment>(okResult.Value);

                Assert.Same(attachment, entity);
            }


            [Fact]
            [Trait("Category", "Attachment")]
            public async Task should_return_NotFoundResult_if_the_created_fail()
            {
                // Arrange
                var attachment = attachments[2];
                //setup DI
                mockService.Setup(repo => repo.CreateAsync(attachment))
                            .ThrowsAsync(new AttachmentNotFoundException());


                await Assert.ThrowsAsync<AttachmentNotFoundException>(() => ControllerUnderTest.CreateAsync(attachment));

            }


            [Fact]
            public async void should_return_BadRequestResult_when_invalid_model()
            {
                var attachment = attachments[2];

                ControllerUnderTest.ModelState.AddModelError("Id", "This is an model state error !!!");

                // Act
                var result = await ControllerUnderTest.CreateAsync(attachment);

                // Assert
                var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
                Assert.IsType<SerializableError>(badRequestResult.Value);
            }




        }

    }
}