
using System; 

using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

//log
using Serilog;

//moq
using Xunit;
using Moq;

//model
//service
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using surflex.netcore22.Services;
using surflex.netcore22.Controllers;
using surflex.netcore22.Exceptions;
using Microsoft.AspNetCore.Http;

namespace surflex.netcore22.test.Controllers
{
    public class ResourceControllerTest
    {
        protected ResourceController ControllerUnderTest { get; set; }

        protected Mock<IResourceService> mockService { get; set; }
        // protected Mock<IAreaService> mockAreaService { get; set; }
        public ResourceControllerTest()
        {
            mockService = new Mock<IResourceService>();
            //mockAreaService = new Mock<IAreaService>();

            ControllerUnderTest = new ResourceController(mockService.Object);

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();
        }

        public class ListAsync : ResourceControllerTest
        {
            private Resource[] resources;
            public ListAsync()
            {
                resources = new Resource[] {
                new Resource()
                {
                    Id = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35",
                    Name = "At The Bottom of the Gravity",
                    Type = null,
                    Description = null,
                    By = "admin",
                    Status = "ACTIVE",
                    // "created": "2017-06-24T11:07:14"
                },
                new Resource()
                {
                    Id = "a797b8b1-efb3-4364-ba3f-8dd59bbdd44f",
                    Name = "7\" Cement Shoe Squeeze",
                    Type = null,
                    Description = null,
                    By = "admin",
                    Status = "ACTIVE"
                    //   "created": "2017-06-24T11:07:14"
                },
                new Resource()
                {
                    Id = "a7b704d2-8523-4014-ae0d-602d4cc92a47",
                    Name = "1 Year Wars",
                    Type = null,
                    Description = "dev",
                    By = null,
                    Status = "ACTIVE"
                    //  "created": "2019-07-22T18:13:08.087"
                },
                new Resource()
                {
                    Id = "ce30bddc-b616-418d-b353-097f8f277341",
                    Name = "For developers, by developers",
                    Type = null,
                    Description = "dev",
                    By = null,
                    Status = "ACTIVE"
                    // "created": "2019-07-22T18:08:43.967"
                },
                new Resource()
                {
                    Id = "d76c4a62-a61f-4448-8e53-dfa236bc2715",
                    Name = "Method Overloading",
                    Type = null,
                    Description = "dev",
                    By = null,
                    Status = "ACTIVE"
                    // "created": "2019-07-22T18:05:31.997"
                }

                };
            }

            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_return_the_OkObjectResult_of_a_all_type_resource()
            {
                // Arrange
                //string type = null;
                //setup DI
                mockService.Setup(repo => repo.ListAsync())
                            .ReturnsAsync(resources);

                // Act
                var result = await ControllerUnderTest.ListAsync();

                // Assert
                var okResult = Assert.IsType<OkObjectResult>(result);
                var entity = Assert.IsType<Resource[]>(okResult.Value);

                Assert.Equal(resources, entity);
            }

            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_return_NotFoundResult_if_the_list_resource_does_not_exist()
            {
                // Arrange
                //string type = null;
                //setup DI
                // mockService.Setup(repo => repo.ListAsync())
                //     .ThrowsAsync(default(Resource[]));

                // Act
                // var result = await ControllerUnderTest.ListAsync(type);
                var result = await ControllerUnderTest.ListAsync();

                // Assert
                var okResult = Assert.IsType<OkObjectResult>(result);
                var entity = Assert.IsType<Resource[]>(okResult.Value);

                Assert.Empty(entity);

            }

        }

        public class CreateAsync : ResourceControllerTest
        {
            private Resource[] resources;
            public CreateAsync()
            {
                resources = new Resource[] {
                new Resource()
                {
                    Id = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35",
                    Name = "At The Bottom of the Gravity",
                    Type = null,
                    Description = null,
                    By = "admin",
                    Status = "ACTIVE",
                    // "created": "2017-06-24T11:07:14"
                },
                new Resource()
                {
                    Id = "a797b8b1-efb3-4364-ba3f-8dd59bbdd44f",
                    Name = "7\" Cement Shoe Squeeze",
                    Type = null,
                    Description = null,
                    By = "admin",
                    Status = "ACTIVE"
                    //   "created": "2017-06-24T11:07:14"
                },
                new Resource()
                {
                    Id = "a7b704d2-8523-4014-ae0d-602d4cc92a47",
                    Name = "1 Year Wars",
                    Type = null,
                    Description = "dev",
                    By = null,
                    Status = "ACTIVE"
                    //  "created": "2019-07-22T18:13:08.087"
                },
                    new Resource()
                    {
                        Id = "ce30bddc-b616-418d-b353-097f8f277341",
                        Name = "For developers, by developers",
                        Type = null,
                        Description = "dev",
                        By = null,
                        Status = "ACTIVE"
                        // "created": "2019-07-22T18:08:43.967"
                    },
                    new Resource()
                    {
                        Id = "d76c4a62-a61f-4448-8e53-dfa236bc2715",
                        Name = "Method Overloading",
                        Type = null,
                        Description = "dev",
                        By = null,
                        Status = "ACTIVE"
                        // "created": "2019-07-22T18:05:31.997"
                    }

                };
            }


            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_return_the_OkObjectResult_of_a_created_resource()
            {
                var resource = resources[2];

                //setup DI
                mockService.Setup(repo => repo.CreateAsync(resource))
                            .ReturnsAsync(resource);

                // Act
                var result = await ControllerUnderTest.CreateAsync(resource);

                // Assert
                var okResult = Assert.IsType<CreatedAtActionResult>(result);
                var entity = Assert.IsType<Resource>(okResult.Value);

                Assert.Equal(resource, entity);
            }


            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_return_NotFoundResult_if_the_created_fail()
            {
                // Arrange
                var resource = resources[2];
                //setup DI
                mockService.Setup(repo => repo.CreateAsync(resource))
                            .ThrowsAsync(new ResourceNotFoundException());


                await Assert.ThrowsAsync<ResourceNotFoundException>(() => ControllerUnderTest.CreateAsync(resource));
                // Act
                //var result = await ControllerUnderTest.CreateAsync(resource);

                // Assert
                //var notFoundResult = Assert.IsType<NotFoundResult>(result);
            }


            [Fact]
            public async void should_return_BadRequestResult_when_invalid_model()
            {
                var resource = resources[2];

                ControllerUnderTest.ModelState.AddModelError("Id", "This is an model state error !!!");

                // Act
                var result = await ControllerUnderTest.CreateAsync(resource);

                // Assert
                var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
                Assert.IsType<SerializableError>(badRequestResult.Value);
            }
        }

        public class UpdateAsync : ResourceControllerTest
        {
            private Resource[] resources;
            public UpdateAsync()
            {
                resources = new Resource[] {
                new Resource()
                {
                    Id = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35",
                    Name = "At The Bottom of the Gravity",
                    Type = null,
                    Description = null,
                    By = "admin",
                    Status = "ACTIVE",
                    // "created": "2017-06-24T11:07:14"
                },
                new Resource()
                {
                    Id = "a797b8b1-efb3-4364-ba3f-8dd59bbdd44f",
                    Name = "7\" Cement Shoe Squeeze",
                    Type = null,
                    Description = null,
                    By = "admin",
                    Status = "ACTIVE"
                    //   "created": "2017-06-24T11:07:14"
                },
                new Resource()
                {
                    Id = "a7b704d2-8523-4014-ae0d-602d4cc92a47",
                    Name = "1 Year Wars",
                    Type = null,
                    Description = "dev",
                    By = null,
                    Status = "ACTIVE"
                    //  "created": "2019-07-22T18:13:08.087"
                },
                new Resource()
                {
                    Id = "ce30bddc-b616-418d-b353-097f8f277341",
                    Name = "For developers, by developers",
                    Type = null,
                    Description = "dev",
                    By = null,
                    Status = "ACTIVE"
                    // "created": "2019-07-22T18:08:43.967"
                },
                new Resource()
                {
                    Id = "d76c4a62-a61f-4448-8e53-dfa236bc2715",
                    Name = "Method Overloading",
                    Type = null,
                    Description = "dev",
                    By = null,
                    Status = "ACTIVE"
                    // "created": "2019-07-22T18:05:31.997"
                }

                };
            }


            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_return_the_OkObjectResult_of_a_updated_resource()
            {
                var resource = resources[2];

                //setup DI
                mockService.Setup(repo => repo.UpdateAsync(resource))
                            .ReturnsAsync(resource);

                // Act
                var result = await ControllerUnderTest.UpdateAsync(resource);

                // Assert
                var okResult = Assert.IsType<OkObjectResult>(result);
                var entity = Assert.IsType<Resource>(okResult.Value);

                Assert.Equal(resource, entity);
            }


            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_return_NotFoundResult_if_the_updated_fail()
            {
                // Arrange
                var resource = resources[2];
                //setup DI
                mockService.Setup(repo => repo.UpdateAsync(resource))
                            .ThrowsAsync(new ResourceNotFoundException());


                await Assert.ThrowsAsync<ResourceNotFoundException>(() => ControllerUnderTest.UpdateAsync(resource));
                // Act
                //var result = await ControllerUnderTest.CreateAsync(resource);

                // Assert
                //var notFoundResult = Assert.IsType<NotFoundResult>(result);
            }


            [Fact]
            public async void should_return_BadRequestResult_when_invalid_model()
            {
                var resource = resources[2];

                ControllerUnderTest.ModelState.AddModelError("Id", "This is an model state error !!!");
                // Act
                var result = await ControllerUnderTest.CreateAsync(resource);

                // Assert
                var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
                Assert.IsType<SerializableError>(badRequestResult.Value);
            }
        }



        public class GetAsync : ResourceControllerTest
        {
            private Resource[] resources;
            public GetAsync()
            {
                resources = new Resource[] {
                new Resource()
                {
                    Id = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35",
                    Name = "At The Bottom of the Gravity",
                    Type = null,
                    Description = null,
                    By = "admin",
                    Status = "ACTIVE",
                    // "created": "2017-06-24T11:07:14"
                },
                new Resource()
                {
                    Id = "a797b8b1-efb3-4364-ba3f-8dd59bbdd44f",
                    Name = "7\" Cement Shoe Squeeze",
                    Type = null,
                    Description = null,
                    By = "admin",
                    Status = "ACTIVE"
                    //   "created": "2017-06-24T11:07:14"
                },
                new Resource()
                {
                    Id = "a7b704d2-8523-4014-ae0d-602d4cc92a47",
                    Name = "1 Year Wars",
                    Type = null,
                    Description = "dev",
                    By = null,
                    Status = "ACTIVE"
                    //  "created": "2019-07-22T18:13:08.087"
                },
                new Resource()
                {
                    Id = "ce30bddc-b616-418d-b353-097f8f277341",
                    Name = "For developers, by developers",
                    Type = null,
                    Description = "dev",
                    By = null,
                    Status = "ACTIVE"
                    // "created": "2019-07-22T18:08:43.967"
                },
                new Resource()
                {
                    Id = "d76c4a62-a61f-4448-8e53-dfa236bc2715",
                    Name = "Method Overloading",
                    Type = null,
                    Description = "dev",
                    By = null,
                    Status = "ACTIVE"
                    // "created": "2019-07-22T18:05:31.997"
                }

                };
            }


            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_return_the_OkObjectResult_of_a_specific_id_resource()
            {
                // Arrange
                var resource = resources[2];
                var id = "b3403c0f-16e3-44ae-9389-795d00a1805e";
                //setup DI
                mockService.Setup(repo => repo.GetAsync(id))
                            .ReturnsAsync(resource);

                // Act
                var result = await ControllerUnderTest.GetAsync(id);

                // Assert
                var okResult = Assert.IsType<OkObjectResult>(result);
                var entity = Assert.IsType<Resource>(okResult.Value);

                Assert.Equal(resource, entity);
            }


            [Fact(Skip = "debug later")]
            [Trait("Category", "Resource")]
            public async Task should_return_NotFoundResult_if_the_specific_resource_does_not_exist()
            {
                // Arrange
                var id = "b3403c0f-16e3-44ae-9389-795d00a1805e";

                //setup DI
                //mockService.Setup(repo => repo.GetAsync(id))
                //   .ThrowsAsync(new ResourceNotFoundException());

                mockService.Setup(repo => repo.GetAsync(id))
                             .ReturnsAsync(default(Resource));
                //
                // Act
                var result = await ControllerUnderTest.GetAsync(id);

                // Assert
                var okResult = Assert.IsType<OkObjectResult>(result);
                var entity = Assert.IsType<Resource>(okResult.Value);

                Assert.Null(entity);
            }
        }


        public class ListLibraryAsync : ResourceControllerTest
        {
            private ResourceLibrary[] resourcelibs;

            public ListLibraryAsync()
            {

                resourcelibs = new ResourceLibrary[]
                {
                    new ResourceLibrary()    {
                        Id = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                        Name = "Drill Time",
                        ValueType = "VARIABLE",
                        Value = null,
                        PlannerType = "CALCULATED",
                        //"section": null,
                        Type = "COST",
                        IsReadonly = true,
                        Description = null,
                        By = "admin",
                        Status = "ACTIVE",
                        //"created": "2017-06-24T11:07:14"
                    },
                    new ResourceLibrary()    {
                        Id = "2ca16741-2cb2-47ba-a76b-b41264a233d4",
                        Name = "Trip In Time",
                        ValueType = "FIXED",
                        Value = null,
                        PlannerType = "CALCULATED",
                        // "section": null,
                        Type = "TIME",
                        IsReadonly = false,
                        Description = null,
                        By = "admin",
                        Status = "ACTIVE",
                        //  "created": "2017-06-24T11:07:14"
                    },
                    new ResourceLibrary()   {
                        Id = "c8f9bd8e-6ac1-4f3e-9ea0-73eb203ea3ad",
                        Name = "Rig Cost",
                        ValueType = "VARIABLE",
                        Value = 0,
                        PlannerType = "CALCULATED",
                        //"section": null,
                        Type = "COST",
                        IsReadonly = true,
                        Description = null,
                        By = "admin",
                        Status = "ACTIVE",
                        //  "created": "2017-06-24T11:07:14"
                    }

                };
            }
            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_return_the_OkObjectResult_of_a_all_type_resource()
            {
                // Arrange
                //string type = null;
                //setup DI
                mockService.Setup(repo => repo.ListLibraryAsync(false))
                            .ReturnsAsync(resourcelibs);

                // Act
                var result = await ControllerUnderTest.ListLibraryAsync();

                // Assert
                var okResult = Assert.IsType<OkObjectResult>(result);
                var entity = Assert.IsType<ResourceLibrary[]>(okResult.Value);

                Assert.Equal(resourcelibs, entity);
            }

            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_return_NotFoundResult_if_the_resource_does_not_exist()
            {
                // Arrange
                //string type = null;
                //setup DI
                mockService.Setup(repo => repo.ListLibraryAsync(false))
                            .ThrowsAsync(new ResourceNotFoundException());

                // Act
                // var result = await ControllerUnderTest.ListAsync(type);
                await Assert.ThrowsAsync<ResourceNotFoundException>(() => ControllerUnderTest.ListLibraryAsync());

            }

        }

        public class GetLibraryAsync : ResourceControllerTest
        {
            private ResourceLibrary[] resourcelibs;

            public GetLibraryAsync()
            {

                resourcelibs = new ResourceLibrary[]
                {
                    new ResourceLibrary()    {
                        Id = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                        Name = "Drill Time",
                        ValueType = "VARIABLE",
                        Value = null,
                        PlannerType = "CALCULATED",
                        //"section": null,
                        Type = "COST",
                        IsReadonly = true,
                        Description = null,
                        By = "admin",
                        Status = "ACTIVE",
                        //"created": "2017-06-24T11:07:14"
                    },
                    new ResourceLibrary()    {
                        Id = "2ca16741-2cb2-47ba-a76b-b41264a233d4",
                        Name = "Trip In Time",
                        ValueType = "FIXED",
                        Value = null,
                        PlannerType = "CALCULATED",
                        // "section": null,
                        Type = "TIME",
                        IsReadonly = false,
                        Description = null,
                        By = "admin",
                        Status = "ACTIVE",
                        //  "created": "2017-06-24T11:07:14"
                    },
                    new ResourceLibrary()   {
                        Id = "c8f9bd8e-6ac1-4f3e-9ea0-73eb203ea3ad",
                        Name = "Rig Cost",
                        ValueType = "VARIABLE",
                        Value = 0,
                        PlannerType = "CALCULATED",
                        //"section": null,
                        Type = "COST",
                        IsReadonly = true,
                        Description = null,
                        By = "admin",
                        Status = "ACTIVE",
                        //  "created": "2017-06-24T11:07:14"
                    }

                };
            }
            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_return_the_OkObjectResult_of_a_specific_resource()
            {
                // Arrange
                var lib = resourcelibs[0];
                var id = "29d69d7a-ea8a-4b92-a202-02962b03c7f0";
                //setup DI
                mockService.Setup(repo => repo.GetLibraryAsync(id))
                            .ReturnsAsync(lib);

                // Act
                var result = await ControllerUnderTest.GetLibraryAsync(id);

                // Assert
                var okResult = Assert.IsType<OkObjectResult>(result);
                var entity = Assert.IsType<ResourceLibrary>(okResult.Value);

                Assert.Equal(lib, entity);
            }

            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_return_NotFoundResult_if_the_specific_resource_library_does_not_exist()
            {
                // Arrange
                var lib = resourcelibs[0];
                var id = "29d69d7a-ea8a-4b92-a202-02962b03c7f0";
                //setup DI
                //mockService.Setup(repo => repo.GetLibraryAsync(id))
                ///./ReturnsAsync(default(ResourceLibrary));

                // Act
                var result = await ControllerUnderTest.GetLibraryAsync(id);
                // await Assert.ThrowsAsync<ResourceNotFoundException>(() => ControllerUnderTest.GetLibraryAsync("haloo"));

                var okResult = Assert.IsType<OkObjectResult>(result);
                // var entity = Assert.IsType<ResourceLibrary>(okResult.Value);

                Assert.Null(okResult.Value);
            }

        }



        public class CreateLibraryAsync : ResourceControllerTest
        {
            private ResourceLibrary[] resourcelibs;

            public CreateLibraryAsync()
            {

                resourcelibs = new ResourceLibrary[]
                {
                    new ResourceLibrary()    {
                        Id = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                        Name = "Drill Time",
                        ValueType = "VARIABLE",
                        Value = null,
                        PlannerType = "CALCULATED",
                        //"section": null,
                        Type = "COST",
                        IsReadonly = true,
                        Description = null,
                        By = "admin",
                        Status = "ACTIVE",
                        //"created": "2017-06-24T11:07:14"
                    },
                    new ResourceLibrary()    {
                        Id = "2ca16741-2cb2-47ba-a76b-b41264a233d4",
                        Name = "Trip In Time",
                        ValueType = "FIXED",
                        Value = null,
                        PlannerType = "CALCULATED",
                        // "section": null,
                        Type = "TIME",
                        IsReadonly = false,
                        Description = null,
                        By = "admin",
                        Status = "ACTIVE",
                        //  "created": "2017-06-24T11:07:14"
                    },
                    new ResourceLibrary()   {
                        Id = "c8f9bd8e-6ac1-4f3e-9ea0-73eb203ea3ad",
                        Name = "Rig Cost",
                        ValueType = "VARIABLE",
                        Value = 0,
                        PlannerType = "CALCULATED",
                        //"section": null,
                        Type = "COST",
                        IsReadonly = true,
                        Description = null,
                        By = "admin",
                        Status = "ACTIVE",
                        //  "created": "2017-06-24T11:07:14"
                    }

                };
            }
            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_overloading_return_the_OkObjectResult_of_a_created_resource()
            {
                // Arrange
                var lib = resourcelibs[0];
                //var id = "29d69d7a-ea8a-4b92-a202-02962b03c7f0";
                //setup DI
                mockService.Setup(repo => repo.CreateAsync(lib))
                            .ReturnsAsync(lib);

                // Act
                var result = await ControllerUnderTest.CreateAsync(lib);

                // Assert
                var okResult = Assert.IsType<CreatedAtActionResult>(result);
                var entity = Assert.IsType<ResourceLibrary>(okResult.Value);

                Assert.Equal(lib, entity);
            }

            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_overloading_return_NotFoundResult_if_the_resource_created_fail()
            {
                // Arrange
                var lib = resourcelibs[0];
                // var id = "29d69d7a-ea8a-4b92-a202-02962b03c7f0";
                //setup DI
                mockService.Setup(repo => repo.CreateAsync(lib))
                            .ThrowsAsync(new ResourceNotFoundException());

                // Act
                // var result = await ControllerUnderTest.ListAsync(type);
                await Assert.ThrowsAsync<ResourceNotFoundException>(() => ControllerUnderTest.CreateAsync(lib));

            }

        }


        public class UpdateLibraryAsync : ResourceControllerTest
        {
            private ResourceLibrary[] resourcelibs;

            public UpdateLibraryAsync()
            {

                resourcelibs = new ResourceLibrary[]
                {
                    new ResourceLibrary()    {
                        Id = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                        Name = "Drill Time",
                        ValueType = "VARIABLE",
                        Value = null,
                        PlannerType = "CALCULATED",
                        //"section": null,
                        Type = "COST",
                        IsReadonly = true,
                        Description = null,
                        By = "admin",
                        Status = "ACTIVE",
                        //"created": "2017-06-24T11:07:14"
                    },
                    new ResourceLibrary()    {
                        Id = "2ca16741-2cb2-47ba-a76b-b41264a233d4",
                        Name = "Trip In Time",
                        ValueType = "FIXED",
                        Value = null,
                        PlannerType = "CALCULATED",
                        // "section": null,
                        Type = "TIME",
                        IsReadonly = false,
                        Description = null,
                        By = "admin",
                        Status = "ACTIVE",
                        //  "created": "2017-06-24T11:07:14"
                    },
                    new ResourceLibrary()   {
                        Id = "c8f9bd8e-6ac1-4f3e-9ea0-73eb203ea3ad",
                        Name = "Rig Cost",
                        ValueType = "VARIABLE",
                        Value = 0,
                        PlannerType = "CALCULATED",
                        //"section": null,
                        Type = "COST",
                        IsReadonly = true,
                        Description = null,
                        By = "admin",
                        Status = "ACTIVE",
                        //  "created": "2017-06-24T11:07:14"
                    }

                };
            }
            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_overloading_return_the_OkObjectResult_of_a_updated_resource()
            {
                // Arrange
                var lib = resourcelibs[0];
                //var id = "29d69d7a-ea8a-4b92-a202-02962b03c7f0";
                //setup DI
                mockService.Setup(repo => repo.UpdateAsync(lib))
                            .ReturnsAsync(lib);

                // Act
                var result = await ControllerUnderTest.UpdateAsync(lib);

                // Assert
                var okResult = Assert.IsType<OkObjectResult>(result);
                var entity = Assert.IsType<ResourceLibrary>(okResult.Value);

                Assert.Equal(lib, entity);
            }

            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_overloading_return_NotFoundResult_if_the_resource_updated_fail()
            {
                // Arrange
                var lib = resourcelibs[0];
                // var id = "29d69d7a-ea8a-4b92-a202-02962b03c7f0";
                //setup DI
                mockService.Setup(repo => repo.UpdateAsync(lib))
                            .ThrowsAsync(new ResourceNotFoundException());

                // Act
                // var result = await ControllerUnderTest.ListAsync(type);
                await Assert.ThrowsAsync<ResourceNotFoundException>(() => ControllerUnderTest.UpdateAsync(lib));
            }
        }

        ////task
        public class ListTaskAsync : ResourceControllerTest
        {
            private ResourceActivity[] tasks;

            public ListTaskAsync()
            {

                tasks = new ResourceActivity[]
                {
                    new ResourceActivity()    {
                        Id = "3724e1d4-8f29-4d52-931a-ca47ca83448e",
                        ResourceId = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35",
                        LibraryId = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                        Name = "Drill Time",
                        ValueType ="VARIABLE",
                        Value = null,
                        PlannerType= "CALCULATED",
                        //   "section": null,
                        Type= "COST",
                        //  "created": "2019-07-25T09:09:34.85"
                    },
                    new ResourceActivity()  {
                        Id = "8fd2ad13-678c-48e9-b380-cad313179fce",
                        ResourceId = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35",
                        LibraryId = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                        Name = "Drill Time",
                        ValueType ="VARIABLE",
                        Value = null,
                        PlannerType= "CALCULATED",
                        //  "section": null,
                        Type= "COST",
                        //   "created": "2017-06-24T11:07:14"
                    },
                    new ResourceActivity()   {
                        Id = "93a9c040-87e2-4216-afbd-0d6c12974111",
                        ResourceId = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35",
                        LibraryId = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                        Name = "Drill Time",
                        ValueType ="VARIABLE",
                        Value = null,
                        PlannerType= "CALCULATED",
                        // "section": null,
                        Type = "COST",
                        // "created": "2017-06-24T11:07:14"
                    }

                };
            }

            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_return_the_OkObjectResult_of_a_all_type_rsource_task()
            {
                // Arrange
                //var task = tasks[0];
                //setup DI
                mockService.Setup(repo => repo.ListTaskAsync(null, null))
                            .ReturnsAsync(tasks);

                // Act
                var result = await ControllerUnderTest.ListTaskAsync();

                // Assert
                var okResult = Assert.IsType<OkObjectResult>(result);
                var entity = Assert.IsType<ResourceActivity[]>(okResult.Value);

                Assert.Equal(tasks, entity);
            }


            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_return_the_OkObjectResult_of_a_specific_parent_rsource_task()
            {
                // Arrange
                var task = tasks[0];
                var parentid = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35";
                //setup DI
                mockService.Setup(repo => repo.ListTaskAsync(parentid, null))
                            .ReturnsAsync(tasks);

                // Act
                var result = await ControllerUnderTest.ListTaskAsync(parentid);

                // Assert
                var okResult = Assert.IsType<OkObjectResult>(result);
                var entity = Assert.IsType<ResourceActivity[]>(okResult.Value);

                Assert.Equal(tasks[2], entity[2]);
            }


            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_return_the_OkObjectResult_of_a_specific_type_rsource_task()
            {
                // Arrange
                var task = tasks[0];
                var type = "COST";

                //setup DI
                mockService.Setup(repo => repo.ListTaskAsync(null, type))
                            .ReturnsAsync(tasks);

                // Act
                var result = await ControllerUnderTest.ListTaskAsync(null, type);

                // Assert
                var okResult = Assert.IsType<OkObjectResult>(result);
                var entity = Assert.IsType<ResourceActivity[]>(okResult.Value);

                Assert.Equal(tasks, entity);
            }

            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_return_NotFoundResult_if_the_resource_task_does_not_exist()
            {
                // Arrange
                //string type = null;
                //setup DI
                mockService.Setup(repo => repo.ListTaskAsync())
                            .ThrowsAsync(new ResourceNotFoundException());

                // Act
                var result = await ControllerUnderTest.ListTaskAsync();


                // Assert
                var okResult = Assert.IsType<OkObjectResult>(result);
                var entity = Assert.IsType<ResourceActivity[]>(okResult.Value);

                Assert.Empty(entity);
            }
        }




        public class GetTaskAsync : ResourceControllerTest
        {
            private ResourceActivity[] tasks;

            public GetTaskAsync()
            {

                tasks = new ResourceActivity[]
                {
                    new ResourceActivity()    {
                        Id = "3724e1d4-8f29-4d52-931a-ca47ca83448e",
                        ResourceId = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35",
                        LibraryId = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                        Name = "Drill Time",
                        ValueType ="VARIABLE",
                        Value = null,
                        PlannerType= "CALCULATED",
                        //   "section": null,
                        Type= "COST",
                        //  "created": "2019-07-25T09:09:34.85"
                    },
                    new ResourceActivity()  {
                        Id = "8fd2ad13-678c-48e9-b380-cad313179fce",
                        ResourceId = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35",
                        LibraryId = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                        Name = "Drill Time",
                        ValueType ="VARIABLE",
                        Value = null,
                        PlannerType= "CALCULATED",
                        //  "section": null,
                        Type= "COST",
                        //   "created": "2017-06-24T11:07:14"
                    },
                    new ResourceActivity()   {
                        Id = "93a9c040-87e2-4216-afbd-0d6c12974111",
                        ResourceId = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35",
                        LibraryId = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                        Name = "Drill Time",
                        ValueType ="VARIABLE",
                        Value = null,
                        PlannerType= "CALCULATED",
                        // "section": null,
                        Type = "COST",
                        // "created": "2017-06-24T11:07:14"
                    }
                };
            }
            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_return_the_OkObjectResult_of_a_all_type_rsource_task()
            {
                // Arrange
                //var task = tasks[0];
                var id = "93a9c040-87e2-4216-afbd-0d6c12974111";

                var task = new ResourceTask()
                {
                    Id = "93a9c040-87e2-4216-afbd-0d6c12974111",
                    ResourceId = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35",
                    LibraryId = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                };


                //setup DI
                mockService.Setup(repo => repo.GetTaskAsync(id))
                            .ReturnsAsync((ResourceTask)task);

                // Act
                var result = await ControllerUnderTest.GetTaskAsync(id);

                // Assert
                var okResult = Assert.IsType<OkObjectResult>(result);
                var entity = Assert.IsType<ResourceTask>(okResult.Value);

                Assert.Equal(task, entity);
            }

            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_return_NotFoundResult_if_the_resource_task_does_not_exist()
            {
                var id = "93a9c040-87e2-4216-afbd-0d6c12974111";

                var task = new ResourceTask()
                {
                    Id = "93a9c040-87e2-4216-afbd-0d6c12974111",
                    ResourceId = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35",
                    LibraryId = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                };


                // Arrange
                //string type = null;
                //setup DI
                mockService.Setup(repo => repo.GetTaskAsync(id))
                            .ThrowsAsync(new ResourceNotFoundException());

                // Act
                // var result = await ControllerUnderTest.ListAsync(type);
                await Assert.ThrowsAsync<ResourceNotFoundException>(() => ControllerUnderTest.GetTaskAsync(id));

            }

        }


        public class CreateTaskAsync : ResourceControllerTest
        {

            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_overloading_return_the_OkObjectResult_of_a_created_rsource_task()
            {
                // Arrange
                //var task = tasks[0];
                // var id = "93a9c040-87e2-4216-afbd-0d6c12974111";

                var task = new ResourceTask()
                {
                    Id = "93a9c040-87e2-4216-afbd-0d6c12974111",
                    ResourceId = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35",
                    LibraryId = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                };


                //setup DI
                mockService.Setup(repo => repo.CreateAsync(task))
                            .ReturnsAsync(task);

                // Act
                var result = await ControllerUnderTest.CreateAsync(task);

                // Assert
                var okResult = Assert.IsType<CreatedAtActionResult>(result);
                var entity = Assert.IsType<ResourceTask>(okResult.Value);

                Assert.Equal(task, entity);
            }

            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_overloading_return_NotFoundResult_if_the_created_task_fail()
            {
                // Arrange
                var task = new ResourceTask()
                {
                    Id = "93a9c040-87e2-4216-afbd-0d6c12974111",
                    ResourceId = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35",
                    LibraryId = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                };

                //setup DI
                mockService.Setup(repo => repo.CreateAsync(task))
                            .ThrowsAsync(new ResourceNotFoundException());


                await Assert.ThrowsAsync<ResourceNotFoundException>(() => ControllerUnderTest.CreateAsync(task));
                // Act
                //var result = await ControllerUnderTest.CreateAsync(resource);

                // Assert
                //var notFoundResult = Assert.IsType<NotFoundResult>(result);
            }


            [Fact]
            public async void should_overloading_return_BadRequestResult_when_invalid_model()
            {
                var task = new ResourceTask()
                {
                    Id = "93a9c040-87e2-4216-afbd-0d6c12974111",
                    ResourceId = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35",
                    LibraryId = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                };


                ControllerUnderTest.ModelState.AddModelError("Id", "This is an model state error !!!");

                // Act
                var result = await ControllerUnderTest.CreateAsync(task);

                // Assert
                var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
                Assert.IsType<SerializableError>(badRequestResult.Value);
            }

        }

        public class UpdateTaskAsync : ResourceControllerTest
        {

            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_overloading_return_the_OkObjectResult_of_a_updated_rsource_task()
            {
                // Arrange
                //var task = tasks[0];
                // var id = "93a9c040-87e2-4216-afbd-0d6c12974111";

                var task = new ResourceTask()
                {
                    Id = "93a9c040-87e2-4216-afbd-0d6c12974111",
                    ResourceId = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35",
                    LibraryId = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                };


                //setup DI
                mockService.Setup(repo => repo.UpdateAsync(task))
                            .ReturnsAsync(task);

                // Act
                var result = await ControllerUnderTest.UpdateAsync(task);

                // Assert
                var okResult = Assert.IsType<OkObjectResult>(result);
                var entity = Assert.IsType<ResourceTask>(okResult.Value);

                Assert.Equal(task, entity);
            }

            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_overloading_return_NotFoundResult_if_the_updated_task_fail()
            {
                // Arrange
                var task = new ResourceTask()
                {
                    Id = "93a9c040-87e2-4216-afbd-0d6c12974111",
                    ResourceId = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35",
                    LibraryId = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                };

                //setup DI
                mockService.Setup(repo => repo.UpdateAsync(task))
                            .ThrowsAsync(new ResourceNotFoundException());


                await Assert.ThrowsAsync<ResourceNotFoundException>(() => ControllerUnderTest.UpdateAsync(task));
                // Act
                //var result = await ControllerUnderTest.CreateAsync(resource);

                // Assert
                //var notFoundResult = Assert.IsType<NotFoundResult>(result);
            }


            [Fact]
            public async void should_overloading_return_BadRequestResult_when_invalid_model()
            {
                var task = new ResourceTask()
                {
                    Id = "93a9c040-87e2-4216-afbd-0d6c12974111",
                    ResourceId = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35",
                    LibraryId = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                };


                ControllerUnderTest.ModelState.AddModelError("Id", "This is an model state error !!!");

                // Act
                var result = await ControllerUnderTest.UpdateAsync(task);

                // Assert
                var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
                Assert.IsType<SerializableError>(badRequestResult.Value);
            }

        }
        public class DeleteTaskAsync : ResourceControllerTest
        {

            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_return_the_OkObjectResult_of_a_deleted_resource_task()
            {
                // Arrange
                //var task = tasks[0];
                var id = "93a9c040-87e2-4216-afbd-0d6c12974111";

                var task = new ResourceTask()
                {
                    Id = "93a9c040-87e2-4216-afbd-0d6c12974111",
                    ResourceId = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35",
                    LibraryId = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                };


                //setup DI
                mockService.Setup(repo => repo.DeleteAsync(id))
                            .ReturnsAsync(task);

                // Act
                var result = await ControllerUnderTest.DeleteAsync(id);

                // Assert
                var okResult = Assert.IsType<OkObjectResult>(result);
                var entity = Assert.IsType<ResourceTask>(okResult.Value);

                Assert.Equal(task, entity);
            }

            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_overloading_return_NotFoundResult_if_the_delete_task_fail()
            {
                //var task = tasks[0];
                var id = "93a9c040-87e2-4216-afbd-0d6c12974111";


                // Arrange
                var task = new ResourceTask()
                {
                    Id = "93a9c040-87e2-4216-afbd-0d6c12974111",
                    ResourceId = "7ae4ed64-e61f-45de-bdf0-fd38457bcc35",
                    LibraryId = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                };

                //setup DI
                mockService.Setup(repo => repo.DeleteAsync(id))
                            .ThrowsAsync(new ResourceNotFoundException());


                await Assert.ThrowsAsync<ResourceNotFoundException>(() => ControllerUnderTest.DeleteAsync(id));
                // Act
                //var result = await ControllerUnderTest.CreateAsync(resource);

                // Assert
                //var notFoundResult = Assert.IsType<NotFoundResult>(result);
            }


        }


        public class ListTangibleAsync : ResourceControllerTest
        {
            private ResourceLibrary[] resourcelibs;

            public ListTangibleAsync()
            {

                resourcelibs = new ResourceLibrary[]
                {
                    new ResourceLibrary()    {
                        Id = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                        Name = "Drill Time",
                        ValueType = "VARIABLE",
                        Value = null,
                        PlannerType = "CALCULATED",
                        //"section": null,
                        Type = "TANGIBLE",
                        IsReadonly = true,
                        Description = null,
                        By = "admin",
                        Status = "ACTIVE",
                        //"created": "2017-06-24T11:07:14"
                    },
                    new ResourceLibrary()    {
                        Id = "2ca16741-2cb2-47ba-a76b-b41264a233d4",
                        Name = "Trip In Time",
                        ValueType = "FIXED",
                        Value = null,
                        PlannerType = "CALCULATED",
                        // "section": null,
                        Type = "TIME",
                        IsReadonly = false,
                        Description = null,
                        By = "admin",
                        Status = "ACTIVE",
                        //  "created": "2017-06-24T11:07:14"
                    },
                    new ResourceLibrary()   {
                        Id = "c8f9bd8e-6ac1-4f3e-9ea0-73eb203ea3ad",
                        Name = "Rig Cost",
                        ValueType = "VARIABLE",
                        Value = 0,
                        PlannerType = "CALCULATED",
                        //"section": null,
                        Type = "COST",
                        IsReadonly = true,
                        Description = null,
                        By = "admin",
                        Status = "ACTIVE",
                        //  "created": "2017-06-24T11:07:14"
                    },

                   new ResourceLibrary()   {
                        Id = "tang",
                        Name = "Rigt Cost",
                        ValueType = "FIXED",
                        Value = 90,
                        Type = "TANGIBLE",
                    },


                    new ResourceLibrary()   {
                        Id = "opex",
                        Name = "OPEXCPP",
                        ValueType = "FIXED",
                        Value = 90,
                        Type = "OPEX",
                    }

                };
            }

            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_return_the_OkObjectResult_of_a_all_type_resource()
            {
                // Arrange
                //string type = null;
                //setup DI
                mockService.Setup(repo => repo.ListTangibleAsync())
                            .ReturnsAsync(resourcelibs);

                // Act
                var result = await ControllerUnderTest.ListTangibleAsync();

                // Assert
                var okResult = Assert.IsType<OkObjectResult>(result);
                var entity = Assert.IsType<ResourceLibrary[]>(okResult.Value);

                // Assert.Equal(1, entity.Length);
                Assert.Equal("TANGIBLE", entity[0].Type);
            }


        }

        public class ListOpexCPPAsync : ResourceControllerTest
        {
            private ResourceLibrary[] resourcelibs;

            public ListOpexCPPAsync()
            {

                resourcelibs = new ResourceLibrary[]
                {
                    new ResourceLibrary()    {
                        Id = "29d69d7a-ea8a-4b92-a202-02962b03c7f0",
                        Name = "Drill Time",
                        ValueType = "VARIABLE",
                        Value = null,
                        PlannerType = "CALCULATED",
                        //"section": null,
                        Type = "TANGIBLE",
                        IsReadonly = true,
                        Description = null,
                        By = "admin",
                        Status = "ACTIVE",
                        //"created": "2017-06-24T11:07:14"
                    },
                    new ResourceLibrary()    {
                        Id = "2ca16741-2cb2-47ba-a76b-b41264a233d4",
                        Name = "Trip In Time",
                        ValueType = "FIXED",
                        Value = null,
                        PlannerType = "CALCULATED",
                        // "section": null,
                        Type = "TIME",
                        IsReadonly = false,
                        Description = null,
                        By = "admin",
                        Status = "ACTIVE",
                        //  "created": "2017-06-24T11:07:14"
                    },
                    new ResourceLibrary()   {
                        Id = "c8f9bd8e-6ac1-4f3e-9ea0-73eb203ea3ad",
                        Name = "Rig Cost",
                        ValueType = "VARIABLE",
                        Value = 0,
                        PlannerType = "CALCULATED",
                        //"section": null,
                        Type = "COST",
                        IsReadonly = true,
                        Description = null,
                        By = "admin",
                        Status = "ACTIVE",
                        //  "created": "2017-06-24T11:07:14"
                    },

                   new ResourceLibrary()   {
                        Id = "tang",
                        Name = "Rigt Cost",
                        ValueType = "FIXED",
                        Value = 90,
                        Type = "TANGIBLE",
                    },


                    new ResourceLibrary()   {
                        Id = "opex",
                        Name = "OPEXCPP",
                        ValueType = "FIXED",
                        Value = 90,
                        Type = "OPEX",
                    }

                };
            }
            [Fact]
            [Trait("Category", "Resource")]
            public async Task should_return_the_OkObjectResult_of_a_all_type_resource()
            {
                // Arrange
                //string type = null;
                //setup DI
                mockService.Setup(repo => repo.ListOpexCPPAsync())
                            .ReturnsAsync(resourcelibs);

                // Act
                var result = await ControllerUnderTest.ListOpexCPPAsync();

                // Assert
                var okResult = Assert.IsType<OkObjectResult>(result);
                var entity = Assert.IsType<ResourceLibrary[]>(okResult.Value);

                //Assert.Equal(1, entity.Length);
                Assert.Equal("OPEX", entity[4].Type);
            }


        }
    }
}