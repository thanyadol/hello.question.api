using Moq;
using surflex.netcore22.Exceptions;
using surflex.netcore22.Helpers.DataHandler;
using surflex.netcore22.Helpers.TemplateProfile;
using System.Threading.Tasks;
using Xunit;
using ExcelRange = surflex.netcore22.Helpers.DataHandler.Range;

namespace surflex.netcore22.test.Utilities
{
    public class ExcelTemplateProfileTest
    {
        protected Mock<IExcelEngine> mockExcel;

        public ExcelTemplateProfileTest()
        {
            mockExcel = new Mock<IExcelEngine>();
        }

        [Fact]
        [Trait("Category", "TemplateProfile")]
        public async void should_be_able_to_validate_is_required_single_record_pass()
        {
            await Task.Delay(0);
            var scalarSheetName = DPITemplateCTEPProfile.SHEET_NAMES["SCALAR_INPUT"];
            var lookUpRange = "A:A";

            var mockReturn = new ExcelRange();
            mockReturn.Add(new Cell()
            {
                RawValue = "has value",
                Value = "has value",
            });

            var mockWorkSheet = new Mock<IExcelWorksheet>();
            mockWorkSheet.Setup(x => x.GetRange(lookUpRange)).Returns(mockReturn);

            mockExcel.Setup(x => x.GetWorksheet(scalarSheetName)).Returns(mockWorkSheet.Object);

            var profile = new DPITemplateCTEPProfile(mockExcel.Object);
            profile.AddDefinition(new DPITemplateCTEPProfileDefinition()
            {
                Mode = ExcelProfileDefinitionMode.Validate,
                SheetName = scalarSheetName,
                CellRange = lookUpRange,
                Key = "validate_test",
                Label = "validate_test",
                Validation = new ExcelValidation()
                {
                    Label = "validate_test",
                    Type = ExcelCellType.Text,
                    IsRequired = true,
                    IsAllRequired = true,
                    IsValid = true,
                    //IsAllValid = true,
                }
            });
            profile.Execute();
        }

        [Fact]
        [Trait("Category", "TemplateProfile")]
        public async void should_be_able_to_validate_is_required_multi_record_pass()
        {
            await Task.Delay(0);
            var scalarSheetName = DPITemplateCTEPProfile.SHEET_NAMES["SCALAR_INPUT"];
            var lookUpRange = "A:A";

            var mockReturn = new ExcelRange();
            mockReturn.Add(new Cell()
            {
                RawValue = "has value",
                Value = "has value",
            });
            mockReturn.Add(new Cell()
            {
                RawValue = "has value 2",
                Value = "has value 2",
            });

            var mockWorkSheet = new Mock<IExcelWorksheet>();
            mockWorkSheet.Setup(x => x.GetRange(lookUpRange)).Returns(mockReturn);

            mockExcel.Setup(x => x.GetWorksheet(scalarSheetName)).Returns(mockWorkSheet.Object);

            var profile = new DPITemplateCTEPProfile(mockExcel.Object);
            profile.AddDefinition(new DPITemplateCTEPProfileDefinition()
            {
                Mode = ExcelProfileDefinitionMode.Validate,
                SheetName = scalarSheetName,
                CellRange = lookUpRange,
                Key = "validate_test",
                Label = "validate_test",
                Validation = new ExcelValidation()
                {
                    Label = "validate_test",
                    Type = ExcelCellType.Text,
                    IsRequired = true,
                    IsAllRequired = true,
                    IsValid = true,
                    //IsAllValid = true,
                }
            });
            profile.Execute();
        }

        [Fact]
        [Trait("Category", "TemplateProfile")]
        public async void should_be_able_to_validate_is_required_multi_record_failed()
        {
            await Task.Delay(0);
            var scalarSheetName = DPITemplateCTEPProfile.SHEET_NAMES["SCALAR_INPUT"];
            var lookUpRange = "A:A";

            var mockReturn = new ExcelRange();
            mockReturn.Add(new Cell()
            {
                RawValue = "has value",
                Value = "has value",
            });
            mockReturn.Add(new Cell()
            {
                RawValue = null,
                Value = string.Empty,
            });

            var mockWorkSheet = new Mock<IExcelWorksheet>();
            mockWorkSheet.Setup(x => x.GetRange(lookUpRange)).Returns(mockReturn);

            mockExcel.Setup(x => x.GetWorksheet(scalarSheetName)).Returns(mockWorkSheet.Object);

            var profile = new DPITemplateCTEPProfile(mockExcel.Object);
            profile.AddDefinition(new DPITemplateCTEPProfileDefinition()
            {
                Mode = ExcelProfileDefinitionMode.Validate,
                SheetName = scalarSheetName,
                CellRange = lookUpRange,
                Key = "validate_test",
                Label = "validate_test",
                Validation = new ExcelValidation()
                {
                    Label = "validate_test",
                    Type = ExcelCellType.Text,
                    IsRequired = true,
                    IsAllRequired = true,
                    IsValid = true,
                    //IsAllValid = true,
                }
            });

            Assert.Throws<ExcelValidationException>(() => profile.Execute());
        }

        [Fact]
        [Trait("Category", "TemplateProfile")]
        public async void should_be_able_to_validate_is_valid_at_least_one_pass()
        {
            await Task.Delay(0);
            var scalarSheetName = DPITemplateCTEPProfile.SHEET_NAMES["SCALAR_INPUT"];
            var lookUpRange = "A:A";

            var mockReturn = new ExcelRange();
            mockReturn.Add(new Cell()
            {
                RawValue = "has value",
                Value = "has value",
            });
            mockReturn.Add(new Cell()
            {
                RawValue = "this can be any thing",
                Value = "#N/A",
            });

            var mockWorkSheet = new Mock<IExcelWorksheet>();
            mockWorkSheet.Setup(x => x.GetRange(lookUpRange)).Returns(mockReturn);

            mockExcel.Setup(x => x.GetWorksheet(scalarSheetName)).Returns(mockWorkSheet.Object);

            var profile = new DPITemplateCTEPProfile(mockExcel.Object);
            profile.AddDefinition(new DPITemplateCTEPProfileDefinition()
            {
                Mode = ExcelProfileDefinitionMode.Validate,
                SheetName = scalarSheetName,
                CellRange = lookUpRange,
                Key = "validate_test",
                Label = "validate_test",
                Validation = new ExcelValidation()
                {
                    Label = "validate_test",
                    Type = ExcelCellType.Text,
                    IsRequired = true,
                    IsAllRequired = true,
                    IsValid = true,
                    //IsAllValid = true,
                }
            });

            profile.Execute();
        }

        [Fact]
        [Trait("Category", "TemplateProfile")]
        public async void should_be_able_to_validate_is_valid_multi_record_failed()
        {
            await Task.Delay(0);
            var scalarSheetName = DPITemplateCTEPProfile.SHEET_NAMES["SCALAR_INPUT"];
            var lookUpRange = "A:A";

            var mockReturn = new ExcelRange();
            mockReturn.Add(new Cell()
            {
                RawValue = "has value",
                Value = "has value",
            });
            mockReturn.Add(new Cell()
            {
                RawValue = "this can be any thing",
                Value = "#N/A",
            });

            var mockWorkSheet = new Mock<IExcelWorksheet>();
            mockWorkSheet.Setup(x => x.GetRange(lookUpRange)).Returns(mockReturn);

            mockExcel.Setup(x => x.GetWorksheet(scalarSheetName)).Returns(mockWorkSheet.Object);

            var profile = new DPITemplateCTEPProfile(mockExcel.Object);
            profile.AddDefinition(new DPITemplateCTEPProfileDefinition()
            {
                Mode = ExcelProfileDefinitionMode.Validate,
                SheetName = scalarSheetName,
                CellRange = lookUpRange,
                Key = "validate_test",
                Label = "validate_test",
                Validation = new ExcelValidation()
                {
                    Label = "validate_test",
                    Type = ExcelCellType.Text,
                    IsRequired = true,
                    IsAllRequired = true,
                    IsValid = true,
                    IsAllValid = true,
                }
            });

            Assert.Throws<ExcelValidationException>(() => profile.Execute());
        }

        [Fact]
        [Trait("Category", "TemplateProfile")]
        public async void should_be_able_to_validate_is_numeric_multi_record_pass()
        {
            await Task.Delay(0);
            var scalarSheetName = DPITemplateCTEPProfile.SHEET_NAMES["SCALAR_INPUT"];
            var lookUpRange = "A:A";

            var mockReturn = new ExcelRange();
            mockReturn.Add(new Cell()
            {
                RawValue = (decimal)1,
                Value = "1.0",
            });
            mockReturn.Add(new Cell()
            {
                RawValue = (double)1,
                Value = "1.0",
            });
            mockReturn.Add(new Cell()
            {
                RawValue = (float)1,
                Value = "1.0",
            });
            mockReturn.Add(new Cell()
            {
                RawValue = (int)1,
                Value = "1",
            });

            var mockWorkSheet = new Mock<IExcelWorksheet>();
            mockWorkSheet.Setup(x => x.GetRange(lookUpRange)).Returns(mockReturn);

            mockExcel.Setup(x => x.GetWorksheet(scalarSheetName)).Returns(mockWorkSheet.Object);

            var profile = new DPITemplateCTEPProfile(mockExcel.Object);
            profile.AddDefinition(new DPITemplateCTEPProfileDefinition()
            {
                Mode = ExcelProfileDefinitionMode.Validate,
                SheetName = scalarSheetName,
                CellRange = lookUpRange,
                Key = "validate_test",
                Label = "validate_test",
                Validation = new ExcelValidation()
                {
                    Label = "validate_test",
                    Type = ExcelCellType.Numeric,
                    IsRequired = false,
                    IsAllRequired = false,
                    IsValid = false,
                    IsAllValid = false,
                }
            });

            profile.Execute();
        }

        [Fact]
        [Trait("Category", "TemplateProfile")]
        public async void should_be_able_to_validate_is_numeric_multi_record_failed()
        {
            await Task.Delay(0);
            var scalarSheetName = DPITemplateCTEPProfile.SHEET_NAMES["SCALAR_INPUT"];
            var lookUpRange = "A:A";

            var mockReturn = new ExcelRange();
            mockReturn.Add(new Cell()
            {
                RawValue = (decimal)1,
                Value = "1.0",
            });
            mockReturn.Add(new Cell()
            {
                RawValue = (double)1,
                Value = "1.0",
            });
            mockReturn.Add(new Cell()
            {
                RawValue = (float)1,
                Value = "1.0",
            });
            mockReturn.Add(new Cell()
            {
                RawValue = (int)1,
                Value = "1",
            });
            mockReturn.Add(new Cell()
            {
                RawValue = "1.0",
                Value = "1.0",
            });
            mockReturn.Add(new Cell()
            {
                RawValue = "1.0",
                Value = "1.0",
            });

            var mockWorkSheet = new Mock<IExcelWorksheet>();
            mockWorkSheet.Setup(x => x.GetRange(lookUpRange)).Returns(mockReturn);

            mockExcel.Setup(x => x.GetWorksheet(scalarSheetName)).Returns(mockWorkSheet.Object);

            var profile = new DPITemplateCTEPProfile(mockExcel.Object);
            profile.AddDefinition(new DPITemplateCTEPProfileDefinition()
            {
                Mode = ExcelProfileDefinitionMode.Validate,
                SheetName = scalarSheetName,
                CellRange = lookUpRange,
                Key = "validate_test",
                Label = "validate_test",
                Validation = new ExcelValidation()
                {
                    Label = "validate_test",
                    Type = ExcelCellType.Numeric,
                    IsRequired = false,
                    IsAllRequired = false,
                    IsValid = false,
                    IsAllValid = false,
                }
            });

            Assert.Throws<ExcelValidationException>(() => profile.Execute());
        }

        [Fact]
        [Trait("Category", "TemplateProfile")]
        public async void should_be_able_to_get_result_pass()
        {
            await Task.Delay(0);
            var resultSheetName = DPITemplateCTEPProfile.SHEET_NAMES["RESULT"];
            decimal expectedNpv = 1.0M;
            decimal expectedInv = 2.0M;
            decimal expectedDpi = 3.0M;

            var mockWorkSheet = new Mock<IExcelWorksheet>();
            mockWorkSheet.Setup(x => x.GetRange(DPITemplateCTEPProfile.PROJECT_SETUP_VALIDATION_ADDRESSES["RESULT_NPV"])).Returns(new ExcelRange() {
                new Cell()
                {
                    RawValue = expectedNpv,
                    Value = expectedNpv.ToString(),
                }
            });
            mockWorkSheet.Setup(x => x.GetRange(DPITemplateCTEPProfile.PROJECT_SETUP_VALIDATION_ADDRESSES["RESULT_INVESTMENT"])).Returns(new ExcelRange() {
                new Cell()
                {
                    RawValue = expectedInv,
                    Value = expectedInv.ToString(),
                }
            });
            mockWorkSheet.Setup(x => x.GetRange(DPITemplateCTEPProfile.PROJECT_SETUP_VALIDATION_ADDRESSES["RESULT_DPI"])).Returns(new ExcelRange() {
                new Cell()
                {
                    RawValue = expectedDpi,
                    Value = expectedDpi.ToString(),
                }
            });

            mockExcel.Setup(x => x.GetWorksheet(resultSheetName)).Returns(mockWorkSheet.Object);

            var profile = new DPITemplateCTEPProfile(mockExcel.Object);
            profile.AddDPIReadDefinition();
            profile.Execute();
            var actual = profile.GetReadDPI();

            Assert.NotNull(actual);
            Assert.Equal(expectedNpv, actual.NPV);
            Assert.Equal(expectedInv, actual.INV);
            Assert.Equal(expectedDpi, actual.DPI);
        }
    }
}