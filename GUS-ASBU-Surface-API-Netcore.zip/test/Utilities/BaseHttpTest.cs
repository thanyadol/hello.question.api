using Moq;
using System; 

using System.Collections.Generic;
using System.Net.Http;
using System.Text;

//service
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using surflex.netcore22.Services;

//Ee2e
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;

using Microsoft.EntityFrameworkCore;
using surflex.netcore22.APIs.Model;

namespace surflex.netcore22.test.Utilities
{
    public abstract class BaseHttpTest : IDisposable
    {
        protected TestServer Server { get; }
        protected HttpClient Client { get; }
        protected virtual Uri BaseAddress => new Uri("https://localhost:5001");
        protected virtual string Environment => "Development";

        protected IConfiguration _config;

        public BaseHttpTest()
        {

            _config = new ConfigurationBuilder()
              .AddJsonFile("appsetting.mock.json", optional: false)
              .Build();

            var builder = new WebHostBuilder()
                .UseEnvironment(Environment)
                .UseConfiguration(_config)
                .ConfigureServices(ConfigureServices)
                .UseStartup<Startup>();

            Server = new TestServer(builder);
            Client = Server.CreateClient();
            Client.BaseAddress = BaseAddress;
        }

        protected virtual void ConfigureServices(IServiceCollection services)
        {
            //in memory
            services.AddDbContext<NorthwindContext>(opt =>
                opt.UseInMemoryDatabase("Northwind"));

            // services.AddDbContext<IceteaContext>(opt =>
            //     opt.UseInMemoryDatabase("Icetea"));

            // services.AddDbContext<IcebergContext>(opt =>
            //     opt.UseInMemoryDatabase("Iceberg"));

            //rllcp
            services.AddDbContext<IceteaContext>(options =>
                options.UseOracle(_config.GetConnectionString("IceteaConnection")));


            //uidm
            services.AddDbContext<IcebergContext>(options =>
                options.UseOracle(_config.GetConnectionString("IcebergConnection")));


        }

        /* public virtual void Configure(IApplicationBuilder app, IHostingEnvironment _environment)
        {

        }*/

        private bool disposedValue = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    Client.Dispose();
                    Server.Dispose();
                }
                disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
        }
    }
}