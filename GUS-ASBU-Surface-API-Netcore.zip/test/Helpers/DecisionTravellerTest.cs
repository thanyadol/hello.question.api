﻿using AutoMapper;
using Newtonsoft.Json;
using surflex.netcore22.Helpers;
using surflex.netcore22.Models;
using surflex.netcore22.Models.Constants;
using surflex.netcore22.Models.Mapper;
using System; 

using System.Collections.Generic;
using Xunit;

namespace surflex.netcore22.test.Helpers
{
    public class DecisionTravellerTest
    {
        public string inparams;

        public DecisionTravellerTest()
        {
            #region
            inparams = @"{
  ""id"": ""ffc6c00f-0b61-40d6-b8f5-1ac0d4931a54"",
  ""resourceId"": ""ffc6c00f-0b61-40d6-b8f5-1ac0d4931a54"",
  ""name"": ""My Decision Tree"",
  ""status"": ""ACTIVE"",
  ""trees"": {
  ""SilverDecisions"": ""1.1.0"",
  ""buildTimestamp"": 1544382143568,
  ""savetime"": ""2019-08-05T03:28:10.834Z"",
  ""lng"": ""en"",
  ""viewMode"": ""criterion1"",
  ""rule"": ""expected-value-maximization"",
  ""title"": """",
  ""description"": """",
  ""format"": {
                ""locales"": ""en"",
    ""payoff1"": {
                    ""style"": ""currency"",
      ""currency"": ""USD"",
      ""currencyDisplay"": ""symbol"",
      ""minimumFractionDigits"": 0,
      ""maximumFractionDigits"": 2,
      ""useGrouping"": true
    },
    ""payoff2"": {
                    ""style"": ""decimal"",
      ""currency"": ""USD"",
      ""currencyDisplay"": ""symbol"",
      ""minimumFractionDigits"": 0,
      ""maximumFractionDigits"": 2,
      ""useGrouping"": true
    },
    ""probability"": {
                    ""style"": ""decimal"",
      ""minimumFractionDigits"": 2,
      ""maximumFractionDigits"": 3,
      ""useGrouping"": true
    }
            },
  ""treeDesigner"": {
                ""margin"": {
                    ""left"": 25,
      ""right"": 25,
      ""top"": 25,
      ""bottom"": 25
                },
    ""scale"": 1,
    ""lng"": ""en"",
    ""layout"": {
                    ""type"": ""cluster"",
      ""nodeSize"": 40,
      ""limitNodePositioning"": true,
      ""limitTextPositioning"": true,
      ""gridHeight"": 75,
      ""gridWidth"": 150,
      ""edgeSlantWidthMax"": 20
    },
    ""fontFamily"": ""sans-serif"",
    ""fontSize"": ""12px"",
    ""fontWeight"": ""normal"",
    ""fontStyle"": ""normal"",
    ""node"": {
                    ""strokeWidth"": ""1px"",
      ""optimal"": {
                        ""stroke"": ""#006f00"",
        ""strokeWidth"": ""1.5px""
      },
      ""label"": {
                        ""fontSize"": ""1em"",
        ""color"": ""black""
      },
      ""payoff"": {
                        ""fontSize"": ""1em"",
        ""color"": ""black"",
        ""negativeColor"": ""#b60000""
      },
      ""decision"": {
                        ""fill"": ""#ff7777"",
        ""stroke"": ""#660000"",
        ""selected"": {
                            ""fill"": ""#aa3333""
        }
                    },
      ""chance"": {
                        ""fill"": ""#ffff44"",
        ""stroke"": ""#666600"",
        ""selected"": {
                            ""fill"": ""#aaaa00""
        }
                    },
      ""terminal"": {
                        ""fill"": ""#44ff44"",
        ""stroke"": ""black"",
        ""selected"": {
                            ""fill"": ""#00aa00""
        },
        ""payoff"": {
                            ""fontSize"": ""1em"",
          ""color"": ""black"",
          ""negativeColor"": ""#b60000""
        }
                    }
                },
    ""edge"": {
                    ""stroke"": ""#424242"",
      ""strokeWidth"": ""1.5"",
      ""optimal"": {
                        ""stroke"": ""#006f00"",
        ""strokeWidth"": ""2.4""
      },
      ""selected"": {
                        ""stroke"": ""#045ad1"",
        ""strokeWidth"": ""3.5""
      },
      ""label"": {
                        ""fontSize"": ""1em"",
        ""color"": ""back""
      },
      ""payoff"": {
                        ""fontSize"": ""1em"",
        ""color"": ""black"",
        ""negativeColor"": ""#b60000""
      }
                },
    ""probability"": {
                    ""fontSize"": ""1em"",
      ""color"": ""#0000d7""
    },
    ""title"": {
                    ""fontSize"": ""16px"",
      ""fontWeight"": ""bold"",
      ""fontStyle"": ""normal"",
      ""color"": ""#000000"",
      ""margin"": {
                        ""top"": 15,
        ""bottom"": 10
      }
                },
    ""description"": {
                    ""show"": true,
      ""fontSize"": ""12px"",
      ""fontWeight"": ""bold"",
      ""fontStyle"": ""normal"",
      ""color"": ""#000000"",
      ""margin"": {
                        ""top"": 5,
        ""bottom"": 10
      }
                },
    ""readOnly"": false,
    ""disableAnimations"": false,
    ""forceFullEdgeRedraw"": false,
    ""hideLabels"": false,
    ""hidePayoffs"": false,
    ""hideProbabilities"": false,
    ""raw"": true,
    ""payoffNames"": [
      null,
      null
    ],
    ""maxPayoffsToDisplay"": 1
  },
  ""data"": {
    ""code"": """",
    ""expressionScope"": {},
    ""trees"": [
      {
        ""computed"": {
          ""expected-value-maximization"": {
            ""childrenPayoff"": [
              ""800""
            ],
            ""payoff"": [
              ""800""
            ],
            ""optimal"": true
          },
          ""expected-value-minimization"": {
            ""childrenPayoff"": [
              ""0""
            ],
            ""payoff"": [
              ""0""
            ],
            ""optimal"": true
          },
          ""maxi-min"": {
            ""childrenPayoff"": [
              ""500""
            ],
            ""payoff"": [
              ""500""
            ],
            ""optimal"": true
          },
          ""maxi-max"": {
            ""childrenPayoff"": [
              ""1200""
            ],
            ""payoff"": [
              ""1200""
            ],
            ""optimal"": true
          },
          ""mini-min"": {
            ""childrenPayoff"": [
              ""0""
            ],
            ""payoff"": [
              ""0""
            ],
            ""optimal"": true
          },
          ""mini-max"": {
            ""childrenPayoff"": [
              ""0""
            ],
            ""payoff"": [
              ""0""
            ],
            ""optimal"": true
          },
          ""min-max"": {
            ""childrenPayoff"": [
              ""0"",
              ""0""
            ],
            ""combinedPayoff"": ""0"",
            ""payoff"": [
              ""0"",
              ""0""
            ],
            ""optimal"": true
          },
          ""max-min"": {
            ""childrenPayoff"": [
              ""800"",
              ""0""
            ],
            ""combinedPayoff"": ""800"",
            ""payoff"": [
              ""800"",
              ""0""
            ],
            ""optimal"": true
          },
          ""min-min"": {
            ""childrenPayoff"": [
              ""0"",
              ""0""
            ],
            ""combinedPayoff"": ""0"",
            ""payoff"": [
              ""0"",
              ""0""
            ],
            ""optimal"": true
          },
          ""max-max"": {
            ""childrenPayoff"": [
              ""800"",
              ""0""
            ],
            ""combinedPayoff"": ""800"",
            ""payoff"": [
              ""800"",
              ""0""
            ],
            ""optimal"": true
          }
        },
        ""childEdges"": [
          {
            ""id"": ""c977c3b3-5a3f-41c7-9c70-49bc26d86998"",
            ""name"": ""Cement Squeeze\n10;20;30"",
            ""payoff"": [
              0,
              0
            ],
            ""childNode"": {
              ""childEdges"": [
                {
                  ""id"": ""47d88ebd-6646-4994-a64b-a4927302edda"",
                  ""name"": ""Success\nDrill to TD"",
                  ""probability"": ""#"",
                  ""payoff"": [
                    ""500"",
                    0
                  ],
                  ""childNode"": {
                    ""childEdges"": [],
                    ""name"": """",
                    ""code"": """",
                    ""expressionScope"": {},
                    ""folded"": false,
                    ""location"": {
                      ""x"": 620,
                      ""y"": 20
                    },
                    ""type"": ""terminal""
                  }
                },
                {
                  ""computed"": {
                    ""payoff"": [
                      ""0"",
                      ""0""
                    ],
                    ""probability"": ""1/2"",
                    ""expected-value-maximization"": {
                      ""probability"": ""1/2"",
                      ""optimal"": true
                    },
                    ""expected-value-minimization"": {
                      ""probability"": ""1/2""
                    },
                    ""maxi-min"": {
                      ""probability"": 0,
                      ""optimal"": false
                    },
                    ""maxi-max"": {
                      ""probability"": 1,
                      ""optimal"": true
                    },
                    ""mini-min"": {
                      ""probability"": 1,
                      ""optimal"": true
                    },
                    ""mini-max"": {
                      ""probability"": 0
                    },
                    ""min-max"": {
                      ""probability"": ""1/2""
                    },
                    ""max-min"": {
                      ""probability"": ""1/2"",
                      ""optimal"": true
                    },
                    ""min-min"": {
                      ""probability"": ""1/2""
                    },
                    ""max-max"": {
                      ""probability"": ""1/2"",
                      ""optimal"": true
                    }
                  },
                  ""name"": ""Failed"",
                  ""probability"": ""#"",
                  ""payoff"": [
                    0,
                    0
                  ],
                  ""childNode"": {
                    ""computed"": {
                      ""expected-value-maximization"": {
                        ""childrenPayoff"": [
                          ""1100""
                        ],
                        ""payoff"": [
                          ""1100""
                        ],
                        ""optimal"": true
                      },
                      ""expected-value-minimization"": {
                        ""childrenPayoff"": [
                          ""0""
                        ],
                        ""payoff"": [
                          ""0""
                        ]
                      },
                      ""maxi-min"": {
                        ""childrenPayoff"": [
                          ""1000""
                        ],
                        ""payoff"": [
                          ""1000""
                        ]
                      },
                      ""maxi-max"": {
                        ""childrenPayoff"": [
                          ""1200""
                        ],
                        ""payoff"": [
                          ""1200""
                        ],
                        ""optimal"": true
                      },
                      ""mini-min"": {
                        ""childrenPayoff"": [
                          ""0""
                        ],
                        ""payoff"": [
                          ""0""
                        ],
                        ""optimal"": true
                      },
                      ""mini-max"": {
                        ""childrenPayoff"": [
                          ""0""
                        ],
                        ""payoff"": [
                          ""0""
                        ]
                      },
                      ""min-max"": {
                        ""childrenPayoff"": [
                          ""0"",
                          ""0""
                        ],
                        ""combinedPayoff"": ""0"",
                        ""payoff"": [
                          ""0"",
                          ""0""
                        ]
                      },
                      ""max-min"": {
                        ""childrenPayoff"": [
                          ""1100"",
                          ""0""
                        ],
                        ""combinedPayoff"": ""1100"",
                        ""payoff"": [
                          ""1100"",
                          ""0""
                        ],
                        ""optimal"": true
                      },
                      ""min-min"": {
                        ""childrenPayoff"": [
                          ""0"",
                          ""0""
                        ],
                        ""combinedPayoff"": ""0"",
                        ""payoff"": [
                          ""0"",
                          ""0""
                        ]
                      },
                      ""max-max"": {
                        ""childrenPayoff"": [
                          ""1100"",
                          ""0""
                        ],
                        ""combinedPayoff"": ""1100"",
                        ""payoff"": [
                          ""1100"",
                          ""0""
                        ],
                        ""optimal"": true
                      }
                    },
                    ""childEdges"": [
                      {
                        ""computed"": {
                          ""payoff"": [
                            ""1000"",
                            ""0""
                          ],
                          ""expected-value-maximization"": {
                            ""probability"": 1,
                            ""optimal"": true
                          },
                          ""expected-value-minimization"": {
                            ""probability"": 0
                          },
                          ""maxi-min"": {
                            ""probability"": 1
                          },
                          ""maxi-max"": {
                            ""probability"": 1,
                            ""optimal"": true
                          },
                          ""mini-min"": {
                            ""probability"": 0,
                            ""optimal"": false
                          },
                          ""mini-max"": {
                            ""probability"": 0
                          },
                          ""min-max"": {
                            ""probability"": 0
                          },
                          ""max-min"": {
                            ""probability"": 1,
                            ""optimal"": true
                          },
                          ""min-min"": {
                            ""probability"": 0
                          },
                          ""max-max"": {
                            ""probability"": 1,
                            ""optimal"": true
                          }
                        },
                        ""name"": ""Cement Squeeze"",
                        ""payoff"": [
                          ""1000"",
                          0
                        ],
                        ""childNode"": {
                          ""computed"": {
                            ""expected-value-maximization"": {
                              ""childrenPayoff"": [
                                ""100""
                              ],
                              ""payoff"": [
                                ""1100""
                              ],
                              ""optimal"": true
                            },
                            ""expected-value-minimization"": {
                              ""childrenPayoff"": [
                                ""100""
                              ],
                              ""payoff"": [
                                ""1100""
                              ]
                            },
                            ""maxi-min"": {
                              ""childrenPayoff"": [
                                ""0""
                              ],
                              ""payoff"": [
                                ""1000""
                              ]
                            },
                            ""maxi-max"": {
                              ""childrenPayoff"": [
                                ""200""
                              ],
                              ""payoff"": [
                                ""1200""
                              ],
                              ""optimal"": true
                            },
                            ""mini-min"": {
                              ""childrenPayoff"": [
                                ""0""
                              ],
                              ""payoff"": [
                                ""1000""
                              ]
                            },
                            ""mini-max"": {
                              ""childrenPayoff"": [
                                ""200""
                              ],
                              ""payoff"": [
                                ""1200""
                              ]
                            },
                            ""min-max"": {
                              ""childrenPayoff"": [
                                ""100"",
                                ""0""
                              ],
                              ""combinedPayoff"": ""-1100"",
                              ""payoff"": [
                                ""1100"",
                                ""0""
                              ]
                            },
                            ""max-min"": {
                              ""childrenPayoff"": [
                                ""100"",
                                ""0""
                              ],
                              ""combinedPayoff"": ""1100"",
                              ""payoff"": [
                                ""1100"",
                                ""0""
                              ],
                              ""optimal"": true
                            },
                            ""min-min"": {
                              ""childrenPayoff"": [
                                ""100"",
                                ""0""
                              ],
                              ""combinedPayoff"": ""-1100"",
                              ""payoff"": [
                                ""1100"",
                                ""0""
                              ]
                            },
                            ""max-max"": {
                              ""childrenPayoff"": [
                                ""100"",
                                ""0""
                              ],
                              ""combinedPayoff"": ""1100"",
                              ""payoff"": [
                                ""1100"",
                                ""0""
                              ],
                              ""optimal"": true
                            }
                          },
                          ""childEdges"": [
                            {
                              ""computed"": {
                                ""payoff"": [
                                  ""200"",
                                  ""0""
                                ],
                                ""probability"": ""1/2"",
                                ""expected-value-maximization"": {
                                  ""probability"": ""1/2"",
                                  ""optimal"": true
                                },
                                ""expected-value-minimization"": {
                                  ""probability"": ""1/2""
                                },
                                ""maxi-min"": {
                                  ""probability"": 0
                                },
                                ""maxi-max"": {
                                  ""probability"": 1,
                                  ""optimal"": true
                                },
                                ""mini-min"": {
                                  ""probability"": 0
                                },
                                ""mini-max"": {
                                  ""probability"": 1
                                },
                                ""min-max"": {
                                  ""probability"": ""1/2""
                                },
                                ""max-min"": {
                                  ""probability"": ""1/2"",
                                  ""optimal"": true
                                },
                                ""min-min"": {
                                  ""probability"": ""1/2""
                                },
                                ""max-max"": {
                                  ""probability"": ""1/2"",
                                  ""optimal"": true
                                }
                              },
                              ""name"": ""Success\nDrill to TD"",
                              ""probability"": ""#"",
                              ""payoff"": [
                                ""200"",
                                0
                              ],
                              ""childNode"": {
                                ""computed"": {
                                  ""expected-value-maximization"": {
                                    ""aggregatedPayoff"": [
                                      ""1200""
                                    ],
                                    ""probabilityToEnter"": ""1/4"",
                                    ""payoff"": [
                                      ""200""
                                    ],
                                    ""optimal"": true
                                  },
                                  ""expected-value-minimization"": {
                                    ""aggregatedPayoff"": [
                                      ""1200""
                                    ],
                                    ""probabilityToEnter"": 0,
                                    ""payoff"": [
                                      ""200""
                                    ]
                                  },
                                  ""maxi-min"": {
                                    ""aggregatedPayoff"": [
                                      ""1200""
                                    ],
                                    ""probabilityToEnter"": 0,
                                    ""payoff"": [
                                      ""200""
                                    ]
                                  },
                                  ""maxi-max"": {
                                    ""aggregatedPayoff"": [
                                      ""1200""
                                    ],
                                    ""probabilityToEnter"": ""1"",
                                    ""payoff"": [
                                      ""200""
                                    ],
                                    ""optimal"": true
                                  },
                                  ""mini-min"": {
                                    ""aggregatedPayoff"": [
                                      ""1200""
                                    ],
                                    ""probabilityToEnter"": 0,
                                    ""payoff"": [
                                      ""200""
                                    ]
                                  },
                                  ""mini-max"": {
                                    ""aggregatedPayoff"": [
                                      ""1200""
                                    ],
                                    ""probabilityToEnter"": 0,
                                    ""payoff"": [
                                      ""200""
                                    ]
                                  },
                                  ""min-max"": {
                                    ""aggregatedPayoff"": [
                                      ""1200"",
                                      ""0""
                                    ],
                                    ""probabilityToEnter"": 0,
                                    ""combinedPayoff"": ""-200"",
                                    ""payoff"": [
                                      ""200"",
                                      ""0""
                                    ]
                                  },
                                  ""max-min"": {
                                    ""aggregatedPayoff"": [
                                      ""1200"",
                                      ""0""
                                    ],
                                    ""probabilityToEnter"": ""1/4"",
                                    ""combinedPayoff"": ""200"",
                                    ""payoff"": [
                                      ""200"",
                                      ""0""
                                    ],
                                    ""optimal"": true
                                  },
                                  ""min-min"": {
                                    ""aggregatedPayoff"": [
                                      ""1200"",
                                      ""0""
                                    ],
                                    ""probabilityToEnter"": 0,
                                    ""combinedPayoff"": ""-200"",
                                    ""payoff"": [
                                      ""200"",
                                      ""0""
                                    ]
                                  },
                                  ""max-max"": {
                                    ""aggregatedPayoff"": [
                                      ""1200"",
                                      ""0""
                                    ],
                                    ""probabilityToEnter"": ""1/4"",
                                    ""combinedPayoff"": ""200"",
                                    ""payoff"": [
                                      ""200"",
                                      ""0""
                                    ],
                                    ""optimal"": true
                                  }
                                },
                                ""childEdges"": [],
                                ""name"": """",
                                ""code"": """",
                                ""expressionScope"": {},
                                ""folded"": false,
                                ""location"": {
                                  ""x"": 620,
                                  ""y"": 110
                                },
                                ""type"": ""terminal""
                              }
                            },
                            {
                              ""computed"": {
                                ""payoff"": [
                                  ""0"",
                                  ""0""
                                ],
                                ""probability"": ""1/2"",
                                ""expected-value-maximization"": {
                                  ""probability"": ""1/2"",
                                  ""optimal"": true
                                },
                                ""expected-value-minimization"": {
                                  ""probability"": ""1/2""
                                },
                                ""maxi-min"": {
                                  ""probability"": 1
                                },
                                ""maxi-max"": {
                                  ""probability"": 0,
                                  ""optimal"": false
                                },
                                ""mini-min"": {
                                  ""probability"": 1
                                },
                                ""mini-max"": {
                                  ""probability"": 0
                                },
                                ""min-max"": {
                                  ""probability"": ""1/2""
                                },
                                ""max-min"": {
                                  ""probability"": ""1/2"",
                                  ""optimal"": true
                                },
                                ""min-min"": {
                                  ""probability"": ""1/2""
                                },
                                ""max-max"": {
                                  ""probability"": ""1/2"",
                                  ""optimal"": true
                                }
                              },
                              ""name"": ""Failed\nShorten TD"",
                              ""probability"": ""#"",
                              ""payoff"": [
                                0,
                                0
                              ],
                              ""childNode"": {
                                ""computed"": {
                                  ""expected-value-maximization"": {
                                    ""aggregatedPayoff"": [
                                      ""1000""
                                    ],
                                    ""probabilityToEnter"": ""1/4"",
                                    ""payoff"": [
                                      ""0""
                                    ],
                                    ""optimal"": true
                                  },
                                  ""expected-value-minimization"": {
                                    ""aggregatedPayoff"": [
                                      ""1000""
                                    ],
                                    ""probabilityToEnter"": 0,
                                    ""payoff"": [
                                      ""0""
                                    ]
                                  },
                                  ""maxi-min"": {
                                    ""aggregatedPayoff"": [
                                      ""1000""
                                    ],
                                    ""probabilityToEnter"": 0,
                                    ""payoff"": [
                                      ""0""
                                    ]
                                  },
                                  ""maxi-max"": {
                                    ""aggregatedPayoff"": [
                                      ""1000""
                                    ],
                                    ""probabilityToEnter"": 0,
                                    ""payoff"": [
                                      ""0""
                                    ]
                                  },
                                  ""mini-min"": {
                                    ""aggregatedPayoff"": [
                                      ""1000""
                                    ],
                                    ""probabilityToEnter"": 0,
                                    ""payoff"": [
                                      ""0""
                                    ]
                                  },
                                  ""mini-max"": {
                                    ""aggregatedPayoff"": [
                                      ""1000""
                                    ],
                                    ""probabilityToEnter"": 0,
                                    ""payoff"": [
                                      ""0""
                                    ]
                                  },
                                  ""min-max"": {
                                    ""aggregatedPayoff"": [
                                      ""1000"",
                                      ""0""
                                    ],
                                    ""probabilityToEnter"": 0,
                                    ""combinedPayoff"": ""0"",
                                    ""payoff"": [
                                      ""0"",
                                      ""0""
                                    ]
                                  },
                                  ""max-min"": {
                                    ""aggregatedPayoff"": [
                                      ""1000"",
                                      ""0""
                                    ],
                                    ""probabilityToEnter"": ""1/4"",
                                    ""combinedPayoff"": ""0"",
                                    ""payoff"": [
                                      ""0"",
                                      ""0""
                                    ],
                                    ""optimal"": true
                                  },
                                  ""min-min"": {
                                    ""aggregatedPayoff"": [
                                      ""1000"",
                                      ""0""
                                    ],
                                    ""probabilityToEnter"": 0,
                                    ""combinedPayoff"": ""0"",
                                    ""payoff"": [
                                      ""0"",
                                      ""0""
                                    ]
                                  },
                                  ""max-max"": {
                                    ""aggregatedPayoff"": [
                                      ""1000"",
                                      ""0""
                                    ],
                                    ""probabilityToEnter"": ""1/4"",
                                    ""combinedPayoff"": ""0"",
                                    ""payoff"": [
                                      ""0"",
                                      ""0""
                                    ],
                                    ""optimal"": true
                                  }
                                },
                                ""childEdges"": [],
                                ""name"": """",
                                ""code"": """",
                                ""expressionScope"": {},
                                ""folded"": false,
                                ""location"": {
                                  ""x"": 620,
                                  ""y"": 185
                                },
                                ""type"": ""terminal""
                              }
                            }
                          ],
                          ""name"": """",
                          ""code"": """",
                          ""expressionScope"": {},
                          ""folded"": false,
                          ""location"": {
                            ""x"": 470,
                            ""y"": 147.5
                          },
                          ""type"": ""chance""
                        }
                      },
                      {
                        ""computed"": {
                          ""payoff"": [
                            ""0"",
                            ""0""
                          ],
                          ""expected-value-maximization"": {
                            ""probability"": 0,
                            ""optimal"": false
                          },
                          ""expected-value-minimization"": {
                            ""probability"": 1
                          },
                          ""maxi-min"": {
                            ""probability"": 0
                          },
                          ""maxi-max"": {
                            ""probability"": 0,
                            ""optimal"": false
                          },
                          ""mini-min"": {
                            ""probability"": 1,
                            ""optimal"": true
                          },
                          ""mini-max"": {
                            ""probability"": 1
                          },
                          ""min-max"": {
                            ""probability"": 1
                          },
                          ""max-min"": {
                            ""probability"": 0,
                            ""optimal"": false
                          },
                          ""min-min"": {
                            ""probability"": 1
                          },
                          ""max-max"": {
                            ""probability"": 0,
                            ""optimal"": false
                          }
                        },
                        ""name"": ""Shorten TD"",
                        ""payoff"": [
                          0,
                          0
                        ],
                        ""childNode"": {
                          ""computed"": {
                            ""expected-value-maximization"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""expected-value-minimization"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""maxi-min"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""maxi-max"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""mini-min"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": ""1"",
                              ""payoff"": [
                                ""0""
                              ],
                              ""optimal"": true
                            },
                            ""mini-max"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""min-max"": {
                              ""aggregatedPayoff"": [
                                ""0"",
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""combinedPayoff"": ""0"",
                              ""payoff"": [
                                ""0"",
                                ""0""
                              ]
                            },
                            ""max-min"": {
                              ""aggregatedPayoff"": [
                                ""0"",
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""combinedPayoff"": ""0"",
                              ""payoff"": [
                                ""0"",
                                ""0""
                              ]
                            },
                            ""min-min"": {
                              ""aggregatedPayoff"": [
                                ""0"",
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""combinedPayoff"": ""0"",
                              ""payoff"": [
                                ""0"",
                                ""0""
                              ]
                            },
                            ""max-max"": {
                              ""aggregatedPayoff"": [
                                ""0"",
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""combinedPayoff"": ""0"",
                              ""payoff"": [
                                ""0"",
                                ""0""
                              ]
                            }
                          },
                          ""childEdges"": [],
                          ""name"": """",
                          ""code"": """",
                          ""expressionScope"": {},
                          ""folded"": false,
                          ""location"": {
                            ""x"": 620,
                            ""y"": 275
                          },
                          ""type"": ""terminal""
                        }
                      },
                      {
                        ""computed"": {
                          ""payoff"": [
                            ""0"",
                            ""0""
                          ],
                          ""expected-value-maximization"": {
                            ""probability"": 0,
                            ""optimal"": false
                          },
                          ""expected-value-minimization"": {
                            ""probability"": 1
                          },
                          ""maxi-min"": {
                            ""probability"": 0
                          },
                          ""maxi-max"": {
                            ""probability"": 0,
                            ""optimal"": false
                          },
                          ""mini-min"": {
                            ""probability"": 1,
                            ""optimal"": true
                          },
                          ""mini-max"": {
                            ""probability"": 1
                          },
                          ""min-max"": {
                            ""probability"": 1
                          },
                          ""max-min"": {
                            ""probability"": 0,
                            ""optimal"": false
                          },
                          ""min-min"": {
                            ""probability"": 1
                          },
                          ""max-max"": {
                            ""probability"": 0,
                            ""optimal"": false
                          }
                        },
                        ""name"": ""P&A Reuse Casing Standalone"",
                        ""payoff"": [
                          0,
                          0
                        ],
                        ""childNode"": {
                          ""computed"": {
                            ""expected-value-maximization"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""expected-value-minimization"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""maxi-min"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""maxi-max"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""mini-min"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": ""1"",
                              ""payoff"": [
                                ""0""
                              ],
                              ""optimal"": true
                            },
                            ""mini-max"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""min-max"": {
                              ""aggregatedPayoff"": [
                                ""0"",
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""combinedPayoff"": ""0"",
                              ""payoff"": [
                                ""0"",
                                ""0""
                              ]
                            },
                            ""max-min"": {
                              ""aggregatedPayoff"": [
                                ""0"",
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""combinedPayoff"": ""0"",
                              ""payoff"": [
                                ""0"",
                                ""0""
                              ]
                            },
                            ""min-min"": {
                              ""aggregatedPayoff"": [
                                ""0"",
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""combinedPayoff"": ""0"",
                              ""payoff"": [
                                ""0"",
                                ""0""
                              ]
                            },
                            ""max-max"": {
                              ""aggregatedPayoff"": [
                                ""0"",
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""combinedPayoff"": ""0"",
                              ""payoff"": [
                                ""0"",
                                ""0""
                              ]
                            }
                          },
                          ""childEdges"": [],
                          ""name"": """",
                          ""code"": """",
                          ""expressionScope"": {},
                          ""folded"": false,
                          ""location"": {
                            ""x"": 620,
                            ""y"": 350
                          },
                          ""type"": ""terminal""
                        }
                      },
                      {
                        ""computed"": {
                          ""payoff"": [
                            ""0"",
                            ""0""
                          ],
                          ""expected-value-maximization"": {
                            ""probability"": 0,
                            ""optimal"": false
                          },
                          ""expected-value-minimization"": {
                            ""probability"": 1
                          },
                          ""maxi-min"": {
                            ""probability"": 0
                          },
                          ""maxi-max"": {
                            ""probability"": 0,
                            ""optimal"": false
                          },
                          ""mini-min"": {
                            ""probability"": 1,
                            ""optimal"": true
                          },
                          ""mini-max"": {
                            ""probability"": 1
                          },
                          ""min-max"": {
                            ""probability"": 1
                          },
                          ""max-min"": {
                            ""probability"": 0,
                            ""optimal"": false
                          },
                          ""min-min"": {
                            ""probability"": 1
                          },
                          ""max-max"": {
                            ""probability"": 0,
                            ""optimal"": false
                          }
                        },
                        ""name"": ""P&A Full Slot Recovery Standalone"",
                        ""payoff"": [
                          0,
                          0
                        ],
                        ""childNode"": {
                          ""computed"": {
                            ""expected-value-maximization"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""expected-value-minimization"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""maxi-min"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""maxi-max"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""mini-min"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": ""1"",
                              ""payoff"": [
                                ""0""
                              ],
                              ""optimal"": true
                            },
                            ""mini-max"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""min-max"": {
                              ""aggregatedPayoff"": [
                                ""0"",
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""combinedPayoff"": ""0"",
                              ""payoff"": [
                                ""0"",
                                ""0""
                              ]
                            },
                            ""max-min"": {
                              ""aggregatedPayoff"": [
                                ""0"",
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""combinedPayoff"": ""0"",
                              ""payoff"": [
                                ""0"",
                                ""0""
                              ]
                            },
                            ""min-min"": {
                              ""aggregatedPayoff"": [
                                ""0"",
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""combinedPayoff"": ""0"",
                              ""payoff"": [
                                ""0"",
                                ""0""
                              ]
                            },
                            ""max-max"": {
                              ""aggregatedPayoff"": [
                                ""0"",
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""combinedPayoff"": ""0"",
                              ""payoff"": [
                                ""0"",
                                ""0""
                              ]
                            }
                          },
                          ""childEdges"": [],
                          ""name"": """",
                          ""code"": """",
                          ""expressionScope"": {},
                          ""folded"": false,
                          ""location"": {
                            ""x"": 620,
                            ""y"": 425
                          },
                          ""type"": ""terminal""
                        }
                      },
                      {
                        ""computed"": {
                          ""payoff"": [
                            ""0"",
                            ""0""
                          ],
                          ""expected-value-maximization"": {
                            ""probability"": 0,
                            ""optimal"": false
                          },
                          ""expected-value-minimization"": {
                            ""probability"": 1
                          },
                          ""maxi-min"": {
                            ""probability"": 0
                          },
                          ""maxi-max"": {
                            ""probability"": 0,
                            ""optimal"": false
                          },
                          ""mini-min"": {
                            ""probability"": 1,
                            ""optimal"": true
                          },
                          ""mini-max"": {
                            ""probability"": 1
                          },
                          ""min-max"": {
                            ""probability"": 1
                          },
                          ""max-min"": {
                            ""probability"": 0,
                            ""optimal"": false
                          },
                          ""min-min"": {
                            ""probability"": 1
                          },
                          ""max-max"": {
                            ""probability"": 0,
                            ""optimal"": false
                          }
                        },
                        ""name"": ""P&A Reuse Casing"",
                        ""payoff"": [
                          0,
                          0
                        ],
                        ""childNode"": {
                          ""computed"": {
                            ""expected-value-maximization"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""expected-value-minimization"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""maxi-min"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""maxi-max"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""mini-min"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": ""1"",
                              ""payoff"": [
                                ""0""
                              ],
                              ""optimal"": true
                            },
                            ""mini-max"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""min-max"": {
                              ""aggregatedPayoff"": [
                                ""0"",
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""combinedPayoff"": ""0"",
                              ""payoff"": [
                                ""0"",
                                ""0""
                              ]
                            },
                            ""max-min"": {
                              ""aggregatedPayoff"": [
                                ""0"",
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""combinedPayoff"": ""0"",
                              ""payoff"": [
                                ""0"",
                                ""0""
                              ]
                            },
                            ""min-min"": {
                              ""aggregatedPayoff"": [
                                ""0"",
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""combinedPayoff"": ""0"",
                              ""payoff"": [
                                ""0"",
                                ""0""
                              ]
                            },
                            ""max-max"": {
                              ""aggregatedPayoff"": [
                                ""0"",
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""combinedPayoff"": ""0"",
                              ""payoff"": [
                                ""0"",
                                ""0""
                              ]
                            }
                          },
                          ""childEdges"": [],
                          ""name"": """",
                          ""code"": """",
                          ""expressionScope"": {},
                          ""folded"": false,
                          ""location"": {
                            ""x"": 620,
                            ""y"": 500
                          },
                          ""type"": ""terminal""
                        }
                      },
                      {
                        ""computed"": {
                          ""payoff"": [
                            ""0"",
                            ""0""
                          ],
                          ""expected-value-maximization"": {
                            ""probability"": 0,
                            ""optimal"": false
                          },
                          ""expected-value-minimization"": {
                            ""probability"": 1
                          },
                          ""maxi-min"": {
                            ""probability"": 0
                          },
                          ""maxi-max"": {
                            ""probability"": 0,
                            ""optimal"": false
                          },
                          ""mini-min"": {
                            ""probability"": 1,
                            ""optimal"": true
                          },
                          ""mini-max"": {
                            ""probability"": 1
                          },
                          ""min-max"": {
                            ""probability"": 1
                          },
                          ""max-min"": {
                            ""probability"": 0,
                            ""optimal"": false
                          },
                          ""min-min"": {
                            ""probability"": 1
                          },
                          ""max-max"": {
                            ""probability"": 0,
                            ""optimal"": false
                          }
                        },
                        ""name"": ""P&A Full Slot Recovery"",
                        ""payoff"": [
                          0,
                          0
                        ],
                        ""childNode"": {
                          ""computed"": {
                            ""expected-value-maximization"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""expected-value-minimization"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""maxi-min"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""maxi-max"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""mini-min"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": ""1"",
                              ""payoff"": [
                                ""0""
                              ],
                              ""optimal"": true
                            },
                            ""mini-max"": {
                              ""aggregatedPayoff"": [
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""payoff"": [
                                ""0""
                              ]
                            },
                            ""min-max"": {
                              ""aggregatedPayoff"": [
                                ""0"",
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""combinedPayoff"": ""0"",
                              ""payoff"": [
                                ""0"",
                                ""0""
                              ]
                            },
                            ""max-min"": {
                              ""aggregatedPayoff"": [
                                ""0"",
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""combinedPayoff"": ""0"",
                              ""payoff"": [
                                ""0"",
                                ""0""
                              ]
                            },
                            ""min-min"": {
                              ""aggregatedPayoff"": [
                                ""0"",
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""combinedPayoff"": ""0"",
                              ""payoff"": [
                                ""0"",
                                ""0""
                              ]
                            },
                            ""max-max"": {
                              ""aggregatedPayoff"": [
                                ""0"",
                                ""0""
                              ],
                              ""probabilityToEnter"": 0,
                              ""combinedPayoff"": ""0"",
                              ""payoff"": [
                                ""0"",
                                ""0""
                              ]
                            }
                          },
                          ""childEdges"": [],
                          ""name"": """",
                          ""code"": """",
                          ""expressionScope"": {},
                          ""folded"": false,
                          ""location"": {
                            ""x"": 620,
                            ""y"": 575
                          },
                          ""type"": ""terminal""
                        }
                      }
                    ],
                    ""name"": """",
                    ""code"": """",
                    ""expressionScope"": {},
                    ""folded"": false,
                    ""location"": {
                      ""x"": 320,
                      ""y"": 378.75000000000005
                    },
                    ""type"": ""decision""
                  }
                }
              ],
              ""id"": ""ba74b6d4-abc6-4ca1-ad8a-4a2efd2ee9c4"",
              ""name"": """",
              ""code"": """",
              ""expressionScope"": {},
              ""folded"": false,
              ""location"": {
                ""x"": 170,
                ""y"": 199.375
              },
              ""type"": ""chance""
            }
          },
          {
            ""id"": ""8c17297b-17ec-4150-a022-97d74ac4e377"",
            ""name"": ""Shorten TD"",
            ""payoff"": [
              0,
              0
            ],
            ""childNode"": {
              ""computed"": {
                ""expected-value-maximization"": {
                  ""aggregatedPayoff"": [
                    ""0""
                  ],
                  ""probabilityToEnter"": 0,
                  ""payoff"": [
                    ""0""
                  ]
                },
                ""expected-value-minimization"": {
                  ""aggregatedPayoff"": [
                    ""0""
                  ],
                  ""probabilityToEnter"": ""1"",
                  ""payoff"": [
                    ""0""
                  ],
                  ""optimal"": true
                },
                ""maxi-min"": {
                  ""aggregatedPayoff"": [
                    ""0""
                  ],
                  ""probabilityToEnter"": 0,
                  ""payoff"": [
                    ""0""
                  ]
                },
                ""maxi-max"": {
                  ""aggregatedPayoff"": [
                    ""0""
                  ],
                  ""probabilityToEnter"": 0,
                  ""payoff"": [
                    ""0""
                  ]
                },
                ""mini-min"": {
                  ""aggregatedPayoff"": [
                    ""0""
                  ],
                  ""probabilityToEnter"": ""1"",
                  ""payoff"": [
                    ""0""
                  ],
                  ""optimal"": true
                },
                ""mini-max"": {
                  ""aggregatedPayoff"": [
                    ""0""
                  ],
                  ""probabilityToEnter"": ""1"",
                  ""payoff"": [
                    ""0""
                  ],
                  ""optimal"": true
                },
                ""min-max"": {
                  ""aggregatedPayoff"": [
                    ""0"",
                    ""0""
                  ],
                  ""probabilityToEnter"": ""1"",
                  ""combinedPayoff"": ""0"",
                  ""payoff"": [
                    ""0"",
                    ""0""
                  ],
                  ""optimal"": true
                },
                ""max-min"": {
                  ""aggregatedPayoff"": [
                    ""0"",
                    ""0""
                  ],
                  ""probabilityToEnter"": 0,
                  ""combinedPayoff"": ""0"",
                  ""payoff"": [
                    ""0"",
                    ""0""
                  ]
                },
                ""min-min"": {
                  ""aggregatedPayoff"": [
                    ""0"",
                    ""0""
                  ],
                  ""probabilityToEnter"": ""1"",
                  ""combinedPayoff"": ""0"",
                  ""payoff"": [
                    ""0"",
                    ""0""
                  ],
                  ""optimal"": true
                },
                ""max-max"": {
                  ""aggregatedPayoff"": [
                    ""0"",
                    ""0""
                  ],
                  ""probabilityToEnter"": 0,
                  ""combinedPayoff"": ""0"",
                  ""payoff"": [
                    ""0"",
                    ""0""
                  ]
                }
              },
              ""childEdges"": [],
              ""name"": """",
              ""code"": """",
              ""expressionScope"": {},
              ""folded"": false,
              ""location"": {
                ""x"": 620,
                ""y"": 665
              },
              ""type"": ""terminal""
            }
          }
        ],
        ""name"": """",
        ""code"": """",
        ""expressionScope"": {},
        ""folded"": false,
        ""location"": {
          ""x"": 20,
          ""y"": 432.1875
        },
        ""type"": ""decision""
      }
    ],
    ""texts"": [],
    ""payoffNames"": [],
    ""defaultCriterion1Weight"": 1,
    ""weightLowerBound"": 0,
    ""weightUpperBound"": ""Infinity""
  },
  ""sensitivityAnalysis"": {}
}
}";

            #endregion Test inputs
        }

        public class Deserilize : DecisionTravellerTest
        {
            [Fact]
            [Trait("Category", "WellScenario")]
            public void Should_be_able_to_deserialize_saved_object()
            {
                var result = JsonConvert.DeserializeObject<WellScenarioParams>(inparams);

                Assert.NotNull(result.Trees.Data);
                Assert.NotEmpty(result.Trees.Data.Trees);
            }
        }

        public class Extract : DecisionTravellerTest
        {
            [Fact]
            [Trait("Category", "WellScenario")]
            public void Should_be_able_to_extract_from_saved_object()
            {
                var inObj = JsonConvert.DeserializeObject<WellScenarioParams>(inparams);

                var savedObj = inObj.Trees;

                var result = DecisionTraveller.ExtractFromSavedObject((Guid)inObj.Id, savedObj);

                Assert.NotNull(result.tree);
                Assert.NotEmpty(result.nodes);
                Assert.NotEmpty(result.edges);
            }
        }

        public class Build : DecisionTravellerTest
        {
            [Fact]
            [Trait("Category", "WellScenario")]
            public void Should_be_able_to_build_from_dto()
            {
                var inObj = JsonConvert.DeserializeObject<WellScenarioParams>(inparams);

                var savedObj = inObj.Trees;

                var result = DecisionTraveller.ExtractFromSavedObject((Guid)inObj.Id, savedObj);

                var built = DecisionTraveller.BuildFromEntity(result.tree, result.nodes, result.edges);

                Assert.NotEmpty(built.Data.Trees);
            }
        }

        public class Map : DecisionTravellerTest
        {
            public IMapper Mapper;

            public Map() : base()
            {
                var mappingProfile = new MappingProfile();
                var config = new MapperConfiguration(cfg =>
                {
                    cfg.AddProfile(mappingProfile);
                });
                Mapper = config.CreateMapper();
            }

            [Fact]
            [Trait("Category", "WellScenario")]
            public void Should_be_able_to_map_preset_well_scenario_from_dto()
            {
                var decisionTreeDto = new DecisionTreeDto()
                {
                    WellScenarioId = Guid.NewGuid(),
                    Name = "Name",
                    Description = "Desc"
                };

                var presetWellScenario = Mapper.Map<PresetWellScenario>(decisionTreeDto);

                Assert.Equal(decisionTreeDto.WellScenarioId, presetWellScenario.Id);
                Assert.Equal(decisionTreeDto.Name, presetWellScenario.Name);
                Assert.Equal(decisionTreeDto.Description, presetWellScenario.Description);
            }

            [Fact]
            [Trait("Category", "WellScenario")]
            public void Should_be_able_to_map_well_scenario_from_dto()
            {
                var decisionTreeDto = new DecisionTreeDto()
                {
                    WellScenarioId = Guid.NewGuid(),
                    Name = "Name",
                    Description = "Desc"
                };

                var wellScenario = Mapper.Map<WellScenario>(decisionTreeDto);

                Assert.Equal(decisionTreeDto.WellScenarioId, wellScenario.Id);
                Assert.Equal(decisionTreeDto.Name, wellScenario.Name);
                Assert.Equal(decisionTreeDto.Description, wellScenario.Description);
            }

            [Fact]
            [Trait("Category", "WellScenario")]
            public void Should_be_able_to_map_preset_node_from_dto()
            {
                var decisionNodeDto = new DecisionNodeDto()
                {
                    Id = Guid.NewGuid(),
                    Name = "Name",
                    TreeId = Guid.NewGuid(),
                    Type = GlobalConstants.DECISION_TREE_NODE_TYPE_CHANCE,
                    X = 1,
                    Y = 2,
                    DPI = (decimal)1.2
                };

                var presetDecisionNode = Mapper.Map<PresetWellScenarioNode>(decisionNodeDto);

                Assert.Equal(decisionNodeDto.Id, presetDecisionNode.Id);
                Assert.Equal(decisionNodeDto.Name, presetDecisionNode.Name);
                Assert.Equal(decisionNodeDto.Type, presetDecisionNode.Type);
                Assert.Equal(decisionNodeDto.X, presetDecisionNode.X);
                Assert.Equal(decisionNodeDto.Y, presetDecisionNode.Y);
            }

            [Fact]
            [Trait("Category", "WellScenario")]
            public void Should_be_able_to_map_node_from_dto()
            {
                var decisionNodeDto = new DecisionNodeDto()
                {
                    Id = Guid.NewGuid(),
                    Name = "Name",
                    TreeId = Guid.NewGuid(),
                    Type = GlobalConstants.DECISION_TREE_NODE_TYPE_CHANCE,
                    X = 1,
                    Y = 2,
                    DPI = (decimal)1.2
                };

                var decisionNode = Mapper.Map<WellScenarioNode>(decisionNodeDto);

                Assert.Equal(decisionNodeDto.Id, decisionNode.Id);
                Assert.Equal(decisionNodeDto.Name, decisionNode.Name);
                Assert.Equal(decisionNodeDto.Type, decisionNode.Type);
                Assert.Equal(decisionNodeDto.X, decisionNode.X);
                Assert.Equal(decisionNodeDto.Y, decisionNode.Y);
            }

            [Fact]
            [Trait("Category", "WellScenario")]
            public void Should_be_able_to_map_edges_from_dtos()
            {

                var decisionEdgeDtos = new List<DecisionEdgeDto>()
                {
                    new DecisionEdgeDto()
                    {
                        Id = Guid.NewGuid(),
                        ActivityId = Guid.NewGuid(),
                        FromId = Guid.NewGuid(),
                        ToId = Guid.NewGuid(),
                        Payoff1 = "1.00",
                        Payoff2 = "2.00",
                        Probability = "1/2"
                    },
                    new DecisionEdgeDto()
                    {
                        Id = Guid.NewGuid(),
                        ActivityId = Guid.NewGuid(),
                        FromId = Guid.NewGuid(),
                        ToId = Guid.NewGuid(),
                        Payoff1 = "2.00",
                        Payoff2 = "3.00",
                        Probability = "2 1/2"
                    }
                };

                var decisionEdges = Mapper.Map<List<PresetWellScenarioEdge>>(decisionEdgeDtos);

                Assert.NotNull(decisionEdges);
                Assert.Equal(decisionEdgeDtos.Count, decisionEdges.Count);
                Assert.Equal(decisionEdgeDtos[0].Id, decisionEdges[0].Id);
                Assert.Equal(decisionEdgeDtos[1].Id, decisionEdges[1].Id);
                Assert.Equal(decisionEdgeDtos[0].ActivityId, decisionEdges[0].ActivityId);
                Assert.Equal(decisionEdgeDtos[1].ActivityId, decisionEdges[1].ActivityId);
                Assert.Equal(decisionEdgeDtos[0].FromId, decisionEdges[0].FromId);
                Assert.Equal(decisionEdgeDtos[1].FromId, decisionEdges[1].FromId);
                Assert.Equal(decisionEdgeDtos[0].ToId, decisionEdges[0].ToId);
                Assert.Equal(decisionEdgeDtos[1].ToId, decisionEdges[1].ToId);
                Assert.Equal(decisionEdgeDtos[0].Payoff1, decisionEdges[0].Payoff1);
                Assert.Equal(decisionEdgeDtos[1].Payoff1, decisionEdges[1].Payoff1);
                Assert.Equal(decisionEdgeDtos[0].Payoff2, decisionEdges[0].Payoff2);
                Assert.Equal(decisionEdgeDtos[1].Payoff2, decisionEdges[1].Payoff2);
                Assert.Equal(decisionEdgeDtos[0].Probability, decisionEdges[0].Probability);
                Assert.Equal(decisionEdgeDtos[1].Probability, decisionEdges[1].Probability);
            }
        }
    }
}