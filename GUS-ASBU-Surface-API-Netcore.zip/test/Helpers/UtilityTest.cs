using AutoMapper;
using Newtonsoft.Json;
using surflex.netcore22.Helpers;
using surflex.netcore22.Models;
using surflex.netcore22.Models.Constants;
using surflex.netcore22.Models.Mapper;
using System; 

using System.Collections.Generic;
using Xunit;

namespace surflex.netcore22.test.Helpers
{
    public class UtilityTest
    {

    }
}
