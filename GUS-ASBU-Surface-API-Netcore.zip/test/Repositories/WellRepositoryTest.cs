
using System; 

using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xunit;

using Moq;

//service
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace surflex.netcore22.test.Repositories
{
    public class WellRepositoryTest
    {
        protected ProjectRepository RepositoryUnderTest { get; }
        protected Project[] Projects { get; }

        protected Mock<DbSet<Project>> mockDBSet { get; }
        protected Mock<NorthwindContext> mockDBContext { get; }

        public WellRepositoryTest()
        {

        }

    }
}