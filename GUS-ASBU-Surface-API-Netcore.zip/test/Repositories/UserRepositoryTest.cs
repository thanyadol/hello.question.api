
using System; 

using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xunit;

using Moq;

//service
using surflex.netcore22.Models;
using surflex.netcore22.Repositories;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace surflex.netcore22.test.Repositories
{
    public class UserRepositoryTest
    {
        protected UserRepository RepositoryUnderTest { get; }
        protected User[] Users { get; }

        protected Mock<DbSet<User>> mockDBSet { get; }
        protected Mock<NorthwindContext> mockDBContext { get; }

        public UserRepositoryTest()
        {
            // Arrange - We're mocking our dbSet & dbContext
            // in-memory data
            /* Users = new User[]
                     {
                        new User() {
                                    Id = "0c57eb18-2dc7-467a-aabd-4faa3ec7e031",
                                    CAI = "KRIT",
                                    Name = null,
                                    Unique = "krithoonsawan@chevron.com",
                                    Role = "PETROLIUM ENGINEER",
                                    Token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9",
                                    IsAuthenticate = false,
                                },
                        new User() {
                                    Id = "1c57eb18-2dc7-467a-aabd-4faa3ec7e032",
                                    CAI = "RATT",
                                    Name = "Rattakan Wanna [Accenture]",
                                    Unique = "rattakanwanna@chevron.com",
                                    Role = "ADMIN",
                                    Token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9",
                                    IsAuthenticate = true,
                                },
                        new User() {
                                    Id = "2c57eb18-2dc7-467a-aabd-4faa3ec7e033",
                                    CAI = "HRXZ",
                                    Name = "Thanyadol Chantarawong",
                                    Unique = "thanyadol.ch@chevron.com",
                                    Role = "EARTH SCIENTIST",
                                    Token = "fyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ0",
                                    IsAuthenticate = true,
                                },
                     };

           /*  var queryableUser = Users.AsQueryable();

            // To query our database we need to implement IQueryable 
            mockDBSet = new Mock<DbSet<User>>();

            mockDBSet.As<IQueryable<User>>().Setup(m => m.Provider).Returns(queryableUser.Provider);
            mockDBSet.As<IQueryable<User>>().Setup(m => m.Expression).Returns(queryableUser.Expression);
            mockDBSet.As<IQueryable<User>>().Setup(m => m.ElementType).Returns(queryableUser.ElementType);
            mockDBSet.As<IQueryable<User>>().Setup(m => m.GetEnumerator()).Returns(queryableUser.GetEnumerator());

            mockDBContext = new Mock<NorthwindContext>();
            mockDBContext.Setup(c => c.Users).Returns(mockDBSet.Object);

            // Act - fetch books
            RepositoryUnderTest = new UserRepository(mockDBContext.Object);*/
        }

        /* public class HierarchyAsync : UserRepositoryTest
        {
            [Fact]
            public async Task should_return_all_users()
            {
                // Arrange
                var expectedUser = Users[1];
                int expectedUserCount = Users.Count();
                var expectedUserName = expectedUser.Name;

                mockDBSet.Setup(c => c.ToListAsync(queryableUser)).Returns(queryableUser);


                // Act
                var result = await RepositoryUnderTest.HierarchyAsync();

                // Assert
                Assert.Equal(expectedUserCount, result.Count());
                Assert.Equal(expectedUserName, result.First().Name);

                Assert.Collection(result,
                    users => Assert.Same(Users[0], users),
                    users => Assert.Same(Users[1], users),
                    users => Assert.Same(Users[2], users)
                );
            }
        }*/

        /* public class GetAsync : UserRepositoryTest
        {
            [Fact]
            public async Task should_return_the_expected_user()
            {
                // Arrange
                var expectedUser = Users[1];
                var expectedUserName = expectedUser.Unique;

                // Act
                var result = await RepositoryUnderTest.GetAsync(expectedUserName);

                // Assert
                Assert.Same(expectedUser, result);
            }

            [Fact]
            public async Task should_return_null_if_the_user_does_not_exist()
            {
                // Arrange
                var unexistingUserName = "Unexisting Unique";

                // Act
                var result = await RepositoryUnderTest.GetAsync(unexistingUserName);

                // Assert
                Assert.Null(result);
            }
        }*/

        /* public class CreateAsync : UserRepositoryTest
        {

            [Fact]
            public async Task should_create_and_return_created_user()
            {
                var expectedUser = Users[1];
                var createdUser = await RepositoryUnderTest.CreateAsync(expectedUser);

                // Assert
                // These two lines of code verifies that a book was added once and
                // we saved our changes once.
                mockDBSet.Verify(m => m.Add(It.IsAny<User>()), Times.Once);
                mockDBContext.Verify(m => m.SaveChanges(), Times.Once);
            }

        }*/

        /* public class UpdateAsync : UserRepositoryTest
        {
            [Fact]
            public async Task should_update_and_return_created_user()
            {
                var expectedUser = Users[1];
                var createdUser = await RepositoryUnderTest.UpdateAsync(expectedUser);

                // Assert
                // These two lines of code verifies that a book was added once and
                // we saved our changes once.
                mockDBSet.Verify(m => m.Update(It.IsAny<User>()), Times.Once);
                mockDBContext.Verify(m => m.SaveChanges(), Times.Once);
            }

        }*/

        /*public class DeleteAsync : UserRepositoryTest
        {
            [Fact]
            public async Task should_update_and_return_created_user()
            {
                var deleteUserId = Users[1].Id;
                var deletedUser = await RepositoryUnderTest.DeleteAsync(deleteUserId);

                // Assert
                // These two lines of code verifies that a book was added once and
                // we saved our changes once.
                mockDBSet.Verify(m => m.Remove(It.IsAny<User>()), Times.Once);
                mockDBContext.Verify(m => m.SaveChanges(), Times.Once);
            }
        }*/
    }
}