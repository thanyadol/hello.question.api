﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chevron.PullStatus.Models
{
    [Flags]
    public enum JobStatus
    {
        [Description("Not Started")]
        NOTSTART,

        [Description("Pending")]
        PENDING,

        [Description("Running")]
        RUNNING,

        [Description("Failed")]
        FAILED,

        [Description("Succeeded")]
        SUCCEEDED,

        [Description("Skipped")]
        SKIPPED,

        [Description("Initialize")]
        INITIALIZE,
    }
}
