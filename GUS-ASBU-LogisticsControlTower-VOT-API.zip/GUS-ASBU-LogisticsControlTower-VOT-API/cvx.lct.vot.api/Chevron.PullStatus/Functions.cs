﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Newtonsoft.Json;
using Microsoft.Azure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Queue;
using Chevron.PullStatus.Models;
using Chevron.PullStatus.Extensions;
using Chevron.PullStatus.Services;

namespace Chevron.PullStatus
{
    public class Functions
    {
        public static void ProcessQueueMessage([QueueTrigger("databrickjobs")] string message, TextWriter log)
        {
            log.WriteLine(message);
            try
            {

                var job = JsonConvert.DeserializeObject<Job>(message);

                VotService votService = new VotService();
                job = votService.PollStatus(job);

                if (IsInprogress(job.Status))
                {
                    QueueService.Instance.AddMessage(JsonConvert.SerializeObject(job));
                }
                else
                {
                    log.WriteLine($"JobId {job.Id} is completed");
                }
            }catch(Exception e)
            {
                LogService.Instance.Exception(e);
                log.WriteLine(JsonConvert.SerializeObject(e));
                throw e;
            }
        }

        private static bool IsInprogress(string status)
        {
            return status == JobStatus.PENDING.GetDescription() ||
                status == JobStatus.RUNNING.GetDescription() ||
                status == JobStatus.INITIALIZE.GetDescription();
        }
    }

    public class Job
    {
        public Guid Id { get; set; }
        //public Guid PlanId { get; set; }
        public string Status { get; set; }
        public string RunId { get; set; }
        public string RunMessage { get; set; }
    }
}
