﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Azure.WebJobs;
using Chevron.PullStatus.Services;

namespace Chevron.PullStatus
{
    class Program
    {
        static void Main(string[] args)
        {
            var environment = "";
             Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            if (args.Length == 0 || string.IsNullOrEmpty(args[0]))
            {
                //Console.WriteLine($"No environment argument");
                environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            }
            else
            {
                environment = args[0];
            }

            var builder = new HostBuilder()
                .UseEnvironment(environment)
                .ConfigureWebJobs(b =>
                {
                    b.AddAzureStorageCoreServices()
                    .AddAzureStorage();
                })
                .ConfigureAppConfiguration((builderContext, config) =>
                {
                    config.AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                        .AddJsonFile($"appsettings.{environment}.json", optional: false, reloadOnChange: true);
                    
                    ConfigurationService.Instance.SetConfiguration(config.Build());
                    var blobConn = ConfigurationService.Instance.BlobConnectionString();
                    var quereOptions = new Dictionary<string, string>
                    {
                        {"AzureWebJobsDashboard", blobConn},
                        {"AzureWebJobsStorage", blobConn}
                    };

                    config.AddInMemoryCollection(quereOptions);

                })
                .ConfigureLogging((context, b) =>
                {
                    b.SetMinimumLevel(LogLevel.Warning);
                    b.AddConsole();
                    b.AddApplicationInsights();
                })
                .UseConsoleLifetime();

            //Console.WriteLine($"Environment {environment}");

            var host = builder.Build();
            Task.Run(async () =>
           {
               await host.RunAsync();
           }).Wait();
        }
    }
}
