﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Queue;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chevron.PullStatus.Services
{
    interface IAzureQueue
    {
        void AddMessage(string msg);
    }

    public class  QueueService : IAzureQueue
    {
        private static CloudQueueClient  _queueClient;
        private static CloudQueue _queue;

        private static readonly QueueService instance = new QueueService();

        static QueueService()
        {
            ConnectQueue();
        }
        public static QueueService Instance
        {
            get
            {
                return instance;
            }
        }

        public void AddMessage(string msg)
        {
            CloudQueueMessage queueMsg = new CloudQueueMessage(msg);
            Task.Run(async () =>
            {
                await _queue.AddMessageAsync(queueMsg);
            }).Wait();
        }

        private static void ConnectQueue()
        {
            if (_queueClient != null) return;

            var connectinString = ConfigurationService.Instance.BlobConnectionString();
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(connectinString);

            _queueClient = storageAccount.CreateCloudQueueClient();
            _queue = _queueClient.GetQueueReference(ConfigurationService.Instance.QueueDatabrick());
            _queue.CreateIfNotExistsAsync();
        }
    }
}
