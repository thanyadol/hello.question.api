﻿using Microsoft.ApplicationInsights;
using System;
using System.Collections.Generic;
using System.Text;

namespace Chevron.PullStatus.Services
{
    interface ILogService
    {
        void TrackTrace(string msg);
        void Exception(Exception ex);
    }
    class LogService
    {

        private static TelemetryClient _telemetry;
        private static readonly LogService instance = new LogService();

        static LogService()
        {
            if(_telemetry == null)
                _telemetry = new TelemetryClient();
        }
        public static LogService Instance
        {
            get
            {
                return instance;
            }
        }

        public void TrackTrace(string msg)
        {
            _telemetry.TrackTrace(msg);
        }

        public void Exception(Exception ex)
        {
            _telemetry.TrackException(ex);
        }

    }
}
