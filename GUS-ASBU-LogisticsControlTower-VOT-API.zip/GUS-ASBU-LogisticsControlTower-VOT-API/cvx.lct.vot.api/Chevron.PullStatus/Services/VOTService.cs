﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Chevron.PullStatus.Services
{
    public interface IVotService
    {
        Job UpdateJob(Job job);
        Job PollStatus(Job job);
    }

    public class VotService : IVotService
    {
        private string _apiUrl { get; set; }
        private HttpClient HttpClient(string token)
        {
            _apiUrl = ConfigurationService.Instance.ApiUri();
            var httpClientHandler = new HttpClientHandler();

            httpClientHandler.DefaultProxyCredentials = System.Net.CredentialCache.DefaultNetworkCredentials;

            HttpClient client = new HttpClient(handler: httpClientHandler, disposeHandler: true);
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            return client;
        }

        public Job PollStatus(Job job)
        {
            var token = AuthenticationService.Instance.GetAuthenticationTokenAsync();

            HttpClient client = this.HttpClient(token);

            var response = client.GetAsync(_apiUrl + $"api/1.0/job/status?id={job.Id}").Result;

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"API Error: Can't get job status in databrick job name { job.RunId}");
            }

            var result = JsonConvert.DeserializeObject<Job>(response.Content.ReadAsStringAsync().Result);


            return result;
        }

        public Job UpdateJob(Job job)
        {
            var token = AuthenticationService.Instance.GetAuthenticationTokenAsync();

            HttpClient client = this.HttpClient(token);

            HttpContent httpContent = new StringContent(JsonConvert.SerializeObject(job));
            httpContent.Headers.ContentType.MediaType = "application/json";

            var response = client.PutAsync(_apiUrl + $"api/1.0/job/put", httpContent).Result;

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"API Error: Can't get job status in databrick job name { job.RunId}");
            }

            var result = JsonConvert.DeserializeObject<Job>(response.Content.ReadAsStringAsync().Result);


            return result;
        }
    }
}
