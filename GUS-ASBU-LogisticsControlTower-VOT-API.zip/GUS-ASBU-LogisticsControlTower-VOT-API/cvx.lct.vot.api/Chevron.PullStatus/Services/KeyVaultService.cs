﻿using Chevron.KeyVault.Client;
using Microsoft.Azure.KeyVault.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chevron.PullStatus.Services
{
    class KeyVaultService
    {
        private static string _keyVaultName;

        private static readonly KeyVaultService instance = new KeyVaultService();

        static KeyVaultService()
        {
            _keyVaultName = ConfigurationService.Instance.KeyVaultName();
        }
        public static KeyVaultService Instance
        {
            get
            {
                return instance;
            }
        }

        public SecretBundle GetSecret(string secretName)
        {
            var kv = new CvxKeyVaultClient(_keyVaultName, Chevron.KeyVault.Client.ServiceTokenProviders.TokenProvider.AutoDetectTokenProvider);
            SecretBundle mySecret = null;
            Task.Run(async () =>
            {
                mySecret = await kv.GetSecretAsync(secretName);
            }).Wait();

            return mySecret;
        }

        public SecretBundle GetSecret(string keyVaultName, string secretName)
        {
            var kv = new CvxKeyVaultClient(keyVaultName, Chevron.KeyVault.Client.ServiceTokenProviders.TokenProvider.AutoDetectTokenProvider);
            SecretBundle mySecret = null;
            Task.Run(async () =>
            {
                mySecret = await kv.GetSecretAsync(secretName);
            }).Wait();

            return mySecret;
        }
    }
}
