﻿using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chevron.PullStatus.Services
{
    class AuthenticationService
    {
        private const string AuthorityUri = "https://login.microsoftonline.com/fd799da1-bfc1-4234-a91c-72b3a1cb9e26";
        private const string BatchResourceUri = "https://batch.core.windows.net/";
        private const string BatchAccountUrl = "https://myaccount.mylocation.batch.azure.com";
        private const string RedirectUri = "https://lct-api-dev.azure.chevron.com/";

        private static readonly AuthenticationService instance = new AuthenticationService();

        static AuthenticationService()
        {

        }
        public static AuthenticationService Instance
        {
            get
            {
                return instance;
            }
        }

        public string GetAuthenticationTokenAsync()
        {
            var clientId = KeyVaultService.Instance.GetSecret("cvx-az-client-id").Value;
            var clientSecret = KeyVaultService.Instance.GetSecret("app-secret").Value;

            var authContext = new AuthenticationContext(AuthorityUri);

            // Acquire the authentication token from Azure AD.
            AuthenticationResult authResult = null;
            Task.Run(async () =>
            {
                authResult = await authContext.AcquireTokenAsync(clientId,
                                                                   new ClientCredential(clientId, clientSecret));
            }).Wait();
            
            return authResult.AccessToken;
           
        }

    }
}
