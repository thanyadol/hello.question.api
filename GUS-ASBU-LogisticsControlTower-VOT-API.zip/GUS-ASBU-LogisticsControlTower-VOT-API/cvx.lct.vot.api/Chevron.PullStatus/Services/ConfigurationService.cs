﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace Chevron.PullStatus.Services
{
    public sealed class ConfigurationService
    {
        private WebJobOption _webJobOption;
        private static readonly ConfigurationService instance = new ConfigurationService();
        static ConfigurationService()
        {

        }

        public static ConfigurationService Instance
        {
            get
            {
                return instance;
            }
        }

        public string KeyVaultName()
        {
            return _webJobOption.KeyVaultName;

        }

        public string ApiUri()
        {
            return _webJobOption.APIUrl;
        }

        internal void SetConfiguration(IConfiguration configuration)
        {
            _webJobOption = configuration.GetSection("WebJobConfig").Get<WebJobOption>();
        }

        public string BlobConnectionString()
        {
            return KeyVaultService.Instance.GetSecret(_webJobOption.BlobConnectionKey).Value;
        }

        public string QueueDatabrick()
        {
            return _webJobOption.DatabrickQueue;
        }
    }

    public class WebJobOption
    {
        public string APIUrl { get; set; }
        public string KeyVaultName { get; set; }
        public string BlobConnectionKey { get; set; }
        public string DatabrickQueue { get; set; }
    }
}
