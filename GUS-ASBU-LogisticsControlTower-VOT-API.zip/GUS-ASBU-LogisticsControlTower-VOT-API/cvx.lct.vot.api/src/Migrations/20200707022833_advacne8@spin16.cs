﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace cvx.lct.vot.api.Migrations
{
    public partial class advacne8spin16 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "dbo");

            migrationBuilder.CreateTable(
                name: "__EFLoggingEvent",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Level = table.Column<string>(maxLength: 20, nullable: true),
                    TimeStamp = table.Column<DateTimeOffset>(nullable: false),
                    Unique = table.Column<string>(maxLength: 50, nullable: true),
                    Message = table.Column<string>(nullable: true),
                    MessageTemplate = table.Column<string>(maxLength: 500, nullable: true),
                    Exception = table.Column<string>(nullable: true),
                    Type = table.Column<string>(maxLength: 20, nullable: true),
                    ErrorCode = table.Column<string>(maxLength: 20, nullable: true),
                    RequestId = table.Column<Guid>(nullable: false),
                    RequestPath = table.Column<string>(maxLength: 500, nullable: true),
                    RequestScheme = table.Column<string>(nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Date = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK___EFLoggingEvent", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Cargo",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(maxLength: 100, nullable: true),
                    Type = table.Column<string>(maxLength: 10, nullable: true),
                    By = table.Column<string>(nullable: true),
                    RecordStatus = table.Column<string>(maxLength: 10, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cargo", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "CargoPriority",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    UserCoefficient = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    NormalizedCoefficient = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    Name = table.Column<string>(maxLength: 100, nullable: true),
                    CargoId = table.Column<Guid>(nullable: true),
                    PlanCargoId = table.Column<Guid>(nullable: false),
                    Order = table.Column<int>(nullable: false),
                    BoundType = table.Column<string>(maxLength: 20, nullable: true),
                    LocationType = table.Column<string>(maxLength: 20, nullable: true),
                    Priority = table.Column<string>(maxLength: 10, nullable: true),
                    Type = table.Column<string>(maxLength: 10, nullable: true),
                    IsIncludeToCalculate = table.Column<bool>(nullable: false),
                    By = table.Column<string>(nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    InsertState = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CargoPriority", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Job",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    PlanId = table.Column<Guid>(nullable: false),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Status = table.Column<string>(maxLength: 50, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    RunId = table.Column<string>(nullable: true),
                    RunMessage = table.Column<string>(nullable: true),
                    ExecuteTime = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    SolutionLimit = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Job", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Location",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    LCTReferenceId = table.Column<int>(nullable: true),
                    Code = table.Column<string>(maxLength: 50, nullable: true),
                    Name = table.Column<string>(maxLength: 50, nullable: true),
                    Lat = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    Long = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    Type = table.Column<string>(maxLength: 50, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Description = table.Column<string>(maxLength: 50, nullable: true),
                    RecordStatus = table.Column<string>(maxLength: 10, nullable: true),
                    ParentLocationLCTReferenceId = table.Column<int>(nullable: true),
                    ChildLocationLCTReferenceId = table.Column<int>(nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Location", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "LocationState",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    LocationId = table.Column<Guid>(nullable: false),
                    LocationCode = table.Column<string>(maxLength: 20, nullable: true),
                    PlanLocationId = table.Column<Guid>(nullable: false),
                    LCTReferenceId = table.Column<int>(nullable: true),
                    Activity = table.Column<string>(maxLength: 20, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    IsIncludeToCalculate = table.Column<bool>(nullable: false),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    ScheduleDateStart = table.Column<DateTime>(type: "datetime", nullable: true),
                    ScheduleDateEnd = table.Column<DateTime>(type: "datetime", nullable: true),
                    RestrictedTimeStart = table.Column<TimeSpan>(type: "time(7)", nullable: true),
                    RestrictedTimeEnd = table.Column<TimeSpan>(type: "time(7)", nullable: true),
                    IsTanker = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LocationState", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Material",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    LCTReferenceId = table.Column<int>(nullable: true),
                    Name = table.Column<string>(maxLength: 50, nullable: true),
                    Type = table.Column<string>(maxLength: 20, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Description = table.Column<string>(maxLength: 50, nullable: true),
                    RecordStatus = table.Column<string>(maxLength: 10, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Material", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "MaterialRequest",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    MaterialId = table.Column<Guid>(nullable: true),
                    PlanId = table.Column<Guid>(nullable: true),
                    BoundType = table.Column<string>(nullable: true),
                    LCTMRMaterialRequestDetailsId = table.Column<int>(nullable: true),
                    LCTMRMaterialRequestId = table.Column<int>(nullable: true),
                    ROSDate = table.Column<DateTime>(nullable: true),
                    PlannedDispatchDate = table.Column<DateTime>(nullable: true),
                    Asset = table.Column<string>(maxLength: 100, nullable: true),
                    LCTMRDepartmentReferenceId = table.Column<int>(nullable: true),
                    From = table.Column<string>(maxLength: 100, nullable: true),
                    LCTOriginReferenceId = table.Column<int>(nullable: true),
                    To = table.Column<string>(maxLength: 100, nullable: true),
                    LCTDestinationReferenceId = table.Column<int>(nullable: true),
                    Department = table.Column<string>(maxLength: 50, nullable: true),
                    ItemType = table.Column<string>(nullable: true),
                    QuantityValue = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    MRQuantityUnitReferenceId = table.Column<int>(nullable: true),
                    WeightValue = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    MRWeightUnitReferenceId = table.Column<int>(nullable: true),
                    Length = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    Width = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    Height = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    Area = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    Remarks = table.Column<string>(maxLength: 500, nullable: true),
                    QuantityUnit = table.Column<string>(maxLength: 50, nullable: true),
                    Qty = table.Column<int>(nullable: true),
                    Weight = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    MRPriorityReferenceId = table.Column<int>(nullable: true),
                    Priority = table.Column<string>(maxLength: 50, nullable: true),
                    Description = table.Column<string>(maxLength: 5000, nullable: true),
                    IsIncludeToCalculate = table.Column<bool>(nullable: false),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    LCTOrderNumber = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MaterialRequest", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ModelParameter",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    ConfigurationType = table.Column<string>(maxLength: 20, nullable: true),
                    RecordStatus = table.Column<string>(maxLength: 50, nullable: true),
                    Remark = table.Column<string>(maxLength: 2500, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    FinishDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    StartDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    OptimizedAlgorithm = table.Column<string>(maxLength: 50, nullable: true),
                    MmrVesselRatio = table.Column<string>(maxLength: 50, nullable: true),
                    VesselEtdRangeTrip = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    VesselPerTrip = table.Column<int>(nullable: false),
                    PenaltyWeight = table.Column<string>(maxLength: 50, nullable: true),
                    SaralineWeightCVFactor = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    FuelWeightCVFactor = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    WaterWeightCVFactor = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    BariteWeightCVFactor = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    CementWeightCVFactor = table.Column<decimal>(type: "decimal(28, 10)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ModelParameter", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ModelPriorityParameter",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    ModelParameterId = table.Column<Guid>(nullable: false),
                    ModelObjectiveType = table.Column<string>(maxLength: 50, nullable: true),
                    IsP1ObjectConstraint = table.Column<bool>(nullable: false),
                    IsRosEndingOrdering = table.Column<bool>(nullable: false),
                    P1ProductionRos = table.Column<int>(nullable: false),
                    P2ProductionRos = table.Column<int>(nullable: false),
                    P3ProductionRos = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ModelPriorityParameter", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ModelProductionParameter",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    ModelParameterId = table.Column<Guid>(nullable: false),
                    Priority = table.Column<string>(maxLength: 20, nullable: true),
                    Type = table.Column<string>(maxLength: 20, nullable: true),
                    StartRosInDays = table.Column<int>(nullable: false),
                    EndingRosInDays = table.Column<int>(nullable: false),
                    CostPerMTRosInDays = table.Column<int>(nullable: false),
                    PercentRosInDays = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ModelProductionParameter", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Plan",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    SyncedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    Key = table.Column<Guid>(nullable: false),
                    Rev = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(maxLength: 500, nullable: true),
                    Version = table.Column<string>(maxLength: 500, nullable: true),
                    By = table.Column<string>(nullable: true),
                    Status = table.Column<string>(maxLength: 10, nullable: true),
                    ConfigurationType = table.Column<string>(maxLength: 20, nullable: true),
                    Remark = table.Column<string>(maxLength: 5000, nullable: true),
                    RecordStatus = table.Column<string>(maxLength: 10, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    FinishDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    StartDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Plan", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PlanCargo",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    PlanId = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(maxLength: 250, nullable: true),
                    ConfigurationType = table.Column<string>(maxLength: 20, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Description = table.Column<string>(maxLength: 50, nullable: true),
                    RecordStatus = table.Column<string>(maxLength: 10, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PlanCargo", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PlanLocation",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    PlanId = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(maxLength: 250, nullable: true),
                    ConfigurationType = table.Column<string>(maxLength: 20, nullable: true),
                    JettyAvailable = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    WHPBuffer = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    RigBuffer = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    AllowWaitingTimeField = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    AllowWaitingTimeJetty = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Description = table.Column<string>(maxLength: 50, nullable: true),
                    RecordStatus = table.Column<string>(maxLength: 10, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PlanLocation", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PlanResource",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    PlanId = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(maxLength: 250, nullable: true),
                    ConfigurationType = table.Column<string>(maxLength: 20, nullable: true),
                    ServiceTimePort = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    ServiceTimeTank = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    ServiceTimePM = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    TieUpRig = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    TieUpOther = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    PumpFuel = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    PumpWater = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    PumpSaraline = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    PumpCementJackUp = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    PumpCementTender = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    PumpBariteJackUp = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    PumpBariteTender = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    LiftingTender = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    LiftingPlatform = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    LiftingJackup = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    LiftingTanker = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    MinimumBlockROB = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    MinimumBlockROBPercentage = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    MinimumTripROB = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    MinimumTripROBPercentage = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    MinimumRefillROB = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    RefillVolume = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    E2QuotaVolume = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    UnderwayVoyageRate = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    PlannedStandbyLessThanTwoHrsRate = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    BerthAtJettyRate = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    AnchorHandlingTowingRate = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    AhtsTarCost = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    UtilityTarCost = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    BackloadCapacityDiscount = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    BackloadAfterBlockout = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    BackloadCountLimit = table.Column<int>(nullable: true),
                    BackloadSpaceLimit = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    BackloadWeightLimit = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    BackloadLengthLimit = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    RouteLocateLimit = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    RouteTurnaround = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    RouteFunction = table.Column<string>(maxLength: 20, nullable: true),
                    MaximizeBackloadCapacity = table.Column<bool>(nullable: false),
                    RouteOption = table.Column<string>(maxLength: 20, nullable: true),
                    ModelTypeSelection = table.Column<string>(maxLength: 20, nullable: true),
                    AssetGroupConcern = table.Column<bool>(nullable: false),
                    AssetBuffer = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Description = table.Column<string>(maxLength: 50, nullable: true),
                    RecordStatus = table.Column<string>(maxLength: 10, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PlanResource", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PlanVessel",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    PlanId = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(maxLength: 250, nullable: true),
                    ConfigurationType = table.Column<string>(maxLength: 20, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Description = table.Column<string>(maxLength: 50, nullable: true),
                    RecordStatus = table.Column<string>(maxLength: 10, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PlanVessel", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RunParameter",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    ConfigurationType = table.Column<string>(maxLength: 20, nullable: true),
                    RecordStatus = table.Column<string>(maxLength: 50, nullable: true),
                    Remark = table.Column<string>(maxLength: 2500, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    FinishDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    StartDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    ExecuteTime = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    SolutionLimit = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RunParameter", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SessionLog",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Token = table.Column<string>(maxLength: 1000, nullable: true),
                    Unique = table.Column<string>(maxLength: 50, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    TokenExpiredDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SessionLog", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tabular",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(maxLength: 50, nullable: true),
                    LengthBundle = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    WidthBundle = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    HeightBundle = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    WeightJoint = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    MaxStackHeight = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    JointBundle = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    Type = table.Column<string>(maxLength: 50, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Description = table.Column<string>(maxLength: 50, nullable: true),
                    RecordStatus = table.Column<string>(maxLength: 10, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tabular", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TabularStack",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    BaseId = table.Column<Guid>(nullable: false),
                    StackableId = table.Column<Guid>(nullable: false),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    RecordStatus = table.Column<string>(maxLength: 10, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TabularStack", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Travel",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    JobId = table.Column<Guid>(nullable: false),
                    PlanId = table.Column<Guid>(nullable: false),
                    StartDate = table.Column<DateTime>(nullable: true),
                    EndDate = table.Column<DateTime>(nullable: true),
                    Remark = table.Column<string>(maxLength: 5000, nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    TotalDistance = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    TotalDuration = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    CostRatioInUSD = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    CostRatioInUSDTrip1 = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    CostRatioInUSDTrip2 = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    FuelConsumption = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    DroppedMaterial = table.Column<int>(nullable: true),
                    IsFavorite = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Travel", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TravelActivity",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Key = table.Column<Guid>(nullable: true),
                    Rev = table.Column<Guid>(nullable: true),
                    Parent = table.Column<Guid>(nullable: true),
                    Discriminator = table.Column<string>(maxLength: 50, nullable: true),
                    Type = table.Column<string>(maxLength: 50, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Status = table.Column<string>(maxLength: 20, nullable: true),
                    Message = table.Column<string>(nullable: true),
                    TravelId = table.Column<Guid>(nullable: false),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TravelActivity", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TravelBlocking",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    TravelId = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(maxLength: 50, nullable: true),
                    VesselLCTReferenceId = table.Column<int>(nullable: false),
                    Description = table.Column<string>(maxLength: 250, nullable: true),
                    FuelConsumtionRateType = table.Column<string>(maxLength: 20, nullable: true),
                    Type = table.Column<string>(maxLength: 20, nullable: true),
                    BlockedType = table.Column<string>(maxLength: 20, nullable: true),
                    TripNo = table.Column<int>(nullable: false),
                    Start = table.Column<DateTime>(type: "datetime", nullable: false),
                    End = table.Column<DateTime>(type: "datetime", nullable: false),
                    TimeDuration = table.Column<TimeSpan>(nullable: false),
                    FuelConsumtionRate = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    FuelConsumtionValue = table.Column<double>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TravelBlocking", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TravelLoaded",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    TravelId = table.Column<Guid>(nullable: false),
                    Priority = table.Column<string>(maxLength: 10, nullable: true),
                    Type = table.Column<string>(maxLength: 20, nullable: true),
                    BoundType = table.Column<string>(maxLength: 20, nullable: true),
                    Success = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    Delivery = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    Total = table.Column<decimal>(type: "decimal(28, 10)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TravelLoaded", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TravelMaterial",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    TravelId = table.Column<Guid>(nullable: false),
                    VesselLCTReferenceId = table.Column<int>(nullable: true),
                    Sequence = table.Column<int>(nullable: true),
                    ItemLCTReferenceId = table.Column<int>(nullable: true),
                    TripNo = table.Column<int>(nullable: true),
                    MmrLCTReferenceId = table.Column<int>(nullable: true),
                    CurrentStatus = table.Column<string>(maxLength: 20, nullable: true),
                    OrderNumber = table.Column<string>(maxLength: 500, nullable: true),
                    DeliveredStatus = table.Column<string>(maxLength: 20, nullable: true),
                    IsChanged = table.Column<bool>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TravelMaterial", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TravelPublish",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    TravelRouteId = table.Column<Guid>(nullable: false),
                    VCN = table.Column<string>(maxLength: 100, nullable: true),
                    Date = table.Column<DateTime>(nullable: false),
                    IsDeleted = table.Column<bool>(nullable: false),
                    PublishId = table.Column<Guid>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TravelPublish", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TravelRoute",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    TravelId = table.Column<Guid>(nullable: false),
                    VesselName = table.Column<string>(maxLength: 50, nullable: true),
                    VesselLCTReferenceId = table.Column<int>(nullable: false),
                    Sequence = table.Column<int>(nullable: false),
                    TripNo = table.Column<int>(nullable: false),
                    FromLCTLocationReferenceId = table.Column<int>(nullable: false),
                    FromLocationCode = table.Column<string>(maxLength: 50, nullable: true),
                    ToLCTLocationReferenceId = table.Column<int>(nullable: false),
                    ToLocationCode = table.Column<string>(maxLength: 50, nullable: true),
                    OriginType = table.Column<string>(maxLength: 50, nullable: true),
                    EtaDate = table.Column<DateTime>(nullable: true),
                    EtdDate = table.Column<DateTime>(nullable: true),
                    LoadingTime = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    OffLoadSpace = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    BackLoadSpace = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    SpaceRemaining = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    OffLoadWeight = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    BackLoadWeight = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    WeightRemaining = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    Distance = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    Speed = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    FromLocationName = table.Column<string>(maxLength: 50, nullable: true),
                    FromLocationType = table.Column<string>(maxLength: 50, nullable: true),
                    FromLocationCategory = table.Column<string>(maxLength: 50, nullable: true),
                    FromLatitude = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    FromLongitude = table.Column<decimal>(type: "decimal(28, 10)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TravelRoute", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TravelTurnaround",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    TravelId = table.Column<Guid>(nullable: false),
                    VesselLCTReferenceId = table.Column<int>(nullable: false),
                    VesselName = table.Column<string>(nullable: true),
                    DispatchDate = table.Column<DateTime>(nullable: true),
                    EtaDate = table.Column<DateTime>(nullable: true),
                    TurnaroundTime = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    NumOfLocation = table.Column<int>(nullable: false),
                    CostRatioInUSD = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    CostInUSD = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    MT = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    TripNo = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TravelTurnaround", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TravelVessel",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    TravelId = table.Column<Guid>(nullable: false),
                    VesselLCTReferenceId = table.Column<int>(nullable: false),
                    BoundType = table.Column<string>(nullable: true),
                    SpaceRemaining = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    CargoWeight = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    BulkWeight = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    TotalWeight = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    BulkVolume = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    DryBulkVolume = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    LiquidBulkVolume = table.Column<decimal>(type: "decimal(28, 10)", nullable: false),
                    TripNo = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TravelVessel", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "User",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 50, nullable: false),
                    ADId = table.Column<Guid>(nullable: false),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    CAI = table.Column<string>(maxLength: 50, nullable: true),
                    DisplayName = table.Column<string>(maxLength: 100, nullable: true),
                    GivenName = table.Column<string>(maxLength: 100, nullable: true),
                    AccountName = table.Column<string>(maxLength: 100, nullable: true),
                    Name = table.Column<string>(maxLength: 200, nullable: true),
                    Unique = table.Column<string>(maxLength: 50, nullable: true),
                    Email = table.Column<string>(maxLength: 100, nullable: true),
                    EmployeeId = table.Column<string>(maxLength: 50, nullable: true),
                    IsADEnable = table.Column<bool>(nullable: false),
                    ADGroup = table.Column<string>(maxLength: 50, nullable: true),
                    Created = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_User", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Vessel",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    LCTReferenceId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(maxLength: 50, nullable: true),
                    Type = table.Column<string>(maxLength: 20, nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    Description = table.Column<string>(maxLength: 50, nullable: true),
                    StatusId = table.Column<int>(nullable: false),
                    Status = table.Column<string>(nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    StartDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    EndDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vessel", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "VesselProperties",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    PlanVesselId = table.Column<Guid>(nullable: false),
                    BaseLocationReferenceId = table.Column<int>(nullable: true),
                    LCTReferenceId = table.Column<int>(nullable: true),
                    TabularSpaceLimitPerside = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    TabularWeightLimitPerside = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    TabularHeightLimitPerside = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    DeckWidth = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    LCTReferenceETADate = table.Column<DateTime>(type: "datetime", nullable: true),
                    ETADate = table.Column<DateTime>(type: "datetime", nullable: true),
                    DeiselROB = table.Column<decimal>(type: "decimal(28, 10)", nullable: true),
                    By = table.Column<string>(maxLength: 50, nullable: true),
                    IsIncludeToCalculate = table.Column<bool>(nullable: false),
                    StatusReferenceId = table.Column<int>(nullable: false),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VesselProperties", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "__EFLoggingEvent",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Cargo",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "CargoPriority",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Job",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Location",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "LocationState",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Material",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "MaterialRequest",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ModelParameter",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ModelPriorityParameter",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ModelProductionParameter",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Plan",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "PlanCargo",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "PlanLocation",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "PlanResource",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "PlanVessel",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "RunParameter",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "SessionLog",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Tabular",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "TabularStack",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Travel",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "TravelActivity",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "TravelBlocking",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "TravelLoaded",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "TravelMaterial",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "TravelPublish",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "TravelRoute",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "TravelTurnaround",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "TravelVessel",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "User",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Vessel",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "VesselProperties",
                schema: "dbo");
        }
    }
}
