﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace cvx.lct.vot.api.Migrations
{
    public partial class advacne9spin16 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "TimeDuration",
                schema: "dbo",
                table: "TravelBlocking");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<TimeSpan>(
                name: "TimeDuration",
                schema: "dbo",
                table: "TravelBlocking",
                nullable: false,
                defaultValue: new TimeSpan(0, 0, 0, 0, 0));
        }
    }
}
