﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace cvx.lct.vot.api.Migrations
{
    public partial class advacne10spin16 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "IsDeleted",
                schema: "dbo",
                table: "TravelMaterial",
                newName: "VotIsChanged");

            migrationBuilder.RenameColumn(
                name: "IsChanged",
                schema: "dbo",
                table: "TravelMaterial",
                newName: "LctReferenceIsDeleted");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "VotIsChanged",
                schema: "dbo",
                table: "TravelMaterial",
                newName: "IsDeleted");

            migrationBuilder.RenameColumn(
                name: "LctReferenceIsDeleted",
                schema: "dbo",
                table: "TravelMaterial",
                newName: "IsChanged");
        }
    }
}
