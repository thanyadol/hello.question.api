using Microsoft.EntityFrameworkCore;

namespace cvx.lct.vot.api.Models
{
    public class NorthwindContext : DbContext
    {
        public NorthwindContext()
        { }

        //virtual for moq ovverride
        public virtual DbSet<Vessel> Vessels { get; set; }
        //   public virtual DbSet<VesselBlockout> VesselBlockouts { get; set; }
        //   public virtual DbSet<VesselArrived> VesselArriveds { get; set; }

        //    public virtual DbSet<VesselSpec> VesselSpecs { get; set; }

        public virtual DbSet<PlanVessel> PlanVessels { get; set; }

        public virtual DbSet<Location> Locations { get; set; }
        public virtual DbSet<LocationState> LocationStates { get; set; }
        public virtual DbSet<PlanLocation> PlanLocations { get; set; }

        //   public virtual DbSet<LocationBlockout> LocationBlockouts { get; set; }


        public virtual DbSet<Material> Materials { get; set; }

        public virtual DbSet<MaterialRequest> MaterialRequests { get; set; }

        public virtual DbSet<PlanResource> PlanResources { get; set; }
        public virtual DbSet<Plan> Plans { get; set; }

        public virtual DbSet<Job> Jobs { get; set; }
        public virtual DbSet<RunParameter> RunParameters { get; set; }

        public virtual DbSet<ModelParameter> ModelParameters { get; set; }

        public virtual DbSet<ModelPriorityParameter> ModelPriorityParameters { get; set; }
        public virtual DbSet<ModelProductionParameter> ModelProductionParameters { get; set; }


        public virtual DbSet<Travel> Travels { get; set; }
        public virtual DbSet<TravelRoute> TravelRoutes { get; set; }
        public virtual DbSet<TravelBlocking> TravelBlockings { get; set; }

        public virtual DbSet<TravelLoaded> TravelLoadeds { get; set; }
        public virtual DbSet<TravelVessel> TravelVessels { get; set; }
        public virtual DbSet<TravelMaterial> TravelMaterials { get; set; }
        public virtual DbSet<TravelTurnaround> TravelTurnarounds { get; set; }
        public virtual DbSet<TravelPublish> TravelPublishes { get; set; }

        public virtual DbSet<VesselProperties> VesselProperties { get; set; }


        public virtual DbSet<PlanCargo> PlanCargos { get; set; }
        public virtual DbSet<CargoPriority> CargoPriorities { get; set; }
        public virtual DbSet<Cargo> Cargos { get; set; }
        // public virtual DbSet<CargoCoefficient> CargoCoefficients { get; set; }

        // public virtual DbSet<Notification> Notifications { get; set; }
        public virtual DbSet<__EFLoggingEvent> __EFLoggingEvents { get; set; }

        public virtual DbSet<User> Users { get; set; }

        public virtual DbSet<SessionLog> SessionLogs { get; set; }
        public virtual DbSet<TravelActivity> TravelActivities { get; set; }


        public virtual DbSet<Tabular> Tabulars { get; set; }
        public virtual DbSet<TabularStack> TabularStacks { get; set; }

        private const string DEFAULT_SCHEMA = "dbo";

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Plan>().ToTable("Plan");
            modelBuilder.Entity<PlanVessel>().ToTable("PlanVessel");
            modelBuilder.Entity<VesselProperties>().ToTable("VesselProperties");

            modelBuilder.Entity<Job>().ToTable("Job");
            modelBuilder.Entity<RunParameter>().ToTable("RunParameter");

            modelBuilder.Entity<ModelParameter>().ToTable("ModelParameter");
            modelBuilder.Entity<ModelPriorityParameter>().ToTable("ModelPriorityParameter");
            modelBuilder.Entity<ModelProductionParameter>().ToTable("ModelProductionParameter");

            modelBuilder.Entity<Travel>().ToTable("Travel");
            modelBuilder.Entity<TravelBlocking>().ToTable("TravelBlocking");
            modelBuilder.Entity<TravelRoute>().ToTable("TravelRoute");
            modelBuilder.Entity<TravelLoaded>().ToTable("TravelLoaded");
            modelBuilder.Entity<TravelVessel>().ToTable("TravelVessel");
            modelBuilder.Entity<TravelMaterial>().ToTable("TravelMaterial");
            modelBuilder.Entity<TravelTurnaround>().ToTable("TravelTurnaround");
            modelBuilder.Entity<TravelPublish>().ToTable("TravelPublish");

            modelBuilder.Entity<Material>().ToTable("Material");
            modelBuilder.Entity<MaterialRequest>().ToTable("MaterialRequest");

            modelBuilder.Entity<Vessel>().ToTable("Vessel");

            modelBuilder.Entity<Location>().ToTable("Location");

            modelBuilder.Entity<PlanLocation>().ToTable("PlanLocation");

            modelBuilder.Entity<LocationState>().ToTable("LocationState");
            //  modelBuilder.Entity<LocationBlockout>().ToTable("LocationBlockout");
            modelBuilder.Entity<PlanResource>().ToTable("PlanResource");

            modelBuilder.Entity<Cargo>().ToTable("Cargo");
            modelBuilder.Entity<CargoPriority>().ToTable("CargoPriority");
            // modelBuilder.Entity<CargoCoefficient>().ToTable("CargoCoefficient");

            modelBuilder.Entity<PlanCargo>().ToTable("PlanCargo");
            //  modelBuilder.Entity<Notification>().ToTable("Notification");

            modelBuilder.Entity<__EFLoggingEvent>().ToTable("__EFLoggingEvent");

            modelBuilder.Entity<User>().ToTable("User");
            modelBuilder.Entity<SessionLog>().ToTable("SessionLog");
            modelBuilder.Entity<TravelActivity>().ToTable("TravelActivity");

            modelBuilder.Entity<Tabular>().ToTable("Tabular");
            modelBuilder.Entity<TabularStack>().ToTable("TabularStack");


            modelBuilder.HasDefaultSchema(DEFAULT_SCHEMA);
        }

        public NorthwindContext(DbContextOptions<NorthwindContext> options)
            : base(options)
        { }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(@"Server=(localdb)\mssqllocaldb;Database=EFProviders.InMemory;Trusted_Connection=True;ConnectRetryCount=0");
            }
        }
    }
}