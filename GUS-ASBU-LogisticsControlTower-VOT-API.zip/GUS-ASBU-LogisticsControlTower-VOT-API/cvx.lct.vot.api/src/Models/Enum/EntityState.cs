

using System;

using System.ComponentModel;
//using surflex.netcore22.Helpers;

namespace cvx.lct.vot.api.Models
{
    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum EntityState
    {
        [Description("QUERIED")]
        QUERIED,


        [Description("MODIFIED")]
        MODIFIED,


        [Description("ADDED")]
        ADDED,



        [Description("REMOVED")]
        REMOVED,

    }


    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum InsertState
    {

        [Description("DEFAULT")]
        DEFAULT,


        [Description("UP")]
        UP,



        [Description("DOWN")]
        DOWN,

    }
}