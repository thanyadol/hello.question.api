using System;
using System.ComponentModel;

namespace cvx.lct.vot.api.Models
{
    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum DeliveredStatus
    {

        [Description("DELIVERED")]
        DELIVERED,


        [Description("DROPPED")]
        DROPPED,

    }
}