﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    [Flags]
    public enum BulkType
    {
        [Description("Fuel and Pot water")]
        FUEL_AND_POTWATER = 0,
        [Description("Barite")]
        BARITE = 1,
        [Description("Cement-Hal")]
        CEMENT_HAL = 2,
        [Description("Cement-BHI")]
        CEMENT_BHI = 3,
        [Description("Saraline")]
        SARALINE = 4,
        [Description("Mud")]
        MUD = 5,
        [Description("Brine")]
        BRINE = 6,
        [Description("Drill water")]
        DRILL_WATER = 7,
    }
}
