using System;
using System.ComponentModel;

namespace cvx.lct.vot.api.Models
{
    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum ActionActivity
    {

        [Description("SAVED")]
        SAVED,


        [Description("PUBLISHED")]
        PUBLISHED,


        [Description("REPUBLISHED")]
        REPUBLISHED,


        [Description("UPDATED")]
        UPDATED,

        [Description("SYNCED")]
        SYNCED,

        [Description("CALCULATED")]
        CALCULATED,


        [Description("MERGED")]
        MERGED,



    }
}