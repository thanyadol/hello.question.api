﻿using System;
using System.ComponentModel;

namespace cvx.lct.vot.api.Models
{
    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum JobStatus
    {
        [Description("Not Started")]
        NOTSTART,

        [Description("Pending")]
        PENDING,

        [Description("Running")]
        RUNNING,

        [Description("Failed")]
        FAILED,

        [Description("Succeeded")]
        SUCCEEDED,

        [Description("Skipped")]
        SKIPPED,

        [Description("Initialize")]
        INITIALIZE,

        [Description("Canceled")]
        CANCELED,
    }
}
