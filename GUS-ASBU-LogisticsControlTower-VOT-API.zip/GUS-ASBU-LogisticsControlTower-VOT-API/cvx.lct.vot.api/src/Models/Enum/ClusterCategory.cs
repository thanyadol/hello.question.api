﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    //
    //order is !!!important for sorting location logic
    //
    ///
    ///

    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum ClusterCategory
    {
        //1
        [Description("Terminal")]
        TERMINAL,

        //2
        [Description("Rig")]
        RIG,

        //3
        [Description("Non Rig")]
        NONRIG,

        //4
        [Description("Tanker")]
        TANKER,



    }
}
