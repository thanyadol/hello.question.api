using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    [Flags]
    public enum LocationArrived
    {
        [Description("ARRIVED")]
        ARRIVED,

        [Description("SKIPPED")]
        SKIPPED,

        [Description("OVERHEAD")]
        OVERHEAD

    }
}
