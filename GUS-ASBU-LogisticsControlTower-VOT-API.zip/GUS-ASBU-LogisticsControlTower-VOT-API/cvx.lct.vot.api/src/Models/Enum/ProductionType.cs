using System;
using System.ComponentModel;

namespace cvx.lct.vot.api.Models
{
    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum ProductionType
    {
        [Description("Drilling")]
        DRILLING,

        [Description("Production")]
        PRODUCTION,
    }
}
