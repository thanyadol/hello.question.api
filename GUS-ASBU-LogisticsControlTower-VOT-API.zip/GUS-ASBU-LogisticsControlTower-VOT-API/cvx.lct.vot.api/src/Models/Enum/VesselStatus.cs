

using System;

using System.ComponentModel;

namespace cvx.lct.vot.api.Models
{
    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum VesselStatus
    {

        [Description("NA")]
        NA,

        //id =1
        [Description("On Hire")]
        ONHIRE,

        //id =2 
        [Description("Off Hire")]
        OFFHIRE,

    }
}