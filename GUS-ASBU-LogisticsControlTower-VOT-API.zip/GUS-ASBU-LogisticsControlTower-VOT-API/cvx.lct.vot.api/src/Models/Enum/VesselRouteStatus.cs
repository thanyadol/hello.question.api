﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    [Flags]
    public enum VesselRouteStatus
    {
        [Description("7-day Draft")]
        DRAFT = 1,
        [Description("7-day Publish or Daily Draft")]
        DAILY_DRAFT = 2,
        [Description("Daily Confirmed")]
        DAILY_CONFIRMED = 3,
        [Description("Active")]
        ACTIVE = 4,
    }
}
