
using System;
using System.ComponentModel;

namespace cvx.lct.vot.api.Models
{
    public enum StorageType
    {
        [Description("DB")]
        DB,

        [Description("LOCAL")]
        LOCAL,

        [Description("AZURE")]
        AZURE
    }
}