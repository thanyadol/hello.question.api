using System;
using System.ComponentModel;

namespace cvx.lct.vot.api.Models
{
    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum PlanType
    {
        [Description("WEEKLY")]
        WEEKLY,

        [Description("DAILY")]
        DAILY,

        [Description("CURRENT")]
        CURRENT,

        [Description("BOOK_ACTIVITY")]
        BOOK_ACTIVITY,

        [Description("JETTY_ACTIVITY")]
        JETTY_ACTIVITY,
    }
}
