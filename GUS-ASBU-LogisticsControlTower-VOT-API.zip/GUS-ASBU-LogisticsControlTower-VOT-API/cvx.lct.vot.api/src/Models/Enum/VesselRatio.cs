using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    [Flags]
    public enum VesselRatio
    {
        [Description("LOW")]
        LOW = 15,

        [Description("MEDIUM")]
        MEDIUM = 20,

        [Description("MEDIUMHEIGHT")]
        MEDIUMHEIGHT = 25,

        [Description("HEIGHT")]
        HEIGHT = 30,
    }
}
