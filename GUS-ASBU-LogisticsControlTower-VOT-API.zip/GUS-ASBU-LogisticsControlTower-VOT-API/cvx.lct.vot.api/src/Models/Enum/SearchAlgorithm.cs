using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public enum SearchAlgorithm
    {
        [Description("Guide Local Search")]
        GLS = 1,

        [Description("Greedy Descent")]
        GD = 2,


        [Description("Simulate Annealing")]
        SA = 3
    }

}