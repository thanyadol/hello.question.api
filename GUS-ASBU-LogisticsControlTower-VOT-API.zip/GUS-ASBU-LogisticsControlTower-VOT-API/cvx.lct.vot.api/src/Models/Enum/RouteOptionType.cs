﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public enum RouteOptionType
    {
        [Description("CONSTAINT")]
        CONSTAINT,

        [Description("UNCONSTAINT")]
        UNCONSTAINT,

        [Description("Unconstaint Route Turnaround")]
        UNCONSTAINT_ROUTE_TURNAROUND = 10,
    }

    
}
