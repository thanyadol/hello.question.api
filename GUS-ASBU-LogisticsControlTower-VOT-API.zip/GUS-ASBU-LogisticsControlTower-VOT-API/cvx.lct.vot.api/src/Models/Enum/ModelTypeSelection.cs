using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    [Flags]
    public enum ModelTypeSelection
    {
        [Description("Offload")]
        OFFLOAD = 0,

        [Description("Backload")]
        BACKLOAD = 2,

        [Description("Hybrid")]
        HYBRID = 3,
    }
}
