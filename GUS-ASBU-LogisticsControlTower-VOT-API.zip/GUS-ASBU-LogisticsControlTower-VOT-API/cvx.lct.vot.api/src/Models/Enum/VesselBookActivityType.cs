﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    [Flags]
    public enum VesselBookType
    {
        [Description("Maintenance")]
        MAINTENANCE = 1,

        [Description("Typhoon Standby")]
        TYPHOON_STANDBY = 3,

        [Description("Buoy")]
        BUOY = 4,

        [Description("Special request")]
        SPECIAL_REQUEST = 5,

        [Description("Rig Move")]
        RIGMOVE = 2,

        [Description("Activity Request")]
        ACTIVITY_REQUEST = 15,

        [Description("Offhire")]
        OFFHIRE,

        [Description("Idle")]
        IDLE = 100,


        [Description("Loading")]
        LOADING = 101,

        [Description("Port Bunkering")]
        PORT_BUNKERING = 102,

        [Description("Queue")]
        QUEUE = 998,

        [Description("Other")]
        OTHER = 999,
    }
}
