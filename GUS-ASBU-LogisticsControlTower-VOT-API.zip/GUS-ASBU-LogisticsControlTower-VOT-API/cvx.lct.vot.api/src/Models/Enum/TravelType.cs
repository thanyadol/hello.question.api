using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    [Flags]
    public enum TravelType
    {
        [Description("Queue")]
        QUEUE = 1,

        [Description("Cargo")]
        CARGO = 2,

        [Description("PM")]
        PM = 3,

        [Description("Port")]
        PORT = 4,   //service proting at terminal

        [Description("Idle")]
        IDLE = 5,

        [Description("Loading")]
        LOADING = 6, //loading time at node
    }
}
