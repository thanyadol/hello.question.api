

using System;

using System.ComponentModel;

namespace cvx.lct.vot.api.Models
{
    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum VesselType
    {
        [Description("NA0")]
        NA0,


        [Description("PSV")]
        PSV,

        [Description("Utility")]
        UTILITY,

        [Description("Crew Boat")]
        CREWBOAT,


        [Description("NA4")]
        NA4,

        [Description("NA5")]
        NA5,


        [Description("AHTS")]
        AHTS,


        [Description("Tug")]
        TUG,

        [Description("Non LDSC Vessel")]
        NONLCD,

    }
}