using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using cvx.lct.vot.api.Models.Gateway;
using Newtonsoft.Json;
using surflex.netcore22.Models.DTO;

namespace cvx.lct.vot.api.Models
{
    public class TravelParams
    {
        public TravelParams()
        {
            this.StartDate = DateTime.MinValue;
            this.EndDate = DateTime.MinValue;

            this.IsFavorite = false;
        }

        public Guid Id { get; set; }

        //for display only
        public Guid JobId { get; set; }
        public Guid TravelId { get; set; }
        public string Name { get; set; }


        public string Remark { get; set; }

        //for display only
        public string Version { get; set; }

        public bool IsFavorite { get; set; }

        public string By { get; set; }


        public int DroppedMMRs { get; set; }
        public int TotalMMRs { get; set; }

        public decimal TotalDistance { get; set; }
        public decimal TotalDuration { get; set; }

        public Gateway.JobParams CurrentJob { get; set; }


        public Nullable<DateTime> StartDate { get; set; }
        public Nullable<DateTime> EndDate { get; set; }

        public decimal FuelConsumption { get; set; }
        public decimal? CostRatioInUSD { get; set; }
        public decimal? CostRatioInUSDTrip1 { get; set; }
        public decimal? CostRatioInUSDTrip2 { get; set; }

        public IEnumerable<Gulf> GulfSchematics { get; set; }
        public string GulfStatement { get; set; }

        public IEnumerable<VesselParams> GroupVessels { get; set; }

        public IEnumerable<TravelRoute> RouteDetails { get; set; }

        public IEnumerable<RouteParams> PlotRoutes { get; set; }
        public IEnumerable<RouteParams> PlotBlocking { get; set; }


        public IEnumerable<TravelVessel> VesselLoads { get; set; }


        public IEnumerable<MaterialParams> LoadingList { get; set; }

        public IEnumerable<MaterialParams> GroupLoading { get; set; }

        public IEnumerable<MaterialParams> DroppingList { get; set; }



        public IEnumerable<TravelTurnaround> Turnarounds { get; set; }


        public IEnumerable<TravelActivity> BlockingActivity { get; set; }

        public IEnumerable<TravelLoaded> BackLoads { get; set; }
        public IEnumerable<TravelLoaded> OffLoads { get; set; }


        public decimal OffLoadDeliveredPercentage { get; set; }
        public decimal OffLoadSuccessPercentage { get; set; }


        public decimal BackLoadDeliveredPercentage { get; set; }
        public decimal BackLoadSuccessPercentage { get; set; }
    }
}

