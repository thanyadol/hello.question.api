﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class FactoryLog
    {
        public string Table { get; set; }
        public DateTime LastSync { get; set; }
        public string Status { get; set; }
    }
}
