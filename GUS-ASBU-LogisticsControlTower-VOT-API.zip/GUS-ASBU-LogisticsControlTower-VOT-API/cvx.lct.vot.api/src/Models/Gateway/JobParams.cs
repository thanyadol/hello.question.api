using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace cvx.lct.vot.api.Models.Gateway
{
    public class JobParams
    {
        public JobParams()
        {
            this.Type = "JOB";
            this.RunId = "0";
        }
        [NotMapped]
        public decimal ExecuteTime { get; set; }

        [NotMapped]
        public int SolutionLimit { get; set; }

        public Guid Id { get; set; }

        //for display only
        [StringLength(100)]
        public string Title { get; set; }

        [NotMapped]
        public string PlanName { get; set; }

        [NotMapped]
        public string PlanRemark { get; set; }



        [NotMapped]
        public string RunMessage { get; set; }


        [NotMapped]
        public Guid JobId { get; set; }


        [NotMapped]
        public string RunId { get; set; }


        [StringLength(1000)]
        public string Message { get; set; }

        [StringLength(1000)]
        //for display only
        public string Remark { get; set; }

        [StringLength(50)]
        public string By { get; set; }

        [StringLength(10)]
        public string Type { get; set; }

        [NotMapped]
        public string JobStatus { get; set; }


        [Column(TypeName = "datetime")]
        public DateTime Date { get; set; }

        public TimeSpan TimeElapsed { get; set; }
        public string TimeElapsedDisplay { get; set; }
        public bool IsUnread { get; set; }

    }
}

