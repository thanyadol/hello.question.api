using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class LocationBlockout
    {
        [Key]
        public Guid Id { get; set; }

        // [ForeignKey("Plan")]
        // public Guid PlanId { get; set; }


        [NotMapped]
        public string EntityState { get; set; }

        [ForeignKey("Location")]
        public Guid LocationId { get; set; }

        public int LCTReferenceId { get; set; }

        //[StringLength(50)]
        //public string BlockoutType { get; set; }


        [StringLength(50)]
        public string By { get; set; }


        [StringLength(10)]
        public string RecordStatus { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Date { get; set; }



        [Column(TypeName = "datetime")]
        public Nullable<DateTime> StartDate { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> EndDate { get; set; }
    }
}
