using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class LocationBlockoutParams
    {

        public Guid Id { get; set; }


        public Guid ClusterId { get; set; }

        public Nullable<int> LCTReferenceId { get; set; }


        public string ClusterName { get; set; }

        public string ClusterCode { get; set; }

        public string Code { get; set; }

        public string Name { get; set; }

        public string Asset { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

    }

}