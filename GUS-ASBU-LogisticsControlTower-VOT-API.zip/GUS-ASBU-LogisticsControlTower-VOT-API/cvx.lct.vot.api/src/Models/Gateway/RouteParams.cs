using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using cvx.lct.vot.api.Extensions;

namespace cvx.lct.vot.api.Models
{
    public class RouteParams
    {
        public RouteParams()
        {
            this.PlanType = Models.PlanType.WEEKLY.GetDescription();
        }

        public Guid Id { get; set; }


        public int? VesselLCTReferenceId { get; set; }

        public string HtmlColorCode { get; set; }

        public int? Trip { get; set; }

        public string VesselName { get; set; }


        //timeline attribute
        //this is cluster
        public string FromLocationCode { get; set; }
        //this is cluster
        public string ToLocationCode { get; set; }


        public string Start { get; set; }


        public string End { get; set; }


        public string Content { get; set; }

        public string Type { get; set; }

        public string TravelType { get; set; }

        public string PlanType { get; set; }


        public string ClassName { get; set; }

        public string Style { get; set; }

        public int Value { get; set; }

        ///grouped by vessel
        public string Group { get; set; }

        public List<Location> Visited { get; set; }
        public string VisitedDisplay { get; set; }

    }



}
