using System;
using System.Collections.Generic;
namespace cvx.lct.vot.api.Models
{

    public class PublishParams
    {
        public bool IsEnableRePublish { get; set; }

        public Guid TravelId { get; set; }
        public List<MaterialParams> DroppedTasks { get; set; }

        public int[] FirstTripVessels { get; set; }
        public int[] SecondTripVessels { get; set; }
    }
}