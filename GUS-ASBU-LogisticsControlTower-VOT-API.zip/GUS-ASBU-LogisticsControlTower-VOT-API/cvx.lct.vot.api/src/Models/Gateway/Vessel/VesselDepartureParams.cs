using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace cvx.lct.vot.api.Models
{
    public class VesselDepartureParams
    {
        public VesselDepartureParams()
        {
            BlockingActivity = new List<VesselActivity>();
            Specification = new VesselSpec();
        }

        public Guid Id { get; set; }

        public Guid BaseLocationId { get; set; }
        public int BaseLocationReferenceId { get; set; }
        public int LCTReferenceId { get; set; }
        public string Name { get; set; }

        [JsonIgnore]
        public TimeSpan ETDTimspanHours { get; set; }

        [JsonIgnore]
        public Nullable<DateTime> LCTReferenceETADate { get; set; }

        [JsonIgnore]
        public Nullable<DateTime> ETADate { get; set; }
        public Nullable<DateTime> ETDDate { get; set; }

        //for debug purpose
        //[JsonIgnore]
        [JsonIgnore]
        public VesselBookActivity PM { get; set; }

        //[JsonIgnore]
        public VesselBookActivity Blockout { get; set; }


        public VesselSpec Specification { get; set; }
        public LocationState BasePort { get; set; }
        public VesselArrived ETA { get; set; }

        [JsonIgnore]
        public VesselDepartureParams PreviousQueue { get; set; }
        // [JsonIgnore]
        public List<VesselActivity> BlockingActivity { get; set; }

        public decimal DieselETD { get; set; }
        public decimal? EffectiveDeadWeightLimit { get; set; }
        public decimal? EffectiveDeckWidth { get; set; }

        public bool IsVisitTanker { get; set; }
        public double BlockoutDiesel { get; set; }


        //look up only
        public Nullable<DateTime> BlockStartDate { get; set; }
        public Nullable<DateTime> BlockEndDate { get; set; }

        public string BlockStartLocationCode { get; set; }
        public string BlockEndLocationCode { get; set; }
        public string Type { get; internal set; }
        public string Status { get; internal set; }
    }
}