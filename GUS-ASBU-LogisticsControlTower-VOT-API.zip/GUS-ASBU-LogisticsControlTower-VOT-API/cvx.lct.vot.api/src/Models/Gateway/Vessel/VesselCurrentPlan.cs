﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class VesselCurrentPlan
    {
        public int Sequence { get; internal set; }
        public int VesselId { get; internal set; }
        public string VesselName { get; internal set; }
        public int FromId { get; internal set; }
        public int ToId { get; internal set; }
        public string FromName { get; internal set; }
        public string ToName { get; internal set; }
        public DateTime? ETD { get; internal set; }
        public DateTime? ETA { get; internal set; }
        public int StatusId { get; internal set; }
        public bool LctReferenceIsActual { get; internal set; }
        public bool LctReferenceIsCurrent { get; internal set; }

        public bool LctReferenceIsDeletedd { get; internal set; }
        public string LocationStatus { get; set; }

        [NotMapped]
        public DateTime? ProcessETD { get; set; }
        [NotMapped]
        public DateTime? UpdatedProcessETD { get; set; }

    }
}
