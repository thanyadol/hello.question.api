﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class VesselRoute
    {
        public int VesselId { get; set; }
        public string VesselName { get; set; }
        public long FromLocationId { get; set; }
        public string FromLocationCode { get; set; }
        public long ToLocationId { get; set; }
        public string ToLocationCode { get; set; }
        public DateTime ETA { get; set; }
        public DateTime ETD { get; set; }
        public IEnumerable<TravelRouteDetail> RouteDetails { get; set; }
        // public IEnumerable<TravelVessel> Materials { get; set; }
        public IEnumerable<TravelVessel> VesselMaterials { get; set; }
        public IEnumerable<MaterialRequest> MaterialRequests { get; set; }
    }

    public class RouteDetail
    {

        public string VesselName { get; set; }

        public int VesselId { get; set; }
        public int Sequence { get; set; }
        public int TripNo { get; set; }
        public long FormLocationId { get; set; }
        public long ToLocationId { get; set; }
        public string FromLocationCode { get; set; }
        public string ToLocationCode { get; set; }
        public DateTime ETA { get; set; }
        public DateTime ETD { get; set; }
        public decimal LoadingTime { get; set; }
        public decimal OffLoadSpace { get; set; }
        public decimal BackLoadSpace { get; set; }
        public decimal SpaceRemaining { get; set; }
        public decimal OffLoadWeight { get; set; }
        public decimal BackLoadWeight { get; set; }
        public decimal WeightRemaining { get; set; }
        public decimal Distance { get; set; }
        public double Speed { get; set; }
    }

    public class MaterialMapping
    {
        public int? VesselLCTReferenceId { get; set; }
        public int? Sequence { get; set; }
        public int? MMRDetailId { get; set; }
        public int? MMRId { get; set; }
        public int? TripNo { get; set; }

        public string OrderNumber { get; set; }

        public string DeliveredStatus { get; set; }

    }
}