using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class VesselSpec
    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("Vessel")]
        public Guid VesselId { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Date { get; set; }

        [StringLength(50)]
        public string By { get; set; }



        [StringLength(10)]
        public string RecordStatus { get; set; }

        public int LCTReferenceId { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> Speed { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> MaxSpeed { get; set; }



        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> DieselTankCapacity { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> SaralineTank { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> Barite { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> BaritePerTank { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> BariteTank { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> HCement { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> HCementPerTank { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> HCementTank { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> BhiCement { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> BhiCementPerTank { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> BhiCementTank { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> PotWater { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> DrillWater { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> DeckSpaceLimit { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> DeadWeightLimit { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> TabularSpaceLimit { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> TabularSpaceLimitPerSide { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> TabularWeightLimitPerSide { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> TabularHeightLimit { get; set; }



        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> DeckWidth { get; set; }

        [NotMapped]
        public Nullable<decimal> Saraline { get; set; }

    }

}