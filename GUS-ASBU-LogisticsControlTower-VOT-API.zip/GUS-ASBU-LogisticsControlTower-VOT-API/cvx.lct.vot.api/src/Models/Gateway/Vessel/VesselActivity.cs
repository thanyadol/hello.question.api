using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class VesselActivity
    {
        //random guid
        public Guid Id { get; set; }

        public int ActivityId { get; set; } //activity id

        public string Name { get; set; }

        public int VesselLCTReferenceId { get; set; }

        public string Description { get; set; }

        public string FuelConsumtionRateType { get; set; }

        public string Type { get; set; }

        public string BlockedType { get; set; }

        public int TripNo { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }

        public TimeSpan TimeDuration { get; set; }

        public decimal FuelConsumtionRate { get; set; }

        public double FuelConsumtionValue { get; set; }
    }
}