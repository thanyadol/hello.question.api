﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class VesselDepartureRequestParams
    {
        public Guid PlanId { get; set; }
        public IEnumerable<VesselArrived> VesselArrivals { get; set; }

        public int TripNo { get; set; }
    }
}
