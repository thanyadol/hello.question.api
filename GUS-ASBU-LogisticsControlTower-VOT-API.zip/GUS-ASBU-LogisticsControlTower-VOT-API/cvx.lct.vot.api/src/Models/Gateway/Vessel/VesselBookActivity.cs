﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class VesselBookActivity
    {
        public int BookActivityId { get; set; }
        public Nullable<int> ActivityTypeId { get; set; }
        public string Description { get; set; }
        public string Info { get; set; }
        public int LocationId { get; set; }
        public string RigMoveStartLocCode { get; set; }
        public string RigMoveEndLocCode { get; set; }
        public int? VesseId { get; internal set; }
        public string VesselName { get; internal set; }
        public int? RigId { get; internal set; }
        public DateTime? StartDate { get; internal set; }
        public DateTime? EndDate { get; internal set; }
        public DateTime? RigMoveStartDate { get; internal set; }
        public DateTime? RigMoveEndDate { get; internal set; }
        [NotMapped]
        public int Type { get; set; }
        [NotMapped]
        public double BlockoutDiesel { get; set; }
        public string StartLocationCode { get; internal set; }
        public string EndLocationCode { get; internal set; }
        public string ActivityType { get; internal set; }
    }
}
