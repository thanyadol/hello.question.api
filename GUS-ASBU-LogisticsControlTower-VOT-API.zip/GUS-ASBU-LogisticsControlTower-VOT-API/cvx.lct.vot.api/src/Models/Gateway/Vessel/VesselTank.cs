﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class VesselTank
    {
        public int VesselId { get; set; }
        public Nullable<decimal> SaralineTank { get; set; }
        
        public Nullable<decimal> Barite { get; set; }
        
        public Nullable<decimal> BaritePerTank { get; set; }
        
        public Nullable<decimal> BariteTank { get; set; }
        
        public Nullable<decimal> HCement { get; set; }
        
        public Nullable<decimal> HCementPerTank { get; set; }
        
        public Nullable<decimal> HCementTank { get; set; }
        
        public Nullable<decimal> BhiCement { get; set; }
        
        public Nullable<decimal> BhiCementPerTank { get; set; }
        
        public Nullable<decimal> BhiCementTank { get; set; }
        
        public Nullable<decimal> PotWater { get; set; }
        
        public Nullable<decimal> DrillWater { get; set; }

        public Nullable<decimal> Saraline { get; set; }
        public Nullable<decimal> SaralinePerTank { get; internal set; }
        public Nullable<decimal> EffectiveDrillWater { get; internal set; }
        public Nullable<decimal> DieselTankCapacity { get; internal set; }
        public Nullable<decimal> EffectivePotWater { get; internal set; }
    }
}
