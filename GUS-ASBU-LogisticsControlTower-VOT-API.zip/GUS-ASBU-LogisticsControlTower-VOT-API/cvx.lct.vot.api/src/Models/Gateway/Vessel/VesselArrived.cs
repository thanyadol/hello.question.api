using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class VesselArrived
    {
        public Guid Id { get; set; }

        public Guid VesselId { get; set; }

        public int LCTReferenceId { get; set; }

        public string VesselName { get; set; }

        public Guid BaseLocationId { get; set; }

        public int BaseLocationReferenceId { get; set; }
        public string By { get; set; }

        public Nullable<DateTime> Date { get; set; }

        public string RecordStatus { get; set; }

        public Nullable<DateTime> ETA { get; set; }

        public decimal DieselROB { get; set; }

    }
}
