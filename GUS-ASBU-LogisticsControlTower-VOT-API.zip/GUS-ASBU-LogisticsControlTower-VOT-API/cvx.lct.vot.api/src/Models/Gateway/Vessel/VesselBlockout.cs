using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace cvx.lct.vot.api.Models
{
    public class VesselBlockout
    {
        [Key]
        public Guid Id { get; set; }

        public Guid VesselId { get; set; }

        [NotMapped]
        public int _VesselId { get; set; }

        public int LCTReferenceId { get; set; }
        public Nullable<int> LCTActivityId { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> StartDate { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> EndDate { get; set; }


        [StringLength(10)]
        public string RecordStatus { get; set; }

        [JsonIgnore]
        [ForeignKey("Location")]
        public Nullable<Guid> StartLocationId { get; internal set; }

        [JsonIgnore]
        [ForeignKey("Location")]
        public Nullable<Guid> EndLocationId { get; internal set; }

        [NotMapped]
        public string StartLocationCode { get; set; }

        [NotMapped]
        public string EndLocationCode { get; set; }

    }
}
