using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace cvx.lct.vot.api.Models
{
    [Serializable]
    public class ModelParams
    {
        public Guid Id { get; set; }

        public string By { get; set; }

        public string ConfigurationType { get; set; }
        public string RecordStatus { get; set; }
        public string Remark { get; set; }
        public Nullable<DateTime> Date { get; set; }

        public Nullable<DateTime> FinishDate { get; set; }

        public Nullable<DateTime> StartDate { get; set; }

        public string OptimizedAlgorithm { get; set; }

        public string MmrVesselRatio { get; set; }
        public Nullable<decimal> VesselEtdRangeTrip { get; set; }

        public int VesselPerTrip { get; set; }

        public string PenaltyWeight { get; set; }

        //conversion factor
        public Nullable<decimal> BariteWeightCVFactor { get; set; }

        public Nullable<decimal> CementWeightCVFactor { get; set; }

        public Nullable<decimal> SaralineWeightCVFactor { get; set; }

        public Nullable<decimal> FuelWeightCVFactor { get; set; }

        public Nullable<decimal> WaterWeightCVFactor { get; set; }

        public List<ModelPriorityParameter> Objectives { get; set; }
        public List<ModelProductionParameter> Productions { get; set; }

        public List<ModelProductionParameter> Drillings { get; set; }
    }
}

