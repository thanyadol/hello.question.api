using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class VesselParams
    {

        public string Id { get; set; }


        public int VesselLCTReferenceId { get; set; }

        public string HtmlColorCode { get; set; }

        public int TripNo { get; set; }

        public string VesselName { get; set; }


        //timeline attribute

        public string FromLocationCode { get; set; }

        public string ToLocationCode { get; set; }


        public string Start { get; set; }


        public string End { get; set; }


        public DateTime EtdDate { get; set; }


        public DateTime EtaDate { get; set; }

        public int StartSequence { get; set; }
        public int EndSequence { get; set; }

        public string Content { get; set; }


        public string ClassName { get; set; }
        public string PlanType { get; set; }


        public int Value { get; set; }


        public int Group { get; set; }


    }



}
