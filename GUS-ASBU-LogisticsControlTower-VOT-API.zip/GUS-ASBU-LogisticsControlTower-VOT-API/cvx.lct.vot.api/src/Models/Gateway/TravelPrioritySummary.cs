﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class TravelPrioritySummary
    {
        public Guid JobId { get; set; }
        public IEnumerable<TravelLoaded> PrioritySummary { get; set; }
        public int DroppedMaterial { get; set; }
    }
}
