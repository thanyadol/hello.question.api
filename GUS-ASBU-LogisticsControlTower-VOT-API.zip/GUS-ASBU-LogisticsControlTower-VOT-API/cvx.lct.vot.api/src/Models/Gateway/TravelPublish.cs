﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class TravelPublishParams
    {
        public bool IsUserEnforced { get; set; }
        public string DeleteVCNStart { get; set; }
        public string DeleteVCNEnd { get; set; }
        public IEnumerable<TravelRoutePublish> Routes { get; set; }
    }

    public class TravelRoutePublish
    {
        public int VesselId { get; set; }
        public string VesselName { get; set; }
        public int DurationAtPort { get; set; }
        public DateTime EtaAtJetty { get; set; }
        public DateTime EtdFromJetty { get; set; }
        public int DepartureFromId { get; set; }
        public string DepartureFrom { get; set; }
        public int DepartureToId { get; set; }
        public string DepartureTo { get; set; }
        public int VesselRoutePurposeId { get; set; }
        public string VesselRoutePurpose { get; set; }
        public string Comment { get; set; }
        public int UserID { get; set; }
        public string EmailAddress { get; set; }
        public string Username { get; set; }
        public Guid VOTRouteId { get; set; }

        public IEnumerable<TravelRouteDetail> RouteDetails { get; set; }
        public IEnumerable<LoadingList> LoadingList { get; set; }
    }

    public class TravelRouteDetail
    {
        public int SequenceNumber { get; set; }
        public string LocationFrom { get; set; }
        public int LocationFromId { get; set; }
        public string LocationTo { get; set; }
        public int LocationToId { get; set; }
        public DateTime eta { get; set; }
        public DateTime etd { get; set; }
        public decimal loadingTime { get; set; }
        public decimal offload { get; set; }
        public decimal backload { get; set; }
        public decimal spaceRemaining { get; set; }
        public string sequenceComments { get; set; }
        public decimal weightAdded { get; set; }
        public decimal weightRemoved { get; set; }
        public decimal weightRemaining { get; set; }
        public decimal distance { get; set; }
        public decimal speed { get; set; }
        public decimal? latitudeFrom { get; set; }
        public decimal? latitudeTo { get; set; }
        public decimal? longitudeFrom { get; set; }
        public decimal? longitudeTo { get; set; }
    }

    public class LoadingList
    {
        public int SequenceNumber { get; set; }
        public int LCTMMRNumber { get; set; }
        public int MaterialRequestDetailsID { get; set; }
    }

    public class VCNMapping
    {
        public string VCN { get; set; }
        public Guid VotRouteId { get; set; }
    }
}
