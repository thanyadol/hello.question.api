using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace cvx.lct.vot.api.Models
{
    public class MaterialParams
    {
        public Guid Id { get; set; }

        public Guid TravelId { get; set; }
        public int VesselLCTReferenceId { get; set; }
        public int Sequence { get; set; }
        public int ItemLCTReferenceId { get; set; }  // joint with LCTMRMaterialRequestDetailsId at MaterialRequest

        public List<int> Sequences { get; set; }

        public string VesselName { get; set; }
        //public string  VesselLCTReferenceId  { get; set; }
        public string CurrentStatusOfItem { get; set; }
        public string CurrentAssignedVessel { get; set; }

        //from mmr

        public Nullable<int> LCTMRMaterialRequestDetailsId { get; set; }
        public Nullable<int> LCTMRMaterialRequestId { get; set; }


        public Nullable<Guid> PlanId { get; set; }
        public string Priority { get; set; }

        public Nullable<int> MRPriorityReferenceId { get; set; }

        // [StringLength(50)]
        public string DeliveredStatus { get; set; }
        public string ItemType { get; set; }
        public string BoundType { get; set; }
        public string Asset { get; set; }

        //[StringLength(100)]//
        public string From { get; set; }
        public Nullable<int> LCTOriginReferenceId { get; set; }

        //[StringLength(100)]
        public string To { get; set; }

        public string Grouping { get; set; }

        public Nullable<int> LCTDestinationReferenceId { get; set; }


        [NotMapped]
        public string FinalDestination { get; set; }

        public string Department { get; set; }

        public string Description { get; set; }


        public Nullable<int> LCTMMRReferenceNumber { get; set; }

        public DateTime? ROSDate { get; set; }

        public Nullable<decimal> Qty { get; set; }

        public string QtyUnit { get; set; }
        public string QuantityUnit { get; set; }
        //dimension
        public Nullable<decimal> Length { get; set; }
        public Nullable<decimal> Width { get; set; }

        public Nullable<decimal> Height { get; set; }

        public Nullable<decimal> Area { get; set; }
        public Nullable<decimal> Weight { get; set; }

        [NotMapped]
        public string WeightUnit { get; set; }

        [NotMapped]
        public int TotalWeight { get; set; }

        [NotMapped]
        public int TripNo { get; set; }

        public string Class { get; set; }
        public string Remarks { get; set; }
        // public string VesselName { get; set; }
        public string LCTOrderNumber { get; set; }
        public string DropOrderNumber { get; set; }

        [NotMapped]
        public decimal GroupArea { get; set; }

        [NotMapped]
        public decimal GroupAreaBackload { get; set; }

        [NotMapped]
        public decimal GroupAreaOffload { get; set; }

        [NotMapped]
        public decimal GroupWeight { get; set; }

        [NotMapped]
        public decimal GroupLift { get; set; }

        [NotMapped]
        public int GroupCount { get; set; }

    }

}