using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace cvx.lct.vot.api.Models
{
    public class PlanParams
    {



        public Guid Id { get; set; }

        //for display only

        public string Name { get; set; }


        public string Remark { get; set; }

        //for display only
        public string Version { get; set; }

        public string Action { get; set; }
        public PlanLocation PlanLocation { get; set; }

        public PlanVessel PlanVessel { get; set; }

        public PlanResource PlanResource { get; set; }

        //for blockout time and location
        public List<VesselBookActivity> VesselBookActivities { get; set; }
        //public Guid[] IsIncludeToCalculateList { get; set; }

        public PlanCargo OrderedCargo { get; set; } //with list of pir=ority
        //public PlanCargo PlanCargo { get; set; }

        public List<MaterialRequest> Tasks { get; set; }

        public List<Location> TaskLocations { get; set; }


        public string By { get; set; }

        public int ClientGmtOffsetInMinutes { get; set; }

        public string Status { get; set; }

        public Nullable<DateTime> SyncedDate { get; set; }
        public Nullable<DateTime> Date { get; set; }
        //public Nullable<Decimal> RigBuffer { get; set; }

        public int Week { get; set; }

        public int Year { get; set; }




    }
}

