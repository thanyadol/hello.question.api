using System;

using System.Collections.Generic;
using System.Linq;
using cvx.lct.vot.api.Extensions;
using cvx.lct.vot.api.Models;

//validator
using FluentValidation;
using FluentValidation.Results;

using VESSEL = cvx.lct.vot.api.Models.Constant.Vessel;
using LOCATION = cvx.lct.vot.api.Models.Constant.Location;

namespace cvx.lct.vot.api.Validator
{
    public class PlanValidator : AbstractValidator<PlanParams>
    {
        public PlanValidator()
        {

            //location
            RuleFor(x => x.PlanLocation.JettyAvailable).NotNull().GreaterThanOrEqualTo(1).LessThanOrEqualTo(2);
            RuleFor(x => x.PlanLocation.WHPBuffer).NotNull().GreaterThanOrEqualTo(0);
            RuleFor(x => x.PlanLocation.RigBuffer).NotNull().GreaterThanOrEqualTo(0);

            //resource
            RuleFor(x => x.PlanResource.ServiceTimePort).NotNull().GreaterThanOrEqualTo(0);
            RuleFor(x => x.PlanResource.ServiceTimePM).NotNull().GreaterThanOrEqualTo(0);
            RuleFor(x => x.PlanResource.ServiceTimeTank).NotNull().GreaterThanOrEqualTo(0);

            RuleFor(x => x.PlanResource.TieUpRig).NotNull().GreaterThanOrEqualTo(0);
            RuleFor(x => x.PlanResource.TieUpOther).NotNull().GreaterThanOrEqualTo(0);

            //pump
            RuleFor(x => x.PlanResource.PumpFuel).NotNull().GreaterThanOrEqualTo(1);
            RuleFor(x => x.PlanResource.PumpWater).NotNull().GreaterThanOrEqualTo(1);
            RuleFor(x => x.PlanResource.PumpSaraline).NotNull().GreaterThanOrEqualTo(1);


            RuleFor(x => x.PlanResource.PumpCementJackUp).NotNull().GreaterThanOrEqualTo(1);
            RuleFor(x => x.PlanResource.PumpCementTender).NotNull().GreaterThanOrEqualTo(1);
            RuleFor(x => x.PlanResource.PumpBariteJackUp).NotNull().GreaterThanOrEqualTo(1);
            RuleFor(x => x.PlanResource.PumpBariteTender).NotNull().GreaterThanOrEqualTo(1);

            RuleFor(x => x.PlanResource.LiftingJackup).NotNull().GreaterThanOrEqualTo(1);
            RuleFor(x => x.PlanResource.LiftingPlatform).NotNull().GreaterThanOrEqualTo(1);
            RuleFor(x => x.PlanResource.LiftingTanker).NotNull().GreaterThanOrEqualTo(1);
            RuleFor(x => x.PlanResource.LiftingTender).NotNull().GreaterThanOrEqualTo(1);

            //minimum
            RuleFor(x => x.PlanResource.MinimumBlockROB).NotNull().GreaterThanOrEqualTo(0);
            // RuleFor(x => x.PlanResource.MinimumRefillROB).NotNull().GreaterThanOrEqualTo(0);
            RuleFor(x => x.PlanResource.MinimumTripROB).NotNull().GreaterThanOrEqualTo(0);
            RuleFor(x => x.PlanResource.MinimumBlockROBPercentage).NotNull().GreaterThanOrEqualTo(0);
            RuleFor(x => x.PlanResource.MinimumTripROBPercentage).NotNull().GreaterThanOrEqualTo(0);


            RuleFor(x => x.PlanResource.RefillVolume).NotNull().GreaterThanOrEqualTo(0);
            RuleFor(x => x.PlanResource.E2QuotaVolume).NotNull().GreaterThanOrEqualTo(0);

            //other
            RuleFor(x => x.PlanResource.UnderwayVoyageRate).NotNull().GreaterThanOrEqualTo(0);
            RuleFor(x => x.PlanResource.PlannedStandbyLessThanTwoHrsRate).NotNull().GreaterThanOrEqualTo(0);
            RuleFor(x => x.PlanResource.BerthAtJettyRate).NotNull().GreaterThanOrEqualTo(0);
            RuleFor(x => x.PlanResource.AhtsTarCost).NotNull().GreaterThanOrEqualTo(0);
            RuleFor(x => x.PlanResource.UtilityTarCost).NotNull().GreaterThanOrEqualTo(0);

            RuleFor(x => x.PlanResource.BackloadCountLimit).NotNull().GreaterThanOrEqualTo(0);
            RuleFor(x => x.PlanResource.BackloadLengthLimit).NotNull().GreaterThanOrEqualTo(0);
            RuleFor(x => x.PlanResource.BackloadSpaceLimit).NotNull().GreaterThanOrEqualTo(0);
            RuleFor(x => x.PlanResource.BackloadWeightLimit).NotNull().GreaterThanOrEqualTo(0);

            //backload
            RuleFor(x => x.PlanResource.BackloadAfterBlockout).NotNull();
            RuleFor(x => x.PlanResource.BackloadCapacityDiscount).NotNull();
            RuleFor(x => x.PlanResource.ModelTypeSelection).NotNull();

            //route
            // RuleFor(x => x.PlanResource.RouteLocateLimit).NotNull().GreaterThanOrEqualTo(1);
            RuleFor(x => x.PlanResource.RouteTurnaround).NotNull().GreaterThanOrEqualTo(1)
                        .When(x => x.PlanResource.RouteOption == RouteOptionType.CONSTAINT.GetDescription());

            RuleFor(x => x.PlanResource.AssetBuffer).NotNull().GreaterThanOrEqualTo(1)
                        .When(x => x.PlanResource.AssetGroupConcern == true);

            //plan location
            RuleFor(x => x.PlanLocation.AllowWaitingTimeField).NotNull();
            RuleFor(x => x.PlanLocation.AllowWaitingTimeField).NotNull();

            //   RuleFor(x => x.PlanVessel.Properties).NotNull().
            //mmr
            RuleFor(x => x.Tasks).NotNull().NotEmpty();
            RuleFor(x => x.Tasks).Custom((list, context) =>
            {
                if (list.Where(c => c.IsIncludeToCalculate == true && c.Status == "Pending").Count() <= 0)
                {
                    context.AddFailure(new ValidationFailure(
                           $"Plan.Tasks", // property name
                           $"'Selected Pending Plan.MMR' tasks must at least one in list"));
                }
            });//.Cascade(CascadeMode.StopOnFirstFailure);


            //foreach vessel
            RuleFor(x => x.PlanVessel.Properties).NotNull().NotEmpty();
            RuleFor(x => x.PlanVessel.Properties).Custom((list, context) =>
                {
                    if (list.Where(c => c.IsIncludeToCalculate == true /* && c.StatusReferenceId == (int)VesselStatus.ONHIRE*/).Count() <= 0)
                    {
                        context.AddFailure(new ValidationFailure(
                               $"PlanVessel.VesselProperties ", // property name
                               $"'Selected Onhire Plan.VesselInfo' must at least one in list"));
                    }
                });

            RuleForEach(x => x.PlanVessel.Properties).ChildRules(p =>
            {
                //deisel
                p.RuleFor(y => y).NotNull().Custom((dto, context) =>
                {
                    var DieselTankCapacity = dto.DieselTankCapacity;
                    var MinimumTripROB = dto.MinimumTripROB;
                    var MinimumRefillROB = dto.MinimumRefillROB;

                    if (dto.DeiselROB >= DieselTankCapacity)
                    {
                        context.AddFailure(new ValidationFailure(
                            $"'VesselProperties.DeiselROB' ", // property name
                            $"{dto.Name} 'VesselProperties.DeiselROB' must less than DieselTankCapacity."));
                    }

                    /* if (dto.DeiselROB <= (MinimumRefillROB * DieselTankCapacity))
                    {
                        context.AddFailure(new ValidationFailure(
                            $"'VesselProperties.DeiselROB' ", // property name
                            $"'VesselProperties.DeiselROB' must greather than percantage of MinimumRefillROB."));
                    }*/

                    if (dto.DeiselROB <= MinimumTripROB)
                    {
                        context.AddFailure(new ValidationFailure(
                            $"'VesselProperties.DeiselROB' ", // property name
                            $"{dto.Name} 'VesselProperties.DeiselROB' must greather than MinimumTripROB."));
                    }

                });

                p.RuleFor(y => y.ETADate).NotNull()
                                   .WithMessage(j => $"{j.Name} VesselProperties.ETADate'  not be null.");

                /*p.RuleFor(y => y.TabularHeightLimitPerside).NotNull().GreaterThan(0)
                          .WithMessage(j => $"{j.Name} VesselProperties.TabularHeightLimitPerside' must greather than zero.");
                p.RuleFor(y => y.TabularSpaceLimitPerside).NotNull().GreaterThan(0)
                     .WithMessage(j => $"{j.Name} VesselProperties.TabularSpaceLimitPerside' must greather than zero.");
                p.RuleFor(y => y.TabularWeightLimitPerside).NotNull().GreaterThan(0)
                     .WithMessage(j => $"{j.Name} VesselProperties.TabularWeightLimitPerside' must greather than zero.");*/


                p.RuleFor(y => y.BaseLocationReferenceId).NotNull().GreaterThan(0).WithMessage(j => $"{j.Name} 'VesselProperties.BaseLocation' must not be null.");


                p.RuleFor(y => y.DeckWidth).NotNull().GreaterThan(0)
                     .WithMessage(j => $"{j.Name} VesselProperties.DeckWidth (LCT)' must greather than zero.");
                p.RuleFor(y => y.DeiselROB).NotNull().GreaterThan(0)
                     .WithMessage(j => $"{j.Name} VesselProperties.DeiselROB (LCT)' must greather than zero.");

                //(LCT Parameters)
                p.RuleFor(y => y.NormalSpeed).NotNull().GreaterThan(0).WithMessage(j => $"{j.Name} 'VesselProperties.NormalSpeed (LCT)' must greather than zero.");
                p.RuleFor(y => y.DeckSpaceLimit).NotNull().GreaterThan(0).WithMessage(j => $"{j.Name} 'VesselProperties.DeckSpaceLimit (LCT)' must greather than zero.");
                p.RuleFor(y => y.DeadWeightLimit).NotNull().GreaterThan(0).WithMessage(j => $"{j.Name} 'VesselProperties.DeadWeightLimit (LCT)' must greather than zero.");
                p.RuleFor(y => y.DieselTankCapacity).NotNull().GreaterThan(0).WithMessage(j => $"{j.Name} 'VesselProperties.DieselTankCapacity (LCT)' must greather than zero.");

                //vessel tank
                //  p.RuleFor(y => y.Tank.Barite).NotNull().WithMessage("'VesselTank.Barite (LCT)' must not be null");
                //  p.RuleFor(y => y.Tank.BhiCement).NotNull().WithMessage("'VesselTank.Cement (LCT)' must not be null");
                // p.RuleFor(y => y.Tank.DrillWater).NotNull().WithMessage("'VesselTank.Water (LCT)' must not be null");
                p.RuleFor(y => y.DieselTankCapacity).NotNull().WithMessage(j => $"{j.Name} 'VesselTank.DieselTankCapacity (LCT)' not be null.");
                // p.RuleFor(y => y.Tank.PotWater).NotNull().WithMessage("'VesselTank.Barite (LCT)' must not be null");


            });

            //max, min ETA
            RuleFor(y => y).NotNull().Custom((dto, context) =>
            {
                var vess = dto.PlanVessel.Properties.Where(c => c.IsIncludeToCalculate == true).OrderBy(c => c.ETADate);

                var min = vess.Min(c => c.ETADate).GetValueOrDefault();
                var max = vess.Max(c => c.ETADate).GetValueOrDefault();

                TimeSpan diff = max.Subtract(min);
                if (diff.TotalDays >= VESSEL.MAXIMUM_ETA_TIMESPAN_INDAY) // + VESSEL.MAX_VALIDATE_ETA_IN_DAYS)
                {
                    context.AddFailure(new ValidationFailure(
                                               $"'VesselProperties.ETADate' ", // property name
                                               $"'VesselProperties.ETADate' maximum interval must less than or equal 7 days."));
                }

                //validate book activity if condition
                //     max = max.AddDays(VESSEL.MAX_VALIDATE_BLOCKOUT__DAYS);

                foreach (var v in vess)
                {
                    foreach (var k in v.BlockActivities)
                    {

                        switch (k.Type)
                        {
                            case 1:
                                break;

                            case 2:
                                //rigg move
                                if (string.IsNullOrEmpty(k.RigMoveStartLocCode))
                                {
                                    context.AddFailure(new ValidationFailure($"'BookActivities.RigMoveStartLocation' ", // property name
                                                                                $"{v.Name} 'BookActivities.RigMoveStartLocation' (LCT) must not be null."));
                                }

                                if (string.IsNullOrEmpty(k.RigMoveEndLocCode))
                                {
                                    context.AddFailure(new ValidationFailure($"'BookActivities.RigMoveEndLocation' ", // property name
                                                                                $"{v.Name} 'BookActivities.RigMoveEndLocation' (LCT) must not be null."));
                                }


                                if (k.RigMoveStartDate == null)
                                {
                                    context.AddFailure(new ValidationFailure($"'BlockActivities.RigMoveStartDate' ", // property name
                                                                 $"{v.Name} 'BookActivities.RigMoveStartDate' (LCT) must not be null."));
                                }

                                if (k.RigMoveEndDate == null)
                                {
                                    context.AddFailure(new ValidationFailure($"'BlockActivities.RigMoveEndDate' ", // property name
                                                                                $"{v.Name} 'BookActivities.RigMoveEndDate' (LCT) must not be null."));
                                }
                                break;

                            default:
                                if (string.IsNullOrEmpty(k.StartLocationCode))
                                {
                                    context.AddFailure(new ValidationFailure($"'BookActivities.StartLocation' ", // property name
                                                                                $"{v.Name} 'BookActivities.StartLocation' (LCT) must not be null."));
                                }

                                if (string.IsNullOrEmpty(k.EndLocationCode))
                                {
                                    context.AddFailure(new ValidationFailure($"'BookActivities.EndLocation' ", // property name
                                                                                $"{v.Name} 'BookActivities.EndLocation' (LCT) must not be null."));
                                }

                                if (k.StartDate == null)
                                {
                                    context.AddFailure(new ValidationFailure($"'BlockActivities.StartDate' ", // property name
                                                    $"{v.Name} 'BookActivities.StartDate' (LCT) must not be null."));
                                }

                                if (k.EndDate == null)
                                {
                                    context.AddFailure(new ValidationFailure($"'BlockActivities.EndDate' ", // property name
                                                                                $"{v.Name} 'BookActivities.EndDate' (LCT) must not be null."));
                                }
                                break;
                        }

                    }
                }


            });

            //corrsponding vessel base location and MMR to,from
            RuleFor(y => y).NotNull().Custom((dto, context) =>
            {

                int[] vessels = dto.PlanVessel.Properties.Where(c => c.IsIncludeToCalculate == true && c.BaseLocationReferenceId.GetValueOrDefault() != 0)
                                        .Select(c => c.BaseLocationReferenceId.GetValueOrDefault()).ToArray();

                int[] froms = dto.Tasks.Where(c => c.IsIncludeToCalculate == true && c.LCTOriginReferenceId.GetValueOrDefault() != 0)
                                        .Select(c => c.LCTOriginReferenceId.GetValueOrDefault()).ToArray();

                int[] tos = dto.Tasks.Where(c => c.IsIncludeToCalculate == true && c.LCTDestinationReferenceId.GetValueOrDefault() != 0)
                                            .Select(c => c.LCTDestinationReferenceId.GetValueOrDefault()).ToArray();


                //just terminal
                var unions = froms.Union(tos).Where(c => LOCATION.TERMINALS.ContainsKey(c)).Distinct();


                //validate destination origin of MMR
                foreach (int v in vessels.Distinct())
                {
                    if (unions.Contains(v))
                    {
                        continue;
                    }

                    context.AddFailure(new ValidationFailure(
                                         $"'VesselProperties.BaseLocation' ", // property name
                                         $"'VesselProperties.BaseLocation' must corresponding with origin or destination at least one of MMR."));
                }

                //validate bsaae locaton of veesel
                foreach (int l in unions)
                {
                    if (vessels.Contains(l))
                    {
                        continue;
                    }

                    context.AddFailure(new ValidationFailure(
                                         $"'MMRs.From / MMRs.To' ", // property name
                                         $"'MMRs.From / MMRs.To' must corresponding with vessel base location at least one of Vessel."));
                }

                //mmr mush have jetty
                var tasks = dto.Tasks.Where(c => c.IsIncludeToCalculate == true);
                var temp = tasks.Where(c => !vessels.Contains(c.LCTOriginReferenceId.GetValueOrDefault())
                                                   && !vessels.Contains(c.LCTDestinationReferenceId.GetValueOrDefault()));

                if (temp.Count() > 0)
                {
                    var ids = String.Join(',', temp.Select(c => c.LCTMRMaterialRequestId).ToArray());

                    context.AddFailure(new ValidationFailure(
                                         $"'MMRs.From / MMRs.To' ", //property name
                                         $"'MMRs.From / MMRs.To' [{ids}]  must corresponding with vessel base location at least one of Vessel."));
                }

            });


            //validate mmr task location
            RuleForEach(x => x.TaskLocations).ChildRules(p =>
            {
                p.RuleFor(y => y.Lat).NotNull().WithMessage(j => $"{j.Code} MMRsLocation.Latitude' must not be null").GreaterThan(0)
                                   .WithMessage(j => $"{j.Code} MMRsLocation.Latitude' must not be null");

                p.RuleFor(y => y.Long).NotNull().WithMessage(j => $"{j.Code} MMRsLocation.Latitude' must not be null").GreaterThan(0)
                .WithMessage(j => $"{j.Code} MMRsLocation.Longtitude' must not be null");
            });


        }
    }

    /* public class VesselPropertiesValidator : AbstractValidator<VesselProperties>
    {
        public VesselPropertiesValidator()
        {
            RuleFor(x => x.Total).GreaterThan(0);
        }
    }*/
}