using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace cvx.lct.vot.api.Models
{
    public class VesselProperties
    {
        public VesselProperties()
        {
            this.MinimumRefillROB = 30m;
            this.MinimumTripROB = 100m;
        }

        [Key]
        public Guid Id { get; set; }

        [ForeignKey("PlanVessel")]
        public Guid PlanVesselId { get; set; }

        [NotMapped]
        public Guid VesselId { get; set; }

        [NotMapped]
        public string Name { get; set; }

        [NotMapped]
        public string BaseLocationName { get; set; }

        [NotMapped]
        public double BaseLocationLong { get; set; }


        [NotMapped]
        public double BaseLocationLat { get; set; }


        [NotMapped]
        public string Status { get; set; }

        [NotMapped]
        public string Type { get; set; }


        public Nullable<int> BaseLocationReferenceId { get; set; }
        //configure
        public Nullable<int> LCTReferenceId { get; set; }

        // [Column(TypeName = "decimal(28, 10)")]
        // public decimal? TabularSpaceLimit { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal? TabularSpaceLimitPerside { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal? TabularWeightLimitPerside { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal? TabularHeightLimitPerside { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public decimal? DeckWidth { get; set; }


        [NotMapped]
        public decimal? DeckSpaceArea { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> LCTReferenceETADate { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> ETADate { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public decimal? DeiselROB { get; set; }


        [StringLength(50)]
        public string By { get; set; }

        [NotMapped]
        public bool IsETAUpdated { get; set; }


        //[StringLength(10)]
        //public string RecordStatus { get; set; }

        public bool IsIncludeToCalculate { get; set; }

        // [StringLength(10)]
        // public string ConfigurationType { get; set; }

        public int StatusReferenceId { get; set; }

        [NotMapped]
        public decimal DieselTankCapacity { get; set; }


        [NotMapped]
        public decimal MinimumRefillROB { get; set; }


        [NotMapped]
        public decimal? MinimumTripROB { get; set; }

        [NotMapped]
        public double? NormalSpeed { get; set; }
        [NotMapped]
        public decimal? DeckSpaceLimit { get; set; }
        [NotMapped]
        public decimal? DeadWeightLimit { get; set; }


        /* 
        [NotMapped]
        public decimal? TankBarite { get; set; }

        [NotMapped]
        public decimal? TankCement { get; set; }

        [NotMapped]
        public decimal? TankWater { get; set; }

        [NotMapped]
        public decimal? TankPotWater { get; set; }

        [NotMapped]
        public decimal? TankLiquidBulk { get; set; }

        [NotMapped]
        public decimal? TankDryBulk { get; set; }

        [NotMapped]
        public decimal? TankFuel { get; set; }*/

        [JsonIgnore]
        [NotMapped]
        public List<VesselBookActivity> BlockActivities { get; set; }

        [JsonIgnore]
        [NotMapped]
        public VesselTank Tank { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Date { get; set; }

    }

}