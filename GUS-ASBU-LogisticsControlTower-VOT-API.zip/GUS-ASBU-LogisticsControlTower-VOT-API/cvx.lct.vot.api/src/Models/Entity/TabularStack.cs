using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class TabularStack
    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("Tabular")]
        public Guid BaseId { get; set; }


        [ForeignKey("Tabular")]
        public Guid StackableId { get; set; }


        [StringLength(50)]
        public string By { get; set; }


        [StringLength(10)]
        public string RecordStatus { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Date { get; set; }


        [NotMapped]
        public string Name { get; internal set; }

        [NotMapped]
        public string StackableName { get; internal set; }

    }

}