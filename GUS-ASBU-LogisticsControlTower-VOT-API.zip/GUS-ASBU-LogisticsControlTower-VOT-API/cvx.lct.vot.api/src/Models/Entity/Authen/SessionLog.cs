using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class SessionLog
    {


        [Key]
        // [StringLength(50)]
        public Guid Id { get; set; }



        [StringLength(1000)]
        public string Token { get; set; }

        [StringLength(50)]
        public string Unique { get; set; }


        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }


        [Column(TypeName = "datetime")]
        public DateTime? TokenExpiredDate { get; set; }

    }
}