using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class User
    {
        [NotMapped]
        public string ObjectId { get; set; }


        [NotMapped]
        public string LastName { get; set; }


        public Guid ADId { get; set; }

        [Key]
        [StringLength(50)]
        public virtual string Id { get; set; }

        [StringLength(50)]
        public string By { get; set; }

        [StringLength(50)]
        public string CAI { get; set; }
        //public Clan Clan { get; set; }

        [StringLength(100)]
        public string DisplayName { get; set; }

        [StringLength(100)]
        public string GivenName { get; set; }


        [StringLength(100)]
        public string AccountName { get; set; }

        [StringLength(200)]
        public string Name { get; set; }

        //[StringLength(20)]
        //public string Mobile { get; set; }

        [StringLength(50)]
        public string Unique { get; set; }

        [StringLength(100)]
        public string Email { get; set; }


        [StringLength(50)]
        public string EmployeeId { get; set; }
        public bool IsADEnable { get; set; }

        [StringLength(50)]
        public string ADGroup { get; set; }


        [Column(TypeName = "datetime")]
        public DateTime? Created { get; set; }

        [NotMapped]
        public string AccessToken { get; set; }


    }
}