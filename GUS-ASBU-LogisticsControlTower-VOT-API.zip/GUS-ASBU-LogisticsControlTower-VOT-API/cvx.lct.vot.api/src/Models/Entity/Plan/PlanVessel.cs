using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class PlanVessel
    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("Plan")]
        public Guid PlanId { get; set; }

        [StringLength(250)]
        public string Name { get; set; }

        [StringLength(20)]
        public string ConfigurationType { get; set; }

        [NotMapped]
        public List<VesselProperties> Properties { get; set; }



        [StringLength(50)]
        public string By { get; set; }


        [StringLength(50)]
        public string Description { get; set; }

        [StringLength(10)]
        public string RecordStatus { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Date { get; set; }

    }

}