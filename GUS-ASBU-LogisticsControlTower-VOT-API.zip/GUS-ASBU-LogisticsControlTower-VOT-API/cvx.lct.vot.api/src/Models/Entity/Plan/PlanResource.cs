using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class PlanResource
    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("Plan")]
        public Guid PlanId { get; set; }

        [StringLength(250)]
        public string Name { get; set; }

        [StringLength(20)]
        public string ConfigurationType { get; set; }


        [Column(TypeName = "decimal(28, 10)")]


        //service time

        public Nullable<Decimal> ServiceTimePort { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> ServiceTimeTank { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> ServiceTimePM { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> TieUpRig { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> TieUpOther { get; set; }


        //pump rate
        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<int> PumpFuel { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<int> PumpWater { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<int> PumpSaraline { get; set; }



        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<int> PumpCementJackUp { get; set; }



        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<int> PumpCementTender { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<int> PumpBariteJackUp { get; set; }



        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<int> PumpBariteTender { get; set; }



        //Lifting rate

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<int> LiftingTender { get; set; }



        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<int> LiftingPlatform { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<int> LiftingJackup { get; set; }



        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<int> LiftingTanker { get; set; }


        //fuel

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<int> MinimumBlockROB { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> MinimumBlockROBPercentage { get; set; }



        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<int> MinimumTripROB { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> MinimumTripROBPercentage { get; set; }



        //in percentage
        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<int> MinimumRefillROB { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<int> RefillVolume { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<int> E2QuotaVolume { get; set; }


        //consumtion
        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> UnderwayVoyageRate { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> PlannedStandbyLessThanTwoHrsRate { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> BerthAtJettyRate { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> AnchorHandlingTowingRate { get; set; }

        //cost
        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> AhtsTarCost { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> UtilityTarCost { get; set; }

        //back load

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> BackloadCapacityDiscount { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> BackloadAfterBlockout { get; set; }

        public Nullable<int> BackloadCountLimit { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> BackloadSpaceLimit { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> BackloadWeightLimit { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> BackloadLengthLimit { get; set; }


        //contrain route

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<int> RouteLocateLimit { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> RouteTurnaround { get; set; }

        [StringLength(20)]
        public string RouteFunction { get; set; }


        public bool MaximizeBackloadCapacity { get; set; }

        [StringLength(20)]
        public string RouteOption { get; set; }

        [StringLength(20)]
        public string ModelTypeSelection { get; set; }



        public bool AssetGroupConcern { get; set; }


        //hrs
        [Column(TypeName = "decimal(28, 10)")]
        public decimal AssetBuffer { get; set; }


        [StringLength(50)]
        public string By { get; set; }


        [StringLength(50)]
        public string Description { get; set; }

        [StringLength(10)]
        public string RecordStatus { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Date { get; set; }

    }

}