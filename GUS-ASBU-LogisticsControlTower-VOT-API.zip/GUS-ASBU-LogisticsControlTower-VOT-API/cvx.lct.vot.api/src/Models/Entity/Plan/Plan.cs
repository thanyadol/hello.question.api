using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

using PLAN = cvx.lct.vot.api.Models.Constant.Plan;

namespace cvx.lct.vot.api.Models
{
    [Serializable]
    public class Plan
    {
        public Plan()
        {
            this.LastestJob = PLAN.DEFAULT_RUNNNING_JOB;
            //this.SyncedDate = DateTime.UtcNow;
        }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> SyncedDate { get; set; }

        [Key]
        public Guid Id { get; set; }

        //[StringLength(50)]
        public Guid Key { get; set; }

        //[StringLength(50)]
        public Guid Rev { get; set; }

        //for display only
        [StringLength(500)]
        public string Name { get; set; }

        //for display only
        [StringLength(500)]
        public string Version { get; set; }

        public string By { get; set; }

        [StringLength(10)]
        public string Status { get; set; }

        [StringLength(20)]
        public string ConfigurationType { get; set; }



        [StringLength(5000)]
        public string Remark { get; set; }

        [NotMapped]
        public Job LastestJob { get; set; }



        [StringLength(10)]
        public string RecordStatus { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Date { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> FinishDate { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> StartDate { get; set; }


        [NotMapped]
        public int Week { get; set; }
        [NotMapped]
        public int Year { get; set; }



        [NotMapped]
        public DateTime PublishedDate { get; set; }


    }
}

