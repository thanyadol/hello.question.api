using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class PlanLocation
    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("Plan")]
        public Guid PlanId { get; set; }

        [StringLength(250)]
        public string Name { get; set; }

        [StringLength(20)]
        public string ConfigurationType { get; set; }


        [Column(TypeName = "decimal(28, 10)")]

        public Nullable<int> JettyAvailable { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> WHPBuffer { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> RigBuffer { get; set; }

        [Column(TypeName = "decimal(28, 10)")]


        //new
        public Nullable<Decimal> AllowWaitingTimeField { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> AllowWaitingTimeJetty { get; set; }


        [NotMapped]
        public List<LocationState> LocationRestrictedHours { get; set; }

        [NotMapped]
        public List<LocationState> TankSchedules { get; set; }


        [StringLength(50)]
        public string By { get; set; }


        [StringLength(50)]
        public string Description { get; set; }

        [StringLength(10)]
        public string RecordStatus { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Date { get; set; }

    }

}