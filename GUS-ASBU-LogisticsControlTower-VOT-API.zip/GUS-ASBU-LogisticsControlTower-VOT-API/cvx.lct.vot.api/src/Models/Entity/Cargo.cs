using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace cvx.lct.vot.api.Models
{

    public class Cargo
    {
        [Key]
        public Guid Id { get; set; }


        [StringLength(100)]
        public string Name { get; set; }



        [StringLength(10)]
        public string Type { get; set; }

        public string By { get; set; }

        [StringLength(10)]
        public string RecordStatus { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Date { get; set; }

    }
}

