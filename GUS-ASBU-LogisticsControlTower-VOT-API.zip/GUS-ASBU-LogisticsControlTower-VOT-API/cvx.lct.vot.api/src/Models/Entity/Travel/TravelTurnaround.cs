﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class TravelTurnaround
    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("Travel")]
        public Guid TravelId { get; set; }

        public int VesselLCTReferenceId { get; set; }
        public string VesselName { get; set; }

        public Nullable<DateTime> DispatchDate { get; set; }
        public Nullable<DateTime> EtaDate { get; set; }
        [Column(TypeName = "decimal(28, 10)")]
        public decimal TurnaroundTime { get; set; }
        public int NumOfLocation { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal? CostRatioInUSD { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal? CostInUSD { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal? MT { get; set; }
        public int TripNo { get; set; }
    }
}
