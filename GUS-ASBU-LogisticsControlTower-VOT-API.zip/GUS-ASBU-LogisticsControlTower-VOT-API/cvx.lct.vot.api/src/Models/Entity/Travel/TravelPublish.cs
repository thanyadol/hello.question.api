﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class TravelPublish
    {
        public Guid Id { get; set; }
        public Guid TravelRouteId { get; set; }

        [StringLength(100)]
        public string VCN { get; set; }
        public DateTime Date { get; set; }
        public bool IsDeleted { get; set; }
        public Guid PublishId { get; set; }
    }
}
