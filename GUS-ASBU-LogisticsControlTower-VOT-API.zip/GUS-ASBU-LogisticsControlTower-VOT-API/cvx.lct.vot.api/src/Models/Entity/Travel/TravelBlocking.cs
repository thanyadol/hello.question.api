using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class TravelBlocking
    {

        [Key]
        public Guid Id { get; set; }

        [ForeignKey("Travel")]
        public Guid TravelId { get; set; }

        [StringLength(50)]
        public string Name { get; set; }

        public int VesselLCTReferenceId { get; set; }

        [StringLength(250)]
        public string Description { get; set; }

        [StringLength(20)]
        public string FuelConsumtionRateType { get; set; }

        [StringLength(20)]
        public string Type { get; set; }

        [StringLength(20)]
        public string BlockedType { get; set; }

        public int TripNo { get; set; }


        [Column(TypeName = "datetime")]
        public DateTime Start { get; set; }


        [Column(TypeName = "datetime")]
        public DateTime End { get; set; }

        [NotMapped]
        public TimeSpan TimeDuration { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal? FuelConsumtionRate { get; set; }

        public double? FuelConsumtionValue { get; set; }
    }
}