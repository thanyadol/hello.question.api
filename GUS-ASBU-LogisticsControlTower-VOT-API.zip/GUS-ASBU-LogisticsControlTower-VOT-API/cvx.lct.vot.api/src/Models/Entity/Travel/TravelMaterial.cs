﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class TravelMaterial
    {
        public TravelMaterial()
        {
            this.VotIsChanged = false;
            this.LctReferenceIsDeleted = false;
        }

        [Key]
        public Guid Id { get; set; }

        [ForeignKey("Travel")]
        public Guid TravelId { get; set; }

        public int? VesselLCTReferenceId { get; set; }
        public int? Sequence { get; set; }
        public int? ItemLCTReferenceId { get; set; }  // joint with LCTMRMaterialRequestDetailsId at MaterialRequest
        public int? TripNo { get; set; }
        public int? MmrLCTReferenceId { get; set; }

        [StringLength(20)]
        public string CurrentStatus { get; set; }

        [StringLength(500)]
        public string OrderNumber { get; set; }

        [StringLength(20)]
        public string DeliveredStatus { get; set; }

        // public bool IsUnprocessed { get; set; }

        [DefaultValue(false)]
        public bool? VotIsChanged { get; set; }

        [DefaultValue(false)]
        public bool? LctReferenceIsDeleted { get; set; }
    }
}
