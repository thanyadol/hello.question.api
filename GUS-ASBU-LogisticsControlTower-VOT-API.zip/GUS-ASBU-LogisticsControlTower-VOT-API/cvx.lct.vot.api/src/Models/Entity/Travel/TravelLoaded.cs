﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class TravelLoaded
    {

        public TravelLoaded()
        {
            this.Order = 0;
        }

        [Key]
        public Guid Id { get; set; }

        [ForeignKey("Travel")]
        public Guid TravelId { get; set; }

        //[NotMapped]

        //public Guid PlanId { get; set; }
        //public int VesselLCTReferenceId { get; set; }

        [NotMapped]
        public int Order { get; set; }

        [StringLength(10)]
        public string Priority { get; set; }

        [NotMapped]
        public string Name { get; set; }

        //CURRENT or EXPIRED
        [StringLength(20)]
        public string Type { get; set; }

        //BACKLOAD or OFFLOAD
        [StringLength(20)]
        public string BoundType { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal? Success { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal? Delivery { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal? Total { get; set; }

        [NotMapped]
        //[Column(TypeName = "decimal(28, 10)")]
        public decimal? DevileredPercentage { get; set; }

        [NotMapped]
        //[Column(TypeName = "decimal(28, 10)")]
        public decimal[] Plots { get; set; }

        [NotMapped]
        //   [Column(TypeName = "decimal(28, 10)")]
        public decimal? SuccessedPercentage { get; set; }
    }
}
