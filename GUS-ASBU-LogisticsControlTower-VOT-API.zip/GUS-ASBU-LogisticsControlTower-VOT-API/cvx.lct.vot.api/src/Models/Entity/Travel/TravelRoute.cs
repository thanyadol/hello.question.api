﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class TravelRoute
    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("Travel")]
        public Guid TravelId { get; set; }

        [NotMapped]
        public string PlanName { get; set; }


        [NotMapped]
        public string HtmlColorCode { get; set; }

        [NotMapped]
        public string RunId { get; set; }


        [NotMapped]
        public string PlanType { get; set; }

        [StringLength(50)]
        public string VesselName { get; set; }


        public int VesselLCTReferenceId { get; set; }

        public int Sequence { get; set; }
        public int TripNo { get; set; }
        public int FromLCTLocationReferenceId { get; set; }

        [StringLength(50)]
        public string FromLocationCode { get; set; }
        public int ToLCTLocationReferenceId { get; set; }

        [StringLength(50)]
        public string ToLocationCode { get; set; }

        [StringLength(50)]
        public string OriginType { get; set; }


        public DateTime? EtaDate { get; set; }
        public DateTime? EtdDate { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal LoadingTime { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal OffLoadSpace { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal BackLoadSpace { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal SpaceRemaining { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal OffLoadWeight { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public decimal BackLoadWeight { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public decimal WeightRemaining { get; set; }

        // public IEnumerable<RouteParams> Routes { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public decimal Distance { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal Speed { get; set; }


        //for gulf
        [StringLength(50)]
        public string FromLocationName { get; set; }

        [StringLength(50)]
        public string FromLocationType { get; set; }

        [StringLength(50)]
        public string FromLocationCategory { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal? FromLatitude { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public decimal? FromLongitude { get; set; }

        [NotMapped]
        [StringLength(50)]
        public string Asset { get; set; }

        [NotMapped]
        public DateTime? ProcessETD { get; set; }
        [NotMapped]
        public DateTime? UpdatedProcessETD { get; set; }



    }
}
