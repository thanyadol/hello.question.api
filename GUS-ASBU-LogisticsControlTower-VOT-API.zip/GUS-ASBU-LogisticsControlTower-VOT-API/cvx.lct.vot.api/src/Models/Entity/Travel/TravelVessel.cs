﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class TravelVessel
    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("Travel")]
        public Guid TravelId { get; set; }

        public int VesselLCTReferenceId { get; set; }

        public string BoundType { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal SpaceRemaining { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal CargoWeight { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal BulkWeight { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal TotalWeight { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal BulkVolume { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public decimal DryBulkVolume { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public decimal LiquidBulkVolume { get; set; }

        public int TripNo { get; set; }

        [NotMapped]
        public decimal EffectiveDeckSpace { get; set; }

        [NotMapped]
        public decimal SpaceUsed { get; set; }

    }
}
