﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class Travel

    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("Job")]
        public Guid JobId { get; set; }


        [ForeignKey("PlanId")]
        public Guid PlanId { get; set; }


        //public string By { get; set; }

        //[StringLength(10)]
        //public string Status { get; set; }

        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        [StringLength(5000)]
        public string Remark { get; set; }

        [NotMapped]
        public Job LastestJob { get; set; }


        //[StringLength(10)]
        //public string RecordStatus { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Date { get; set; }


        [NotMapped]
        public DateTime PublishedDate { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal? TotalDistance { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal? TotalDuration { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal? CostRatioInUSD { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal? CostRatioInUSDTrip1 { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal? CostRatioInUSDTrip2 { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal? FuelConsumption { get; set; }

        public int? DroppedMaterial { get; set; }
        public bool IsFavorite { get; set; }
    }
}
