using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class TravelActivity
    {


        [Key]
        // [StringLength(50)]
        public Guid Id { get; set; }


        public Guid? Key { get; set; }

        public Guid? Rev { get; set; }

        public Guid? Parent { get; set; }


        [StringLength(50)]
        public string Discriminator { get; set; }  //LOGIN or ADMIN



        [StringLength(50)]
        public string Type { get; set; } //SAVED, PUBLISHED

        [StringLength(50)]
        public string By { get; set; }

        [StringLength(20)]
        public string Status { get; set; }

        public string Message { get; set; }
        //  public int WeekOfYear { get; set; }

        //[ForeignKey("Job")]
        //  public Guid JobId { get; set; }


        [ForeignKey("Travel")]
        public Guid TravelId { get; set; }

        [NotMapped]
        public string JobRunId { get; set; }

        [NotMapped]
        public Guid JobId { get; set; }


        [NotMapped]
        public string PlanName { get; set; }
        [NotMapped]
        public string PlanRemark { get; set; }

        [NotMapped]
        public bool IsTravelFavorite { get; set; }


        [NotMapped]
        public DateTime JobRunDate { get; set; }



        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }

    }
}