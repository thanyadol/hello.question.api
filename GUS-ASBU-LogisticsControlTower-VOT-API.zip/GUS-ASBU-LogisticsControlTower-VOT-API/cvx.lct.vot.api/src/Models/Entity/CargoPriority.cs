using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using cvx.lct.vot.api.Extensions;
using Newtonsoft.Json;

namespace cvx.lct.vot.api.Models
{

    public class CargoPriority
    {
        public CargoPriority()
        {
            this.InsertState = cvx.lct.vot.api.Models.InsertState.DEFAULT.GetDescription();
        }

        [Key]
        public Guid Id { get; set; }


        //[NotMapped]
        [Column(TypeName = "decimal(28, 10)")]
        public decimal UserCoefficient { get; set; }


        // [NotMapped]
        [Column(TypeName = "decimal(28, 10)")]
        public decimal NormalizedCoefficient { get; set; }


        [StringLength(100)]
        public string Name { get; set; }


        [ForeignKey("Cargo")]
        public Nullable<Guid> CargoId { get; set; }


        [ForeignKey("PlanCargo")]
        public Guid PlanCargoId { get; set; }

        public int Order { get; set; }

        [StringLength(20)]
        public string BoundType { get; set; }


        [StringLength(20)]
        public string LocationType { get; set; }

        [StringLength(10)]
        public string Priority { get; set; }


        [StringLength(10)]
        public string Type { get; set; }

        public bool IsIncludeToCalculate { get; set; }
        public string By { get; set; }

        //  [StringLength(10)]
        // public string RecordStatus { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Date { get; set; }

        [NotMapped]
        public string BoundTypeDisplay { get; set; }

        [NotMapped]
        public string LocationTypeDisplay { get; set; }

        //[NotMapped]
        public string InsertState { get; set; }

    }
}

