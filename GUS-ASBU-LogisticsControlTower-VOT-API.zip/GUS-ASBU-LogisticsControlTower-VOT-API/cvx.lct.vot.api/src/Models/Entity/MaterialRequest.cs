using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class MaterialRequest
    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("Material")]
        public Nullable<Guid> MaterialId { get; set; }

        [ForeignKey("Plan")]
        public Nullable<Guid> PlanId { get; set; }


        public string BoundType { get; set; }


        public Nullable<int> LCTMRMaterialRequestDetailsId { get; set; }
        public Nullable<int> LCTMRMaterialRequestId { get; set; }

        public DateTime? ROSDate { get; set; }
        public DateTime? PlannedDispatchDate { get; set; }

        [StringLength(100)]
        public string Asset { get; set; }


        public Nullable<int> LCTMRDepartmentReferenceId { get; set; }

        [StringLength(100)]
        public string From { get; set; }
        public Nullable<int> LCTOriginReferenceId { get; set; }

        [StringLength(100)]
        public string To { get; set; }
        public Nullable<int> LCTDestinationReferenceId { get; set; }

        [StringLength(50)]
        public string Department { get; set; }
        //  public Nullable<Nullable<int> >  LCTMRNumber { get; set; }
        public string ItemType { get; set; }
        //  public string ItemSubType { get; set; }
        // public string Item { get; set; }
        //  public string MaterialDescription { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> QuantityValue { get; set; }
        public Nullable<int> MRQuantityUnitReferenceId { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> WeightValue { get; set; }
        // public string WeightUnit { get; set; }
        public Nullable<int> MRWeightUnitReferenceId { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> Length { get; set; }
        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> Width { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> Height { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> Area { get; set; }

        [StringLength(500)]
        public string Remarks { get; set; }


        //public Nullable<decimal> QuantityValue { get; set; }
        [StringLength(50)]
        public string QuantityUnit { get; set; }

        public Nullable<int> Qty { get; set; }



        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> Weight { get; set; }


        public Nullable<int> MRPriorityReferenceId { get; set; }

        [StringLength(50)]
        public string Priority { get; set; }


        [StringLength(5000)]
        public string Description { get; set; }


        //[NotMapped]
        public bool IsIncludeToCalculate { get; set; }

        [StringLength(50)]
        public string By { get; set; }

        [StringLength(10)]
        public string Status { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Date { get; set; }

        [NotMapped]
        public string FromCluster { get; set; }
        [NotMapped]
        public string ToCluster { get; set; }
        [NotMapped]
        public string DestinationType { get; set; }
        [NotMapped]
        public string DestinationCategory { get; set; }

        [NotMapped]
        public string Vendor { get; set; }

        [NotMapped]
        public string Class { get; set; }

        [NotMapped]
        public string Remark { get; set; }
        [NotMapped]
        public bool IsAssignedToVessel { get; set; }
        [NotMapped]
        public int PlannedVesselId { get; set; }
        [NotMapped]
        public string PlannedVesselName { get; set; }

        //[NotMapped]
        public string LCTOrderNumber { get; set; }

    }
}
