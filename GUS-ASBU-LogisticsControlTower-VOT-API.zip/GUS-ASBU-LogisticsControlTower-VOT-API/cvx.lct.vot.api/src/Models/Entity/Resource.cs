using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class Resource
    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("Plan")]
        public Guid PlanId { get; set; }

        [StringLength(250)]
        public string Name { get; set; }

        [StringLength(20)]
        public string Type { get; set; }


        [Column(TypeName = "decimal(28, 10)")]


        //service time

        public Nullable<Decimal> ServiceTimePort { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> ServiceTimeTank { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> ServiceTimePM { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> TieUpRig { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> TieUpOther { get; set; }


        //pump rate
        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> PumpFuel { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> PumpWater { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> PumpSaraline { get; set; }



        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> PumpCementJackUp { get; set; }



        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> PumpCementTender { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> PumpBariteJackUp { get; set; }



        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> BariteTender { get; set; }



        //Lifting rate

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> LiftingTender { get; set; }



        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> LiftingPlatform { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> LiftingJackup { get; set; }



        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> LiftingTanker { get; set; }


        //fuel

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> MinimumBlockROB { get; set; }



        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> MinimumTripROB { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> MinimumRefillROB { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> RefileVolumn { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> E2QuotaVolumn { get; set; }


        //consumtion
        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> UnderwayVoyageRate { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> PlannedStandbyLessThanTwoHrsRate { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> BerithAtJettyRate { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> AnchorHandlingTowingRate { get; set; }

        //cost
        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> AhtsTarCost { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> UtilityTarCost { get; set; }

        //back load

        public Nullable<int> BackloadCountLimit { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> BackloadSpaceLimit { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> BackloadWeightLimit { get; set; }


        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> BackloadLengthLimit { get; set; }


        //contrain route

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> RouteLocateLimit { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<Decimal> RouteTurnaround { get; set; }


        [StringLength(50)]
        public string RouteFunction { get; set; }



        [StringLength(50)]
        public string RouteOption { get; set; }



        //public bool AssetGroupConcern { get; set; }


        //hrs.
        // [Column(TypeName = "decimal(28, 10)")]
        //  public string AssetBuffer { get; set; }



        [StringLength(50)]
        public string By { get; set; }


        [StringLength(50)]
        public string Description { get; set; }

        [StringLength(10)]
        public string RecordStatus { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Date { get; set; }

    }

}