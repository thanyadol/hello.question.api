using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace cvx.lct.vot.api.Models
{
    [Serializable]

    [Table("ModelProductionParameter", Schema = "dbo")]
    public class ModelProductionParameter
    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("ModelParameter")]
        public Guid ModelParameterId { get; set; }

        [StringLength(20)]
        public string Priority { get; set; }

        [StringLength(20)]
        public string Type { get; set; } //prodcution or drilling

        public int StartRosInDays { get; set; }
        public int EndingRosInDays { get; set; }

        public int CostPerMTRosInDays { get; set; }
        public int PercentRosInDays { get; set; }

    }
}

