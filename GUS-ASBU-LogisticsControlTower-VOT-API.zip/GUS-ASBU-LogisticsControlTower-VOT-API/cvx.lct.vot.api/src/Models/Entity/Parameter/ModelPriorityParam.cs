using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace cvx.lct.vot.api.Models
{
    [Serializable]

    [Table("ModelPriorityParameter", Schema = "dbo")]
    public class ModelPriorityParameter
    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("ModelParameter")]
        public Guid ModelParameterId { get; set; }


        [StringLength(50)]
        public string ModelObjectiveType { get; set; } //prodcution or drilling


        public bool IsP1ObjectConstraint { get; set; }

        public bool IsRosEndingOrdering { get; set; }

        public int P1ProductionRos { get; set; }
        public int P2ProductionRos { get; set; }
        public int P3ProductionRos { get; set; }

    }
}

