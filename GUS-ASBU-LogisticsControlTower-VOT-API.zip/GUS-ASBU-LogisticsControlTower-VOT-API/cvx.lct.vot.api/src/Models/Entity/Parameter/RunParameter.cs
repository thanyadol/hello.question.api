using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace cvx.lct.vot.api.Models
{
    [Serializable]

    [Table("RunParameter", Schema = "dbo")]
    public class RunParameter
    {
        [Key]
        public Guid Id { get; set; }


        [StringLength(50)]
        public string By { get; set; }

        [StringLength(20)]
        public string ConfigurationType { get; set; }

        [StringLength(50)]
        public string RecordStatus { get; set; }

        [StringLength(2500)]
        public string Remark { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Date { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> FinishDate { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> StartDate { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public decimal? ExecuteTime { get; set; }

        public int? SolutionLimit { get; set; }

    }
}

