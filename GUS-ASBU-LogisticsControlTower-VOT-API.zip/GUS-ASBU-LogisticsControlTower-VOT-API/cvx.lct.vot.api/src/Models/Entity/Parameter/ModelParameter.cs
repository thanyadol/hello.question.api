using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace cvx.lct.vot.api.Models
{
    [Serializable]

    [Table("ModelParameter", Schema = "dbo")]
    public class ModelParameter
    {
        [Key]
        public Guid Id { get; set; }


        [StringLength(50)]
        public string By { get; set; }

        [StringLength(20)]
        public string ConfigurationType { get; set; }

        [StringLength(50)]
        public string RecordStatus { get; set; }

        [StringLength(2500)]
        public string Remark { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Date { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> FinishDate { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> StartDate { get; set; }


        //properties of model parameters
        [StringLength(50)]
        public string OptimizedAlgorithm { get; set; }


        [StringLength(50)]
        public string MmrVesselRatio { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> VesselEtdRangeTrip { get; set; }

        public int VesselPerTrip { get; set; }

        [StringLength(50)]
        public string PenaltyWeight { get; set; } //should be int

        //conversion factor

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> SaralineWeightCVFactor { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> FuelWeightCVFactor { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> WaterWeightCVFactor { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> BariteWeightCVFactor { get; set; }

        [Column(TypeName = "decimal(28, 10)")]

        public Nullable<decimal> CementWeightCVFactor { get; set; }

        [NotMapped]

        public List<ModelPriorityParameter> Objectives { get; set; }

        [NotMapped]
        public List<ModelProductionParameter> Productions { get; set; }
        [NotMapped]
        public List<ModelProductionParameter> Drillings { get; set; }

    }
}

