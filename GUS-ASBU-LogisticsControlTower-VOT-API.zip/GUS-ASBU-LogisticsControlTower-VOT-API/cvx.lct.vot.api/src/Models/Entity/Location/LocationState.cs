using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using cvx.lct.vot.api.Extensions;
using Newtonsoft.Json;

namespace cvx.lct.vot.api.Models
{
    public class LocationState
    {
        public LocationState()
        {
            this.EntityState = cvx.lct.vot.api.Models.EntityState.QUERIED.GetDescription();
        }

        [Key]
        public Guid Id { get; set; }

        [JsonIgnore]
        [ForeignKey("Location")]
        public Guid LocationId { get; set; }

        [NotMapped]
        public string LocationName { get; set; }

        [StringLength(20)]
        public string LocationCode { get; set; }

        [NotMapped]
        public string LocationCategory { get; set; }



        [ForeignKey("PlanLocation")]
        public Guid PlanLocationId { get; set; }


        public Nullable<int> LCTReferenceId { get; set; }


        //public bool IsRig { get; set; }


        // 
        //public bool IsFuel { get; set; }
        [StringLength(20)]
        public string Activity { get; set; }


        [StringLength(50)]
        public string By { get; set; }


        public bool IsIncludeToCalculate { get; set; }

        //   [StringLength(10)]
        //  public string RecordStatus { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Date { get; set; }

        [Column(TypeName = "datetime")]
        public Nullable<DateTime> ScheduleDateStart { get; set; }



        [Column(TypeName = "datetime")]
        public Nullable<DateTime> ScheduleDateEnd { get; set; }




        [Column(TypeName = "time(7)")]
        public Nullable<TimeSpan> RestrictedTimeStart { get; set; }


        [Column(TypeName = "time(7)")]
        public Nullable<TimeSpan> RestrictedTimeEnd { get; set; }

        [NotMapped]
        public string EntityState { get; set; }


        [NotMapped]
        public string Asset { get; set; }

        //[StringLength(50)]
        public bool IsTanker { get; set; }


    }

}