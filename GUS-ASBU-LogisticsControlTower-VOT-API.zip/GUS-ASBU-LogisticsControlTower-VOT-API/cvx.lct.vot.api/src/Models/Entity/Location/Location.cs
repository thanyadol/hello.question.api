using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models
{
    public class Location
    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("Location")]
        public Nullable<int> LCTReferenceId { get; set; }


        [StringLength(50)]
        public string Code { get; set; }

        // [NotMapped]
        // public Guid RouteParamsId { get; set; }


        [StringLength(50)]
        public string Name { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> Lat { get; set; }

        [Column(TypeName = "decimal(28, 10)")]
        public Nullable<decimal> Long { get; set; }


        [StringLength(50)]
        public string Type { get; set; }


        [StringLength(50)]
        public string By { get; set; }


        [StringLength(50)]
        public string Description { get; set; }

        [StringLength(10)]
        public string RecordStatus { get; set; }

        //[NotMapped]
        [Column("ParentLocationLCTReferenceId")]
        public Nullable<int> ParentLocationLCTReferenceId { get; set; }

        //[NotMapped]
        [Column("ChildLocationLCTReferenceId")]
        public Nullable<int> ChildLocationLCTReferenceId { get; set; }


        [Column(TypeName = "datetime")]
        public Nullable<DateTime> Date { get; set; }

        [NotMapped]
        public string Asset { get; set; }



        [NotMapped]
        public string Category { get; set; }

        [NotMapped]
        public int? ClusterRefId { get; internal set; }

        [NotMapped]
        public string ClusterCode { get; internal set; }

        [NotMapped]
        public decimal? ClusterLongtitude { get; internal set; }

        [NotMapped]
        public decimal? ClusterLatitude { get; internal set; }

        [NotMapped]
        public string ClusterName { get; internal set; }

        [NotMapped]
        public bool IsActive { get; internal set; }

        [NotMapped]
        public bool IsDeleted { get; internal set; }

        [NotMapped]
        public int LocationTypeId { get; internal set; }

        [NotMapped]
        public int DORPlatformId { get; set; }
    }

}