using System;
using AutoMapper;
using cvx.lct.vot.api.APIs.Models;
using cvx.lct.vot.api.Models;

namespace cvx.lct.vot.api.Mapper
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<MmrAsync, MaterialRequest>()
                    .ForMember(dest => dest.LCTMRMaterialRequestId, opt => opt.MapFrom(src => src.MRMaterialRequestId))
                    .ForMember(dest => dest.LCTMRMaterialRequestDetailsId, opt => opt.MapFrom(src => src.MRMaterialRequestDetailsId))
                    .ForMember(dest => dest.PlannedDispatchDate, opt => opt.MapFrom(src => src.PlannedDispatchDate))
                    .ForMember(dest => dest.ROSDate, opt => opt.MapFrom(src => src.ROSDate))
                    .ForMember(dest => dest.Asset, opt => opt.MapFrom(src => src.Asset))
                    .ForMember(dest => dest.LCTOriginReferenceId, opt => opt.MapFrom(src => src.OriginId))
                    .ForMember(dest => dest.From, opt => opt.MapFrom(src => src.Origin))
                    .ForMember(dest => dest.LCTDestinationReferenceId, opt => opt.MapFrom(src => src.DestinationId))
                    .ForMember(dest => dest.To, opt => opt.MapFrom(src => src.Destination))
                    .ForMember(dest => dest.LCTMRDepartmentReferenceId, opt => opt.MapFrom(src => src.MRDepartmentId))
                    .ForMember(dest => dest.Department, opt => opt.MapFrom(src => src.Department))
                    .ForMember(dest => dest.MRQuantityUnitReferenceId, opt => opt.MapFrom(src => src.MRQuantityUnitId))
                    .ForMember(dest => dest.MRWeightUnitReferenceId, opt => opt.MapFrom(src => src.MRWeightUnitId))
                    .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.MaterialDescription))
                    .ForMember(dest => dest.ItemType, opt => opt.MapFrom(src => src.ItemType))
                    .ForMember(dest => dest.Qty, opt => opt.MapFrom(src => src.QuantityValue))

                    .ForMember(dest => dest.Length, opt => opt.MapFrom(src => src.Length))
                    .ForMember(dest => dest.Width, opt => opt.MapFrom(src => src.Width))
                    .ForMember(dest => dest.Height, opt => opt.MapFrom(src => src.Height))
                    .ForMember(dest => dest.Area, opt => opt.MapFrom(src => src.Area))
                    .ForMember(dest => dest.Weight, opt => opt.MapFrom(src => src.TotalWeight))
                    .ForMember(dest => dest.Priority, opt => opt.MapFrom(src => src.Priority))
                    .ForMember(dest => dest.MRPriorityReferenceId, opt => opt.MapFrom(src => src.MRPriorityId))

                     .ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.RequestStatus))
                     .ForMember(dest => dest.IsAssignedToVessel, opt => opt.MapFrom(src => src.IsAssignedToVessel))
                     .ForMember(dest => dest.PlannedVesselId, opt => opt.MapFrom(src => src.PlannedVesselId))
                     .ForMember(dest => dest.PlannedVesselName, opt => opt.MapFrom(src => src.PlannedVesselName))

                     //.ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.ItemType))

                     .ForMember(dest => dest.LCTOrderNumber, opt => opt.MapFrom(src => src.OrderNumber))

                     .ReverseMap();

            //why error ????
            /* *
            CreateMap<LocationAsync, Location>()
                .ForMember(dest => dest.LCTReferenceId, opt => opt.MapFrom(src => src.Id))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Name))
                .ForMember(dest => dest.Code, opt => opt.MapFrom(src => src.Code))
                .ForMember(dest => dest.Lat, opt => opt.MapFrom(src => src.Latitude))
                .ForMember(dest => dest.Long, opt => opt.MapFrom(src => src.Longitude))
                .ForMember(dest => dest.Type, opt => opt.MapFrom(src => src.Type))
                .ForMember(dest => dest.IsActive, opt => opt.MapFrom(src => src.IsActive))
                .ForMember(dest => dest.IsDeleted, opt => opt.MapFrom(src => src.IsDeleted))
                .ForMember(dest => dest.LocationTypeId, opt => opt.MapFrom(src => src.LocationTypeId))
                .ReverseMap();


            /* 
            CreateMap<VesselAsync, Vessel>()
                .ForMember(dest => dest.LCTReferenceId, opt => opt.MapFrom(src => src.Id))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Name))
                .ForMember(dest => dest.StatusId, opt => opt.MapFrom(src => src.StatusId))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.Status))
                .ForMember(dest => dest.Type, opt => opt.MapFrom(src => src.Type))
                       .ReverseMap();*/
        }
    }
}