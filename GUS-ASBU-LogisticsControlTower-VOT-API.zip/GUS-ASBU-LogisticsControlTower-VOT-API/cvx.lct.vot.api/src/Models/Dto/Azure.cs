
using System;

using System.IO;
using System.Reflection;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Collections.Generic;

namespace surflex.netcore22.Models.DTO
{
    public class JobRequest
    {
        public JobRequest()
        {
            notebook_params = new Dictionary<string, string>();
        }

        public long job_id { get; set; }
        public Dictionary<string, string> notebook_params { get; set; }
    }

    public class CancelParams
    {
        public string run_id { get; set; }
    }

    public class JobParams
    {
        public string url { get; set; }
        public Guid jobId { get; set; }
        public Guid planId { get; set; }
    }

    public class JobResponse
    {
        public string run_id { get; set; }
        public string number_in_job { get; set; }
        public State state { get; set; }
    }

    public class State
    {
        public string life_cycle_state { get; set; }
        public string state_message { get; set; }
        public string result_state { get; set; }
    }
    public class DataBrickJobs
    {
        public IEnumerable<DatabrickJob> jobs { get; set; }
    }
    public class DatabrickJob
    {
        public Int64 job_id { get; set; }
        public DatabrickJobSetting settings { get; set; }
    }

    public class DatabrickJobSetting
    {
        public string name { get; set; }
        public int max_concurrent_runs { get; set; }
    }
}