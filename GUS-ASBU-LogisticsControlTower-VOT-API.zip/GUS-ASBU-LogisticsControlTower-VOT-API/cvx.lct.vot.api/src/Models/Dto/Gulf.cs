using System;

using System.IO;
using System.Reflection;
using System.Globalization;
using System.Runtime.InteropServices;

namespace surflex.netcore22.Models.DTO
{
    [Serializable]
    public class Gulf
    {
        public string PlanName { get; set; }
        public string RunId { get; set; }

        public int VesselId { get; set; }
        public DateTime? ArrivalTimeCurrent { get; set; }
        public DateTime? DepartureTimeCurrent { get; set; }

        public DateTime? ArrivalTimeNext { get; set; }
        public string Vessel { get; set; }
        public int TripNo { get; set; }

        public string FromLocationCode { get; set; }
        public string ToLocationCode { get; set; }


        // public int ClusterId { get; set; }
        //public string ClusterCode { get; set; }
        public string FromLocationName { get; set; }
        public decimal? Lat { get; set; }
        public decimal? Long { get; set; }

        public string Type { get; set; }
        public string Category { get; set; }
        public string Asset { get; set; }
    }
}