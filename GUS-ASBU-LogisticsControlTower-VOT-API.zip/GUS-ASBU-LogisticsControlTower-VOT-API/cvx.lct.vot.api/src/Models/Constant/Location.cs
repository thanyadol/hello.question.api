using System;
using System.Collections.Generic;
using cvx.lct.vot.api.Extensions;
using cvx.lct.vot.api.Models;

//using LocationCluster = cvx.lct.vot.api.Models.Location;

namespace cvx.lct.vot.api.Models.Constant
{
    public static class Location
    {

        public static string[] CATEGORY_ORDERED = {
            "Terminal",
            "Rig",
            "Non Rig",
            "Tanker",
            null
        };

        public static Dictionary<string, string> ACTIVITY = new Dictionary<string, string>() {
            {
                "DOTOPUP",
                "D.O. Top up"
            },
            {
                "CONDENSATELIFTING",
                "Condensate Lifting"
            },
            {
                "MAINTENANCE",
                "Maintenance"
            },

        };

        public static Dictionary<int, string> TERMINALS = new Dictionary<int, string>() {
            {
                349,
                "PSB JETTY"
            },
            {
                350,
                "SAT JETTY"
            }

        };

        public static string DEFAULT_COLOR_CODE = "#fff";

        public static Dictionary<int, string> HTML_COLOR_CODE = new Dictionary<int, string>() {
            {
                349,
                "#9e9e9e"
            },
            {
                350,
                "#9e9e9e"
            },

            {
                397,
                "#4caf50"
            },
            {
                187,
                "#3f51b5"
            },
            {
                202,
                "#ff5722"
            },

            {
                222,
                "#9e9e9e"
            },
            {
                341,
                "#4caf50"
            },
            {
                167,
                "#3f51b5"
            },
            {
                152,
                "#ff5722"
            },
        };
        public static Guid DEFAULT_SCHEDULE_ID = Guid.Parse("000D5A47-26A6-4271-BFDB-644EBB0A16FB");

    }

}
