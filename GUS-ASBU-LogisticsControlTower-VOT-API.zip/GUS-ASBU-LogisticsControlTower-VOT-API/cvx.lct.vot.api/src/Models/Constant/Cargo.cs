using System;
using System.Collections.Generic;
using cvx.lct.vot.api.Extensions;
using cvx.lct.vot.api.Models;

namespace cvx.lct.vot.api.Models.Constant

{
    public static class Cargo
    {

        public static Dictionary<string, string> BOUND = new Dictionary<string, string>()
        {
            { "OFFLOAD", "Offload"},
            { "BACKLOAD", "Backload" },
        };

        public static Dictionary<string, string> LOCATION = new Dictionary<string, string>()
        {
            { "PRODUCTION", "Production"},
            { "RIG", "Rig" },
        };



        public static Dictionary<string, decimal> PRIORITY = new Dictionary<string, decimal>()
        {
            { "P1", 0.5m},
            { "P2", 0.25m},
            { "P3", 0.125m},
        };


       // public static Guid DEFAULT_SCHEDULE_ID = Guid.Parse("000D5A47-26A6-4271-BFDB-644EBB0A16FB");

    }

}