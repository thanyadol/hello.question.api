﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models.Constant
{
    public class Databrick
    {
        public const string urlRunJobNow = "/api/2.0/jobs/run-now";
        public const string urlGetRunStatus = "/api/2.0/jobs/runs/get";
        public const string urlGetJobs = "/api/2.0/jobs/list";
        public const string urlCannel = "/api/2.0/jobs/runs/cancel";
    }
}
