using System;
using System.Collections.Generic;
using cvx.lct.vot.api.Extensions;
using cvx.lct.vot.api.Models;

namespace cvx.lct.vot.api.Models.Constant
{
    public static class Plan
    {

        public static Guid DEFAULT_PLANNED_ID = Guid.Parse("000d5a47-26a6-4271-bfdb-644ebb0a16fb");

        public static Job DEFAULT_RUNNNING_JOB = new Job() { Status = JobStatus.INITIALIZE.GetDescription(), RunId = "0" };     //  public static Guid DEFAULT_PLANNED_RESOURCE_ID = Guid.Parse("47f468fa-5cda-4987-a0f4-ab6af6d9010c");

        public static double[] PENALTY_WEIGHT = {
              Math.Pow(10, 3),
            Math.Pow(10, 5),
            Math.Pow(10, 7),
            Math.Pow(10, 9),
            Math.Pow(10, 11),
             Math.Pow(10, 13),
        };

    }
}