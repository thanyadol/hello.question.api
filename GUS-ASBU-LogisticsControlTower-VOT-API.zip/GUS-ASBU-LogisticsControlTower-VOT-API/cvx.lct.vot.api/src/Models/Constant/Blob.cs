﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Models.Constant
{
    public static class Blob
    {
        public static string INPUT_LCT_CONTAINER = "lct-processed-input-data";

        public static string CsvDelimiter { get; set; } = ",";
        public static Encoding Encoding { get; set; } = Encoding.UTF8;

        //public static Encoding UniEncoding { get; set; } = Encoding.UTF32;
    }
}
