using System;
using System.Collections.Generic;
using cvx.lct.vot.api.Extensions;
using cvx.lct.vot.api.Models;

namespace cvx.lct.vot.api.Models.Constant
{
    public static class Vessel
    {

        public static Dictionary<int, VesselActivity> ACTIVITY = new Dictionary<int, VesselActivity>
        {
            //for blockingout
           //ANCHOR HANDLING AND
            { (int)VesselBookType.RIGMOVE,
                new VesselActivity() {
                     ActivityId = (int)VesselBookType.RIGMOVE,
                    Name = VesselBookType.RIGMOVE.GetDescription(),
                    FuelConsumtionRate = 0.8m,
                    FuelConsumtionRateType = "ANCHOR HANDLING",
            } },

          //ANCHOR HANDLING AND
            {
                (int)VesselBookType.BUOY,
                new VesselActivity()
                {
                     ActivityId = (int)VesselBookType.BUOY,
                    Name = VesselBookType.BUOY.GetDescription(),
                    FuelConsumtionRate = 0.8m,
                    FuelConsumtionRateType = "ANCHOR HANDLING",
            }  },
           
           //UNDERWAY (VOYAGE)
            {
                (int)VesselBookType.SPECIAL_REQUEST,
                 new VesselActivity()
                 {
                     ActivityId = (int)VesselBookType.SPECIAL_REQUEST,
                    Name = VesselBookType.SPECIAL_REQUEST.GetDescription(),
                    FuelConsumtionRate = 0.4m,
                    FuelConsumtionRateType = "UNDERWAY (VOYAGE)",
            } },

         //BERTH AT JETTY 
            {
                (int)VesselBookType.MAINTENANCE,
                new VesselActivity() {  ActivityId = (int)VesselBookType.MAINTENANCE,
                Name = VesselBookType.MAINTENANCE.GetDescription(), FuelConsumtionRate = 0.05m, FuelConsumtionRateType = "BERTH AT JETTY"  }  },
            {
                (int)VesselBookType.TYPHOON_STANDBY,
                new VesselActivity() {  ActivityId = (int)VesselBookType.TYPHOON_STANDBY,
                Name = VesselBookType.TYPHOON_STANDBY.GetDescription(), FuelConsumtionRate = 0.05m, FuelConsumtionRateType = "BERTH AT JETTY" } },
            
            
          //BERTH AT JETTY 
            { (int)VesselBookType.IDLE,
                new VesselActivity()
                {  ActivityId = (int)VesselBookType.IDLE, Name = VesselBookType.IDLE.GetDescription(), FuelConsumtionRate = 0.05m, FuelConsumtionRateType = "BERTH AT JETTY"  } },
            { (int)VesselBookType.LOADING,
                new VesselActivity()
                {  ActivityId = (int)VesselBookType.LOADING, Name = VesselBookType.LOADING.GetDescription(), FuelConsumtionRate = 0.05m, FuelConsumtionRateType = "BERTH AT JETTY"  } },
            { (int)VesselBookType.PORT_BUNKERING,
                new VesselActivity()
                {  ActivityId = (int)VesselBookType.PORT_BUNKERING, Name = VesselBookType.PORT_BUNKERING.GetDescription(), FuelConsumtionRate = 0.05m, FuelConsumtionRateType = "BERTH AT JETTY"  } },

            { (int)VesselBookType.ACTIVITY_REQUEST, new VesselActivity() {  ActivityId = (int)VesselBookType.ACTIVITY_REQUEST, Name = VesselBookType.ACTIVITY_REQUEST.GetDescription(), FuelConsumtionRate = 0.0m } },
            { (int)VesselBookType.OFFHIRE, new VesselActivity() {  ActivityId = (int)VesselBookType.OFFHIRE, Name = VesselBookType.OFFHIRE.GetDescription(), FuelConsumtionRate = 0.0m } },
            { (int)VesselBookType.OTHER, new VesselActivity() {  ActivityId = (int)VesselBookType.OTHER, Name = VesselBookType.OTHER.GetDescription(), FuelConsumtionRate = 0.0m } },
        };


        public static Dictionary<int, string> STATUS = new Dictionary<int, string>
        {
            //for blockingout
            { 1, "On Hire" },
            { 2, "Off Hire" },
        };

        public static string SAT_BURKERING_LOCATION_CODE = "SAT JETTY";

        /*public static Dictionary<int, string> LCT_ACTIVITY_REFERENCE_ID = new Dictionary<int, string>
        {
            //for blockingout
            { 4, "Final Backload" },
            { 5, "Support Rig Move" },

            //{ 6, "Maintenance" },
            { 7, "DP Operation Require" },
            { 8, "Off Hire" },
            { 10, "Dry Dock" },
            { 11, "Typhoon Standby" },

            { 12, "Riser Less Standby" },
            { 13, "Buoy Maintenance" },

        };*/

        public static Guid DEFAULT_VESSEL_INFO_ID = Guid.Parse("f0a2a815-bc1f-4670-981e-ff6751fff8c9");

        public static decimal MINIMUM_BLOCK_ROB = 300;

        public static decimal ADDITION_DIESEL_SAT_BUNKERING = 200;
        public static decimal MINIMUM_BLOCK_ROB_PERCENTAGE = 50;
        public static decimal MINIMUM_REFILL_ROB_PERCENTAGE = 30;

        public static int ETA_BLOCK_HRS = 84;

        public static int MAX_VALIDATE_BLOCKOUT_DAYS = 14;

        public static decimal NAUTICAL_MILE_CONVERT_CONSTANT = 0.5399568m;

        public static int MAXIMUM_ETA_TIMESPAN_INDAY = 7;

        public static decimal DECK_SIDE = 0.5m;
        public static decimal TUBULAR_EFFECTIVE_DECK_LENGTH = 13.1m;

        public static Dictionary<int, int> LCT_VESSEL_ACTIVITY_REQUESTS = new Dictionary<int, int>
        {
            { 17, (int) VesselBookType.SPECIAL_REQUEST },

            { 19, (int) VesselBookType.MAINTENANCE },

            { 20, (int) VesselBookType.SPECIAL_REQUEST },

            { 21, (int) VesselBookType.OFFHIRE },
            { 23, (int) VesselBookType.OFFHIRE },
            { 24, (int) VesselBookType.TYPHOON_STANDBY },

            { 25, (int) VesselBookType.SPECIAL_REQUEST },
            { 26, (int) VesselBookType.BUOY },
            { 27, (int) VesselBookType.RIGMOVE },

            { 28, (int) VesselBookType.SPECIAL_REQUEST },
            { 29, (int) VesselBookType.SPECIAL_REQUEST }
        };

    }

}
