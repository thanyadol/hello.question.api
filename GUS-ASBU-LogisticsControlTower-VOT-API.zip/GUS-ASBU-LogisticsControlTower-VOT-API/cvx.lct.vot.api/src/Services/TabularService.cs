using System;

using System.Collections.Generic;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;
using AutoMapper;
using cvx.lct.vot.api.APIs.Services;
using cvx.lct.vot.api.Exceptions;
using cvx.lct.vot.api.Extensions;
//vot
using cvx.lct.vot.api.Models;
using cvx.lct.vot.api.Repositories;

//logg
using Serilog;

using BLOB = cvx.lct.vot.api.Models.Constant.Blob;
using System.IO;

namespace cvx.lct.vot.api.Services
{

    public interface ITabularService
    {
        Task<Tabular> CreateAsync(Tabular tabular);
        Task<Tabular> UpdateAsync(Tabular tabular);
        Task<Tabular> GetAsync(Guid id);

        Task<IEnumerable<Tabular>> ListAsync();
        Task<IEnumerable<Tabular>> ListCurrentlyAsync();
        Task<TabularStack> CreateAsync(TabularStack tabular);
        Task<TabularStack> UpdateAsync(TabularStack tabular);
        Task<TabularStack> GetStackAsync(Guid id);

        Task<IEnumerable<TabularStack>> ListStackAsync();

        Task<Tabular> EnforceExistenceAsync(Guid id);
        Task<TabularStack> EnforceStackExistenceAsync(Guid id);

        Stream ListStackBlobAsync(IEnumerable<TabularStack> stacks);
        Stream ListBlobAsync(IEnumerable<Tabular> tabulars);
    }

    public class TabularService : ITabularService
    {
        private readonly ITabularRepository _tabularRepository;
        private readonly ITabularStackRepository _tabularStackRepository;

        public TabularService(ITabularRepository tabularRepository, ITabularStackRepository tabularStackRepository)
        {
            _tabularRepository = tabularRepository ?? throw new ArgumentNullException(nameof(tabularRepository));
            _tabularStackRepository = tabularStackRepository ?? throw new ArgumentNullException(nameof(tabularStackRepository));


            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }

        public Stream ListStackBlobAsync(IEnumerable<TabularStack> stacks)
        {
            var stream = new MemoryStream();

            var headers = new List<string>
            {
                "Id",
                "StackableId",
                "Name",
                "StackableName",
            };

            //Header columns
            string headerLine = $"{string.Join(BLOB.CsvDelimiter, headers.ToArray())}\n";
            stream.Write(BLOB.Encoding.GetBytes(headerLine), 0, BLOB.Encoding.GetBytes(headerLine).Length);

            //records
            foreach (var v in stacks)
            {
                var entity = new List<string>();

                entity.Add(v.Id.ToString());
                entity.Add(v.StackableId.ToString());
                entity.Add(v.Name);
                entity.Add(v.StackableName.ToString());

                var valueLine = $"{string.Join(BLOB.CsvDelimiter, entity.toReplaceArray())}\n";
                stream.Write(BLOB.Encoding.GetBytes(valueLine), 0, BLOB.Encoding.GetBytes(valueLine).Length);
            }

            stream.Position = 0;
            return stream;
        }


        public Stream ListBlobAsync(IEnumerable<Tabular> tabulars)
        {
            var stream = new MemoryStream();

            var headers = new List<string>
            {
                "Id",
                "Name",

                "LengthBundle",
                "WidthBundle",
                "HeightBundle",
                "WeightJoint",

                "MaxStackHeight",
                "JointBundle",

                "Type",

                 "SpaceBundle",
                 "MaxStackLayer",
            };

            //Header columns
            string headerLine = $"{string.Join(BLOB.CsvDelimiter, headers.ToArray())}\n";
            stream.Write(BLOB.Encoding.GetBytes(headerLine), 0, BLOB.Encoding.GetBytes(headerLine).Length);

            //records
            foreach (var v in tabulars)
            {
                var entity = new List<string>();

                entity.Add(v.Id.ToString());
                entity.Add(v.Name.ToString());
                entity.Add(v.LengthBundle.ToString());

                entity.Add(v.WidthBundle.ToString());
                entity.Add(v.HeightBundle.ToString());
                entity.Add(v.WeightJoint.ToString());

                entity.Add(v.MaxStackHeight.ToString());
                entity.Add(v.JointBundle.ToString());
                entity.Add(v.Type);

                entity.Add(v.SpaceBundle.ToString());
                entity.Add(v.MaxStackLayer.ToString());

                var valueLine = $"{string.Join(BLOB.CsvDelimiter, entity.toReplaceArray())}\n";
                stream.Write(BLOB.Encoding.GetBytes(valueLine), 0, BLOB.Encoding.GetBytes(valueLine).Length);
            }

            stream.Position = 0;
            return stream;
        }

        public async Task<Tabular> CreateAsync(Tabular tabular)
        {
            tabular.Id = Guid.NewGuid();
            tabular.Date = DateTime.UtcNow;

            //await EnforceClanExistenceAsync(Tabular.Clan.Name);
            var entity = await _tabularRepository.CreateAsync(tabular);
            if (entity == null)
            {
                throw new TabularNotFoundException(tabular.Id);
            }

            return entity;
        }


        public async Task<Tabular> UpdateAsync(Tabular tabular)
        {
            var updated = await this.EnforceExistenceAsync(tabular.Id);

            //assigned
            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //tabular.Key = Guid.NewGuid().ToString();

            var entity = await _tabularRepository.UpdateAsync(tabular);
            if (entity == null)
            {
                throw new TabularNotFoundException(tabular.Id);
            }

            return entity;
        }

        public async Task<Tabular> GetAsync(Guid id)
        {
            //  await this.EnforceExistenceAsync(id);

            var entity = await _tabularRepository.GetAsync(id);
            return entity;
        }


        public async Task<IEnumerable<Tabular>> ListAsync()
        {
            return await _tabularRepository.ListAsync();
        }

        public async Task<IEnumerable<Tabular>> ListCurrentlyAsync()
        {
            var entities = await _tabularRepository.ListAsync();

            entities = entities.Where(c => c.RecordStatus == RecordStatus.ACTIVE.GetDescription());
            if (entities == null)
            {
                throw new TabularNotFoundException();
            }

            entities.OrderBy(c => c.Name);

            //calculate space, amax stack
            entities = entities.Select(c =>
            {
                c.SpaceBundle = c.LengthBundle * c.WidthBundle.GetValueOrDefault();
                c.MaxStackLayer = Math.Floor(c.MaxStackHeight.GetValueOrDefault() / c.HeightBundle.GetValueOrDefault());
                return c;
            }
            ).ToList();

            return entities;
        }


        //stacl
        public async Task<TabularStack> CreateAsync(TabularStack tabular)
        {
            tabular.Id = Guid.NewGuid();
            tabular.Date = DateTime.UtcNow;

            //await EnforceClanExistenceAsync(Tabular.Clan.Name);
            var entity = await _tabularStackRepository.CreateAsync(tabular);
            if (entity == null)
            {
                throw new TabularStackNotFoundException(tabular.Id);
            }

            return entity;
        }


        public async Task<TabularStack> UpdateAsync(TabularStack tabular)
        {
            var updated = await this.EnforceExistenceAsync(tabular.Id);

            //assigned
            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //tabular.Key = Guid.NewGuid().ToString();

            var entity = await _tabularStackRepository.UpdateAsync(tabular);
            if (entity == null)
            {
                throw new TabularStackNotFoundException(tabular.Id);
            }

            return entity;
        }


        public async Task<TabularStack> GetStackAsync(Guid id)
        {
            //await this.EnforceExistenceAsync(id);

            var entity = await _tabularStackRepository.GetAsync(id);
            return entity;
        }


        public async Task<IEnumerable<TabularStack>> ListStackAsync()
        {
            return await _tabularStackRepository.ListAsync();
        }


        public async Task<Tabular> EnforceExistenceAsync(Guid id)
        {
            var tabular = await _tabularRepository.GetAsync(id);
            if (tabular == null)
            {
                throw new TabularNotFoundException();
            }

            return tabular;
        }

        public async Task<TabularStack> EnforceStackExistenceAsync(Guid id)
        {
            var tabular = await _tabularStackRepository.GetAsync(id);
            if (tabular == null)
            {
                throw new TabularStackNotFoundException();
            }

            return tabular;
        }

    }

}