using System;
using System.Text;
using System.IO;

using System.Collections.Generic;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;
using AutoMapper;
using cvx.lct.vot.api.APIs.Services;
using cvx.lct.vot.api.Exceptions;
using cvx.lct.vot.api.Extensions;

//vot
using cvx.lct.vot.api.Models;
using cvx.lct.vot.api.Repositories;

//logg
using Serilog;

using LOCATION = cvx.lct.vot.api.Models.Constant.Location;
using VESSEL = cvx.lct.vot.api.Models.Constant.Vessel;
using PLAN = cvx.lct.vot.api.Models.Constant.Plan;
using BLOB = cvx.lct.vot.api.Models.Constant.Blob;

using VesselDetailAsync = cvx.lct.vot.api.APIs.Models.VesselRouteDetailAsync;

namespace cvx.lct.vot.api.Services
{

    public interface IVesselService
    {
        Task<Vessel> CreateAsync(Vessel vessel);
        Task<Vessel> UpdateAsync(Vessel vessel);

        Task<Vessel> GetAsync(Guid id);

        Task<IEnumerable<Vessel>> ListAsync();
        Task<Vessel> EnforceVesselExistenceAsync(Guid id);
        Task<VesselProperties> EnforcePropertiesExistenceAsync(Guid id);
        //block out
        Task<IEnumerable<VesselBlockout>> ListBlockoutAsync();
        Task<IEnumerable<VesselDepartureParams>> EstimateTimeDepartureAsync(VesselDepartureRequestParams vessels);
        Task<IEnumerable<VesselProperties>> EstimateTimeArrivedAsync(IEnumerable<VesselProperties> props);
        Task<Vessel> CalculateEffectiveSpaceAsync(decimal deckwidth, decimal deadWeightLimit, decimal dieselTankCapacity);
        Task<VesselActivity> CalculateFuelConsumtionAsync(VesselActivity activity, PlanResource resource);

        //Task<PlanVessel> GetInfoAsync(Guid id);
        //Task<PlanVessel> SynceInfoAsync();

        Task<IEnumerable<VesselProperties>> ListPropertiesAsync(Guid id);
        Task<IEnumerable<VesselArrived>> ListArrivalAsync(Guid id);

        Task<IEnumerable<VesselProperties>> SyncePropertiesAsync(Guid id);
        //Task<VesselArrived> EstimateTimeArrivedAsync(VesselProperties vessel);
        //Task<IEnumerable<VesselBookActivity>> ListBookActivitiesAysnc();
        Task<IEnumerable<VesselBookActivity>> ListBookActivitiesAysnc(DateTime start, DateTime end);
        Task<IEnumerable<VesselTank>> ListVesselTanksAsync();
        Task<PlanVessel> GetPlanVesselAsync(Guid id);

        //move from process data
        // Task<IEnumerable<VesselArrived>> ListVesselArrivalAsync(IEnumerable<VesselProperties> propserties);
        Task<IEnumerable<VesselBookActivity>> ListEtaBookActivityAsync(IEnumerable<VesselDepartureParams> vessels, PlanResource planResource);

        //Task<IEnumerable<VesselBookActivity>> ListBookActivityAsync(IEnumerable<VesselProperties> vessels);

        Task<IEnumerable<VesselCurrentPlan>> ListCurrentRouteAsync();


        Stream ListVesselBlobAsync(IEnumerable<VesselDepartureParams> vessels);


        Stream ListCurrentPlanBlobAsync(IEnumerable<VesselCurrentPlan> vesselss);
        Stream ListBookActivityBlobAsync(IEnumerable<VesselBookActivity> vesselBookActivities);
    }

    public class VesselService : IVesselService
    {
        private readonly IVesselRepository _vesselRepository;
        private readonly ILocationService _locationService;

        private readonly IPlanJobService _planService;

        private readonly IPlanLocationRepository _locationsRepository;
        private readonly IPlanResourceRepository _planResourceRepository;
        private readonly IPlanVesselRepository _planVesselRepository;

        private readonly IPlanVesselRepository _vesselInfoRepository;
        private readonly IVesselPropertiesRepository _propsertiesRepository;

        private readonly IClientService _clientService;
        //private readonly IEntityService _clientService;
        private readonly IMapper _mapper;

        private const string SKIPPED_ROUTE = "SKIPPED";

        public VesselService(IVesselRepository vesselRepository, IPlanVesselRepository vesselInfoRepository, IPlanLocationRepository locationsRepository,
                     ILocationService locationService, IVesselPropertiesRepository propsertiesRepository, IPlanVesselRepository planVesselRepository,
                     IPlanResourceRepository planResourceRepository, IPlanJobService planService, IClientService clientService, IMapper mapper)
        {
            _vesselRepository = vesselRepository ?? throw new ArgumentNullException(nameof(vesselRepository));
            _locationsRepository = locationsRepository ?? throw new ArgumentNullException(nameof(locationsRepository));
            _planResourceRepository = planResourceRepository ?? throw new ArgumentNullException(nameof(planResourceRepository));
            _planVesselRepository = planVesselRepository ?? throw new ArgumentNullException(nameof(planVesselRepository));

            _planService = planService ?? throw new ArgumentNullException(nameof(planService));

            _vesselInfoRepository = vesselInfoRepository ?? throw new ArgumentNullException(nameof(vesselInfoRepository));
            _propsertiesRepository = propsertiesRepository ?? throw new ArgumentNullException(nameof(propsertiesRepository));

            _locationService = locationService ?? throw new ArgumentNullException(nameof(locationService));
            _clientService = clientService ?? throw new ArgumentNullException(nameof(clientService));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }


        public async Task<Vessel> CreateAsync(Vessel vessel)
        {
            vessel.Id = Guid.NewGuid();
            vessel.Date = DateTime.UtcNow;
            //vessel.Status = VesselStatus.ONHIRE.GetDescription();
            vessel.By = "admin";

            //await EnforceClanExistenceAsync(Vessel.Clan.Name);
            var entity = await _vesselRepository.CreateAsync(vessel);
            if (entity == null)
            {
                throw new VesselNotFoundException(vessel.Id);
            }

            return entity;
        }


        public async Task<Vessel> UpdateAsync(Vessel vessel)
        {
            var updated = await this.EnforceVesselExistenceAsync(vessel.Id);

            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //vessel.Key = Guid.NewGuid().ToString();

            var entity = await _vesselRepository.UpdateAsync(vessel);
            if (entity == null)
            {
                throw new VesselNotFoundException(vessel.Id);
            }

            return entity;
        }

        public async Task<Vessel> GetAsync(Guid id)
        {
            //  await this.EnforceVesselExistenceAsync(id);

            var entity = await _vesselRepository.GetAsync(id);
            return entity;
        }


        /* *public async Task<Vessel> DeleteAsync(Guid id)
        {
            await this.EnforceVesselExistenceAsync(id);

            var deletedVessel = await _vesselRepository.DeleteAsync(id);
            return deletedVessel;
        }*/

        public async Task<IEnumerable<Vessel>> ListAsync()
        {
            return await _vesselRepository.ListAsync();
        }


        public async Task<IEnumerable<VesselBlockout>> ListBlockoutAsync()
        {
            var vesselBookActivity = await _clientService.ListBookActivityAsync();

            var vesselBlockout = new List<VesselBlockout>();

            foreach (var bookActivity in vesselBookActivity)
            {
                vesselBlockout.Add(new VesselBlockout
                {
                    LCTReferenceId = bookActivity.BookedActivityId,
                    LCTActivityId = bookActivity.ActivityTypeId,
                    StartDate = bookActivity.StartDate,
                    StartLocationCode = "",
                    //StartLocationId = 0,
                    EndDate = bookActivity.EndDate,
                    EndLocationCode = "",
                    //EndLocationId = 0,
                    _VesselId = bookActivity.VesselId.GetValueOrDefault()
                });
            }

            return vesselBlockout;
        }


        //
        // Summary:
        //     retrun and list veesel congih
        //
        // Returns:
        //
        //   Vessel Variation   model
        //
        // Type parameters:
        //   id:
        //     vessel info  id
        //
        public async Task<IEnumerable<VesselProperties>> ListPropertiesAsync(Guid id)
        {
            var entity = await _propsertiesRepository.ListAsync(id);
            entity = entity.OrderBy(c => c.LCTReferenceId);

            var vessels = await _clientService.ListVesselAsync();
            var location = await _clientService.ListLocationAsync();

            location = location.Where(c => c.IsActive == true);

            //var specifications = await _clientService.ListVesselSpecificationAsync();
            var tanks = await this.ListVesselTanksAsync();

            //set vessel name and base location
            var result = new List<VesselProperties>();
            foreach (var p in entity)
            {
                var v = vessels.Where(c => c.Id == p.LCTReferenceId).FirstOrDefault();
                if (v == null)
                    continue;

                if (v != null)
                {
                    p.Name = v.Name;
                    p.Status = v.Status;
                    p.Type = p.Type;
                    p.DeckSpaceArea = v.Specfication.EffectiveDeckSpace;
                }

                var l = location.Where(c => c.Id == p.BaseLocationReferenceId).FirstOrDefault();
                if (l != null)
                {
                    p.BaseLocationName = l.Code;
                }

                //var s = specifications.Where(c => c.VesselId == p.LCTReferenceId).FirstOrDefault();
                //if (s != null)
                //{
                //    //  p.TabularSpaceLimit = s.TabularSpaceLimit;
                //    //p.DieselTankCapacity = s.DieselTankCapacity.GetValueOrDefault();
                //    p.DeckSpaceArea = s.EffectiveDeckSpace;
                //}

                var t = tanks.Where(c => c.VesselId == v.Id).FirstOrDefault();
                if (t != null)
                {
                    p.DieselTankCapacity = t.DieselTankCapacity.GetValueOrDefault();
                }

                //p.BaseLocationName = "hello";
                //get is updated ETA
                p.IsETAUpdated = p.ETADate != p.LCTReferenceETADate ? true : false;

                result.Add(p);
            }


            return result;
        }

        public async Task<IEnumerable<VesselArrived>> ListArrivalAsync(Guid id)
        {
            var entity = await _propsertiesRepository.ListAsync(id);
            entity = entity.Where(c => c.IsIncludeToCalculate == true).OrderBy(c => c.LCTReferenceId);

            var vessels = await _clientService.ListVesselAsync();
            var location = await _clientService.ListLocationAsync();
            location = location.Where(c => c.IsActive == true);

            //set vessel name and base location
            var result = new List<VesselArrived>();
            foreach (var p in entity)
            {
                var v = vessels.Where(c => c.Id == p.LCTReferenceId).FirstOrDefault();
                if (v != null)
                {
                    p.Name = v.Name;
                    p.Status = v.Status;
                    p.Type = p.Type;
                }

                var l = location.Where(c => c.Id == p.BaseLocationReferenceId).FirstOrDefault();
                if (l != null)
                {
                    p.BaseLocationName = l.Code;
                    p.BaseLocationReferenceId = l.Id;
                }

                //get is updated ETA
                p.IsETAUpdated = p.ETADate != p.LCTReferenceETADate ? true : false;

                if (p.ETADate == null)
                {
                    throw new Exception($"Please enter ETA for vessel {p.VesselId} {p.Name}");
                }

                result.Add(new VesselArrived
                {
                    VesselId = p.VesselId,
                    LCTReferenceId = (int)p.LCTReferenceId,
                    BaseLocationReferenceId = (int)p.BaseLocationReferenceId.GetValueOrDefault(),
                    VesselName = p.Name,
                    ETA = p.ETADate,
                    DieselROB = (decimal)p.DeiselROB

                });
            }


            return result;
        }


        //
        // Summary:
        //     retrun a list of vessel default inoit tabular
        //
        // Returns:
        //
        //   gateway of vessel blockout
        //
        // parameters
        // id is plan vessel id
        //
        public async Task<IEnumerable<VesselProperties>> SyncePropertiesAsync(Guid id)
        {
            //vessel type id
            int[] VESSEL_TYPE_AHTS_UTILITY = new int[] { 2, 6 };

            //list vessel
            var entity = await _clientService.ListVesselAsync();
            if (entity == null)
            {
                throw new VesselNotFoundException();
            }
            entity = entity.Where(c => VESSEL_TYPE_AHTS_UTILITY.Contains(c.TypeId)).ToList();

            //list default props
            var props = await _propsertiesRepository.ListAsync(id);//VESSEL.DEFAULT_VESSEL_INFO_ID);
            if (props == null)
            {
                throw new VesselPropertiesNotFoundException();
            }

            var location = await _clientService.ListLocationAsync();
            location = location.Where(c => c.IsActive == true);

            //filter
            //props = props.Where(c => c.PlanVesselId == VESSEL.DEFAULT_VESSEL_INFO_ID).ToList();

            //loop by vessel
            var entities = new List<VesselProperties>();

            foreach (var v in entity)
            {
                var e = new VesselProperties();
                var p = props.Where(c => c.LCTReferenceId == v.Id).FirstOrDefault();

                //new vessel from LCT
                if (p == null)
                {
                    e.Id = Guid.NewGuid();
                    e.LCTReferenceId = v.Id;
                    e.Name = v.Name;
                    e.StatusReferenceId = v.StatusId;
                    e.Status = v.Status;
                    e.StatusReferenceId = v.StatusId;


                    // e.Type = v.Type;

                    //logic with on of hire
                    //e.IsIncludeToCalculate = e.StatusReferenceId == 1 ? true : false;
                    e.IsETAUpdated = false;
                }
                //default from VOT
                else
                {
                    e = p;
                    e.Name = v.Name;
                    e.Status = v.Status;
                    e.StatusReferenceId = v.StatusId;
                    // e.Type = v.TypeId;

                    //eta
                    //int lct_id = e.LCTReferenceId.GetValueOrDefault();
                    /*var eta = await this.EstimateTimeArrivedAsync(v.Id);
                    if (eta != null)
                    {
                        e.LCTReferenceETADate = eta.ETA;
                        e.ETADate = eta.ETA;
                    }

                    //get is updated ETA
                    e.IsETAUpdated = e.ETADate != e.LCTReferenceETADate ? true : false;*/
                }

                //set type display
                VesselType foo = (VesselType)Enum.ToObject(typeof(VesselType), v.TypeId);
                e.Type = foo.GetDescription();

                //check box flag
                //utitlity
                if (v.TypeId == (int)VesselType.UTILITY)
                {
                    e.IsIncludeToCalculate = false;
                }
                else
                {
                    //ahts
                    if (e.StatusReferenceId == (int)VesselStatus.OFFHIRE)
                    {
                        e.IsIncludeToCalculate = false;
                    }
                    else
                    {
                        e.IsIncludeToCalculate = true;

                    }
                }


                //location
                var l = location.Where(c => c.Id == e.BaseLocationReferenceId).FirstOrDefault();
                if (l != null)
                {
                    e.BaseLocationName = l.Code;
                }

                entities.Add(e);
            }

            //estimate arrival time
            var arrivals = await this.EstimateTimeArrivedAsync(entities);


            //custom order
            string[] CARGO_TYPE = { "AHTS", "Utility" };
            entities = arrivals.OrderBy(c => Array.IndexOf(CARGO_TYPE, c.Type)).ThenBy(c => c.Name).ToList();

            return entities;
        }


        //
        // Summary:
        //     retrun a list of vessel ETA
        //
        // Returns:
        //
        //   model of VesselArrived
        //
        // Params :
        // vessel vessel props with base location
        //
        /*public async Task<VesselArrived> EstimateTimeArrivedAsync(VesselProperties vessel)//IEnumerable<VesselProperties> propserties)
        {
            var entities = await this.ListCurrentRouteAsync();

            var q = entities.Where(c => ((c.LctReferenceIsActual == true && c.LctReferenceIsCurrent == true && c.StatusId == (int)VesselRouteStatus.ACTIVE) ||
                                              (c.LctReferenceIsActual == true && c.LctReferenceIsCurrent == false && c.StatusId == (int)VesselRouteStatus.DAILY_CONFIRMED))
                                              && c.LctReferenceIsDeletedd == false).OrderByDescending(c => c.ETA);

            //  var entities = new List<VesselArrived>();
            var currentPlan = q.Where(c => c.VesselId == vessel.LCTReferenceId && c.ToId == vessel.BaseLocationReferenceId).FirstOrDefault();
            var entity = new VesselArrived
            {
                //Id = v.VesselId,
                LCTReferenceId = (int)vessel.LCTReferenceId,
                //BaseLocationReferenceId = (int)v.BaseLocationReferenceId.GetValueOrDefault(),
                ETA = currentPlan == null ? null : (currentPlan.ETA),

            };

            return entity;
        }*/



        //
        // Summary:
        //     retrun a n arival time at jetty
        //
        // Returns:
        //
        //   vessel eta model
        // props :
        //   vessel props (require only lct id)
        //
        //
        public async Task<IEnumerable<VesselProperties>> EstimateTimeArrivedAsync(IEnumerable<VesselProperties> props)
        {

            var currents = await _clientService.ListVesselCurrentPlanAsync();
            if (!currents.Any())
            {
                throw new VesselNotFoundException();
            }

            //group and get first
            var entities = currents.OrderBy(o => o.VesselId).OrderByDescending(o => o.RouteStatusId).GroupBy(g => new
            {
                g.VesselId,
                g.SequenceNumber

            }).Select(s => new
            {
                VesselId = s.First().VesselId,

                Eta = s.First().UpdatedETA == null ? s.First().Eta : s.First().UpdatedETA,

                RouteStatusId = s.First().RouteStatusId,
                LctReferenceIsActual = s.First().IsActual,
                LctReferenceIsCurrent = s.First().IsCurrent,
                LocationStatus = s.First().LocationStatus,
                LctReferenceIsDeleted = s.First().IsDeleted,

            });

            //focus on ETA
            entities = entities.Where(c => ((c.LctReferenceIsActual == true && c.LctReferenceIsCurrent == true && c.RouteStatusId == (int)VesselRouteStatus.ACTIVE) ||
                                                 (c.LctReferenceIsActual == true && c.LctReferenceIsCurrent == false && c.RouteStatusId == (int)VesselRouteStatus.DAILY_CONFIRMED))
                                                 && c.LctReferenceIsDeleted == false).OrderByDescending(c => c.Eta);

            var result = new List<VesselProperties>();
            foreach (var p in props)
            {
                var plan = entities.Where(c => c.VesselId == p.LCTReferenceId).FirstOrDefault();
                p.ETADate = plan == null ? null : (plan.Eta);

                result.Add(p);
            }

            return result;
        }


        //
        // Summary:
        //     retrun a vessel info tab (cuurently dont have any additional information)
        //
        // Returns:
        //
        //   vessel info model
        // id :
        //   planned id
        //
        //
        public async Task<PlanVessel> GetPlanVesselAsync(Guid id)
        {

            //get plan to determine is defaultplan ???
            var plan = await _planService.GetPlanAsync(id);
            if (plan == null)
            {
                throw new PlanNotFoundException();
            }

            var entity = await _planVesselRepository.GetByPlanIdAsync(plan.Id);
            if (entity == null)
            {
                throw new VesselNotFoundException();
            }

            // var vessel = entity.Where(c => c.PlanId == id
            //                          && c.RecordStatus == RecordStatus.ACTIVE.GetDescription()).FirstOrDefault();

            //synce if default plan
            if (plan.ConfigurationType == ConfigurationType.DEFAULT.GetDescription())
            {
                var query = await this.SyncePropertiesAsync(entity.Id);
                entity.Properties = query.ToList();
            }
            else
            {
                var query = await this.ListPropertiesAsync(entity.Id);
                entity.Properties = query.ToList();
            }

            //synce some required spec (not persist on VOT)
            var vessels = await _clientService.ListVesselAsync();
            //var specifications = await _clientService.ListVesselSpecificationAsync();
            var tanks = await this.ListVesselTanksAsync();
            //var mapped = _mapper.Map<List<Vessel>>(entity);

            //set required  fiedl
            entity.Properties = entity.Properties.Select(c =>
            {
                //deck spacae area
                /*var s = specifications.Where(x => x.VesselId == c.LCTReferenceId).FirstOrDefault();
                if (s != null)
                {
                   // c.NormalSpeed = s.NormalSpeed;
                   c.DeckSpaceLimit = s.EffectiveDeckSpace;
                   c.DeadWeightLimit = s.EffectiveDeadWeight;
                   c.DeckSpaceArea = s.EffectiveDeckSpace;
                };*/

                //tank
                var t = tanks.Where(cx => cx.VesselId == c.LCTReferenceId).FirstOrDefault();
                if (t != null)
                {
                    //for validate
                    //c.Tank = t;

                    c.DieselTankCapacity = t.DieselTankCapacity.GetValueOrDefault();
                }

                //speed
                var v = vessels.Where(cv => cv.Id == c.LCTReferenceId).FirstOrDefault();
                if (v != null)
                {
                    c.NormalSpeed = v.Speed;
                    if (v.Specfication != null)
                    {
                        c.DeckSpaceLimit = v.Specfication.EffectiveDeckSpace;
                        c.DeadWeightLimit = v.Specfication.EffectiveDeadWeight;
                        c.DeckSpaceArea = v.Specfication.EffectiveDeckSpace;
                    }
                }

                return c;
            }).ToList();

            return entity;
        }


        //
        // Summary:
        //     retrun a list of vessel with blockout time and cluster
        //
        // Returns:
        //
        //   gateway of vessel blockout
        //
        //
        /* public async Task<IEnumerable<VesselBlockout>> ListCurrentBlockoutAsync()
        {
            var locations = await _locationService.ListAsync();
            if (locations == null)
            {
                throw new LocationNotFoundException();
            }

            var blocks = await _vesselBlockoutRepository.ListAsync();
            if (blocks == null)
            {
                throw new LocationNotFoundException();
            }

            ///active only
            // blocks = blocks.Where(c => c.RecordStatus == RecordStatus.ACTIVE.GetDescription());

            var entities = new List<VesselBlockout>();
            foreach (var b in blocks)
            {
                //get location 
                var s = locations.Where(c => c.Code == b.StartLocationCode).FirstOrDefault();
                if (s != null)
                {
                    b.StartLocationCode = s.Code;
                }

                var e = locations.Where(c => c.Code == b.EndLocationCode).FirstOrDefault();
                if (e != null)
                {
                    b.EndLocationCode = e.Code;
                }

                //force blockout time at 06:00:00
                var ts = new TimeSpan(6, 0, 0);
                b.StartDate = b.StartDate.GetValueOrDefault().GetDateZeroTime().Add(ts);
                b.EndDate = b.EndDate.GetValueOrDefault().AddDays(1).GetDateZeroTime().Add(ts);

                entities.Add(b);
            }

            return entities;
        }*/


        public async Task<Vessel> EnforceVesselExistenceAsync(Guid id)
        {
            var entity = await _vesselRepository.GetAsync(id);
            if (entity == null)
            {
                throw new VesselNotFoundException();
            }

            return entity;
        }


        public async Task<VesselProperties> EnforcePropertiesExistenceAsync(Guid id)
        {
            var entity = await _propsertiesRepository.GetAsync(id);
            if (entity == null)
            {
                throw new VesselNotFoundException();
            }

            return entity;
        }



        //
        // Summary:
        //     retrun effective deck width of vessel
        //
        // Returns:
        //
        //    Vessel model
        //
        // Type parameters:
        //   id:
        //     vessel id
        //
        public async Task<Vessel> CalculateEffectiveSpaceAsync(decimal deckwidth, decimal deadWeightLimit, decimal dieselTankCapacity)
        {
            await Task.Delay(0);

            //  const decimal EFFECTIVE_DECK_PERCENTAGE = 80;
            const decimal EFFECTIVE_DECK_CONSTANT = 0.5m;
            const decimal DIESEL_WEIGHT_IN_TONS = 0.823m;

            //set
            var vessel = new Vessel();
            vessel.EffectiveDeckWidth = deckwidth - EFFECTIVE_DECK_CONSTANT; //* (EFFECTIVE_DECK_PERCENTAGE / 100);

            var dead = deadWeightLimit - (dieselTankCapacity * DIESEL_WEIGHT_IN_TONS);

            //change to KGs
            vessel.EffectiveDeadWeightLimit = dead * 1000;

            return vessel;
        }



        //
        // Summary:
        //     retrun desiel consumtion of vessel
        //
        // Returns:
        //
        //    Vessel model
        //
        // Type parameters:
        //   activities:
        //     list of vessel activity 
        //
        private async Task<IEnumerable<VesselActivity>> CalculateFuelConsumtionAsync(IEnumerable<VesselActivity> activities, PlanResource resource)
        {
            //await Task.Delay(0);
            var entities = new List<VesselActivity>();
            foreach (var v in activities)
            {
                var entity = await this.CalculateFuelConsumtionAsync(v, resource);
                entities.Add(entity);
            }

            return entities;
        }


        public async Task<VesselActivity> CalculateFuelConsumtionAsync(VesselActivity activity, PlanResource resource)
        {
            await Task.Delay(0);

            var entity = VESSEL.ACTIVITY[activity.ActivityId];
            if (entity == null)
            {
                throw new VesselActivityNotFoundException();
            }

            var fuelConsumtionRate = 0m;

            switch (entity.FuelConsumtionRateType)
            {
                //move to enum
                case "UNDERWAY (VOYAGE)":
                    fuelConsumtionRate = resource.UnderwayVoyageRate.GetValueOrDefault();
                    break;
                case "BERTH AT JETTY":
                    fuelConsumtionRate = resource.BerthAtJettyRate.GetValueOrDefault();
                    break;
                case "ANCHOR HANDLING":
                    fuelConsumtionRate = resource.AnchorHandlingTowingRate.GetValueOrDefault();
                    break;
                default:
                    break;
            }


            var value = activity.TimeDuration.TotalHours * Convert.ToDouble(fuelConsumtionRate);   //qubic metres per hours
            activity.FuelConsumtionValue = value;

            //for dev check
            activity.Name = entity.Name;
            activity.FuelConsumtionRate = entity.FuelConsumtionRate;

            return activity;
        }

        //
        // Summary:
        //     retrun a visit tanker flag
        //
        // Returns:
        //
        //    vessel model
        //
        // Type parameters:
        //   vessel:
        //     vessel id  << important !!
        //
        private async Task<VesselDepartureParams> IsVisitTanker(VesselDepartureParams vessel, PlanResource resource)
        {
            //set value
            if (vessel.BasePort.LocationCode.ToLower() != VESSEL.SAT_BURKERING_LOCATION_CODE.ToLower())
            {
                vessel.IsVisitTanker = false;
                var diesel = vessel.DieselETD;

                //check blocout
                //check vessel id with blockout
                var etdstart = vessel.ETDDate.GetValueOrDefault();
                var etdend = etdstart.AddDays((double)resource.RouteTurnaround);

                var blocks = await this.ListBookActivitiesAysnc(etdstart, etdend);

                var b = blocks.Where(c => c.VesseId == vessel.LCTReferenceId).FirstOrDefault();
                if (b != null)
                {
                    // blocout
                    var tanker = vessel.Specification.DieselTankCapacity * ((decimal)resource.MinimumBlockROBPercentage / 100);
                    if (diesel < resource.MinimumBlockROB || diesel < tanker)
                    {
                        vessel.IsVisitTanker = true;
                    }

                }
                else
                {

                    //with without activity
                    var tanker = vessel.Specification.DieselTankCapacity * ((decimal)resource.MinimumTripROBPercentage / 100);
                    if (diesel < tanker)
                    {
                        vessel.IsVisitTanker = true;
                    }

                }

            }
            else
            { /*not implement*/ }

            return vessel;
        }


        //
        // Summary:
        //     retrun and etd time of vessel 
        //
        // Returns:
        //
        //   gateway of Vessel model
        //
        // Type parameters:
        //   id:
        //     vessel id
        //

        public async Task<IEnumerable<VesselDepartureParams>> EstimateTimeDepartureAsync(VesselDepartureRequestParams param)
        {
            var vessels = await _clientService.ListVesselAsync();
            var tanks = await this.ListVesselTanksAsync();

            var entities = new List<VesselDepartureParams>();

            var ids = param.PlanId;

            var terminals = await _locationService.ListTerminalAsync();
            var locations = await _locationsRepository.GetByPlanIdAsync(ids);

            IEnumerable<LocationState> restricts = new List<LocationState>();
            if (locations != null)
                restricts = await _locationService.ListRestrictedHourAsync(locations.Id);

            var specs = await _vesselInfoRepository.GetByPlanIdAsync(ids);
            var props = await this.ListPropertiesAsync(specs.Id);

            var resource = await _planResourceRepository.GetByPlanAsync(ids);


            // ??? what a logic
            var startDate = param.VesselArrivals.Min(c => c.ETA);
            var endDate = startDate.Value.AddDays(VESSEL.MAX_VALIDATE_BLOCKOUT_DAYS);
            startDate = startDate.Value.AddDays(-1 * (double)(resource.RouteTurnaround));

            var blocks = await this.ListBookActivitiesAysnc(startDate.Value, endDate);
            //var param = param.Vessels;
            //sortt by eta date
            //var query = await _vesselArrivedRepository.ListArrivedAsync();
            //var hastable = new HashSet<Guid>(param.Select(c => c.Id));

            if (param.VesselArrivals == null)
            {
                throw new VesselNotFoundException("No input param arrival");
            }

            var query = param.VesselArrivals.OrderBy(c => c.ETA);

            //
            //PM blockout loop
            //
            foreach (var v in query)
            {
                var vp = props.Where(c => c.LCTReferenceId == v.LCTReferenceId).FirstOrDefault();
                if (vp == null)
                {
                    throw new VesselNotFoundException($"Could not find vessel {v.VesselId } {v.VesselName} in configuration plan");
                }

                var vv = vessels.Where(c => c.Id == v.LCTReferenceId).FirstOrDefault();
                if (vv == null)
                {
                    throw new VesselNotFoundException($"Could not find vessel {v.VesselId } {v.VesselName}");
                }

                var tt = tanks.Where(t => t.VesselId == v.LCTReferenceId).FirstOrDefault();
                if (tt == null)
                {
                    throw new VesselNotFoundException($"Could not find vessel tank {v.VesselId } {v.VesselName}");
                }

                var current = new VesselDepartureParams();

                //reset
                current.ETDTimspanHours = new TimeSpan();

                //current
                current.Id = v.VesselId;
                current.Name = v.VesselName;
                current.BaseLocationId = v.BaseLocationId;
                current.BaseLocationReferenceId = v.BaseLocationReferenceId;
                current.LCTReferenceId = v.LCTReferenceId;


                current.Status = vv.Status;
                current.Type = vv.Type;
                current.Name = vv.Name;

                //assigned eta
                current.ETA = v;
                current.ETADate = v.ETA;

                //buffer ETA for dev check
                current.LCTReferenceETADate = v.ETA;

                //get space compute
                var space = await this.CalculateEffectiveSpaceAsync((decimal)vp.DeckWidth.GetValueOrDefault(), (decimal)vv.Specfication.EffectiveDeadWeight.GetValueOrDefault(), (decimal)vv.Specfication.DieselTankCapacity.GetValueOrDefault());
                current.EffectiveDeadWeightLimit = space.EffectiveDeadWeightLimit;
                current.EffectiveDeckWidth = space.EffectiveDeckWidth;

                //Add specification from VOT
                current.Specification.TabularHeightLimit = vp.TabularHeightLimitPerside;
                current.Specification.TabularWeightLimitPerSide = vp.TabularWeightLimitPerside;
                current.Specification.TabularSpaceLimitPerSide = vp.TabularSpaceLimitPerside;
                current.Specification.DeckWidth = vp.DeckWidth;
                //Add specification from LCT
                current.Specification.DeadWeightLimit = vv.Specfication.EffectiveDeadWeight;
                current.Specification.DeckSpaceLimit = vv.Specfication.EffectiveDeckSpace;
                current.Specification.PotWater = tt.EffectivePotWater;
                current.Specification.DrillWater = tt.EffectiveDrillWater;
                current.Specification.Speed = Convert.ToDecimal(vv.Speed);
                current.Specification.MaxSpeed = vv.MaxSpeed;
                current.Specification.DieselTankCapacity = vp.DieselTankCapacity; //vv.Specfication.DieselTankCapacity;
                //Barite
                current.Specification.Barite = tt.Barite;
                current.Specification.BaritePerTank = tt.BaritePerTank;
                current.Specification.BariteTank = tt.BariteTank;
                //BHI Cement
                current.Specification.BhiCement = tt.BhiCement;
                current.Specification.BhiCementPerTank = tt.BhiCementPerTank;
                current.Specification.BhiCementTank = tt.BhiCementTank;
                //H Cement
                current.Specification.HCement = tt.HCement;
                current.Specification.HCementPerTank = tt.HCementPerTank;
                current.Specification.HCementTank = tt.HCementTank;
                //Saraline
                current.Specification.SaralineTank = tt.SaralineTank;
                current.Specification.Saraline = tt.Saraline;


                current.Specification.TabularSpaceLimit = (Convert.ToDecimal(current.Specification.DeckWidth) - VESSEL.DECK_SIDE) * VESSEL.TUBULAR_EFFECTIVE_DECK_LENGTH;

                //check port --location state
                var port = restricts.Where(c => c.LCTReferenceId == vp.BaseLocationReferenceId).FirstOrDefault();

                //cal port waiting time arrived
                var idle = new TimeSpan();
                if (port != null)
                {
                    current.BasePort = port;

                    var arrivedate = current.ETADate.GetValueOrDefault();

                    if (arrivedate.TimeOfDay >= port.RestrictedTimeStart && arrivedate.TimeOfDay < port.RestrictedTimeEnd)
                    {
                        idle = port.RestrictedTimeEnd.GetValueOrDefault().Subtract(arrivedate.TimeOfDay);

                        //collect blocking activity
                        current.BlockingActivity.Add(new VesselActivity
                        {
                            Id = Guid.NewGuid(),
                            ActivityId = (int)VesselBookType.IDLE,
                            TimeDuration = idle,
                            Description = "Arrived",
                            BlockedType = VesselBookType.IDLE.GetDescription(),
                            Start = arrivedate,
                            End = arrivedate.Add(idle),
                            VesselLCTReferenceId = v.LCTReferenceId,
                            TripNo = param.TripNo
                        });
                    }
                }
                else
                {
                    //no bas port set own is base
                    current.BasePort = new LocationState
                    {
                        RestrictedTimeStart = new TimeSpan(),
                        RestrictedTimeEnd = new TimeSpan(),
                        LocationCode = vp.BaseLocationName,
                        LCTReferenceId = vp.BaseLocationReferenceId
                    };
                }

                current.ETDTimspanHours = current.ETDTimspanHours + idle;

                //check vessel id with block PM
                var etastart = current.ETADate.GetValueOrDefault().Add(current.ETDTimspanHours);
                var etaend = etastart.AddDays((double)resource.RouteTurnaround);

                var pm = blocks.Where(c => c.VesseId == current.LCTReferenceId && c.Type == (int)VesselBookType.MAINTENANCE
                                                    && ((c.StartDate >= etastart && c.StartDate <= etaend) || (c.EndDate >= etastart && c.EndDate <= etaend))
                                                    ).FirstOrDefault();
                if (pm != null)
                {
                    //cal blockout time    
                    current.ETDTimspanHours = current.ETDTimspanHours + TimeSpan.FromHours((double)resource.ServiceTimePM);

                    var maintenance = TimeSpan.FromHours((double)resource.ServiceTimePM);

                    //collect blocking activity
                    // current.BlockingActivity.Add(new VesselActivity { ActivityId = (int)VesselBookType.MAINTENANCE, TimeDuration = maintenance, Description = "PM", BlockedType = VesselBookType.MAINTENANCE.GetDescription() }); ;

                    current.BlockingActivity.Add(new VesselActivity
                    {
                        Id = Guid.NewGuid(),
                        ActivityId = (int)VesselBookType.MAINTENANCE,
                        TimeDuration = maintenance,
                        Description = "PM",
                        BlockedType = VesselBookType.MAINTENANCE.GetDescription(),
                        Start = etastart,
                        End = etastart.Add(maintenance),
                        VesselLCTReferenceId = v.LCTReferenceId,
                        TripNo = param.TripNo
                    });

                }

                ///cal new  ETA
                current.ETADate = current.ETADate.GetValueOrDefault().Add(current.ETDTimspanHours);

                //set blockout
                current.PM = pm;

                //swap value
                //previous = current;
                entities.Add(current);
            }


            /******************** */
            //
            // bunkering
            //
            for (int i = 0; i < entities.Count; i++)/// pm for all   
            {
                var current = entities.ElementAt(i);
                var eta = current.ETA;

                //reset
                current.ETDTimspanHours = new TimeSpan();

                var port = current.BasePort;
                var arrivedate = current.ETADate.GetValueOrDefault(); //.Add(Convert.ToDouble(current.ETDTimspanHours));
                                                                      //cal port waiting time arrived
                var idle = new TimeSpan();
                if (arrivedate.TimeOfDay >= port.RestrictedTimeStart && arrivedate.TimeOfDay < port.RestrictedTimeEnd)
                {
                    idle = port.RestrictedTimeEnd.GetValueOrDefault().Subtract(arrivedate.TimeOfDay);

                    //collect blocking activity
                    // current.BlockingActivity.Add(new VesselActivity { ActivityId = (int)VesselBookType.IDLE, TimeDuration = idle, Description = "Arrived", BlockedType = VesselBookType.IDLE.GetDescription() });

                    current.BlockingActivity.Add(new VesselActivity
                    {
                        Id = Guid.NewGuid(),
                        ActivityId = (int)VesselBookType.IDLE,
                        TimeDuration = idle,
                        Description = "Arrived",
                        BlockedType = VesselBookType.IDLE.GetDescription(),
                        Start = arrivedate,
                        End = arrivedate.Add(idle),
                        VesselLCTReferenceId = current.LCTReferenceId,
                        TripNo = param.TripNo
                    });

                }

                current.ETDTimspanHours = current.ETDTimspanHours + idle;

                try
                {
                    //berkering
                    if (current.BasePort.LocationCode.ToLower() == VESSEL.SAT_BURKERING_LOCATION_CODE.ToLower())
                    {
                        //burkering time
                        if (eta.DieselROB < current.Specification.DieselTankCapacity * ((decimal)resource.MinimumRefillROB / 100))
                        {
                            var bunker_start = arrivedate.Add(current.ETDTimspanHours);

                            current.ETDTimspanHours = current.ETDTimspanHours + TimeSpan.FromHours((double)resource.ServiceTimeTank);
                            current.IsVisitTanker = false;

                            var bkr = TimeSpan.FromHours((double)resource.ServiceTimeTank);

                            //collect blocking activity
                            //current.BlockingActivity.Add(new VesselActivity { ActivityId = (int)VesselBookType.PORT_BUNKERING, TimeDuration = bkr, Description = "Bunkering", BlockedType = VesselBookType.PORT_BUNKERING.GetDescription() });
                            current.BlockingActivity.Add(new VesselActivity
                            {
                                Id = Guid.NewGuid(),
                                ActivityId = (int)VesselBookType.PORT_BUNKERING,
                                TimeDuration = bkr,
                                Description = "Bunkering",
                                BlockedType = VesselBookType.PORT_BUNKERING.GetDescription(),
                                Start = bunker_start,
                                End = bunker_start.Add(bkr),
                                VesselLCTReferenceId = current.LCTReferenceId,
                                TripNo = param.TripNo
                            });


                        }
                    }
                }
                catch (NullReferenceException)
                {
                    throw new VesselNotValidException();
                }


                ///cal new  ETA
                current.ETADate = current.ETADate.GetValueOrDefault().Add(current.ETDTimspanHours);

                entities[i] = current;
            }

            /******************** */

            //sort by ETAdate
            entities = entities.OrderBy(c => c.ETADate).ToList();

            //
            //loading loop
            //
            var queues = new Dictionary<int, Queue<VesselDepartureParams>>();

            for (int i = 0; i < entities.Count; i++)/// pm for all
            {
                var current = entities[i];
                //reset
                current.ETDTimspanHours = new TimeSpan();

                //init queue with base location
                Queue<VesselDepartureParams> queue;
                if (!queues.TryGetValue(current.BaseLocationReferenceId, out queue))
                {
                    queue = new Queue<VesselDepartureParams>();
                    //queues.Add(current.BaseLocationId, queue);
                }
                else
                {
                    queues.Remove(current.BaseLocationReferenceId);
                }

                var port = current.BasePort;
                var arrivedate = current.ETADate.GetValueOrDefault(); //.Add(Convert.ToDouble(current.ETDTimspanHours));
                                                                      //cal port waiting time arrived
                var idle = new TimeSpan();
                if (arrivedate.TimeOfDay >= port.RestrictedTimeStart && arrivedate.TimeOfDay < port.RestrictedTimeEnd)
                {
                    idle = port.RestrictedTimeEnd.GetValueOrDefault().Subtract(arrivedate.TimeOfDay);

                    //collect blocking activity
                    //current.BlockingActivity.Add(new VesselActivity { ActivityId = (int)VesselBookType.IDLE, TimeDuration = idle, Description = "Arrived", BlockedType = VesselBookType.IDLE.GetDescription() });

                    current.BlockingActivity.Add(new VesselActivity
                    {
                        Id = Guid.NewGuid(),
                        ActivityId = (int)VesselBookType.IDLE,
                        TimeDuration = idle,
                        Description = "Arrived",
                        BlockedType = VesselBookType.IDLE.GetDescription(),
                        Start = arrivedate,
                        End = arrivedate.Add(idle),
                        VesselLCTReferenceId = current.LCTReferenceId,
                        TripNo = param.TripNo
                    });

                }

                current.ETDTimspanHours = current.ETDTimspanHours + idle;

                //shift overlapping with previouse, check base location id
                var prev = new VesselDepartureParams();
                if (queue.Count() == locations.JettyAvailable)
                {
                    try
                    {
                        prev = queue.Dequeue();
                    }
                    catch (InvalidOperationException)
                    { }
                }

                //??? required update ETA before ???
                var current_date = current.ETADate.GetValueOrDefault(); //current.ETADate.GetValueOrDefault().Add(current.ETDTimspanHours);

                idle = new TimeSpan();
                if (current.BaseLocationReferenceId == prev.BaseLocationReferenceId && current_date <= prev.ETDDate)
                {
                    var queue_start = arrivedate.Add(current.ETDTimspanHours);

                    idle = prev.ETDDate.GetValueOrDefault().Subtract(current_date);

                    current.PreviousQueue = prev;

                    //collect blocking activity
                    //current.BlockingActivity.Add(new VesselActivity { ActivityId = (int)VesselBookType.IDLE, TimeDuration = idle, Description = "Queue", BlockedType = VesselBookType.IDLE.GetDescription() });

                    current.BlockingActivity.Add(new VesselActivity
                    {
                        Id = Guid.NewGuid(),
                        ActivityId = (int)VesselBookType.IDLE,
                        TimeDuration = idle,
                        Description = "Queue",
                        BlockedType = VesselBookType.QUEUE.GetDescription(),
                        Start = queue_start,
                        End = queue_start.Add(idle),
                        VesselLCTReferenceId = current.LCTReferenceId,
                        TripNo = param.TripNo
                    });

                }

                queue.Enqueue(current);
                current.ETDTimspanHours = current.ETDTimspanHours + idle;

                //add to dictionary
                queues.Add(current.BaseLocationReferenceId, queue);

                var ld = TimeSpan.FromHours((double)resource.ServiceTimePort);

                var load_date = current.ETADate.GetValueOrDefault().Add(current.ETDTimspanHours);

                //loading time
                current.ETDTimspanHours = current.ETDTimspanHours + TimeSpan.FromHours((double)resource.ServiceTimePort);
                //  current.BlockingActivity.Add(new VesselActivity { ActivityId = (int)VesselBookType.LOADING, TimeDuration = ld, Description = "Loading", BlockedType = VesselBookType.LOADING.GetDescription() });

                current.BlockingActivity.Add(new VesselActivity
                {
                    Id = Guid.NewGuid(),
                    ActivityId = (int)VesselBookType.LOADING,
                    TimeDuration = ld,
                    Description = "Loading",
                    BlockedType = VesselBookType.LOADING.GetDescription(),
                    Start = load_date,
                    End = load_date.Add(ld),
                    VesselLCTReferenceId = current.LCTReferenceId,
                    TripNo = param.TripNo
                });

                //cal departure
                var depart_date = current.ETADate.GetValueOrDefault().Add(current.ETDTimspanHours);

                idle = new TimeSpan();
                if (depart_date.TimeOfDay >= port.RestrictedTimeStart && depart_date.TimeOfDay < port.RestrictedTimeEnd)
                {
                    idle = port.RestrictedTimeEnd.GetValueOrDefault().Subtract(depart_date.TimeOfDay);

                    //collect blocking activity
                    //current.BlockingActivity.Add(new VesselActivity { ActivityId = (int)VesselBookType.IDLE, TimeDuration = idle, Description = "Departure", BlockedType = VesselBookType.IDLE.GetDescription() });

                    current.BlockingActivity.Add(new VesselActivity
                    {
                        Id = Guid.NewGuid(),
                        ActivityId = (int)VesselBookType.IDLE,
                        TimeDuration = idle,
                        Description = "Departure",
                        BlockedType = VesselBookType.IDLE.GetDescription(),
                        Start = depart_date,
                        End = depart_date.Add(idle),
                        VesselLCTReferenceId = current.LCTReferenceId,
                        TripNo = param.TripNo
                    });

                }

                current.ETDTimspanHours = current.ETDTimspanHours + idle;

                //cal etd date
                current.ETDDate = current.ETADate.GetValueOrDefault().Add(current.ETDTimspanHours);

                //add to list
                entities[i] = current;
            }


            /******************** */

            //calculate fueled consumtion from blockout ETD and visit tanker
            for (int i = 0; i < entities.Count; i++)/// pm for all   
            {
                var current = entities.ElementAt(i);
                //reset
                // current.ETDTimspanHours = new TimeSpan();


                var temp = await this.CalculateFuelConsumtionAsync(current.BlockingActivity, resource);
                current.BlockingActivity = temp.ToList();


                var eta = query.Where(c => c.LCTReferenceId == current.LCTReferenceId).FirstOrDefault();
                if (eta == null)
                {
                    throw new VesselETANotFoundException(current.Id);
                }


                //bunkering at SAT
                var bunker = temp.Where(c => c.BlockedType == VesselBookType.PORT_BUNKERING.GetDescription()).FirstOrDefault();
                if (bunker != null)
                {
                    eta.DieselROB = eta.DieselROB + VESSEL.ADDITION_DIESEL_SAT_BUNKERING;
                }

                // deiselETD = ieselRob - total 
                current.DieselETD = eta.DieselROB - Convert.ToDecimal(temp.Sum(c => c.FuelConsumtionValue));

                //finde desiel blocking
                var etdstart = current.ETDDate.GetValueOrDefault();
                var etdend = etdstart.AddDays(Convert.ToDouble(resource.RouteTurnaround));//etdstart.AddHours(VESSEL.ETA_BLOCK_HRS);

                var blocking = blocks.Where(c => c.VesseId == current.LCTReferenceId
                                            && (c.StartDate >= etdstart && c.StartDate <= etdend)).FirstOrDefault();
                if (blocking != null)
                {
                    current.Blockout = blocking;

                    current.BlockStartLocationCode = blocking.StartLocationCode;
                    current.BlockEndLocationCode = blocking.EndLocationCode;

                    current.BlockStartDate = blocking.StartDate;
                    current.BlockEndDate = blocking.EndDate;

                    //deisel blcoking
                    var ts = blocking.EndDate.GetValueOrDefault().Subtract(blocking.StartDate.GetValueOrDefault());
                    var activity = new VesselActivity() { ActivityId = blocking.Type, TimeDuration = ts };
                    var t = await this.CalculateFuelConsumtionAsync(activity, resource);

                    current.BlockoutDiesel = t.FuelConsumtionValue;

                    //set field for datascience


                }

                //get visit tank
                var tank = await this.IsVisitTanker(current, resource);
                current.IsVisitTanker = tank.IsVisitTanker;

                //roll eta date back
                current.ETADate = current.LCTReferenceETADate;
                entities[i] = current;
            }

            return entities;
        }

        public async Task<IEnumerable<VesselBookActivity>> ListBookActivitiesAysnc(DateTime start, DateTime end)
        {
            const int ACTIVITY_CLOSING_SCHEDULE_IN_HOURS = 6;
            const int ACTIVITY_CLOSING_SCHEDULE_IN_DAYS = 1;

            var entity = await _clientService.ListBookActivityAsync(start, end);
            var vessels = await _clientService.ListVesselAsync();
            var locations = await _clientService.ListLocationAsync();

            //removed isDeleted
            entity = entity.Where(c => c.IsDeleted != true);

            var riggs = entity.Where(c => c.VesselId == null);
            var activities = entity.Where(c => c.VesselId != null);

            var entities = new List<VesselBookActivity>();

            foreach (var activity in activities)
            {
                if (activity.VesselId == null) continue;

                if (activity.ActivityTypeId == null) continue;

                var vessel = vessels.Where(c => c.Id == activity.VesselId).FirstOrDefault();

                var booked = new VesselBookActivity
                {
                    BookActivityId = activity.BookedActivityId,
                    VesseId = (int)activity.VesselId.GetValueOrDefault(),
                    VesselName = (vessel != null ? vessel.Name : activity.VesselName),
                    ActivityTypeId = activity.ActivityTypeId,

                    //update start / end from LCT
                    StartDate = activity.StartDate.Value.Date.AddHours(ACTIVITY_CLOSING_SCHEDULE_IN_HOURS),
                    EndDate = activity.EndDate.Value.Date.AddDays(ACTIVITY_CLOSING_SCHEDULE_IN_DAYS).AddHours(ACTIVITY_CLOSING_SCHEDULE_IN_HOURS),

                    Description = activity.ActivityDescription,
                    Info = activity.ActivityInfo,
                    LocationId = (int)activity.DORPlatformId.GetValueOrDefault(),
                    RigId = activity.RigId,
                    //  Type = this.GetActivityTypeAsync(activity.ActivityType),

                    ActivityType = activity.ActivityType
                };

                //mapping type
                var value = (int)VesselBookType.OTHER;
                if (VESSEL.LCT_VESSEL_ACTIVITY_REQUESTS.TryGetValue(activity.ActivityTypeId.GetValueOrDefault(), out value))
                {
                    booked.Type = value;
                }

                //next
                if (booked.Type == (int)VesselBookType.OTHER) continue;

                //process
                if (booked.Type == (int)VesselBookType.RIGMOVE)
                {
                    var subActivity = riggs.Where(c => c.BookedActivityId == activity.RigMoveId).FirstOrDefault();

                    if (subActivity != null && !string.IsNullOrEmpty(subActivity.ActivityDetails))
                    {
                        var rigCodes = subActivity.ActivityDetails.Replace(" ", "").Split("-");
                        if (rigCodes.Length == 2)
                        {
                            booked.RigMoveStartLocCode = rigCodes[0];
                            booked.RigMoveEndLocCode = rigCodes[1];
                            booked.StartLocationCode = booked.RigMoveStartLocCode;
                            booked.EndLocationCode = booked.RigMoveEndLocCode;
                        }

                        booked.RigMoveStartDate = subActivity.StartDate;
                        booked.RigMoveEndDate = subActivity.EndDate;
                    }

                }
                else if (activity.DORPlatformId != null && activity.DORPlatformId != 0)
                {
                    var block = locations.Where(c => c.Id == activity.DORPlatformId).FirstOrDefault();
                    booked.StartLocationCode = block.Code;
                    booked.EndLocationCode = block.Code;
                }

                entities.Add(booked);
            }

            return entities;
        }

        public async Task<IEnumerable<VesselTank>> ListVesselTanksAsync()
        {
            var vessels = await _clientService.ListVesselAsync();
            var entities = vessels.Where(c => c.Specfication != null).Select(s => new VesselTank
            {
                VesselId = s.Specfication.VesselId,
                Barite = s.Specfication.Barite,
                BaritePerTank = s.Specfication.BaritePerTank,
                BariteTank = s.Specfication.BariteTank,
                BhiCement = s.Specfication.BhiCement,
                BhiCementPerTank = s.Specfication.BhiCementPerTank,
                BhiCementTank = s.Specfication.BhiCementTank,
                DieselTankCapacity = s.Specfication.DieselTankCapacity,
                //DrillWater = s.Specfication.EffectiveDrillWater,
                EffectiveDrillWater = s.Specfication.EffectiveDrillWater,
                EffectivePotWater = s.Specfication.EffectivePotWater,
                HCement = s.Specfication.HCement,
                HCementPerTank = s.Specfication.HCementPerTank,
                HCementTank = s.Specfication.HCementTank,
                //PotWater = s.Specfication.EffectivePotWater,
                Saraline = s.Specfication.Saraline,
                SaralinePerTank = s.Specfication.SaralinePerTank,
                SaralineTank = s.Specfication.SaralineTank
            });

            return entities;
        }


        public async Task<IEnumerable<VesselBookActivity>> ListEtaBookActivityAsync(IEnumerable<VesselDepartureParams> vessels, PlanResource planResource)
        {
            var entities = new List<VesselBookActivity>();
            if (vessels == null) return entities;

            foreach (var v in vessels)
            {
                //by start, end logic
                var startDate = v.ETDDate.GetValueOrDefault(); //.AddDays(-1 * (double)planResource.RouteTurnaround);
                var endDate = v.ETDDate.Value.AddDays(VESSEL.MAX_VALIDATE_BLOCKOUT_DAYS);

                var activities = await ListBookActivitiesAysnc(startDate, endDate);

                if (activities.Count() == 0) continue;

                //no maintenance
                var entity = activities.Where(c => c.VesseId == v.LCTReferenceId && c.Type != (int)VesselBookType.MAINTENANCE).OrderBy(c => c.StartDate);

                if (entity == null) continue;

                entities.AddRange(entity);
            }

            foreach (var blocking in entities)
            {
                var ts = blocking.EndDate.GetValueOrDefault().Subtract(blocking.StartDate.GetValueOrDefault());
                var activity = new VesselActivity() { ActivityId = blocking.Type, TimeDuration = ts };
                var t = await this.CalculateFuelConsumtionAsync(activity, planResource);
                blocking.BlockoutDiesel = t.FuelConsumtionValue;
            }

            return entities;
        }


        //
        // Summary:
        //    Return veesel bloockiing (booking) activity
        //
        // Returns:
        //     list of VesselBookActivity object
        //
        // Type parameters:
        //   vessels:
        //     list of vessel ETA props
        //
        /*public async Task<IEnumerable<VesselBookActivity>> ListBookActivityAsync(IEnumerable<VesselProperties> vessels) //, PlanResource planResource)
        {
            if (vessels == null) return new List<VesselBookActivity>();


            //??
            /*foreach (var blocking in entities)
            {
                var ts = blocking.EndDate.GetValueOrDefault().Subtract(blocking.StartDate.GetValueOrDefault());
                var activity = new VesselActivity() { Id = blocking.Type, TimeDuration = ts };
                ///  var t = await _vesselService.CalculateFuelConsumtionAsync(activity, planResource);
                //  blocking.BlockoutDiesel = t.FuelConsumtionValue;
            }*

            return entities;
        }*/


        public async Task<IEnumerable<VesselCurrentPlan>> ListCurrentRouteAsync()
        {
            var currents = await _clientService.ListVesselCurrentPlanAsync();
            if (!currents.Any())
            {
                throw new VesselNotFoundException();
            }

            //filter null and skipped
            currents = currents.Where(c => !String.IsNullOrEmpty(c.LocationStatus));
            //currents = currents.Where(c => c.LocationStatus != SKIPPED_ROUTE);
            //var skipped = currents.Where(c => c.LocationStatus == SKIPPED_ROUTE);

            var routes = new List<VesselDetailAsync>();
            var hello = currents.ToArray();

            for (int i = 0; i < hello.Length; i++)
            {
                var item = hello[i].DeepClone();
                for (int j = 0; j < hello.Length; j++)
                {
                    if (j == i + 1)
                    {

                        item.ProcessETD = hello[j].Etd;
                        item.UpdatedProcessETD = hello[j].UpdatedETD;
                    }
                }

                routes.Add(item);
            }

            routes = routes.Where(c => c.LocationStatus != SKIPPED_ROUTE).ToList();

            //group and get first
            var entities = routes.OrderBy(o => o.VesselId).OrderByDescending(o => o.RouteStatusId).GroupBy(g => new
            {
                g.VesselId,
                g.SequenceNumber

            }).Select(s => new
            {
                VesselId = s.First().VesselId,
                SequenceNumber = s.First().SequenceNumber,
                OriginId = s.First().OriginId,
                DestinationId = s.First().DestinationId,
                UpdatedETA = s.First().UpdatedETA,// == null ? s.First().UpdatedETA : TimeZoneInfo.ConvertTimeFromUtc(s.First().UpdatedETA.Value, estTimeZone),
                UpdatedETD = s.First().UpdatedETD,// == null ? s.First().UpdatedETD : TimeZoneInfo.ConvertTimeFromUtc(s.First().UpdatedETD.Value, estTimeZone),
                Eta = s.First().Eta,//TimeZoneInfo.ConvertTimeFromUtc(s.First().Eta, estTimeZone),
                Etd = s.First().Etd,//TimeZoneInfo.ConvertTimeFromUtc(s.First().Etd, estTimeZone),
                RouteStatusId = s.First().RouteStatusId,
                LctReferenceIsActual = s.First().IsActual,
                LctReferenceIsCurrent = s.First().IsCurrent,
                LocationStatus = s.First().LocationStatus,
                LctReferenceIsDeleted = s.First().IsDeleted,


                ProcessETD = s.First().ProcessETD,
                UpdatedProcessETD = s.First().UpdatedProcessETD,

            });


            var cluster = await _locationService.ListClusterAsync();
            var vessels = await _clientService.ListVesselAsync();

            var result = new List<VesselCurrentPlan>();
            foreach (var cr in entities)
            {
                var from = cluster.Where(c => c.LCTReferenceId == cr.OriginId).FirstOrDefault();
                if (from == null)
                    throw new LocationNotFoundException($"GetLocationBlockoutAsync: Could not find cluster location id {cr.DestinationId}", new Exception());
                var to = cluster.Where(c => c.LCTReferenceId == cr.DestinationId).FirstOrDefault();
                if (to == null)
                    throw new LocationNotFoundException($"GetLocationBlockoutAsync: Could not find cluster location id {cr.DestinationId}", new Exception());

                var v = vessels.Where(c => c.Id == cr.VesselId).FirstOrDefault();
                if (v == null)
                    throw new Exception($"GetLocationBlockoutAsync: Could not find vessel id {cr.VesselId}");

                result.Add(new VesselCurrentPlan
                {
                    Sequence = cr.SequenceNumber,
                    VesselId = cr.VesselId,
                    VesselName = v.Name,
                    FromId = cr.OriginId,
                    ToId = cr.DestinationId,
                    FromName = from.Code,
                    ToName = to.Code,

                    //updated ETA logic from LCT !important
                    ETD = cr.UpdatedETD == null ? cr.Etd : cr.UpdatedETD,
                    ETA = cr.UpdatedETA == null ? cr.Eta : cr.UpdatedETA,

                    ProcessETD = cr.UpdatedProcessETD == null ? cr.ProcessETD : cr.UpdatedProcessETD,

                    /***********************************************/

                    StatusId = cr.RouteStatusId,
                    LctReferenceIsActual = (bool)cr.LctReferenceIsActual,
                    LctReferenceIsCurrent = (bool)cr.LctReferenceIsCurrent,
                    LctReferenceIsDeletedd = (bool)cr.LctReferenceIsDeleted,
                    LocationStatus = cr.LocationStatus
                });
            }

            return result;
        }

        public Stream ListVesselBlobAsync(IEnumerable<VesselDepartureParams> vessels)
        {
            var stream = new MemoryStream();

            var headers = new List<string>
            {
                //"VesselId",
                "LCTReferenceId",
                "VesselName",
                "VesselType",
                "Status",
                "BaseLocationCode",
                "BaseLocationReferenceId",
                "VesselETA",
                "NormalSpeed",
                "MaxSpeed",
                "DieselROB",
                "DieselTankCapacity",
                "SaralineTank",
                "Saraline",
                "Barite",
                "BaritePerTank",
                "BariteTank",
                "HCement",
                "HCementPerTank",
                "HCementTank",
                "BHICement",
                "BHICementPerTank",
                "BHICementTank",
                "PotWater",
                "DrillWater",
                "DeckSpaceLimit",
                "DeadWeightLimit",
                "TubularSpaceLimit",
                "TubularSpaceLimitPerSide",
                "TubularWeightLimitPerSide",
                "TubularHeightLimit",
                "Width",
                "DeckWidth",
                "EffectiveDeckWidth",
                "Maintenance",
                "VesselETD",
                "BlockoutStartTime",
                "BlockoutEndTime",
                "BlockoutStartLocation",
                "BlockoutEndLocation",
                "DieselETD",
                "EffectiveDeadWeightLimit",
                "VisitTanker",
                "BlockoutDiesel"
            };

            //Header columns
            string headerLine = $"{string.Join(BLOB.CsvDelimiter, headers.ToArray())}\n";

            stream.Write(BLOB.Encoding.GetBytes(headerLine), 0, BLOB.Encoding.GetBytes(headerLine).Length);

            //Records
            foreach (var v in vessels)
            {
                var lstV = new List<string>();
                //lstV.Add(v.Id.ToString());
                lstV.Add(v.LCTReferenceId.ToString());
                lstV.Add(v.Name);
                lstV.Add(v.Type);
                lstV.Add(v.Status);
                lstV.Add(v.BasePort.LocationCode);
                lstV.Add(v.BaseLocationReferenceId.ToString());
                lstV.Add(v.ETADate.ToString());
                lstV.Add(v.Specification.Speed.ToString());
                lstV.Add(v.Specification.MaxSpeed.ToString());
                lstV.Add(v.DieselETD.ToString());
                lstV.Add(v.Specification.DieselTankCapacity.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.SaralineTank.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.Saraline.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.Barite.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.BaritePerTank.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.BariteTank.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.HCement.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.HCementPerTank.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.HCementTank.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.BhiCement.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.BhiCementPerTank.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.BhiCementTank.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.PotWater.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.DrillWater.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.DeckSpaceLimit.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.DeadWeightLimit.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.TabularSpaceLimit.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.TabularSpaceLimitPerSide.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.TabularWeightLimitPerSide.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.TabularHeightLimit.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.DeckWidth.GetValueOrDefault().ToString());
                lstV.Add(v.Specification.DeckWidth.GetValueOrDefault().ToString());
                lstV.Add(v.EffectiveDeckWidth.GetValueOrDefault().ToString());
                lstV.Add(v.PM == null ? "No" : "Yes");
                lstV.Add(v.ETDDate.ToString());
                lstV.Add(v.BlockStartDate.ToString());
                lstV.Add(v.BlockEndDate.ToString());
                lstV.Add(v.BlockStartLocationCode);
                lstV.Add(v.BlockEndLocationCode);
                lstV.Add(v.DieselETD.ToString());
                lstV.Add(v.EffectiveDeadWeightLimit.ToString());
                lstV.Add(v.IsVisitTanker ? "Yes" : "No");
                lstV.Add(v.BlockoutDiesel.ToString());


                var valueLine = $"{string.Join(BLOB.CsvDelimiter, lstV.toReplaceArray())}\n";

                stream.Write(BLOB.Encoding.GetBytes(valueLine), 0, BLOB.Encoding.GetBytes(valueLine).Length);
            }

            stream.Position = 0;
            return stream;
        }
        public Stream ListCurrentPlanBlobAsync(IEnumerable<VesselCurrentPlan> vesselss)
        {
            var stream = new MemoryStream();

            var headers = new List<string>
            {
                "No.",
                "VesselId",
                "VesselName",
                "From",
                "To",
                "ETD",
                "ETA",

                "ProcessETD"
            };

            //Header columns
            string headerLine = $"{string.Join(BLOB.CsvDelimiter, headers.ToArray())}\n";

            stream.Write(BLOB.Encoding.GetBytes(headerLine), 0, BLOB.Encoding.GetBytes(headerLine).Length);

            //Records
            foreach (var v in vesselss)
            {
                var lstV = new List<string>();
                lstV.Add(v.Sequence.ToString());
                lstV.Add(v.VesselId.ToString());
                lstV.Add(v.VesselName);
                lstV.Add(v.FromName);
                lstV.Add(v.ToName);
                lstV.Add(v.ETD.ToString());
                lstV.Add(v.ETA.ToString());

                lstV.Add(v.ProcessETD.ToString());

                var valueLine = $"{string.Join(BLOB.CsvDelimiter, lstV.toReplaceArray())}\n";

                stream.Write(BLOB.Encoding.GetBytes(valueLine), 0, BLOB.Encoding.GetBytes(valueLine).Length);
            }

            stream.Position = 0;
            return stream;
        }

        public Stream ListBookActivityBlobAsync(IEnumerable<VesselBookActivity> vesselBookActivities)
        {
            var stream = new MemoryStream();

            var headers = new List<string>
            {
                "VesselId",
                "VesselName",
                "StartDate",
                "EndDate",
                "StartLocation",
                "EndLocation",
                "VesselBookType",
                "BlockoutDiesel"
            };

            //Header columns
            string headerLine = $"{string.Join(BLOB.CsvDelimiter, headers.ToArray())}\n";

            stream.Write(BLOB.Encoding.GetBytes(headerLine), 0, BLOB.Encoding.GetBytes(headerLine).Length);

            //Records
            foreach (var v in vesselBookActivities)
            {
                var lstV = new List<string>();
                lstV.Add(v.VesseId.ToString());
                lstV.Add(v.VesselName);
                lstV.Add(v.StartDate.ToString());
                lstV.Add(v.EndDate.ToString());
                lstV.Add(v.StartLocationCode);
                lstV.Add(v.EndLocationCode);
                var type = (VesselBookType)v.Type;
                lstV.Add(type.GetDescription());
                lstV.Add(v.BlockoutDiesel.ToString());

                var valueLine = $"{string.Join(BLOB.CsvDelimiter, lstV.toReplaceArray())}\n";

                stream.Write(BLOB.Encoding.GetBytes(valueLine), 0, BLOB.Encoding.GetBytes(valueLine).Length);
            }

            stream.Position = 0;
            return stream;
        }

        /*
        public async Task<IEnumerable<VesselBookActivity>> ListBookActivitiesAysnc(DateTime start, DateTime end)
        {
            var entities = await this.ListBookActivitiesAysnc();

            entities = entities.Where(c => c.StartDate >= start && c.StartDate <= end).OrderBy(c => c.StartDate);

            return entities;
        }
        */
    }


    public interface IVesselLocationService
    {
        Task<IEnumerable<LocationBlockoutParams>> ListVesselLocationBlockoutAsync();
        Stream ListVesselLocationBlockoutBlobAsync(IEnumerable<LocationBlockoutParams> locationBlockoutParams, IEnumerable<LocationState> locationStates);
    }

    public class VesselLocationService : IVesselLocationService
    {
        private readonly IVesselRepository _vesselRepository;
        private readonly ILocationRepository _locationRepository;

        private readonly IClientService _clientService;
        private readonly ILocationService _locationService;
        private readonly IVesselService _vesselService;
        //private readonly IEntityService _clientService;
        public VesselLocationService(IVesselRepository vesselRepository, ILocationRepository locationRepository, IClientService clientService, IVesselService vesselService, ILocationService locationService)
        {
            _locationRepository = locationRepository ?? throw new ArgumentNullException(nameof(locationRepository));
            _vesselRepository = vesselRepository ?? throw new ArgumentNullException(nameof(vesselRepository));
            _clientService = clientService ?? throw new ArgumentNullException(nameof(clientService));

            _vesselService = vesselService ?? throw new ArgumentNullException(nameof(vesselService));
            _locationService = locationService ?? throw new ArgumentNullException(nameof(locationService));


            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }

        //
        // Summary:
        //     retrun the location blockout with vessel
        //
        // Returns:
        //
        //   Location Blockout  model
        //
        //move from process datra

        public async Task<IEnumerable<LocationBlockoutParams>> ListVesselLocationBlockoutAsync()
        {
            var currents = await _vesselService.ListCurrentRouteAsync();

            if (!currents.Any())
            {
                throw new VesselNotFoundException();
            }

            var cluster = await _locationService.ListClusterAsync();

            //remove jetty
            var entity = currents.Where(c => !LOCATION.TERMINALS.Keys.ToArray().Contains(c.ToId)).OrderBy(o => o.VesselId).ThenBy(o => o.Sequence);

            var entities = new List<LocationBlockoutParams>();
            // var previous = entity.FirstOrDefault();

            var locations = await _clientService.ListLocationAsync();

            foreach (var cr in entity)
            {
                /*if (cr.Sequence == 1)
                {
                    previous = cr;
                    continue;
                }*/
                var to = cluster.Where(c => c.LCTReferenceId == cr.ToId).FirstOrDefault();
                if (to == null)
                    throw new LocationNotFoundException($"GetLocationBlockoutAsync: Could not find cluster location id {cr.ToId}", new Exception());

                var temp = new LocationBlockoutParams
                {
                    Code = to.Code,
                    ClusterCode = to.ClusterCode,
                    StartDate = cr.ETA,
                    EndDate = cr.ProcessETD

                    //old asset
                    //Asset = from.Asset
                };

                //find  new asset with dor plaform (new by gulf of thailand area)
                var l = locations.Where(c => c.DORPlatformId == to.DORPlatformId).FirstOrDefault();
                if (l != null)
                {
                    temp.Asset = l.Asset;
                }

                entities.Add(temp);

                //swap
                //previous = cr;
            }

            return entities;
        }



        public Stream ListVesselLocationBlockoutBlobAsync(IEnumerable<LocationBlockoutParams> locationBlockoutParams, IEnumerable<LocationState> locationStates)
        {
            var stream = new MemoryStream();

            var headers = new List<string>
            {
                "ClusterCode",
                "Arrival",
                "Departure",

                "Asset",
                "Type",
                "Location"
            };

            //Header columns
            string headerLine = $"{string.Join(BLOB.CsvDelimiter, headers.ToArray())}\n";

            stream.Write(BLOB.Encoding.GetBytes(headerLine), 0, BLOB.Encoding.GetBytes(headerLine).Length);

            //Records
            foreach (var v in locationBlockoutParams)
            {
                var lstV = new List<string>();
                lstV.Add(v.ClusterCode);
                lstV.Add(v.StartDate.ToString());
                lstV.Add(v.EndDate.ToString());

                lstV.Add(v.Asset);
                lstV.Add("Current");
                lstV.Add(v.Code);

                var valueLine = $"{string.Join(BLOB.CsvDelimiter, lstV.toReplaceArray())}\n";

                stream.Write(BLOB.Encoding.GetBytes(valueLine), 0, BLOB.Encoding.GetBytes(valueLine).Length);
            }

            //Tankers
            foreach (var v in locationStates)
            {
                var lstV = new List<string>();
                lstV.Add(v.LocationCode);
                lstV.Add(v.ScheduleDateStart.ToString());
                lstV.Add(v.ScheduleDateEnd.ToString());

                lstV.Add(v.Asset);
                lstV.Add("Tanker");
                lstV.Add(v.LocationCode);

                var valueLine = $"{string.Join(BLOB.CsvDelimiter, lstV.toReplaceArray())}\n";

                stream.Write(BLOB.Encoding.GetBytes(valueLine), 0, BLOB.Encoding.GetBytes(valueLine).Length);
            }

            stream.Position = 0;
            return stream;
        }




    }

}