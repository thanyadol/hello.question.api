using System;

using System.Collections.Generic;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;
using AutoMapper;
using cvx.lct.vot.api.APIs.Services;
using cvx.lct.vot.api.Exceptions;
using cvx.lct.vot.api.Extensions;
//vot
using cvx.lct.vot.api.Models;
using cvx.lct.vot.api.Repositories;

//logg
using Serilog;


using PLAN = cvx.lct.vot.api.Models.Constant.Plan;
using LOCATION = cvx.lct.vot.api.Models.Constant.Location;
using BLOB = cvx.lct.vot.api.Models.Constant.Blob;
using System.IO;

namespace cvx.lct.vot.api.Services
{

    public interface ILocationService
    {
        Task<Location> CreateAsync(Location location);
        Task<Location> UpdateAsync(Location location);

        Task<Location> GetAsync(Guid id);

        Task<IEnumerable<Location>> ListAsync();
        Task<Location> EnforceLocationExistenceAsync(Guid id);

        //block out
        // Task<LocationBlockout> CreateAsync(LocationBlockout blockout);
        //Task<IEnumerable<LocationBlockout>> ListBlockoutAsync();
        Task<LocationState> GetStateAsync(Guid id);
        // Task<LocationState> GetStateAsync(Guid id, Guid planId);
        //Task<Location> GetAsync(string code);

        //   Task<IEnumerable<LocationBlockoutParams>> ListCurrentBlockoutAsync();
        Task<LocationState> EnforceStateExistenceAsync(Guid id);

        //schedule
        Task<PlanLocation> CreateAsync(PlanLocation location);

        //plan id
        Task<IEnumerable<LocationState>> ListTankAsync(Guid id);

        //plan id
        Task<IEnumerable<LocationState>> ListRestrictedHourAsync(Guid id);

        Task<IEnumerable<LocationState>> SynceRestrictedHourAsync();
        Task<IEnumerable<LocationState>> SynceTankerAsync();

        Task<IEnumerable<Location>> SynceAsync();
        Task<IEnumerable<Location>> ListClusterAsync();

        Task<IEnumerable<Location>> ListTankerAsync();
        Task<IEnumerable<Location>> ListTerminalAsync();

        //Task<IEnumerable<LocationBlockoutParams>> GetLocationBlockoutAsync();


        Stream ListRestrictedBlobAsync(IEnumerable<LocationState> locationStates);
        Stream ListClusterBlobAsync(IEnumerable<Location> locations);

        //        Task<IEnumerable<LocationState>> InitRestrictedHourAsync(IEnumerable<LocationState> locations);
    }

    public class LocationService : ILocationService
    {
        private readonly ILocationRepository _locationRepository;
        //  private readonly ILocationBlockoutRepository _locationBlockoutRepository;
        private readonly ILocationStateRepository _locationStateRepository;
        private readonly IPlanLocationRepository _locationScheduleRepository;

        private readonly IMapper _mapper;

        // Assign the object in the constructor for dependency injection

        //private readonly IEntityService _entitySerivce;

        private readonly IClientService _clientService;

        private readonly IWorkUnitExtension _workUnitService;

        public LocationService(ILocationRepository locationRepository, ILocationStateRepository locationStateRepository,
                                    IPlanLocationRepository locationScheduleRepository, IClientService clientService, IMapper mapper, IWorkUnitExtension workUnitService)
        {
            _locationRepository = locationRepository ?? throw new ArgumentNullException(nameof(locationRepository));
            //    _locationBlockoutRepository = locationBlockoutRepository ?? throw new ArgumentNullException(nameof(locationBlockoutRepository));
            _locationStateRepository = locationStateRepository ?? throw new ArgumentNullException(nameof(locationStateRepository));

            _locationScheduleRepository = locationScheduleRepository ?? throw new ArgumentNullException(nameof(locationScheduleRepository));

            //  _entitySerivce = entitySerivce ?? throw new ArgumentNullException(nameof(entitySerivce));
            _clientService = clientService ?? throw new ArgumentNullException(nameof(clientService));
            _mapper = mapper;

            _workUnitService = workUnitService ?? throw new ArgumentNullException(nameof(workUnitService));


            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }
        public Stream ListClusterBlobAsync(IEnumerable<Location> locations)
        {
            var stream = new MemoryStream();

            var headers = new List<string>
            {
                "ClusterId",
                "ClusterCode",
                "ClusterName",
                "ClusterLatitude",
                "ClusterLongitude",
                "ClusterType",
                "ClusterCategory",

                "Asset"
            };

            //Header columns
            string headerLine = $"{string.Join(BLOB.CsvDelimiter, headers.ToArray())}\n";

            stream.Write(BLOB.Encoding.GetBytes(headerLine), 0, BLOB.Encoding.GetBytes(headerLine).Length);

            //Records
            foreach (var v in locations)
            {
                var lstV = new List<string>();
                lstV.Add(v.LCTReferenceId.ToString());
                lstV.Add(v.Code);
                lstV.Add(v.Name);
                lstV.Add(v.Lat.ToString());
                lstV.Add(v.Long.ToString());
                lstV.Add(v.Type);
                lstV.Add(v.Category);

                lstV.Add(v.Asset);

                var valueLine = $"{string.Join(BLOB.CsvDelimiter, lstV.toReplaceArray())}\n";

                stream.Write(BLOB.Encoding.GetBytes(valueLine), 0, BLOB.Encoding.GetBytes(valueLine).Length);
            }

            stream.Position = 0;
            return stream;
        }

        public Stream ListRestrictedBlobAsync(IEnumerable<LocationState> locationStates)
        {
            var stream = new MemoryStream();

            var headers = new List<string>
            {
                "Id",
                "ClusterId",
                "ClusterCode",
                "Start time",
                "End time"
            };

            //Header columns
            string headerLine = $"{string.Join(BLOB.CsvDelimiter, headers.ToArray())}\n";

            stream.Write(BLOB.Encoding.GetBytes(headerLine), 0, BLOB.Encoding.GetBytes(headerLine).Length);

            var maxPM = new TimeSpan(23, 59, 59);
            var minAM = new TimeSpan(0, 0, 0);

            //Records
            foreach (var v in locationStates)
            {
                var lstV = new List<string>();

                var needSpitLine = (v.RestrictedTimeStart - v.RestrictedTimeEnd) > minAM;

                if (needSpitLine)
                {
                    lstV.Add(v.LCTReferenceId.ToString());
                    lstV.Add(v.LCTReferenceId.ToString());
                    lstV.Add(v.LocationCode);
                    lstV.Add(v.RestrictedTimeStart.ToString());
                    lstV.Add(maxPM.ToString());

                    var valueLine = $"{string.Join(BLOB.CsvDelimiter, lstV.toReplaceArray())}\n";
                    stream.Write(BLOB.Encoding.GetBytes(valueLine), 0, BLOB.Encoding.GetBytes(valueLine).Length);

                    lstV.Clear();

                    lstV.Add(v.LCTReferenceId.ToString());
                    lstV.Add(v.LCTReferenceId.ToString());
                    lstV.Add(v.LocationCode);
                    lstV.Add(minAM.ToString());
                    lstV.Add(v.RestrictedTimeEnd.ToString());

                    valueLine = $"{string.Join(BLOB.CsvDelimiter, lstV.toReplaceArray())}\n";
                    stream.Write(BLOB.Encoding.GetBytes(valueLine), 0, BLOB.Encoding.GetBytes(valueLine).Length);
                }
                else
                {
                    lstV.Add(v.LCTReferenceId.ToString());
                    lstV.Add(v.LCTReferenceId.ToString());
                    lstV.Add(v.LocationCode);
                    lstV.Add(v.RestrictedTimeStart.ToString());
                    lstV.Add(v.RestrictedTimeEnd.ToString());

                    var valueLine = $"{string.Join(BLOB.CsvDelimiter, lstV.toReplaceArray())}\n";
                    stream.Write(BLOB.Encoding.GetBytes(valueLine), 0, BLOB.Encoding.GetBytes(valueLine).Length);
                }

            }

            stream.Position = 0;
            return stream;
        }

        public async Task<Location> CreateAsync(Location location)
        {
            location.Id = Guid.NewGuid();
            location.Date = DateTime.UtcNow;

            //await EnforceClanExistenceAsync(Location.Clan.Name);
            var entity = await _locationRepository.CreateAsync(location);
            if (entity == null)
            {
                throw new LocationNotFoundException(location.Id);
            }

            return entity;
        }



        public async Task<PlanLocation> CreateAsync(PlanLocation location)
        {
            location.Id = Guid.NewGuid();
            location.Date = DateTime.UtcNow;
            location.By = "admin";


            //await EnforceClanExistenceAsync(Location.Clan.Name);
            var entity = await _locationScheduleRepository.CreateAsync(location);
            if (entity == null)
            {
                throw new LocationNotFoundException(location.Id);
            }

            return entity;
        }


        /* 
        public async Task<LocationBlockout> CreateAsync(LocationBlockout blockout)
        {
            //validate
            await this.EnforceLocationExistenceAsync(blockout.LocationId);

            blockout.Id = Guid.NewGuid();
            // blockout.Date = DateTime.UtcNow;

            //await EnforceClanExistenceAsync(Location.Clan.Name);
            var entity = await _locationBlockoutRepository.CreateAsync(blockout);
            if (entity == null)
            {
                throw new LocationNotFoundException();
            }

            return entity;
        }*/


        public async Task<Location> UpdateAsync(Location location)
        {
            var updated = await this.EnforceLocationExistenceAsync(location.Id);

            //assigned
            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //location.Key = Guid.NewGuid().ToString();

            var entity = await _locationRepository.UpdateAsync(location);
            if (entity == null)
            {
                throw new LocationNotFoundException(location.Id);
            }

            return entity;
        }

        public async Task<Location> GetAsync(Guid id)
        {
            //  await this.EnforceLocationExistenceAsync(id);

            var entity = await _locationRepository.GetAsync(id);
            return entity;
        }


        /*  public async Task<IEnumerable<LocationState>> InitRestrictedHourAsync(IEnumerable<LocationState> locations)
         {
             // var DEFAULT_LOCATION_SCHEDULE_ID = Guid.Parse("000d5a47-26a6-4271-bfdb-644ebb0a16fb");

             var locates = await this.SynceAsync();

             using (var transaction = _workUnitService.BeginTransaction())
             {
                 //create space
                 var entities = new List<LocationState>();
                 foreach (var l in locations)
                 {
                     l.Id = Guid.NewGuid();
                     l.Date = DateTime.UtcNow;
                     //l.RecordStatus = RecordStatus.ACTIVE.GetDescription();

                     l.IsTanker = false;
                     // l.PlanLocationId = DEFAULT_LOCATION_SCHEDULE_ID;

                     l.LCTReferenceId = locates.Where(c => c.Code == l.LocationCode).FirstOrDefault()?.LCTReferenceId;
                     l.By = "admin";

                     entities.Add(l);
                 }

                 await _workUnitService.LocationStates.CreateRangeAsync(entities);

                 try
                 {

                     transaction.Commit();
                     return locations;
                 }
                 catch (InvalidOperationException)
                 {
                     transaction.Rollback();
                     throw new LocationNotFoundException();
                 }
             }

         }*/



        public async Task<IEnumerable<Location>> ListAsync()
        {
            return await _locationRepository.ListAsync();
        }


        /* *public async Task<Location> DeleteAsync(Guid id)
        {
            await this.EnforceLocationExistenceAsync(id);

            var deletedLocation = await _locationRepository.DeleteAsync(id);
            return deletedLocation;
        }*/

        public async Task<IEnumerable<Location>> SynceAsync()
        {
            //await Task.Delay(5000);
            var entity = await _clientService.ListLocationAsync();
            if (entity == null)
            {
                throw new LocationNotFoundException();
            }

            entity = entity.Where(c => c.IsActive == true);

            //fucking auto mapper
            var mapped = new List<Location>(); //_mapper.Map<IEnumerable<Location>>(entity);
            foreach (var e in entity)
            {
                mapped.Add(new Location { LCTReferenceId = e.Id, Name = e.Name, Code = e.Code, Lat = e.Latitude, Long = e.Longitude, Type = e.Type });
            }

            return mapped.OrderBy(c => c.Code);
        }


        public async Task<IEnumerable<Location>> ListTerminalAsync()
        {
            const string TERMINAL_LOCATION_TYPE = "Terminal";
            //await Task.Delay(5000);
            var entity = await _clientService.ListLocationAsync();
            if (entity == null)
            {
                throw new LocationNotFoundException();
            }


            entity = entity.Where(c => c.Type == TERMINAL_LOCATION_TYPE && c.IsActive == true);

            //fucking auto mapper
            var mapped = new List<Location>(); //_mapper.Map<IEnumerable<Location>>(entity);
            foreach (var e in entity)
            {
                mapped.Add(new Location { LCTReferenceId = e.Id, Name = e.Name, Code = e.Code, Lat = e.Latitude, Long = e.Longitude, Type = e.Type });
            }

            return mapped.OrderBy(c => c.Code);

        }



        public async Task<IEnumerable<Location>> ListTankerAsync()
        {
            const string TANKER_LOCATION_CODE = "EFSO2";
            //await Task.Delay(5000);
            var entity = await _clientService.ListLocationAsync();
            entity = entity.Where(c => c.IsActive == true);
            if (entity == null)
            {
                throw new LocationNotFoundException();
            }

            entity = entity.Where(c => c.Code == TANKER_LOCATION_CODE && c.IsActive == true);

            //fucking auto mapper
            var mapped = new List<Location>(); //_mapper.Map<IEnumerable<Location>>(entity);
            foreach (var e in entity)
            {
                mapped.Add(new Location { LCTReferenceId = e.Id, Name = e.Name, Code = e.Code, Lat = e.Latitude, Long = e.Longitude, Type = e.Type });
            }

            return mapped.OrderBy(c => c.Code);
        }



        //add some logic to determine cluseter
        public async Task<IEnumerable<Location>> ListClusterAsync()
        {
            //await Task.Delay(5000);
            var entity = await _clientService.ListLocationAsync();
            var clusters = await _locationRepository.ListClusterAsync();

            var terminals = await this.ListTerminalAsync();
            var tankers = await this.ListTankerAsync();

            var rigTypes = new List<string> { "Jack Up", "Tender Drilling Rig", "Barge Rig" };

            if (entity == null)
            {
                throw new LocationNotFoundException();
            }

            //entity = entity.Where(c => c.IsActive == true);
            entity = entity.Where(c => c.IsDeleted == false);

            var mapped = new List<Location>(); //_mapper.Map<IEnumerable<Location>>(entity);
            foreach (var e in entity)
            {
                //vessel go
                if (e.Type == LocationType.VESSEL.GetDescription()) continue;

                //null (default)
                var cluster = e.DeepClone(); //new APIs.Models.LocationAsync() { };
                cluster.Code = "";
                cluster.Name = "";

                //determine cluster from child

                //determine cluster from child
                var locate = clusters.Where(c => c.LCTReferenceId == e.Id).FirstOrDefault();
                if (locate != null)
                {
                    //cluster is parent
                    cluster = entity.Where(c => c.Id == locate.ParentLocationLCTReferenceId).FirstOrDefault();
                }

                //determind category
                string category = ClusterCategory.NONRIG.GetDescription();

                var tanker = tankers.Where(c => c.LCTReferenceId == e.Id).FirstOrDefault();
                var terminal = terminals.Where(c => c.LCTReferenceId == e.Id).FirstOrDefault();

                if (tanker != null)
                {
                    category = ClusterCategory.TANKER.GetDescription();
                }
                if (terminal != null)
                {
                    category = ClusterCategory.TERMINAL.GetDescription();
                }
                var rig = rigTypes.Where(c => c == e.Type).FirstOrDefault();
                if (rig != null)
                {
                    category = ClusterCategory.RIG.GetDescription();
                }

                mapped.Add(new Location
                {
                    LCTReferenceId = e.Id,
                    Name = e.Name,
                    Code = e.Code,
                    Lat = e.Latitude,
                    Long = e.Longitude,
                    Type = e.Type,

                    ChildLocationLCTReferenceId = e.Id, //! important
                    //for mr asset
                    DORPlatformId = e.DORPlatformId,
                    Asset = e.Asset,

                    Category = category,
                    ClusterRefId = cluster.Id,
                    ClusterCode = cluster.Code,
                    ClusterName = cluster.Name,
                    ClusterLatitude = cluster.Latitude,
                    ClusterLongtitude = cluster.Longitude
                });
            }

            return mapped.OrderBy(c => c.Code);
        }

        //
        // Summary:
        //     retrun and list status of port by type
        //
        // Returns:
        //
        //   location state  model
        //
        // Type parameters:
        //   id:
        //     scheduler  id
        //
        public async Task<IEnumerable<LocationState>> ListRestrictedHourAsync(Guid id)
        {
            var entities = await _locationStateRepository.ListAsync(id, false);

            //  .Select(c => { c.LocationName = _locationRepository.GetAsync(c.LocationId)?.Result.Name; return c; }).ToList();

            //get type
            var locations = await this.ListClusterAsync();
            entities = entities.Select(c => { c.LocationCategory = locations.Where(x => x.LCTReferenceId == c.LCTReferenceId).FirstOrDefault()?.Category; return c; }).ToList();

            return entities.OrderBy(c => Array.IndexOf(LOCATION.CATEGORY_ORDERED, c.LocationCategory)).ThenBy(c => c.LocationCode);
        }


        //list blockout with only tanker type
        public async Task<IEnumerable<LocationState>> ListTankAsync(Guid id)
        {

            var entities = await _locationStateRepository.ListAsync(id, true);
            //entities = entities;
            // .Select(c => { c.LocationName = _locationRepository.GetAsync(c.LocationId)?.Result.Name; return c; }).ToList();

            //get type
            //var locations = await this.ListCusterAsync();
            //entities = entities.Select(c => { c.LocationCategory = locations.Where(x => x.LCTReferenceId == c.LCTReferenceId).FirstOrDefault()?.Category; return c; }).ToList();

            //custom order
            return entities; //.OrderBy(c => Array.IndexOf(LOCATION.CATEGORY_ORDERED, c.LocationCategory)).ThenBy(c => c.LocationCode);
        }


        public async Task<IEnumerable<LocationState>> SynceTankerAsync()
        {
            var entities = await _locationStateRepository.ListAsync(LOCATION.DEFAULT_SCHEDULE_ID, true);

            //entities = entities.Where(c => c.IsTanker == true && c.PlanLocationId == LOCATION.DEFAULT_SCHEDULE_ID);
            //entities = entities.Select(c => { c.LocationName = this.GetAsync(c.LCTReferenceId.GetValueOrDefault())?.Result.Name; return c; }).ToList();

            //get type
            // var locations = await this.ListCusterAsync();
            ///entities = entities.Select(c => { c.LocationCategory = locations.Where(x => x.LCTReferenceId == c.LCTReferenceId).FirstOrDefault()?.Category; return c; }).ToList();

            //custom order
            return entities; //.OrderBy(c => Array.IndexOf(LOCATION.CATEGORY_ORDERED, c.LocationCategory)).ThenBy(c => c.LocationCode);
        }


        public async Task<IEnumerable<LocationState>> SynceRestrictedHourAsync()
        {
            var entities = await _locationStateRepository.ListAsync(LOCATION.DEFAULT_SCHEDULE_ID, false);

            //  entities = entities.Where(c => c.IsTanker != true && c.PlanLocationId == LOCATION.DEFAULT_SCHEDULE_ID);
            //entities = entities.Select(c => { c.LocationName = this.GetAsync(c.LCTReferenceId.GetValueOrDefault())?.Result.Name; return c; }).ToList();

            //get type
            var locations = await this.ListClusterAsync();
            entities = entities.Select(c => { c.LocationCategory = locations.Where(x => x.LCTReferenceId == c.LCTReferenceId).FirstOrDefault()?.Category; return c; }).ToList();

            //custom order
            return entities.OrderBy(c => Array.IndexOf(LOCATION.CATEGORY_ORDERED, c.LocationCategory)).ThenBy(c => c.LocationCode);
        }



        //
        // Summary:
        //     retrun and status of port by location id  
        //
        // Returns:
        //
        //   location state  model
        //
        // Type parameters:
        //   id:
        //     location id
        //

        public async Task<LocationState> GetStateAsync(Guid id)
        {
            var entity = await _locationStateRepository.ListAsync();
            return entity.Where(c => c.LocationId == id).FirstOrDefault();
        }

        //by lctref id
        public async Task<Location> GetAsync(int id)
        {
            var entity = await this.SynceAsync();
            return entity.Where(c => c.LCTReferenceId == id).FirstOrDefault();
        }

        public async Task<Location> EnforceLocationExistenceAsync(Guid id)
        {
            var entity = await _locationRepository.GetAsync(id);
            if (entity == null)
            {
                throw new LocationNotFoundException();
            }

            return entity;
        }

        public async Task<LocationState> EnforceStateExistenceAsync(Guid id)
        {
            var entity = await _locationStateRepository.GetAsync(id);
            if (entity == null)
            {
                throw new LocationNotFoundException();
            }

            return entity;
        }



    }

}