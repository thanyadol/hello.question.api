﻿
using FluentValidation;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.WindowsAzure.Storage.Queue;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

//vot
using cvx.lct.vot.api.APIs.Services;
using cvx.lct.vot.api.Environment;
using cvx.lct.vot.api.Exceptions;
using cvx.lct.vot.api.Extensions;
using cvx.lct.vot.api.Models;
using cvx.lct.vot.api.Models.Constant;
using cvx.lct.vot.api.Validator;
using surflex.netcore22.Models.DTO;

namespace cvx.lct.vot.api.Services
{
    public interface IAzureService
    {

        Task<Job> RunJobAsync(Job job);
        long GetDatabrickJob(string jobName);
        Task<Job> CancelJobAsync(Guid id);


        //Task<IEnumerable<FactoryLog>> ListSynceLogAsync();


        Task<string> UploadBlobAsync(Uri uri, Stream stream);
        Task<string> UploadBlobAsync(Uri uri, string content);
        Task<MemoryStream> DownloadBlobAsync(Uri uri);


        void AddMessage(string msg);
    }

    public class AzureService : IAzureService
    {

        //private readonly IEntityService _entityService;
        // private readonly AbstractValidator<PlanParams> _planValidator;
        private readonly IPlanService _planService;

        private readonly IMaterialService _materialService;
        private readonly ILocationService _locationService;
        private readonly IVesselService _vesselService;
        private readonly ICargoService _cargoService;
        private readonly IJobService _jobService;


        private readonly ITabularService _tabularService;

        private static CloudBlobClient blobClient;

        private static CloudQueueClient _queueClient;
        private static CloudQueue _queue;
        private readonly IParamService _paramService;

        private readonly IVesselLocationService _vesselLocationService;

        public AzureService(IPlanService planService, IMaterialService materialService, IJobService jobService, ILocationService locationService,
                                                            IVesselService vesselService, ICargoService cargoService, ITabularService tabularService, IParamService paramService,
                                                             IVesselLocationService vesselLocationService)
        {
            _jobService = jobService ?? throw new ArgumentNullException(nameof(jobService));
            _planService = planService ?? throw new ArgumentNullException(nameof(planService));
            // _planValidator = planValidator ?? throw new ArgumentNullException(nameof(planValidator));

            _materialService = materialService ?? throw new ArgumentNullException(nameof(materialService));
            _locationService = locationService ?? throw new ArgumentNullException(nameof(locationService));
            _vesselService = vesselService ?? throw new ArgumentNullException(nameof(vesselService));

            _cargoService = cargoService ?? throw new ArgumentNullException(nameof(cargoService));
            _tabularService = tabularService ?? throw new ArgumentNullException(nameof(tabularService));

            _paramService = paramService ?? throw new ArgumentNullException(nameof(paramService));
            _vesselLocationService = vesselLocationService ?? throw new ArgumentNullException(nameof(vesselLocationService));

            //_entityService = entitySerivce ?? throw new ArgumentNullException(nameof(entitySerivce));

            var connectinString = Configuration.Instance.GetVOTBlobConnectionString();
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(connectinString);

            if (_queue != null) return;

            _queueClient = storageAccount.CreateCloudQueueClient();
            _queue = _queueClient.GetQueueReference(Configuration.Instance.GetQueueName());
            _queue.CreateIfNotExistsAsync();
            //Task.Run(async () =>
            //{
            //    await _queue.CreateIfNotExistsAsync();
            //}).Wait();
            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }


        public void AddMessage(string msg)
        {
            CloudQueueMessage queueMsg = new CloudQueueMessage(msg);
            Task.Run(async () =>
            {
                await _queue.AddMessageAsync(queueMsg);
            }).Wait();
        }

        // public static AzureService Instance
        // {
        //     get
        //     {
        //         return instance;
        //     }
        // }

        private void InitBlobClient()
        {
            if (blobClient != null)
                return;

            var blobConnectionStringSecret = Environment.Configuration.Instance.GetVOTBlobConnectionString();

            CloudStorageAccount storageAccount;
            if (CloudStorageAccount.TryParse(blobConnectionStringSecret, out storageAccount))
            {
                blobClient = storageAccount.CreateCloudBlobClient();
            }
            else
            {
                throw new AzureNotValidException("can't connect azure account storage!");
            }
        }

        private string GetContainerFromUri(Uri uri)
        {
            var items = uri.AbsolutePath.Split("/").Where(x => x != "").ToArray();

            if (items.Length == 0 || string.IsNullOrEmpty(uri.AbsolutePath))
            {
                throw new AzureNotValidException("Can't find container from uri");
            }

            return items[0];
        }

        private async Task<CloudBlockBlob> CreateIfNoExistsContainnerAndFolderAsync(Uri uri)
        {
            var containerName = GetContainerFromUri(uri);

            CloudBlobContainer blobContianer = blobClient.GetContainerReference(containerName);
            var result = await blobContianer.CreateIfNotExistsAsync();

            var blockPath = uri.AbsolutePath.Replace("/" + containerName + "/", "");

            return blobContianer.GetBlockBlobReference(blockPath);
        }

        public async Task<string> UploadBlobAsync(Uri uri, Stream stream)
        {
            InitBlobClient();

            var blob = await CreateIfNoExistsContainnerAndFolderAsync(uri);
            await blob.UploadFromStreamAsync(stream);
            return blob.Uri.AbsoluteUri;
        }

        public async Task<string> UploadBlobAsync(Uri uri, string content)
        {
            InitBlobClient();

            var blob = await CreateIfNoExistsContainnerAndFolderAsync(uri);
            await blob.UploadTextAsync(content);
            return blob.Uri.AbsoluteUri;
        }

        public async Task<bool> UploadBlobAsync(string containnerName, string blobName, string path)
        {
            InitBlobClient();
            var container = blobClient.GetContainerReference(containnerName);
            await container.CreateIfNotExistsAsync();
            CloudBlockBlob blob = container.GetBlockBlobReference(blobName);
            await blob.UploadFromFileAsync(path);
            return true;
        }

        public async Task<MemoryStream> DownloadBlobAsync(Uri uri)
        {
            InitBlobClient();
            CloudBlockBlob blob = new CloudBlockBlob(uri, blobClient.Credentials);
            var isExist = await blob.ExistsAsync();
            if (!isExist)
                throw new AzureNotValidException($"Could not find {uri}");

            var reader = await blob.OpenReadAsync();
            var readMem = new MemoryStream();
            await reader.CopyToAsync(readMem);
            return readMem;
        }


        private HttpClient HttpClient()
        {
            var httpClientHandler = new HttpClientHandler();

            // Omit this part if you don't need to authenticate with the web server:
            httpClientHandler.DefaultProxyCredentials = System.Net.CredentialCache.DefaultNetworkCredentials;

            HttpClient client = new HttpClient(handler: httpClientHandler, disposeHandler: true);
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Configuration.Instance.GetDatabrickToken());
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            return client;
        }
        //cancel job with job id
        public async Task<Job> CancelJobAsync(Guid id)
        {

            var job = await _jobService.GetAsync(id);
            if (job == null)
            {
                throw new JobNotFoundException();
            }


            HttpClient client = this.HttpClient();
            HttpContent httpContent = new StringContent(JsonConvert.SerializeObject(new CancelParams
            {
                run_id = job.RunId
            }));

            //cancek in db
            job.Status = JobStatus.CANCELED.GetDescription();
            job = await _jobService.UpdateAsync(job);

            //cancel in databrick
            var response = client.PostAsync(Configuration.Instance.GetDatabrickUrl() + Databrick.urlCannel, httpContent).Result;
            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"API Error: Can't cancel job in databrick run id { job.RunId}");
            }

            return job;
        }

        public long GetDatabrickJob(string jobName)
        {
            HttpClient client = this.HttpClient();

            var response = client.GetAsync(Configuration.Instance.GetDatabrickUrl() + Databrick.urlGetJobs).Result;

            if (!response.IsSuccessStatusCode)
            {
                throw new AzureNotValidException($"API Error: Can't get jobs in databrick job name {jobName}");
            }

            var result = JsonConvert.DeserializeObject<DataBrickJobs>(response.Content.ReadAsStringAsync().Result);

            foreach (var job in result.jobs)
            {
                if (job.settings.name == jobName)
                    return job.job_id;
            }

            throw new JobNotFoundException($"Can't found job {jobName} in databrick");
        }

        public async Task<Job> RunJobAsync(Job job)
        {
            //validator
            var plan = await _planService.GetParamsAsync(job.PlanId);
            if (plan == null)
            {
                throw new PlanNotFoundException();
            }

            //P
            job = await _jobService.CreateAsync(job);
            if (job == null)
            {
                throw new JobNotFoundException();
            }

            //Processing data
            string blobBaseUrl = $"{ Environment.Configuration.Instance.GetBlobInputUrl() }{ job.Id }/";
            var inputPath = Configuration.Instance.GetPath();

            //Cluster
            var clusters = await _locationService.ListClusterAsync();
            await this.UploadBlobAsync(new Uri($"{blobBaseUrl}{inputPath.ClusterFilename}"),
                                                _locationService.ListClusterBlobAsync(clusters));


            //tabular
            var tabulars = await _tabularService.ListCurrentlyAsync();
            await this.UploadBlobAsync(new Uri($"{blobBaseUrl}{inputPath.TabularFilename}"), _tabularService.ListBlobAsync(tabulars));

            var stacks = await _tabularService.ListStackAsync();
            await this.UploadBlobAsync(new Uri($"{blobBaseUrl}{inputPath.StackFilename}"), _tabularService.ListStackBlobAsync(stacks));


            //Get MMR
            var materials = plan.Tasks.Where(c => c.IsIncludeToCalculate == true);
            materials = _materialService.GetMaterialRequestsAsync(materials, clusters).ToList();
            await this.UploadBlobAsync(new Uri($"{blobBaseUrl}{inputPath.MMRFileName}"),
                                                _materialService.ListMaterialBlobAsync(materials));

            var vesselArrivals = await _vesselService.ListArrivalAsync(plan.PlanVessel.Id);
            var vessels = await _vesselService.EstimateTimeDepartureAsync(new VesselDepartureRequestParams { PlanId = job.PlanId, VesselArrivals = vesselArrivals });
            await this.UploadBlobAsync(new Uri($"{blobBaseUrl}{inputPath.VesselFileName}"),
                                                _vesselService.ListVesselBlobAsync(vessels));

            var vesselBookActivity = await _vesselService.ListEtaBookActivityAsync(vessels, plan.PlanResource);
            await this.UploadBlobAsync(new Uri($"{blobBaseUrl}{inputPath.VesselBookActivity}"),
                                                _vesselService.ListBookActivityBlobAsync(vesselBookActivity));

            var locationRestrictHour = plan.PlanLocation.LocationRestrictedHours;
            locationRestrictHour = locationRestrictHour.Where(c => c.IsTanker == false && c.IsIncludeToCalculate == true).ToList();
            await this.UploadBlobAsync(new Uri($"{blobBaseUrl}{inputPath.RestrictHourFileName}"),
                                                _locationService.ListRestrictedBlobAsync(locationRestrictHour));
            //Tanks
            var tankerBlockouts = plan.PlanLocation.TankSchedules;
            tankerBlockouts = tankerBlockouts.Where(c => c.IsTanker == true && c.IsIncludeToCalculate == true).ToList();

            //Cargo priority
            var cargoPlan = plan.OrderedCargo;
            //  var cargoCoefficient = await _cargoService.ListCargoCoefficientAsync();
            await this.UploadBlobAsync(new Uri($"{blobBaseUrl}{inputPath.CargoPriorityFileName}"),
                                                _cargoService.ListCargoBlobAsync(cargoPlan.Priorities));//, cargoCoefficient));

            //Current plan file closing_current_plan.csv
            var currentPlanBlockouts = await _vesselLocationService.ListVesselLocationBlockoutAsync();
            await this.UploadBlobAsync(new Uri($"{blobBaseUrl}{inputPath.LocationBlockoutFilename}"),
                                                _vesselLocationService.ListVesselLocationBlockoutBlobAsync(currentPlanBlockouts, tankerBlockouts));

            var vesselPlan = await _vesselService.ListCurrentRouteAsync();
            await this.UploadBlobAsync(new Uri($"{blobBaseUrl}{inputPath.VesselCurrentPlanFileName}"),
                                                _vesselService.ListCurrentPlanBlobAsync(vesselPlan));

            //Get Resource 
            var planLocation = plan.PlanLocation;
            var resource = plan.PlanResource;
            var model = await _paramService.GetRecentlyModelAsync();
            await this.UploadBlobAsync(new Uri($"{blobBaseUrl}{inputPath.ConfigParametersFileName}"),
                                                _planService.GetResourceBlobAsync(resource, planLocation, job, model));

            HttpClient client = this.HttpClient();

            var jobRequest = new JobRequest();

            jobRequest.job_id = GetDatabrickJob(Configuration.Instance.GetDatabrickJobName());

            jobRequest.notebook_params.Add("params",
                                    JsonConvert.SerializeObject(new JobParams
                                    {
                                        jobId = job.Id,
                                        planId = job.PlanId,
                                        url = Configuration.Instance.GetHostName()
                                    }));

            HttpContent httpContent = new StringContent(JsonConvert.SerializeObject(jobRequest));


            var response = client.PostAsync(Configuration.Instance.GetDatabrickUrl() + Databrick.urlRunJobNow, httpContent).Result;

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"API Error: Can't run job in databrick job id { jobRequest.job_id}");
            }

            var res = JsonConvert.DeserializeObject<JobResponse>(response.Content.ReadAsStringAsync().Result);
            job.Status = JobStatus.PENDING.GetDescription();
            job.RunId = res.run_id;

            //Update status
            job = await _jobService.UpdateAsync(job);

            this.AddMessage(JsonConvert.SerializeObject(job));

            //temp remove try
            // }
            // catch (Exception ex)
            // {
            //     job.RunMessage = $"{ex.Message}";
            //     job.Status = JobStatus.FAILED.GetDescription();
            //     job = await _jobService.UpdateAsync(job);

            //     throw ex;
            // }

            return job;
        }

        public async Task<Job> GetJobStatusAsync(Job job)
        {
            HttpClient client = this.HttpClient();
            var currentStatus = job.Status;
            var response = client.GetAsync(Configuration.Instance.GetDatabrickUrl() + $"{Databrick.urlGetRunStatus}?run_id={job.RunId}").Result;

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"API Error: Can't get job status in databrick job name { job.RunId}");
            }

            var result = JsonConvert.DeserializeObject<JobResponse>(response.Content.ReadAsStringAsync().Result);

            job.Status = GetJobDescription(!string.IsNullOrEmpty(result.state.result_state) ? result.state.result_state : result.state.life_cycle_state);

            var currentJob = await this._jobService.GetAsync(job.Id);
            if (string.IsNullOrEmpty(currentJob.RunMessage))
                job.RunMessage = result.state.state_message;

            if (currentStatus != job.Status)
                job = await this._jobService.UpdateAsync(job);

            return job;
        }

        private string GetJobDescription(string status)
        {
            switch (status)
            {
                case "PENDING":
                    return JobStatus.PENDING.GetDescription();
                case "SUCCESS":
                    return JobStatus.SUCCEEDED.GetDescription();
                case "TERMINATING":
                case "RUNNING":
                    return JobStatus.RUNNING.GetDescription();
                case "SKIPPED":
                    return JobStatus.SKIPPED.GetDescription();
                case "INTERNAL_ERROR":
                case "FAILED":
                case "TIMEDOUT":
                    return JobStatus.FAILED.GetDescription();
                case "CANCELED":
                    return JobStatus.CANCELED.GetDescription();
                default:
                    return "Unknow Status";
            }
        }

    }
    public interface IAzurePlanService
    {
        //Task<IEnumerable<FactoryLog>> ListSynceLogAsync();

    }

    public class AzurePlanService : IAzurePlanService
    {

        /* *private readonly IEntityService _entityService;

        public AzurePlanService(IEntityService entitySerivce)
        {
            _entityService = entitySerivce ?? throw new ArgumentNullException(nameof(entitySerivce));

        }

        public async Task<IEnumerable<FactoryLog>> ListSynceLogAsync()
        {
            var datafactLogs = await _entityService.ListDataFactoryLogAsync();

            var lastSyncs = new List<FactoryLog>();
            if (datafactLogs == null)
                return lastSyncs;

            lastSyncs = datafactLogs.GroupBy(c => new
            {
                c.SyncTable
            }).Select(
                          g => new FactoryLog
                          {
                              Table = g.First().SyncTable,
                              LastSync = g.Max(c => c.EndSync),
                              Status = g.OrderByDescending(c => c.EndSync).First().Status
                          }).ToList();

            return lastSyncs;
        }*/
    }





}