using System;

using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;

using Microsoft.AspNetCore.Http;
//Windows Authen

//configure
using Microsoft.Extensions.Configuration;
//logg
using Serilog;
//JSON manipulate

//http
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;
using cvx.lct.vot.api.Repositories;


using User = cvx.lct.vot.api.Models.User;
using Chevron.Identity.AspNet.Client;
using System.Security.Principal;
using Microsoft.AspNetCore.Authentication;

namespace cvx.lct.vot.api.Services
{

    public interface IUserService
    {
        //Task<User> LDAPAuthenAsync();

        Task<User> CreateAsync(User user);
        Task<User> UpdateAsync(User user);
        Task<User> DeleteAsync(string id);
        Task<User> GetAsync(string id);
        Task<User> EnforceUserExistenceAsync(string id);

        Task<User> AuthenAsync();


        // Task<User> GetAzureADUser();
        // bool IsAssignedAdGroup();
        Task<User> GetHttpCurrentUserAsync();

    }

    public class UserService : IUserService
    {

        private readonly IHttpContextAccessor _httpContextAccessor;


        private readonly IUserRepository _userRepository;
        private readonly ISessionLogRepository _sessionLogRepository;

        //     private readonly IUserService _userService;

        //private readonly Models.User httpCurrentUser;

        //  private const int TOKEN_EXPIRED_DAYS = 7;
        //private const int TOKEN_EXPIRED_SEC = 30;

        public UserService(IHttpContextAccessor httpContextAccessor, IUserRepository userRepository, ISessionLogRepository sessionLogRepository)//, IUserService httpService,
        {
            _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));

            //   _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
            _userRepository = userRepository ?? throw new ArgumentNullException(nameof(userRepository));
            _sessionLogRepository = sessionLogRepository ?? throw new ArgumentNullException(nameof(sessionLogRepository));
            // _userService = httpService ?? throw new ArgumentNullException(nameof(httpService));


            // httpCurrentUser = _userService.GetCurrentUserAsync().Result;


            //logg
            Log.Logger = new LoggerConfiguration()
                                .WriteTo.Console()
                                .CreateLogger();
        }


        //
        // Summary:
        //     Returns the http request api user from window credential
        //
        // Returns:
        //     Models.Entity.User object
        //
        // Type parameters:
        //   httpContext:
        //     a base of http context
        //
        /* /public async Task<User> GetHttpUserAsync()
        {
            await Task.Delay(0);
            throw new NotImplementedException();
        }*/

        public async Task<User> CreateAsync(User user)
        {
            await Task.Delay(0);
            throw new NotImplementedException();
        }


        public async Task<User> UpdateAsync(User _user)
        {
            var user = await this.EnforceUserExistenceAsync(_user.Id);

            await Task.Delay(0);
            throw new NotImplementedException();
        }

        public async Task<User> GetAsync(string id)
        {
            await Task.Delay(0);
            throw new NotImplementedException();
        }

        public async Task<User> DeleteAsync(string id)
        {
            await this.EnforceUserExistenceAsync(id);

            await Task.Delay(0);
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<User>> ListAsync()
        {
            return await _userRepository.ListAsync();
        }



        //
        // Summary:
        //     Return the list of authorize role/project  if token is valid
        //
        // Returns:
        //     User object
        //
        // Type parameters:
        //   token:
        //      azure AD token
        //
        public async Task<User> AuthenAsync()
        {
            await Task.Delay(0);
            throw new NotImplementedException();
        }


        public async Task<User> EnforceUserExistenceAsync(string id)
        {
            var user = await _userRepository.GetAsync(id);

            if (user == null)
            {
                //throw new UserNotFoundException();
            }

            return user;
        }

        public async Task<Models.User> GetAzureADUser()
        {
            await Task.Delay(0);
            IPrincipal principal = _httpContextAccessor.HttpContext.User;

            var CliamUser = new CvxClaimsPrincipal(principal);
            var entity = new Models.User
            {
                ObjectId = CliamUser.ObjectId,
                Name = CliamUser.Name,
                LastName = CliamUser.LogonName,
                Email = CliamUser.Email,
                CAI = CliamUser.Cai,
                Unique = CliamUser.Email
            };

            return entity;
        }

        //
        // Summary:
        //     Returns the http request api user from window credential
        //
        // Returns:
        //     Models.Entity.Http object
        //
        // Type parameters:
        //   httpContext:
        //     a base of http context
        //
        public async Task<User> GetHttpCurrentUserAsync()
        {
            await Task.Delay(0);
            // string mode = _configuration["AppSettings:AuthenticationMode"];
            var entity = new User() { Id = "anonymously", DisplayName = "anonymously", Unique = "anonymously" };
            var httpContext = _httpContextAccessor.HttpContext;


            //var accessToken = new JwtSecurityToken(jwtEncodedString: token.AccessToken);
            //var id = accessToken.Claims.First(c => c.Type == "unique_name").Value;

            var accessToken = await httpContext.GetTokenAsync("access_token");
            if (accessToken != null)
            {
                entity.AccessToken = accessToken;
            }

            //var claimsIdentity = Http.Identity as ClaimsIdentity;

            // alternatively
            // claimsIdentity = HttpContext.Http.Identity as ClaimsIdentity;

            // get some claim by type
            // var someClaim = Http.Claims.FirstOrDefault(c => c.Type == "Currency").Value;

            //  iterate all claims
            /*foreach (var claim in claimsIdentity.Claims)
            {
                Log.Information(claim.Type + ":" + claim.Value);
            }*/

            entity = await this.GetAzureADUser();

            var sid = httpContext.User.Claims.FirstOrDefault(c => c.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name");
            if (sid != null)
            {
                entity.Unique = sid.Value;
                entity.Name = httpContext.User.Claims.FirstOrDefault(c => c.Type == "name").Value;

            }
            entity.Id = httpContext.User.Claims.FirstOrDefault(c => c.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier").Value;

            return entity;
        }

    }
}