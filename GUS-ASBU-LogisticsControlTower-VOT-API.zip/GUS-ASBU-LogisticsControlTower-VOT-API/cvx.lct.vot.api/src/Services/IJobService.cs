using System;

using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;
using cvx.lct.vot.api.Environment;
using cvx.lct.vot.api.Exceptions;
using cvx.lct.vot.api.Extensions;

//vot
using cvx.lct.vot.api.Models;
using cvx.lct.vot.api.Models.Gateway;
using cvx.lct.vot.api.Repositories;
using Newtonsoft.Json;

//logg
using Serilog;

using PLAN = cvx.lct.vot.api.Models.Constant.Plan;
using BRICK = cvx.lct.vot.api.Models.Constant.Databrick;
using System.Net.Http.Headers;
using surflex.netcore22.Models.DTO;

namespace cvx.lct.vot.api.Services
{

    public interface IJobService
    {
        Task<Job> CreateAsync(Job job);
        Task<Job> UpdateAsync(Job job);

        Task<Job> GetAsync(Guid id);

        Task<IEnumerable<Job>> ListRecentAsync();

        Task<IEnumerable<Job>> ListAsync();
        Task<IEnumerable<Job>> ListProgressAsync();
        //     Task<IEnumerable<JobParams>> ListParamsAsync();
        Task<Job> EnforceJobExistenceAsync(Guid id);

    }

    public class JobService : IJobService
    {
        private readonly IJobRepository _jobRepository;

        //  private readonly IRunParameterRepository _runParameterRepository;

        private readonly IWorkUnitExtension _workUnitService;
        private readonly IPlanJobService _planService;
        private readonly IUserService _userService;
        private readonly User httpCurrentUser;

        public JobService(IJobRepository jobRepository, IUserService userService, IPlanJobService planService,
                        ITravelRepository resultRepository, ITravelRouteRepository travelRouteRepository,
                        ITravelLoadedRepository travelLoadedRepository,
                        IWorkUnitExtension workUnitExtension)
        {
            _jobRepository = jobRepository ?? throw new ArgumentNullException(nameof(jobRepository));
            //     _runParameterRepository = runParameterRepository ?? throw new ArgumentNullException(nameof(runParameterRepository));

            _planService = planService ?? throw new ArgumentNullException(nameof(planService));
            _userService = userService ?? throw new ArgumentNullException(nameof(userService));
            _workUnitService = workUnitExtension ?? throw new ArgumentNullException(nameof(workUnitExtension));

            httpCurrentUser = _userService.GetHttpCurrentUserAsync().Result;

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }


        private HttpClient HttpClient()
        {
            var httpClientHandler = new HttpClientHandler();

            // Omit this part if you don't need to authenticate with the web server:
            httpClientHandler.DefaultProxyCredentials = System.Net.CredentialCache.DefaultNetworkCredentials;

            HttpClient client = new HttpClient(handler: httpClientHandler, disposeHandler: true);
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Configuration.Instance.GetDatabrickToken());
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            return client;
        }


        public async Task<Job> CreateAsync(Job job)
        {

            //check id of base job
            job.Id = Guid.NewGuid();
            job.Date = DateTime.UtcNow;
            job.UpdatedDate = DateTime.UtcNow;
            job.By = httpCurrentUser.Unique;
            job.Status = JobStatus.PENDING.GetDescription();


            //await EnforceClanExistenceAsync(Job.Clan.Name);
            var entity = await _jobRepository.CreateAsync(job);
            if (entity == null)
            {
                throw new JobNotFoundException(job.Id);
            }

            return entity;
        }


        public async Task<Job> UpdateAsync(Job job)
        {
            var updated = await this.EnforceJobExistenceAsync(job.Id);

            //assigned
            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //job.Key = Guid.NewGuid().ToString();

            var entity = await _jobRepository.UpdateAsync(job);
            if (entity == null)
            {
                throw new JobNotFoundException(job.Id);
            }

            return entity;
        }

        public async Task<Job> GetAsync(Guid id)
        {
            //  await this.EnforceJobExistenceAsync(id);

            var entity = await _jobRepository.GetAsync(id);
            return entity;
        }




        /* *public async Task<Job> DeleteAsync(Guid id)
        {
            await this.EnforceJobExistenceAsync(id);

            var deletedJob = await _jobRepository.DeleteAsync(id);
            return deletedJob;
        }*/

        public async Task<IEnumerable<Job>> ListAsync()
        {
            return await _jobRepository.ListAsync();
        }


        public async Task<IEnumerable<Job>> ListRecentAsync()
        {
            var entity = await _jobRepository.ListAsync();

            return entity.OrderByDescending(c => c.Date); //.Take(5);

        }


        public async Task<Job> EnforceJobExistenceAsync(Guid id)
        {
            var entity = await _jobRepository.GetAsync(id);
            if (entity == null)
            {
                throw new JobNotFoundException();
            }

            return entity;
        }

        public async Task<IEnumerable<Job>> ListProgressAsync()
        {
            var entities = await _jobRepository.ListAsync();
            entities = entities.Where(c => c.Status != JobStatus.SUCCEEDED.GetDescription());
            return entities;
        }


        public async Task<Job> GetJobStatusAsync(Job job)
        {
            var client = this.HttpClient();
            var currentStatus = job.Status;
            var response = client.GetAsync(Configuration.Instance.GetDatabrickUrl() + $"{BRICK.urlGetRunStatus}?run_id={job.RunId}").Result;

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"API Error: Can't get job status in databrick job name { job.RunId}");
            }

            var result = JsonConvert.DeserializeObject<JobResponse>(response.Content.ReadAsStringAsync().Result);

            //job.Status = this.GetDescriptionAsync();
            var state = !string.IsNullOrEmpty(result.state.result_state) ? result.state.result_state : result.state.life_cycle_state;

            switch (state)
            {
                case "PENDING":
                    job.Status = JobStatus.PENDING.GetDescription();
                    break;
                case "SUCCESS":
                    job.Status = JobStatus.SUCCEEDED.GetDescription();
                    break;
                case "TERMINATING":
                case "RUNNING":
                    job.Status = JobStatus.RUNNING.GetDescription();
                    break;
                case "SKIPPED":
                    job.Status = JobStatus.SKIPPED.GetDescription();
                    break;
                case "INTERNAL_ERROR":
                case "FAILED":
                case "TIMEDOUT":
                    job.Status = JobStatus.FAILED.GetDescription();
                    break;
                case "CANCELED":
                    job.Status = JobStatus.CANCELED.GetDescription();
                    break;
                default:
                    job.Status = "Unknow Status";
                    break;
            }

            var currentJob = await this.GetAsync(job.Id);
            if (string.IsNullOrEmpty(currentJob.RunMessage))
                job.RunMessage = result.state.state_message;

            if (currentStatus != job.Status)
                job = await this.UpdateAsync(job);

            return job;
        }
    }


    public interface IJobHubService
    {
        Task<IEnumerable<Models.Gateway.JobParams>> ListParamsAsync(int? days = null);

        Task<Models.Gateway.JobParams> GetRecentlyParamsAsync(Guid id);
    }

    public class JobHubService : IJobHubService
    {
        private readonly IJobRepository _jobRepository;
        private const int NOTIFICATION_TIMESAPN_IN_DAYS = -7;
        private readonly IPlanJobService _planService;

        public JobHubService(IJobRepository jobRepository, IPlanJobService planService)
        {
            _jobRepository = jobRepository ?? throw new ArgumentNullException(nameof(jobRepository));
            _planService = planService ?? throw new ArgumentNullException(nameof(planService));

        }


        //
        // Summary:
        //    return recently a job with time elapse of current plan
        //
        // Returns:
        //
        //   job
        //
        // Type parameters:
        //   id:
        //      current plan id
        //
        public async Task<Models.Gateway.JobParams> GetRecentlyParamsAsync(Guid id)
        {
            //get job with current status
            var entities = await _jobRepository.ListAsync();
            var job = entities.OrderByDescending(c => c.Date).Where(c => c.PlanId == id).FirstOrDefault();
            if (job == null)
            {
                job = PLAN.DEFAULT_RUNNNING_JOB;
            }

            var entity = new Models.Gateway.JobParams()
            {
                Id = Guid.NewGuid(),
                JobId = job.Id,
                RunId = job.RunId,
                //PlanName = "DefaultPlanned",
                //PlanRemark =

                Date = job.Date.GetValueOrDefault(),
                By = job.By,
                JobStatus = job.Status,

                IsUnread = false, // job.IsUnread;
                RunMessage = job.RunMessage,

                //for display
                ExecuteTime = job.ExecuteTime,
                SolutionLimit = job.SolutionLimit,

            };

            //running
            if (job.Status == JobStatus.PENDING.GetDescription() || job.Status == JobStatus.RUNNING.GetDescription())
            {
                entity.TimeElapsed = DateTime.UtcNow.Subtract(job.Date.GetValueOrDefault());
            }
            //succecd or fail
            else
            {
                entity.TimeElapsed = job.UpdatedDate.GetValueOrDefault().Subtract(job.Date.GetValueOrDefault());
            }

            if (entity.TimeElapsed.Minutes > 0) entity.TimeElapsedDisplay = entity.TimeElapsedDisplay + String.Format("{0}m ", entity.TimeElapsed.Minutes);
            entity.TimeElapsedDisplay = entity.TimeElapsedDisplay + String.Format("{0}s", entity.TimeElapsed.Seconds);


            return entity;
        }


        //
        // Summary:
        //    return a list of job notification with time elapse of current plan
        //
        // Returns:
        //
        //   list of job
        //
        public async Task<IEnumerable<Models.Gateway.JobParams>> ListParamsAsync(int? days = null)
        {
            // const string COMPLETE_JOB_MESSAGE_PATTERN = "Manually triggered plan [{0}] instance is {1} ";
            var dasy = days == null ? NOTIFICATION_TIMESAPN_IN_DAYS : days.GetValueOrDefault();

            var entity = await _jobRepository.ListPreviouslyAsync(dasy);

            entity = entity.OrderByDescending(c => c.Date);

            var entities = new List<Models.Gateway.JobParams>();
            foreach (var j in entity)
            {
                var param = new Models.Gateway.JobParams()
                {
                    Id = Guid.NewGuid(),
                    JobId = j.Id,
                    //PlanName = "DefaultPlanned",
                    //PlanRemark =

                    Date = j.Date.GetValueOrDefault(),
                    By = j.By,
                    JobStatus = j.Status,
                    RunId = j.RunId,

                    IsUnread = false, // j.IsUnread;
                    RunMessage = j.RunMessage,

                    //for display
                    ExecuteTime = j.ExecuteTime,
                    SolutionLimit = j.SolutionLimit,


                };

                //running
                if (j.Status == JobStatus.PENDING.GetDescription() || j.Status == JobStatus.RUNNING.GetDescription())
                {
                    param.TimeElapsed = DateTime.UtcNow.Subtract(j.Date.GetValueOrDefault());
                }
                //succecd or fail
                else
                {
                    param.TimeElapsed = j.UpdatedDate.GetValueOrDefault().Subtract(j.Date.GetValueOrDefault());
                }

                if (param.TimeElapsed.Minutes > 0) param.TimeElapsedDisplay = param.TimeElapsedDisplay + String.Format("{0}m ", param.TimeElapsed.Minutes);
                param.TimeElapsedDisplay = param.TimeElapsedDisplay + String.Format("{0}s", param.TimeElapsed.Seconds);

                //flag is read
                //var notii = await _notiRepository.ListAsync();
                //param.IsUnread =

                //planname
                var plan = await _planService.GetPlanAsync(j.PlanId);
                if (plan != null)
                {
                    param.PlanName = plan.Name;
                    param.PlanRemark = plan.Remark;
                    //  param.Message = plan
                }

                //construct message
                //  param.Message = String.Format(COMPLETE_JOB_MESSAGE_PATTERN, param.PlanName, param.JobStatus, param.jobId);

                entities.Add(param);
            }

            return entities;
        }

    }

}