using System;

using System.Collections.Generic;
using System.IO;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;
using AutoMapper;
using cvx.lct.vot.api.APIs.Services;
using cvx.lct.vot.api.Exceptions;
using cvx.lct.vot.api.Extensions;
using cvx.lct.vot.api.Mapper;

//vot
using cvx.lct.vot.api.Models;
using cvx.lct.vot.api.Repositories;

//logg
using Serilog;


using BLOB = cvx.lct.vot.api.Models.Constant.Blob;
using LOCATION = cvx.lct.vot.api.Models.Constant.Location;

namespace cvx.lct.vot.api.Services
{

    public interface IMaterialService
    {
        Task<Material> CreateAsync(Material material);
        Task<Material> UpdateAsync(Material material);

        Task<Material> GetAsync(Guid id);

        Task<IEnumerable<Material>> ListAsync();
        Task<IEnumerable<MaterialRequest>> ListTaskAsync(Guid id);
        Task<IEnumerable<MaterialRequest>> ListRequestAsync(Guid id);

        Task<Material> EnforceMaterialExistenceAsync(Guid id);
        Task<MaterialRequest> EnforceTaskExistenceAsync(Guid id);
        //Task<IEnumerable<MaterialRequest>> ListRecentlyTaskAsync();

        Task<IEnumerable<MaterialRequest>> SynceTaskAsync();


        IEnumerable<MaterialRequest> GetMaterialRequestsAsync(IEnumerable<MaterialRequest> materialRequests, IEnumerable<Location> locations);

        Stream ListMaterialBlobAsync(IEnumerable<MaterialRequest> materials);
    }

    public class MaterialService : IMaterialService
    {
        private readonly IMaterialRepository _materialRepository;
        private readonly IMaterialRequestRepository _materialRequestRepository;
        // Create a field to store the mapper object
        private readonly IMapper _mapper;

        // Assign the object in the constructor for dependency injection

        // private readonly IEntityService _entitySerivce;
        private readonly IClientService _clientService;

        public MaterialService(IMaterialRepository materialRepository, IMaterialRequestRepository MaterialRequestRepository, IClientService clientService,
                //IEntityService entitySerivce, 
                IMapper mapper)
        {
            _materialRepository = materialRepository ?? throw new ArgumentNullException(nameof(materialRepository));
            _materialRequestRepository = MaterialRequestRepository ?? throw new ArgumentNullException(nameof(MaterialRequestRepository));
            _clientService = clientService ?? throw new ArgumentNullException(nameof(clientService));

            _mapper = mapper;

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }

        public Stream ListMaterialBlobAsync(IEnumerable<MaterialRequest> materials)
        {
            var stream = new MemoryStream();

            var headers = new List<string>
            {
                "MMRId",
                "MMRDetailId",
                "PlanDispatchDate",
                "ROS Date",
                "ItemType",
                "Department",
                "Priority",
                "Item Status",
                "Material Description",
                "From",
                "To",
                "FromCluster",
                "ToCluster",
                "LocationType",
                "LocationCategory",
                "Quantity Value",
                "QuantityUnit",
                "TotalWeight",
                "Length(m)",
                "Width(m)",
                "Height(m)",
                "Area(sq.m)",

                //for group asster dor platform
                "Asset",
                "OrderNumber"
            };

            //Header columns
            string headerLine = $"{string.Join(BLOB.CsvDelimiter, headers.ToArray())}\n";

            stream.Write(BLOB.Encoding.GetBytes(headerLine), 0, BLOB.Encoding.GetBytes(headerLine).Length);

            //Records
            foreach (var m in materials)
            {
                var entity = new List<string>();
                entity.Add(m.LCTMRMaterialRequestId.ToString());
                entity.Add(m.LCTMRMaterialRequestDetailsId.ToString());
                entity.Add(m.PlannedDispatchDate.ToString());
                entity.Add(String.Format("{0:M/d/yyyy}", m.ROSDate));
                entity.Add(m.ItemType);
                entity.Add(m.Department);
                entity.Add(m.Priority);
                entity.Add(m.Status);
                entity.Add(m.Description.Replace("\n", " ").Replace("\r", "").StripIncompatableQuotes());
                entity.Add(m.From);
                entity.Add(m.To);
                entity.Add(m.FromCluster);
                entity.Add(m.ToCluster);

                entity.Add(m.DestinationType);

                entity.Add(m.DestinationCategory);
                entity.Add(m.QuantityValue.ToString());
                entity.Add(m.QuantityUnit);
                entity.Add(m.Weight.ToString());
                entity.Add(m.Length.ToString());
                entity.Add(m.Width.ToString());
                entity.Add(m.Height.ToString());
                entity.Add(m.Area.ToString());

                //for group asster dor platform
                entity.Add(m.Asset.ToString());

                entity.Add(m.LCTOrderNumber);

                var valueLine = $"{string.Join(BLOB.CsvDelimiter, entity.toReplaceArray())}\n";

                stream.Write(BLOB.Encoding.GetBytes(valueLine), 0, BLOB.Encoding.GetBytes(valueLine).Length);
            }

            stream.Position = 0;
            return stream;
        }


        public async Task<Material> CreateAsync(Material material)
        {
            material.Id = Guid.NewGuid();
            material.Date = DateTime.UtcNow;

            //await EnforceClanExistenceAsync(Material.Clan.Name);
            var entity = await _materialRepository.CreateAsync(material);
            if (entity == null)
            {
                throw new MaterialNotFoundException(material.Id);
            }

            return entity;
        }


        public async Task<MaterialRequest> CreateAsync(MaterialRequest material)
        {
            material.Id = Guid.NewGuid();
            material.Date = DateTime.UtcNow;

            //await EnforceClanExistenceAsync(Material.Clan.Name);
            var entity = await _materialRequestRepository.CreateAsync(material);
            if (entity == null)
            {
                throw new MaterialNotFoundException(material.Id);
            }

            return entity;
        }



        public async Task<Material> UpdateAsync(Material material)
        {
            var updated = await this.EnforceMaterialExistenceAsync(material.Id);

            //assigned
            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //material.Key = Guid.NewGuid().ToString();

            var entity = await _materialRepository.UpdateAsync(material);
            if (entity == null)
            {
                throw new MaterialNotFoundException(material.Id);
            }

            return entity;
        }

        public async Task<Material> GetAsync(Guid id)
        {
            //  await this.EnforceMaterialExistenceAsync(id);

            var entity = await _materialRepository.GetAsync(id);
            return entity;
        }


        private async Task<string> GetLoadingTypeAsync(int id)
        {
            await Task.Delay(0);
            if (LOCATION.TERMINALS.ContainsKey(id))
            {
                return BoundType.OFFLOAD.GetDescription();
            }

            return BoundType.BACKLOAD.GetDescription();
        }


        //synce
        public async Task<IEnumerable<MaterialRequest>> SynceTaskAsync()
        {
            var entity = await _clientService.ListTaskAsync();

            if (entity == null)
            {
                throw new MaterialNotFoundException();
            }

            var mapped = _mapper.Map<IEnumerable<MaterialRequest>>(entity);

            //default check and map bound type
            mapped = mapped.Select(c =>
                    {
                        c.Id = Guid.NewGuid(); c.IsIncludeToCalculate = true;
                        c.BoundType = this.GetLoadingTypeAsync(c.LCTOriginReferenceId.GetValueOrDefault()).Result;
                        return c;
                    }).ToList();

            return mapped; //.OrderBy(c => c.ROSDate).ThenBy(c => c.From).ThenBy(c => c.To);
        }

        //by plan id
        public async Task<IEnumerable<MaterialRequest>> ListTaskAsync(Guid id)
        {
            var entity = await _materialRequestRepository.ListAsync(id);
            //entity = entity.Where(c => c.PlanId == id);

            //map bound type
            /* entity = entity.Select(c =>
            {
                c.BoundType = this.GetLoadingTypeAsync(c.LCTOriginReferenceId.GetValueOrDefault()).Result;
                return c;
            }).ToList();*/

            return entity; //.OrderBy(c => c.ROSDate).ThenBy(c => c.From).ThenBy(c => c.To);
        }

        public async Task<IEnumerable<MaterialRequest>> ListRequestAsync(Guid id)
        {
            var entity = await _materialRequestRepository.ListAsync(id);
            //entity = entity.Where(c => c.PlanId == id);

            return entity;
        }


        /* *public async Task<Material> DeleteAsync(Guid id)
        {
            await this.EnforceMaterialExistenceAsync(id);

            var deletedMaterial = await _materialRepository.DeleteAsync(id);
            return deletedMaterial;
        }*/

        public async Task<IEnumerable<Material>> ListAsync()
        {
            return await _materialRepository.ListAsync();
        }

        public async Task<IEnumerable<MaterialRequest>> ListRecentlyTaskAsync()
        {
            return await _materialRequestRepository.ListRecentlyAsync();
        }

        public async Task<Material> EnforceMaterialExistenceAsync(Guid id)
        {
            var entity = await _materialRepository.GetAsync(id);
            if (entity == null)
            {
                throw new MaterialNotFoundException();
            }

            return entity;
        }


        public async Task<MaterialRequest> EnforceTaskExistenceAsync(Guid id)
        {
            var entity = await _materialRequestRepository.GetAsync(id);
            if (entity == null)
            {
                throw new MaterialNotFoundException(id);
            }

            return entity;
        }

        // moved from process data
        public IEnumerable<MaterialRequest> GetMaterialRequestsAsync(IEnumerable<MaterialRequest> materialRequests, IEnumerable<Location> locations)
        {
            var entities = new List<MaterialRequest>();
            foreach (var m in materialRequests)
            {

                //mapping location cluser
                var from = locations.Where(c => c.ChildLocationLCTReferenceId == m.LCTOriginReferenceId).FirstOrDefault();
                if (from == null)
                    throw new LocationNotFoundException($"GetMaterialRequestsAsync: Can not found location cluster {m.LCTOriginReferenceId}");

                m.FromCluster = from.ClusterCode;

                var to = locations.Where(c => c.ChildLocationLCTReferenceId == m.LCTDestinationReferenceId).FirstOrDefault();
                if (to == null)
                    throw new LocationNotFoundException($"GetMaterialRequestsAsync: Can not found location cluster {m.LCTDestinationReferenceId}");

                m.ToCluster = to.ClusterCode;
                //  m.DestinationType = to.Type;

                //mapping asset logic
                var dorPlatform = locations.Where(c => c.DORPlatformId == from.DORPlatformId).FirstOrDefault();

                //switch to (one of two must be jetty)
                var terminals = LOCATION.TERMINALS.Values.ToArray();
                if (terminals.Contains(from.ClusterCode))
                {
                    //set dor
                    dorPlatform = locations.Where(c => c.DORPlatformId == to.DORPlatformId).FirstOrDefault();

                    //set location type
                    m.DestinationType = to.Type;
                    m.DestinationCategory = to.Category;
                }

                if (terminals.Contains(to.ClusterCode))
                {
                    //set location type
                    m.DestinationType = from.Type;
                    m.DestinationCategory = from.Category;
                }


                //assign
                if (dorPlatform != null)
                {
                    m.Asset = dorPlatform.Asset;
                }

                entities.Add(m);
            }

            return entities;
        }

    }
}