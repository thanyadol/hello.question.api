using System;

using System.Collections.Generic;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;
using cvx.lct.vot.api.Exceptions;
using cvx.lct.vot.api.Extensions;

//vot
using cvx.lct.vot.api.Models;
using cvx.lct.vot.api.Repositories;


using CARGO = cvx.lct.vot.api.Models.Constant.Cargo;
using BLOB = cvx.lct.vot.api.Models.Constant.Blob;

//logg
using Serilog;
using System.IO;
using System.Text;

namespace cvx.lct.vot.api.Services
{

    public interface ICargoService
    {
        Task<Cargo> CreateAsync(Cargo cargo);
        Task<Cargo> UpdateAsync(Cargo cargo);

        Task<Cargo> GetAsync(Guid id);

        Task<IEnumerable<Cargo>> ListRecentAsync();

        Task<IEnumerable<Cargo>> ListAsync();
        Task<Cargo> EnforceCargoExistenceAsync(Guid id);
        Task<CargoPriority> EnforcePriorityExistenceAsync(Guid id);

        //Task<PlanCargo> GetPriorityAsync(Guid id);
        Task<IEnumerable<CargoPriority>> ListPriorityAsync(Guid id);
        //  Task<IEnumerable<CargoCoefficient>> ListCargoCoefficientAsync();

        Stream ListCargoBlobAsync(IEnumerable<CargoPriority> priorities);//, IEnumerable<CargoCoefficient> cargoCoefficients);

    }

    public class CargoService : ICargoService
    {
        private readonly ICargoRepository _cargoRepository;

        private readonly ICargoPriorityRepository _cargoPriorityRepository;

        // public Encoding Encoding { get; set; } = BLOB.Encoding.UTF8;

        public CargoService(ICargoPriorityRepository cargoPriorityRepository, ICargoRepository cargoRepository)
        {
            _cargoRepository = cargoRepository ?? throw new ArgumentNullException(nameof(cargoRepository));
            _cargoPriorityRepository = cargoPriorityRepository ?? throw new ArgumentNullException(nameof(cargoPriorityRepository));

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }


        public Stream ListCargoBlobAsync(IEnumerable<CargoPriority> priorities)//, IEnumerable<CargoCoefficient> cargoCoefficients)
        {
            var stream = new MemoryStream();
            var headers = new List<string>
            {
                "Id",
                "Order",
                "LocationType",
                "BoundType",
                "Priority",
                "Coefficient",
            };

            //Header columns
            string headerLine = $"{string.Join(BLOB.CsvDelimiter, headers.ToArray())}\n";
            stream.Write(BLOB.Encoding.GetBytes(headerLine), 0, BLOB.Encoding.GetBytes(headerLine).Length);

            //Records
            foreach (var v in priorities)
            {
                /*var coefficient = cargoCoefficients.Where(c => c.SequenceNumber == v.Order).FirstOrDefault();
                if (coefficient == null)
                    throw new Exception($"Can't find cargo coefficient {v.Order}");*/

                var lstV = new List<string>();
                lstV.Add(v.Id.ToString());
                lstV.Add(v.Order.ToString());
                lstV.Add(v.LocationType);
                lstV.Add(v.BoundType);
                lstV.Add(v.Priority);

                lstV.Add(v.NormalizedCoefficient.ToString());

                var valueLine = $"{string.Join(BLOB.CsvDelimiter, lstV.toReplaceArray())}\n";

                stream.Write(BLOB.Encoding.GetBytes(valueLine), 0, BLOB.Encoding.GetBytes(valueLine).Length);
            }

            stream.Position = 0;
            return stream;
        }


        public async Task<Cargo> CreateAsync(Cargo cargo)
        {
            //check id of base cargo
            cargo.Id = Guid.NewGuid();
            cargo.Date = DateTime.UtcNow;
            cargo.By = "admin";

            //await EnforceClanExistenceAsync(Cargo.Clan.Name);
            var entity = await _cargoRepository.CreateAsync(cargo);
            if (entity == null)
            {
                throw new CargoNotFoundException(cargo.Id);
            }

            return entity;
        }

        public async Task<Cargo> UpdateAsync(Cargo cargo)
        {
            var updated = await this.EnforceCargoExistenceAsync(cargo.Id);

            //assigned
            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //cargo.Key = Guid.NewGuid().ToString();

            var entity = await _cargoRepository.UpdateAsync(cargo);
            if (entity == null)
            {
                throw new CargoNotFoundException(cargo.Id);
            }

            return entity;
        }

        public async Task<Cargo> GetAsync(Guid id)
        {
            //  await this.EnforceCargoExistenceAsync(id);

            var entity = await _cargoRepository.GetAsync(id);
            return entity;
        }


        /* *public async Task<Cargo> DeleteAsync(Guid id)
        {
            await this.EnforceCargoExistenceAsync(id);

            var deletedCargo = await _cargoPriorityRepository.DeleteAsync(id);
            return deletedCargo;
        }*/

        public async Task<IEnumerable<Cargo>> ListAsync()
        {
            return await _cargoRepository.ListAsync();
        }


        public async Task<IEnumerable<Cargo>> ListRecentAsync()
        {
            var entity = await _cargoRepository.ListAsync();

            return entity.OrderByDescending(c => c.Date); //.Take(5);

        }


        public async Task<Cargo> EnforceCargoExistenceAsync(Guid id)
        {
            var entity = await _cargoRepository.GetAsync(id);
            if (entity == null)
            {
                throw new CargoNotFoundException();
            }

            return entity;
        }


        public async Task<CargoPriority> EnforcePriorityExistenceAsync(Guid id)
        {
            var entity = await _cargoPriorityRepository.GetAsync(id);
            if (entity == null)
            {
                throw new CargoNotFoundException();
            }

            return entity;
        }

        //
        // Summary:
        //     retrun and list veesel congih
        //
        // Returns:
        //
        //   Vessel Variation   model
        //
        // Type parameters:
        //   id:
        //     vessel info  id
        //
        public async Task<IEnumerable<CargoPriority>> ListPriorityAsync(Guid id)
        {
            var entity = await _cargoPriorityRepository.ListAsync();

            entity = entity.Where(c => c.PlanCargoId == id)
                    //mapping dialay vaue
                    .Select(c => { c.LocationTypeDisplay = CARGO.LOCATION[c.LocationType]; c.BoundTypeDisplay = CARGO.BOUND[c.BoundType]; return c; }).ToList();

            return entity.OrderBy(c => c.Order).ToList();
        }

        /* public async Task<IEnumerable<CargoCoefficient>> ListCargoCoefficientAsync()
        {
            var entity = await _cargoRepository.ListCargoCoefficientAsync();

            return entity.OrderBy(c => c.SequenceNumber).ToList();
        }*/


    }

}