using System;

using System.Collections.Generic;
using System.IO;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;
using cvx.lct.vot.api.Exceptions;
using cvx.lct.vot.api.Extensions;

//vot
using cvx.lct.vot.api.Models;
using cvx.lct.vot.api.Repositories;
using FluentValidation;
using FluentValidation.Results;

//logg
using Serilog;

using VESSEL = cvx.lct.vot.api.Models.Constant.Vessel;
using PLAN = cvx.lct.vot.api.Models.Constant.Plan;
using BLOB = cvx.lct.vot.api.Models.Constant.Blob;
using cvx.lct.vot.api.APIs.Services;

namespace cvx.lct.vot.api.Services
{

    public interface IPlanService
    {
        Task<Plan> CreateAsync(Plan plan);
        Task<Plan> UpdateAsync(Plan plan);

        Task<Plan> GetAsync(Guid id);

        Task<IEnumerable<Plan>> ListRecentAsync();

        Task<IEnumerable<Plan>> ListAsync();
        Task<Plan> EnforcePlanExistenceAsync(Guid id);
        Task<PlanResource> EnforceResourceExistenceAsync(Guid id);

        Task<Plan> BatchCreateAsync(PlanParams plan);
        Task<Plan> BatchUpdateAsync(PlanParams plan);

        Task<Plan> GetRecentlyAsync(Guid id);

        Task<PlanCargo> GetCargoAsync(Guid id);
        Task<PlanLocation> GetLocationAsync(Guid id);
        // Task<PlanVessel> GetVesselAsync(Guid id);

        // Task<Plan> SynceAsync();
        Task<PlanResource> GetResourceAsync(Guid id);

        Task<PlanParams> GetParamsAsync(Guid id);
        Task<ValidationResult> ValidateParamsAsync(Guid id);
        //  Task<Plan> GetPublishWeekAsync(int week, int year);
        Stream GetResourceBlobAsync(PlanResource resource, PlanLocation location, Job runtime, ModelParameter model);

        Task<Plan> SynceAsync();
        Task<Plan> BatchDefaultAsync(PlanParams plan);
    }

    public class PlanService : IPlanService
    {
        private readonly IPlanRepository _planRepository;

        private readonly IWorkUnitExtension _workUnitService;

        private readonly IPlanCargoRepository _planCargoRepository;
        private readonly IPlanLocationRepository _locationRepository;

        private readonly IPlanResourceRepository _planResourceRepository;

        private readonly IVesselService _vesselService;
        private readonly ILocationService _locationService;
        private readonly ICargoService _cargoService;
        private readonly IAzurePlanService _azureService;

        private readonly IMaterialService _materialService;
        private readonly IPlanJobService _jobService;
        private readonly IUserService _userService;


        private readonly IClientService _clientService;
        private readonly AbstractValidator<PlanParams> _planValidator;

        private readonly User httpCurrentUser;


        public PlanService(IPlanRepository planRepository, IPlanCargoRepository planCargoRepository, IPlanLocationRepository locationRepository,
                IPlanVesselRepository planVesselRepository, IWorkUnitExtension workUnitService, IVesselService vesselService,
                ILocationService locationService, ICargoService cargoService, IPlanResourceRepository planResourceRepository, IPlanJobService jobService,
                IUserService httpService, IMaterialService materialService, AbstractValidator<PlanParams> planValidator,
                IAzurePlanService azureService, IClientService clientService)
        {
            _planRepository = planRepository ?? throw new ArgumentNullException(nameof(planRepository));

            _planCargoRepository = planCargoRepository ?? throw new ArgumentNullException(nameof(planCargoRepository));
            _locationRepository = locationRepository ?? throw new ArgumentNullException(nameof(locationRepository));

            _planResourceRepository = planResourceRepository ?? throw new ArgumentNullException(nameof(planResourceRepository));

            _vesselService = vesselService ?? throw new ArgumentNullException(nameof(vesselService));
            _locationService = locationService ?? throw new ArgumentNullException(nameof(locationService));
            _cargoService = cargoService ?? throw new ArgumentNullException(nameof(cargoService));

            _azureService = azureService ?? throw new ArgumentNullException(nameof(azureService));

            _materialService = materialService ?? throw new ArgumentNullException(nameof(materialService));
            _jobService = jobService ?? throw new ArgumentNullException(nameof(jobService));
            _userService = httpService ?? throw new ArgumentNullException(nameof(httpService));

            _planValidator = planValidator ?? throw new ArgumentNullException(nameof(planValidator));
            _workUnitService = workUnitService ?? throw new ArgumentNullException(nameof(workUnitService));
            _clientService = clientService ?? throw new ArgumentNullException(nameof(clientService));

            httpCurrentUser = _userService.GetHttpCurrentUserAsync().Result;

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }
        //
        // Summary:
        //     created default plan as new ACTIVE record with start date
        //
        // Returns:
        //
        //   location state  model
        //
        // Type parameters:
        //   plan:
        //      planned params from UI
        //

        public async Task<Plan> BatchDefaultAsync(PlanParams plan)
        {
            //deactive old
            //deactive old
            if (plan.Id != Guid.Empty)
            {
                var pppp = await _planRepository.GetAsync(plan.Id);
                if (pppp == null)
                {
                    throw new PlanNotFoundException();
                }

                pppp.RecordStatus = RecordStatus.ARCHIVED.GetDescription();
                pppp.FinishDate = DateTime.UtcNow;

                //production.Key = product.Key;

                await _planRepository.UpdateAsync(pppp);
            }


            // created plan
            var planned = new Plan()
            {
                Id = Guid.NewGuid(),
                Name = plan.Name.Trim(),
                //Version = plan.Version,

                Week = plan.Week,
                Year = plan.Year,

                Remark = plan.Remark,
                SyncedDate = plan.SyncedDate,

                ConfigurationType = ConfigurationType.DEFAULT.GetDescription(),
                By = httpCurrentUser.Unique,
                Date = DateTime.UtcNow,
                RecordStatus = RecordStatus.ACTIVE.GetDescription(),

                StartDate = DateTime.UtcNow,
            };


            planned.Key = planned.Key;
            //get rev
            planned.Rev = Guid.NewGuid();

            using (var transaction = _workUnitService.BeginTransaction())
            {
                var threads = new List<Task>();

                //create space
                var entity = await _workUnitService.Plans.CreateAsync(planned);

                //creaded location scedule
                var locate = plan.PlanLocation;
                locate.PlanId = entity.Id;
                locate.Id = Guid.NewGuid();
                locate.Name = plan.Name;
                locate.Date = DateTime.UtcNow;
                locate.ConfigurationType = ConfigurationType.CONFIGURATION.GetDescription();
                locate.RecordStatus = RecordStatus.ACTIVE.GetDescription();

                var sch = await _workUnitService.PlanLocations.CreateAsync(locate);

                var entities = new List<LocationState>();
                //restric hour 
                //loop created location state
                foreach (var rr in plan.PlanLocation.LocationRestrictedHours)
                {
                    //set value
                    rr.Id = Guid.NewGuid();
                    rr.Date = DateTime.UtcNow;
                    rr.IsTanker = false;
                    //rr.RecordStatus = RecordStatus.ACTIVE.GetDescription();
                    //  rr.RecordStatus = RecordStatus.ACTIVE.GetDescription();
                    // fk
                    rr.PlanLocationId = sch.Id;

                    entities.Add(rr);
                }

                //loop created location tanks
                foreach (var tt in plan.PlanLocation.TankSchedules)
                {
                    //set value
                    tt.Id = Guid.NewGuid();
                    tt.Date = DateTime.UtcNow;
                    tt.IsTanker = true;
                    // tt.RecordStatus = RecordStatus.ACTIVE.GetDescription();

                    //fk
                    tt.PlanLocationId = sch.Id;

                    entities.Add(tt);
                }

                //  ;
                threads.Add(_workUnitService.LocationStates.CreateRangeAsync(entities));

                var tasks = new List<MaterialRequest>();

                //loop created mmr taske
                /*foreach (var mm in plan.Tasks)
                {
                    mm.IsIncludeToCalculate = mm.IsIncludeToCalculate;
                    //if (mm.IsIncludeToCalculate)
                    //{
                    //set value new id
                    mm.Id = Guid.NewGuid();
                    mm.Date = DateTime.UtcNow;
                    //  mm.RecordStatus = RecordStatus.ACTIVE.GetDescription();
                    //fk
                    mm.PlanId = entity.Id;

                    mm.By = httpCurrentUser.Unique;
                    tasks.Add(mm);
                    // }
                }

                threads.Add(_workUnitService.MaterialRequests.CreateRangeAsync(tasks));*/

                //persiste vessel info / and vessel list
                var vi = plan.PlanVessel;
                vi.PlanId = entity.Id;
                vi.Id = Guid.NewGuid();
                vi.Name = plan.Name;
                vi.RecordStatus = RecordStatus.ACTIVE.GetDescription();
                vi.Date = DateTime.UtcNow;
                vi.ConfigurationType = ConfigurationType.CONFIGURATION.GetDescription();

                var info = await _workUnitService.PlanVesseles.CreateAsync(vi);

                //vessel properties
                //mmr checked only
                var vessels = new List<VesselProperties>();
                foreach (var vv in plan.PlanVessel.Properties)
                {
                    //set value
                    vv.Id = Guid.NewGuid();
                    vv.Date = DateTime.UtcNow;
                    vv.PlanVesselId = vi.Id;
                    // vv.RecordStatus = RecordStatus.ACTIVE.GetDescription();
                    vessels.Add(vv);
                }

                threads.Add(_workUnitService.VesselProperties.CreateRangeAsync(vessels));

                //persist cargo piority
                //persiste vessel info / and vessel list
                var cc = plan.OrderedCargo;
                cc.PlanId = entity.Id;
                cc.Id = Guid.NewGuid();
                cc.RecordStatus = RecordStatus.ACTIVE.GetDescription();
                cc.Name = plan.Name;
                cc.Date = DateTime.UtcNow;
                cc.ConfigurationType = ConfigurationType.CONFIGURATION.GetDescription();

                var cargo = await _workUnitService.PlanCargos.CreateAsync(cc); //

                //vessel properties
                var priorities = new List<CargoPriority>();
                foreach (var pp in plan.OrderedCargo.Priorities)
                {
                    //set value
                    pp.Id = Guid.NewGuid();
                    pp.Date = DateTime.UtcNow;
                    pp.PlanCargoId = cargo.Id;
                    // pp.RecordStatus = RecordStatus.ACTIVE.GetDescription();
                    priorities.Add(pp);
                }

                threads.Add(_workUnitService.CargoPriorities.CreateRangeAsync(priorities));

                //persis resource
                var resouce = plan.PlanResource;
                resouce.PlanId = entity.Id;
                resouce.RecordStatus = RecordStatus.ACTIVE.GetDescription();
                resouce.Id = Guid.NewGuid();
                resouce.Name = plan.Name;
                resouce.Date = DateTime.UtcNow;
                resouce.ConfigurationType = ConfigurationType.CONFIGURATION.GetDescription();

                threads.Add(_workUnitService.PlanResources.CreateAsync(resouce));

                //waite merge
                Task.WaitAll(threads.ToArray());

                try
                {
                    //assigned value
                    //plan.Id = entity.Id;

                    //default
                    //planned.RunningJob =

                    transaction.Commit();
                    return entity;
                }
                catch (InvalidOperationException)
                {
                    transaction.Rollback();
                    throw new PlanNotFoundException();
                }
            }

        }

        //
        // Summary:
        //     updaet plan and other config with transacton
        //
        // Returns:
        //
        //   location state  model
        //
        // Type parameters:
        //   plan:
        //      planned params from UI
        //

        public async Task<Plan> BatchUpdateAsync(PlanParams plan)
        {
            //var id = plan.Id;
            var entity = await this.EnforcePlanExistenceAsync(plan.Id);

            //track activity
            entity.By = httpCurrentUser.Unique;
            entity.Date = DateTime.UtcNow;

            using (var transaction = _workUnitService.BeginTransaction())
            {
                entity = await _workUnitService.Plans.UpdateAsync(entity);

                var locate = await this.GetLocationAsync(plan.Id);

                //update props
                locate.JettyAvailable = plan.PlanLocation.JettyAvailable;
                locate.WHPBuffer = plan.PlanLocation.WHPBuffer;
                locate.RigBuffer = plan.PlanLocation.RigBuffer;

                locate.AllowWaitingTimeField = plan.PlanLocation.AllowWaitingTimeField;
                locate.AllowWaitingTimeJetty = plan.PlanLocation.AllowWaitingTimeJetty;

                locate = await _workUnitService.PlanLocations.UpdateAsync(locate);

                var threads = new List<Task>();

                //clear and add new for performance
                //remove all
                // DELETE all
                threads.Add(_workUnitService.LocationStates.RemoveRangeAsync(locate.Id));

                var entities = new List<LocationState>();
                //restric hour 
                //loop created location state
                foreach (var rr in plan.PlanLocation.LocationRestrictedHours)
                {
                    //set value
                    rr.Id = Guid.NewGuid();
                    rr.Date = DateTime.UtcNow;
                    rr.IsTanker = false;
                    //rr.RecordStatus = RecordStatus.ACTIVE.GetDescription();
                    //  rr.RecordStatus = RecordStatus.ACTIVE.GetDescription();
                    // fk
                    rr.PlanLocationId = locate.Id;

                    entities.Add(rr);
                }

                //loop created location tanks
                foreach (var tt in plan.PlanLocation.TankSchedules)
                {
                    //set value
                    tt.Id = Guid.NewGuid();
                    tt.Date = DateTime.UtcNow;
                    tt.IsTanker = true;
                    // tt.RecordStatus = RecordStatus.ACTIVE.GetDescription();

                    //fk
                    tt.PlanLocationId = locate.Id;

                    entities.Add(tt);
                }

                threads.Add(_workUnitService.LocationStates.CreateRangeAsync(entities));

                ///**********************************************************************************/

                //mmr removed
                var tasks = new List<MaterialRequest>();
                threads.Add(_workUnitService.MaterialRequests.RemoveRangeAsync(entity.Id));

                //loop created mmr taske
                foreach (var mm in plan.Tasks)
                {
                    mm.IsIncludeToCalculate = mm.IsIncludeToCalculate;
                    //if (mm.IsIncludeToCalculate)
                    //{
                    //set value new id
                    mm.Id = Guid.NewGuid();
                    mm.Date = DateTime.UtcNow;
                    //  mm.RecordStatus = RecordStatus.ACTIVE.GetDescription();
                    //fk
                    mm.PlanId = entity.Id;

                    mm.By = httpCurrentUser.Unique;
                    tasks.Add(mm);
                    // }
                }

                threads.Add(_workUnitService.MaterialRequests.CreateRangeAsync(tasks));


                //persiste vessel info / and vessel list
                //vessel properties
                var velss = new List<VesselProperties>();
                foreach (var v in plan.PlanVessel.Properties)
                {
                    var vv = await _vesselService.EnforcePropertiesExistenceAsync(v.Id);

                    //update value 
                    vv.BaseLocationReferenceId = v.BaseLocationReferenceId;
                    vv.ETADate = v.ETADate;
                    vv.DeckWidth = v.DeckWidth;
                    vv.DeiselROB = v.DeiselROB;

                    vv.TabularHeightLimitPerside = v.TabularHeightLimitPerside;
                    vv.TabularSpaceLimitPerside = v.TabularSpaceLimitPerside;
                    vv.TabularWeightLimitPerside = v.TabularWeightLimitPerside;

                    vv.IsIncludeToCalculate = v.IsIncludeToCalculate;
                    velss.Add(vv);
                }

                threads.Add(_workUnitService.VesselProperties.UpdateRangeAsync(velss));

                //cargo priority
                var prios = new List<CargoPriority>();
                foreach (var c in plan.OrderedCargo.Priorities)
                {
                    var cc = await _cargoService.EnforcePriorityExistenceAsync(c.Id);
                    cc.Order = c.Order;
                    cc.InsertState = c.InsertState;

                    cc.UserCoefficient = c.UserCoefficient;
                    cc.NormalizedCoefficient = c.NormalizedCoefficient;

                    prios.Add(cc);
                }

                threads.Add(_workUnitService.CargoPriorities.UpdateRangeAsync(prios));


                //get plan resource
                var reso = await this.EnforceResourceExistenceAsync(plan.PlanResource.Id);

                //update attributes
                reso.ServiceTimePort = plan.PlanResource.ServiceTimePort;
                reso.ServiceTimePM = plan.PlanResource.ServiceTimePM;
                reso.ServiceTimeTank = plan.PlanResource.ServiceTimeTank;

                reso.TieUpRig = plan.PlanResource.TieUpRig;
                reso.TieUpOther = plan.PlanResource.TieUpOther;

                reso.PumpWater = plan.PlanResource.PumpWater;
                reso.PumpFuel = plan.PlanResource.PumpFuel;
                reso.PumpBariteJackUp = plan.PlanResource.PumpBariteJackUp;
                reso.PumpBariteTender = plan.PlanResource.PumpBariteTender;
                reso.PumpCementJackUp = plan.PlanResource.PumpCementJackUp;
                reso.PumpSaraline = plan.PlanResource.PumpSaraline;
                reso.PumpCementTender = plan.PlanResource.PumpCementTender;

                reso.LiftingJackup = plan.PlanResource.LiftingJackup;
                reso.LiftingPlatform = plan.PlanResource.LiftingPlatform;
                reso.LiftingTanker = plan.PlanResource.LiftingTanker;
                reso.LiftingTender = plan.PlanResource.LiftingTender;

                reso.MinimumBlockROB = plan.PlanResource.MinimumBlockROB;
                reso.MinimumRefillROB = plan.PlanResource.MinimumRefillROB;
                reso.MinimumTripROB = plan.PlanResource.MinimumTripROB;
                reso.RefillVolume = plan.PlanResource.RefillVolume;
                reso.E2QuotaVolume = plan.PlanResource.E2QuotaVolume;

                reso.UnderwayVoyageRate = plan.PlanResource.UnderwayVoyageRate;
                reso.PlannedStandbyLessThanTwoHrsRate = plan.PlanResource.PlannedStandbyLessThanTwoHrsRate;
                reso.BerthAtJettyRate = plan.PlanResource.BerthAtJettyRate;
                reso.AnchorHandlingTowingRate = plan.PlanResource.AnchorHandlingTowingRate;

                reso.AhtsTarCost = plan.PlanResource.AhtsTarCost;
                reso.UtilityTarCost = plan.PlanResource.UtilityTarCost;

                reso.BackloadCountLimit = plan.PlanResource.BackloadCountLimit;
                reso.BackloadLengthLimit = plan.PlanResource.BackloadLengthLimit;
                reso.BackloadSpaceLimit = plan.PlanResource.BackloadSpaceLimit;
                reso.BackloadWeightLimit = plan.PlanResource.BackloadWeightLimit;

                reso.RouteFunction = plan.PlanResource.RouteFunction;
                reso.RouteLocateLimit = plan.PlanResource.RouteLocateLimit;
                reso.RouteOption = plan.PlanResource.RouteOption;
                reso.RouteTurnaround = plan.PlanResource.RouteTurnaround;

                //new
                reso.MinimumBlockROBPercentage = plan.PlanResource.MinimumBlockROBPercentage;
                reso.MinimumTripROBPercentage = plan.PlanResource.MinimumTripROBPercentage;

                reso.BackloadAfterBlockout = plan.PlanResource.BackloadAfterBlockout;
                reso.BackloadCapacityDiscount = plan.PlanResource.BackloadCapacityDiscount;

                reso.MaximizeBackloadCapacity = plan.PlanResource.MaximizeBackloadCapacity;
                reso.ModelTypeSelection = plan.PlanResource.ModelTypeSelection;

                reso.AssetBuffer = plan.PlanResource.AssetBuffer;
                reso.AssetGroupConcern = plan.PlanResource.AssetGroupConcern;

                threads.Add(_workUnitService.PlanResources.UpdateAsync(reso));

                Task.WaitAll(threads.ToArray());

                try
                {
                    transaction.Commit();
                    return entity;
                }
                catch (InvalidOperationException)
                {
                    transaction.Rollback();
                    throw new PlanNotFoundException();
                }
            }

        }


        //
        // Summary:
        //     created plan and other config with transacton
        //
        // Returns:
        //
        //   location state  model
        //
        // Type parameters:
        //   plan:
        //      planned params from UI
        //

        public async Task<Plan> BatchCreateAsync(PlanParams plan)
        {
            // created plan
            var planned = new Plan()
            {
                Id = Guid.NewGuid(),
                Name = plan.Name.Trim(),
                //Version = plan.Version,

                Week = plan.Week,
                Year = plan.Year,

                Remark = plan.Remark,
                SyncedDate = plan.SyncedDate,

                ConfigurationType = ConfigurationType.CONFIGURATION.GetDescription(),
                By = httpCurrentUser.Unique,
                Date = DateTime.UtcNow,
                RecordStatus = RecordStatus.ACTIVE.GetDescription()
            };

            planned.Key = Guid.NewGuid();
            //get rev
            planned.Rev = Guid.NewGuid();

            using (var transaction = _workUnitService.BeginTransaction())
            {
                var threads = new List<Task>();

                //create space
                var entity = await _workUnitService.Plans.CreateAsync(planned);

                //creaded location scedule
                var locate = plan.PlanLocation;
                locate.PlanId = entity.Id;
                locate.Id = Guid.NewGuid();
                locate.Name = plan.Name;
                locate.Date = DateTime.UtcNow;
                locate.ConfigurationType = ConfigurationType.CONFIGURATION.GetDescription();
                locate.RecordStatus = RecordStatus.ACTIVE.GetDescription();

                var sch = await _workUnitService.PlanLocations.CreateAsync(locate);

                var entities = new List<LocationState>();
                //restric hour 
                //loop created location state
                foreach (var rr in plan.PlanLocation.LocationRestrictedHours)
                {
                    //set value
                    rr.Id = Guid.NewGuid();
                    rr.Date = DateTime.UtcNow;
                    rr.IsTanker = false;
                    //rr.RecordStatus = RecordStatus.ACTIVE.GetDescription();
                    //  rr.RecordStatus = RecordStatus.ACTIVE.GetDescription();

                    // fk
                    rr.PlanLocationId = sch.Id;
                    entities.Add(rr);
                }

                //loop created location tanks
                foreach (var tt in plan.PlanLocation.TankSchedules)
                {
                    //set value
                    tt.Id = Guid.NewGuid();
                    tt.Date = DateTime.UtcNow;
                    tt.IsTanker = true;
                    // tt.RecordStatus = RecordStatus.ACTIVE.GetDescription();

                    //fk
                    tt.PlanLocationId = sch.Id;

                    entities.Add(tt);
                }

                //  ;
                threads.Add(_workUnitService.LocationStates.CreateRangeAsync(entities));

                var tasks = new List<MaterialRequest>();

                //loop created mmr taske
                foreach (var mm in plan.Tasks)
                {
                    mm.IsIncludeToCalculate = mm.IsIncludeToCalculate;
                    //if (mm.IsIncludeToCalculate)
                    //{
                    //set value new id
                    mm.Id = Guid.NewGuid();
                    mm.Date = DateTime.UtcNow;
                    //  mm.RecordStatus = RecordStatus.ACTIVE.GetDescription();
                    //fk
                    mm.PlanId = entity.Id;

                    mm.By = httpCurrentUser.Unique;
                    tasks.Add(mm);
                    // }
                }

                threads.Add(_workUnitService.MaterialRequests.CreateRangeAsync(tasks));

                //persiste vessel info / and vessel list
                var vi = plan.PlanVessel;
                vi.PlanId = entity.Id;
                vi.Id = Guid.NewGuid();
                vi.Name = plan.Name;
                vi.RecordStatus = RecordStatus.ACTIVE.GetDescription();
                vi.Date = DateTime.UtcNow;
                vi.ConfigurationType = ConfigurationType.CONFIGURATION.GetDescription();

                var info = await _workUnitService.PlanVesseles.CreateAsync(vi);

                //vessel properties
                //mmr checked only
                var vessels = new List<VesselProperties>();
                foreach (var vv in plan.PlanVessel.Properties)
                {
                    //set value
                    vv.Id = Guid.NewGuid();
                    vv.Date = DateTime.UtcNow;
                    vv.PlanVesselId = vi.Id;
                    // vv.RecordStatus = RecordStatus.ACTIVE.GetDescription();
                    vessels.Add(vv);
                }

                threads.Add(_workUnitService.VesselProperties.CreateRangeAsync(vessels));

                //persist cargo piority
                //persiste vessel info / and vessel list
                var cc = plan.OrderedCargo;
                cc.PlanId = entity.Id;
                cc.Id = Guid.NewGuid();
                cc.RecordStatus = RecordStatus.ACTIVE.GetDescription();
                cc.Name = plan.Name;
                cc.Date = DateTime.UtcNow;
                cc.ConfigurationType = ConfigurationType.CONFIGURATION.GetDescription();

                var cargo = await _workUnitService.PlanCargos.CreateAsync(cc); //

                //vessel properties
                var priorities = new List<CargoPriority>();
                foreach (var pp in plan.OrderedCargo.Priorities)
                {
                    //set value
                    pp.Id = Guid.NewGuid();
                    pp.Date = DateTime.UtcNow;
                    pp.PlanCargoId = cargo.Id;
                    // pp.RecordStatus = RecordStatus.ACTIVE.GetDescription();
                    priorities.Add(pp);
                }

                threads.Add(_workUnitService.CargoPriorities.CreateRangeAsync(priorities));

                //persis resource
                var resouce = plan.PlanResource;
                resouce.PlanId = entity.Id;
                resouce.RecordStatus = RecordStatus.ACTIVE.GetDescription();
                resouce.Id = Guid.NewGuid();
                resouce.Name = plan.Name;
                resouce.Date = DateTime.UtcNow;
                resouce.ConfigurationType = ConfigurationType.CONFIGURATION.GetDescription();

                threads.Add(_workUnitService.PlanResources.CreateAsync(resouce));

                //waite merge
                Task.WaitAll(threads.ToArray());

                try
                {
                    //assigned value
                    //plan.Id = entity.Id;

                    //default
                    //planned.RunningJob =

                    transaction.Commit();
                    return entity;
                }
                catch (InvalidOperationException)
                {
                    transaction.Rollback();
                    throw new PlanNotFoundException();
                }
            }

        }


        public async Task<Plan> CreateAsync(Plan plan)
        {

            //check id of base plan
            plan.Id = Guid.NewGuid();
            plan.Date = DateTime.UtcNow;
            plan.By = httpCurrentUser.Unique;

            plan.Status = RecordStatus.ACTIVE.GetDescription();

            //key and rev
            plan.Key = plan.Key == Guid.Empty ? Guid.NewGuid() : plan.Key;

            //new rev
            plan.Rev = Guid.NewGuid();

            //await EnforceClanExistenceAsync(Plan.Clan.Name);
            var entity = await _planRepository.CreateAsync(plan);
            if (entity == null)
            {
                throw new PlanNotFoundException(plan.Id);
            }

            return entity;
        }


        public async Task<Plan> UpdateAsync(Plan plan)
        {
            var updated = await this.EnforcePlanExistenceAsync(plan.Id);

            //assigned
            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //plan.Key = Guid.NewGuid().ToString();

            var entity = await _planRepository.UpdateAsync(plan);
            if (entity == null)
            {
                throw new PlanNotFoundException(plan.Id);
            }

            return entity;
        }

        public async Task<Plan> GetAsync(Guid id)
        {
            var entities = await _planRepository.GetAsync(id);
            return entities;
        }

        //
        // Summary:
        //    Return the validation result of params at calculate before sending to phyton model
        //
        // Returns:
        //     Fluentvalidate.ValidationResult object
        //
        // Type parameters:
        //   id:
        //     guid of plan
        //
        public async Task<ValidationResult> ValidateParamsAsync(Guid id)
        {
            var entity = await this.GetParamsAsync(id);

            var props = entity.PlanVessel.Properties.Where(c => c.IsIncludeToCalculate == true);
            //entity.PlanVessel.Properties = props.ToList();
            var tanks = await _vesselService.ListVesselTanksAsync();

            //find by start , end  ************************ not strongly  ! important there is no calculate by ETA like python model)

            var start = props.Min(c => c.ETADate);
            var end = props.Max(c => c.ETADate);
            end = end.Value.AddDays(VESSEL.MAX_VALIDATE_BLOCKOUT_DAYS);
            start = start.Value; //.AddDays(-1 * VESSEL.MAX_VALIDATE_BLOCKOUT_DAYS);

            var blocks = await _vesselService.ListBookActivitiesAysnc(start.Value, end.Value);

            //*******************************************************************************************************88

            //var blocks = await _vesselService.ListBookActivityAsync(props);

            //set required validate fiedl
            entity.PlanVessel.Properties = props.Select(c =>
            {
                c.MinimumRefillROB = entity.PlanResource.MinimumRefillROB.GetValueOrDefault();
                c.MinimumTripROB = entity.PlanResource.MinimumTripROB.GetValueOrDefault();

                // c.BaseLocationLat = 0;
                // c.BaseLocationLong = 0;

                var temp = blocks.Where(x => x.VesseId == c.LCTReferenceId).ToList();
                c.BlockActivities = temp;

                //tank
                var t = tanks.Where(cx => cx.VesselId == c.LCTReferenceId).FirstOrDefault();
                c.Tank = t;

                return c;
            }
            ).ToList();


            //mmr validate from to lat long
            var from = entity.Tasks.Where(c => c.IsIncludeToCalculate == true).Select(c => c.From).Distinct();
            var to = entity.Tasks.Where(c => c.IsIncludeToCalculate == true).Select(c => c.To).Distinct();
            var loc = from.Union(to).Distinct();

            var locations = await _locationService.ListClusterAsync();


            entity.TaskLocations = locations.Where(c => loc.Contains(c.Code)).ToList();

            //mock
            //entity.TaskLocations.Add(new Location() { Code = "MOCK", Lat = null, Long = null });
            // entity.TaskLocations.Add(new Location() { Code = "DOLE", Lat = 0, Long = 0 });

            //await TypeLoadException();
            var flag = _planValidator.Validate(entity);

            if (flag.IsValid != true)
            {
                //var err = flag.Errors.GroupBy(c => c.PropertyName);

                var err = from p in flag.Errors
                          group p by p.ErrorMessage into g
                          select new ValidationFailure(g.FirstOrDefault().PropertyName, g.Key)
                          {
                              //PropertyName = g.Key,
                              //errorMessage = g
                          };

                throw new PlanNotValidException(err.ToList());
            }

            return flag;
        }

        public async Task<PlanParams> GetParamsAsync(Guid id)
        {
            var plan = await _planRepository.GetAsync(id);
            if (plan == null)
            {
                throw new PlanNotFoundException();
            }

            var mmrs = await _materialService.ListRequestAsync(plan.Id);

            var entities = new PlanParams()
            {
                Id = plan.Id,

                //should refactory to each service
                PlanLocation = await this.GetLocationAsync(plan.Id),
                PlanResource = await this.GetResourceAsync(plan.Id),


                PlanVessel = await _vesselService.GetPlanVesselAsync(plan.Id),

                //should refactory to each service
                OrderedCargo = await this.GetCargoAsync(plan.Id),

                Tasks = mmrs.ToList(),
            };

            return entities;
        }


        //
        // Summary:
        //    Return the default active plan
        //
        // Returns:
        //     Plan object
        public async Task<Plan> SynceAsync()
        {
            var plans = await _planRepository.ListAsync();

            var entity = plans.Where(c => c.ConfigurationType == ConfigurationType.DEFAULT.GetDescription()
                                            && c.RecordStatus == RecordStatus.ACTIVE.GetDescription()).OrderByDescending(c => c.Date).FirstOrDefault();
            if (entity == null)
            {
                throw new PlanNotFoundException();
            }

            return entity;
        }

        //
        // Summary:
        //    Return the plan with recently job run
        //
        // Returns:
        //     Plan object
        //
        // Type parameters:
        //   id:
        //     guid of plan
        //
        public async Task<Plan> GetRecentlyAsync(Guid id)
        {
            var plan = await _planRepository.GetAsync(id);
            if (plan == null)
            {
                throw new PlanNotFoundException();
            }

            //synce last time of default plan
            /* *if (plan.Id == PLAN.DEFAULT_PLANNED_ID)
            {
                var synces = await _azureService.ListSynceLogAsync();
                plan.SyncedDate = synces.OrderByDescending(c => c.LastSync).FirstOrDefault().LastSync;
            }*/

            //get job with current status
            var entities = await _jobService.ListJobAsync(plan.Id);
            var job = entities.OrderByDescending(c => c.Date).FirstOrDefault();
            if (job != null)
            {
                // job.TempolaryTimeElapsed =
                //running
                if (job.Status == JobStatus.PENDING.GetDescription() || job.Status == JobStatus.RUNNING.GetDescription())
                {
                    job.TempolaryTimeElapsed = DateTime.UtcNow.Subtract(job.Date.GetValueOrDefault());
                }
                //succecd or fail
                else
                {
                    job.TempolaryTimeElapsed = job.UpdatedDate.GetValueOrDefault().Subtract(job.Date.GetValueOrDefault());
                }

                plan.LastestJob = job;
            }

            return plan;
        }



        /* *public async Task<Plan> DeleteAsync(Guid id)
        {
            await this.EnforcePlanExistenceAsync(id);

            var deletedPlan = await _planRepository.DeleteAsync(id);
            return deletedPlan;
        }*/

        public async Task<IEnumerable<Plan>> ListAsync()
        {
            var entity = await _planRepository.ListAsync();
            return entity; //Where(c => c.RecordStatus == RecordStatus.ACTIVE.GetDescription()).OrderByDescending(c => c.Date);
        }



        public async Task<IEnumerable<Plan>> ListRecentAsync()
        {
            int take = 10;
            var entity = await _planRepository.ListAsync(take);
            return entity;
        }


        /* public async Task<Plan> SynceAsync()
        {
            var entity = await _planRepository.ListAsync();
            return entity.Where(c => c.ConfigurationType == ConfigurationType.DEFAULT.GetDescription()).FirstOrDefault();
        }*/


        public async Task<Plan> EnforcePlanExistenceAsync(Guid id)
        {
            var entity = await _planRepository.GetAsync(id);
            if (entity == null)
            {
                throw new PlanNotFoundException();
            }

            return entity;
        }

        public async Task<PlanResource> EnforceResourceExistenceAsync(Guid id)
        {
            var entity = await _planResourceRepository.GetAsync(id);
            if (entity == null)
            {
                throw new PlanNotFoundException();
            }

            return entity;
        }


        //
        // Summary:
        //     retrun plan cargoPriority
        //
        // Returns:
        //
        //  CargoPriority Plan model
        //
        // Type parameters:
        //   id:
        //     plan \  id
        //
        public async Task<PlanCargo> GetCargoAsync(Guid id)
        {
            var entity = await _planCargoRepository.ListAsync(id);
            if (entity == null)
            {
                throw new CargoNotFoundException();
            }

            //get
            var priority = await _cargoService.ListPriorityAsync(entity.Id);
            entity.Priorities = priority.ToList();
            return entity;
        }

        public async Task<PlanLocation> GetLocationAsync(Guid id)
        {
            var entity = await _locationRepository.ListAsync(id);
            if (entity == null)
            {
                throw new LocationNotFoundException();
            }

            // var location = entity;

            //tanker mapping asset
            var tank = await _locationService.ListTankAsync(entity.Id);
            var entities = new List<LocationState>();
            // var previous = entity.FirstOrDefault();

            var locations = await _clientService.ListLocationAsync();
            foreach (var t in tank)
            {

                //find  new asset with dor plaform (new by gulf of thailand area)
                var l = locations.Where(c => c.DORPlatformId == t.LCTReferenceId).FirstOrDefault();
                if (l != null)
                {
                    t.Asset = l.Asset;
                }

                entities.Add(t);
            }

            entity.TankSchedules = entities;

            //retricted
            var restricted = await _locationService.ListRestrictedHourAsync(entity.Id);
            entity.LocationRestrictedHours = restricted.ToList();

            return entity;
        }


        //
        // Summary:
        //     retrun plan resource
        //
        // Returns:
        //
        //  PlanResource Plan model
        //
        // Type parameters:
        //   id:
        //     plan \  id
        //
        public async Task<PlanResource> GetResourceAsync(Guid id)
        {
            var entity = await _planResourceRepository.ListAsync(id);
            if (entity == null)
            {
                throw new PlanResourceNotFoundException();
            }

            return entity;
        }


        public Stream GetResourceBlobAsync(PlanResource resource, PlanLocation location, Job runtime, ModelParameter model)
        {
            var stream = new MemoryStream();

            var headers = new List<string>
            {
                "ParameterName",
                "ParameterValue"
            };

            //Header columns
            string headerLine = $"{string.Join(BLOB.CsvDelimiter, headers.ToArray())}\n";

            stream.Write(BLOB.Encoding.GetBytes(headerLine), 0, BLOB.Encoding.GetBytes(headerLine).Length);

            //Records
            var lstV = new List<string>();

            lstV.Add($"Id, {resource.Id}");
            lstV.Add($"PlanId, {resource.PlanId}");
            lstV.Add($"Name, {resource.Name}");

            lstV.Add($"ConfigurationType, {resource.ConfigurationType}");
            lstV.Add($"JettyAvailable, {location.JettyAvailable}");

            lstV.Add($"WHPBuffer, {location.WHPBuffer}");
            lstV.Add($"RigBuffer, {location.RigBuffer}");

            lstV.Add($"ServiceTimePort, {resource.ServiceTimePort}");
            lstV.Add($"ServiceTimeTank, {resource.ServiceTimeTank}");
            lstV.Add($"ServiceTimePM, {resource.ServiceTimePM}");

            lstV.Add($"TieUpRig, {resource.TieUpRig}");

            lstV.Add($"TieUpOther, {resource.TieUpOther}");
            lstV.Add($"PumpFuel, {resource.PumpFuel}");
            lstV.Add($"PumpWater, {resource.PumpWater}");
            lstV.Add($"PumpSaraline, {resource.PumpSaraline}");

            lstV.Add($"PumpCementJackUp, {resource.PumpCementJackUp}");
            lstV.Add($"PumpCementTender, {resource.PumpCementTender}");
            lstV.Add($"PumpBariteJackUp, {resource.PumpBariteJackUp}");
            lstV.Add($"PumpBariteTender, {resource.PumpBariteTender}");

            lstV.Add($"LiftingTender, {resource.LiftingTender}");
            lstV.Add($"LiftingPlatform, {resource.LiftingPlatform}");
            lstV.Add($"LiftingJackup, {resource.LiftingJackup}");
            lstV.Add($"LiftingTanker, {resource.LiftingTanker}");


            lstV.Add($"MinimumBlockROB, {resource.MinimumBlockROB}");
            lstV.Add($"MinimumTripROB, {resource.MinimumTripROB}");
            lstV.Add($"MinimumRefillROB, {resource.MinimumTripROBPercentage}");

            lstV.Add($"MinBlockROBPercent, {resource.MinimumBlockROBPercentage}");
            // lstV.Add($"MinTripROBPercent, {resource.MinimumTripROBPercentage}");

            lstV.Add($"RefillVolume, {resource.RefillVolume}");
            lstV.Add($"E2QuotaVolume, {resource.E2QuotaVolume}");
            lstV.Add($"UnderwayVoyageRate, {resource.UnderwayVoyageRate}");
            lstV.Add($"PlannedStandbyLessThanTwoHrsRate, {resource.PlannedStandbyLessThanTwoHrsRate}");
            lstV.Add($"BerthAtJettyRate, {resource.BerthAtJettyRate}");
            lstV.Add($"AnchorHandlingTowingRate, {resource.AnchorHandlingTowingRate}");
            lstV.Add($"AhtsTarCost, {resource.AhtsTarCost}");
            lstV.Add($"UtilityTarCost, {resource.UtilityTarCost}");

            lstV.Add($"BackloadCountLimit, {resource.BackloadCountLimit}");
            lstV.Add($"BackloadSpaceLimit, {resource.BackloadSpaceLimit}");
            lstV.Add($"BackloadWeightLimit, {resource.BackloadWeightLimit}");
            lstV.Add($"BackloadLengthLimit, {resource.BackloadLengthLimit}");

            lstV.Add($"RouteLocateLimit, {resource.RouteLocateLimit}");
            if (resource.RouteOption == RouteOptionType.UNCONSTAINT.GetDescription())
                resource.RouteTurnaround = (decimal)RouteOptionType.UNCONSTAINT_ROUTE_TURNAROUND;
            lstV.Add($"RouteTurnaround, {resource.RouteTurnaround}");
            lstV.Add($"RouteFunction, {resource.RouteFunction}");
            lstV.Add($"RouteOption, {resource.RouteOption}");

            lstV.Add($"AllowWaiting, {location.AllowWaitingTimeField}");

            lstV.Add($"TerminalBuffer, {location.AllowWaitingTimeJetty}");
            lstV.Add($"TimeLimit, {runtime.ExecuteTime}");
            lstV.Add($"SolutionLimit, {runtime.SolutionLimit}");
            lstV.Add($"BackloadCapacityRatio, {resource.BackloadCapacityDiscount}");
            lstV.Add($"BackloadTripBufferTime, {resource.BackloadAfterBlockout}");

            lstV.Add($"MaximizeBackloadCapacity, {resource.MaximizeBackloadCapacity}");

            lstV.Add($"AssetBuffer, {resource.AssetBuffer}");
            lstV.Add($"AssetGroupConcern, {Convert.ToInt32(resource.AssetGroupConcern)}");

            ModelTypeSelection type = (ModelTypeSelection)Enum.Parse(typeof(ModelTypeSelection), resource.ModelTypeSelection, true);
            lstV.Add($"ModelTypeSelection, {(int)type}");

            //lstV.Add($"ModelTypeSelection, {(int)type}");
            // lstV.Add($"ModelTypeSelection, {(int)type}");

            lstV.Add($"By, {resource.By}");
            lstV.Add($"Description, {resource.Description}");

            //where with cuurent rout objective plan
            var objective = model.Objectives.Where(c => c.ModelObjectiveType == resource.RouteFunction).FirstOrDefault();
            if (objective == null)
            {
                new ParamsNotValidException();
            }

            lstV.Add($"P1Constraint, {Convert.ToInt32(objective.IsP1ObjectConstraint)}");
            lstV.Add($"RosEndOrdering, {Convert.ToInt32(objective.IsRosEndingOrdering)}");

            //production
            var prod1 = model.Productions.Where(c => c.Priority == "P1").FirstOrDefault();
            if (prod1 == null)
            {
                new ParamsNotValidException();
            }

            var prod2 = model.Productions.Where(c => c.Priority == "P2").FirstOrDefault();
            if (prod2 == null)
            {
                new ParamsNotValidException();
            }

            var prod3 = model.Productions.Where(c => c.Priority == "P3").FirstOrDefault();
            if (prod3 == null)
            {
                new ParamsNotValidException();
            }

            if (resource.RouteFunction == ModelObjective.MT.GetDescription())
            {
                //set with mt field ! what thee fuck db designed
                lstV.Add($"RosStartProdP1, {prod1.CostPerMTRosInDays * -1}");
                lstV.Add($"RosStartProdP2, {prod2.CostPerMTRosInDays * -1}");
                lstV.Add($"RosStartProdP3, {prod3.CostPerMTRosInDays * -1}");
            }
            else
            {
                lstV.Add($"RosStartProdP1, {prod1.PercentRosInDays * -1}");
                lstV.Add($"RosStartProdP2, {prod2.PercentRosInDays * -1}");
                lstV.Add($"RosStartProdP3, {prod3.PercentRosInDays * -1}");
            }

            lstV.Add($"RosEndProdP1, {prod1.EndingRosInDays}");
            lstV.Add($"RosEndProdP2, {prod2.EndingRosInDays}");
            lstV.Add($"RosEndProdP3, {prod3.EndingRosInDays}");

            //drilling
            var drill1 = model.Drillings.Where(c => c.Priority == "P1").FirstOrDefault();
            if (drill1 == null)
            {
                new ParamsNotValidException();
            }

            var drill2 = model.Drillings.Where(c => c.Priority == "P2").FirstOrDefault();
            if (drill2 == null)
            {
                new ParamsNotValidException();
            }

            var drill3 = model.Drillings.Where(c => c.Priority == "P3").FirstOrDefault();
            if (drill3 == null)
            {
                new ParamsNotValidException();
            }

            lstV.Add($"RosStartDrP1, {drill1.StartRosInDays * -1}");
            lstV.Add($"RosStartDrP2, {drill2.StartRosInDays * -1}");
            lstV.Add($"RosStartDrP3, {drill3.StartRosInDays * -1}");

            lstV.Add($"RosEndDrP1, {drill1.EndingRosInDays}");
            lstV.Add($"RosEndDrP2, {drill2.EndingRosInDays}");
            lstV.Add($"RosEndDrP3, {drill3.EndingRosInDays}");

            var alg = (int)Enum.Parse(typeof(SearchAlgorithm), model.OptimizedAlgorithm, true);
            lstV.Add($"SearchParameter, {alg}");

            var ration = (int)Enum.Parse(typeof(VesselRatio), model.MmrVesselRatio, true);
            lstV.Add($"MmrPerVessel, {ration}");

            lstV.Add($"VesselEtdRange, {model.VesselEtdRangeTrip}");
            lstV.Add($"VesselPerModel, {model.VesselPerTrip}");

            var weight = PLAN.PENALTY_WEIGHT[Convert.ToInt32(model.PenaltyWeight)];
            lstV.Add($"PenaltyWeight, {weight}");

            //cv
            lstV.Add($"BariteWieght, {model.BariteWeightCVFactor}");
            lstV.Add($"CementWeight, {model.CementWeightCVFactor}");
            lstV.Add($"SaralineWeight, {model.SaralineWeightCVFactor}");
            lstV.Add($"FuelWeight, {model.FuelWeightCVFactor}");
            lstV.Add($"WaterWeight, {model.WaterWeightCVFactor}");

            //lstV.Add($"RecordStatus, {resource.RecordStatus}");
            //lstV.Add($"Date, {resource.Date}");

            var valueLine = $"{string.Join("\n", lstV.ToArray())}";

            stream.Write(BLOB.Encoding.GetBytes(valueLine), 0, BLOB.Encoding.GetBytes(valueLine).Length);

            stream.Position = 0;
            return stream;
        }



    }

    public interface IPlanJobService
    {
        Task<Plan> GetPlanAsync(Guid id);
        Task<IEnumerable<Job>> ListJobAsync(Guid id);

        Task<Job> EnforceJobExistenceAsync(Guid id);
        Task<Job> GetJobAsync(Guid id);
    }

    public class PlanJobService : IPlanJobService
    {
        private readonly IPlanRepository _planRepository;
        private readonly IJobRepository _jobRepository;

        public PlanJobService(IPlanRepository planRepository, IJobRepository jobRepository)
        {
            _planRepository = planRepository ?? throw new ArgumentNullException(nameof(planRepository));
            _jobRepository = jobRepository ?? throw new ArgumentNullException(nameof(jobRepository));
        }


        public async Task<Job> GetJobAsync(Guid id)
        {
            var entities = await _jobRepository.GetAsync(id);
            return entities;
        }


        public async Task<Plan> GetPlanAsync(Guid id)
        {
            var entities = await _planRepository.GetAsync(id);
            return entities;
        }

        public async Task<IEnumerable<Job>> ListJobAsync(Guid id)
        {
            var entity = await _jobRepository.ListAsync(id);
            return entity; //.OrderByDescending(c => c.Date); //.Take(5);

        }




        public async Task<Job> EnforceJobExistenceAsync(Guid id)
        {
            var entity = await _jobRepository.GetAsync(id);
            if (entity == null)
            {
                throw new JobNotFoundException();
            }

            return entity;
        }



    }


}