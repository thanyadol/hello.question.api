using System;

using System.Collections.Generic;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;
using AutoMapper;
using cvx.lct.vot.api.APIs.Services;
using cvx.lct.vot.api.Exceptions;
using cvx.lct.vot.api.Extensions;
//vot
using cvx.lct.vot.api.Models;
using cvx.lct.vot.api.Repositories;

//logg
using Serilog;

using BLOB = cvx.lct.vot.api.Models.Constant.Blob;
using System.IO;

namespace cvx.lct.vot.api.Services
{

    public interface IParamService
    {
        Task<Parameter> CreateAsync(Parameter param);
        Task<Parameter> UpdateAsync(Parameter param);
        Task<Parameter> GetAsync(Guid id);

        Task<IEnumerable<Parameter>> ListAsync();

        //Task<Parameter> EnforceExistenceAsync(Guid id);

        ///

        Task<RunParameter> GetRecentlyRunAsync();
        Task<RunParameter> EnforceDefaultRunAsync();

        Task<RunParameter> CreateAsync(RunParameter param);
        Task<RunParameter> UpdateAsync(RunParameter param);
        Task<RunParameter> GetRunAsync(Guid id);

        Task<IEnumerable<RunParameter>> ListRunAsync();
        Task<RunParameter> EnforceRunExistenceAsync(Guid id);


        // Stream ListRunBlobAsync(IEnumerable<RunParameter> runs);
        // Stream ListBlobAsync(IEnumerable<Parameter> params);

        Task<ModelParameter> BatchCreateAsync(ModelParams param);
        Task<ModelParameter> UpdateAsync(ModelParameter param);
        Task<ModelParameter> GetModelAsync(Guid id);

        Task<IEnumerable<ModelParameter>> ListModelAsync();

        Task<ModelParameter> EnforceModelExistenceAsync(Guid id);


        Task<ModelParameter> EnforceDefaultModelAsync();
        Task<ModelParameter> GetRecentlyModelAsync();

        //   

        Task<ModelPriorityParameter> CreateAsync(ModelPriorityParameter param);
        Task<ModelPriorityParameter> UpdateAsync(ModelPriorityParameter param);
        Task<ModelPriorityParameter> GetModelObjectAsync(Guid id);

        Task<IEnumerable<ModelPriorityParameter>> ListModelObjectAsync();

        Task<ModelPriorityParameter> EnforceModelObjectExistenceAsync(Guid id);

    }

    public class ParamService : IParamService
    {
        // private readonly IParameterRepository _parameterRepository;
        private readonly IRunParameterRepository _runParameterRepository;
        private readonly IModelParameterRepository _modelParameterRepository;
        private readonly IModelPriorityParameterRepository _modelPriorityParameterRepository;
        private readonly IModelProductionParameterRepository _modelProductionParameterRepository;

        private readonly IUserService _userService;
        private readonly User httpCurrentUser;


        private readonly IWorkUnitExtension _workUnitService;

        public ParamService(/*IParameterRepository parameterRepository,*/ IRunParameterRepository runParameterRepository,
                                IModelParameterRepository modelParameterRepository, IModelPriorityParameterRepository modelPriorityParameterRepository,
                                IModelProductionParameterRepository modelProductionParameterRepository, IUserService userService, IWorkUnitExtension workUnitExtension)
        {
            // _parameterRepository = parameterRepository ?? throw new ArgumentNullException(nameof(parameterRepository));
            _runParameterRepository = runParameterRepository ?? throw new ArgumentNullException(nameof(runParameterRepository));
            _modelParameterRepository = modelParameterRepository ?? throw new ArgumentNullException(nameof(modelParameterRepository));
            _modelPriorityParameterRepository = modelPriorityParameterRepository ?? throw new ArgumentNullException(nameof(modelPriorityParameterRepository));
            _modelProductionParameterRepository = modelProductionParameterRepository ?? throw new ArgumentNullException(nameof(modelProductionParameterRepository));

            _workUnitService = workUnitExtension ?? throw new ArgumentNullException(nameof(workUnitExtension));

            _userService = userService ?? throw new ArgumentNullException(nameof(userService));
            httpCurrentUser = _userService.GetHttpCurrentUserAsync().Result;


            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }


        /*
        public Stream ListRunBlobAsync(IEnumerable<RunParameter> runs)
        {
            var stream = new MemoryStream();

            var headers = new List<string>
            {
                "Id",
                "StackableId",
                "Name",
                "StackableName",
            };

            //Header columns
            string headerLine = $"{string.Join(BLOB.CsvDelimiter, headers.ToArray())}\n";
            stream.Write(BLOB.Encoding.GetBytes(headerLine), 0, BLOB.Encoding.GetBytes(headerLine).Length);

            //records
            foreach (var v in runs)
            {
                var entity = new List<string>();

                entity.Add(v.Id.ToString());
                entity.Add(v.StackableId.ToString());
                entity.Add(v.Name);
                entity.Add(v.StackableName.ToString());

                var valueLine = $"{string.Join(BLOB.CsvDelimiter, entity.toReplaceArray())}\n";
                stream.Write(BLOB.Encoding.GetBytes(valueLine), 0, BLOB.Encoding.GetBytes(valueLine).Length);
            }

            stream.Position = 0;
            return stream;
        }


        public Stream ListBlobAsync(IEnumerable<Parameter> params)
        {
            var stream = new MemoryStream();

            var headers = new List<string>
            {
                "Id",
                "Name",

                "LengthBundle",
                "WidthBundle",
                "HeightBundle",
                "WeightJoint",

                "MaxStackHeight",
                "JointBundle",

                "Type",

                 "SpaceBundle",
                 "MaxStackLayer",
            };

            //Header columns
            string headerLine = $"{string.Join(BLOB.CsvDelimiter, headers.ToArray())}\n";
            stream.Write(BLOB.Encoding.GetBytes(headerLine), 0, BLOB.Encoding.GetBytes(headerLine).Length);

            //records
            foreach (var v in params)
            {
                var entity = new List<string>();

                entity.Add(v.Id.ToString());
                entity.Add(v.Name.ToString());
                entity.Add(v.LengthBundle.ToString());

                entity.Add(v.WidthBundle.ToString());
                entity.Add(v.HeightBundle.ToString());
                entity.Add(v.WeightJoint.ToString());

                entity.Add(v.MaxStackHeight.ToString());
                entity.Add(v.JointBundle.ToString());
                entity.Add(v.Type);

                entity.Add(v.SpaceBundle.ToString());
                entity.Add(v.MaxStackLayer.ToString());

                var valueLine = $"{string.Join(BLOB.CsvDelimiter, entity.toReplaceArray())}\n";
                stream.Write(BLOB.Encoding.GetBytes(valueLine), 0, BLOB.Encoding.GetBytes(valueLine).Length);
            }

            stream.Position = 0;
            return stream;
        }*/

        public async Task<Parameter> CreateAsync(Parameter param)
        {
            await Task.Delay(0);
            throw new NotImplementedException();
        }


        public async Task<Parameter> UpdateAsync(Parameter param)
        {
            await Task.Delay(0);
            throw new NotImplementedException();
        }

        public async Task<Parameter> GetAsync(Guid id)
        {
            await Task.Delay(0);
            throw new NotImplementedException();
        }


        public async Task<IEnumerable<Parameter>> ListAsync()
        {
            await Task.Delay(0);
            throw new NotImplementedException();
        }


        /*public async Task<Parameter> EnforceExistenceAsync(Guid id)
        {
            var param = await _parameterRepository.GetAsync(id);
            if (param == null)
            {
                throw new ParamsNotFoundException();
            }

            return param;
        }*/

        /*public async Task<IEnumerable<Parameter>> ListCurrentlyAsync()
        {
            var entities = await _parameterRepository.ListAsync();

            entities = entities.Where(c => c.RecordStatus == RecordStatus.ACTIVE.GetDescription());
            if (entities == null)
            {
                throw new ParamsNotFoundException();
            }

            entities.OrderBy(c => c.Name);

            //calculate space, amax stack
            entities = entities.Select(c =>
            {
                c.SpaceBundle = c.LengthBundle * c.WidthBundle.GetValueOrDefault();
                c.MaxStackLayer = Math.Floor(c.MaxStackHeight.GetValueOrDefault() / c.HeightBundle.GetValueOrDefault());
                return c;
            }
            ).ToList();

            return entities;
        }*/


        //
        // Summary:
        //    return a lastest job params
        //
        // Returns:
        //
        //   params
        //
        public async Task<RunParameter> GetRunAsync(Guid id)
        {
            var entity = await _runParameterRepository.GetAsync(id);
            return entity;
        }

        //
        // Summary:
        //    return a lastest job params
        //
        // Returns:
        //
        //   params
        //
        public async Task<RunParameter> GetRecentlyRunAsync()
        {
            //  await this.EnforceJobExistenceAsync(id);

            var entitities = await _runParameterRepository.ListAsync();
            if (entitities == null)
            {
                throw new ParamsNotFoundException();
            }

            var entity = entitities.Where(c => c.RecordStatus == RecordStatus.ACTIVE.GetDescription()).OrderByDescending(c => c.Date).FirstOrDefault();


            return entity;
        }

        //
        // Summary:
        //    return a  job params type = "DEFAULT"
        //
        // Returns:
        //
        //   params
        //
        public async Task<RunParameter> EnforceDefaultRunAsync()
        {
            //  await this.EnforceJobExistenceAsync(id);

            var entitities = await _runParameterRepository.ListAsync();
            if (entitities == null)
            {
                throw new ParamsNotFoundException();
            }

            var entity = entitities.Where(c => c.ConfigurationType == ConfigurationType.DEFAULT.GetDescription()).OrderByDescending(c => c.Date).FirstOrDefault();
            return entity;
        }


        //
        // Summary:
        //    return a  created new job paramse with history logic
        //
        // Returns:
        //
        //   params
        //
        public async Task<RunParameter> CreateAsync(RunParameter param)
        {

            //controlversion
            //deactive old
            if (param.Id != Guid.Empty)
            {
                var pppp = await _runParameterRepository.GetAsync(param.Id);
                if (pppp == null)
                {
                    throw new ParamsNotFoundException();
                }

                pppp.RecordStatus = RecordStatus.ARCHIVED.GetDescription();
                pppp.FinishDate = DateTime.UtcNow;

                //production.Key = product.Key;

                await _runParameterRepository.UpdateAsync(pppp);
            }
            else
            {
                // production.Key = Guid.NewGuid().ToString();
            }


            //assigned
            //production.AreaId = area.Id;

            param.Id = Guid.NewGuid();
            param.ConfigurationType = ConfigurationType.CONFIGURATION.GetDescription();
            // production.Rev = Guid.NewGuid().ToString();

            param.Date = DateTime.UtcNow;
            param.RecordStatus = RecordStatus.ACTIVE.GetDescription();

            param.StartDate = DateTime.UtcNow;
            param.By = httpCurrentUser.Unique;

            //persist parent
            var entity = await _runParameterRepository.CreateAsync(param);
            if (entity == null)
            {
                throw new ParamsNotFoundException();
            }

            return entity;
        }



        public async Task<RunParameter> UpdateAsync(RunParameter param)
        {
            var updated = await this.EnforceRunExistenceAsync(param.Id);

            //assigned
            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //param.Key = Guid.NewGuid().ToString();

            var entity = await _runParameterRepository.UpdateAsync(param);
            if (entity == null)
            {
                throw new ParamsNotFoundException(param.Id);
            }

            return entity;
        }


        public async Task<IEnumerable<RunParameter>> ListRunAsync()
        {
            return await _runParameterRepository.ListAsync();
        }



        public async Task<RunParameter> EnforceRunExistenceAsync(Guid id)
        {
            var param = await _runParameterRepository.GetAsync(id);
            if (param == null)
            {
                throw new ParamsNotFoundException();
            }

            return param;
        }

        ////

        //
        // Summary:
        //    return a  created new job paramse with history logic
        //
        // Returns:
        //
        //   params
        //
        public async Task<ModelParameter> BatchCreateAsync(ModelParams param)
        {

            //controlversion
            //deactive old
            if (param.Id != Guid.Empty)
            {
                var pppp = await _modelParameterRepository.GetAsync(param.Id);
                if (pppp == null)
                {
                    throw new ParamsNotFoundException();
                }

                pppp.RecordStatus = RecordStatus.ARCHIVED.GetDescription();
                pppp.FinishDate = DateTime.UtcNow;

                //production.Key = product.Key;

                await _modelParameterRepository.UpdateAsync(pppp);
            }
            else
            {
                // production.Key = Guid.NewGuid().ToString();
            }

            var model = new ModelParameter()
            {
                Id = Guid.NewGuid(),
                ConfigurationType = ConfigurationType.CONFIGURATION.GetDescription(),
                // production.Rev = Guid.NewGuid().ToString(),

                OptimizedAlgorithm = param.OptimizedAlgorithm,
                MmrVesselRatio = param.MmrVesselRatio,
                VesselEtdRangeTrip = param.VesselEtdRangeTrip,
                VesselPerTrip = param.VesselPerTrip,
                PenaltyWeight = param.PenaltyWeight,

                SaralineWeightCVFactor = param.SaralineWeightCVFactor,
                FuelWeightCVFactor = param.FuelWeightCVFactor,
                WaterWeightCVFactor = param.WaterWeightCVFactor,
                BariteWeightCVFactor = param.BariteWeightCVFactor,
                CementWeightCVFactor = param.CementWeightCVFactor,

                Remark = param.Remark,

                Date = DateTime.UtcNow,
                RecordStatus = RecordStatus.ACTIVE.GetDescription(),

                StartDate = DateTime.UtcNow,
                By = httpCurrentUser.Unique,
            };

            using (var transaction = _workUnitService.BeginTransaction())
            {
                var entity = await _workUnitService.ModelParameters.CreateAsync(model);

                var matrixs = new List<ModelPriorityParameter>();
                foreach (var pp in param.Objectives)
                {
                    //set value
                    pp.Id = Guid.NewGuid();
                    pp.ModelParameterId = entity.Id;

                    matrixs.Add(pp);
                }

                await _workUnitService.ModelPriorityParameters.CreateRangeAsync(matrixs);


                var products = new List<ModelProductionParameter>();
                foreach (var pp in param.Productions)
                {
                    //set value
                    pp.Id = Guid.NewGuid();
                    pp.ModelParameterId = entity.Id;
                    pp.Type = ProductionType.PRODUCTION.GetDescription();

                    products.Add(pp);
                }

                //drilling
                foreach (var pp in param.Drillings)
                {
                    //set value
                    pp.Id = Guid.NewGuid();
                    pp.ModelParameterId = entity.Id;
                    pp.Type = ProductionType.DRILLING.GetDescription();

                    products.Add(pp);
                }

                await _workUnitService.ModelProductionParameters.CreateRangeAsync(products);

                //set value for return
                entity.Objectives = matrixs;

                //get ros production type
                entity.Productions = products.Where(c => c.Type == ProductionType.PRODUCTION.GetDescription()).OrderBy(c => c.Priority).ToList();
                entity.Drillings = products.Where(c => c.Type == ProductionType.DRILLING.GetDescription()).OrderBy(c => c.Priority).ToList();

                try
                {
                    transaction.Commit();
                    return entity;
                }
                catch (InvalidOperationException)
                {
                    transaction.Rollback();
                    throw new PlanNotFoundException();
                }
            }
        }

        //
        // Summary:
        //    return a  advance params type = "DEFAULT"
        //
        // Returns:
        //
        //   params
        //
        public async Task<ModelParameter> EnforceDefaultModelAsync()
        {
            //  await this.EnforceJobExistenceAsync(id);

            var entitities = await _modelParameterRepository.ListAsync();

            var entity = entitities.Where(c => c.ConfigurationType == ConfigurationType.DEFAULT.GetDescription()).OrderByDescending(c => c.Date).FirstOrDefault();
            if (entity == null)
            {
                throw new ParamsNotFoundException();
            }
            //get matirx
            var matrix = await _modelPriorityParameterRepository.ListAsync(entity.Id);
            entity.Objectives = matrix.ToList();


            //get ros production type
            var products = await _modelProductionParameterRepository.ListAsync(entity.Id);

            entity.Productions = products.Where(c => c.Type == ProductionType.PRODUCTION.GetDescription()).OrderBy(c => c.Priority).ToList();
            entity.Drillings = products.Where(c => c.Type == ProductionType.DRILLING.GetDescription()).OrderBy(c => c.Priority).ToList();

            return entity;
        }



        public async Task<ModelParameter> UpdateAsync(ModelParameter param)
        {
            var updated = await this.EnforceModelExistenceAsync(param.Id);

            //assigned
            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //param.Key = Guid.NewGuid().ToString();

            var entity = await _modelParameterRepository.UpdateAsync(param);
            if (entity == null)
            {
                throw new ParamsNotFoundException(param.Id);
            }

            return entity;
        }

        public async Task<ModelParameter> GetModelAsync(Guid id)
        {
            //  await this.EnforceExistenceAsync(id);

            var entity = await _modelParameterRepository.GetAsync(id);

            //get matirx
            var matrix = await _modelPriorityParameterRepository.ListAsync(entity.Id);
            entity.Objectives = matrix.ToList();


            //get ros production type
            var products = await _modelProductionParameterRepository.ListAsync(entity.Id);
            entity.Productions = products.Where(c => c.Type == ProductionType.PRODUCTION.GetDescription()).OrderBy(c => c.Priority).ToList();
            entity.Drillings = products.Where(c => c.Type == ProductionType.DRILLING.GetDescription()).OrderBy(c => c.Priority).ToList();


            return entity;
        }


        public async Task<IEnumerable<ModelParameter>> ListModelAsync()
        {
            return await _modelParameterRepository.ListAsync();
        }

        public async Task<ModelParameter> EnforceModelExistenceAsync(Guid id)
        {
            var param = await _modelParameterRepository.GetAsync(id);
            if (param == null)
            {
                throw new ParamsNotFoundException();
            }

            return param;
        }


        //
        // Summary:
        //    return a lastest job params
        //
        // Returns:
        //
        //   params
        //
        public async Task<ModelParameter> GetRecentlyModelAsync()
        {
            //  await this.EnforceJobExistenceAsync(id);

            var entitities = await _modelParameterRepository.ListAsync();
            var entity = entitities.Where(c => c.RecordStatus == RecordStatus.ACTIVE.GetDescription()).OrderByDescending(c => c.Date).FirstOrDefault();
            if (entity == null)
            {
                throw new ParamsNotFoundException();
            }

            //get object matrix
            var matrix = await _modelPriorityParameterRepository.ListAsync(entity.Id);
            entity.Objectives = matrix.ToList();

            //get ros production type
            var products = await _modelProductionParameterRepository.ListAsync(entity.Id);
            entity.Productions = products.Where(c => c.Type == ProductionType.PRODUCTION.GetDescription()).OrderBy(c => c.Priority).ToList();
            entity.Drillings = products.Where(c => c.Type == ProductionType.DRILLING.GetDescription()).OrderBy(c => c.Priority).ToList();

            return entity;
        }

        ////


        public async Task<ModelPriorityParameter> CreateAsync(ModelPriorityParameter param)
        {
            param.Id = Guid.NewGuid();

            //await EnforceClanExistenceAsync(ModelPriorityParameter.Clan.Name);
            var entity = await _modelPriorityParameterRepository.CreateAsync(param);
            if (entity == null)
            {
                throw new ParamsNotFoundException(param.Id);
            }

            return entity;
        }


        public async Task<ModelPriorityParameter> UpdateAsync(ModelPriorityParameter param)
        {
            var updated = await this.EnforceModelObjectExistenceAsync(param.Id);

            //assigned
            //new rev and key
            //updated.Rev = Guid.NewGuid().ToString();
            //param.Key = Guid.NewGuid().ToString();

            var entity = await _modelPriorityParameterRepository.UpdateAsync(param);
            if (entity == null)
            {
                throw new ParamsNotFoundException(param.Id);
            }

            return entity;
        }

        public async Task<ModelPriorityParameter> GetModelObjectAsync(Guid id)
        {
            //  await this.EnforceModelObjectExistenceAsync(id);

            var entity = await _modelPriorityParameterRepository.GetAsync(id);
            return entity;
        }

        public async Task<IEnumerable<ModelPriorityParameter>> ListModelObjectAsync()
        {
            return await _modelPriorityParameterRepository.ListAsync();
        }

        public async Task<ModelPriorityParameter> EnforceModelObjectExistenceAsync(Guid id)
        {
            var param = await _modelPriorityParameterRepository.GetAsync(id);
            if (param == null)
            {
                throw new ParamsNotFoundException();
            }

            return param;
        }

    }

}