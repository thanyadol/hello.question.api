﻿using Chevron.KeyVault.Client;
using cvx.lct.vot.api.Environment;
using Microsoft.Azure.KeyVault.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Services
{
    public interface IChevronService
    {
        SecretBundle GetSecret(string secretName);
    }
    public sealed class ChevronService : IChevronService
    {
        private static string _keyVaultName;

        private static readonly ChevronService instance = new ChevronService();

        static ChevronService()
        {
            _keyVaultName = Configuration.Instance.GetKeyVaultName();
        }
        public static ChevronService Instance
        {
            get
            {
                return instance;
            }
        }

        public SecretBundle GetSecret(string secretName)
        {
            var kv = new CvxKeyVaultClient(_keyVaultName, Chevron.KeyVault.Client.ServiceTokenProviders.TokenProvider.AutoDetectTokenProvider);
            SecretBundle mySecret = null;
            Task.Run(async () =>
            {
                mySecret = await kv.GetSecretAsync(secretName);
            }).Wait();

            if (mySecret == null)
                throw new Exception($"Could not get secret {secretName} from {_keyVaultName} ");

            return mySecret;
        }

        public SecretBundle GetSecret(string keyVaultName, string secretName)
        {
            var kv = new CvxKeyVaultClient(keyVaultName, Chevron.KeyVault.Client.ServiceTokenProviders.TokenProvider.AutoDetectTokenProvider);
            SecretBundle mySecret = null;
            Task.Run(async () =>
            {
                mySecret = await kv.GetSecretAsync(secretName);
            }).Wait();

            if (mySecret == null)
                throw new Exception($"Could not get secret {secretName} from {keyVaultName} ");

            return mySecret;
        }
    }
}
