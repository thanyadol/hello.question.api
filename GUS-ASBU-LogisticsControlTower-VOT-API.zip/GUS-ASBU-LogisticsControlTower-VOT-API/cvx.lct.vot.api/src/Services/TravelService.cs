
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;


using cvx.lct.vot.api.Environment;
using cvx.lct.vot.api.Extensions;
using cvx.lct.vot.api.Exceptions;
using cvx.lct.vot.api.Models;
using cvx.lct.vot.api.Repositories;


using VESSEL = cvx.lct.vot.api.Models.Constant.Vessel;
using LOCATION = cvx.lct.vot.api.Models.Constant.Location;
using cvx.lct.vot.api.APIs.Services;
using FluentValidation.Results;
using Microsoft.ApplicationInsights;
using Microsoft.EntityFrameworkCore;
using surflex.netcore22.Models.DTO;

namespace cvx.lct.vot.api.Services
{
    public interface ITravelService
    {
        //Task<TravelParams> GetKeyParamsAsync(Guid id);

        Task<TravelActivity> PublishAsync(PublishParams param);
        Task<TravelActivity> GetLastPublishedAsync();
        Task<IEnumerable<TravelActivity>> ListRecentlyActivityAsync();


        //Stream GetResourceBlobAsync(PlanResource resource, PlanLocation planLocation);
        Task<IEnumerable<TravelParams>> ListRecentlyAsync();
        Task<TravelParams> GetAsync(Guid id);

        Task<TravelActivity> GetActivityAsync(Guid id);

        Task<TravelParams> GetLoadedAsync(Guid id);

        Task<TravelParams> GetRouteAsync(Guid id);
        Task<TravelParams> ListCurrentRouteAsync(Guid id);
        Task<TravelParams> GetDailyRouteAsync(Guid id);

        //  Task<IEnumerable<TravelRoute>> ListVesselCurrentRouteAsync();
        //  Task<IEnumerable<TravelRoute>> ListVesselDailyRouteAsync();
        Task<IEnumerable<RouteParams>> ListCurrentlyActivityAsync(Guid id);

        Task<Travel> PutTravelAsync(Guid id);

        Task<Travel> PutFavoriteAsync(Guid id);

        Task<TravelParams> GetMaterialAsync(Guid id);
        Task<TravelParams> GetVesselAsync(Guid id);
        Task<Attachment> GetAttachAsync(Job job, string status);

        Task<TravelParams> GetTurnaroundAsync(Guid id);

        //Task<ValidationResult> ValidatePublishedAsync(Guid id);

        Task<ValidationResult> ValidatePublishedAsync(PublishParams param);

        Task<TravelPublishParams> GetPublishParamsAsync(PublishParams param);
        Task<IEnumerable<TravelActivity>> ListPublishedAsync();

        Task<TravelParams> ListGulfAsync(Guid id);

        Task<Attachment> GetGulfAttachAsync();
        Task<TravelParams> GetJettyBlockAsync(Guid id);
    }

    public class TravelService : ITravelService
    {
        private readonly IJobRepository _jobRepository;
        private readonly ITravelRepository _travelRepository;
        private readonly ITravelActivityRepository _travelActivityRepository;

        private readonly ITravelBlockingRepository _travelBlockRepository;
        private readonly ITravelVesselRepository _travelVesselRepository;
        private readonly ITravelRouteRepository _travelRouteRepository;
        private readonly ITravelLoadedRepository _travelLoadedRepository;
        private readonly ITravelMaterialRepository _travelMaterialRespoitory;
        private readonly ITravelTurnaroundRepository _travelTurnaroudRespoitory;
        private readonly ITravelPublishRepository _travelPublishRepository;

        private readonly IVesselService _vesselService;
        private readonly IMaterialService _materialService;
        private readonly IAzureService _azureService;
        //private readonly IEntityService _clientService;
        private readonly IClientService _clientService;

        private readonly IWorkUnitExtension _workUnitService;
        private readonly IPlanService _planService;

        private readonly ILocationService _locationService;

        private readonly IJobService _jobService;
        private readonly IJobHubService _jobHubService;
        private readonly IUserService _userService;


        private const int PUBLSIHED_TIMESAPN_IN_DAYS = -7;

        private readonly User httpCurrentUser;
        public TravelService(IJobRepository jobRepository, IUserService httpService, IPlanService planService, IJobService jobService, IJobHubService jobHubService, ITravelMaterialRepository travelMaterialRespoitory, ITravelTurnaroundRepository travelTurnaroudRespoitory,
                        ITravelRepository jobPlanResultRepository, ITravelRouteRepository travelRouteRepository, ITravelVesselRepository travelVesselRepository, IWorkUnitExtension workUnitExtension, ITravelActivityRepository travelActivityRepository, ITravelPublishRepository travelPublishRepository,
                        IVesselService vesselService, ITravelLoadedRepository travelLoadedRepository, IAzureService azureService, IMaterialService materialService, IClientService clientService, ILocationService locationService, ITravelBlockingRepository travelBlockRepository) //, IEntityService _clientService)
        {
            _jobRepository = jobRepository ?? throw new ArgumentNullException(nameof(jobRepository));
            _travelRepository = jobPlanResultRepository ?? throw new ArgumentNullException(nameof(jobPlanResultRepository));
            _travelRouteRepository = travelRouteRepository ?? throw new ArgumentNullException(nameof(travelRouteRepository));
            _travelVesselRepository = travelVesselRepository ?? throw new ArgumentNullException(nameof(travelVesselRepository));
            _travelLoadedRepository = travelLoadedRepository ?? throw new ArgumentNullException(nameof(travelLoadedRepository));
            _travelMaterialRespoitory = travelMaterialRespoitory ?? throw new ArgumentNullException(nameof(travelMaterialRespoitory));
            _travelTurnaroudRespoitory = travelTurnaroudRespoitory ?? throw new ArgumentNullException(nameof(travelTurnaroudRespoitory));
            _travelPublishRepository = travelPublishRepository ?? throw new ArgumentNullException(nameof(travelPublishRepository));

            _travelBlockRepository = travelBlockRepository ?? throw new ArgumentNullException(nameof(travelBlockRepository));

            _planService = planService ?? throw new ArgumentNullException(nameof(planService));
            _vesselService = vesselService ?? throw new ArgumentNullException(nameof(vesselService));
            _jobService = jobService ?? throw new ArgumentNullException(nameof(jobService));

            _locationService = locationService ?? throw new ArgumentNullException(nameof(locationService));

            _jobHubService = jobHubService ?? throw new ArgumentNullException(nameof(jobHubService));

            _materialService = materialService ?? throw new ArgumentNullException(nameof(materialService));


            _azureService = azureService ?? throw new ArgumentNullException(nameof(azureService));
            _clientService = clientService ?? throw new ArgumentNullException(nameof(clientService));

            _travelActivityRepository = travelActivityRepository ?? throw new ArgumentNullException(nameof(travelActivityRepository));


            _userService = httpService ?? throw new ArgumentNullException(nameof(httpService));
            _workUnitService = workUnitExtension ?? throw new ArgumentNullException(nameof(workUnitExtension));

            httpCurrentUser = _userService.GetHttpCurrentUserAsync().Result;

            //logg
            Log.Logger = new LoggerConfiguration()
                            .WriteTo.Console()
                            .CreateLogger();
        }

        public async Task<Attachment> GetAttachAsync(Job job, string status)
        {

            var config = Configuration.Instance.GetPath();
            //var type = DownloadType.RESULT.ToString();//"";
            var filePath = "";
            var fileExtension = "";

            //compleretd
            if (status == JobStatus.SUCCEEDED.GetDescription())
            {
                filePath = $"{Configuration.Instance.GetBlobOutputUrl()}{job.Id}/{config.ResultFileName}";
                fileExtension = config.ResultExtension;
            }

            //preprocess
            else if (status == JobStatus.FAILED.GetDescription())
            {
                filePath = $"{Configuration.Instance.GetBlobInputUrl()}{job.Id}/{config.ProcessMmrFileName}";
                fileExtension = config.ProcessMmrExtension;
            }
            else
            {
                throw new JobNotValidException();
            }


            var uri = new Uri(filePath);
            var memoryStream = await _azureService.DownloadBlobAsync(uri);


            var entity = new Attachment()
            {
                Id = job.Id,
                Base64Value = Convert.ToBase64String(memoryStream.ToArray()),

                Extension = fileExtension,
                StorageType = StorageType.AZURE.GetDescription(),
            };

            //gen checksum
            entity.Checksum = entity.Base64Value.ToMD5();

            return entity;
        }


        public async Task<Attachment> GetGulfAttachAsync()
        {
            var config = Configuration.Instance.GetPath();

            var file = $"{Configuration.Instance.GetBlobTemplateUrl()}{config.SpotfireTemplate}";
            var extension = Path.GetExtension(file); ;

            var uri = new Uri(file);
            var memoryStream = await _azureService.DownloadBlobAsync(uri);

            var entity = new Attachment()
            {
                Id = Guid.NewGuid(),
                Base64Value = Convert.ToBase64String(memoryStream.ToArray()),

                Extension = extension,
                StorageType = StorageType.AZURE.GetDescription(),
            };

            //gen checksum
            entity.Checksum = entity.Base64Value.ToMD5();

            return entity;
        }


        //read json result file from blob
        public async Task<Travel> PutTravelAsync(Guid id)
        {
            var routes = await this.GetTravelRouteAsync(id);
            var materials = await this.GetTravelMaterialAsync(id);
            var loads = await this.GetTravelLoadedAsync(id);
            var turns = await this.GetTravelVesselTurnaroundAsync(id);
            var vessels = await this.GetTravelVesselSummaryAsync(id);

            var blocking = await this.GetTravelBlockAsync(id);

            routes.JobId = id;

            var entity = await this.PutAsync(routes, materials, loads, turns, vessels, blocking);
            return entity;
        }


        //persisted to db
        private async Task<Travel> PutAsync(TravelParams result, IEnumerable<MaterialMapping> materials,
                            TravelPrioritySummary loads, IEnumerable<TravelTurnaround> turns, IEnumerable<TravelVessel> vessels, IEnumerable<TravelBlocking> blocking)
        {
            var job = await _jobRepository.GetAsync(result.JobId);

            if (job == null)
                throw new TravelActivityNotFoundException(result.JobId);

            var travel = new Travel
            {
                Id = Guid.NewGuid(),
                PlanId = job.PlanId,
                StartDate = result.StartDate,
                EndDate = result.EndDate,
                JobId = result.JobId,
                TotalDistance = result.TotalDistance,
                TotalDuration = result.TotalDuration,
                CostRatioInUSD = result.CostRatioInUSD,
                CostRatioInUSDTrip1 = result.CostRatioInUSDTrip1,
                CostRatioInUSDTrip2 = result.CostRatioInUSDTrip2,
                FuelConsumption = result.FuelConsumption,
                DroppedMaterial = loads.DroppedMaterial,
                Date = DateTime.Now
            };

            using (var transaction = _workUnitService.BeginTransaction())
            {
                /*
                var existEntity = await _workUnitService.Travels.GetByJobIdAsync(travel.Id);
                if (existEntity != null)
                {
                    await _workUnitService.Travels.DeleteAsync(travel.Id);
                    await _workUnitService.TravelRoutes.DeleteRangeAsync(await _workUnitService.TravelRoutes.ListAsync(travel.JobId));
                    await _workUnitService.TravelLoadeds.DeleteRangeAsync(await _workUnitService.TravelLoadeds.ListAsync(travel.JobId));
                    await _workUnitService.TravelVessels.DeleteRangeAsync(await _workUnitService.TravelVessels.ListAsync(travel.JobId));
                    await _workUnitService.TravelMaterials.DeleteRangeAsync(await _workUnitService.TravelMaterials.ListAsync(travel.JobId));
                }
                */

                //create space
                var entity = await _workUnitService.Travels.CreateAsync(travel);

                var routes = result.RouteDetails.Select(s => new TravelRoute
                {
                    Id = Guid.NewGuid(),
                    TravelId = travel.Id,
                    VesselLCTReferenceId = s.VesselLCTReferenceId,
                    VesselName = s.VesselName,
                    Sequence = s.Sequence,
                    TripNo = s.TripNo,
                    FromLCTLocationReferenceId = s.FromLCTLocationReferenceId,
                    ToLCTLocationReferenceId = s.ToLCTLocationReferenceId,
                    FromLocationCode = s.FromLocationCode,
                    ToLocationCode = s.ToLocationCode,
                    OriginType = s.OriginType != null ? s.OriginType.ToLower().Trim() : string.Empty,
                    EtaDate = s.EtaDate,
                    EtdDate = s.EtdDate,
                    LoadingTime = s.LoadingTime,
                    OffLoadSpace = s.OffLoadSpace,
                    BackLoadSpace = s.BackLoadSpace,
                    SpaceRemaining = s.SpaceRemaining,
                    OffLoadWeight = s.OffLoadWeight,
                    BackLoadWeight = s.BackLoadWeight,
                    WeightRemaining = s.WeightRemaining,
                    Distance = s.Distance,
                    Speed = s.Speed,

                    //for gulf
                    FromLocationName = s.FromLocationName,
                    FromLocationType = s.FromLocationType,
                    FromLocationCategory = s.FromLocationCategory,
                    FromLatitude = s.FromLatitude,
                    FromLongitude = s.FromLongitude,
                    Asset = s.Asset,

                });

                await _workUnitService.TravelRoutes.CreateRangeAsync(routes);

                //Add loading list
                var planLoading = materials.Select(s => new TravelMaterial
                {
                    Id = Guid.NewGuid(),
                    TravelId = travel.Id,
                    VesselLCTReferenceId = s.VesselLCTReferenceId,
                    Sequence = s.Sequence,
                    ItemLCTReferenceId = s.MMRDetailId,
                    TripNo = s.TripNo,
                    MmrLCTReferenceId = s.MMRId,

                    DeliveredStatus = s.DeliveredStatus,

                    LctReferenceIsDeleted = false,
                    VotIsChanged = false,
                    OrderNumber = s.OrderNumber,
                });

                await _workUnitService.TravelMaterials.CreateRangeAsync(planLoading);

                //Add Vessel turnaround
                turns = turns.Select(s => new TravelTurnaround
                {
                    Id = Guid.NewGuid(),
                    TravelId = travel.Id,
                    VesselLCTReferenceId = s.VesselLCTReferenceId,
                    VesselName = s.VesselName,
                    DispatchDate = s.DispatchDate,
                    EtaDate = s.EtaDate,
                    TurnaroundTime = s.TurnaroundTime,
                    NumOfLocation = s.NumOfLocation,
                    CostRatioInUSD = s.CostRatioInUSD,
                    TripNo = s.TripNo,

                    CostInUSD = s.CostInUSD,
                    MT = s.MT
                });

                await _workUnitService.TravelTurnarounds.CreateRangeAsync(turns);

                //Add Vessel Summary
                vessels = vessels.Select(s => new TravelVessel
                {
                    Id = Guid.NewGuid(),
                    TravelId = travel.Id,
                    VesselLCTReferenceId = s.VesselLCTReferenceId,
                    TripNo = s.TripNo,
                    BoundType = s.BoundType,
                    BulkVolume = s.BulkVolume,
                    BulkWeight = s.BulkWeight,
                    CargoWeight = s.CargoWeight,
                    SpaceRemaining = s.SpaceRemaining,
                    TotalWeight = s.TotalWeight,

                    DryBulkVolume = s.DryBulkVolume,
                    LiquidBulkVolume = s.LiquidBulkVolume

                });

                await _workUnitService.TravelVessels.CreateRangeAsync(vessels);

                //create travel blocking
                blocking = blocking.Select(s => new TravelBlocking
                {
                    Id = Guid.NewGuid(),
                    TravelId = travel.Id,
                    VesselLCTReferenceId = s.VesselLCTReferenceId,
                    TripNo = s.TripNo,

                    Start = s.Start,
                    End = s.End,
                    Type = s.Type,
                    BlockedType = s.BlockedType,

                    TimeDuration = s.TimeDuration,
                    FuelConsumtionRate = s.FuelConsumtionRate,
                    FuelConsumtionRateType = s.FuelConsumtionRateType,
                    FuelConsumtionValue = s.FuelConsumtionValue,

                    Description = s.Description,
                });

                await _workUnitService.TravelBlockings.CreateRangeAsync(blocking);

                //Add priority
                var summaries = loads.PrioritySummary.Select(s => new TravelLoaded
                {
                    Id = Guid.NewGuid(),
                    TravelId = travel.Id,
                    Type = s.Type,
                    BoundType = s.BoundType,
                    Priority = s.Priority,
                    Delivery = s.Delivery,
                    Success = s.Success,
                    Total = s.Total
                });

                await _workUnitService.TravelLoadeds.CreateRangeAsync(summaries);

                try
                {
                    transaction.Commit();
                }
                catch (InvalidOperationException)
                {
                    transaction.Rollback();
                    throw new TravelNotFoundException();
                }
            }

            return travel;

        }


        private async Task<IEnumerable<MaterialMapping>> GetTravelMaterialAsync(Guid id)
        {

            var path = Configuration.Instance.GetPath();
            var entity = await GetTravelJsonAsync<IEnumerable<MaterialMapping>>($"{Configuration.Instance.GetBlobOutputUrl()}{id}/{path.LoadingListJson}");

            return entity;
        }

        private async Task<IEnumerable<TravelTurnaround>> GetTravelVesselTurnaroundAsync(Guid id)
        {
            var path = Configuration.Instance.GetPath();
            var entity = await GetTravelJsonAsync<IEnumerable<TravelTurnaround>>($"{Configuration.Instance.GetBlobOutputUrl()}{id}/{path.VesselTurnaround}");

            return entity;
        }

        private async Task<IEnumerable<TravelVessel>> GetTravelVesselSummaryAsync(Guid id)
        {
            var path = Configuration.Instance.GetPath();
            var entity = await GetTravelJsonAsync<IEnumerable<TravelVessel>>($"{Configuration.Instance.GetBlobOutputUrl()}{id}/{path.VesselSummary}");

            return entity;
        }

        private async Task<TravelPrioritySummary> GetTravelLoadedAsync(Guid id)
        {
            var path = Configuration.Instance.GetPath();
            var entity = await GetTravelJsonAsync<TravelPrioritySummary>($"{Configuration.Instance.GetBlobOutputUrl()}{id}/{path.MmrSummary}");

            return entity;
        }


        private async Task<TravelParams> GetTravelRouteAsync(Guid id)
        {
            var path = Configuration.Instance.GetPath();
            var entity = await GetTravelJsonAsync<TravelParams>($"{Configuration.Instance.GetBlobOutputUrl()}{id}/{path.RoutePlanJson}");

            return entity;
        }


        private async Task<IEnumerable<TravelBlocking>> GetTravelBlockAsync(Guid id)
        {
            var path = Configuration.Instance.GetPath();
            var entity = await GetTravelJsonAsync<IEnumerable<TravelBlocking>>($"{Configuration.Instance.GetBlobOutputUrl()}{id}/{path.VesselActivity}");

            return entity;
        }



        // private IEnumerable<VesselRoute> GetTravelRoutesAsync(TravelParams planTravelOutput, IEnumerable<MaterialMapping> materials, PlanParams plan)
        // {
        //     var vesselRoutes = new List<VesselRoute>();

        //     var vessels = planTravelOutput.Routes.GroupBy(g => new { g.VesselLCTReferenceId, g.TripNo }).Select(s => new
        //     {
        //         VesselId = s.First().VesselLCTReferenceId,
        //         TripNo = s.First().TripNo
        //     });

        //     foreach (var v in vessels)
        //     {
        //         var r = new VesselRoute();

        //         var prop = plan.PlanVessel.Properties.Where(c => c.LCTReferenceId == v.VesselId).FirstOrDefault();

        //         if (prop == null)
        //             throw new Exception("Could not find vessel id");

        //         r.VesselId = v.VesselId;
        //         r.VesselName = prop.Name;
        //         //  r.RouteDetails = planTravelOutput.Routes.Where(c => c.VesselLCTReferenceId == v.VesselId && c.TripNo == v.TripNo).OrderBy(o => o.Sequence);
        //         //Route
        //         if (r.RouteDetails != null)
        //         {
        //             r.FromLocationId = r.RouteDetails.First().FormLocationId;
        //             r.FromLocationCode = r.RouteDetails.First().FromLocationCode;
        //             r.ETD = r.RouteDetails.First().ETD;
        //             r.ETA = r.RouteDetails.Last().ETA;
        //             r.ToLocationId = r.RouteDetails.Last().ToLocationId;
        //             r.ToLocationCode = r.RouteDetails.Last().ToLocationCode;
        //         }
        //         //Material
        //         var materials = materials.Where(c => c.VesselId == v.VesselId);
        //         //r.Materials = materials;
        //         if (materials.Count() != 0)
        //         {
        //             var queryMaterails = (from m in plan.Tasks
        //                                   join d in materials on m.LCTMRMaterialRequestId equals d.MaterailDetailId //on m.LCTMRMaterialRequestDetailsId equals d.MaterailDetailId
        //                                   select new MaterialRequest
        //                                   {
        //                                       LCTMRMaterialRequestDetailsId = m.LCTMRMaterialRequestDetailsId,
        //                                       LCTMRMaterialRequestId = m.LCTMRMaterialRequestId,
        //                                       Priority = m.Priority,
        //                                       Asset = m.Asset,
        //                                       From = m.From,
        //                                       To = m.To,
        //                                       Department = m.Department,
        //                                       ROSDate = m.ROSDate,
        //                                       QuantityValue = m.QuantityValue,
        //                                       QuantityUnit = m.QuantityUnit,
        //                                       ItemType = m.ItemType,
        //                                       //Order number
        //                                       Length = m.Length,
        //                                       Width = m.Width,
        //                                       Height = m.Height,
        //                                       Area = m.Area,
        //                                       WeightValue = m.WeightValue,
        //                                       //WeightUnit
        //                                       Weight = m.Weight,
        //                                       //Vendor
        //                                       //Consignee
        //                                       //Hazmat
        //                                       //MaterailClass
        //                                       //UN
        //                                       //HighRentalCost
        //                                       Remarks = m.Remarks,
        //                                       //ReasonForPostpone
        //                                       Status = m.Status,
        //                                       //CreateDate,
        //                                       //LastModifiedBy
        //                                   }).ToList();

        //             r.MaterialRequests = queryMaterails;
        //         }

        //         vesselRoutes.Add(r);
        //     }

        //     return vesselRoutes;
        // }


        private async Task<T> GetTravelJsonAsync<T>(string path)
        {
            var uri = new Uri($"{path}");
            var memoryStream = await _azureService.DownloadBlobAsync(uri);
            memoryStream.Position = 0;

            StreamReader reader = new StreamReader(memoryStream);
            var jsonString = await reader.ReadToEndAsync();

            T objT = JsonConvert.DeserializeObject<T>(jsonString);

            return objT;
        }




        //
        // Summary:
        //     get current lct loading list 
        //
        // Returns:
        //
        //  TravelParams model
        //
        // Type parameters:
        //   id:
        //     Travel \  id
        //
        public async Task<TravelParams> ListCurrentRouteAsync(Guid id)
        {

            var travel = await _travelRepository.GetAsync(id);
            if (travel == null)
            {
                throw new TravelNotFoundException();
            }

            var entity = new TravelParams()
            {
                Id = travel.Id
            };

            var weekly = await _travelRouteRepository.ListAsync(id);
            if (weekly == null)
            {
                throw new TravelNotFoundException();
            }

            var colors = await _clientService.ListLocationColorAsync();

            //current and daily
            var ccs = await _vesselService.ListCurrentRouteAsync();
            var currents = ccs.Where(c => c.StatusId == (int)VesselRouteStatus.ACTIVE)
                        .Select(s => new TravelRoute
                        {
                            Id = Guid.NewGuid(),
                            VesselName = s.VesselName,
                            VesselLCTReferenceId = s.VesselId,
                            Sequence = s.Sequence,
                            EtaDate = s.ETA,
                            EtdDate = s.ETD,
                            FromLCTLocationReferenceId = s.FromId,
                            FromLocationCode = s.FromName,
                            ToLCTLocationReferenceId = s.ToId,
                            ToLocationCode = s.ToName,
                            PlanType = PlanType.CURRENT.GetDescription(),

                            ProcessETD = s.ProcessETD,

                            TripNo = 99,
                        }).OrderBy(c => c.EtaDate);


            var entities = new List<RouteParams>();

            var vin = weekly.Select(c => c.VesselLCTReferenceId).Distinct().ToArray();

            // //unoin rtoute
            var routes = currents.Where(p => vin.Contains(p.VesselLCTReferenceId)).OrderBy(c => c.VesselLCTReferenceId).ThenBy(x => x.Sequence);

            // Console.WriteLine(Newtonsoft.Json.JsonConvert.SerializeObject(routes));
            //orderds again
            //routes = routes.OrderBy(c => c.VesselLCTReferenceId).ThenBy(c => c.TripNo).ThenBy(c => c.Sequence).ToArray();

            //idle
            var vessels = from p in routes
                          group p by new { p.VesselLCTReferenceId, p.TripNo } into g
                          select new VesselParams
                          {
                              Id = g.Key.VesselLCTReferenceId.ToString(),
                              // Content = "g.FirstOrDefault().VesselName",
                              Value = 1,
                              ClassName = "openwheel trip" + g.Key.TripNo.ToString(),
                              EtaDate = g.Min(c => c.EtdDate).GetValueOrDefault(),   // min of ETD
                              EtdDate = g.Max(c => c.EtaDate).GetValueOrDefault(),   // max of ETA

                              TripNo = g.Key.TripNo,
                              StartSequence = g.Min(c => c.Sequence),
                              EndSequence = g.Max(c => c.Sequence),

                              PlanType = g.FirstOrDefault().PlanType,

                              VesselLCTReferenceId = g.Key.VesselLCTReferenceId

                          };

            //plot trips
            foreach (var c in vessels)
            {
                //mapped name
                entities.Add(new RouteParams()
                {
                    Id = Guid.NewGuid(),
                    //  VesselLCTReferenceId = c.Id,
                    // Sequence = i,
                    VesselName = c.Content,

                    //Trip = 1,
                    //  Value = i,
                    PlanType = c.PlanType,

                    Start = c.EtaDate.ToString("s"),
                    End = c.EtdDate.ToString("s"),

                    Content = "",
                    Group = c.Id,
                    ClassName = c.ClassName,
                    TravelType = "Idle",
                });

                var last = routes.Where(x => x.VesselLCTReferenceId == c.VesselLCTReferenceId).LastOrDefault();
                var first = routes.Where(x => x.VesselLCTReferenceId == c.VesselLCTReferenceId).FirstOrDefault(); //temp code

                //last node
                //back home node
                var end = new RouteParams()
                {

                    Id = Guid.NewGuid(),
                    Start = last.EtaDate.GetValueOrDefault().ToString("s"),
                    Content = first.FromLCTLocationReferenceId.ToString(),  ///back
                    Type = "box",

                    Group = last.VesselLCTReferenceId.ToString(),
                    ClassName = "rally end",
                    TravelType = "Loading",

                    PlanType = c.PlanType,

                };

                //temp code
                var value = LOCATION.DEFAULT_COLOR_CODE;  //LOCATION.HTML_COLOR_CODE[v.FromLCTLocationReferenceId]
                if (LOCATION.HTML_COLOR_CODE.TryGetValue(first.FromLCTLocationReferenceId, out value))
                {
                    // rr.Style = $"background-color: {value};";
                }

                var color = colors.Where(cc => cc.Id == first.FromLCTLocationReferenceId).FirstOrDefault();
                if (color != null)
                {
                    if (string.IsNullOrEmpty(color.AssetColor))
                        value = LOCATION.DEFAULT_COLOR_CODE;
                    else
                        value = color.AssetColor;
                }

                end.Style = $"background-color: {value};";
                entities.Add(end);

                //start
                var start = new RouteParams()
                {

                    Id = Guid.NewGuid(),
                    Start = first.EtdDate.GetValueOrDefault().ToString("s"),
                    Content = first.FromLCTLocationReferenceId.ToString(),  ///back
                    Type = "box",

                    Group = first.VesselLCTReferenceId.ToString(),
                    ClassName = "rally start",
                    TravelType = "Loading",

                    PlanType = c.PlanType,

                };

                //temp code
                var _value = LOCATION.DEFAULT_COLOR_CODE;  //LOCATION.HTML_COLOR_CODE[v.FromLCTLocationReferenceId]
                if (LOCATION.HTML_COLOR_CODE.TryGetValue(first.FromLCTLocationReferenceId, out value))
                {
                    // rr.Style = $"background-color: {value};";
                }

                var _color = colors.Where(cc => cc.Id == first.FromLCTLocationReferenceId).FirstOrDefault();
                if (color != null)
                {
                    if (string.IsNullOrEmpty(color.AssetColor))
                        value = LOCATION.DEFAULT_COLOR_CODE;
                    else
                        value = color.AssetColor;
                }

                start.Style = $"background-color: {_value};";
                entities.Add(start);
            }

            //  var filter = routes.Where(c => c.VesselLCTReferenceId == 37).ToList();

            //plot trips
            foreach (var vr in vessels)
            {

                //var prev = new TravelRoute() { EtaDate = null };
                //plot loading
                // !important
                var ploting = routes.Where(h => h.VesselLCTReferenceId == vr.VesselLCTReferenceId).OrderBy(h => h.Sequence).ToArray();

                for (int i = 0; i < ploting.Count(); i++)
                {
                    var v = ploting[i].DeepClone();
                    var rr = new RouteParams()
                    {

                        Id = v.Id, //focus purpose anmdd zoom
                        VesselLCTReferenceId = v.VesselLCTReferenceId,
                        End = v.ProcessETD.GetValueOrDefault().ToString("s"),

                        Content = v.ToLocationCode,

                        Group = v.VesselLCTReferenceId.ToString(),
                        ClassName = "rally",
                        TravelType = "Loading",

                        PlanType = v.PlanType,

                    };

                    try
                    {
                        rr.Start = v.EtaDate.GetValueOrDefault().ToString("s"); //null if terminal go to next block
                    }
                    catch (IndexOutOfRangeException) { }

                    //for start terminal plot
                    // string emp;
                    // if (LOCATION.TERMINALS.TryGetValue(v.FromLCTLocationReferenceId, out emp))
                    // {
                    //     rr.Start = v.EtdDate.GetValueOrDefault().ToString("s");
                    //     rr.Content = v.FromLCTLocationReferenceId.ToString();
                    //     rr.Type = "box";
                    //     rr.ClassName = "rally start";
                    // }

                    string _value = LOCATION.DEFAULT_COLOR_CODE;  //LOCATION.HTML_COLOR_CODE[v.FromLCTLocationReferenceId]
                    /*if (LOCATION.HTML_COLOR_CODE.TryGetValue(v.FromLCTLocationReferenceId, out value))
                     {
                         // rr.Style = $"background-color: {value};";
                     }*/

                    var _color = colors.Where(cc => cc.Id == v.ToLCTLocationReferenceId).FirstOrDefault();
                    if (_color != null)
                    {
                        if (string.IsNullOrEmpty(_color.AssetColor))
                        {
                            _value = LOCATION.DEFAULT_COLOR_CODE;
                        }
                        else
                            _value = _color.AssetColor;

                    }

                    rr.Style = $"background-color: {_value};";
                    entities.Add(rr);
                }

            }

            //lasr order
            entity.PlotRoutes = entities;

            return entity;
        }


        //
        // Summary:
        //     get daily lct loading list 
        //
        // Returns:
        //
        //  TravelParams model
        //
        // Type parameters:
        //   id:
        //     Travel \  id
        //
        public async Task<TravelParams> GetDailyRouteAsync(Guid id)
        {
            var travel = await _travelRepository.GetAsync(id);
            if (travel == null)
            {
                throw new TravelNotFoundException();
            }

            var entity = new TravelParams()
            {
                Id = travel.Id
            };

            var weekly = await _travelRouteRepository.ListAsync(id);
            if (weekly == null)
            {
                throw new TravelNotFoundException();
            }

            var colors = await _clientService.ListLocationColorAsync();

            //current and daily
            var ccs = await _vesselService.ListCurrentRouteAsync();
            var currents = ccs.Where(c => c.StatusId == (int)VesselRouteStatus.DAILY_CONFIRMED)
                        .Select(s => new TravelRoute
                        {
                            Id = Guid.NewGuid(),
                            VesselName = s.VesselName,
                            VesselLCTReferenceId = s.VesselId,
                            Sequence = s.Sequence,
                            EtaDate = s.ETA,
                            EtdDate = s.ETD,
                            FromLCTLocationReferenceId = s.FromId,
                            FromLocationCode = s.FromName,
                            ToLCTLocationReferenceId = s.ToId,
                            ToLocationCode = s.ToName,
                            PlanType = PlanType.DAILY.GetDescription(),

                            ProcessETD = s.ProcessETD,

                            TripNo = 98,
                        }).OrderBy(c => c.EtaDate);


            var entities = new List<RouteParams>();

            var vin = weekly.Select(c => c.VesselLCTReferenceId).Distinct().ToArray();

            // //unoin rtoute
            var routes = currents.Where(p => vin.Contains(p.VesselLCTReferenceId)).OrderBy(c => c.VesselLCTReferenceId).ThenBy(x => x.Sequence);

            // Console.WriteLine(Newtonsoft.Json.JsonConvert.SerializeObject(routes));
            //orderds again
            //routes = routes.OrderBy(c => c.VesselLCTReferenceId).ThenBy(c => c.TripNo).ThenBy(c => c.Sequence).ToArray();

            //idle
            var vessels = from p in routes
                          group p by new { p.VesselLCTReferenceId, p.TripNo } into g
                          select new VesselParams
                          {
                              Id = g.Key.VesselLCTReferenceId.ToString(),
                              // Content = "g.FirstOrDefault().VesselName",
                              Value = 1,
                              ClassName = "openwheel trip" + g.Key.TripNo.ToString(),
                              EtaDate = g.Min(c => c.EtdDate).GetValueOrDefault(),   // min of ETD
                              EtdDate = g.Max(c => c.EtaDate).GetValueOrDefault(),   // max of ETA

                              TripNo = g.Key.TripNo,
                              StartSequence = g.Min(c => c.Sequence),
                              EndSequence = g.Max(c => c.Sequence),

                              PlanType = g.FirstOrDefault().PlanType,

                              VesselLCTReferenceId = g.Key.VesselLCTReferenceId

                          };

            //plot trips
            foreach (var c in vessels)
            {
                //mapped name
                entities.Add(new RouteParams()
                {
                    Id = Guid.NewGuid(),
                    //  VesselLCTReferenceId = c.Id,
                    // Sequence = i,
                    VesselName = c.Content,

                    //Trip = 1,
                    //  Value = i,
                    PlanType = c.PlanType,

                    Start = c.EtaDate.ToString("s"),
                    End = c.EtdDate.ToString("s"),

                    Content = "",
                    Group = c.Id,
                    ClassName = c.ClassName,
                    TravelType = "Idle",
                });

                var last = routes.Where(x => x.VesselLCTReferenceId == c.VesselLCTReferenceId).LastOrDefault();
                var first = routes.Where(x => x.VesselLCTReferenceId == c.VesselLCTReferenceId).FirstOrDefault(); //temp code

                //last node
                //back home node
                var end = new RouteParams()
                {

                    Id = Guid.NewGuid(),
                    Start = last.EtaDate.GetValueOrDefault().ToString("s"),
                    Content = first.FromLCTLocationReferenceId.ToString(),  ///back
                    Type = "box",

                    Group = last.VesselLCTReferenceId.ToString(),
                    ClassName = "rally end",
                    TravelType = "Loading",

                    PlanType = c.PlanType,

                };

                //temp code
                var value = LOCATION.DEFAULT_COLOR_CODE;  //LOCATION.HTML_COLOR_CODE[v.FromLCTLocationReferenceId]
                if (LOCATION.HTML_COLOR_CODE.TryGetValue(first.FromLCTLocationReferenceId, out value))
                {
                    // rr.Style = $"background-color: {value};";
                }

                var color = colors.Where(cc => cc.Id == first.FromLCTLocationReferenceId).FirstOrDefault();
                if (color != null)
                {
                    if (string.IsNullOrEmpty(color.AssetColor))
                        value = LOCATION.DEFAULT_COLOR_CODE;
                    else
                        value = color.AssetColor;
                }

                end.Style = $"background-color: {value};";
                entities.Add(end);

                //start
                var start = new RouteParams()
                {

                    Id = Guid.NewGuid(),
                    Start = first.EtdDate.GetValueOrDefault().ToString("s"),
                    Content = first.FromLCTLocationReferenceId.ToString(),  ///back
                    Type = "box",

                    Group = first.VesselLCTReferenceId.ToString(),
                    ClassName = "rally start",
                    TravelType = "Loading",

                    PlanType = c.PlanType,

                };

                //temp code
                var _value = LOCATION.DEFAULT_COLOR_CODE;  //LOCATION.HTML_COLOR_CODE[v.FromLCTLocationReferenceId]
                if (LOCATION.HTML_COLOR_CODE.TryGetValue(first.FromLCTLocationReferenceId, out value))
                {
                    // rr.Style = $"background-color: {value};";
                }

                var _color = colors.Where(cc => cc.Id == first.FromLCTLocationReferenceId).FirstOrDefault();
                if (color != null)
                {
                    if (string.IsNullOrEmpty(color.AssetColor))
                        value = LOCATION.DEFAULT_COLOR_CODE;
                    else
                        value = color.AssetColor;
                }

                start.Style = $"background-color: {_value};";
                entities.Add(start);
            }

            //  var filter = routes.Where(c => c.VesselLCTReferenceId == 37).ToList();

            //plot trips
            foreach (var vr in vessels)
            {

                //var prev = new TravelRoute() { EtaDate = null };
                //plot loading
                // !important
                var ploting = routes.Where(h => h.VesselLCTReferenceId == vr.VesselLCTReferenceId).OrderBy(h => h.Sequence).ToArray();

                for (int i = 0; i < ploting.Count(); i++)
                {
                    var v = ploting[i].DeepClone();
                    var rr = new RouteParams()
                    {

                        Id = v.Id, //focus purpose anmdd zoom
                        VesselLCTReferenceId = v.VesselLCTReferenceId,
                        End = v.ProcessETD.GetValueOrDefault().ToString("s"),

                        Content = v.ToLocationCode,

                        Group = v.VesselLCTReferenceId.ToString(),
                        ClassName = "rally",
                        TravelType = "Loading",

                        PlanType = v.PlanType,

                    };

                    try
                    {
                        rr.Start = v.EtaDate.GetValueOrDefault().ToString("s"); //null if terminal go to next block
                    }
                    catch (IndexOutOfRangeException) { }

                    //for start terminal plot
                    // string emp;
                    // if (LOCATION.TERMINALS.TryGetValue(v.FromLCTLocationReferenceId, out emp))
                    // {
                    //     rr.Start = v.EtdDate.GetValueOrDefault().ToString("s");
                    //     rr.Content = v.FromLCTLocationReferenceId.ToString();
                    //     rr.Type = "box";
                    //     rr.ClassName = "rally start";
                    // }

                    string _value = LOCATION.DEFAULT_COLOR_CODE;  //LOCATION.HTML_COLOR_CODE[v.FromLCTLocationReferenceId]
                    /*if (LOCATION.HTML_COLOR_CODE.TryGetValue(v.FromLCTLocationReferenceId, out value))
                     {
                         // rr.Style = $"background-color: {value};";
                     }*/

                    var _color = colors.Where(cc => cc.Id == v.ToLCTLocationReferenceId).FirstOrDefault();
                    if (_color != null)
                    {
                        if (string.IsNullOrEmpty(_color.AssetColor))
                        {
                            _value = LOCATION.DEFAULT_COLOR_CODE;
                        }
                        else
                            _value = _color.AssetColor;

                    }

                    rr.Style = $"background-color: {_value};";
                    entities.Add(rr);
                }

            }

            //lasr order
            entity.PlotRoutes = entities;

            return entity;
        }



        //
        // Summary:
        //     get loading list 
        //
        // Returns:
        //
        //  TravelParams model
        //
        // Type parameters:
        //   id:
        //     Travel \  id
        //
        public async Task<TravelParams> GetJettyBlockAsync(Guid id)
        {

            var travel = await _travelRepository.GetAsync(id);
            if (travel == null)
            {
                throw new TravelNotFoundException();
            }

            var entity = new TravelParams()
            {
                Id = travel.Id
            };

            var routes = await _travelRouteRepository.ListAsync(id);
            if (routes == null)
            {
                throw new TravelNotFoundException();
            }

            var blockings = await _travelBlockRepository.ListAsync(id);
            if (!blockings.Any())
            {
                throw new TravelNotFoundException();
            }
            blockings = blockings.OrderBy(c => c.Start);

            //orderds
            routes = routes.OrderBy(c => c.VesselLCTReferenceId).ThenBy(c => c.TripNo).ThenBy(c => c.Sequence).ToArray();

            //set plantype
            routes = routes.Select(c => { c.PlanType = PlanType.WEEKLY.GetDescription(); return c; }).ToList();

            var entities = new List<RouteParams>();
            //idle
            var vessels = from p in routes
                          group p by new { p.VesselLCTReferenceId, p.TripNo } into g
                          select new VesselParams
                          {
                              Id = g.Key.VesselLCTReferenceId.ToString(),
                              // Content = "g.FirstOrDefault().VesselName",
                              Value = 1,
                              ClassName = "openwheel trip" + g.Key.TripNo.ToString(),
                              EtaDate = g.Min(c => c.EtdDate).GetValueOrDefault(),   // min of ETD
                              EtdDate = g.Max(c => c.EtaDate).GetValueOrDefault(),   // max of ETA

                              TripNo = g.Key.TripNo,
                              StartSequence = g.Min(c => c.Sequence),
                              EndSequence = g.Max(c => c.Sequence),

                              PlanType = g.FirstOrDefault().PlanType,

                          };

            //plot trips
            foreach (var c in vessels)
            {
                var activity = blockings.Where(x => x.VesselLCTReferenceId == Convert.ToInt16(c.Id) && x.TripNo == c.TripNo);
                if (!activity.Any())
                {
                    continue;
                }

                //terminal port service al time
                entities.Add(new RouteParams()
                {
                    Id = Guid.NewGuid(),
                    //  VesselLCTReferenceId = c.Id,
                    // Sequence = i,
                    VesselName = c.Content,

                    //Trip = 1,
                    //  Value = i,
                    PlanType = PlanType.JETTY_ACTIVITY.GetDescription(),

                    Start = activity.Min(y => y.Start).ToString("s"),
                    End = c.EtaDate.ToString("s"),

                    Content = "",
                    Group = c.Id,
                    ClassName = "endurance trip" + c.TripNo.ToString(),
                    TravelType = TravelType.PORT.GetDescription(),
                });


                foreach (var aa in activity)
                {
                    var ts6 = aa.End.Subtract(aa.Start);

                    //add queue
                    entities.Add(new RouteParams()
                    {
                        Id = Guid.NewGuid(),
                        //  VesselLCTReferenceId = c.Id,
                        // Sequence = i,
                        VesselName = c.Content,

                        //Trip = 1,
                        //  Value = i,
                        PlanType = PlanType.JETTY_ACTIVITY.GetDescription(),

                        Start = aa.Start.ToString("s"),
                        End = aa.End.ToString("s"),

                        Content = String.Format("{0} ({1} hrs)", aa.BlockedType, ts6.TotalHours),
                        Group = c.Id,
                        ClassName = "rally " + aa.BlockedType.ToLower(),
                        TravelType = aa.BlockedType
                    });

                }

            }

            //lasr order
            entity.PlotBlocking = entities;

            return entity;
        }



        //
        // Summary:
        //     get loading list 
        //
        // Returns:
        //
        //  TravelParams model
        //
        // Type parameters:
        //   id:
        //     Travel \  id
        //
        public async Task<TravelParams> GetRouteAsync(Guid id)
        {

            var travel = await _travelRepository.GetAsync(id);
            if (travel == null)
            {
                throw new TravelNotFoundException();
            }

            var entity = new TravelParams()
            {
                Id = travel.Id
            };

            var routes = await _travelRouteRepository.ListAsync(id);
            if (routes == null)
            {
                throw new TravelNotFoundException();
            }


            var colors = await _clientService.ListLocationColorAsync();

            //filter
            // routes = routes.Where(c => c.TravelId == id);

            //orderds
            routes = routes.OrderBy(c => c.VesselLCTReferenceId).ThenBy(c => c.TripNo).ThenBy(c => c.Sequence).ToArray();

            //set plantype
            routes = routes.Select(c => { c.PlanType = PlanType.WEEKLY.GetDescription(); return c; }).ToList();

            var entities = new List<RouteParams>();
            var routings = new List<TravelRoute>();
            //idle
            var vessels = from p in routes
                          group p by new { p.VesselLCTReferenceId, p.TripNo } into g
                          select new VesselParams
                          {
                              Id = g.Key.VesselLCTReferenceId.ToString(),
                              // Content = "g.FirstOrDefault().VesselName",
                              Value = 1,
                              ClassName = "openwheel trip" + g.Key.TripNo.ToString(),
                              EtaDate = g.Min(c => c.EtdDate).GetValueOrDefault(),   // min of ETD
                              EtdDate = g.Max(c => c.EtaDate).GetValueOrDefault(),   // max of ETA

                              TripNo = g.Key.TripNo,
                              StartSequence = g.Min(c => c.Sequence),
                              EndSequence = g.Max(c => c.Sequence),

                              PlanType = g.FirstOrDefault().PlanType,

                          };

            //plot trips
            foreach (var c in vessels)
            {
                //add queue
                /*entities.Add(new RouteParams()
                {
                    Id = Guid.NewGuid(),
                    //  VesselLCTReferenceId = c.Id,
                    // Sequence = i,
                    VesselName = c.Content,

                    //Trip = 1,
                    //  Value = i,
                    PlanType = PlanType.JETTY_ACTIVITY.GetDescription(),

                    Start = c.EtaDate.AddHours(-32).ToString("s"),
                    End = c.EtaDate.AddHours(-16).ToString("s"),

                    Content = "Queue",
                    Group = c.Id,
                    ClassName = "rally queue",
                    TravelType = TravelType.QUEUE.GetDescription(),
                });


                //add cargo loading
                entities.Add(new RouteParams()
                {
                    Id = Guid.NewGuid(),
                    //  VesselLCTReferenceId = c.Id,
                    // Sequence = i,
                    VesselName = c.Content,

                    //Trip = 1,
                    //  Value = i,
                    PlanType = PlanType.JETTY_ACTIVITY.GetDescription(),
                    Start = c.EtaDate.AddHours(-15).ToString("s"),
                    End = c.EtaDate.AddHours(-8).ToString("s"),

                    Content = "Cargo",
                    Group = c.Id,
                    ClassName = "rally cargo",
                    TravelType = TravelType.CARGO.GetDescription(),
                });


                //add pm
                entities.Add(new RouteParams()
                {
                    Id = Guid.NewGuid(),
                    //  VesselLCTReferenceId = c.Id,
                    // Sequence = i,
                    VesselName = c.Content,

                    //Trip = 1,
                    //  Value = i,
                    PlanType = PlanType.JETTY_ACTIVITY.GetDescription(),

                    Start = c.EtaDate.AddHours(-7).ToString("s"),
                    End = c.EtaDate.AddHours(-1).ToString("s"),

                    Content = "PM",
                    Group = c.Id,
                    ClassName = "rally pm",
                    TravelType = TravelType.PM.GetDescription(),
                });


                //terminal port service al time
                entities.Add(new RouteParams()
                {
                    Id = Guid.NewGuid(),
                    //  VesselLCTReferenceId = c.Id,
                    // Sequence = i,
                    VesselName = c.Content,

                    //Trip = 1,
                    //  Value = i,
                    PlanType = PlanType.JETTY_ACTIVITY.GetDescription(),

                    Start = c.EtaDate.AddHours(-50).ToString("s"),
                    End = c.EtaDate.ToString("s"),

                    Content = "",
                    Group = c.Id,
                    ClassName = "endurance",
                    TravelType = TravelType.PORT.GetDescription(),
                });*/


                //////////////////////////////

                //mapped name
                entities.Add(new RouteParams()
                {
                    Id = Guid.NewGuid(),
                    //  VesselLCTReferenceId = c.Id,
                    // Sequence = i,
                    VesselName = c.Content,

                    //Trip = 1,
                    //  Value = i,
                    PlanType = c.PlanType,

                    Start = c.EtaDate.ToString("s"),
                    End = c.EtdDate.ToString("s"),

                    Content = "",
                    Group = c.Id,
                    ClassName = c.ClassName,
                    TravelType = TravelType.IDLE.GetDescription(),
                });

                var quries = routes.Where(x => x.VesselLCTReferenceId.ToString() == c.Id && x.TripNo == c.TripNo).OrderBy(cj => cj.Sequence);

                var last = quries.LastOrDefault();
                var first = quries.FirstOrDefault(); //temp code

                //last node
                //back home node
                var end = new RouteParams()
                {

                    Id = first.Id,
                    Start = last.EtaDate.GetValueOrDefault().ToString("s"),
                    Content = first.FromLCTLocationReferenceId.ToString(),  ///back
                    Type = "box",

                    Group = last.VesselLCTReferenceId.ToString(),
                    ClassName = "rally end",
                    TravelType = TravelType.LOADING.GetDescription(),

                    PlanType = c.PlanType,

                };

                //temp code
                var value = LOCATION.DEFAULT_COLOR_CODE;  //LOCATION.HTML_COLOR_CODE[v.FromLCTLocationReferenceId]
                if (LOCATION.HTML_COLOR_CODE.TryGetValue(first.FromLCTLocationReferenceId, out value))
                {
                    // rr.Style = $"background-color: {value};";
                }

                var locColor = colors.Where(cc => cc.Id == first.FromLCTLocationReferenceId).FirstOrDefault();
                if (locColor != null)
                {
                    if (string.IsNullOrEmpty(locColor.AssetColor))
                        value = LOCATION.DEFAULT_COLOR_CODE;
                    else
                        value = locColor.AssetColor;
                }

                end.Style = $"background-color: {value};";
                entities.Add(end);

                //temp code  ??? what the fucking bug ??? 
                //Message: "Invalid column name 'RouteParamsId'."
                // var locations = await _locationService.ListAsync();

                //route
                //var prev = new TravelRoute() { EtaDate = null };
                //plot loading
                // !important
                var arr = quries.ToArray();

                for (int i = 0; i < quries.Count(); i++)
                {
                    //deep copy object
                    var v = arr[i].DeepClone();

                    var rr = new RouteParams()
                    {

                        Id = v.Id, //focus purpose anmdd zoom
                        VesselLCTReferenceId = v.VesselLCTReferenceId,
                        End = v.EtdDate.GetValueOrDefault().ToString("s"),

                        Content = v.FromLocationCode,

                        Group = v.VesselLCTReferenceId.ToString(),
                        ClassName = "rally",
                        TravelType = TravelType.LOADING.GetDescription(),

                        PlanType = v.PlanType,
                    };

                    //mock get visited
                    // var clt = locations.Where(x => x.LCTReferenceId == v.VesselLCTReferenceId).FirstOrDefault();
                    rr.Visited = new List<Location>()
                    {
                        new Location() { Id = Guid.NewGuid(), Code = "H"},
                        new Location() { Id = Guid.NewGuid(), Code = "E"},
                        new Location() { Id = Guid.NewGuid(), Code = "L"},
                        new Location() { Id = Guid.NewGuid(), Code = "L"},
                        new Location() { Id = Guid.NewGuid(), Code = "O"}
                    };

                    var arrs = rr.Visited.Select(x => x.Code).ToArray();
                    rr.VisitedDisplay = string.Join(" - ", arrs);

                    routings.Add(v);

                    try
                    {
                        rr.Start = arr[i - 1].EtaDate.GetValueOrDefault().ToString("s"); //null if terminal go to next block
                    }
                    catch (IndexOutOfRangeException) { }

                    //for start terminal plot
                    string emp;
                    if (LOCATION.TERMINALS.TryGetValue(v.FromLCTLocationReferenceId, out emp))
                    {
                        //removed id for start (removed timeline focus)
                        rr.Id = Guid.NewGuid();

                        rr.Start = v.EtdDate.GetValueOrDefault().ToString("s");
                        rr.Content = v.FromLCTLocationReferenceId.ToString();
                        rr.Type = "box";
                        rr.ClassName = "rally start";
                    }

                    string val = LOCATION.DEFAULT_COLOR_CODE;  //LOCATION.HTML_COLOR_CODE[v.FromLCTLocationReferenceId]
                    /* if (LOCATION.HTML_COLOR_CODE.TryGetValue(v.ToLCTLocationReferenceId, out value))
                    {
                        rr.Id = sid;
                        // rr.Style = $"background-color: {value};";
                    }*/

                    var lc = colors.Where(cc => cc.Id == v.FromLCTLocationReferenceId).FirstOrDefault();
                    if (lc != null)
                    {
                        if (string.IsNullOrEmpty(lc.AssetColor))
                        {
                            val = LOCATION.DEFAULT_COLOR_CODE;
                        }
                        else
                            val = lc.AssetColor;
                    }

                    rr.Style = $"background-color: {val};";
                    entities.Add(rr);
                }

            }

            //group vessel
            var query = from p in routes
                        group p by p.VesselLCTReferenceId into g
                        select new VesselParams
                        {
                            Id = g.Key.ToString(),
                            Content = g.FirstOrDefault().VesselName,
                            Value = 1,
                            ClassName = "openwheel",
                            Start = g.Min(c => c.EtdDate).GetValueOrDefault().ToString("s"),
                            //     End = g.Max(c => c.EtdDate).GetValueOrDefault().ToString("s"),
                        };

            //lasr order
            entity.PlotRoutes = entities;

            entity.GroupVessels = query.OrderBy(c => c.Start);

            //transform distanct to nm
            routings = routings.Select(c => { c.Distance = c.Distance * VESSEL.NAUTICAL_MILE_CONVERT_CONSTANT; return c; }).ToList();

            //set detail table only trip 1, 2
            //  var trips = new int[] { 1, 2 };
            entity.RouteDetails = routings; //.Where(c => trips.Contains(c.TripNo)).OrderBy(c => c.VesselLCTReferenceId).ThenBy(c => c.EtdDate);


            return entity;
        }


        //
        // Summary:
        //     get loading list 
        //
        // Returns:
        //
        //  TravelParams model
        //
        // Type parameters:
        //   id:
        //     Travel \  id
        //
        public async Task<TravelParams> GetLoadedAsync(Guid id)
        {
            var travel = await _travelRepository.GetAsync(id);
            if (travel == null)
            {
                throw new TravelNotFoundException();
            }

            //new object
            var entity = new TravelParams()
            {
                Id = id,
            };

            var loadeds = await _travelLoadedRepository.ListAsync();
            var backLoads = loadeds.Where(c => c.TravelId == id && c.BoundType == BoundType.BACKLOAD.ToString()).ToList();
            if (backLoads == null)
            {
                //backLoads = new List<TravelLoaded>();
            }

            //add all P logic
            // if (!backLoads.Where(c => c.Priority == "P1").Any()) backLoads.Add(new TravelLoaded { Priority = "P1", Success = 0, Delivery = 0, Total = 0, Order = 0 });
            // if (!backLoads.Where(c => c.Priority == "P2").Any()) backLoads.Add(new TravelLoaded { Priority = "P2", Success = 0, Delivery = 0, Total = 0, Order = 0 });
            // if (!backLoads.Where(c => c.Priority == "P3").Any()) backLoads.Add(new TravelLoaded { Priority = "P3", Success = 0, Delivery = 0, Total = 0, Order = 0 });


            //cal percentage
            backLoads = backLoads.Select(c =>
            {
                if (c.Total.GetValueOrDefault() > 0)
                {
                    c.DevileredPercentage = (c.Delivery.GetValueOrDefault() / c.Total.GetValueOrDefault()) * 100;
                    c.SuccessedPercentage = (c.Success.GetValueOrDefault() / c.Total.GetValueOrDefault()) * 100;
                }

                c.Order = 1; //for sorting
                return c;
            }).ToList();

            string[] types = { "CURRENT", "EXPIRED" };
            //  decimal grandSucces = 0;
            //   decimal grandDelivery = 0;
            // decimal grandTotal = 0;

            foreach (var s in types)
            {
                //backload current
                decimal success = backLoads.Where(c => c.Type.Trim() == s).Sum(c => c.Success.GetValueOrDefault());
                decimal deliver = backLoads.Where(c => c.Type.Trim() == s).Sum(c => c.Delivery.GetValueOrDefault());
                decimal total = backLoads.Where(c => c.Type.Trim() == s).Sum(c => c.Total.GetValueOrDefault());

                var v = new TravelLoaded() { Total = total, Order = 99, Type = s, Priority = s };
                if (total > 0)
                {
                    v.SuccessedPercentage = (success / total) * 100;
                    v.DevileredPercentage = (deliver / total) * 100;
                }
                backLoads.Add(v);

                // if (s == types[0])
                // {
                //     entity.BackLoadSuccessPercentage = (success / total) * 100;
                // }

                //  grandDelivery += deliver;
                //  grandSucces += success;
                //  grandTotal += total;
            }
            entity.BackLoads = backLoads.OrderBy(c => c.Order).ThenBy(c => c.Priority);

            //grand total
            //entity.BackLoadSuccessPercentage = grandSucces / grandTotal * 100;  //backLoads.Where(c => types.Contains(c.Priority)).Sum(c => c.SuccessedPercentage.GetValueOrDefault());
            //entity.BackLoadDeliveredPercentage = grandDelivery / grandTotal * 100; //backLoads.Where(c => types.Contains(c.Priority)).Sum(c => c.DevileredPercentage.GetValueOrDefault());

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            var offloads = loadeds.Where(c => c.TravelId == id && c.BoundType == BoundType.OFFLOAD.ToString()).ToList();

            if (offloads == null)
            {
                //offloads = new List<TravelLoaded>();
            }

            // if (!offloads.Where(c => c.Priority == "P1").Any()) offloads.Add(new TravelLoaded { Type="" Priority = "P1", Success = 0, Delivery = 0, Total = 0, Order = 0 });
            // if (!offloads.Where(c => c.Priority == "P2").Any()) offloads.Add(new TravelLoaded { Priority = "P2", Success = 0, Delivery = 0, Total = 0, Order = 0 });
            // if (!offloads.Where(c => c.Priority == "P3").Any()) offloads.Add(new TravelLoaded { Priority = "P3", Success = 0, Delivery = 0, Total = 0, Order = 0 });

            //cal percentage
            offloads = offloads.Select(c =>
            {
                if (c.Total.GetValueOrDefault() > 0)
                {
                    c.DevileredPercentage = (c.Delivery.GetValueOrDefault() / c.Total.GetValueOrDefault()) * 100;
                    c.SuccessedPercentage = (c.Success.GetValueOrDefault() / c.Total.GetValueOrDefault()) * 100;
                }

                c.Order = 1; //for sorting

                return c;
            }).ToList();

            // grandDelivery = 0;
            // grandSucces = 0;
            //  grandTotal = 0;

            foreach (var s in types)
            {
                //backload current
                decimal success = offloads.Where(c => c.Type.Trim() == s).Sum(c => c.Success.GetValueOrDefault());
                decimal deliver = offloads.Where(c => c.Type.Trim() == s).Sum(c => c.Delivery.GetValueOrDefault());
                decimal total = offloads.Where(c => c.Type.Trim() == s).Sum(c => c.Total.GetValueOrDefault());

                var v = new TravelLoaded() { Total = total, Order = 99, Type = s, Priority = s };
                if (total > 0)
                {
                    v.SuccessedPercentage = (success / total) * 100;
                    v.DevileredPercentage = (deliver / total) * 100;
                }
                offloads.Add(v);


                // if (s == types[0])
                // {
                //     entity.OffLoadSuccessPercentage = (success / total) * 100;
                // }

                //   grandDelivery += deliver;
                //   grandSucces += success;
                //   grandTotal += total;
            }

            entity.OffLoads = offloads.OrderBy(c => c.Order).ThenBy(c => c.Priority);

            //entity.OffLoadSuccessPercentage = grandSucces / grandTotal * 100;// offloads.Where(c => types.Contains(c.Priority)).Sum(c => c.SuccessedPercentage.GetValueOrDefault());
            //entity.OffLoadDeliveredPercentage = grandDelivery / grandTotal * 100;// offloads.Where(c => types.Contains(c.Priority)).Sum(c => c.DevileredPercentage.GetValueOrDefault());

            return entity;
        }

        public async Task<ValidationResult> ValidatePublishedAsync(PublishParams param)
        {
            var id = param.TravelId;
            var travel = await _travelRepository.GetAsync(id);
            if (travel == null)
            {
                throw new TravelNotFoundException();
            }

            //get plan week yaer
            var plan = await _planService.GetAsync(travel.PlanId);
            if (plan == null)
            {
                throw new PlanNotFoundException();
            }

            var currents = await _materialService.SynceTaskAsync();


            //remove week year machnic
            /* try
             {
                 //has one or more published by week year
                 var publish = await _planService.GetPublishWeekAsync(plan.Week, plan.Year);

                 //snaps publish mmr that lost from lct
                 var snaps = await _materialService.ListTaskAsync(publish.Id);

                 //union
                 currents = currents.Union(snaps.Where(c => c.IsIncludeToCalculate == true));
             }
             catch (PlanNotFoundException) { }*/

            var loads = await _travelMaterialRespoitory.ListAsync(travel.Id);
            if (loads == null)
            {
                throw new TravelNotFoundException();
            }

            var mmrs = await _materialService.ListRequestAsync(travel.PlanId);

            //var arr = loads.Select(c => c.MmrLCTReferenceId).ToArray();
            // var filters = mmrs.Where(c => arr.Contains(c.LCTMRMaterialRequestId.GetValueOrDefault()));
            IEnumerable<TravelMaterial> loss = null;
            if (!param.IsEnableRePublish)
            {
                //compared 2 list for validate (find to drop)
                var curs = currents.Where(c => c.IsAssignedToVessel != true).Select(c => c.LCTMRMaterialRequestDetailsId).ToArray();
                loss = loads.Where(c => !curs.Contains(c.ItemLCTReferenceId));
            }
            else
            {
                //get cuurent mmr synce with assign to vessel flag
                var curs = currents.Where(c => c.IsAssignedToVessel != true).Select(c => c.LCTMRMaterialRequestDetailsId).ToArray();

                //get last publish complete
                var last = await _travelActivityRepository.GetRecentlyAsync();
                if (last != null)
                {
                    //get old pubish list
                    var olds = await _travelMaterialRespoitory.ListAsync(last.TravelId);
                    if (olds != null)
                    {
                        var prevs = olds.Where(c => c.LctReferenceIsDeleted == false).Select(c => c.ItemLCTReferenceId);

                        //new load not in old
                        loads = loads.Where(c => !prevs.Contains(c.ItemLCTReferenceId));
                    }
                }

                loss = loads.Where(c => !curs.Contains(c.ItemLCTReferenceId));
            }

            //vessel
            var vessels = await _clientService.ListVesselAsync();

            //join with task
            var query = (from m in loss
                         join t in mmrs
                         on new { a = m.ItemLCTReferenceId, } // b = m.OrderNumber }
                         equals new { a = t.LCTMRMaterialRequestDetailsId, } // b = t.LCTOrderNumber }
                         where String.IsNullOrEmpty(m.OrderNumber) == String.IsNullOrEmpty(t.LCTOrderNumber)
                         select new MaterialParams
                         {

                             Id = m.Id,
                             TravelId = id,
                             Sequence = m.Sequence.GetValueOrDefault(),
                             ItemLCTReferenceId = m.ItemLCTReferenceId.GetValueOrDefault(),
                             LCTMRMaterialRequestDetailsId = t.LCTMRMaterialRequestDetailsId.GetValueOrDefault(),
                             LCTMRMaterialRequestId = t.LCTMRMaterialRequestId.GetValueOrDefault(),

                             //VesselName = "m.VesselLCTReferenceId",
                             VesselLCTReferenceId = m.VesselLCTReferenceId.GetValueOrDefault(),
                             LCTOrderNumber = t.LCTOrderNumber,
                             DropOrderNumber = m.OrderNumber,
                             //CurrentAssignedVessel = 

                             VesselName = vessels.FirstOrDefault(c => c.Id == m.VesselLCTReferenceId).Name,
                             // FinalDestination = "",

                             BoundType = t.BoundType,

                             //PlanId = plan.Id,
                             MRPriorityReferenceId = t.MRPriorityReferenceId,
                             Priority = t.Priority,
                             Asset = t.Asset,
                             From = t.From,
                             LCTOriginReferenceId = t.LCTOriginReferenceId,
                             To = t.To,
                             LCTDestinationReferenceId = t.LCTDestinationReferenceId,

                             ItemType = t.ItemType,
                             Qty = t.Qty,
                             QuantityUnit = t.QuantityUnit,

                             Area = t.Area,
                             Length = t.Length,
                             Weight = t.Weight,
                             Height = t.Height,

                             Width = t.Width,

                             // WeightUnit = t.WeightValue
                             FinalDestination = t.BoundType == BoundType.OFFLOAD.GetDescription() ? t.To : t.From,
                             Department = t.Department,
                             Description = t.Description,
                             LCTMMRReferenceNumber = 0,

                             ROSDate = t.ROSDate,

                             TripNo = m.TripNo.GetValueOrDefault(),
                         });

            var val = new ValidationResult() { };

            if (query.Any())
            {
                //mocke
                var errs = new List<ValidationFailure>();
                errs.Add(new ValidationFailure("Routes", "Route creation failed due to non-pending items") { });

                throw new TravelNotValidException(errs, query.ToList());
            }

            return val;
        }



        //set is change and is delete and persitsed DB
        private async Task<bool> RemoveNonOutstandingItemAsync(PublishParams param)
        {
            var loadinglist = await _travelMaterialRespoitory.ListAsync(param.TravelId);

            if (param.DroppedTasks != null && param.DroppedTasks.Count() > 0)
            {
                var drops = param.DroppedTasks.Select(c => c.ItemLCTReferenceId);
                loadinglist = loadinglist.Where(c => drops.Contains(c.ItemLCTReferenceId.GetValueOrDefault())).Select(c =>
                {
                    c.VotIsChanged = true;
                    c.LctReferenceIsDeleted = true;
                    return c;
                });


                var entities = await _travelMaterialRespoitory.UpdateRangeAsync(loadinglist);
                return true;
            }
            return true;
        }


        //
        // Summary:
        //     publish plan to LCT
        //
        // Returns:
        //
        //  TravelParams model
        //
        // Type parameters:
        //   id:
        //     Travel \  id
        //
        public async Task<TravelActivity> PublishAsync(PublishParams param)
        {
            await Task.Delay(500);

            var id = param.TravelId;

            //revision for tracking repubish sequence
            //get current publsih
            var current = await _travelActivityRepository.GetRecentlyAsync();
            if (current == null)
            {
                // param.IsEnableRePublish = false;
            }

            var exception = "default";

            var travel = await _travelRepository.GetAsync(id);
            if (travel == null)
            {
                throw new TravelNotFoundException();
            }

            var status = PublishStatus.COMPLETED.GetDescription();
            var publishId = Guid.NewGuid();

            try
            {
                //set is change and is delete
                var flag = await this.RemoveNonOutstandingItemAsync(param);
            }
            catch (DbUpdateException ex)
            {
                throw ex;
            }

            var published = await this.GetPublishParamsAsync(param);

            if (!published.Routes.Any())
            {
                status = PublishStatus.FAILED.GetDescription();
                exception = "Route creation failed due to select route not found or there is no pending mmrs in vessel loading list";
            }
            else
            {

                try
                {
                    var result = await _clientService.PublishTravelAsync(published);

                    if (result.FlaggingMessage != null)
                    {
                        status = PublishStatus.FAILED.GetDescription();
                        exception = result.FlaggingMessage.Message;
                        if (result.FlaggingMessage.NonPendingItems != null)
                        {
                            //Update flag
                            var materials = await _travelMaterialRespoitory.ListAsync(id);
                            materials = materials.Where(c => c.VotIsChanged == false);
                            foreach (var m in result.FlaggingMessage.NonPendingItems)
                            {
                                var mat = materials.Where(c => c.MmrLCTReferenceId == m.LCTMMRNumber && c.ItemLCTReferenceId == m.MaterialRequestDetailsId).FirstOrDefault() as TravelMaterial;
                                if (mat == null)
                                    continue;

                                mat.CurrentStatus = m.CurrentStatusOfItem;
                                mat.VotIsChanged = true;
                            }

                            await _travelMaterialRespoitory.UpdateRangeAsync(materials);
                        }

                        if (result.FlaggingMessage.SurpassedVCNs != null)
                        {
                            exception = $"{exception} VCNs:{string.Join(",", result.FlaggingMessage.SurpassedVCNs.Select(c => c.VCN))}";
                        }

                        if (result.FlaggingMessage.NoRouteCreator != null)
                        {
                            exception = result.FlaggingMessage.NoRouteCreator.FirstOrDefault().Message;
                        }

                    }

                    if (result.PublishedRoutes != null)
                    {
                        if (result.PublishedRoutes.RouteMap != null)
                        {
                            if (!string.IsNullOrEmpty(published.DeleteVCNEnd) && !string.IsNullOrEmpty(published.DeleteVCNEnd))
                            {
                                var travelpublishs = await _travelPublishRepository.ListAsync();
                                travelpublishs = travelpublishs.Where(c => c.VCN.CompareTo(published.DeleteVCNStart) >= 0 && c.VCN.CompareTo(published.DeleteVCNEnd) <= 0)
                                    .Select(c =>
                                    {
                                        c.IsDeleted = true;
                                        return c;
                                    });

                                travelpublishs = await _travelPublishRepository.UpdateRangeAsync(travelpublishs);
                            }

                            foreach (var m in result.PublishedRoutes.RouteMap)
                            {
                                var date = DateTime.Now;
                                await _travelPublishRepository.CreateAsync(new TravelPublish
                                {
                                    Id = Guid.NewGuid(),
                                    Date = date,
                                    TravelRouteId = m.VOTUniqueNumber,
                                    VCN = m.VCN,
                                    IsDeleted = false,
                                    PublishId = publishId,
                                });
                            }
                        }
                    }
                }
                catch (APIs.Exceptions.ClientNotSuccessException ex)
                {
                    var telemetry = new TelemetryClient();
                    telemetry.TrackException(ex);
                    status = PublishStatus.FAILED.GetDescription();
                    exception = ex.Message;
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                //  var job = await _jobService.EnforceJobExistenceAsync(travel.JobId);
            }

            //looging activity
            var act = new TravelActivity()
            {
                Id = publishId,
                TravelId = id,
                //JobId = job.Id,

                Type = param.IsEnableRePublish ? ActionActivity.REPUBLISHED.GetDescription() : ActionActivity.PUBLISHED.GetDescription(),
                Status = status,
                Message = exception,

                //revision for tracking repubish sequence
                Rev = param.IsEnableRePublish ? current.Rev : Guid.NewGuid(),
                //Parent = param.IsEnableRePublish ? current.Id : ,

                By = httpCurrentUser.Unique,
                Date = DateTime.UtcNow
            };

            //tracking parent
            if (param.IsEnableRePublish)
            {
                act.Parent = current.Id;
            }

            var entity = await _travelActivityRepository.CreateAsync(act);
            return entity;
        }



        //
        // Summary:
        //     favorite plan 
        //
        // Returns:
        //
        //  TravelParams model
        //
        // Type parameters:
        //   id:
        //     Travel \  id
        //
        public async Task<Travel> PutFavoriteAsync(Guid id)
        {
            var travel = await _travelRepository.GetAsync(id);
            if (travel == null)
            {
                throw new TravelNotFoundException();
            }

            travel.IsFavorite = !travel.IsFavorite;

            var entity = await _travelRepository.UpdateAsync(travel);
            return entity;
        }


        //
        // Summary:
        //     get current publish plan to LCT
        //
        // Returns:
        //
        //  Plan model

        public async Task<TravelActivity> GetLastPublishedAsync()
        {
            var entity = await _travelActivityRepository.GetRecentlyAsync();
            if (entity == null)
            {
                throw new TravelActivityNotFoundException();
            }

            var travel = await _travelRepository.GetAsync(entity.TravelId);
            if (travel == null)
            {
                throw new TravelNotFoundException();
                //travel = new Travel() { Id = Guid.NewGuid() }; //mocking
            }

            //set value
            var job = await _jobService.GetAsync(travel.JobId);
            var plan = await _planService.GetAsync(travel.PlanId);

            if (job != null)
            {
                entity.PlanName = plan.Name;
                entity.PlanRemark = plan.Remark;
                entity.JobRunId = job.RunId;
                entity.JobId = job.Id;
                entity.JobRunDate = job.Date.GetValueOrDefault();
            }
            else
            {
                throw new JobNotFoundException();
            }


            return entity;
        }

        //
        // Summary:
        //     get current publish plan to LCT
        //
        // Returns:
        //
        //  Plan model

        public async Task<IEnumerable<TravelActivity>> ListPublishedAsync()
        {

            var entities = await _travelActivityRepository.ListAsync();
            if (entities == null)
            {
                throw new TravelActivityNotFoundException();
            }

            //filter
            entities = entities.Where(c => c.Status == PublishStatus.COMPLETED.GetDescription()).OrderByDescending(c => c.Date);

            var query = new List<TravelActivity>();
            foreach (var entity in entities)
            {
                var travel = await _travelRepository.GetAsync(entity.TravelId);
                if (travel == null)
                {
                    continue;
                    //travel = new Travel() { Id = Guid.NewGuid() }; //mocking
                }

                //set value
                var job = await _jobService.GetAsync(travel.JobId);
                var plan = await _planService.GetAsync(travel.PlanId);

                if (job != null)
                {
                    entity.PlanName = plan.Name;
                    entity.PlanRemark = plan.Remark;
                    entity.JobRunId = job.RunId;
                    entity.JobId = job.Id;
                    entity.JobRunDate = job.Date.GetValueOrDefault();
                }
                else
                {
                    continue;
                    //throw new JobNotFoundException();
                }

                query.Add(entity);
            }

            return query;
        }


        //
        // Summary:
        //     get current publish plan to LCT
        //
        // Returns:
        //
        //  Plan model

        public async Task<TravelActivity> GetActivityAsync(Guid id)
        {
            var entity = await _travelActivityRepository.ListAsync(id);
            // var entity = activities.Where(c => c.TravelId == id && c.Type == ActionActivity.PUBLISHED.GetDescription())
            //                 .OrderByDescending(c => c.Date).FirstOrDefault();

            //no publis activity
            if (entity == null)
            {
                entity = new TravelActivity()
                {
                    Date = null,
                    TravelId = id
                };
            }

            var travel = await _travelRepository.GetAsync(entity.TravelId);
            if (travel == null)
            {
                throw new TravelNotFoundException();
            }

            //set value
            var job = await _jobService.GetAsync(travel.JobId);
            var plan = await _planService.GetAsync(job.PlanId);

            if (job != null)
            {
                entity.PlanName = plan.Name;
                entity.PlanRemark = plan.Remark;
                entity.JobRunId = job.RunId;
                entity.JobId = job.Id;
                entity.JobRunDate = job.Date.GetValueOrDefault();
            }
            else
            {
                throw new JobNotFoundException();
            }


            return entity;
        }


        //
        // Summary:
        //     get recently publish plans 
        //
        // Returns:
        //
        //  Plan list
        //
        // 
        public async Task<IEnumerable<TravelActivity>> ListRecentlyActivityAsync()
        {

            var activities = await _travelActivityRepository.ListRecentlyAsync(PUBLSIHED_TIMESAPN_IN_DAYS);
            if (activities == null)
            {
                throw new TravelActivityNotFoundException();
            }


            var entities = new List<TravelActivity>();
            //get job. runid

            foreach (var p in activities)
            {
                var travel = await _travelRepository.GetAsync(p.TravelId);
                if (travel == null)
                {
                    throw new TravelNotFoundException();
                    //travel = new Travel() { Id = Guid.NewGuid() }; //mocking

                }

                // p.IsTravelFavorite = travel.IsFavorite;

                //set value
                var job = await _jobService.GetAsync(travel.JobId);
                var plan = await _planService.GetAsync(travel.PlanId);

                if (job == null)
                {
                    throw new JobNotFoundException();
                }

                p.PlanName = plan.Name;
                p.JobRunId = job.RunId;
                p.JobId = job.Id;
                p.JobRunDate = job.Date.GetValueOrDefault();

                entities.Add(p);

            }


            return entities;
        }


        public async Task<TravelParams> GetAsync(Guid id)
        {

            var travel = await _travelRepository.GetAsync(id);
            if (travel == null)
            {
                throw new TravelNotFoundException();
            }

            //set value
            var job = await _jobService.GetAsync(travel.JobId);
            var plan = await _planService.GetAsync(travel.PlanId);

            // var tasks = await _materialService.ListRequestAsync(plan.Id);

            var entity = new TravelParams();

            entity.Id = job.Id;
            entity.Name = plan.Name;
            entity.Remark = plan.Remark;
            entity.StartDate = job.Date;
            entity.Version = plan.Version;
            entity.EndDate = job.UpdatedDate;
            entity.By = job.By;

            //entity.WeeklyRoutes  = GetTravelRoutesAsync(routePlan, materials, plan);
            entity.CostRatioInUSD = travel.CostRatioInUSD.GetValueOrDefault();
            entity.CostRatioInUSDTrip1 = travel.CostRatioInUSDTrip1.GetValueOrDefault();
            entity.CostRatioInUSDTrip2 = travel.CostRatioInUSDTrip2.GetValueOrDefault();
            entity.FuelConsumption = travel.FuelConsumption.GetValueOrDefault();

            //convert to nm
            entity.TotalDistance = travel.TotalDistance.GetValueOrDefault() * VESSEL.NAUTICAL_MILE_CONVERT_CONSTANT;

            entity.TotalDuration = travel.TotalDuration.GetValueOrDefault();
            entity.StartDate = travel.StartDate;
            entity.EndDate = travel.EndDate;

            entity.DroppedMMRs = travel.DroppedMaterial.GetValueOrDefault();
            // entity.TotalMMRs = tasks.Count();

            return entity;
        }

        public async Task<TravelParams> GetVesselAsync(Guid id)
        {

            var travel = await _travelRepository.GetAsync(id);
            if (travel == null)
            {
                throw new TravelNotFoundException();
            }

            var plan = await _planService.GetAsync(travel.PlanId);
            if (plan == null)
            {
                throw new PlanNotFoundException();
            }

            //new object
            var entity = new TravelParams()
            {
                Id = id,
            };

            var entities = await _travelVesselRepository.ListAsync();
            if (entities == null)
            {
                throw new TravelNotFoundException();
            }

            var vessels = await _clientService.ListVesselAsync();

            entities = entities.Where(c => c.TravelId == id);

            //calcualte space used
            foreach (var e in entities)
            {
                var vessel = vessels.Where(c => c.Id == e.VesselLCTReferenceId).FirstOrDefault();

                //calculate space used
                if (vessel != null)
                {
                    e.EffectiveDeckSpace = vessel.Specfication.EffectiveDeckSpace.GetValueOrDefault();
                    e.SpaceUsed = vessel.Specfication.EffectiveDeckSpace.GetValueOrDefault() - e.SpaceRemaining;
                }

            }

            //vessel summary
            entity.VesselLoads = entities;

            return entity;

        }

        public async Task<TravelParams> GetMaterialAsync(Guid id)
        {

            var travel = await _travelRepository.GetAsync(id);
            if (travel == null)
            {
                throw new TravelNotFoundException();
            }

            var plan = await _planService.GetAsync(travel.PlanId);
            if (plan == null)
            {
                throw new PlanNotFoundException();
            }

            // var vess = await _clientService.ListVesselAsync();

            //new object
            var entity = new TravelParams()
            {
                Id = id,
            };

            var material = await _travelMaterialRespoitory.ListAsync(id);

            //filter only delverd
            //var material = entities.Where(c => c.DeliveredStatus == DeliveredStatus.DELIVERED.GetDescription());
            if (material == null)
            {
                throw new TravelNotFoundException();
            }
            //material = material.Where(c => c.TravelId == id);

            //loading list
            var tasks = await _materialService.ListRequestAsync(travel.PlanId);

            var entities = (from m in material
                            join t in tasks
                            on m.ItemLCTReferenceId equals t.LCTMRMaterialRequestDetailsId
                            select new MaterialParams
                            {

                                Id = m.Id,
                                TravelId = id,
                                Sequence = m.Sequence.GetValueOrDefault(),
                                ItemLCTReferenceId = m.ItemLCTReferenceId.GetValueOrDefault(),
                                LCTMRMaterialRequestDetailsId = t.LCTMRMaterialRequestDetailsId,
                                LCTMRMaterialRequestId = t.LCTMRMaterialRequestId,

                                PlanId = plan.Id,
                                MRPriorityReferenceId = t.MRPriorityReferenceId,
                                Priority = t.Priority,
                                Asset = t.Asset,

                                LCTOrderNumber = t.LCTOrderNumber,

                                //offload
                                Grouping = t.BoundType == BoundType.OFFLOAD.GetDescription() ? t.To : t.From,

                                To = t.To,
                                From = t.From,

                                DeliveredStatus = m.DeliveredStatus,


                                LCTOriginReferenceId = t.LCTOriginReferenceId,
                                LCTDestinationReferenceId = t.LCTDestinationReferenceId,

                                FinalDestination = t.BoundType == BoundType.OFFLOAD.GetDescription() ? t.To : t.From,
                                Department = t.Department,
                                Description = t.Description,
                                LCTMMRReferenceNumber = 0,

                                ROSDate = t.ROSDate,

                                Qty = t.Qty,
                                QtyUnit = t.QuantityUnit,
                                QuantityUnit = t.QuantityUnit,

                                Length = t.Length,
                                Width = t.Weight,
                                Height = t.Height,

                                Area = t.Area,
                                Weight = t.Weight,
                                Remarks = t.Remarks,

                                Class = t.Class,
                                ItemType = t.ItemType,
                                BoundType = t.BoundType,

                                VesselLCTReferenceId = m.VesselLCTReferenceId.GetValueOrDefault(),
                                TripNo = m.TripNo.GetValueOrDefault(),

                            });

            var query = entities.Where(c => c.DeliveredStatus == DeliveredStatus.DELIVERED.GetDescription());

            //mapping veseel name
            //query = query.Select(c => { c.VesselName = vess.Where(v => v.Id == c.VesselLCTReferenceId).FirstOrDefault()?.Name; return c; }).ToList();
            var cons = new string[] { "Loose Material", "Container", "Tubular" };
            //idle
            var group = from p in query
                        group p by new { p.Grouping, p.VesselLCTReferenceId, p.TripNo, p.Sequence } into g
                        select new MaterialParams
                        {
                            VesselLCTReferenceId = g.Key.VesselLCTReferenceId,
                            // VesselName = g.FirstOrDefault().VesselName,
                            // From = g.Key.From,
                            // To = g.Key.To,

                            Grouping = g.Key.Grouping,

                            TripNo = g.Key.TripNo,


                            Sequence = g.Key.Sequence,
                            //Sequences = g.Select(c => c.Sequence).ToList(),

                            //caclcualte
                            GroupCount = g.Count(),
                            GroupWeight = g.Sum(c => c.Weight.GetValueOrDefault()),

                            GroupAreaBackload = g.Where(c => c.BoundType == BoundType.BACKLOAD.GetDescription() && cons.Contains(c.ItemType)).Sum(c => c.Area.GetValueOrDefault()),
                            GroupAreaOffload = g.Where(c => c.BoundType == BoundType.OFFLOAD.GetDescription() && cons.Contains(c.ItemType)).Sum(c => c.Area.GetValueOrDefault()),

                            GroupLift = g.Where(c => cons.Contains(c.ItemType)).Count(),
                        };

            entity.LoadingList = query.ToList();

            //grouping
            entity.GroupLoading = group.ToList();

            //set drooped task
            entity.DroppingList = entities.Where(c => c.DeliveredStatus == DeliveredStatus.DROPPED.GetDescription());

            return entity;
        }


        public async Task<TravelParams> GetTurnaroundAsync(Guid id)
        {
            var travel = await _travelRepository.GetAsync(id);
            if (travel == null)
            {
                throw new TravelNotFoundException();
            }

            var plan = await _planService.GetAsync(travel.PlanId);
            if (plan == null)
            {
                throw new PlanNotFoundException();
            }

            //var vess = await _clientService.ListVesselAsync();

            //new object
            var entity = new TravelParams()
            {
                Id = id,
            };

            var entities = await _travelTurnaroudRespoitory.ListAsync();
            if (entities == null)
            {
                throw new TravelNotFoundException();
            }
            entities = entities.Where(c => c.TravelId == id);

            //setvalue
            entity.Turnarounds = entities.ToList();

            return entity;
        }

        public async Task<IEnumerable<TravelParams>> ListRecentlyAsync()
        {
            var TRAVEL_TIMESAPN_IN_DAYS = -14;

            var jobs = await _jobHubService.ListParamsAsync(TRAVEL_TIMESAPN_IN_DAYS);
            if (jobs == null)
            {
                throw new JobNotFoundException();
            }

            var travels = await _travelRepository.ListAsync();

            var entities = new List<TravelParams>();
            foreach (var j in jobs)
            {
                var entity = new TravelParams();

                var tt = travels.Where(c => c.JobId == j.JobId).FirstOrDefault();
                if (tt != null)
                {
                    entity.TravelId = tt.Id;
                    entity.IsFavorite = tt.IsFavorite;

                    entity.CostRatioInUSD = tt.CostRatioInUSD.GetValueOrDefault();
                    entity.CostRatioInUSDTrip1 = tt.CostRatioInUSDTrip1.GetValueOrDefault();
                    entity.CostRatioInUSDTrip2 = tt.CostRatioInUSDTrip2.GetValueOrDefault();
                    entity.FuelConsumption = tt.FuelConsumption.GetValueOrDefault();

                    //convert to nm
                    entity.TotalDistance = tt.TotalDistance.GetValueOrDefault() * VESSEL.NAUTICAL_MILE_CONVERT_CONSTANT;


                    entity.TotalDuration = tt.TotalDuration.GetValueOrDefault();
                    entity.StartDate = tt.StartDate;
                    entity.EndDate = tt.EndDate;
                }

                entity.CurrentJob = j;
                entities.Add(entity);

            }

            return entities;
        }

        /* public async Task<IEnumerable<TravelRoute>> ListVesselCurrentRouteAsync()
        {
            var vesselsCurrentPlan = await _vesselService.ListCurrentRouteAsync();
            var entity = vesselsCurrentPlan.Where(c => c.StatusId == (int)VesselRouteStatus.ACTIVE).Select(s => new TravelRoute
            {
                VesselName = s.VesselName,
                VesselLCTReferenceId = s.VesselId,
                Sequence = s.Sequence,
                EtaDate = s.ETA,
                EtdDate = s.ETD,
                FromLCTLocationReferenceId = s.FromId,
                FromLocationCode = s.FromName,
                ToLCTLocationReferenceId = s.ToId,
                ToLocationCode = s.ToName
            });


            return entity;
        }

        public async Task<IEnumerable<TravelRoute>> ListVesselDailyRouteAsync()
        {
            var vesselsCurrentPlan = await _vesselService.ListCurrentRouteAsync();
            var entity = vesselsCurrentPlan.Where(c => c.StatusId == (int)VesselRouteStatus.DAILY_CONFIRMED).Select(s => new TravelRoute
            {
                VesselName = s.VesselName,
                VesselLCTReferenceId = s.VesselId,
                Sequence = s.Sequence,
                EtaDate = s.ETA,
                EtdDate = s.ETD,
                FromLCTLocationReferenceId = s.FromId,
                FromLocationCode = s.FromName,
                ToLCTLocationReferenceId = s.ToId,
                ToLocationCode = s.ToName
            });

            return entity;
        }*/

        /* private IEnumerable<TravelRoute> CalculateLoadingTime(IEnumerable<TravelRoute> routes)
        {
            TravelRoute previous = null;
            var newRoutes = new List<TravelRoute>();
            foreach (var r in routes)
            {
                if (previous != null)
                {
                    previous.LoadingTime = (decimal)(r.EtaDate.Value.Subtract(previous.EtdDate.Value)).TotalHours;
                    newRoutes.Add(previous);
                }

                previous = r;
            }
            newRoutes.Add(previous);
            return newRoutes;
        }*/

        public async Task<TravelPublishParams> GetPublishParamsAsync(PublishParams param)
        {
            var id = param.TravelId;

            var travel = new TravelPublishParams();
            travel.IsUserEnforced = false;
            var routesPublish = new List<TravelRoutePublish>();

            var resources = await _travelRepository.GetAsync(id);
            var routes = await _travelRouteRepository.ListAsync(id);
            var materials = await _travelMaterialRespoitory.ListAsync(id);
            var locations = await _clientService.ListLocationAsync();
            var published = await _travelPublishRepository.ListAsync();
            var turnaround = await _travelTurnaroudRespoitory.ListAsync(id);

            //filter by route vessel
            routes = routes.Where(c => (param.FirstTripVessels.Contains(c.VesselLCTReferenceId) && c.TripNo == 1) ||
                (param.SecondTripVessels.Contains(c.VesselLCTReferenceId) && c.TripNo == 2)
            );

            /*if (!routes.Any())
            {
                throw new TravelRouteNotFoundException();
            }*/

            var vessels = routes.GroupBy(g => new
            {
                g.VesselLCTReferenceId,
                g.TripNo

            }).Select(s => new
            {
                VesselId = s.First().VesselLCTReferenceId,
                VesselName = s.First().VesselName,
                TripNo = s.First().TripNo

            }).OrderBy(o => o.TripNo).ThenBy(o => o.VesselId);

            foreach (var v in vessels)
            {
                var t = new TravelRoutePublish();

                // *** !important
                //filter material by drop from updating db from this.RemoveNonOutstandingItemAsync()
                // *
                // *
                // *

                t.LoadingList = materials.Where(c =>
                        (c.VesselLCTReferenceId == v.VesselId && c.TripNo == v.TripNo)
                              && (c.LctReferenceIsDeleted != true || c.VotIsChanged != true))

                        .Select(s => new LoadingList
                        {
                            LCTMMRNumber = s.MmrLCTReferenceId.GetValueOrDefault(), //(int)tasks.Where(c=>c.LCTMRMaterialRequestDetailsId == s.ItemLCTReferenceId).FirstOrDefault().LCTMRMaterialRequestId, 
                            MaterialRequestDetailsID = s.ItemLCTReferenceId.GetValueOrDefault(),
                            SequenceNumber = s.Sequence.GetValueOrDefault(),
                        });

                //remove publish vessel trip when there is no mmr (effected from drops) 
                if (!t.LoadingList.Any())
                {
                    continue;
                }

                t.VesselId = v.VesselId;
                t.VesselName = v.VesselName;

                t.RouteDetails = routes.Where(c => c.VesselLCTReferenceId == v.VesselId && c.TripNo == v.TripNo).Select(s => new TravelRouteDetail
                {
                    SequenceNumber = s.Sequence,
                    LocationFrom = s.FromLocationCode,
                    LocationFromId = s.FromLCTLocationReferenceId,
                    LocationTo = s.ToLocationCode,
                    LocationToId = s.ToLCTLocationReferenceId,
                    eta = s.EtaDate.Value,
                    etd = s.EtdDate.Value,
                    loadingTime = s.LoadingTime,
                    backload = s.BackLoadSpace,
                    offload = s.OffLoadSpace,
                    spaceRemaining = s.SpaceRemaining,
                    weightAdded = s.BackLoadWeight,
                    weightRemoved = s.OffLoadWeight,
                    weightRemaining = s.WeightRemaining,
                    distance = s.Distance,
                    speed = s.Speed,
                    latitudeFrom = locations.Where(c => c.Id == s.FromLCTLocationReferenceId).FirstOrDefault().Latitude.GetValueOrDefault(),
                    longitudeFrom = locations.Where(c => c.Id == s.FromLCTLocationReferenceId).FirstOrDefault().Longitude.GetValueOrDefault(),
                    latitudeTo = locations.Where(c => c.Id == s.ToLCTLocationReferenceId).FirstOrDefault().Latitude.GetValueOrDefault(),
                    longitudeTo = locations.Where(c => c.Id == s.ToLCTLocationReferenceId).FirstOrDefault().Longitude.GetValueOrDefault(),
                    sequenceComments = ""

                }).OrderBy(o => o.SequenceNumber);

                t.VOTRouteId = routes.Where(c => c.VesselLCTReferenceId == v.VesselId && c.TripNo == v.TripNo && c.Sequence == 1).FirstOrDefault().Id;
                t.UserID = 0;
                t.Username = "";
                t.EmailAddress = httpCurrentUser.Unique;
                t.Comment = "";
                t.VesselRoutePurpose = Configuration.Instance.GetLctConfig().PublishPurpose;
                t.VesselRoutePurposeId = Configuration.Instance.GetLctConfig().PublishPurposeId;

                t.DepartureTo = t.RouteDetails.Last().LocationTo;
                t.DepartureToId = t.RouteDetails.Last().LocationToId;
                t.DepartureFrom = t.RouteDetails.First().LocationFrom;
                t.DepartureFromId = t.RouteDetails.First().LocationFromId;
                t.EtaAtJetty = (DateTime)turnaround.Where(c => c.VesselLCTReferenceId == v.VesselId && c.TripNo == v.TripNo).FirstOrDefault().EtaDate;// t.RouteDetails.First().etd;
                t.EtdFromJetty = (DateTime)t.RouteDetails.First().etd;
                t.DurationAtPort = (t.EtdFromJetty - t.EtaAtJetty).Hours + 1;

                //t.VCNsForDeletion = new List<VCNMapping>();

                routesPublish.Add(t);
            }

            travel.IsUserEnforced = materials.Where(c => c.LctReferenceIsDeleted == true).Count() > 0;
            travel.Routes = routesPublish;

            if (param.IsEnableRePublish)
            {
                var last = await _travelActivityRepository.GetRecentlyAsync();
                if (last != null)
                {
                    published = published.Where(c => c.PublishId == last.Id).OrderBy(o => o.VCN);
                    if (published.Count() > 0)
                    {
                        travel.DeleteVCNStart = published.Min(c => c.VCN);
                        travel.DeleteVCNEnd = published.Max(c => c.VCN);
                    }
                }
            }

            string blobBaseUrl = $"{ Environment.Configuration.Instance.GetBlobInputUrl() }{ id }/";
            var inputPath = Configuration.Instance.GetPath();
            await _azureService.UploadBlobAsync(new Uri($"{blobBaseUrl}{Guid.NewGuid()}.json"),
                                                   JsonConvert.SerializeObject(travel));

            return travel;
        }

        public async Task<IEnumerable<RouteParams>> ListCurrentlyActivityAsync(Guid id)
        {
            var travel = await _travelRepository.GetAsync(id);
            if (travel == null)
            {
                throw new TravelNotFoundException();
            }

            var weekly = await _travelRouteRepository.ListAsync(id);
            if (weekly == null)
            {
                throw new TravelNotFoundException();
            }


            var vessel = await _vesselService.GetPlanVesselAsync(travel.PlanId);
            var props = vessel.Properties;

            //find by start , end
            var start = props.Min(c => c.ETADate);
            var end = props.Max(c => c.ETADate);
            end = end.Value.AddDays(VESSEL.MAX_VALIDATE_BLOCKOUT_DAYS);
            start = start.Value.AddDays(-1 * VESSEL.MAX_VALIDATE_BLOCKOUT_DAYS);

            var routes = await _vesselService.ListBookActivitiesAysnc(start.Value, end.Value);
            var vin = weekly.Select(c => c.VesselLCTReferenceId).Distinct().ToArray();

            //filter vessel
            routes = routes.Where(p => vin.Contains(p.VesseId.GetValueOrDefault()));


            var entities = routes.Select(s => new RouteParams
            {
                Id = Guid.NewGuid(),

                VesselLCTReferenceId = (int)s.VesseId,
                VesselName = s.VesselName,
                PlanType = PlanType.BOOK_ACTIVITY.GetDescription(),
                FromLocationCode = s.StartLocationCode,
                ToLocationCode = s.EndLocationCode,

                Start = s.StartDate.GetValueOrDefault().ToString("s"),
                End = s.EndDate.GetValueOrDefault().ToString("s"),

                Content = $"{s.ActivityType}  {(string.IsNullOrEmpty(s.Description) ? s.Info : s.Description)}",
                Group = s.VesseId.ToString(),

                ClassName = "rally booked",
                // HtmlColorCode = "",

                //Style = "",
                //TravelType = "",
                //Type = "",
            });


            return entities;
        }

        public async Task<TravelParams> ListGulfAsync(Guid id)
        {
            /* var travel = await _travelRepository.GetAsync(id);
            if (travel == null)
            {
                throw new TravelNotFoundException();
            }

            var plan = await _planService.GetAsync(travel.PlanId);
            if (plan == null)
            {
                throw new PlanNotFoundException();
            }*/

            //var vess = await _clientService.ListVesselAsync()

            var travels = await _travelRepository.ListAsync();
            var date = DateTime.UtcNow.AddDays(-3);
            travels = travels.Where(c => c.Date > date);

            var routes = await _travelRouteRepository.ListAsync(travels);
            if (routes == null)
            {
                throw new TravelNotFoundException();
            }
            //filter
            // routes = routes.Where(c => c.TravelId == id);

            //orderds
            routes = routes.OrderBy(c => c.RunId).ThenBy(c => c.VesselLCTReferenceId).ThenBy(c => c.TripNo).ThenBy(c => c.Sequence).ToArray();

            var statement = @"SELECT  p.Name,
                                r.VesselName,
                                j.RunId,
                                r.TripNo,
                                r.FromLocationCode,
                                r.EtaDate,
                                r.EtdDate,
                                r.ToLocationCode,
                                r.FromLocationName,
                                r.FromLatitude,
                                r.FromLongitude,
                                r.FromLocationType,
                                r.FromLocationCategory
                        FROM travel t
                        JOIN [plan] p ON t.PlanId = p.Id
                        JOIN [job] j ON t.JobId = j.Id
                        JOIN travelroute r ON t.Id = r.TravelId
                        WHERE t.Date > DATEADD(day, -3, GETDATE())
                        ORDER BY   p.Name, j.RunId, r.VesselName, r.TripNo";

            var entities = new List<Gulf>();
            //var locations = await _locationService.ListClusterAsync();

            foreach (var r in routes)
            {
                var g = new Gulf()
                {
                    PlanName = r.PlanName,
                    RunId = r.RunId,
                    Vessel = r.VesselName,
                    VesselId = r.VesselLCTReferenceId,

                    TripNo = r.TripNo,
                    FromLocationCode = r.FromLocationCode,

                    ArrivalTimeCurrent = r.EtaDate,
                    ToLocationCode = r.ToLocationCode,
                    DepartureTimeCurrent = r.EtdDate,

                    FromLocationName = r.FromLocationName,
                    Lat = r.FromLatitude,
                    Long = r.FromLongitude,

                    Asset = r.Asset,
                    Type = r.FromLocationType,
                    Category = r.FromLocationCategory

                    // ArrivalTimeNext = r.
                };

                //mapping asset logic
                /* *var custer = locations.Where(c => c.ClusterCode == g.FromLocationCode).FirstOrDefault();

                //switch to
                var terminals = LOCATION.TERMINALS.Values.ToArray();
                if (terminals.Contains(g.FromLocationCode))
                {
                    custer = locations.Where(c => c.ClusterCode == g.ToLocationCode).FirstOrDefault();
                }

                //assign
                if (custer != null)
                {
                    var platform = locations.Where(c => c.DORPlatformId == custer.DORPlatformId).FirstOrDefault();

                    g.ClusterId = custer.LCTReferenceId.GetValueOrDefault();
                    g.ClusterCode = custer.ClusterCode;
                    g.ClusterName = custer.ClusterName;

                    g.Lat = custer.ClusterLatitude;
                    g.Long = custer.ClusterLongtitude;

                    g.ClusterType = custer.Type;
                    g.ClusterCategory = custer.Category;
                    g.Asset = platform.Asset;
                }*/

                entities.Add(g);
            }

            //new object
            var entity = new TravelParams()
            {
                Id = id,

                GulfSchematics = entities,
                GulfStatement = statement
            };

            return entity;
        }
    }



    public interface ITravelHubService
    {
        Task<IEnumerable<TravelActivity>> ListRecentlyActivityAsync();
    }

    public class TravelHubService : ITravelHubService
    {

        private readonly ITravelRepository _travelRepository;
        private readonly ITravelActivityRepository _travelActivityRepository;

        private const int PUBLSIHED_TIMESAPN_IN_DAYS = -7;
        private readonly IPlanJobService _planService;

        public TravelHubService(ITravelRepository travelRepository, ITravelActivityRepository travelActivityRepository, IPlanJobService planService)
        {
            _travelRepository = travelRepository ?? throw new ArgumentNullException(nameof(travelRepository));
            _travelActivityRepository = travelActivityRepository ?? throw new ArgumentNullException(nameof(travelActivityRepository));

            _planService = planService ?? throw new ArgumentNullException(nameof(planService));

        }



        //
        // Summary:
        //     get recently publish plans 
        //
        // Returns:
        //
        //  Plan list
        //
        // 
        public async Task<IEnumerable<TravelActivity>> ListRecentlyActivityAsync()
        {

            var activities = await _travelActivityRepository.ListRecentlyAsync(PUBLSIHED_TIMESAPN_IN_DAYS);
            if (activities == null)
            {
                throw new TravelActivityNotFoundException();
            }


            var entities = new List<TravelActivity>();
            //get job. runid

            foreach (var p in activities)
            {
                var travel = await _travelRepository.GetAsync(p.TravelId);
                if (travel == null)
                {
                    throw new TravelNotFoundException();
                    //travel = new Travel() { Id = Guid.NewGuid() }; //mocking

                }

                // p.IsTravelFavorite = travel.IsFavorite;

                //set value
                var job = await _planService.GetJobAsync(travel.JobId);
                var plan = await _planService.GetPlanAsync(travel.PlanId);

                if (job == null)
                {
                    throw new JobNotFoundException();
                }

                p.PlanName = plan.Name;
                p.JobRunId = job.RunId;
                p.JobId = job.Id;
                p.JobRunDate = job.Date.GetValueOrDefault();

                entities.Add(p);

            }
            return entities;
        }
    }

}
