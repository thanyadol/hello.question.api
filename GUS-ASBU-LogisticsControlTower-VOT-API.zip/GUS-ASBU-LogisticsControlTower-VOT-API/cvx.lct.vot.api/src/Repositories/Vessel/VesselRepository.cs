using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{

    public interface IVesselRepository
    {
        Task<IEnumerable<Vessel>> ListAsync();
        Task<Vessel> GetAsync(Guid id);
        Task<Vessel> CreateAsync(Vessel vessel);
        Task<Vessel> UpdateAsync(Vessel vessel);
        //Task<Vessel> DeleteAsync(Guid id);
    }

    public class VesselRepository : IVesselRepository
    {

        private readonly NorthwindContext _context;
        public VesselRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<Vessel> CreateAsync(Vessel vessel)
        {

            var entity = await _context.Vessels.AddAsync(vessel);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<Vessel> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _VesselEntityTableStorageRepository.DeleteOneAsync(VesselName, VesselKey);
            var entity = await _context.Vessels.FindAsync(id);
            _context.Vessels.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<Vessel>> ListAsync()
        {

            var entities = await _context.Vessels.ToListAsync();
            //var Vessel = _context.Vessels.ToList();
            return entities;
        }

        public async Task<Vessel> UpdateAsync(Vessel vessel)
        {

            var entity = await _context.Vessels.FindAsync(vessel.Id);

            // vessel.By = "admin";
            // vessel.Date = Utility.CurrentSEAsiaStandardTime();

            _context.Vessels.Update(vessel);

            _context.SaveChanges();
            return entity;
        }

        public async Task<Vessel> GetAsync(Guid id)
        {
            var entity = await _context.Vessels.FindAsync(id);
            return entity;
        }


    }
}