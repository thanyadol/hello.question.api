using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{

    public interface IVesselPropertiesRepository
    {
        Task<IEnumerable<VesselProperties>> ListAsync();
        Task<IEnumerable<VesselProperties>> ListAsync(Guid Id);
        Task<VesselProperties> GetAsync(Guid id);
        Task<VesselProperties> CreateAsync(VesselProperties vessel);
        Task<VesselProperties> UpdateAsync(VesselProperties vessel);
        //Task<VesselProperties> DeleteAsync(Guid id);

        Task<IEnumerable<VesselProperties>> CreateRangeAsync(IEnumerable<VesselProperties> vessels);
        Task<IEnumerable<VesselProperties>> UpdateRangeAsync(IEnumerable<VesselProperties> vessels);
    }

    public class VesselPropertiesRepository : IVesselPropertiesRepository
    {

        private readonly NorthwindContext _context;
        public VesselPropertiesRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }


        public async Task<IEnumerable<VesselProperties>> CreateRangeAsync(IEnumerable<VesselProperties> vessels)
        {

            await _context.VesselProperties.AddRangeAsync(vessels);
            _context.SaveChanges();

            return vessels;
        }


        public async Task<IEnumerable<VesselProperties>> UpdateRangeAsync(IEnumerable<VesselProperties> vessels)
        {
            await Task.Delay(0);
            _context.VesselProperties.UpdateRange(vessels);
            _context.SaveChanges();

            return vessels;
        }


        public async Task<VesselProperties> CreateAsync(VesselProperties vessel)
        {

            var entity = await _context.VesselProperties.AddAsync(vessel);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<VesselProperties> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _VesselPropertiesEntityTableStorageRepository.DeleteOneAsync(VesselPropertiesName, VesselPropertiesKey);
            var entity = await _context.VesselProperties.FindAsync(id);
            _context.VesselProperties.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<VesselProperties>> ListAsync()
        {

            var entities = await _context.VesselProperties.ToListAsync();
            //var VesselProperties = _context.VesselProperties.ToList();
            return entities;
        }


        public async Task<IEnumerable<VesselProperties>> ListAsync(Guid id)
        {

            var entities = await _context.VesselProperties.Where(c => c.PlanVesselId == id).ToListAsync();
            //var VesselProperties = _context.VesselProperties.ToList();
            return entities;
        }


        public async Task<VesselProperties> UpdateAsync(VesselProperties vessel)
        {

            var entity = await _context.VesselProperties.FindAsync(vessel.Id);

            // vessel.By = "admin";
            // vessel.Date = Utility.CurrentSEAsiaStandardTime();

            _context.VesselProperties.Update(vessel);

            _context.SaveChanges();
            return entity;
        }

        public async Task<VesselProperties> GetAsync(Guid id)
        {
            var entity = await _context.VesselProperties.FindAsync(id);
            return entity;
        }


    }
}