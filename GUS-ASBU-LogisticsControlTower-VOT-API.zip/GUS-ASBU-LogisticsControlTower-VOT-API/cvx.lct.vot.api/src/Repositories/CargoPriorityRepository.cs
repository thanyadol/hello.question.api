using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{

    public interface ICargoPriorityRepository
    {
        Task<IEnumerable<CargoPriority>> ListAsync();
        Task<CargoPriority> GetAsync(Guid id);
        Task<CargoPriority> CreateAsync(CargoPriority cargo);
        Task<CargoPriority> UpdateAsync(CargoPriority cargo);

        Task<IEnumerable<CargoPriority>> CreateRangeAsync(IEnumerable<CargoPriority> entities);
        Task<IEnumerable<CargoPriority>> UpdateRangeAsync(IEnumerable<CargoPriority> entities);
    }

    public class CargoPriorityRepository : ICargoPriorityRepository
    {


        private readonly NorthwindContext _context;
        public CargoPriorityRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }


        public async Task<IEnumerable<CargoPriority>> CreateRangeAsync(IEnumerable<CargoPriority> entities)
        {

            await _context.CargoPriorities.AddRangeAsync(entities);
            _context.SaveChanges();

            return entities;
        }

        public async Task<IEnumerable<CargoPriority>> UpdateRangeAsync(IEnumerable<CargoPriority> entities)
        {

            await Task.Delay(0);
            _context.CargoPriorities.UpdateRange(entities);
            _context.SaveChanges();

            return entities;
        }


        public async Task<CargoPriority> CreateAsync(CargoPriority cargo)
        {

            var entity = await _context.CargoPriorities.AddAsync(cargo);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<CargoPriority> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _CargoEntityTableStorageRepository.DeleteOneAsync(CargoName, CargoKey);
            var entity = await _context.CargoPriorities.FindAsync(id);
            _context.CargoPriorities.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<CargoPriority>> ListAsync()
        {

            var entities = await _context.CargoPriorities.ToListAsync();
            //var CargoPriority = _context.CargoPriorities.ToList();
            return entities;
        }

        public async Task<CargoPriority> UpdateAsync(CargoPriority cargo)
        {

            var entity = await _context.CargoPriorities.FindAsync(cargo.Id);

            // cargo.By = "admin";
            // cargo.Date = Utility.CurrentSEAsiaStandardTime();

            _context.CargoPriorities.Update(cargo);

            _context.SaveChanges();
            return entity;
        }

        public async Task<CargoPriority> GetAsync(Guid id)
        {
            var entity = await _context.CargoPriorities.FindAsync(id);
            return entity;
        }



    }
}