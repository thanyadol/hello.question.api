using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{

    public interface ITabularStackRepository
    {
        Task<IEnumerable<TabularStack>> ListAsync();
        Task<TabularStack> GetAsync(Guid id);
        Task<TabularStack> CreateAsync(TabularStack tabular);
        Task<TabularStack> UpdateAsync(TabularStack tabular);
    }

    public class TabularStackRepository : ITabularStackRepository
    {

        private readonly NorthwindContext _context;
        public TabularStackRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<TabularStack> CreateAsync(TabularStack tabular)
        {

            var entity = await _context.TabularStacks.AddAsync(tabular);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<TabularStack> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _TabularStackEntityTableStorageRepository.DeleteOneAsync(TabularStackName, TabularStackKey);
            var entity = await _context.TabularStacks.FindAsync(id);
            _context.TabularStacks.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<TabularStack>> ListAsync()
        {

            // var entities = await _context.TabularStacks.ToListAsync();

            var entities = await (from t in _context.TabularStacks
                                  join b in _context.Tabulars on t.BaseId equals b.Id
                                  join s in _context.Tabulars on t.StackableId equals s.Id
                                  select new TabularStack()
                                  {
                                      Id = t.Id,

                                      BaseId = b.Id,
                                      StackableId = s.Id,

                                      Name = b.Name,
                                      StackableName = s.Name,

                                      By = t.By,
                                      Date = t.Date

                                  }).ToListAsync();

            return entities;
        }

        public async Task<TabularStack> UpdateAsync(TabularStack tabular)
        {

            var entity = await _context.TabularStacks.FindAsync(tabular.Id);

            // tabular.By = "admin";
            // tabular.Date = Utility.CurrentSEAsiaStandardTime();

            _context.TabularStacks.Update(tabular);

            _context.SaveChanges();
            return entity;
        }

        public async Task<TabularStack> GetAsync(Guid id)
        {
            var entity = await _context.TabularStacks.FindAsync(id);
            return entity;
        }



    }
}