using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{

    public interface IRunParameterRepository
    {
        Task<IEnumerable<RunParameter>> ListAsync();
        Task<RunParameter> GetAsync(Guid id);
        Task<RunParameter> CreateAsync(RunParameter param);
        Task<RunParameter> UpdateAsync(RunParameter param);
    }

    public class RunParameterRepository : IRunParameterRepository
    {

        private readonly NorthwindContext _context;
        public RunParameterRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<RunParameter> CreateAsync(RunParameter param)
        {

            var entity = await _context.RunParameters.AddAsync(param);

            _context.SaveChanges();
            return entity.Entity;
        }

        public async Task<RunParameter> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _RunParameterEntityTableStorageRepository.DeleteOneAsync(RunParameterName, RunParameterKey);
            var entity = await _context.RunParameters.FindAsync(id);
            _context.RunParameters.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<RunParameter>> ListAsync()
        {

            var entities = await _context.RunParameters.ToListAsync();
            //var RunParameter = _context.RunParameters.ToList();
            return entities;
        }

        public async Task<RunParameter> UpdateAsync(RunParameter param)
        {

            var entity = await _context.RunParameters.FindAsync(param.Id);

            // param.By = "admin";
            // param.Date = Utility.CurrentSEAsiaStandardTime();

            //entity.Status = param.Status;

            _context.RunParameters.Update(entity);
            _context.SaveChanges();

            return entity;
        }

        public async Task<RunParameter> GetAsync(Guid id)
        {
            var entity = await _context.RunParameters.FindAsync(id);
            return entity;
        }



    }
}