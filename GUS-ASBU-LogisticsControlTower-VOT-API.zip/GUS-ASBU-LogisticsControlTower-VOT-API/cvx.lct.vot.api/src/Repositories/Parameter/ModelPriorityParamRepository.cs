using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{

    public interface IModelPriorityParameterRepository
    {
        Task<IEnumerable<ModelPriorityParameter>> ListAsync();
        Task<IEnumerable<ModelPriorityParameter>> ListAsync(Guid id);
        Task<ModelPriorityParameter> GetAsync(Guid id);
        Task<ModelPriorityParameter> CreateAsync(ModelPriorityParameter param);
        Task<ModelPriorityParameter> UpdateAsync(ModelPriorityParameter param);
        Task<IEnumerable<ModelPriorityParameter>> CreateRangeAsync(IEnumerable<ModelPriorityParameter> entities);
    }

    public class ModelPriorityParameterRepository : IModelPriorityParameterRepository
    {

        private readonly NorthwindContext _context;
        public ModelPriorityParameterRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<IEnumerable<ModelPriorityParameter>> CreateRangeAsync(IEnumerable<ModelPriorityParameter> entities)
        {

            await _context.ModelPriorityParameters.AddRangeAsync(entities);
            _context.SaveChanges();

            return entities;
        }


        public async Task<ModelPriorityParameter> CreateAsync(ModelPriorityParameter param)
        {

            var entity = await _context.ModelPriorityParameters.AddAsync(param);

            _context.SaveChanges();
            return entity.Entity;
        }

        public async Task<ModelPriorityParameter> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _ModelPriorityParameterEntityTableStorageRepository.DeleteOneAsync(ModelPriorityParameterName, ModelPriorityParameterKey);
            var entity = await _context.ModelPriorityParameters.FindAsync(id);
            _context.ModelPriorityParameters.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<ModelPriorityParameter>> ListAsync()
        {

            var entities = await _context.ModelPriorityParameters.ToListAsync();
            //var ModelPriorityParameter = _context.ModelPriorityParameters.ToList();
            return entities;
        }

        public async Task<IEnumerable<ModelPriorityParameter>> ListAsync(Guid id)
        {

            var entities = await _context.ModelPriorityParameters.ToListAsync();
            //var ModelPriorityParameter = _context.ModelPriorityParameters.ToList();
            return entities.Where(c => c.ModelParameterId == id);
        }

        public async Task<ModelPriorityParameter> UpdateAsync(ModelPriorityParameter param)
        {

            var entity = await _context.ModelPriorityParameters.FindAsync(param.Id);

            // param.By = "admin";
            // param.Date = Utility.CurrentSEAsiaStandardTime();

            //entity.Status = param.Status;

            _context.ModelPriorityParameters.Update(entity);
            _context.SaveChanges();

            return entity;
        }

        public async Task<ModelPriorityParameter> GetAsync(Guid id)
        {
            var entity = await _context.ModelPriorityParameters.FindAsync(id);
            return entity;
        }



    }
}