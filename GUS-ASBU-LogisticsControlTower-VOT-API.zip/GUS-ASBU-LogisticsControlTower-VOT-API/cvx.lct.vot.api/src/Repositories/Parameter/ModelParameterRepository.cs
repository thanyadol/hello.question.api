using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{

    public interface IModelParameterRepository
    {
        Task<IEnumerable<ModelParameter>> ListAsync();
        Task<ModelParameter> GetAsync(Guid id);
        Task<ModelParameter> CreateAsync(ModelParameter param);
        Task<ModelParameter> UpdateAsync(ModelParameter param);
    }

    public class ModelParameterRepository : IModelParameterRepository
    {

        private readonly NorthwindContext _context;
        public ModelParameterRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<ModelParameter> CreateAsync(ModelParameter param)
        {

            var entity = await _context.ModelParameters.AddAsync(param);

            _context.SaveChanges();
            return entity.Entity;
        }

        public async Task<ModelParameter> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _ModelParameterEntityTableStorageRepository.DeleteOneAsync(ModelParameterName, ModelParameterKey);
            var entity = await _context.ModelParameters.FindAsync(id);
            _context.ModelParameters.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<ModelParameter>> ListAsync()
        {

            var entities = await _context.ModelParameters.ToListAsync();
            //var ModelParameter = _context.ModelParameters.ToList();
            return entities;
        }

        public async Task<ModelParameter> UpdateAsync(ModelParameter param)
        {

            var entity = await _context.ModelParameters.FindAsync(param.Id);

            // param.By = "admin";
            // param.Date = Utility.CurrentSEAsiaStandardTime();

            //entity.Status = param.Status;

            _context.ModelParameters.Update(entity);
            _context.SaveChanges();

            return entity;
        }

        public async Task<ModelParameter> GetAsync(Guid id)
        {
            var entity = await _context.ModelParameters.FindAsync(id);
            return entity;
        }



    }
}