using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{

    public interface IModelProductionParameterRepository
    {
        Task<IEnumerable<ModelProductionParameter>> ListAsync();
        Task<IEnumerable<ModelProductionParameter>> ListAsync(Guid id);
        Task<ModelProductionParameter> GetAsync(Guid id);
        Task<ModelProductionParameter> CreateAsync(ModelProductionParameter param);
        Task<ModelProductionParameter> UpdateAsync(ModelProductionParameter param);
        Task<IEnumerable<ModelProductionParameter>> CreateRangeAsync(IEnumerable<ModelProductionParameter> entities);
    }

    public class ModelProductionParameterRepository : IModelProductionParameterRepository
    {

        private readonly NorthwindContext _context;
        public ModelProductionParameterRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<IEnumerable<ModelProductionParameter>> CreateRangeAsync(IEnumerable<ModelProductionParameter> entities)
        {

            await _context.ModelProductionParameters.AddRangeAsync(entities);
            _context.SaveChanges();

            return entities;
        }


        public async Task<ModelProductionParameter> CreateAsync(ModelProductionParameter param)
        {

            var entity = await _context.ModelProductionParameters.AddAsync(param);

            _context.SaveChanges();
            return entity.Entity;
        }

        public async Task<ModelProductionParameter> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _ModelProductionParameterEntityTableStorageRepository.DeleteOneAsync(ModelProductionParameterName, ModelProductionParameterKey);
            var entity = await _context.ModelProductionParameters.FindAsync(id);
            _context.ModelProductionParameters.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<ModelProductionParameter>> ListAsync()
        {

            var entities = await _context.ModelProductionParameters.ToListAsync();
            //var ModelProductionParameter = _context.ModelProductionParameters.ToList();
            return entities;
        }

        public async Task<IEnumerable<ModelProductionParameter>> ListAsync(Guid id)
        {

            var entities = await _context.ModelProductionParameters.ToListAsync();
            //var ModelProductionParameter = _context.ModelProductionParameters.ToList();
            return entities.Where(c => c.ModelParameterId == id);
        }

        public async Task<ModelProductionParameter> UpdateAsync(ModelProductionParameter param)
        {

            var entity = await _context.ModelProductionParameters.FindAsync(param.Id);

            // param.By = "admin";
            // param.Date = Utility.CurrentSEAsiaStandardTime();

            //entity.Status = param.Status;

            _context.ModelProductionParameters.Update(entity);
            _context.SaveChanges();

            return entity;
        }

        public async Task<ModelProductionParameter> GetAsync(Guid id)
        {
            var entity = await _context.ModelProductionParameters.FindAsync(id);
            return entity;
        }



    }
}