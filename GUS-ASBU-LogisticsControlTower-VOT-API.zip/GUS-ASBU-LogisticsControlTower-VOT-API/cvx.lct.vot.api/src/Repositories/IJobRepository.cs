using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{

    public interface IJobRepository
    {
        Task<IEnumerable<Job>> ListAsync();
        Task<IEnumerable<Job>> ListAsync(Guid id);
        Task<IEnumerable<Job>> ListPreviouslyAsync(int day);
        Task<Job> GetAsync(Guid id);
        Task<Job> CreateAsync(Job job);
        Task<Job> UpdateAsync(Job job);
    }

    public class JobRepository : IJobRepository
    {

        private readonly NorthwindContext _context;
        public JobRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<Job> CreateAsync(Job job)
        {

            var entity = await _context.Jobs.AddAsync(job);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<Job> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _JobEntityTableStorageRepository.DeleteOneAsync(JobName, JobKey);
            var entity = await _context.Jobs.FindAsync(id);
            _context.Jobs.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<Job>> ListPreviouslyAsync(int day)
        {

            var date = DateTime.UtcNow.AddDays(day);
            var entities = await _context.Jobs.Where(c => c.Date >= date && !String.IsNullOrEmpty(c.Status))
                                .OrderByDescending(c => c.Date).Take(150).ToListAsync();
            //var Job = _context.Jobs.ToList();
            return entities;
        }

        public async Task<IEnumerable<Job>> ListAsync()
        {

            var entities = await _context.Jobs.ToListAsync();
            //var Job = _context.Jobs.ToList();
            return entities;
        }

        public async Task<IEnumerable<Job>> ListAsync(Guid id)
        {

            var entities = await _context.Jobs.Where(c => c.PlanId == id).ToListAsync();
            //var Job = _context.Jobs.ToList();
            return entities;
        }

        public async Task<Job> UpdateAsync(Job job)
        {

            var entity = await _context.Jobs.FindAsync(job.Id);

            // job.By = "admin";
            // job.Date = Utility.CurrentSEAsiaStandardTime();

            entity.Status = job.Status;
            entity.RunMessage = job.RunMessage;
            entity.UpdatedDate = DateTime.Now;

            _context.Jobs.Update(entity);

            _context.SaveChanges();

            return entity;
        }

        public async Task<Job> GetAsync(Guid id)
        {
            var entity = await _context.Jobs.FindAsync(id);
            return entity;
        }



    }
}