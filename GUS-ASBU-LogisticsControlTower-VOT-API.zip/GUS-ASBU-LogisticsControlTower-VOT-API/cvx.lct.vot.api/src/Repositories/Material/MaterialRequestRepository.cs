using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;
using Z.EntityFramework.Plus;

namespace cvx.lct.vot.api.Repositories
{

    public interface IMaterialRequestRepository
    {
        Task<IEnumerable<MaterialRequest>> ListAsync();
        Task<IEnumerable<MaterialRequest>> ListAsync(Guid id);


        Task<MaterialRequest> GetAsync(Guid id);
        Task<MaterialRequest> CreateAsync(MaterialRequest material);
        Task<MaterialRequest> UpdateAsync(MaterialRequest material);

        Task<IEnumerable<MaterialRequest>> ListRecentlyAsync();
        Task<IEnumerable<MaterialRequest>> CreateRangeAsync(IEnumerable<MaterialRequest> tasks);
        Task<IEnumerable<MaterialRequest>> UpdateRangeAsync(IEnumerable<MaterialRequest> tasks);

        Task<bool> RemoveRangeAsync(Guid id);
    }

    public class MaterialRequestRepository : IMaterialRequestRepository
    {

        private readonly NorthwindContext _context;
        public MaterialRequestRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<MaterialRequest> CreateAsync(MaterialRequest material)
        {

            var entity = await _context.MaterialRequests.AddAsync(material);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<IEnumerable<MaterialRequest>> UpdateRangeAsync(IEnumerable<MaterialRequest> tasks)
        {
            await Task.Delay(0);
            _context.MaterialRequests.UpdateRange(tasks);
            _context.SaveChanges();

            return tasks;
        }

        public async Task<IEnumerable<MaterialRequest>> CreateRangeAsync(IEnumerable<MaterialRequest> tasks)
        {

            await _context.MaterialRequests.AddRangeAsync(tasks);
            _context.SaveChanges();

            return tasks;
        }

        public async Task<MaterialRequest> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _MaterialRequestEntityTableStorageRepository.DeleteOneAsync(MaterialRequestName, MaterialRequestKey);
            var entity = await _context.MaterialRequests.FindAsync(id);
            _context.MaterialRequests.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<MaterialRequest>> ListAsync()
        {

            var entities = await _context.MaterialRequests.ToListAsync();
            //var MaterialRequest = _context.MaterialRequests.ToList();
            return entities;
        }


        public async Task<IEnumerable<MaterialRequest>> ListAsync(Guid id)
        {

            var entities = await _context.MaterialRequests.Where(c => c.PlanId == id).ToListAsync();
            //var MaterialRequest = _context.MaterialRequests.ToList();
            return entities;
        }

        public async Task<IEnumerable<MaterialRequest>> ListRecentlyAsync()
        {
            var entities = await _context.MaterialRequests.ToListAsync();

            return entities;
        }


        public async Task<MaterialRequest> UpdateAsync(MaterialRequest material)
        {

            var entity = await _context.MaterialRequests.FindAsync(material.Id);

            // material.By = "admin";
            // material.Date = Utility.CurrentSEAsiaStandardTime();

            _context.MaterialRequests.Update(material);

            _context.SaveChanges();
            return entity;
        }

        //
        // Summary:
        //    remove baatch withtout query by EF plus by plan id
        //
        // Returns:
        //
        //   boolean
        //
        // Type parameters:
        //   plan:
        //      planned params from UI
        //

        public async Task<bool> RemoveRangeAsync(Guid id)
        {
            await Task.Delay(0);

            try
            {
                _context.MaterialRequests.Where(c => c.PlanId == id).Delete();
                //  _context.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }


        public async Task<MaterialRequest> GetAsync(Guid id)
        {
            var entity = await _context.MaterialRequests.FindAsync(id);
            return entity;
        }



    }
}