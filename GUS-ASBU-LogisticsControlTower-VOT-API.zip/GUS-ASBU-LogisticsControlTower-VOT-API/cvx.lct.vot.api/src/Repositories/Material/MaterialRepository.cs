using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{

    public interface IMaterialRepository
    {
        Task<IEnumerable<Material>> ListAsync();
        Task<Material> GetAsync(Guid id);
        Task<Material> CreateAsync(Material material);
        Task<Material> UpdateAsync(Material material);
    }

    public class MaterialRepository : IMaterialRepository
    {

        private readonly NorthwindContext _context;
        public MaterialRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<Material> CreateAsync(Material material)
        {

            var entity = await _context.Materials.AddAsync(material);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<Material> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _MaterialEntityTableStorageRepository.DeleteOneAsync(MaterialName, MaterialKey);
            var entity = await _context.Materials.FindAsync(id);
            _context.Materials.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<Material>> ListAsync()
        {

            var entities = await _context.Materials.ToListAsync();
            //var Material = _context.Materials.ToList();
            return entities;
        }

        public async Task<Material> UpdateAsync(Material material)
        {

            var entity = await _context.Materials.FindAsync(material.Id);

            // material.By = "admin";
            // material.Date = Utility.CurrentSEAsiaStandardTime();

            _context.Materials.Update(material);

            _context.SaveChanges();
            return entity;
        }

        public async Task<Material> GetAsync(Guid id)
        {
            var entity = await _context.Materials.FindAsync(id);
            return entity;
        }



    }
}