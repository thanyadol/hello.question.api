using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{

    public interface ICargoRepository
    {
        Task<IEnumerable<Cargo>> ListAsync();
        Task<Cargo> GetAsync(Guid id);
        Task<Cargo> CreateAsync(Cargo cargo);
        Task<Cargo> UpdateAsync(Cargo cargo);
    }

    public class CargoRepository : ICargoRepository
    {

        private readonly NorthwindContext _context;
        public CargoRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<Cargo> CreateAsync(Cargo cargo)
        {

            var entity = await _context.Cargos.AddAsync(cargo);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<Cargo> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _CargoEntityTableStorageRepository.DeleteOneAsync(CargoName, CargoKey);
            var entity = await _context.Cargos.FindAsync(id);
            _context.Cargos.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<Cargo>> ListAsync()
        {

            var entities = await _context.Cargos.ToListAsync();
            //var Cargo = _context.Cargos.ToList();
            return entities;
        }

        public async Task<Cargo> UpdateAsync(Cargo cargo)
        {

            var entity = await _context.Cargos.FindAsync(cargo.Id);

            // cargo.By = "admin";
            // cargo.Date = Utility.CurrentSEAsiaStandardTime();

            _context.Cargos.Update(cargo);

            _context.SaveChanges();
            return entity;
        }

        public async Task<Cargo> GetAsync(Guid id)
        {
            var entity = await _context.Cargos.FindAsync(id);
            return entity;
        }


    }
}