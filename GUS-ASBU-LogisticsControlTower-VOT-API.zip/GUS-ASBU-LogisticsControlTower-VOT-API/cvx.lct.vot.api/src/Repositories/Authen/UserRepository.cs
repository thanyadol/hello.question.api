using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using cvx.lct.vot.api.Models;


//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{

    public interface IUserRepository
    {
        Task<IEnumerable<User>> ListAsync();

        Task<User> GetAsync(string id);
        Task<User> CreateAsync(User User);
        Task<User> UpdateAsync(User User);
        Task<User> DeleteAsync(string id);
    }

    public class UserRepository : IUserRepository
    {
        //private readonly IUserMappingService _UserMappingService;
        //private readonly ITableStorageRepository<UserEntity> _UserEntityTableStorageRepository;

        private readonly NorthwindContext _context;

        public UserRepository(NorthwindContext context) //IUserMappingService UserMappingService, ITableStorageRepository<UserEntity> UserEntityTableStorageRepository)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            //_UserMappingService = UserMappingService ?? throw new ArgumentNullException(nameof(UserMappingService));
            //_UserEntityTableStorageRepository = UserEntityTableStorageRepository ?? throw new ArgumentNullException(nameof(UserEntityTableStorageRepository));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<User> CreateAsync(User user)
        {
            //var entityToCreate = _UserMappingService.Map(User);
            //var createdEntity = await _UserEntityTableStorageRepository.InsertOrReplaceAsync(entityToCreate);
            //var createUser = _UserMappingService.Map(createdEntity);

            var entity = await _context.Users.AddAsync(user);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<User> DeleteAsync(string id)
        {
            //var deletedEntity = await _UserEntityTableStorageRepository.DeleteOneAsync(userName, UserKey);
            var entity = await _context.Users.FindAsync(id);
            _context.Users.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<User> UpdateAsync(User User)
        {
            var updateUser = await _context.Users.FindAsync(User.Id);
            _context.Users.Update(User);
            _context.SaveChanges();

            return updateUser;
        }

        // public async Task<UserAuthen> PutProjectAsync(UserAuthen UserAuthen)
        // {

        //     //var assinedRecord = await _context.UserAuthens.FindAsync(UserAuthen.Id);
        //     var entity = await _context.UserAuthens.AddAsync(UserAuthen);
        //     _context.SaveChanges();

        //     return entity.Entity;
        // }

        public async Task<User> GetAsync(string id)
        {
            var user = await _context.Users.FindAsync(id);
            return user;
        }


        public async Task<IEnumerable<User>> ListAsync()
        {
            var user = await _context.Users.ToListAsync();
            return user;
        }


    }
}