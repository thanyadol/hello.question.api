using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{
    public interface ISessionLogRepository
    {
        Task<IEnumerable<SessionLog>> ListAsync();

        // Task<SessionLog> GetRecentlyAsync(Guid id, string action);

        Task<SessionLog> GetAsync(Guid id);
        Task<SessionLog> CreateAsync(SessionLog logg);
        Task<SessionLog> UpdateAsync(SessionLog logg);
        //Task<SessionLog> DeleteAsync(string id);
    }

    /*
     * to controll the user activities
     *
     */

    public class SessionLogRepository : ISessionLogRepository
    {

        private readonly NorthwindContext _context;
        public SessionLogRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<SessionLog> CreateAsync(SessionLog logg)
        {

            var entity = await _context.SessionLogs.AddAsync(logg);

            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<SessionLog> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _SessionLogEntityTableStorageRepository.DeleteOneAsync(SessionLogName, SessionLogKey);
            var entity = await _context.SessionLogs.FindAsync(id);
            _context.SessionLogs.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<SessionLog>> ListAsync()
        {

            var entities = await _context.SessionLogs.ToListAsync();
            //var SessionLog = _context.SessionLogs.ToList();
            return entities;
        }

        public async Task<SessionLog> UpdateAsync(SessionLog logg)
        {

            var entity = await _context.SessionLogs.FindAsync(logg.Id);

            // logg.By = "admin";
            // logg.Date = Utility.CurrentSEAsiaStandardTime();

            _context.SessionLogs.Update(logg);

            _context.SaveChanges();
            return entity;
        }

        public async Task<SessionLog> GetAsync(Guid id)
        {
            var entity = await _context.SessionLogs.FindAsync(id);
            return entity;
        }


    }
}