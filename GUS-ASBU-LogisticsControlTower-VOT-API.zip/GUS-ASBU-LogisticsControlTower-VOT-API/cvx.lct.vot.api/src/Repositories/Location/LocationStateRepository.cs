using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

using Z.EntityFramework.Plus;

namespace cvx.lct.vot.api.Repositories
{

    public interface ILocationStateRepository
    {
        Task<IEnumerable<LocationState>> ListAsync();
        Task<LocationState> GetAsync(Guid id);
        Task<LocationState> CreateAsync(LocationState locate);
        Task<LocationState> UpdateAsync(LocationState locate);
        Task<IEnumerable<LocationState>> ListAsync(Guid id, bool isTank);

        Task<IEnumerable<LocationState>> CreateRangeAsync(IEnumerable<LocationState> locates);
        Task<IEnumerable<LocationState>> UpdateRangeAsync(IEnumerable<LocationState> locates);
        Task<bool> RemoveRangeAsync(Guid id);
    }

    public class LocationStateRepository : ILocationStateRepository
    {

        private readonly NorthwindContext _context;
        public LocationStateRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<LocationState> CreateAsync(LocationState locate)
        {

            var entity = await _context.LocationStates.AddAsync(locate);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<IEnumerable<LocationState>> UpdateRangeAsync(IEnumerable<LocationState> locates)
        {
            await Task.Delay(0);
            _context.LocationStates.UpdateRange(locates);
            _context.SaveChanges();

            return locates;
        }

        public async Task<IEnumerable<LocationState>> CreateRangeAsync(IEnumerable<LocationState> locates)
        {
            await _context.LocationStates.AddRangeAsync(locates);
            _context.SaveChanges();

            return locates;
        }

        //
        // Summary:
        //    remove baatch withtout query by EF plus by plan location id
        //
        // Returns:
        //
        //   boolean
        //
        // Type parameters:
        //   plan:
        //      planned params from UI
        //

        public async Task<bool> RemoveRangeAsync(Guid id)
        {
            await Task.Delay(0);

            try
            {
                _context.LocationStates.Where(c => c.PlanLocationId == id).Delete();
                //  _context.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }


        public async Task<LocationState> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _LocationStateEntityTableStorageRepository.DeleteOneAsync(LocationStateName, LocationStateKey);
            var entity = await _context.LocationStates.FindAsync(id);
            _context.LocationStates.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<LocationState>> ListAsync()
        {

            var entities = await _context.LocationStates.ToListAsync();
            //var LocationState = _context.LocationStates.ToList();
            return entities;
        }


        public async Task<IEnumerable<LocationState>> ListAsync(Guid id, bool isTank)
        {

            var entities = await _context.LocationStates.Where(c => c.PlanLocationId == id
                                        // && c.RecordStatus == RecordStatus.ACTIVE.GetDescription()
                                        && c.IsTanker == isTank).ToListAsync();
            //var LocationState = _context.LocationStates.ToList();
            return entities;
        }


        public async Task<LocationState> UpdateAsync(LocationState locate)
        {

            var entity = await _context.LocationStates.FindAsync(locate.Id);

            // locate.By = "admin";
            // locate.Date = Utility.CurrentSEAsiaStandardTime();

            _context.LocationStates.Update(locate);

            _context.SaveChanges();
            return entity;
        }

        public async Task<LocationState> GetAsync(Guid id)
        {
            var entity = await _context.LocationStates.FindAsync(id);
            return entity;
        }


    }
}