using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{

    public interface ILocationRepository
    {
        Task<IEnumerable<Location>> ListAsync();
        Task<Location> GetAsync(Guid id);
        Task<Location> CreateAsync(Location locate);
        Task<Location> UpdateAsync(Location locate);
        Task<IEnumerable<Location>> ListClusterAsync();
    }

    public class LocationRepository : ILocationRepository
    {

        private readonly NorthwindContext _context;
        public LocationRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<Location> CreateAsync(Location locate)
        {

            var entity = await _context.Locations.AddAsync(locate);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<Location> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _LocationEntityTableStorageRepository.DeleteOneAsync(LocationName, LocationKey);
            var entity = await _context.Locations.FindAsync(id);
            _context.Locations.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<Location>> ListAsync()
        {

            return await _context.Locations.ToListAsync();

        }

        public async Task<Location> UpdateAsync(Location locate)
        {

            var entity = await _context.Locations.FindAsync(locate.Id);

            // locate.By = "admin";
            // locate.Date = Utility.CurrentSEAsiaStandardTime();

            _context.Locations.Update(locate);

            _context.SaveChanges();
            return entity;
        }

        public async Task<Location> GetAsync(Guid id)
        {
            var entity = await _context.Locations.FindAsync(id);
            return entity;
        }

        //list cluster
        public async Task<IEnumerable<Location>> ListClusterAsync()
        {
            return await _context.Locations.ToListAsync();//.Where(c => c.ParentLocationLCTReferenceId == c.ChildLocationLCTReferenceId).ToListAsync();
        }

    }
}