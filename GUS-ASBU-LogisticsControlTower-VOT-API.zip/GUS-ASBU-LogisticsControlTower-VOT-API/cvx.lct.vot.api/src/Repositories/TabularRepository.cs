using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{

    public interface ITabularRepository
    {
        Task<IEnumerable<Tabular>> ListAsync();
        Task<Tabular> GetAsync(Guid id);
        Task<Tabular> CreateAsync(Tabular tabular);
        Task<Tabular> UpdateAsync(Tabular tabular);
    }

    public class TabularRepository : ITabularRepository
    {

        private readonly NorthwindContext _context;
        public TabularRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<Tabular> CreateAsync(Tabular tabular)
        {

            var entity = await _context.Tabulars.AddAsync(tabular);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<Tabular> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _TabularEntityTableStorageRepository.DeleteOneAsync(TabularName, TabularKey);
            var entity = await _context.Tabulars.FindAsync(id);
            _context.Tabulars.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<Tabular>> ListAsync()
        {

            var entities = await _context.Tabulars.ToListAsync();
            //var Tabular = _context.Tabulars.ToList();
            return entities;
        }

        public async Task<Tabular> UpdateAsync(Tabular tabular)
        {

            var entity = await _context.Tabulars.FindAsync(tabular.Id);

            // tabular.By = "admin";
            // tabular.Date = Utility.CurrentSEAsiaStandardTime();

            _context.Tabulars.Update(tabular);

            _context.SaveChanges();
            return entity;
        }

        public async Task<Tabular> GetAsync(Guid id)
        {
            var entity = await _context.Tabulars.FindAsync(id);
            return entity;
        }



    }
}