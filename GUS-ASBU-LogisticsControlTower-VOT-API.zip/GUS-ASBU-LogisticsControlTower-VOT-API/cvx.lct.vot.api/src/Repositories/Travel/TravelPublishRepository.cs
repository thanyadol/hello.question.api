﻿using cvx.lct.vot.api.Models;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Repositories
{
    public interface ITravelPublishRepository
    {
        Task<TravelPublish> CreateAsync(TravelPublish publish);
        Task<TravelPublish> DeleteAsync(Guid id);
        Task<IEnumerable<TravelPublish>> ListAsync();
        Task<IEnumerable<TravelPublish>> ListAsync(Guid id);
        Task<TravelPublish> UpdateAsync(TravelPublish TravelPublish);
        Task<TravelPublish> GetAsync(Guid id);
        Task<IEnumerable<TravelPublish>> UpdateRangeAsync(IEnumerable<TravelPublish> travelpublishs);
    }
    public class TravelPublishRepository: ITravelPublishRepository
    {
        private readonly NorthwindContext _context;
        public TravelPublishRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();
        }

        public async Task<TravelPublish> CreateAsync(TravelPublish trip)
        {

            var entity = await _context.TravelPublishes.AddAsync(trip);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<TravelPublish> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _JobEntityTableStorageRepository.DeleteOneAsync(JobName, JobKey);
            var entity = await _context.TravelPublishes.FindAsync(id);
            _context.TravelPublishes.Remove(entity);
            _context.SaveChanges();
            return entity;
        }
        
        public async Task<IEnumerable<TravelPublish>> ListAsync()
        {

            var entities = await _context.TravelPublishes.ToListAsync();
            return entities;
        }

        public async Task<IEnumerable<TravelPublish>> ListAsync(Guid id)
        {

            var entities = await _context.TravelPublishes.ToListAsync();
            entities = entities.Where(c => c.TravelRouteId == id).ToList();
            return entities;
        }

        public async Task<TravelPublish> UpdateAsync(TravelPublish TravelPublish)
        {

            var entity = await _context.TravelPublishes.FindAsync(TravelPublish.Id);

            _context.TravelPublishes.Update(TravelPublish);

            _context.SaveChanges();

            return entity;
        }

        public async Task<TravelPublish> GetAsync(Guid id)
        {
            var entity = await _context.TravelPublishes.FindAsync(id);
            return entity;
        }

        public async Task<TravelPublish> GetByJobIdAsync(Guid id)
        {
            var entities = await ListAsync(id);
            var entity = entities.FirstOrDefault();
            return entity;
        }

        public async Task<IEnumerable<TravelPublish>> UpdateRangeAsync(IEnumerable<TravelPublish> travelpublishs)
        {
            await Task.Delay(0);
            if (travelpublishs == null || travelpublishs.Count() == 0)
                return new List<TravelPublish>();

            _context.TravelPublishes.UpdateRange(travelpublishs);
            _context.SaveChanges();

            return travelpublishs;
        }
    }
}
