using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using cvx.lct.vot.api.Extensions;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{

    public interface ITravelActivityRepository
    {
        Task<IEnumerable<TravelActivity>> ListAsync();
        Task<TravelActivity> ListAsync(Guid id);
        Task<TravelActivity> GetAsync(Guid id);
        Task<TravelActivity> CreateAsync(TravelActivity activity);
        Task<TravelActivity> UpdateAsync(TravelActivity activity);

        Task<TravelActivity> GetRecentlyAsync();
        Task<IEnumerable<TravelActivity>> ListRecentlyAsync(int day);
    }

    public class TravelActivityRepository : ITravelActivityRepository
    {

        private readonly NorthwindContext _context;
        public TravelActivityRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<TravelActivity> CreateAsync(TravelActivity activity)
        {

            var entity = await _context.TravelActivities.AddAsync(activity);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<TravelActivity> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _PlanActivityEntityTableStorageRepository.DeleteOneAsync(PlanActivityName, PlanActivityKey);
            var entity = await _context.TravelActivities.FindAsync(id);
            _context.TravelActivities.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<TravelActivity>> ListAsync()
        {

            var entities = await _context.TravelActivities.ToListAsync();
            //var TravelActivity = _context.TravelActivities.ToList();
            return entities;
        }

        public async Task<TravelActivity> ListAsync(Guid id)
        {

            var entities = await _context.TravelActivities.Where(c => c.TravelId == id && (c.Type == ActionActivity.PUBLISHED.GetDescription() || c.Type == ActionActivity.REPUBLISHED.GetDescription()) && c.Status == PublishStatus.COMPLETED.GetDescription())
                                .OrderByDescending(c => c.Date).FirstOrDefaultAsync();
            //var TravelActivity = _context.TravelActivities.ToList();
            return entities;
        }

        public async Task<IEnumerable<TravelActivity>> ListRecentlyAsync(int day)
        {
            var date = DateTime.UtcNow.AddDays(day);
            var entities = await _context.TravelActivities.Where(c => c.Date >= date && (c.Type == ActionActivity.PUBLISHED.GetDescription() || c.Type == ActionActivity.REPUBLISHED.GetDescription())).OrderByDescending(c => c.Date).ToListAsync();
            //var TravelActivity = _context.TravelActivities.ToList();
            return entities;
        }

        public async Task<TravelActivity> GetRecentlyAsync()
        {

            var entities = await _context.TravelActivities.Where(c => (c.Type == ActionActivity.PUBLISHED.GetDescription() || c.Type == ActionActivity.REPUBLISHED.GetDescription()) && c.Status == PublishStatus.COMPLETED.GetDescription())
                                                          .OrderByDescending(c => c.Date).FirstOrDefaultAsync();
            //var TravelActivity = _context.TravelActivities.ToList();
            return entities;
        }

        public async Task<TravelActivity> UpdateAsync(TravelActivity activity)
        {

            var entity = await _context.TravelActivities.FindAsync(activity.Id);

            // activity.By = "admin";
            // activity.Date = Utility.CurrentSEAsiaStandardTime();

            _context.TravelActivities.Update(activity);

            _context.SaveChanges();
            return entity;
        }

        public async Task<TravelActivity> GetAsync(Guid id)
        {
            var entity = await _context.TravelActivities.FindAsync(id);
            return entity;
        }



    }
}