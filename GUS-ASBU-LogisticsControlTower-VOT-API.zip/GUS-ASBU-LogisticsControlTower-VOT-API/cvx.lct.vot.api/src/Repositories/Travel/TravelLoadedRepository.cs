﻿using cvx.lct.vot.api.Models;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Repositories
{
    public interface ITravelLoadedRepository
    {
        Task<TravelLoaded> CreateAsync(TravelLoaded route);
        Task<IEnumerable<TravelLoaded>> CreateRangeAsync(IEnumerable<TravelLoaded> loads);
        Task<TravelLoaded> DeleteAsync(Guid id);
        Task<IEnumerable<TravelLoaded>> DeleteRangeAsync(IEnumerable<TravelLoaded> loads);
        Task<IEnumerable<TravelLoaded>> ListAsync();
        Task<IEnumerable<TravelLoaded>> ListAsync(Guid id);
        Task<TravelLoaded> UpdateAsync(TravelLoaded loaded);
        Task<TravelLoaded> GetAsync(Guid id);
    }

    public class TravelLoadedRepository : ITravelLoadedRepository
    {
        private readonly NorthwindContext _context;
        public TravelLoadedRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();
        }

        public async Task<TravelLoaded> CreateAsync(TravelLoaded summary)
        {

            var entity = await _context.TravelLoadeds.AddAsync(summary);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<IEnumerable<TravelLoaded>> CreateRangeAsync(IEnumerable<TravelLoaded> loads)
        {
            await _context.TravelLoadeds.AddRangeAsync(loads);
            _context.SaveChanges();

            return loads;
        }

        public async Task<TravelLoaded> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _JobEntityTableStorageRepository.DeleteOneAsync(JobName, JobKey);
            var entity = await _context.TravelLoadeds.FindAsync(id);
            _context.TravelLoadeds.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<TravelLoaded>> DeleteRangeAsync(IEnumerable<TravelLoaded> loads)
        {
            await Task.Delay(0);
            if (loads == null || loads.Count() == 0)
                return new List<TravelLoaded>();

            _context.TravelLoadeds.RemoveRange(loads);
            _context.SaveChanges();

            return loads;
        }

        public async Task<IEnumerable<TravelLoaded>> ListAsync()
        {

            var entities = await _context.TravelLoadeds.ToListAsync();
            return entities;
        }

        public async Task<IEnumerable<TravelLoaded>> ListAsync(Guid id)
        {

            var entities = await _context.TravelLoadeds.Where(c => c.TravelId == id).ToListAsync();
            return entities;
        }

        public async Task<TravelLoaded> UpdateAsync(TravelLoaded loaded)
        {

            var entity = await _context.TravelLoadeds.FindAsync(loaded.Id);

            _context.TravelLoadeds.Update(loaded);

            _context.SaveChanges();

            return entity;
        }

        public async Task<TravelLoaded> GetAsync(Guid id)
        {
            var entity = await _context.TravelLoadeds.FindAsync(id);
            return entity;
        }
    }
}
