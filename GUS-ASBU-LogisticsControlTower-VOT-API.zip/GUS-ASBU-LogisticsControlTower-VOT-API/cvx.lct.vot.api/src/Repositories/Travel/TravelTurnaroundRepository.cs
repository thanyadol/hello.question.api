﻿using cvx.lct.vot.api.Models;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Repositories
{
    public interface ITravelTurnaroundRepository
    {
        Task<TravelTurnaround> CreateAsync(TravelTurnaround route);
        Task<IEnumerable<TravelTurnaround>> CreateRangeAsync(IEnumerable<TravelTurnaround> turnaround);
        Task<TravelTurnaround> DeleteAsync(Guid id);
        Task<IEnumerable<TravelTurnaround>> DeleteRangeAsync(IEnumerable<TravelTurnaround> turnaround);
        Task<IEnumerable<TravelTurnaround>> ListAsync();
        Task<IEnumerable<TravelTurnaround>> ListAsync(Guid travelId);
        Task<TravelTurnaround> UpdateAsync(TravelTurnaround jobPlanRoute);
        Task<TravelTurnaround> GetAsync(Guid id);
    }
    public class TravelTurnaroundRepository: ITravelTurnaroundRepository
    {
        private readonly NorthwindContext _context;
        public TravelTurnaroundRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();
        }

        public async Task<TravelTurnaround> CreateAsync(TravelTurnaround route)
        {

            var entity = await _context.TravelTurnarounds.AddAsync(route);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<IEnumerable<TravelTurnaround>> CreateRangeAsync(IEnumerable<TravelTurnaround> turnaround)
        {
            await _context.TravelTurnarounds.AddRangeAsync(turnaround);
            _context.SaveChanges();

            return turnaround;
        }

        public async Task<TravelTurnaround> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _JobEntityTableStorageRepository.DeleteOneAsync(JobName, JobKey);
            var entity = await _context.TravelTurnarounds.FindAsync(id);
            _context.TravelTurnarounds.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<TravelTurnaround>> DeleteRangeAsync(IEnumerable<TravelTurnaround> turnaround)
        {
            await Task.Delay(0);
            if (turnaround == null || turnaround.Count() == 0)
                return new List<TravelTurnaround>();

            _context.TravelTurnarounds.RemoveRange(turnaround);
            _context.SaveChanges();

            return turnaround;
        }

        public async Task<IEnumerable<TravelTurnaround>> ListAsync()
        {

            var entities = await _context.TravelTurnarounds.ToListAsync();
            return entities;
        }

        public async Task<IEnumerable<TravelTurnaround>> ListAsync(Guid travelId)
        {
            var entities = await _context.TravelTurnarounds.ToListAsync();
            entities = entities.Where(c => c.TravelId == travelId).ToList();
            return entities;
        }

        public async Task<TravelTurnaround> UpdateAsync(TravelTurnaround jobPlanRoute)
        {

            var entity = await _context.TravelTurnarounds.FindAsync(jobPlanRoute.Id);

            _context.TravelTurnarounds.Update(jobPlanRoute);

            _context.SaveChanges();

            return entity;
        }

        public async Task<TravelTurnaround> GetAsync(Guid id)
        {
            var entity = await _context.TravelTurnarounds.FindAsync(id);
            return entity;
        }
    }
}
