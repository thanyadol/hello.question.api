using cvx.lct.vot.api.Models;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Repositories
{
    public interface ITravelRouteRepository
    {
        Task<TravelRoute> CreateAsync(TravelRoute route);
        Task<IEnumerable<TravelRoute>> CreateRangeAsync(IEnumerable<TravelRoute> routes);
        Task<TravelRoute> DeleteAsync(Guid id);
        Task<IEnumerable<TravelRoute>> DeleteRangeAsync(IEnumerable<TravelRoute> routes);
        Task<IEnumerable<TravelRoute>> ListAsync();
        Task<IEnumerable<TravelRoute>> ListAsync(Guid id);
        Task<TravelRoute> UpdateAsync(TravelRoute jobPlanRoute);
        Task<TravelRoute> GetAsync(Guid id);

        Task<IEnumerable<TravelRoute>> ListAsync(IEnumerable<Travel> travels);
    }

    public class TravelRouteRepository : ITravelRouteRepository
    {
        private readonly NorthwindContext _context;
        public TravelRouteRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();
        }

        public async Task<TravelRoute> CreateAsync(TravelRoute route)
        {

            var entity = await _context.TravelRoutes.AddAsync(route);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<IEnumerable<TravelRoute>> CreateRangeAsync(IEnumerable<TravelRoute> routes)
        {
            await _context.TravelRoutes.AddRangeAsync(routes);
            _context.SaveChanges();

            return routes;
        }

        public async Task<TravelRoute> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _JobEntityTableStorageRepository.DeleteOneAsync(JobName, JobKey);
            var entity = await _context.TravelRoutes.FindAsync(id);
            _context.TravelRoutes.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<TravelRoute>> DeleteRangeAsync(IEnumerable<TravelRoute> routes)
        {
            await Task.Delay(0);
            if (routes == null || routes.Count() == 0)
                return new List<TravelRoute>();

            _context.TravelRoutes.RemoveRange(routes);
            _context.SaveChanges();

            return routes;
        }

        public async Task<IEnumerable<TravelRoute>> ListAsync()
        {

            var entities = await _context.TravelRoutes.ToListAsync();
            return entities;
        }

        public async Task<IEnumerable<TravelRoute>> ListAsync(IEnumerable<Travel> travels)
        {
            await Task.Delay(0);
            var entities = (from t in travels
                            join j in _context.Jobs on t.JobId equals j.Id
                            join b in _context.Plans on t.PlanId equals b.Id
                            join r in _context.TravelRoutes on t.Id equals r.TravelId
                            select new TravelRoute()
                            {
                                PlanName = b.Name,
                                RunId = j.RunId,
                                VesselName = r.VesselName,
                                VesselLCTReferenceId = r.VesselLCTReferenceId,

                                TripNo = r.TripNo,
                                FromLocationCode = r.FromLocationCode,

                                EtaDate = r.EtaDate,
                                ToLocationCode = r.ToLocationCode,
                                EtdDate = r.EtdDate,

                                FromLocationName = r.FromLocationName,
                                FromLatitude = r.FromLatitude,
                                FromLongitude = r.FromLongitude,

                                Asset = r.Asset,
                                FromLocationType = r.FromLocationType,
                                FromLocationCategory = r.FromLocationCategory

                            }).ToList();

            return entities;
        }

        public async Task<IEnumerable<TravelRoute>> ListAsync(Guid id)
        {
            var entities = await _context.TravelRoutes.Where(c => c.TravelId == id).ToListAsync();
            // entities = entitiesToList();
            return entities;
        }

        public async Task<TravelRoute> UpdateAsync(TravelRoute route)
        {

            var entity = await _context.TravelRoutes.FindAsync(route.Id);

            _context.TravelRoutes.Update(route);
            _context.SaveChanges();

            return entity;
        }

        public async Task<TravelRoute> GetAsync(Guid id)
        {
            var entity = await _context.TravelRoutes.FindAsync(id);
            return entity;
        }
    }
}
