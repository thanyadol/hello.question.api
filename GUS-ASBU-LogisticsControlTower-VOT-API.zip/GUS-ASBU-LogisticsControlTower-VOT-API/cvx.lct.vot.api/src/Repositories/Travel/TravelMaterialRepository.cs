﻿using cvx.lct.vot.api.Models;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Repositories
{
    public interface ITravelMaterialRepository
    {
        Task<TravelMaterial> CreateAsync(TravelMaterial material);
        Task<IEnumerable<TravelMaterial>> CreateRangeAsync(IEnumerable<TravelMaterial> materials);
        Task<TravelMaterial> DeleteAsync(Guid id);
        Task<IEnumerable<TravelMaterial>> DeleteRangeAsync(IEnumerable<TravelMaterial> materials);
        Task<IEnumerable<TravelMaterial>> ListAsync();
        Task<IEnumerable<TravelMaterial>> ListAsync(Guid id);
        Task<TravelMaterial> UpdateAsync(TravelMaterial TravelMaterial);
        Task<IEnumerable<TravelMaterial>> UpdateRangeAsync(IEnumerable<TravelMaterial> materials);
        Task<TravelMaterial> GetAsync(Guid id);
    }

    public class TravelMaterialRepository : ITravelMaterialRepository
    {
        private readonly NorthwindContext _context;
        public TravelMaterialRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();
        }


        public async Task<TravelMaterial> CreateAsync(TravelMaterial material)
        {

            var entity = await _context.TravelMaterials.AddAsync(material);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<IEnumerable<TravelMaterial>> CreateRangeAsync(IEnumerable<TravelMaterial> materials)
        {
            await _context.TravelMaterials.AddRangeAsync(materials);
            _context.SaveChanges();
            return materials;
        }

        public async Task<TravelMaterial> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _JobEntityTableStorageRepository.DeleteOneAsync(JobName, JobKey);
            var entity = await _context.TravelMaterials.FindAsync(id);
            _context.TravelMaterials.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<TravelMaterial>> DeleteRangeAsync(IEnumerable<TravelMaterial> materials)
        {
            await Task.Delay(0);
            if (materials == null || materials.Count() == 0)
                return new List<TravelMaterial>();

            _context.TravelMaterials.RemoveRange(materials);
            _context.SaveChanges();

            return materials;
        }

        public async Task<IEnumerable<TravelMaterial>> ListAsync(Guid id)
        {

            var entities = await _context.TravelMaterials.Where(c => c.TravelId == id).ToListAsync();
            return entities;
        }

        public async Task<IEnumerable<TravelMaterial>> ListAsync()
        {

            var entities = await _context.TravelMaterials.ToListAsync();
            return entities;
        }


        public async Task<TravelMaterial> UpdateAsync(TravelMaterial TravelMaterial)
        {

            var entity = await _context.TravelMaterials.FindAsync(TravelMaterial.Id);

            _context.TravelMaterials.Update(TravelMaterial);

            _context.SaveChanges();

            return entity;
        }

        public async Task<IEnumerable<TravelMaterial>> UpdateRangeAsync(IEnumerable<TravelMaterial> materials)
        {
            await Task.Delay(0);
            if (materials == null || materials.Count() == 0)
                return new List<TravelMaterial>();

            _context.TravelMaterials.UpdateRange(materials);
            _context.SaveChanges();

            return materials;
        }

        public async Task<TravelMaterial> GetAsync(Guid id)
        {
            var entity = await _context.TravelMaterials.FindAsync(id);
            return entity;
        }
    }
}
