﻿using cvx.lct.vot.api.Models;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Repositories
{
    public interface ITravelRepository
    {
        Task<Travel> CreateAsync(Travel trip);
        Task<Travel> DeleteAsync(Guid id);
        Task<IEnumerable<Travel>> DeleteByJobIdAsync(Guid id);
        Task<IEnumerable<Travel>> ListAsync();
        Task<IEnumerable<Travel>> ListAsync(Guid id);
        Task<Travel> UpdateAsync(Travel Travel);
        Task<Travel> GetAsync(Guid id);
        Task<Travel> GetByJobIdAsync(Guid id);
    }

    public class TravelRepository : ITravelRepository
    {
        private readonly NorthwindContext _context;
        public TravelRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();
        }

        public async Task<Travel> CreateAsync(Travel trip)
        {

            var entity = await _context.Travels.AddAsync(trip);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<Travel> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _JobEntityTableStorageRepository.DeleteOneAsync(JobName, JobKey);
            var entity = await _context.Travels.FindAsync(id);
            _context.Travels.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<Travel>> DeleteByJobIdAsync(Guid id)
        {
            //var deletedEntity = await _JobEntityTableStorageRepository.DeleteOneAsync(JobName, JobKey);
            var entities = await _context.Travels.Where(c => c.JobId == id).ToListAsync();
            _context.Travels.RemoveRange(entities);
            _context.SaveChanges();
            return entities;
        }

        public async Task<IEnumerable<Travel>> ListAsync()
        {

            var entities = await _context.Travels.ToListAsync();
            return entities;
        }

        public async Task<IEnumerable<Travel>> ListAsync(Guid id)
        {

            var entities = await _context.Travels.ToListAsync();
            entities = entities.Where(c => c.JobId == id).ToList();
            return entities;
        }

        public async Task<Travel> UpdateAsync(Travel Travel)
        {

            var entity = await _context.Travels.FindAsync(Travel.Id);

            _context.Travels.Update(Travel);

            _context.SaveChanges();

            return entity;
        }

        public async Task<Travel> GetAsync(Guid id)
        {
            var entity = await _context.Travels.FindAsync(id);
            return entity;
        }

        public async Task<Travel> GetByJobIdAsync(Guid id)
        {
            var entities = await ListAsync(id);
            var entity = entities.FirstOrDefault();
            return entity;
        }
    }
}
