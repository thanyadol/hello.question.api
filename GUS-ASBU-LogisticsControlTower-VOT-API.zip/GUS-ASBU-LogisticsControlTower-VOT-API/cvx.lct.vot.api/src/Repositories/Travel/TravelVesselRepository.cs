﻿using cvx.lct.vot.api.Models;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Repositories
{
    public interface ITravelVesselRepository
    {
        Task<TravelVessel> CreateAsync(TravelVessel load);
        Task<IEnumerable<TravelVessel>> CreateRangeAsync(IEnumerable<TravelVessel> loads);
        Task<TravelVessel> DeleteAsync(Guid id);
        Task<IEnumerable<TravelVessel>> DeleteRangeAsync(IEnumerable<TravelVessel> loads);
        Task<IEnumerable<TravelVessel>> ListAsync();
        Task<IEnumerable<TravelVessel>> ListAsync(Guid id);
        Task<TravelVessel> UpdateAsync(TravelVessel TravelVessel);
        Task<TravelVessel> GetAsync(Guid id);
    }

    public class TravelVesselRepository : ITravelVesselRepository
    {
        private readonly NorthwindContext _context;
        public TravelVesselRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();
        }


        public async Task<TravelVessel> CreateAsync(TravelVessel load)
        {

            var entity = await _context.TravelVessels.AddAsync(load);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<IEnumerable<TravelVessel>> CreateRangeAsync(IEnumerable<TravelVessel> loads)
        {
            await _context.TravelVessels.AddRangeAsync(loads);
            _context.SaveChanges();

            return loads;
        }

        public async Task<TravelVessel> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _JobEntityTableStorageRepository.DeleteOneAsync(JobName, JobKey);
            var entity = await _context.TravelVessels.FindAsync(id);
            _context.TravelVessels.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<TravelVessel>> DeleteRangeAsync(IEnumerable<TravelVessel> loads)
        {
            await Task.Delay(0);
            if (loads == null || loads.Count() == 0)
                return new List<TravelVessel>();

            _context.TravelVessels.RemoveRange(loads);
            _context.SaveChanges();

            return loads;
        }

        public async Task<IEnumerable<TravelVessel>> ListAsync()
        {

            var entities = await _context.TravelVessels.ToListAsync();
            return entities;
        }

        public async Task<IEnumerable<TravelVessel>> ListAsync(Guid id)
        {
            await Task.Delay(0);
            throw new NotImplementedException();

            //var entities = await _context.TravelVessels.ToListAsync();
            //entities = entities.Where(c => c.JobId == jobId).ToList();
            //return entities;
        }

        public async Task<TravelVessel> UpdateAsync(TravelVessel TravelVessel)
        {

            var entity = await _context.TravelVessels.FindAsync(TravelVessel.Id);

            _context.TravelVessels.Update(TravelVessel);

            _context.SaveChanges();

            return entity;
        }

        public async Task<TravelVessel> GetAsync(Guid id)
        {
            var entity = await _context.TravelVessels.FindAsync(id);
            return entity;
        }
    }
}
