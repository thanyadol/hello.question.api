using cvx.lct.vot.api.Models;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Repositories
{
    public interface ITravelBlockingRepository
    {
        Task<TravelBlocking> CreateAsync(TravelBlocking route);
        Task<IEnumerable<TravelBlocking>> CreateRangeAsync(IEnumerable<TravelBlocking> blocks);
        Task<TravelBlocking> DeleteAsync(Guid id);
        Task<IEnumerable<TravelBlocking>> DeleteRangeAsync(IEnumerable<TravelBlocking> blocks);
        Task<IEnumerable<TravelBlocking>> ListAsync();
        Task<IEnumerable<TravelBlocking>> ListAsync(Guid id);
        Task<TravelBlocking> UpdateAsync(TravelBlocking loaded);
        Task<TravelBlocking> GetAsync(Guid id);
    }

    public class TravelBlockingRepository : ITravelBlockingRepository
    {
        private readonly NorthwindContext _context;
        public TravelBlockingRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();
        }

        public async Task<TravelBlocking> CreateAsync(TravelBlocking summary)
        {

            var entity = await _context.TravelBlockings.AddAsync(summary);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<IEnumerable<TravelBlocking>> CreateRangeAsync(IEnumerable<TravelBlocking> blocks)
        {
            await _context.TravelBlockings.AddRangeAsync(blocks);
            _context.SaveChanges();

            return blocks;
        }

        public async Task<TravelBlocking> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _JobEntityTableStorageRepository.DeleteOneAsync(JobName, JobKey);
            var entity = await _context.TravelBlockings.FindAsync(id);
            _context.TravelBlockings.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<TravelBlocking>> DeleteRangeAsync(IEnumerable<TravelBlocking> blocks)
        {
            await Task.Delay(0);
            if (blocks == null || blocks.Count() == 0)
                return new List<TravelBlocking>();

            _context.TravelBlockings.RemoveRange(blocks);
            _context.SaveChanges();

            return blocks;
        }

        public async Task<IEnumerable<TravelBlocking>> ListAsync()
        {

            var entities = await _context.TravelBlockings.ToListAsync();
            return entities;
        }

        public async Task<IEnumerable<TravelBlocking>> ListAsync(Guid id)
        {

            var entities = await _context.TravelBlockings.Where(c => c.TravelId == id).ToListAsync();
            return entities;
        }

        public async Task<TravelBlocking> UpdateAsync(TravelBlocking loaded)
        {

            var entity = await _context.TravelBlockings.FindAsync(loaded.Id);

            _context.TravelBlockings.Update(loaded);

            _context.SaveChanges();

            return entity;
        }

        public async Task<TravelBlocking> GetAsync(Guid id)
        {
            var entity = await _context.TravelBlockings.FindAsync(id);
            return entity;
        }
    }
}
