using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using cvx.lct.vot.api.Extensions;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{

    public interface IPlanCargoRepository
    {
        Task<IEnumerable<PlanCargo>> ListAsync();
        Task<PlanCargo> ListAsync(Guid id);
        Task<PlanCargo> GetAsync(Guid id);
        Task<PlanCargo> CreateAsync(PlanCargo cargo);
        Task<PlanCargo> UpdateAsync(PlanCargo cargo);
    }

    public class PlanCargoRepository : IPlanCargoRepository
    {

        private readonly NorthwindContext _context;
        public PlanCargoRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<PlanCargo> CreateAsync(PlanCargo cargo)
        {

            var entity = await _context.PlanCargos.AddAsync(cargo);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<PlanCargo> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _PlanCargoEntityTableStorageRepository.DeleteOneAsync(PlanCargoName, PlanCargoKey);
            var entity = await _context.PlanCargos.FindAsync(id);
            _context.PlanCargos.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<PlanCargo>> ListAsync()
        {

            var entities = await _context.PlanCargos.ToListAsync();
            //var PlanCargo = _context.PlanCargos.ToList();
            return entities;
        }

        public async Task<PlanCargo> ListAsync(Guid id)
        {

            var entities = await _context.PlanCargos.Where(c => c.PlanId == id
                                        && c.RecordStatus == RecordStatus.ACTIVE.GetDescription()).FirstOrDefaultAsync();
            //var PlanCargo = _context.PlanCargos.ToList();
            return entities;
        }

        public async Task<PlanCargo> UpdateAsync(PlanCargo cargo)
        {

            var entity = await _context.PlanCargos.FindAsync(cargo.Id);

            // cargo.By = "admin";
            // cargo.Date = Utility.CurrentSEAsiaStandardTime();

            _context.PlanCargos.Update(cargo);

            _context.SaveChanges();
            return entity;
        }

        public async Task<PlanCargo> GetAsync(Guid id)
        {
            var entity = await _context.PlanCargos.FindAsync(id);
            return entity;
        }



    }
}