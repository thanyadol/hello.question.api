using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using cvx.lct.vot.api.Exceptions;
using cvx.lct.vot.api.Extensions;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{

    public interface IPlanResourceRepository
    {
        Task<IEnumerable<PlanResource>> ListAsync();
        Task<PlanResource> ListAsync(Guid id);
        Task<PlanResource> GetAsync(Guid id);
        Task<PlanResource> CreateAsync(PlanResource resource);
        Task<PlanResource> UpdateAsync(PlanResource resource);
        Task<PlanResource> GetByPlanAsync(Guid id);
    }

    public class PlanResourceRepository : IPlanResourceRepository
    {

        private readonly NorthwindContext _context;
        public PlanResourceRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<PlanResource> CreateAsync(PlanResource resource)
        {

            var entity = await _context.PlanResources.AddAsync(resource);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<PlanResource> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _PlanResourceEntityTableStorageRepository.DeleteOneAsync(PlanResourceName, PlanResourceKey);
            var entity = await _context.PlanResources.FindAsync(id);
            _context.PlanResources.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<PlanResource>> ListAsync()
        {

            var entities = await _context.PlanResources.ToListAsync();
            //var PlanResource = _context.PlanResources.ToList();
            return entities;
        }


        public async Task<PlanResource> ListAsync(Guid id)
        {

            var entities = await _context.PlanResources
                                    .Where(c => c.PlanId == id && c.RecordStatus == RecordStatus.ACTIVE.GetDescription()).FirstOrDefaultAsync();
            //var PlanResource = _context.PlanResources.ToList();
            return entities;
        }

        public async Task<PlanResource> UpdateAsync(PlanResource resource)
        {

            var entity = await _context.PlanResources.FindAsync(resource.Id);

            // resource.By = "admin";
            // resource.Date = Utility.CurrentSEAsiaStandardTime();

            _context.PlanResources.Update(resource);

            _context.SaveChanges();
            return entity;
        }

        public async Task<PlanResource> GetAsync(Guid id)
        {
            var entity = await _context.PlanResources.FindAsync(id);
            return entity;
        }

        public async Task<PlanResource> GetByPlanAsync(Guid id)
        {
            var entities = await _context.PlanResources.ToListAsync();
            if (entities == null)
            {
                throw new PlanResourceNotFoundException();
            }

            return entities.Where(c => c.PlanId == id).FirstOrDefault();
        }


    }
}