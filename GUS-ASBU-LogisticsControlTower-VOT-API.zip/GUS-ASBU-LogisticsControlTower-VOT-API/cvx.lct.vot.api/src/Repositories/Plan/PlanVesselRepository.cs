using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{

    public interface IPlanVesselRepository
    {
        Task<IEnumerable<PlanVessel>> ListAsync();
        Task<PlanVessel> GetAsync(Guid id);
        Task<PlanVessel> GetByPlanIdAsync(Guid planId);
        Task<PlanVessel> CreateAsync(PlanVessel vessel);
        Task<PlanVessel> UpdateAsync(PlanVessel vessel);
        //Task<PlanVessel> DeleteAsync(Guid id);
    }

    public class PlanVesselRepository : IPlanVesselRepository
    {

        private readonly NorthwindContext _context;
        public PlanVesselRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<PlanVessel> CreateAsync(PlanVessel vessel)
        {

            var entity = await _context.PlanVessels.AddAsync(vessel);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<PlanVessel> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _PlanVesselEntityTableStorageRepository.DeleteOneAsync(PlanVesselName, PlanVesselKey);
            var entity = await _context.PlanVessels.FindAsync(id);
            _context.PlanVessels.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<PlanVessel>> ListAsync()
        {

            var entities = await _context.PlanVessels.ToListAsync();
            //var PlanVessel = _context.PlanVessels.ToList();
            return entities;
        }

        public async Task<PlanVessel> UpdateAsync(PlanVessel vessel)
        {

            var entity = await _context.PlanVessels.FindAsync(vessel.Id);

            // vessel.By = "admin";
            // vessel.Date = Utility.CurrentSEAsiaStandardTime();

            _context.PlanVessels.Update(vessel);

            _context.SaveChanges();
            return entity;
        }

        public async Task<PlanVessel> GetAsync(Guid id)
        {
            var entity = await _context.PlanVessels.FindAsync(id);
            return entity;
        }

        public async Task<PlanVessel> GetByPlanIdAsync(Guid planId)
        {
            var entity = await _context.PlanVessels.Where(c=>c.PlanId == planId).FirstOrDefaultAsync();
            return entity;
        }


    }
}