using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using cvx.lct.vot.api.Extensions;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{

    public interface IPlanRepository
    {
        Task<IEnumerable<Plan>> ListAsync();
        Task<IEnumerable<Plan>> ListAsync(int take);
        Task<Plan> GetAsync(Guid id);
        Task<Plan> CreateAsync(Plan plan);
        Task<Plan> UpdateAsync(Plan plan);

        //Task<Plan> GetPublishWeekAsync(int week, int year);
    }

    public class PlanRepository : IPlanRepository
    {

        private readonly NorthwindContext _context;
        public PlanRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<Plan> CreateAsync(Plan plan)
        {

            var entity = await _context.Plans.AddAsync(plan);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<Plan> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _PlanEntityTableStorageRepository.DeleteOneAsync(PlanName, PlanKey);
            var entity = await _context.Plans.FindAsync(id);
            _context.Plans.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<Plan>> ListAsync()
        {

            var entities = await _context.Plans.ToListAsync();
            //var Plan = _context.Plans.ToList();
            return entities;
        }

        public async Task<IEnumerable<Plan>> ListAsync(int take)
        {

            var entities = await _context.Plans.Where(c => c.ConfigurationType == ConfigurationType.CONFIGURATION.GetDescription()).OrderByDescending(c => c.Date).Take(take).ToListAsync();
            //var Plan = _context.Plans.ToList();
            return entities;
        }



        public async Task<Plan> GetPublishWeekAsync(int week, int year)
        {
            var entities = await (from a in _context.TravelActivities
                                  join t in _context.Travels
                                   on a.TravelId equals t.Id

                                  join p in _context.Plans
                                  on t.PlanId equals p.Id
                                  where p.Week == week && p.Year == year
                                  select new Plan
                                  {
                                      Id = p.Id,
                                      Week = p.Week,
                                      Year = p.Year,
                                      PublishedDate = a.Date.GetValueOrDefault(),

                                  }).OrderByDescending(c => c.PublishedDate).FirstOrDefaultAsync();

            return entities;
        }

        public async Task<Plan> UpdateAsync(Plan plan)
        {

            var entity = await _context.Plans.FindAsync(plan.Id);

            // plan.By = "admin";
            // plan.Date = Utility.CurrentSEAsiaStandardTime();

            _context.Plans.Update(plan);

            _context.SaveChanges();
            return entity;
        }

        public async Task<Plan> GetAsync(Guid id)
        {
            var entity = await _context.Plans.FindAsync(id);
            return entity;
        }



    }
}