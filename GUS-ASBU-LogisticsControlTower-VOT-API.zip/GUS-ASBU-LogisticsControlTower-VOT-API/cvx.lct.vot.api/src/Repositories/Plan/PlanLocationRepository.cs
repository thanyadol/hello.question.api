using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using cvx.lct.vot.api.Extensions;

//vot
using cvx.lct.vot.api.Models;

//EF
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace cvx.lct.vot.api.Repositories
{

    public interface IPlanLocationRepository
    {
        Task<IEnumerable<PlanLocation>> ListAsync();
        Task<PlanLocation> ListAsync(Guid id);
        Task<PlanLocation> GetAsync(Guid id);
        Task<PlanLocation> GetByPlanIdAsync(Guid planId);
        Task<PlanLocation> CreateAsync(PlanLocation locate);
        Task<PlanLocation> UpdateAsync(PlanLocation locate);
        //Task<PlanLocation> DeleteAsync(Guid id);
    }

    public class PlanLocationRepository : IPlanLocationRepository
    {

        private readonly NorthwindContext _context;
        public PlanLocationRepository(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .CreateLogger();

        }

        public async Task<PlanLocation> CreateAsync(PlanLocation locate)
        {

            var entity = await _context.PlanLocations.AddAsync(locate);
            _context.SaveChanges();

            return entity.Entity;
        }

        public async Task<PlanLocation> DeleteAsync(Guid id)
        {
            //var deletedEntity = await _PlanLocationEntityTableStorageRepository.DeleteOneAsync(PlanLocationName, PlanLocationKey);
            var entity = await _context.PlanLocations.FindAsync(id);
            _context.PlanLocations.Remove(entity);
            _context.SaveChanges();
            return entity;
        }

        public async Task<IEnumerable<PlanLocation>> ListAsync()
        {

            var entities = await _context.PlanLocations.ToListAsync();
            //var PlanLocation = _context.PlanLocations.ToList();
            return entities;
        }


        public async Task<PlanLocation> ListAsync(Guid id)
        {

            var entities = await _context.PlanLocations.Where(c => c.PlanId == id
                                        && c.RecordStatus == RecordStatus.ACTIVE.GetDescription()).FirstOrDefaultAsync();
            //var PlanLocation = _context.PlanLocations.ToList();
            return entities;
        }

        public async Task<PlanLocation> UpdateAsync(PlanLocation locate)
        {

            var entity = await _context.PlanLocations.FindAsync(locate.Id);

            // locate.By = "admin";
            // locate.Date = Utility.CurrentSEAsiaStandardTime();

            _context.PlanLocations.Update(locate);

            _context.SaveChanges();
            return entity;
        }

        public async Task<PlanLocation> GetAsync(Guid id)
        {
            var entity = await _context.PlanLocations.FindAsync(id);
            return entity;
        }

        public async Task<PlanLocation> GetByPlanIdAsync(Guid planId)
        {
            var entity = await _context.PlanLocations.Where(c => c.PlanId == planId).FirstOrDefaultAsync();
            return entity;
        }

    }
}