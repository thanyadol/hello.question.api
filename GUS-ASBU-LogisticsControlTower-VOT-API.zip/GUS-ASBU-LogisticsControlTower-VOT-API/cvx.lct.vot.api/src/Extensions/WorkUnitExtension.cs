
using System;
using cvx.lct.vot.api.Models;
using cvx.lct.vot.api.Repositories;
using Microsoft.EntityFrameworkCore.Storage;

namespace cvx.lct.vot.api.Extensions
{
    public interface IEntityTransaction : IDisposable
    {
        void Commit();

        void Rollback();
    }

    public class EntityTransaction : IEntityTransaction
    {
        private readonly IDbContextTransaction _transaction;
        //private readonly NorthwindContext _context;

        public EntityTransaction(NorthwindContext context)
        {
            //_context = context ?? throw new ArgumentNullException(nameof(context));
            _transaction = context.Database.BeginTransaction();
        }

        public void Commit()
        {
            _transaction.Commit();
        }

        public void Rollback()
        {
            _transaction.Rollback();
        }

        public void Dispose()
        {
            _transaction.Dispose();
        }
    }

    public interface IWorkUnitExtension : IDisposable
    {
        IEntityTransaction BeginTransaction();
        IPlanRepository Plans { get; }
        IPlanLocationRepository PlanLocations { get; }

        ILocationStateRepository LocationStates { get; }

        IMaterialRequestRepository MaterialRequests { get; }

        IVesselPropertiesRepository VesselProperties { get; }
        IPlanVesselRepository PlanVesseles { get; }

        IPlanResourceRepository PlanResources { get; }

        ICargoRepository Cargos { get; }
        ICargoPriorityRepository CargoPriorities { get; }
        IPlanCargoRepository PlanCargos { get; }

        ITravelRepository Travels { get; }
        ITravelRouteRepository TravelRoutes { get; }
        ITravelLoadedRepository TravelLoadeds { get; }
        ITravelVesselRepository TravelVessels { get; }
        ITravelMaterialRepository TravelMaterials { get; }
        ITravelTurnaroundRepository TravelTurnarounds { get; }
        ITravelBlockingRepository TravelBlockings { get; }

        IModelParameterRepository ModelParameters { get; }
        IModelPriorityParameterRepository ModelPriorityParameters { get; }
        IModelProductionParameterRepository ModelProductionParameters { get; }
    }

    public class WorkUnitExtension : IWorkUnitExtension
    {
        private readonly NorthwindContext _context;

        public IPlanRepository Plans { get; private set; }
        public IPlanLocationRepository PlanLocations { get; private set; }
        public ILocationStateRepository LocationStates { get; private set; }
        public IMaterialRequestRepository MaterialRequests { get; private set; }

        public IVesselPropertiesRepository VesselProperties { get; private set; }

        public IPlanVesselRepository PlanVesseles { get; private set; }


        public ICargoRepository Cargos { get; private set; }
        public ICargoPriorityRepository CargoPriorities { get; private set; }

        public IPlanResourceRepository PlanResources { get; private set; }
        public IPlanCargoRepository PlanCargos { get; private set; }

        public ITravelRepository Travels { get; private set; }
        public ITravelRouteRepository TravelRoutes { get; private set; }

        public ITravelBlockingRepository TravelBlockings { get; private set; }

        public ITravelLoadedRepository TravelLoadeds { get; private set; }
        public ITravelVesselRepository TravelVessels { get; private set; }
        public ITravelMaterialRepository TravelMaterials { get; private set; }
        public ITravelTurnaroundRepository TravelTurnarounds { get; private set; }

        public IModelParameterRepository ModelParameters { get; private set; }
        public IModelPriorityParameterRepository ModelPriorityParameters { get; private set; }
        public IModelProductionParameterRepository ModelProductionParameters { get; private set; }


        public WorkUnitExtension(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            Plans = new PlanRepository(_context); ;
            PlanLocations = new PlanLocationRepository(_context); ;
            LocationStates = new LocationStateRepository(_context);
            MaterialRequests = new MaterialRequestRepository(_context);

            VesselProperties = new VesselPropertiesRepository(_context);
            PlanVesseles = new PlanVesselRepository(_context);

            Cargos = new CargoRepository(_context);
            CargoPriorities = new CargoPriorityRepository(_context);
            PlanCargos = new PlanCargoRepository(_context);

            PlanResources = new PlanResourceRepository(_context);

            Travels = new TravelRepository(_context);
            TravelRoutes = new TravelRouteRepository(_context);
            TravelLoadeds = new TravelLoadedRepository(_context);
            TravelVessels = new TravelVesselRepository(_context);
            TravelMaterials = new TravelMaterialRepository(_context);
            TravelTurnarounds = new TravelTurnaroundRepository(_context);

            TravelBlockings = new TravelBlockingRepository(_context);

            ModelParameters = new ModelParameterRepository(_context);
            ModelPriorityParameters = new ModelPriorityParameterRepository(_context);
            ModelProductionParameters = new ModelProductionParameterRepository(_context);
        }

        public WorkUnitExtension()
            : this(new NorthwindContext())
        {

        }

        public int Save()
        {
            return _context.SaveChanges();
        }
        public void Dispose()
        {
            _context.Dispose();
        }

        public IEntityTransaction BeginTransaction()
        {
            return new EntityTransaction(_context);
        }
    }
}