
using System;

using System.Data;
using cvx.lct.vot.api.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using Serilog.Core;
using Serilog.Events;

//model
using surflex.netcore22.Models;


namespace cvx.lct.vot.api.Extensions
{

    public class EntityLogEventSink : ILogEventSink
    {
        // private readonly IDbContextTransaction _transaction;
        private readonly NorthwindContext _context;
        private readonly string _connectStr;
        //private readonly IServiceScopeFactory _serviceScopeFactory;

        public EntityLogEventSink(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public EntityLogEventSink()//IServiceScopeFactory serviceScopeFactory)
        {
            this._connectStr = Environment.Configuration.Instance.GetVOTDbConnectionString();

        }

        //
        // Summary:
        //     Emit the provided log event to the sink.
        //
        // Parameters:
        //   logEvent:
        //     The log event to write.
        public void Emit(LogEvent logg)
        {


            var optionsBuilder = new DbContextOptionsBuilder<NorthwindContext>();
            optionsBuilder.UseSqlServer(_connectStr);

            //  var dbContext = new NorthwindContext(optionsBuilder.Options);

            // Or you can instantiate inside using
            using (var dbContext = new NorthwindContext(optionsBuilder.Options))
            {
                // var types =  logg.Properties["type"]
                var unique = logg.Properties["unique"].ToString().Trim('"');

                var events = new __EFLoggingEvent()
                {
                    Id = Guid.NewGuid(),
                    TimeStamp = logg.Timestamp,
                    Level = logg.Level.GetDescription().ToUpper(),
                    // MessageTemplate = logg.MessageTemplate.Text,
                    Exception = logg.Properties["trace"].ToString().Trim('"'),

                    RequestId = Guid.Parse(logg.Properties["requestId"].ToString().Trim('"')),
                    RequestPath = logg.Properties["requestPath"].ToString().Trim('"'),
                    RequestScheme = logg.Properties["requestScheme"].ToString().Trim('"'),
                    // RequestBody = logg.Properties["RequestBody"].ToString(),
                    Unique = unique,
                    Message = logg.RenderMessage(),
                    Type = logg.Properties["type"].ToString().Trim('"'),

                    Date = DateTime.UtcNow
                };

                //var id = Utility.ToUniqeIdentity(cai);
                //var user = dbContext.Users.Find(id);
                if (!string.IsNullOrEmpty(unique))
                {
                    events.By = unique;
                }

                dbContext.__EFLoggingEvents.AddAsync(events);
                dbContext.SaveChanges();



            }

        }
    }
}