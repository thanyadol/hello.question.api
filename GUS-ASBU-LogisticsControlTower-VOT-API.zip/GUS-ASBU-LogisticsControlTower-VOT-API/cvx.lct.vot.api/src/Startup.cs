﻿using System;

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Net.Http.Headers;
using System.Linq;

using Microsoft.EntityFrameworkCore;

using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using System.Text;
using System.Configuration;

using Microsoft.Extensions.DependencyInjection.Extensions;
using AutoMapper;

//logging
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Swagger;
using Microsoft.AspNetCore.Mvc.Authorization;

using Chevron.Identity;
using Chevron.Identity.AspNet.Client;

using cvx.lct.vot.api.Mapper;
using cvx.lct.vot.api.Models;
using cvx.lct.vot.api.Repositories;
using cvx.lct.vot.api.Services;
using cvx.lct.vot.api.Extensions;

using WebApiContrib.Core.Formatter.Csv;
using cvx.lct.vot.api.APIs.Services;
using cvx.lct.vot.api.APIs.Models;
using Microsoft.AspNetCore.Cors.Infrastructure;
using cvx.lct.vot.api.Formatters;
using Microsoft.ApplicationInsights;
using Newtonsoft.Json;
using Chevron.Net.Http;
using Microsoft.AspNetCore.Authentication;
using cvx.lct.vot.api.Validator;
using FluentValidation;
using cvx.lct.vot.api.Middleware;
using Microsoft.AspNetCore.HttpOverrides;
using cvx.lct.vot.api.Filters;
using Newtonsoft.Json.Serialization;
//using Chevron.Identity.AspNet.Client;

namespace cvx.lct.vot.api
{
    public class Startup
    {
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public IConfiguration _configuration { get; }
        public IHostingEnvironment _environment { get; }

        private readonly ILoggerFactory _loggerFactory;

        private static TelemetryClient _telemetry;

        public Startup(IHostingEnvironment environment, IConfiguration configuration,
          ILoggerFactory loggerFactory)
        {
            _configuration = configuration;
            _environment = environment;
            _loggerFactory = loggerFactory;

            _telemetry = new TelemetryClient();
        }

        // This method gets called by the runtime. Use this method to add services to the 
        //container.
        public void ConfigureServices(IServiceCollection services)
        {
            // try
            //  {
            if ((_configuration["AppSettings:AuthenticationMode"] == "Anonymous"))
            {
                services.AddMvc(opts =>
                {
                    //global filter
                    opts.Filters.Add(new AllowAnonymousFilter());
                });
            }
            else
            {
                var csvFormatterOptions = new CsvFormatterOptions();
                csvFormatterOptions.CsvDelimiter = ",";
                var blobFormatterOptions = new BlobFormatterOptions();

                services.AddResponseCompression(options =>
                {
                    options.MimeTypes = ResponseCompressionDefaults.MimeTypes.Concat(new[] { "text/csv" });
                });

                // ...
                services.AddMvc(

                opts =>
                {
                    //global filter
                    // opts.InputFormatters.Add(new CsvInputFormatter(csvFormatterOptions));
                    opts.OutputFormatters.Add(new CsvOutputFormatter(csvFormatterOptions));
                    opts.FormatterMappings.SetMediaTypeMappingForFormat("csv", MediaTypeHeaderValue.Parse("text/csv"));

                    //opts.OutputFormatters.Add(new BlobOutputFormatter(blobFormatterOptions));
                    // opts.FormatterMappings.SetMediaTypeMappingForFormat("blob", MediaTypeHeaderValue.Parse("text/blob"));

                }).SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
            }

            Environment.Configuration.Instance.SetConfiguration(_configuration);
            //in memory
            //services.AddDbContext<NorthwindContext>(opt =>
            //opt.UseInMemoryDatabase("Northwind"));

            //services.AddIdentity<IdentityUser, IdentityRole>();
            //services.AddIdentity<ApplicationUser, IdentityRole>();

            //for http request information
            services.AddHttpContextAccessor();

            //http client factory
            //Set 5 min as the lifetime for the HttpMessageHandler objects in the pool used for the Catalog Typed Client 
            //services.AddHttpClient<IClientService, ClientService>()
            //.SetHandlerLifetime(TimeSpan.FromMinutes(5));

            // services.AddScoped<NorthwindContext>();
            services.AddApiVersioning();


            //serilog custome sink
            // services.AddScoped<EntityLogEventSink>();

            //parameterize
            /*services.AddTransient<NorthwindContext>(provider =>
            {
                //resolve another classes from DI
                var anyOtherClass = provider.GetService<AnyOtherClass>();

                //pass any parameters
                return new NorthwindContext(foo, bar);
            });*/


            //vot
            services.AddDbContext<NorthwindContext>(options =>
                   options.UseSqlServer(Environment.Configuration.Instance.GetVOTDbConnectionString(),
                    x => x.MigrationsHistoryTable("__EFMigrationsHistory", "dbo")));
            // options.UseSqlServer(this._configuration.GetConnectionString("NorthwindConnection"),
            // x => x.MigrationsHistoryTable("__EFMigrationsHistory", "dbo")));

            //lct
            //services.AddDbContext<IcebergContext>(options =>
            // options.UseSqlServer(this._configuration.GetConnectionString("IcebergConnection")));


            services.AddScoped<IVesselService, VesselService>();
            services.AddScoped<IVesselRepository, VesselRepository>();
            services.AddScoped<IPlanVesselRepository, PlanVesselRepository>();
            services.AddScoped<IVesselPropertiesRepository, VesselPropertiesRepository>();

            services.AddScoped<ILocationService, LocationService>();
            services.AddScoped<IVesselLocationService, VesselLocationService>();
            services.AddScoped<ILocationRepository, LocationRepository>();
            services.AddScoped<ILocationStateRepository, LocationStateRepository>();
            services.AddScoped<IPlanLocationRepository, PlanLocationRepository>();

            services.AddScoped<IPlanService, PlanService>();
            services.AddScoped<IPlanRepository, PlanRepository>();
            services.AddScoped<ITravelActivityRepository, TravelActivityRepository>();

            //services.AddScoped<IPlanResourceService, PlanResourceService>();
            services.AddScoped<IPlanResourceRepository, PlanResourceRepository>();

            services.AddScoped<IMaterialService, MaterialService>();
            services.AddScoped<IMaterialRepository, MaterialRepository>();
            services.AddScoped<IMaterialRequestRepository, MaterialRequestRepository>();

            services.AddScoped<ICargoService, CargoService>();
            services.AddScoped<ICargoRepository, CargoRepository>();
            services.AddScoped<ICargoPriorityRepository, CargoPriorityRepository>();
            services.AddScoped<IPlanCargoRepository, PlanCargoRepository>();

            services.AddScoped<IJobService, JobService>();
            services.AddScoped<IJobRepository, JobRepository>();

            services.AddScoped<IRunParameterRepository, RunParameterRepository>();
            services.AddScoped<IModelParameterRepository, ModelParameterRepository>();
            services.AddScoped<IModelPriorityParameterRepository, ModelPriorityParameterRepository>();
            services.AddScoped<IModelProductionParameterRepository, ModelProductionParameterRepository>();

            services.AddScoped<IParamService, ParamService>();

            services.AddScoped<ITravelRepository, TravelRepository>();
            services.AddScoped<ITravelBlockingRepository, TravelBlockingRepository>();
            services.AddScoped<ITravelRouteRepository, TravelRouteRepository>();
            services.AddScoped<ITravelVesselRepository, TravelVesselRepository>();
            services.AddScoped<ITravelLoadedRepository, TravelLoadedRepository>();
            services.AddScoped<ITravelMaterialRepository, TravelMaterialRepository>();
            services.AddScoped<ITravelTurnaroundRepository, TravelTurnaroundRepository>();
            services.AddScoped<ITravelPublishRepository, TravelPublishRepository>();

            services.AddScoped<IAzureService, AzureService>();
            services.AddScoped<IAzurePlanService, AzurePlanService>();
            // services.AddScoped<ICsvService, CsvService>();
            // services.AddScoped<INotificationRepository, NotificationRepository>();
            // services.AddScoped<INotificationService, NotificationService>();


            services.AddScoped<IJobRepository, JobRepository>();
            //services.AddScoped<IJobService, JobService>();

            services.AddScoped<IPlanJobService, PlanJobService>();

            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<ISessionLogRepository, SessionLogRepository>();
            services.AddScoped<IUserService, UserService>();

            services.AddScoped<ITravelService, TravelService>();


            services.AddScoped<ITabularService, TabularService>();
            services.AddScoped<ITabularRepository, TabularRepository>();
            services.AddScoped<ITabularStackRepository, TabularStackRepository>();

            //LCT APIs

            //http client factory
            //Set 5 min as the lifetime for the HttpMessageHandler objects in the pool used for the Catalog Typed Client 
            services.AddHttpClient<IClientService, ClientService>().SetHandlerLifetime(TimeSpan.FromMinutes(5));

            /* 
            services.AddScoped<IEntityService, EntityService>();
            services.AddScoped<ILctService, LctService>();
            services.AddScoped<APIs.Repositories.IVesselRepository, APIs.Repositories.VesselRepository>();
            services.AddScoped<APIs.Repositories.IMaterialRepository, APIs.Repositories.MaterialRepository>();
            services.AddScoped<APIs.Repositories.ILocationRepository, APIs.Repositories.LocationRepository>();
            services.AddScoped<APIs.Repositories.IAdfLogRepository, APIs.Repositories.AdfLogRepository>();*/

            services.AddScoped<Chevron.Identity.ITokenCacheProvider, Chevron.Identity.CoreTokenCacheProvider>();

            services.AddTransient<IWorkUnitExtension, WorkUnitExtension>();
            // services.AddTransient<IUserService, HttpService>();

            //validator
            services.AddScoped<AbstractValidator<PlanParams>, PlanValidator>();


            /******************************/
            // Auto Mapper Configurations

            // Auto Mapper
            //  services.AddAutoMapper(typeof(MappingProfile));

            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new MappingProfile());
            });

            IMapper mapper = mappingConfig.CreateMapper();
            services.TryAddSingleton(mapper);

            // services.AddAuthentication(sharedOptions =>
            // {
            //     sharedOptions.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            // })
            // .AddAzureAdBearer(options => _configuration.Bind("AzureAd", options));


            /* .AddJwtBearer(x =>
             {
                 x.RequireHttpsMetadata = false;
                 x.SaveToken = true;
                 x.TokenValidationParameters = new TokenValidationParameters
                 {
                     ValidateIssuerSigningKey = true,
                     IssuerSigningKey = new SymmetricSecurityKey(key),
                     ValidateIssuer = false,
                     ValidateAudience = false
                 };
             });*/

            //serilog custome sinkc
            services.AddScoped<EntityLogEventSink>();

            services.AddCal(_configuration, true);
            services.AddTransient<ICvxHttpClient, CvxHttpClient>();

            //web socket by microsoft
            services.AddTransient<IJobHubService, JobHubService>();
            services.AddTransient<ITravelHubService, TravelHubService>();

            services.AddSignalR();

            //enable CORES
            services.AddCors(o => o.AddPolicy("AllowCores", builder =>
            {
                builder.AllowAnyOrigin()
                        .AllowAnyMethod()
                        .AllowAnyHeader()
                        .WithOrigins(_configuration.GetValue<string>("AppSettings:HostName", string.Empty))
                        .WithOrigins(Environment.Configuration.Instance.GetCorsURL())
                        .AllowCredentials();
            }));

            //for azure proxy server and lad balance
            services.Configure<ForwardedHeadersOptions>(options =>
            {
                options.ForwardedHeaders =
                    ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
            });


            // Add application services.
            //services.AddTransient<IEmailSender, AuthMessageSender>();
            //services.AddTransient<ISmsSender, AuthMessageSender>();

            // Adds Swagger
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Swashbuckle.AspNetCore.Swagger.Info
                {
                    Version = "v1",
                    Title = "cvx.lct.vot.api",
                    Description = "A simple example ASP.NET Core Web API",
                    TermsOfService = "None",
                    Contact = new Contact
                    {
                        Name = "thanyadol",
                        Email = string.Empty,
                        Url = "https://twitter.com/thanyadol"
                    },
                    License = new License
                    {
                        Name = "Use under LICX",
                        Url = "https://example.com/license"
                    }
                });
            });

            //camel case json serialize
            /*  services.AddMvc()
                     .AddJsonOptions(options => options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver());
             */

            //servicetype di filter
            //services.AddScoped<ActionFilterExample>();
            //services.AddScoped<EnsureUserAuthorizeIn>();
            services.AddScoped<EnsureUserAuthorizeInAsync>();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment _environment, NorthwindContext context)
        {
            var logger = _loggerFactory.CreateLogger<Startup>();

            //for azure proxy server and lad balance
            app.UseForwardedHeaders();

            //context.Database.Migrate();

            if (_environment.IsDevelopment() || _environment.IsEnvironment("dev"))
            {
                // Development service configuration
                app.UseDeveloperExceptionPage();
            }

            if (_environment.IsProduction() || _environment.IsStaging() || !_environment.IsEnvironment("dev"))
            {
                // Non-development service configuration
                app.UseHsts();
                app.UseExceptionHandler("/Error");
            }

            logger.LogInformation($"Environment: {_environment.EnvironmentName}");

            //app.ConfigureExceptionHandler();
            app.ConfigureCustomExceptionMiddleware();

            app.ApplicationServices.GetService<IDisposable>();

            app.UseAuthentication();
            app.UseCors("AllowCores");

            //Add our new middleware to the pipeline
            app.UseMiddleware<LoggingMiddleware>();

            app.UseHttpsRedirection();
            app.UseMvc();

            // Adds Swagger
            if (_configuration.GetValue<bool>("AppSettings:Swagger:IsEnabled", false) == true)
            {
                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("/swagger/v1/swagger.json", "VOT-API V1");
                });
            }

            //signalr route
            app.UseSignalR(routes =>
            {
                routes.MapHub<JobHubMiddleware>("/hub");
            });


        }
    }
}
