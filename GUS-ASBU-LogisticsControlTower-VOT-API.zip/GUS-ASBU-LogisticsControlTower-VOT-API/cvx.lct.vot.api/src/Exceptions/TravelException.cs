using System;
using System.Collections.Generic;
using cvx.lct.vot.api.Models;
using FluentValidation.Results;

namespace cvx.lct.vot.api.Exceptions
{

    public class TravelNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Travel not found";
        public string rev { get; }
        public string value { get; }

        public TravelNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public TravelNotFoundException(Guid id)
            : base(string.Format("Travel with id = {0} not found", id.ToString()))
        {
        }

        public TravelNotFoundException(string message, Travel plan)
            : base(message)
        {
        }

        public TravelNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }

    public class TravelRouteNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Travel route not found";
        public string rev { get; }
        public string value { get; }

        public TravelRouteNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public TravelRouteNotFoundException(Guid id)
            : base(string.Format("Travel route with id = {0} not found", id.ToString()))
        {
        }

        public TravelRouteNotFoundException(string message, Plan plan)
            : base(message)
        {
        }
    }

    public class TravelActivityNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Travel activity not found";
        public string rev { get; }
        public string value { get; }

        public TravelActivityNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public TravelActivityNotFoundException(Guid id)
            : base(string.Format("Travel with id = {0} not found", id.ToString()))
        {
        }

        public TravelActivityNotFoundException(string message, Plan plan)
            : base(message)
        {
        }
    }

    public class TravelNotValidException : Exception
    {
        public List<ValidationFailure> ValidateErrors { get; }
        public List<MaterialParams> NonPendingItems { get; }


        public TravelNotValidException(string message)
            : base(message)
        {
        }

        public TravelNotValidException(List<ValidationFailure> es, List<MaterialParams> ts)
         : base()
        {
            this.NonPendingItems = ts;
            this.ValidateErrors = es;
        }
    }

}