using System;
using cvx.lct.vot.api.Models;

namespace cvx.lct.vot.api.Exceptions
{

    public class CargoNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Cargo not found";
        public string rev { get; }
        public string value { get; }

        public CargoNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public CargoNotFoundException(Guid id)
            : base(string.Format("Cargo with id = {0} not found", id.ToString()))
        {
        }

        public CargoNotFoundException(string message, Cargo cargo)
            : base(message)
        {
        }

        public CargoNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }

}