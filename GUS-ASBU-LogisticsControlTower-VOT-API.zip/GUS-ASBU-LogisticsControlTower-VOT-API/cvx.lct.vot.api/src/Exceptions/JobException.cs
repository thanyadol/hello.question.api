using System;
using cvx.lct.vot.api.Models;

namespace cvx.lct.vot.api.Exceptions
{

    public class JobNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Job not found";
        public string rev { get; }
        public string value { get; }

        public JobNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public JobNotFoundException(Guid id)
            : base(string.Format("Job with id = {0} not found", id.ToString()))
        {
        }


        public JobNotFoundException(string message)
            : base(message)
        {
        }

        public JobNotFoundException(string message, Job job)
            : base(message)
        {
        }

        public JobNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }



    public class JobNotValidException : Exception
    {

        private const string DEFAULT_MESSAGE = "Job not valid";
        public string rev { get; }
        public string value { get; }

        public JobNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public JobNotValidException(Guid id)
            : base(string.Format("Job with id = {0} not fovalidund", id.ToString()))
        {
        }

        public JobNotValidException(string message, Job paras)
            : base(message)
        {
        }
    }

}