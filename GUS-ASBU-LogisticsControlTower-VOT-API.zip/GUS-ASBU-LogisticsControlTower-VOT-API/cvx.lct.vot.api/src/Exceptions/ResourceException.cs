using System;
using cvx.lct.vot.api.Models;

namespace cvx.lct.vot.api.Exceptions
{

    public class PlanResourceNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "PlanResource not found";
        public string rev { get; }
        public string value { get; }

        public PlanResourceNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public PlanResourceNotFoundException(Guid id)
            : base(string.Format("PlanResource with id = {0} not found", id.ToString()))
        {
        }

        public PlanResourceNotFoundException(string message, PlanResource resource)
            : base(message)
        {
        }

        public PlanResourceNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }

}