using System;
using cvx.lct.vot.api.Models;

namespace cvx.lct.vot.api.Exceptions
{

    public class ParamsNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Params not found";
        public string rev { get; }
        public string value { get; }

        public ParamsNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public ParamsNotFoundException(Guid id)
            : base(string.Format("Params with id = {0} not found", id.ToString()))
        {
        }

    }

    public class ParamsNotValidException : Exception
    {

        private const string DEFAULT_MESSAGE = "Params not valid";
        public string rev { get; }
        public string value { get; }

        public ParamsNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public ParamsNotValidException(Guid id)
            : base(string.Format("Params with id = {0} not valid", id.ToString()))
        {
        }

    }
}