using System;
using cvx.lct.vot.api.Models;

namespace cvx.lct.vot.api.Exceptions
{

    public class MaterialNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Material not found";
        public string rev { get; }
        public string value { get; }

        public MaterialNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public MaterialNotFoundException(Guid id)
            : base(string.Format("Material with id = {0} not found", id.ToString()))
        {
        }

        public MaterialNotFoundException(string message, Material material)
            : base(message)
        {
        }

        public MaterialNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }

}