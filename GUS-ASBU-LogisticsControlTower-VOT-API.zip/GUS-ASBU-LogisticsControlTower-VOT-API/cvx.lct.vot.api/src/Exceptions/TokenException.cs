using System;


//model
using surflex.netcore22.Models;

namespace cvx.lct.vot.api.Exceptions
{
    public class InvalidTokenException : Exception
    {
        private const string DEFAULT_MESSAGE = "Token not valid";
        public string rev { get; }
        public string value { get; }

        public InvalidTokenException()
           : base(DEFAULT_MESSAGE)
        {
        }


        /* public InvalidTokenException(Token token)
            : this(string.Format("Token with value = {0} not valid", token.AccessToken))
        {
        }*/

        public InvalidTokenException(string message)
            : base(message)
        {
        }

        public InvalidTokenException(string message, Exception inner)
       : base(message, inner)
        {
        }
    }

}