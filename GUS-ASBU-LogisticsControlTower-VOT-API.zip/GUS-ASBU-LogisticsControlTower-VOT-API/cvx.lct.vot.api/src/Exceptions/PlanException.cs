using System;
using System.Collections.Generic;
using cvx.lct.vot.api.Models;
using FluentValidation.Results;

namespace cvx.lct.vot.api.Exceptions
{

    public class PlanNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Plan not found";
        public string rev { get; }
        public string value { get; }

        public PlanNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public PlanNotFoundException(Guid id)
            : base(string.Format("Plan with id = {0} not found", id.ToString()))
        {
        }

        public PlanNotFoundException(string message, Plan plan)
            : base(message)
        {
        }

        public PlanNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }



    public class PlanNotValidException : Exception
    {
        public List<ValidationFailure> ValidateErrors { get; }


        public PlanNotValidException(string message)
            : base(message)
        {
        }

        public PlanNotValidException(List<ValidationFailure> es)
         : base()
        {
            this.ValidateErrors = es;
        }
    }

}