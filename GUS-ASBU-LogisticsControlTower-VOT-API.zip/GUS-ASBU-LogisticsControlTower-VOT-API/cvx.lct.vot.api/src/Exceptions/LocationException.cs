using System;
using cvx.lct.vot.api.Models;

namespace cvx.lct.vot.api.Exceptions
{

    public class LocationNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Location not found";
        public string rev { get; }
        public string value { get; }

        public LocationNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public LocationNotFoundException(Guid id)
            : base(string.Format("Location with id = {0} not found", id.ToString()))
        {
        }

        public LocationNotFoundException(string message, Location loc)
            : base(message)
        {
        }


        public LocationNotFoundException(string message)
            : base(message)
        {
        }

        public LocationNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }


    public class LocationStateNotFoundException : Exception
    {
        public LocationStateNotFoundException(Guid id)
          : base(string.Format("Port state with location id = {0} not found", id.ToString()))
        {
        }
    }

}