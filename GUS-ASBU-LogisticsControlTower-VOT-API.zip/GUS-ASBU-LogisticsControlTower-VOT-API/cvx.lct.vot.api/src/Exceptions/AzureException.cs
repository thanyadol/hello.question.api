﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Exceptions
{
    public class AzureNotValidException : Exception
    {

        private const string DEFAULT_MESSAGE = "Blob not found";
        public string rev { get; }
        public string value { get; }

        public AzureNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public AzureNotValidException(string message)
       : base(message)
        {
        }

        public AzureNotValidException(Guid id)
            : base(string.Format("Blob with id = {0} not found", id.ToString()))
        {
        }

        public AzureNotValidException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }
}
