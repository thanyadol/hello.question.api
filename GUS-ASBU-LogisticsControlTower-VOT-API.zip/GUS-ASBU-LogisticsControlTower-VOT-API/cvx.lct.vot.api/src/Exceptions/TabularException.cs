using System;
using cvx.lct.vot.api.Models;

namespace cvx.lct.vot.api.Exceptions
{

    public class TabularNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Tabular not found";
        public string rev { get; }
        public string value { get; }

        public TabularNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public TabularNotFoundException(Guid id)
            : base(string.Format("Tabular with id = {0} not found", id.ToString()))
        {
        }

        public TabularNotFoundException(string message, Tabular tar)
            : base(message)
        {
        }


        public TabularNotFoundException(string message)
            : base(message)
        {
        }

        public TabularNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }


    public class TabularStackNotFoundException : Exception
    {
        private const string DEFAULT_MESSAGE = "Tabular stack not found";
        public string rev { get; }
        public string value { get; }

        public TabularStackNotFoundException()
         : base(DEFAULT_MESSAGE)
        {
        }

        public TabularStackNotFoundException(Guid id)
          : base(string.Format("Tabular stack with taration id = {0} not found", id.ToString()))
        {
        }
    }

}