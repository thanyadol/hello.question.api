using System;
using cvx.lct.vot.api.Models;

namespace cvx.lct.vot.api.Exceptions
{

    public class VesselNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Vessel not found";
        public string rev { get; }
        public string value { get; }

        public VesselNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }


        public VesselNotFoundException(Guid id)
            : base(string.Format("Vessel with id = {0} not found", id.ToString()))
        {
        }


        public VesselNotFoundException(string message)
            : base(message)
        {
        }

        public VesselNotFoundException(string message, Vessel vess)
            : base(message)
        {
        }

        public VesselNotFoundException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }

    public class VesselETANotFoundException : Exception
    {

        public VesselETANotFoundException(Guid id)
            : base(string.Format("Vessel ETA with vessel id = {0} not found", id.ToString()))
        {
        }
    }



    public class VesselNotValidException : Exception
    {

        private const string DEFAULT_MESSAGE = "Vessel not valid";
        public string rev { get; }
        public string value { get; }

        public VesselNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public VesselNotValidException(Guid id)
            : base(string.Format("Vessel with id = {0} not valid", id.ToString()))
        {
        }
    }


    public class VesselSpecNotFoundException : Exception
    {

        public VesselSpecNotFoundException(Guid id)
            : base(string.Format("Vessel spce with vessel id = {0} not found", id.ToString()))
        {
        }
    }


    public class VesselActivityNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Vessel activity not found";
        public string rev { get; }
        public string value { get; }

        public VesselActivityNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public VesselActivityNotFoundException(Guid id)
            : base(string.Format("Vessel activity with vessel id = {0} not found", id.ToString()))
        {
        }
    }



    public class VesselPropertiesNotFoundException : Exception
    {

        private const string DEFAULT_MESSAGE = "Vessel properties not found";
        public string rev { get; }
        public string value { get; }

        public VesselPropertiesNotFoundException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public VesselPropertiesNotFoundException(Guid id)
            : base(string.Format("Vessel properties with vessel id = {0} not found", id.ToString()))
        {
        }

        public VesselPropertiesNotFoundException(string msg)
            : base(string.Format("{0}", msg))
        {
        }
    }



}