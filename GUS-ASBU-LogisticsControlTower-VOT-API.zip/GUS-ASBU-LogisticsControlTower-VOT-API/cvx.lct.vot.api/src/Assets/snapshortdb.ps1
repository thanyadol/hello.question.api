    
$snapshotname = 'advacne10@spin16'
dotnet ef migrations add $snapshotname  --project 	cvx.lct.vot.api.csproj --context NorthwindContext