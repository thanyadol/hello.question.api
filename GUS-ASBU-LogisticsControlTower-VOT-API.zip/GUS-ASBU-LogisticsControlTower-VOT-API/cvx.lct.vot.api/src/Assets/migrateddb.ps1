
$date = Get-Date -Format "yyyyMMddHHmmss"
$path = "Migrations/20200415001advacne10@spin16.sql"
dotnet ef migrations script > $path   --context 		NorthwindContext