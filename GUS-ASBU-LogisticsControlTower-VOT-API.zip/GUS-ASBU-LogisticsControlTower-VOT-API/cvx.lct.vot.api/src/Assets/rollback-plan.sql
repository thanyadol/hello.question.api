
delete  from [Plan] where id != '000D5A47-26A6-4271-BFDB-644EBB0A16FB'

delete from [PlanLocation] where planid in  (
				select id  from [Plan] where id != '000D5A47-26A6-4271-BFDB-644EBB0A16FB')
delete  from [PlanLocation] where planid != '000D5A47-26A6-4271-BFDB-644EBB0A16FB'

delete from [VesselProperties] where PlanVesselId in (
			select id from [PlanVessel] where planid != '000D5A47-26A6-4271-BFDB-644EBB0A16FB') 
delete  from [PlanVessel] where planid != '000D5A47-26A6-4271-BFDB-644EBB0A16FB'

delete from [PlanResource] where planid != '000D5A47-26A6-4271-BFDB-644EBB0A16FB'

delete from [CargoPriority] where PlanCargoId in (select id from [PlanCargo] where planid != '000D5A47-26A6-4271-BFDB-644EBB0A16FB')
delete  from [PlanCargo] where planid != '000D5A47-26A6-4271-BFDB-644EBB0A16FB'