﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Authentication;

//logg
using Serilog;

//services
using System.IO;
using System.Net.Http;
using cvx.lct.vot.api.Models;
using cvx.lct.vot.api.Services;
using cvx.lct.vot.api.Exceptions;

using PLAN = cvx.lct.vot.api.Models.Constant.Plan;
using cvx.lct.vot.api.Filters;

namespace cvx.lct.vot.api.Controllers
{
    [Authorize]
    [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
    [ApiVersion("1.0")]
    [Route("api/{version:apiVersion}/[controller]")]
    [ApiController]
    public class VesselController : ControllerBase
    {
        private readonly IVesselService _vesselService;

        public VesselController(IVesselService vesselService, IUserService userService)
        {
            _vesselService = vesselService ?? throw new ArgumentNullException(nameof(vesselService));
        }


        /*
        [EnableCors("AllowCores")]
        [Route("etd/calculate/blob")]
        [Produces("text/blob")]
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<VesselDepartureParams>), StatusCodes.Status200OK)]
        public async Task<IActionResult> EstimateTimeDepartureWithPlanIdBlobAsync([FromBody]VesselDepartureRequestParams vesseldepartureRequestParams)
        {
            var entity = await _vesselService.EstimateTimeDepartureAsync(vesseldepartureRequestParams);
            return Ok(entity);
        }

        [EnableCors("AllowCores")]
        [Route("etd/calculate/csv")]
        [Produces("text/csv")]
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<VesselDepartureParams>), StatusCodes.Status200OK)]
        public async Task<IActionResult> EstimateTimeDepartureWithPlanIdCsvAsync([FromBody]VesselDepartureRequestParams vesseldepartureRequestParams)
        {
            var entity = await _vesselService.EstimateTimeDepartureAsync(vesseldepartureRequestParams);
            return Ok(entity);
        }
        */

        [EnableCors("AllowCores")]
        [Route("etd/calculate")]
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<VesselDepartureParams>), StatusCodes.Status200OK)]
        public async Task<IActionResult> EstimateTimeDepartureWithPlanIdAsync([FromBody] VesselDepartureRequestParams vesseldepartureRequestParams)
        {
            var entity = await _vesselService.EstimateTimeDepartureAsync(vesseldepartureRequestParams);
            return Ok(entity);
        }

        [EnableCors("AllowCores")]
        [Route("blockout/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<VesselBlockout>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListBlockoutAsync()
        {
            var vessels = await _vesselService.ListBlockoutAsync();
            return Ok(vessels);
        }


        [EnableCors("AllowCores")]
        [Route("props/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<VesselProperties>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListPropertiesAsync(Guid id)
        {
            var vessels = await _vesselService.ListPropertiesAsync(id);
            return Ok(vessels);
        }


        [EnableCors("AllowCores")]
        [Route("props/synce")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<VesselProperties>), StatusCodes.Status200OK)]
        public async Task<IActionResult> SyncePropertiesAsync(Guid id)
        {
            var vessels = await _vesselService.SyncePropertiesAsync(id);
            return Ok(vessels);
        }


        //vessel
        [EnableCors("AllowCores")]
        [Route("synce")]
        [HttpGet]
        [ProducesResponseType(typeof(PlanVessel), StatusCodes.Status200OK)]
        public async Task<IActionResult> SynceVesselAsync(Guid id)
        {
            //var id = PLAN.DEFAULT_PLANNED_ID;

            var plans = await _vesselService.GetPlanVesselAsync(id);
            return Ok(plans);
        }


        [EnableCors("AllowCores")]
        [Route("get")]
        [HttpGet]
        [ProducesResponseType(typeof(PlanVessel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(PlanVessel), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetVesselAsync(Guid id)
        {
            //change to encrypted
            var vess = await _vesselService.GetPlanVesselAsync(id);
            if (vess == null)
            {
                throw new PlanNotFoundException();
            }

            return Ok(vess);
        }


        /* 
        [EnableCors("AllowCores")]
        [Route("post")]
        [HttpPost]
        [ProducesResponseType(typeof(Vessel), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateAsync([FromBody]Vessel vessel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _vesselService.CreateAsync(vessel);

            return CreatedAtAction(
                nameof(CreateAsync),
                entity
            );
        }*/


    }
}
