using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Authentication;

//logg
using Serilog;

//services
using System.IO;
using System.Net.Http;
using cvx.lct.vot.api.Models;
using cvx.lct.vot.api.Services;
using cvx.lct.vot.api.Exceptions;
using cvx.lct.vot.api.Filters;
using cvx.lct.vot.api.Extensions;
using cvx.lct.vot.api.Models.Gateway;

namespace cvx.lct.vot.api.Controllers
{
    [Authorize]
    [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
    [ApiVersion("1.0")]
    [Route("api/{version:apiVersion}/[controller]")]
    [ApiController]
    public class JobController : ControllerBase
    {
        private readonly IJobService _jobService;

        //  private readonly IJobResultService _jobResultService;

        private readonly IJobHubService _jobHubService;

        private readonly IAzureService _azureService;

        private readonly ITravelService _travelService;

        public JobController(IJobService jobService, IJobHubService jobHubService, IAzureService azureService, ITravelService travelService)
        {
            _jobService = jobService ?? throw new ArgumentNullException(nameof(jobService));
            //  _jobResultService = jobResultService ?? throw new ArgumentNullException(nameof(jobResultService));
            _jobHubService = jobHubService ?? throw new ArgumentNullException(nameof(jobHubService));
            _azureService = azureService ?? throw new ArgumentNullException(nameof(azureService));
            _travelService = travelService ?? throw new ArgumentNullException(nameof(travelService));
        }

        [EnableCors("AllowCores")]
        [Route("recent")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Job>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListRecentAsync()
        {
            var jobs = await _jobService.ListRecentAsync();
            return Ok(jobs);
        }


        [EnableCors("AllowCores")]
        [Route("list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Job>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListAsync()
        {
            var jobs = await _jobService.ListAsync();
            return Ok(jobs);
        }


        [EnableCors("AllowCores")]
        [Route("noti/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<JobParams>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListParamsAsync()
        {
            var jobs = await _jobHubService.ListParamsAsync();
            return Ok(jobs);
        }

        [EnableCors("AllowCores")]
        [Route("noti/get")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<JobParams>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetRecentlyParamsAsync(Guid id)
        {
            var jobs = await _jobHubService.GetRecentlyParamsAsync(id);
            return Ok(jobs);
        }


        [EnableCors("AllowCores")]
        [Route("inprogress")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Job>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListInProgressAsync()
        {
            var jobs = await _jobService.ListProgressAsync();
            return Ok(jobs);
        }



        [EnableCors("AllowCores")]
        [Route("get")]
        [HttpGet]
        [ProducesResponseType(typeof(Job), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Job), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAsync(Guid id)
        {
            //change to encrypted
            var vess = await _jobService.GetAsync(id);
            return Ok(vess);
        }

        /* 
        [EnableCors("AllowCores")]
        [Route("status")]
        [HttpGet]
        [ProducesResponseType(typeof(Job), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Job), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetStatusAsync(Guid id)
        {
            //change to encrypted
            var job = await _jobService.GetAsync(id);
            if (job == null)
            {
                throw new JobNotFoundException(id);
            }

            job = await _databrickService.GetJobStatusAsync(job);

            return Ok(job);
        }*/

        [EnableCors("AllowCores")]
        [Route("result")]
        [HttpGet]
        [ProducesResponseType(typeof(Attachment), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Attachment), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAttachAsync(Guid id, string status)
        {
            //change to encrypted
            var job = await _jobService.GetAsync(id);
            if (job == null)
            {
                throw new JobNotFoundException(id);
            }

            var attach = await _travelService.GetAttachAsync(job, status);

            return Ok(attach);
        }

        /* [EnableCors("AllowCores")]
        [Route("output")]
        [HttpGet]
        [ProducesResponseType(typeof(Attachment), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Attachment), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetResultJsonAsync(Guid id)
        {
            //change to encrypted
            var job = await _jobService.GetAsync(id);
            if (job == null)
            {
                throw new JobNotFoundException(id);
            }

            var planTravel = await _jobResultService.GetPlanTravelAsync(job.Id);

            return Ok(planTravel);
        }*/

        [EnableCors("AllowCores")]
        [Route("cancel")]
        [HttpPost]
        [ProducesResponseType(typeof(Job), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Job), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> CancelJobAsync(Guid id)
        {
            var job = await _jobService.GetAsync(id);
            if (job == null)
            {
                throw new JobNotFoundException(id);
            }

            job = await _azureService.CancelJobAsync(job.Id);
            return Ok(job);
        }

        /*[EnableCors("AllowCores")]
        [Route("post")]
        [HttpPost]
        [ProducesResponseType(typeof(Job), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateAsync([FromBody]Job job)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _jobService.CreateAsync(job);

            return CreatedAtAction(
                nameof(CreateAsync),
                entity
            );
        }*/

        [EnableCors("AllowCores")]
        [Route("put")]
        [HttpPut]
        [ProducesResponseType(typeof(Job), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UpdateAsync([FromBody] Job job)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _jobService.UpdateAsync(job);

            //if (entity.Status == JobStatus.SUCCEEDED.GetDescription())
            //    await _databrickService.PutTravelAsync(entity.Id);

            return Ok(entity);
        }


        //run databrick job with Plan id
        [EnableCors("AllowCores")]
        [Route("run")]
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<Job>), StatusCodes.Status200OK)]
        public async Task<IActionResult> RunAsync(Job job)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _azureService.RunJobAsync(job);
            return Ok(entity); ;
        }



    }
}
