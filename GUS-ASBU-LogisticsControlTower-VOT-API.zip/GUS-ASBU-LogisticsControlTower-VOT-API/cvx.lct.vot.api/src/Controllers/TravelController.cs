using System;
using Microsoft.AspNetCore.Authorization;

using Microsoft.AspNetCore.Mvc;

using cvx.lct.vot.api.Services;
using System.Threading.Tasks;
using cvx.lct.vot.api.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;

namespace cvx.lct.vot.api.Controllers
{
    // [Authorize]
    //[ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
    [ApiVersion("1.0")]
    [Route("api/{version:apiVersion}/[controller]")]
    [ApiController]
    public class TravelController : ControllerBase
    {
        private readonly ITravelService _travelService;

        public TravelController(ITravelService travelService)
        {
            _travelService = travelService ?? throw new ArgumentNullException(nameof(travelService));
        }

        [EnableCors("AllowCores")]
        [Route("get")]
        [HttpGet]
        [ProducesResponseType(typeof(TravelParams), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAsync(Guid id)
        {
            var entity = await _travelService.GetAsync(id);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("route/get")]
        [HttpGet]
        [ProducesResponseType(typeof(TravelParams), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetRouteAsync(Guid id)
        {
            var entity = await _travelService.GetRouteAsync(id);
            return Ok(entity);
        }

        [EnableCors("AllowCores")]
        [Route("publish/get")]
        [HttpGet]
        [ProducesResponseType(typeof(TravelParams), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetPublishParamsAsync(PublishParams param)
        {
            var entity = await _travelService.GetPublishParamsAsync(param);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("loaded/get")]
        [HttpGet]
        [ProducesResponseType(typeof(TravelParams), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetLoadedAsync(Guid id)
        {
            var entity = await _travelService.GetLoadedAsync(id);
            return Ok(entity);
        }




        [EnableCors("AllowCores")]
        [Route("material/get")]
        [HttpGet]
        [ProducesResponseType(typeof(TravelParams), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetMaterialAsync(Guid id)
        {
            var entity = await _travelService.GetMaterialAsync(id);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("vessel/get")]
        [HttpGet]
        [ProducesResponseType(typeof(TravelParams), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetVesselAsync(Guid id)
        {
            var entity = await _travelService.GetVesselAsync(id);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("turn/get")]
        [HttpGet]
        [ProducesResponseType(typeof(TravelParams), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetTurnaroundAsync(Guid id)
        {
            var entity = await _travelService.GetTurnaroundAsync(id);
            return Ok(entity);
        }

        [EnableCors("AllowCores")]
        [Route("route/block/get")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<RouteParams>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListCurrentlyActivityAsync(Guid id)
        {
            var entities = await _travelService.ListCurrentlyActivityAsync(id);
            return Ok(entities);
        }


        [EnableCors("AllowCores")]
        [Route("route/current")]
        [HttpGet]
        [ProducesResponseType(typeof(TravelParams), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListCurrentRouteAsync(Guid id)
        {
            var entities = await _travelService.ListCurrentRouteAsync(id);
            return Ok(entities);
        }

        [EnableCors("AllowCores")]
        [Route("route/daily")]
        [HttpGet]
        [ProducesResponseType(typeof(TravelParams), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetDailyRouteAsync(Guid id)
        {
            var entities = await _travelService.GetDailyRouteAsync(id);
            return Ok(entities);
        }

        [EnableCors("AllowCores")]
        [Route("route/jetty")]
        [HttpGet]
        [ProducesResponseType(typeof(TravelParams), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetJettyBlockAsync(Guid id)
        {
            var entities = await _travelService.GetJettyBlockAsync(id);
            return Ok(entities);
        }


        [EnableCors("AllowCores")]
        [Route("list")]
        [HttpGet]
        [ProducesResponseType(typeof(TravelParams), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListRecentlyAsync()
        {
            var entity = await _travelService.ListRecentlyAsync();
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("gulf/list")]
        [HttpGet]
        [ProducesResponseType(typeof(TravelParams), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListGulfAsync(Guid id)
        {
            var entity = await _travelService.ListGulfAsync(id);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("gulf/attach")]
        [HttpGet]
        [ProducesResponseType(typeof(Attachment), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetGulfAttachAsync()
        {
            var entity = await _travelService.GetGulfAttachAsync();
            return Ok(entity);
        }

        [EnableCors("AllowCores")]
        [Route("activity/get")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<TravelActivity>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetActivityAsync(Guid id)
        {
            var entity = await _travelService.GetActivityAsync(id);
            return Ok(entity);
        }



        [EnableCors("AllowCores")]
        [Route("activity/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<TravelActivity>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListRecentlyActivityAsync()
        {
            var entity = await _travelService.ListRecentlyActivityAsync();
            return Ok(entity);
        }



        [EnableCors("AllowCores")]
        [Route("publish/recent")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<TravelActivity>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetLastPublishedAsync()
        {
            var entity = await _travelService.GetLastPublishedAsync();
            return Ok(entity);
        }

        [EnableCors("AllowCores")]
        [Route("publish/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<TravelActivity>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListPublishedAsync()
        {
            var entity = await _travelService.ListPublishedAsync();
            return Ok(entity);
        }




        [EnableCors("AllowCores")]
        [Route("publish")]
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<TravelActivity>), StatusCodes.Status200OK)]
        public async Task<IActionResult> PublishAsync(PublishParams param)
        {
            var entity = await _travelService.PublishAsync(param);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("publish/validate")]
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<TravelActivity>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ValidatePublishedAsync(PublishParams param)
        {
            var entity = await _travelService.ValidatePublishedAsync(param);
            return Ok(entity);
        }

        [EnableCors("AllowCores")]
        [Route("favorite")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<TravelActivity>), StatusCodes.Status200OK)]
        public async Task<IActionResult> PutFavoriteAsync(Guid id)
        {
            var entity = await _travelService.PutFavoriteAsync(id);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("synce")]
        [HttpPost]
        [ProducesResponseType(typeof(Guid), StatusCodes.Status200OK)]
        public async Task<IActionResult> PutTravelAsync(Guid id)
        {
            var entity = await _travelService.PutTravelAsync(id);
            return Ok(entity);
        }

    }
}