using System;

using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

using System.IO;
using surflex.netcore22.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;
using Chevron.Identity.AspNet.Client;
using Newtonsoft.Json;
using System.Security.Claims;
using Chevron.Identity;
using Microsoft.Extensions.Options;
using System.Threading.Tasks;
using surflex.netcore22.Models.DTO;

namespace surflex.netcore22.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiVersionNeutral]
    [AllowAnonymous]
    public class HelloController : ControllerBase
    {

        private readonly IConfiguration configuration;

        /* private readonly IAzureADOptions _options;
        private readonly ITokenManagerProvider _tokenManager;
        private readonly ICvxHttpClient _client;
        private readonly ICvxClaimsPrincipal _cvxClaimsPrincipal;*/

        public HelloController(IConfiguration _configuration)
        {
            configuration = _configuration ?? throw new ArgumentNullException(nameof(_configuration));
        }



        [EnableCors("AllowCores")]
        [Route("")]
        [HttpGet]
        public ActionResult<string> Index()
        {
            //var user = CvxClaimsPrincipal.Current;
            var user = HttpContext.User;

            return $"Hello World with .NET Framework CORE Web API at { DateTime.UtcNow }.";
        }

        //[AllowAnonymous]
        [EnableCors("AllowCores")]
        [Route("hosting")]
        [HttpGet]
        public ActionResult<string> Hosting()
        {
            return Ok(configuration["AppSettings:HostName"]);
        }

        //[AllowAnonymous]
        [EnableCors("AllowCores")]
        [Route("health")]
        [HttpGet]
        public ActionResult<Health> Health()
        {
            return new Health("Ok");
        }

        //[AllowAnonymous]
        [EnableCors("AllowCores")]
        [Route("throw")]
        [HttpGet]
        public ActionResult<string> Throw()
        {
            throw new IOException();
        }
    }
}