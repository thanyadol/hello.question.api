using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Authentication;

//logg
using Serilog;

//services
using System.IO;
using System.Net.Http;
using cvx.lct.vot.api.Models;
using cvx.lct.vot.api.Services;
using cvx.lct.vot.api.Exceptions;
using cvx.lct.vot.api.Filters;
using cvx.lct.vot.api.Extensions;
using cvx.lct.vot.api.Models.Gateway;

namespace cvx.lct.vot.api.Controllers
{
    [Authorize]
    [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
    [ApiVersion("1.0")]
    [Route("api/{version:apiVersion}/[controller]")]
    [ApiController]
    public class ParamController : ControllerBase
    {
        private readonly IParamService _paramService;
        public ParamController(IParamService paramService)
        {
            _paramService = paramService ?? throw new ArgumentNullException(nameof(paramService));
        }



        [EnableCors("AllowCores")]
        [Route("run/recent")]
        [HttpGet]
        [ProducesResponseType(typeof(RunParameter), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RunParameter), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetRecentlyRunAsync()
        {

            var pppp = await _paramService.GetRecentlyRunAsync();
            return Ok(pppp);
        }


        [EnableCors("AllowCores")]
        [Route("run/get")]
        [HttpGet]
        [ProducesResponseType(typeof(RunParameter), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RunParameter), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetRunAsync(Guid id)
        {

            var pppp = await _paramService.GetRunAsync(id);
            return Ok(pppp);
        }


        [EnableCors("AllowCores")]
        [Route("run/default")]
        [HttpGet]
        [ProducesResponseType(typeof(RunParameter), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RunParameter), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> EnforceDefaultRunAsync()
        {

            var pppp = await _paramService.EnforceDefaultRunAsync();
            return Ok(pppp);
        }


        [EnableCors("AllowCores")]
        [Route("run/post")]
        [HttpPost]
        [ProducesResponseType(typeof(ModelParameter), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ModelParameter), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> CreateAsync(RunParameter param)
        {

            var pppp = await _paramService.CreateAsync(param);
            return Ok(pppp);
        }

        /////

        [EnableCors("AllowCores")]
        [Route("model/recent")]
        [HttpGet]
        [ProducesResponseType(typeof(ModelParameter), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ModelParameter), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetRecentlyModelAsync()
        {

            var pppp = await _paramService.GetRecentlyModelAsync();
            return Ok(pppp);
        }


        [EnableCors("AllowCores")]
        [Route("model/get")]
        [HttpGet]
        [ProducesResponseType(typeof(ModelParameter), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ModelParameter), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetModelAsync(Guid id)
        {

            var pppp = await _paramService.GetModelAsync(id);
            return Ok(pppp);
        }


        [EnableCors("AllowCores")]
        [Route("model/default")]
        [HttpGet]
        [ProducesResponseType(typeof(ModelParameter), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ModelParameter), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> EnforceDefaultModelAsync()
        {

            var pppp = await _paramService.EnforceDefaultModelAsync();
            return Ok(pppp);
        }


        [EnableCors("AllowCores")]
        [Route("model/post")]
        [HttpPost]
        [ProducesResponseType(typeof(ModelParameter), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ModelParameter), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> BatchCreateAsync(ModelParams param)
        {

            var pppp = await _paramService.BatchCreateAsync(param);
            return Ok(pppp);
        }

    }
}