using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Authentication;

//logg
using Serilog;

//services
using System.IO;
using System.Net.Http;
using cvx.lct.vot.api.Models;
using cvx.lct.vot.api.Services;
using cvx.lct.vot.api.Exceptions;
using cvx.lct.vot.api.Filters;


using PLAN = cvx.lct.vot.api.Models.Constant.Plan;

namespace cvx.lct.vot.api.Controllers
{
    [Authorize]
    [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
    [ApiVersion("1.0")]
    [Route("api/{version:apiVersion}/[controller]")]
    [ApiController]
    public class MaterialController : ControllerBase
    {
        private readonly IMaterialService _materialService;

        public MaterialController(IMaterialService materialService, IUserService userService)
        {
            _materialService = materialService ?? throw new ArgumentNullException(nameof(materialService));
        }



        [EnableCors("AllowCores")]
        [Route("task/synce")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<MaterialRequest>), StatusCodes.Status200OK)]
        public async Task<IActionResult> SynceTaskAsync()
        {
            var materials = await _materialService.SynceTaskAsync(); //shcedule id
            return Ok(materials);
        }



        [EnableCors("AllowCores")]
        [Route("task/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<MaterialRequest>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListTaskAsync(Guid id)
        {
            if (id == PLAN.DEFAULT_PLANNED_ID)
            {
                var materials = await _materialService.SynceTaskAsync(); //shcedule id
                return Ok(materials);
            }
            else
            {
                var materials = await _materialService.ListTaskAsync(id); //shcedule id
                return Ok(materials);
            }
        }

        [EnableCors("AllowCores")]
        [Route("task/list/blob")]
        [Produces("text/blob")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<MaterialRequest>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListTaskBlobAsync(Guid id)
        {
            var materials = await _materialService.ListTaskAsync(id); //shcedule id
            return Ok(materials);
        }


        [EnableCors("AllowCores")]
        [Route("list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Material>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListAsync()
        {

            var materials = await _materialService.ListAsync();
            return Ok(materials);
        }

        [EnableCors("AllowCores")]
        [Route("list/blob")]
        [Produces("text/blob")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Material>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListBlobAsync()
        {

            var materials = await _materialService.ListAsync();
            return Ok(materials);
        }

        [EnableCors("AllowCores")]
        [Route("get")]
        [HttpGet]
        [ProducesResponseType(typeof(Material), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Material), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAsync(Guid id)
        {
            //change to encrypted
            var vess = await _materialService.GetAsync(id);
            if (vess == null)
            {
                throw new MaterialNotFoundException();
            }

            return Ok(vess);
        }

        /* 
        [EnableCors("AllowCores")]
        [Route("post")]
        [HttpPost]
        [ProducesResponseType(typeof(Material), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateAsync([FromBody]Material material)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _materialService.CreateAsync(material);

            return CreatedAtAction(
                nameof(CreateAsync),
                entity
            );
        }*/



    }
}
