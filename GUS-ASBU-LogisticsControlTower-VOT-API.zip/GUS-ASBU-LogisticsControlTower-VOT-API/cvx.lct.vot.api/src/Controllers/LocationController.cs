using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Authentication;

//logg
using Serilog;

//services
using System.IO;
using System.Net.Http;
using cvx.lct.vot.api.Models;
using cvx.lct.vot.api.Services;
using cvx.lct.vot.api.Exceptions;
using cvx.lct.vot.api.Filters;

namespace cvx.lct.vot.api.Controllers
{
    [Authorize]
    [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
    [ApiVersion("1.0")]
    [Route("api/{version:apiVersion}/[controller]")]
    [ApiController]
    public class LocationController : ControllerBase
    {
        private readonly ILocationService _locationService;

        public LocationController(ILocationService locationService, IUserService userService)
        {
            _locationService = locationService ?? throw new ArgumentNullException(nameof(locationService));
        }

        /*        [EnableCors("AllowCores")]
        [Route("restrict/init")]
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<LocationState>), StatusCodes.Status200OK)]
        public async Task<IActionResult> InitRestrictedHourAsync([FromBody]IEnumerable<LocationState> states)
        {
            var locations = await _locationService.InitRestrictedHourAsync(states);
            return Ok(locations);

        }*/


        [EnableCors("AllowCores")]
        [Route("list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Location>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListLocationAsync(string type)
        {
            if (type == "cluster")
            {

                var locations = await _locationService.ListClusterAsync();
                return Ok(locations);
            }

            if (type == "terminal")
            {

                var locations = await _locationService.ListTerminalAsync();
                return Ok(locations);
            }

            if (type == "tanker")
            {

                var locations = await _locationService.ListTankerAsync();
                return Ok(locations);
            }

            throw new LocationNotFoundException();
        }

        [EnableCors("AllowCores")]
        [Route("synce")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Location>), StatusCodes.Status200OK)]
        public async Task<IActionResult> SynceAsync()
        {
            var locations = await _locationService.SynceAsync();
            return Ok(locations);
        }


        /* [EnableCors("AllowCores")]
        [Route("cluster/synce")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Location>), StatusCodes.Status200OK)]
        public async Task<IActionResult> SynceCusterAsync()
        {
            var locations = await _locationService.SynceCusterAsync();
            return Ok(locations);
        }*/



        [EnableCors("AllowCores")]
        [Route("tank/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<LocationState>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListTankAsync(Guid id)  //schedule id
        {
            var locations = await _locationService.ListTankAsync(id);
            return Ok(locations);
        }


        [EnableCors("AllowCores")]
        [Route("restrict/list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<LocationState>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListRestrictedHourAsync(Guid id) //schedule id
        {
            var locations = await _locationService.ListRestrictedHourAsync(id);
            return Ok(locations);
        }



        [EnableCors("AllowCores")]
        [Route("tank/synce")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<LocationState>), StatusCodes.Status200OK)]
        public async Task<IActionResult> SynceTankerAsync()  //schedule id
        {
            var locations = await _locationService.SynceTankerAsync();
            return Ok(locations);
        }


        [EnableCors("AllowCores")]
        [Route("restrict/synce")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<LocationState>), StatusCodes.Status200OK)]
        public async Task<IActionResult> SynceRestrictedHourAsync() //schedule id
        {
            var locations = await _locationService.SynceRestrictedHourAsync();
            return Ok(locations);
        }


        [EnableCors("AllowCores")]
        [Route("get")]
        [HttpGet]
        [ProducesResponseType(typeof(Location), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Location), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAsync(Guid id)
        {
            //change to encrypted
            var vess = await _locationService.GetAsync(id);
            if (vess == null)
            {
                throw new LocationNotFoundException();
            }

            return Ok(vess);
        }

        /* 
        [EnableCors("AllowCores")]
        [Route("post")]
        [HttpPost]
        [ProducesResponseType(typeof(Location), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateAsync([FromBody]Location location)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _locationService.CreateAsync(location);

            return CreatedAtAction(
                nameof(CreateAsync),
                entity
            );
        }*/


    }
}
