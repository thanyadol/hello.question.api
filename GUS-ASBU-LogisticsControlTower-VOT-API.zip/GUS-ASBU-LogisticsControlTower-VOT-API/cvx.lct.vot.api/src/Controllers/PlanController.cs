using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Authentication;

//logg
using Serilog;

//services
using System.IO;
using System.Net.Http;
using cvx.lct.vot.api.Models;
using cvx.lct.vot.api.Services;
using cvx.lct.vot.api.Exceptions;

using PLAN = cvx.lct.vot.api.Models.Constant.Plan;
using FluentValidation.Results;
using cvx.lct.vot.api.Filters;

namespace cvx.lct.vot.api.Controllers
{
    [Authorize]
    [ServiceFilter(typeof(EnsureUserAuthorizeInAsync))]
    [ApiVersion("1.0")]
    [Route("api/{version:apiVersion}/[controller]")]
    [ApiController]
    public class PlanController : ControllerBase
    {
        private readonly IPlanService _planService;

        public PlanController(IPlanService planService)
        {
            _planService = planService ?? throw new ArgumentNullException(nameof(planService));
        }


        [EnableCors("AllowCores")]
        [Route("recent")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Plan>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListRecentAsync()
        {
            var plans = await _planService.ListRecentAsync();
            return Ok(plans);
        }


        [EnableCors("AllowCores")]
        [Route("validate")]
        [HttpPost]
        [ProducesResponseType(typeof(ValidationResult), StatusCodes.Status200OK)]
        public async Task<IActionResult> ValidateParamsAsync(Guid id)
        {
            var entity = await _planService.ValidateParamsAsync(id);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("params/get")]
        [HttpGet]
        [ProducesResponseType(typeof(PlanParams), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetParamsAsync(Guid id)
        {
            var entity = await _planService.GetParamsAsync(id);
            return Ok(entity);
        }


        [EnableCors("AllowCores")]
        [Route("list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Plan>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListAsync()
        {
            var plans = await _planService.ListAsync();
            return Ok(plans);
        }


        [EnableCors("AllowCores")]
        [Route("synce")]
        [HttpGet]
        [ProducesResponseType(typeof(Plan), StatusCodes.Status200OK)]
        public async Task<IActionResult> SynceAsync()
        {
            //var id = PLAN.DEFAULT_PLANNED_ID;

            var plans = await _planService.SynceAsync();
            return Ok(plans);
        }


        [EnableCors("AllowCores")]
        [Route("default")]
        [HttpGet]
        [ProducesResponseType(typeof(Plan), StatusCodes.Status200OK)]
        public async Task<IActionResult> SynceDefaultAsync()
        {
            //alway get first default for reset defualt purpose
            var id = PLAN.DEFAULT_PLANNED_ID;

            var plans = await _planService.GetRecentlyAsync(id);
            return Ok(plans);
        }

        //baatch post
        [EnableCors("AllowCores")]
        [Route("default/post")]
        [HttpPost]
        [ProducesResponseType(typeof(Plan), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BatchDefaultAsync([FromBody] PlanParams plan)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _planService.BatchDefaultAsync(plan);

            return Ok(entity);
        }



        [EnableCors("AllowCores")]
        [Route("get")]
        [HttpGet]
        [ProducesResponseType(typeof(Plan), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Plan), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetRecentlyAsync(Guid id)
        {
            //change to encrypted
            var vess = await _planService.GetRecentlyAsync(id);
            if (vess == null)
            {
                throw new PlanNotFoundException();
            }

            return Ok(vess);
        }

        //resource
        [EnableCors("AllowCores")]
        [Route("resource/synce")]
        [HttpGet]
        [ProducesResponseType(typeof(PlanResource), StatusCodes.Status200OK)]
        public async Task<IActionResult> SynceResourceAsync()
        {
            var id = PLAN.DEFAULT_PLANNED_ID;

            var plans = await _planService.GetResourceAsync(id);
            return Ok(plans);
        }


        [EnableCors("AllowCores")]
        [Route("resource/get")]
        [HttpGet]
        [ProducesResponseType(typeof(PlanResource), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(PlanResource), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetResourceAsync(Guid id)
        {
            //change to encrypted
            var vess = await _planService.GetResourceAsync(id);
            if (vess == null)
            {
                throw new PlanNotFoundException();
            }

            return Ok(vess);
        }

        //location
        [EnableCors("AllowCores")]
        [Route("location/synce")]
        [HttpGet]
        [ProducesResponseType(typeof(PlanLocation), StatusCodes.Status200OK)]
        public async Task<IActionResult> SynceLocationAsync()
        {
            var id = PLAN.DEFAULT_PLANNED_ID;

            var plans = await _planService.GetLocationAsync(id);
            return Ok(plans);
        }


        [EnableCors("AllowCores")]
        [Route("location/get")]
        [HttpGet]
        [ProducesResponseType(typeof(PlanLocation), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(PlanLocation), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetLocationAsync(Guid id)
        {
            //change to encrypted
            var vess = await _planService.GetLocationAsync(id);
            if (vess == null)
            {
                throw new PlanNotFoundException();
            }

            return Ok(vess);
        }


        //location
        [EnableCors("AllowCores")]
        [Route("cargo/synce")]
        [HttpGet]
        [ProducesResponseType(typeof(PlanCargo), StatusCodes.Status200OK)]
        public async Task<IActionResult> SynceCargoAsync()
        {

            var id = PLAN.DEFAULT_PLANNED_ID;

            var plans = await _planService.GetCargoAsync(id);
            return Ok(plans);
        }


        [EnableCors("AllowCores")]
        [Route("cargo/get")]
        [HttpGet]
        [ProducesResponseType(typeof(PlanCargo), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(PlanCargo), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetCargoAsync(Guid id)
        {
            //change to encrypted
            var vess = await _planService.GetCargoAsync(id);
            if (vess == null)
            {
                throw new PlanNotFoundException();
            }

            return Ok(vess);
        }


        //baatch post
        [EnableCors("AllowCores")]
        [Route("post")]
        [HttpPost]
        [ProducesResponseType(typeof(Plan), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BatchCreateAsync([FromBody] PlanParams plan)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _planService.BatchCreateAsync(plan);

            return Ok(entity);
        }


        //baatch put
        [EnableCors("AllowCores")]
        [Route("put")]
        [HttpPut]
        [ProducesResponseType(typeof(Plan), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BatchUpdateAsync([FromBody] PlanParams plan)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await _planService.BatchUpdateAsync(plan);

            return Ok(entity);
        }



    }
}
