using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using cvx.lct.vot.api.APIs.Models;
using cvx.lct.vot.api.APIs.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


namespace cvx.lct.vot.api.APIs.Controller
{
    /*
    * this controller no longer use as we do not intend to separate API by system
    *
    *
    */

    [AllowAnonymous]
    [ApiVersion("1.0")]
    [Route("apis/{version:apiVersion}/[controller]")]
    [ApiController]
    public class LocationController : ControllerBase
    {
        private readonly IClientService _clientService;
        // private readonly IEntityService _entityService;

        public LocationController(IClientService clientService)
        {
            //_entityService = entityService ?? throw new ArgumentNullException(nameof(entityService));
            _clientService = clientService ?? throw new ArgumentNullException(nameof(clientService));
        }


        [EnableCors("AllowCores")]
        [Route("list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<LocationAsync>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListAsync()
        {
            var entities = await _clientService.ListLocationAsync();
            return Ok(entities);
        }

    }
}
