using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using cvx.lct.vot.api.APIs.Models;
using cvx.lct.vot.api.APIs.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


namespace cvx.lct.vot.api.APIs.Controller
{
    /*
    * this controller no longer use as we do not intend to separate API by system
    *
    *
    */


    [ApiVersion("1.0")]
    [Route("apis/{version:apiVersion}/[controller]")]
    [ApiController]
    public class VesselController : ControllerBase
    {
        /* *private readonly IEntityService _entityService;

        public VesselController(IEntityService entityService)
        {
            _entityService = entityService ?? throw new ArgumentNullException(nameof(entityService));
        }


        [EnableCors("AllowCores")]
        [Route("list")]
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<VesselAsync>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ListVesselAsync()
        {
            var entities = await _entityService.ListVesselAsync();
            return Ok(entities);
        }*/

    }
}
