using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.APIs.Models
{
    [Table("LCT_MMR", Schema = "dbo")]
    public class MmrAsync
    {
        [Column("MRMaterialRequestDetailsId")]
        public int? MRMaterialRequestDetailsId { get; set; }

        [Column("MRMaterialRequestId")]
        public int? MRMaterialRequestId { get; set; }

        [Column("RequestStatus")]
        public string RequestStatus { get; set; }

        [Column("SubmitDate")]
        public DateTime? SubmitDate { get; set; }

        [Column("PlannedDispatchDate")]
        public DateTime? PlannedDispatchDate { get; set; }

        [Column("ROSDate")]
        public DateTime? ROSDate { get; set; }

        [Column("MRPriorityId")]
        public int? MRPriorityId { get; set; }

        [Column("Priority")]
        public string Priority { get; set; }

        [Column("RentalCost")]
        public string RentalCost { get; set; }

        [Column("Asset")]
        public string Asset { get; set; }

        [Column("MRDepartmentId")]
        public int? MRDepartmentId { get; set; }

        [Column("Origin")]
        public string Origin { get; set; }

        [Column("OriginId")]
        public int? OriginId { get; set; }

        [Column("Destination")]
        public string Destination { get; set; }

        [Column("DestinationId")]
        public int? DestinationId { get; set; }

        [Column("Department")]
        public string Department { get; set; }

        [Column("LCTMRNumber")]
        public int? LCTMRNumber { get; set; }

        [Column("ItemType")]
        public string ItemType { get; set; }

        [Column("MaterialDescription")]
        public string MaterialDescription { get; set; }

        [Column("QuantityValue")]
        public decimal? QuantityValue { get; set; }

        [Column("QuantityUnit")]
        public string QuantityUnit { get; set; }

        [Column("MRQuantityUnitId")]
        public int? MRQuantityUnitId { get; set; }

        [Column("WeightValue")]
        public decimal? WeightValue { get; set; }

        [Column("WeightUnit")]
        public string WeightUnit { get; set; }

        [Column("MRWeightUnitId")]
        public int? MRWeightUnitId { get; set; }

        [Column("Length")]
        public decimal? Length { get; set; }

        [Column("Width")]
        public decimal? Width { get; set; }

        [Column("Height")]
        public decimal? Height { get; set; }

        [Column("Area")]
        public decimal? Area { get; set; }

        [Column("MaterialLongDescription")]
        public string MaterialLongDescription { get; set; }

        [Column("ContainerOwner")]
        public string ContainerOwner { get; set; }

        [Column("Consignee")]
        public string Consignee { get; set; }

        [Column("Vendor")]
        public string Vendor { get; set; }

        [Column("Hazmat")]
        public bool? Hazmat { get; set; }

        [Column("ReasonForPostpone")]
        public string ReasonForPostpone { get; set; }

        [Column("Remarks")]
        public string Remarks { get; set; }

        [Column("UNNumber")]
        public string UNNumber { get; set; }

        [Column("MRMaterialClassId")]
        public int? MRMaterialClassId { get; set; }

        [Column("MaterialClass")]
        public string MaterialClass { get; set; }

        [Column("UserId")]
        public int? UserId { get; set; }

        [Column("LastModifiedBy")]
        public string LastModifiedBy { get; set; }

        [Column("OrderNumber")]
        public string OrderNumber { get; set; }

        [Column("PlannedVesselId")]
        public int? PlannedVesselId { get; set; }

        [Column("PlannedVesselName")]
        public string PlannedVesselName { get; set; }

        [Column("SevenDayPlannedDispatchDate")]
        public DateTime? SevenDayPlannedDispatchDate { get; set; }

        [Column("ActualVesselId")]
        public int? ActualVesselId { get; set; }

        [Column("ActualVesselName")]
        public string ActualVesselName { get; set; }

        [Column("InnerItemExist")]
        public int? InnerItemExist { get; set; }

        [Column("MRContainerId")]
        public int? MRContainerId { get; set; }

        [Column("MRPackageId")]
        public int? MRPackageId { get; set; }

        [Column("MRLoosePieceId")]
        public int? MRLoosePieceId { get; set; }

        [Column("MRBundleId")]
        public int? MRBundleId { get; set; }

        [Column("MRTubularId")]
        public int? MRTubularId { get; set; }

        [Column("MRJointId")]
        public int? MRJointId { get; set; }

        [Column("MRDeliveryLocationId")]
        public int? MRDeliveryLocationId { get; set; }

        [Column("IsAssignedToVessel")]
        public bool? IsAssignedToVessel { get; set; }

        [Column("TotalWeight")]
        public decimal? TotalWeight { get; set; }

        [Column("IsDeleted")]
        public bool? IsDeleted { get; set; }
    }
}