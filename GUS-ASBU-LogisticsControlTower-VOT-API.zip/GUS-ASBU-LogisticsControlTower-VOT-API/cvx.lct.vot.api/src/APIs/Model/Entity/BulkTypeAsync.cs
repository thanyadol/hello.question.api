﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.APIs.Models
{
    [Table("LCT_Bulk", Schema = "dbo")]
    public class BulkTypeAsync
    {
        [Column("BulkId")]
        public int Id { get; set; }
        [Column("BulkName")]
        public string Name { get; set; }
    }
}
