﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.APIs.Models
{
    [Table("LCT_VesselSpecification", Schema = "dbo")]
    public class VesselSpecAsync
    {
        [Column("VesselId")]
        public int VesselId { get; set; }

        [Column("ActualDeadWeight")]
        public decimal? EffectiveDeadWeight { get; set; }

        [Column("ActualDeckSpace")]
        public decimal? EffectiveDeckSpace { get; set; }

        [Column("ActualPotWaterTanksTotal")]
        public decimal? EffectivePotWater { get; set; }

        [Column("ActualDrillWaterTanksTotal")]
        public decimal? EffectiveDrillWater { get; set; }

        [Column("AvailableFuelTanksTotal")]
        public decimal? DieselTankCapacity { get; set; }

        [NotMapped]
        public Nullable<decimal> SaralineTank { get; set; }
        [NotMapped]
        public Nullable<decimal> Saraline { get; internal set; }
        [NotMapped]
        public Nullable<decimal> SaralinePerTank { get; internal set; }

        [NotMapped]
        public Nullable<decimal> Barite { get; set; }

        [NotMapped]
        public Nullable<decimal> BaritePerTank { get; set; }

        [NotMapped]
        public Nullable<decimal> BariteTank { get; set; }

        [NotMapped]
        public Nullable<decimal> HCement { get; set; }

        [NotMapped]
        public Nullable<decimal> HCementPerTank { get; set; }

        [NotMapped]
        public Nullable<decimal> HCementTank { get; set; }

        [NotMapped]
        public Nullable<decimal> BhiCement { get; set; }

        [NotMapped]
        public Nullable<decimal> BhiCementPerTank { get; set; }

        [NotMapped]
        public Nullable<decimal> BhiCementTank { get; set; }
    }
}
