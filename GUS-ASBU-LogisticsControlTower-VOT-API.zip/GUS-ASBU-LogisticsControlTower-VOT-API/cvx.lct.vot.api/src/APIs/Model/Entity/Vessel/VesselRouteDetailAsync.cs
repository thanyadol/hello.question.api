﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.APIs.Models
{
    [Table("LCT_VesselRouteDetails", Schema = "dbo")]
    public class VesselRouteDetailAsync
    {
        [Column("VesselRouteDetailsId")]
        public int Id { get; set; }
        [Column("VesselRouteId")]
        public int RouteId { get; set; }
        [Column("FromId")]
        public int FromId { get; set; }
        [Column("ToId")]
        public int ToId { get; set; }
        [Column("LatitudeFrom")]
        public decimal? LatitudeFrom { get; set; }
        [Column("LongitudeFrom")]
        public decimal? LongitudeFrom { get; set; }
        [Column("LatitudeTo")]
        public decimal? LatitudeTo { get; set; }
        [Column("LongitudeTo")]
        public decimal? LongitudeTo { get; set; }
        [Column("SequenceNumber")]
        public int SequenceNumber { get; set; }
        [Column("Comments")]
        public string Comments { get; set; }
        [Column("ETD")]
        public DateTime? ETD { get; set; }
        [Column("ETA")]
        public DateTime? ETA { get; set; }
        [Column("MannualETD")]
        public DateTime? MannualETD { get; set; }
        [Column("MannualETA")]
        public DateTime? MannualETA { get; set; }
        [Column("UpdatedETD")]
        public DateTime? UpdatedETD { get; set; }
        [Column("UpdatedETA")]
        public DateTime? UpdatedETA { get; set; }
        [Column("Speed")]
        public decimal? Speed { get; set; }
        [Column("Distance")]
        public decimal? Distance { get; set; }
        [Column("LoadingTime")]
        public decimal? LoadingTime { get; set; }
        [Column("SpaceFIlled")]
        public decimal? SpaceFIlled { get; set; }
        [Column("SpaceFree")]
        public decimal? SpaceFree { get; set; }
        [Column("SpaceRemaining")]
        public decimal? SpaceRemaining { get; set; }
        [Column("WeightAdded")]
        public decimal? WeightAdded { get; set; }
        [Column("WeightRemoved")]
        public decimal? WeightRemoved { get; set; }
        [Column("WeightRemaining")]
        public decimal? WeightRemaining { get; set; }
        [Column("assignedActivities")]
        public string assignedActivities { get; set; }
        [Column("vsitComments")]
        public string vsitComments { get; set; }
        [Column("assignedVSIT")]
        public string assignedVSIT { get; set; }
        [Column("Isdeleted")]
        public bool Isdeleted { get; set; }
        [Column("IsActual")]
        public bool IsActual { get; set; }
        [Column("IsCurrent")]
        public bool IsCurrent { get; set; }
        [Column("LocationStatus")]
        public string LocationStatus { get; set; }

        [NotMapped]
        public int StatusId { get; internal set; }

        [NotMapped]
        public int VesselId { get; set; }

        [NotMapped]
        public string VesselName { get; set; }

        [NotMapped]
        public int OriginId { get; set; }

        [NotMapped]
        public string Origin { get; set; }

        [NotMapped]
        public int DestinationId { get; set; }

        [NotMapped]
        public string Destination { get; set; }
        [NotMapped]
        public DateTime Etd { get; set; }
        [NotMapped]
        public DateTime Eta { get; set; }

        [NotMapped]
        public int RouteStatusId { get; set; }


        public bool IsDeleted { get; set; }

        [NotMapped]
        public DateTime? ProcessETD { get; set; }
        [NotMapped]
        public DateTime? UpdatedProcessETD { get; set; }

    }
}
