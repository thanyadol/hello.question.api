﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.APIs.Models
{
    [Table("LCT_VSVesselActivityRequestMaster", Schema = "dbo")]
    public class VesselActivityTypeAsync
    {
        [Column("VSVesselActivityRequestId")]
        public int Id { get; set; }
        [Column("ActivityType")]
        public string Type { get; set; }
        [Column("ActivityRequestType")]
        public string RequestType { get; set; }
        [Column("IsDeleted")]
        public bool IsDeleted { get; set; }
        [Column("IsActive")]
        public bool IsActive { get; set; }

    }
}
