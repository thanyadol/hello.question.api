using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.APIs.Models
{
    [Table("LCT_Vessel", Schema = "dbo")]
    public class VesselAsync
    {
        [Column("VesselId")]
        public int Id { get; set; }

        [Column("VesselName")]
        public string Name { get; set; }

        [Column("VesselTypeId")]
        public int TypeId { get; set; }

        [NotMapped]
        public string Type { get; set; }

        [Column("VesselStatusId")]
        public int StatusId { get; set; }

        [Column("Speed")]
        public double? Speed { get; set; }

        [Column("MaxSpeed")]
        public decimal? MaxSpeed { get; set; }

        [NotMapped]
        public string Status { get; set; }

        [Column("OVIDDate")]

        public Nullable<DateTime> Date { get; set; }

        [NotMapped]
        public VesselSpecAsync Specfication { get; set; }
    }
}