﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.APIs.Models
{
    [Table("LCT_VesselType", Schema = "dbo")]
    public class VesselTypeAsync
    {
        [Column("VesselTypeId")]
        public int Id { get; set; }

        [Column("VesselType")]
        public string Type { get; set; }

        [Column("IsDeleted")]
        public bool IsDeleted { get; set; }

    }
}
