using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.APIs.Models
{
    [Table("LCT_VesselStatus", Schema = "dbo")]
    public class VesselStatusAsync
    {
        [Column("VesselStatusId")]
        public int Id { get; set; }

        [Column("VesselStatus")]
        public string Status { get; set; }
        
    }
}