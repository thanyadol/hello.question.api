﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.APIs.Models
{
    [Table("LCT_VesselRoute", Schema = "dbo")]
    public class VesselRouteAsync
    {
        [Column("VesselRouteId")]
        public int Id { get; set; }
        [Column("VesselId")]
        public int VesselId { get; set; }
        [Column("VesselRoutePurposeId")]
        public int PurposeId { get; set; }
        [Column("ETAAtJetty")]
        public DateTime ETA { get; set; }
        [Column("DurationAtPort")]
        public int DurationAtPort { get; set; }
        [Column("ETDFromJetty")]
        public DateTime ETD { get; set; }
        [Column("StatusId")]
        public int StatusId { get; set; }
        [Column("FromPortId")]
        public int FromPortId { get; set; }
        [Column("ToPortId")]
        public int ToPortId { get; set; }
        [Column("PlanDispatchDate")]
        public DateTime? PlanDispatchDate { get; set; }
        [Column("Comments")]
        public string Comments { get; set; }
        [Column("IsWeekly")]
        public bool? IsWeekly { get; set; }
        [Column("IsPublish")]
        public bool? IsPublish { get; set; }
        [Column("IsDeleted")]
        public bool IsDeleted { get; set; }
        [Column("CreatedDate")]
        public DateTime? CreatedDate { get; set; }
        [Column("CreatedBy")]
        public int CreatedBy { get; set; }
        [Column("VoyageNumber")]
        public string VoyageNumber { get; set; }
        [Column("VRGuid")]
        public Guid VRGuid { get; set; }
        [Column("IsActual")]
        public bool? IsActual { get; set; }
        [Column("MarineControllerId")]
        public int? MarineControllerId { get; set; }
        [Column("IsCurrent")]
        public bool? IsCurrent { get; set; }
        [Column("LastModifiedDate")]
        public DateTime? LastModifiedDate { get; set; }
        [Column("LastModifiedBy")]
        public int? LastModifiedBy { get; set; }
    }
}
