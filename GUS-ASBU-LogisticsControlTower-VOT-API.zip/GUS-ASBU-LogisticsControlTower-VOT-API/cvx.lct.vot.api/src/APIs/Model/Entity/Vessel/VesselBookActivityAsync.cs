﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.APIs.Models
{
    public class VesselBookActivityAsync
    {
        public int BookedActivityId { get; set; }
        public string DataSource { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int? ActivityTypeId { get; set; }
        public string ActivityDetails { get; set; }
        public string ActivityDescription { get; set; }
        public string ActivityInfo { get; set; }
        public int? VesselId { get; set; }
        public string VesselName { get; set; }
        public int? RigId { get; set; }
        public int? RigMoveId { get; set; }
        public int? DORPlatformId { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? LastModifiedDate { get; set; }
        public int? LastModifiedBy { get; set; }
        public bool? IsDeleted { get; set; }

        [NotMapped]
        public string ActivityType { get; set; }
    }
}
