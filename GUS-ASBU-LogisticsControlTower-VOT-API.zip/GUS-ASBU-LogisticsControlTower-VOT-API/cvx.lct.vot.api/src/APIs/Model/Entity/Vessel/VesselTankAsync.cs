﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.APIs.Models
{
    [Table("LCT_VesselTank", Schema = "dbo")]
    public class VesselTankAsync
    {
        [Column("VesselTankId")]
        public int Id { get; set; }
        [Column("VesselId")]
        public int VesselId { get; set; }
        [Column("TankName")]
        public string TankName { get; set; }
        [Column("Available")]
        public decimal? Available { get; set; }
        [Column("Actual")]
        public decimal? Actual { get; set; }
        [Column("VesselTankTypeId")]
        public int TankTypeId { get; set; }
        [Column("BulkId")]
        public int BulkId { get; set; }
        [Column("IsDeleted")]
        public bool IsDeleted { get; set; }
    }
}
