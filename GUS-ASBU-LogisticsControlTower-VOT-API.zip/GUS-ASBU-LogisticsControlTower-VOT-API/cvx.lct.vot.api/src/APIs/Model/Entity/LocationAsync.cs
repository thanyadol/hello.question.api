using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.APIs.Models
{
    [Table("LCT_Location", Schema = "dbo")]
    public class LocationAsync
    {
        [Column("LocationId")]
        public Nullable<int> Id { get; set; }

        [Column("LocationCode")]
        public string Code { get; set; }

        [Column("LocationName")]
        public string Name { get; set; }

        [Column("Latitude")]
        public Nullable<decimal> Latitude { get; set; }

        [Column("Longitude")]
        public Nullable<decimal> Longitude { get; set; }


        [Column("LocationType")]
        public string Type { get; set; }

        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public int LocationTypeId { get; set; }

        [NotMapped]
        public string Asset { get; set; }

        [NotMapped]
        public string AssetColor { get; set; }

        [NotMapped]
        public int DORPlatformId { get; set; }
    }




}