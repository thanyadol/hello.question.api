﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.APIs.Models
{
    public class Route
    {
        public int SequenceNumber { get; set; }
        public int VesselId { get; set; }
        public string VesselName { get; set; }
        public int OriginId { get; set; }
        public string Origin { get; set; }
        public int DestinationId { get; set; }
        public string Destination { get; set; }
        public DateTime Etd { get; set; }
        public DateTime Eta { get; set; }
        public int RouteStatusId { get; set; }
        public string RouteStatusName { get; set; }
        public string PlanType { get; set; }
        public bool IsActual { get; set; }
        public bool IsCurrent { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime? UpdatedETA { get; set; }
        public DateTime? UpdatedETD { get; set; }
        public string LocationStatus { get; set; }
    }

    public class RouteListAsync
    {
        public IEnumerable<Route> AllRoutePlanList { get; set; }
    }
}
