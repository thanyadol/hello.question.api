﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.APIs.Models
{
    public class Booked
    {
        public int BookedActivityId { get; set; }
        public int? ActivityTypeId { get; set; }
        public string ActivityType { get; set; }
        public string ActivityDetails { get; set; }
        public string ActivityDescription { get; set; }
        public string ActivityInfo { get; set; }
        public int? VesselId { get; set; }
        public string VesselName { get; set; }
        public int? RigId { get; set; }
        public int? RigMoveId { get; set; }
        public int? DorPlatformId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public bool IsDeleted { get; set; }
    }

    public class BookedList
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public IEnumerable<Booked> votBookingActivityList { get; set; }
    }
}
