﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.APIs.Models
{
    public class PublishAsync
    {
        public LCTPullichResponse FlaggingMessage { get; set; }
        public LCTSuccessPublishResponse PublishedRoutes { get; set; }
        public string Message { get; set; }
    }

    public class NoRouteCreator
    {
        public string EmailAddress { get; set; }
        public Guid VOTUniqueNumber { get; set; }
        public string Message { get; set; }
    }

    public class LCTPullichResponse
    {
        public string Message { get; set; }
        public IEnumerable<MaterialInfo> NonPendingItems { get; set; }
        public IEnumerable<RouteMap> RouteMap { get; set; }
        public IEnumerable<NonDraftVCN> SurpassedVCNs { get; set; }
        public IEnumerable<NoRouteCreator> NoRouteCreator { get; set; }
    }

    public class LCTSuccessPublishResponse
    {
        public string Message { get; set; }
        public IEnumerable<RouteMap> RouteMap { get; set; }
    }

    public class NonDraftVCN
    {
        public string VCN { get; set; }
    }

    public class RouteMap
    {
        public string VCN { get; set; }
        public Guid VOTUniqueNumber { get; set; }
    }

    public class MaterialInfo
    {
        public int MaterialRequestId { get; set; }
        public int LCTMMRNumber { get; set; }
        public int MaterialRequestDetailsId { get; set; }
        public int? VesselID { get; set; }
        public string VesselName { get; set; }
        public Guid? VOTUniqueNumber { get; set; }
        public string CurrentStatusOfItem { get; set; }
        public string CurrentAssignedVessel { get; set; }
    }
}
