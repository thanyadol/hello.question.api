

using System;

using System.ComponentModel;
//using surflex.netcore22.Helpers;

namespace cvx.lct.vot.api.APIs.Models
{
    // Add the attribute Flags or FlagsAttribute.
    [Flags]
    public enum RequestStatus
    {

        [Description("Pending")]
        PENDING,

    }
}