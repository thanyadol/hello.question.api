﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.APIs.Models
{
    [Flags]
    public enum TankType
    {
        [Description("Fuel")]
        FUEL = 1,
        [Description("Liquid bulk")]
        LIQUID_BULK = 3,
        [Description("Pot Water")]
        POT_WATER = 4,
        [Description("Dry bulk")]
        DRY_BULK = 5,
    }
}
