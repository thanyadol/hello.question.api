﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.APIs.Models
{
    [Flags]
    public enum LocationStatus
    {
        [Description("Skipped")]
        SKIPPED,
    }

}
