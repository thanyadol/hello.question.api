﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.APIs.Models
{
    public class Location
    {
        public int DORPlatformId { get; set; }
        public string PlatformCode { get; set; }
        public string PlatformName { get; set; }
        public decimal? Latitude { get; set; }
        public decimal? Longitude { get; set; }
        public int LocationTypeId { get; set; }
        public string LocationTypeName { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsActive { get; set; }
        public string Asset { get; set; }
        public string AssetColor { get; set; }
    }

    public class LocationListAsync
    {
        public IEnumerable<Location> locations { get; set; }
    }
}
