﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.APIs.Models
{
    public class Mmr
    {
        public int MaterialRequestDetailsId { get; set; }
        public int MaterialRequestId { get; set; }
        public string RequestStatus { get; set; }
        public DateTime? SubmitDate { get; set; }
        public DateTime? PlannedDispatchDate { get; set; }
        public DateTime? RosDate { get; set; }
        public int PriorityId { get; set; }
        public string Priority { get; set; }
        public string RentalCost { get; set; }
        public string Asset { get; set; }
        public int DepartmentId { get; set; }
        public string Department { get; set; }
        public int OriginId { get; set; }
        public string Origin { get; set; }
        public int DestinationId { get; set; }
        public string Destination { get; set; }
        public string ItemType { get; set; }
        public string MaterialDescription { get; set; }
        public decimal? QuantityUnitId { get; set; }
        public string QuantityUnit { get; set; }
        public decimal? QuantityValue { get; set; }
        public int? WeightUnitId { get; set; }
        public string WeightUnit { get; set; }
        public decimal? WeightValue { get; set; }
        public decimal? TotalWeight { get; set; }
        public decimal? Length { get; set; }
        public decimal? Width { get; set; }
        public decimal? Height { get; set; }
        public decimal? Area { get; set; }
        public string ContainerOwner { get; set; }
        public string Consignee { get; set; }
        public string Vendor { get; set; }
        public bool? Hazmat { get; set; }
        public string ReasonForPostpone { get; set; }
        public string Remarks { get; set; }
        public string UnNumber { get; set; }
        public int? MaterialClassId { get; set; }
        public string MaterialClass { get; set; }
        public int? UserId { get; set; }
        public string LastModifiedBy { get; set; }
        public string OrderNumber { get; set; }
        public int? PlannedVesselId { get; set; }
        public string PlannedVesselName { get; set; }
        public DateTime? SevenDayPlannedDispatchDate { get; set; }
        public int? ActualVesselId { get; set; }
        public string ActualVesselName { get; set; }
        public bool? InnerItemExists { get; set; }
        public int? ContainerId { get; set; }
        public int? PackageId { get; set; }
        public int? LoosePieceId { get; set; }
        public int? BundleId { get; set; }
        public int? TubularId { get; set; }
        public int? JointId { get; set; }
        public int? DeliveryLocationId { get; set; }
        public bool? IsAssignedToVessel { get; set; }
        public bool? IsDeleted { get; set; }
    }

    public class MmrListAsync
    {
        public IEnumerable<Mmr> AllMaterialList { get; set; }
    }
}
