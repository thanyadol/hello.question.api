﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.APIs.Models
{
    public class Vessel
    {
        public int VesselId { get; set; }
        public string VesselName { get; set; }
        public int VesselTypeId { get; set; }
        public string VesselType { get; set; }
        public int VesselStatusId { get; set; }
        public string VesselStatus { get; set; }
        public double Speed { get; set; }
        public decimal MaxSpeed { get; set; }
        public DateTime? EtaAtJettyDateTime { get; set; }
        public int? BaseJettyId { get; set; }
        public string BaseJetty { get; set; }
        public VesselSpecification VesselSpecification { get; set; }
    }

    public class VesselSpecification
    {
        public decimal? EffectiveDeadWeight { get; set; }
        public decimal? EffectiveDeckSpace { get; set; }
        public decimal? EffectivePotWater { get; set; }
        public decimal? EffectiveDrillWater { get; set; }
        public decimal? DieselTankCapacity { get; set; }
        public decimal? ActualFuelTanksTotal { get; set; }
        public decimal? SaralineTank { get; set; }
        public decimal? Saraline { get; set; }
        public decimal? SaralinePerTank { get; set; }
        public decimal? Barite { get; set; }
        public decimal? BaritePerTank { get; set; }
        public decimal? BariteTank { get; set; }
        public decimal? HCement { get; set; }
        public decimal? HCementPerTank { get; set; }
        public decimal? HCementTank { get; set; }
        public decimal? BhiCement { get; set; }
        public decimal? BhiCementPerTank { get; set; }
        public decimal? BhiCementTank { get; set; }
    }

    public class VesselListAsync
    {
        public IEnumerable<Vessel> vesselInfoList { get; set; }
    }
}
