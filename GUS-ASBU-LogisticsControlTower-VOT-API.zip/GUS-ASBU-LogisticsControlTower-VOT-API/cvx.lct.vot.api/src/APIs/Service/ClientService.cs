using System;

using System.Collections.Generic;
using System.Linq;
//using System.Reflection.PortableExecutable;
using System.Threading.Tasks;
using cvx.lct.vot.api.Exceptions;
using cvx.lct.vot.api.Extensions;

//vot
using cvx.lct.vot.api.APIs.Models;
using Newtonsoft.Json;

//logg
using Serilog;
using Microsoft.ApplicationInsights;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using cvx.lct.vot.api.APIs.Exceptions;
using System.Text;
using System.Net.Http.Headers;

using TravelPublishParams = cvx.lct.vot.api.Models.TravelPublishParams;

namespace cvx.lct.vot.api.APIs.Services
{
    public interface IClientService
    {
        Task<IEnumerable<VesselAsync>> ListVesselAsync();
        Task<IEnumerable<MmrAsync>> ListTaskAsync();

        Task<IEnumerable<LocationAsync>> ListLocationAsync();
        Task<IEnumerable<LocationAsync>> ListLocationColorAsync();
        // Task<IEnumerable<CusterAsync>> ListCusterAsync();
        Task<IEnumerable<VesselRouteAsync>> ListVesselRouteAsync();

        Task<IEnumerable<VesselRouteDetailAsync>> ListVesselRouteDetailAsync();
        Task<IEnumerable<VesselRouteDetailAsync>> ListVesselCurrentPlanAsync();

        Task<IEnumerable<VesselSpecAsync>> ListVesselSpecificationAsync();

        Task<IEnumerable<VesselBookActivityAsync>> ListBookActivityAsync();
        Task<IEnumerable<VesselBookActivityAsync>> ListBookActivityAsync(DateTime start, DateTime end);
        Task<IEnumerable<VesselActivityTypeAsync>> ListActivityTypeAsync();
        Task<IEnumerable<VesselTankAsync>> ListVesselTanksAsync();
        Task<IEnumerable<BulkTypeAsync>> ListBulkTypesAsync();


        Task<PublishAsync> PublishTravelAsync(api.Models.TravelPublishParams entity);
    }

    public class ClientService : IClientService
    {
        private readonly HttpClient _httpClient;

        //private string _remoteServiceBaseUrl; // = "https://localhost:5001";
        private string _remoteLCTServiceBaseUrl;

        private static TelemetryClient _telemetry { get; set; }

        private readonly IConfiguration _configuration;

        public ClientService(HttpClient httpClient, IConfiguration configuration)
        {
            // _httpClient = httpClient;
            _configuration = configuration;

            //var credentialsCache = new CredentialCache { { uri, "NTLM", CredentialCache.DefaultNetworkCredentials } };
            //var handler = new HttpClientHandler { Credentials = credentialsCache };

            // Create an HttpClientHandler object and set to use default credentials
            HttpClientHandler handler = new HttpClientHandler();
            handler.UseDefaultCredentials = true;
            handler.ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator;
            //handler.UseProxy = false;

            // handler.Credentials = new NetworkCredential("svc-bkkhq-surface-dv", "svc-bkkhq-surface-dv", "CT");

            // Create an HttpClient object
            _httpClient = new HttpClient(handler);

            //_remoteServiceBaseUrl = _configuration["ApiSettings:RemoteServiceBaseUrl"];
            _remoteLCTServiceBaseUrl = _configuration["LctConfig:Host"];

            //for proxy authen
            /* HttpClientHandler handler = new HttpClientHandler();
            handler.UseDefaultCredentials = true;
            handler.ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator;
            //handler.UseProxy = false;

            // Omit this part if you don't need to authenticate with the web server:
            handler.DefaultProxyCredentials = System.Net.CredentialCache.DefaultNetworkCredentials;

            _httpClient = new HttpClient(handler: handler, disposeHandler: true);
            //client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", "token");
            _httpClient.DefaultRequestHeaders.Accept.Clear();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            _remoteLCTServiceBaseUrl = _configuration["LctConfig:Host"];*/
        }

        //
        // Summary:
        //   list all status vessel from LCT
        //
        // Returns:
        //    vessel list
        //
        public async Task<IEnumerable<VesselAsync>> ListVesselAsync()
        {
            var url = _configuration["LctConfig:VesselUrl"];
            //LCT enpoint
            var uri = new Uri(_remoteLCTServiceBaseUrl + url);

            //call
            //ar result = await _httpClient.GetStringAsync(uri);

            // Act
            var result = new HttpResponseMessage();

            try
            {
                result = await _httpClient.GetAsync(uri);
                result.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var vessels = JsonConvert.DeserializeObject<VesselListAsync>(httpReponse);

            var entities = vessels.vesselInfoList.Select(s => new VesselAsync
            {
                Id = s.VesselId,
                Name = s.VesselName,
                TypeId = s.VesselTypeId,
                Type = s.VesselType,
                Status = s.VesselStatus,
                StatusId = s.VesselStatusId,
                MaxSpeed = s.MaxSpeed,
                Speed = s.Speed,
                //Date = null,
                Specfication = new VesselSpecAsync
                {
                    VesselId = s.VesselId,
                    Barite = s.VesselSpecification.Barite,
                    BaritePerTank = s.VesselSpecification.BaritePerTank,
                    BariteTank = s.VesselSpecification.BariteTank,
                    BhiCement = s.VesselSpecification.BhiCement,
                    BhiCementPerTank = s.VesselSpecification.BhiCementPerTank,
                    BhiCementTank = s.VesselSpecification.BhiCementTank,
                    DieselTankCapacity = s.VesselSpecification.ActualFuelTanksTotal,
                    EffectiveDeadWeight = s.VesselSpecification.EffectiveDeadWeight,
                    EffectiveDeckSpace = s.VesselSpecification.EffectiveDeckSpace,
                    EffectiveDrillWater = s.VesselSpecification.EffectiveDrillWater,
                    EffectivePotWater = s.VesselSpecification.EffectivePotWater,
                    HCement = s.VesselSpecification.HCement,
                    HCementPerTank = s.VesselSpecification.HCementPerTank,
                    HCementTank = s.VesselSpecification.HCementTank,
                    Saraline = s.VesselSpecification.Saraline,
                    SaralinePerTank = s.VesselSpecification.SaralinePerTank,
                    SaralineTank = s.VesselSpecification.SaralineTank
                }
            });

            return entities;
        }

        //
        // Summary:
        //   list all status mmrs tasks from LCT
        //
        // Returns:
        //    task list
        //
        public async Task<IEnumerable<MmrAsync>> ListTaskAsync()
        {
            var url = _configuration["LctConfig:MrrUrl"];
            //LCT enpoint
            var uri = new Uri(_remoteLCTServiceBaseUrl + url);

            //call
            //ar result = await _httpClient.GetStringAsync(uri);

            // Act
            var result = new HttpResponseMessage();

            try
            {
                result = await _httpClient.GetAsync(uri);
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var mmrs = JsonConvert.DeserializeObject<MmrListAsync>(httpReponse);

            var entities = mmrs.AllMaterialList.Select(s => new MmrAsync
            {
                MRMaterialRequestId = s.MaterialRequestId,
                MRMaterialRequestDetailsId = s.MaterialRequestDetailsId,
                Destination = s.Destination,
                DestinationId = s.DestinationId,
                MaterialDescription = s.MaterialDescription,
                ActualVesselId = s.ActualVesselId,
                ActualVesselName = s.ActualVesselName,
                Area = s.Area,
                Asset = s.Asset,
                Consignee = s.Consignee,
                ContainerOwner = s.ContainerOwner,
                Department = s.Department,
                Hazmat = s.Hazmat,
                Height = s.Height,
                InnerItemExist = Convert.ToInt32(s.InnerItemExists),
                IsAssignedToVessel = s.IsAssignedToVessel,
                IsDeleted = s.IsDeleted,
                ItemType = s.ItemType,
                RentalCost = s.RentalCost,
                Remarks = s.Remarks,
                ReasonForPostpone = s.ReasonForPostpone,
                QuantityValue = s.QuantityValue,
                QuantityUnit = s.QuantityUnit,
                Priority = s.Priority,
                RequestStatus = s.RequestStatus,
                PlannedVesselId = s.PlannedVesselId,
                PlannedDispatchDate = s.PlannedDispatchDate,// == null ? s.PlannedDispatchDate : TimeZoneInfo.ConvertTimeFromUtc(s.PlannedDispatchDate.Value, estTimeZone),
                LastModifiedBy = s.LastModifiedBy,
                LCTMRNumber = s.MaterialRequestId,
                Length = s.Length,
                MaterialClass = s.MaterialClass,
                MaterialLongDescription = "",
                MRBundleId = s.BundleId,
                MRContainerId = s.ContainerId,
                MRDeliveryLocationId = s.DeliveryLocationId,
                MRDepartmentId = s.DepartmentId,
                MRJointId = s.JointId,
                MRLoosePieceId = s.LoosePieceId,
                MRMaterialClassId = s.MaterialClassId,
                MRPackageId = s.PackageId,
                MRPriorityId = s.PriorityId,
                MRQuantityUnitId = (int)s.QuantityUnitId,
                MRTubularId = s.TubularId,
                MRWeightUnitId = s.WeightUnitId,
                OrderNumber = s.OrderNumber,
                Origin = s.Origin,
                OriginId = s.OriginId,
                PlannedVesselName = s.PlannedVesselName,
                ROSDate = s.RosDate,// == null ? s.RosDate : TimeZoneInfo.ConvertTimeFromUtc(s.RosDate.Value, estTimeZone),
                SevenDayPlannedDispatchDate = s.SevenDayPlannedDispatchDate,// == null ? s.SevenDayPlannedDispatchDate : TimeZoneInfo.ConvertTimeFromUtc(s.SevenDayPlannedDispatchDate.Value, estTimeZone),
                SubmitDate = s.SubmitDate,// == null ? s.SubmitDate : TimeZoneInfo.ConvertTimeFromUtc(s.SubmitDate.Value, estTimeZone),
                TotalWeight = s.TotalWeight,
                UNNumber = s.UnNumber,
                UserId = s.UserId,
                Vendor = s.Vendor,
                WeightUnit = s.WeightUnit,
                WeightValue = s.WeightValue,
                Width = s.Width
            });

            return entities;
        }

        //
        // Summary:
        //    Return a list of location with cluster from lct
        //
        // Returns:
        //    list of location
        //
        public async Task<IEnumerable<LocationAsync>> ListLocationAsync()
        {

            var url = _configuration["LctConfig:LocationUrl"];
            //LCT enpoint
            var uri = new Uri(_remoteLCTServiceBaseUrl + url);

            //call
            //ar result = await _httpClient.GetStringAsync(uri);

            // Act
            var result = new HttpResponseMessage();

            try
            {
                result = await _httpClient.GetAsync(uri);
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var locations = JsonConvert.DeserializeObject<LocationListAsync>(httpReponse);

            var entities = locations.locations.Select(s => new LocationAsync
            {
                Id = s.DORPlatformId,
                DORPlatformId = s.DORPlatformId,
                Code = s.PlatformCode,
                IsActive = s.IsActive,
                IsDeleted = s.IsDeleted,
                Latitude = s.Latitude,
                LocationTypeId = s.LocationTypeId,
                Longitude = s.Longitude,
                Name = s.PlatformName,
                Type = s.LocationTypeName,
                Asset = s.Asset,
                AssetColor = s.AssetColor
            });

            return entities;
        }


        public async Task<IEnumerable<VesselRouteAsync>> ListVesselRouteAsync()
        {
            await Task.Delay(0);
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<VesselSpecAsync>> ListVesselSpecificationAsync()
        {
            await Task.Delay(0);
            throw new NotImplementedException();
        }

        //
        // Summary:
        //    Return a daily route and confirm route status from lct
        //
        // Returns:
        //    list vessel route
        //
        public async Task<IEnumerable<VesselRouteDetailAsync>> ListVesselRouteDetailAsync()
        {

            var url = _configuration["LctConfig:VesselPlanUrl"];
            //LCT enpoint
            var uri = new Uri(_remoteLCTServiceBaseUrl + url);

            //call
            //ar result = await _httpClient.GetStringAsync(uri);

            // Act
            var result = new HttpResponseMessage();

            try
            {
                result = await _httpClient.GetAsync(uri);
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var routes = JsonConvert.DeserializeObject<RouteListAsync>(httpReponse);

            var entities = routes.AllRoutePlanList.Select(s => new VesselRouteDetailAsync
            {
                Id = s.VesselId,
                //RouteId = 0,
                SequenceNumber = s.SequenceNumber,
                ToId = s.DestinationId,
                FromId = s.OriginId,
                ETA = s.Eta,
                ETD = s.Etd,
                UpdatedETA = s.UpdatedETA,
                UpdatedETD = s.UpdatedETD,
                StatusId = s.RouteStatusId,
                IsActual = s.IsActual,
                IsCurrent = s.IsCurrent
            });

            return entities;

        }


        //
        // Summary:
        //    Return a booked vessel activity from lct
        //
        // Returns:
        //    list vessel booked
        //
        public async Task<IEnumerable<VesselBookActivityAsync>> ListBookActivityAsync()
        {
            var url = _configuration["LctConfig:VesselBookActivityUrl"];
            //LCT enpoint
            var uri = new Uri(_remoteLCTServiceBaseUrl + url);

            //call
            //ar result = await _httpClient.GetStringAsync(uri);

            // Act
            var result = new HttpResponseMessage();

            try
            {
                result = await _httpClient.GetAsync(uri);
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var bookeds = JsonConvert.DeserializeObject<BookedList>(httpReponse);

            var entities = bookeds.votBookingActivityList.Select(s => new VesselBookActivityAsync
            {
                BookedActivityId = s.BookedActivityId,
                VesselId = s.VesselId,
                VesselName = s.VesselName,
                ActivityDescription = s.ActivityDescription,
                ActivityDetails = s.ActivityDetails,
                ActivityInfo = s.ActivityInfo,
                ActivityType = s.ActivityType,
                ActivityTypeId = s.ActivityTypeId,
                StartDate = s.StartDate,// == null ? s.StartDate : TimeZoneInfo.ConvertTimeFromUtc(s.StartDate.Value, estTimeZone),
                EndDate = s.EndDate,// == null ? s.EndDate : TimeZoneInfo.ConvertTimeFromUtc(s.EndDate.Value, estTimeZone),
                DORPlatformId = s.DorPlatformId,
                RigId = s.RigId,
                RigMoveId = s.RigMoveId,
                IsDeleted = s.IsDeleted,
                //CreatedDate = null,
                //DataSource = "",
                //CreatedBy = "",
                //LastModifiedBy = "",
                //LastModifiedDate = ""
            });

            return entities;

        }

        //
        // Summary:
        //     Return a booked vessel activity from lct
        //
        // Returns:
        //    list vessel route
        // Params:
        //  start:  date start
        //  end:  date end
        public async Task<IEnumerable<VesselBookActivityAsync>> ListBookActivityAsync(DateTime start, DateTime end)
        {
            var url = _configuration["LctConfig:VesselBookActivityUrl"];
            //LCT enpoint
            var uri = new Uri(_remoteLCTServiceBaseUrl + url + $"?startDate={JsonConvert.SerializeObject(start).Replace("\"", "")}&EndDate={JsonConvert.SerializeObject(end).Replace("\"", "")}");

            //call
            //ar result = await _httpClient.GetStringAsync(uri);

            // Act
            var result = new HttpResponseMessage();

            try
            {
                result = await _httpClient.GetAsync(uri);
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var bookeds = JsonConvert.DeserializeObject<BookedList>(httpReponse);

            bookeds.StartDate = start;
            bookeds.EndDate = end;

            var entities = new List<VesselBookActivityAsync>();
            if (bookeds.votBookingActivityList != null)
            {
                entities = bookeds.votBookingActivityList.Select(s => new VesselBookActivityAsync
                {
                    BookedActivityId = s.BookedActivityId,
                    VesselId = s.VesselId,
                    VesselName = s.VesselName,
                    ActivityDescription = s.ActivityDescription,
                    ActivityDetails = s.ActivityDetails,
                    ActivityInfo = s.ActivityInfo,
                    ActivityType = s.ActivityType,
                    ActivityTypeId = s.ActivityTypeId,
                    StartDate = s.StartDate,// == null ? s.StartDate : TimeZoneInfo.ConvertTimeFromUtc(s.StartDate.Value, estTimeZone),
                    EndDate = s.EndDate,// == null ? s.EndDate : TimeZoneInfo.ConvertTimeFromUtc(s.EndDate.Value, estTimeZone),
                    DORPlatformId = s.DorPlatformId,
                    RigId = s.RigId,
                    RigMoveId = s.RigMoveId,
                    IsDeleted = s.IsDeleted,
                }).ToList();
            }
            return entities;
        }

        public async Task<IEnumerable<VesselActivityTypeAsync>> ListActivityTypeAsync()
        {
            await Task.Delay(0);
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<VesselTankAsync>> ListVesselTanksAsync()
        {
            await Task.Delay(0);
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<BulkTypeAsync>> ListBulkTypesAsync()
        {
            await Task.Delay(0);
            throw new NotImplementedException();
        }


        public async Task<IEnumerable<VesselRouteDetailAsync>> ListVesselCurrentPlanAsync()
        {
            //TimeZoneInfo estTimeZone = TimeZoneInfo.FindSystemTimeZoneById("SE Asia Standard Time");
            //DateTime estDateTime = TimeZoneInfo.ConvertTimeFromUtc(timeUtc, estTimeZone);

            var url = _configuration["LctConfig:VesselPlanUrl"];
            //LCT enpoint
            var uri = new Uri(_remoteLCTServiceBaseUrl + url);

            //call
            //ar result = await _httpClient.GetStringAsync(uri);
            // Act
            var result = new HttpResponseMessage();

            try
            {
                result = await _httpClient.GetAsync(uri);
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var currents = JsonConvert.DeserializeObject<RouteListAsync>(httpReponse);

            var entities = currents.AllRoutePlanList.Select(s => new VesselRouteDetailAsync
            {
                VesselId = s.VesselId,
                SequenceNumber = s.SequenceNumber,
                OriginId = s.OriginId,
                DestinationId = s.DestinationId,
                UpdatedETA = s.UpdatedETA,// == null ? s.First().UpdatedETA : TimeZoneInfo.ConvertTimeFromUtc(s.First().UpdatedETA.Value, estTimeZone),
                UpdatedETD = s.UpdatedETD,// == null ? s.First().UpdatedETD : TimeZoneInfo.ConvertTimeFromUtc(s.First().UpdatedETD.Value, estTimeZone),
                Eta = s.Eta,//TimeZoneInfo.ConvertTimeFromUtc(s.First().Eta, estTimeZone),
                Etd = s.Etd,//TimeZoneInfo.ConvertTimeFromUtc(s.First().Etd, estTimeZone),
                RouteStatusId = s.RouteStatusId,
                IsActual = s.IsActual,
                IsCurrent = s.IsCurrent,
                LocationStatus = s.LocationStatus,
                IsDeleted = s.IsDeleted,
            });

            //var temp = entities.Where(c => c.VesselId == 22).OrderBy(c => c.SequenceNumber);

            return entities;
        }

        public async Task<IEnumerable<LocationAsync>> ListLocationColorAsync()
        {

            var url = _configuration["LctConfig:LocationUrl"];
            //LCT enpoint
            var uri = new Uri(_remoteLCTServiceBaseUrl + url);

            //call
            //ar result = await _httpClient.GetStringAsync(uri);
            // Act
            var result = new HttpResponseMessage();

            try
            {
                result = await _httpClient.GetAsync(uri);
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPGET", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();
            var locations = JsonConvert.DeserializeObject<LocationListAsync>(httpReponse);

            var entities = locations.locations.Select(s => new LocationAsync
            {
                Id = s.DORPlatformId,
                Code = s.PlatformCode,
                IsActive = s.IsActive,
                IsDeleted = s.IsDeleted,
                Latitude = s.Latitude,
                LocationTypeId = s.LocationTypeId,
                Longitude = s.Longitude,
                Name = s.PlatformName,
                Type = s.LocationTypeName,
                Asset = s.Asset,
                AssetColor = s.AssetColor
            });

            return entities;
        }

        public async Task<PublishAsync> PublishTravelAsync(TravelPublishParams entity)
        {

            var url = _configuration["LctConfig:PublishUrl"];
            //LCT enpoint
            var uri = new Uri(_remoteLCTServiceBaseUrl + url);

            var json = JsonConvert.SerializeObject(entity);
            var buffer = Encoding.UTF8.GetBytes(json);
            var byteContent = new ByteArrayContent(buffer);
            byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            //   var result = await _httpClient.PostAsync(uri, byteContent);
            // Act
            var result = new HttpResponseMessage();

            try
            {
                result = await _httpClient.PostAsync(uri, byteContent);
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTPPOST", uri.ToString(), ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();

            //var httpReponse = await result.Content.ReadAsStringAsync();
            var entities = JsonConvert.DeserializeObject<PublishAsync>(httpReponse);
            return entities;
        }
    }
}