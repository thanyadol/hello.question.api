﻿using cvx.lct.vot.api.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.WindowsAzure.Storage;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Environment
{
    public sealed class Configuration
    {
        private static readonly Configuration instance = new Configuration();

        private static string Environment { get; set; }
        private static string EnvironmentName { get; set; }
        private BlobParameter _blobParameter { get; set; }
        private AzureConfigOption _azureConfigOption { get; set; }
        private LctConfigOption _lctConfigOption { get; set; }

        static Configuration()
        {

        }

        internal string GetEnvironment()
        {
            return Environment;
        }

        public static Configuration Instance
        {
            get
            {
                return instance;
            }
        }

        public string GetKeyVaultName()
        {
            return _azureConfigOption.KeyVaultName;
        }

        internal string GetQueueName()
        {
            return _azureConfigOption.BlobQueue;
        }

        public string GetCorsURL()
        {
            return _azureConfigOption.CorsUrl;
        }

        public string GetVOTDbConnectionString()
        {
            var connectionString = _azureConfigOption.DbConnKey;
            if (string.IsNullOrEmpty(connectionString))
                throw new Exception("Could not find database connection string.");
            var blobSecret = ChevronService.Instance.GetSecret(_azureConfigOption.KeyVaultName, connectionString);
            return blobSecret.Value;
        }

        public string GetVOTBlobConnectionString()
        {
            var connectionString = _azureConfigOption.BlobConnKey;
            if (string.IsNullOrEmpty(connectionString))
                throw new Exception("GetVOTBlobConnectionString Could not find blob connection string.");
            var blobSecret = ChevronService.Instance.GetSecret(_azureConfigOption.KeyVaultName, connectionString);
            return blobSecret.Value;
        }

        public string GetDatabrickToken()
        {
            var connectionString = _azureConfigOption.DatabrickTokenKey;
            if (string.IsNullOrEmpty(connectionString))
                throw new Exception("GetDatabrickToken: Could not find databricks token.");
            var blobSecret = ChevronService.Instance.GetSecret(_azureConfigOption.KeyVaultName, connectionString);
            return blobSecret.Value;
        }

        public string GetDatabrickUrl()
        {
            return _azureConfigOption.DatabrickUrl;
        }

        public string GetHostName()
        {
            return _azureConfigOption.HostName;
        }

        public string GetBlobUrl()
        {
            return _azureConfigOption.BlobUrl;

        }

        public bool IsEnableApiCall()
        {
            return _lctConfigOption.EnableApi;
        }

        public string GetBlobTemplateUrl()
        {
            return $"{GetBlobUrl()}/{GetPath().TemplatePath}/";

        }

        public string GetBlobInputUrl()
        {
            return $"{GetBlobUrl()}/{GetPath().InputPath}/";
        }

        public string GetBlobOutputUrl()
        {
            return $"{GetBlobUrl()}/{GetPath().OutputPath}/";

        }

        internal void SetConfiguration(IConfiguration configuration)
        {
            _blobParameter = configuration.GetSection("FilesOutput").Get<BlobParameter>();
            _azureConfigOption = configuration.GetSection("AzureConfig").Get<AzureConfigOption>();
            _lctConfigOption = configuration.GetSection("LctConfig").Get<LctConfigOption>();

            InitResource();
        }

        private void InitResource()
        {
            //Blob container
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(this.GetVOTBlobConnectionString());
            var blobClient = storageAccount.CreateCloudBlobClient();
            var container = blobClient.GetContainerReference(_blobParameter.OutputPath);
            Task.Run(async () =>
            {
                await container.CreateIfNotExistsAsync();
            }).Wait();
            container = blobClient.GetContainerReference(_blobParameter.InputPath);
            Task.Run(async () =>
            {
                await container.CreateIfNotExistsAsync();
            }).Wait();
            container = blobClient.GetContainerReference(_blobParameter.OutputTemplate);
            Task.Run(async () =>
            {
                await container.CreateIfNotExistsAsync();
            }).Wait();
            //Blob queue
            var _queueClient = storageAccount.CreateCloudQueueClient();
            var _queue = _queueClient.GetQueueReference(_azureConfigOption.BlobQueue);
            _queue.CreateIfNotExistsAsync();
        }

        public IEnumerable<string> AllowADGroups()
        {
            return _azureConfigOption.AllowADGroups;
        }

        public string GetDatabrickJobName()
        {
            return _azureConfigOption.DatabrickJobName;
        }

        public BlobParameter GetPath()
        {
            return _blobParameter;
        }

        public LctConfigOption GetLctConfig()
        {
            return _lctConfigOption;
        }
    }

    public class BlobParameter
    {

        public string TemplatePath { get; set; }

        public string InputPath { get; set; }
        public string OutputPath { get; set; }
        public string OutputTemplate { get; set; }
        public string ClusterFilename { get; set; }

        public string TabularFilename { get; set; }
        public string StackFilename { get; set; }
        public string MMRFileName { get; set; }
        public string VesselFileName { get; set; }
        public string VesselBookActivity { get; set; }
        public string RestrictHourFileName { get; set; }
        public string CargoPriorityFileName { get; set; }
        public string LocationBlockoutFilename { get; set; }
        public string VesselCurrentPlanFileName { get; set; }
        public string ConfigParametersFileName { get; set; }
        public string ResultFileName { get; set; }
        public string ResultExtension { get; set; }
        public string ProcessMmrFileName { get; set; }
        public string ProcessMmrExtension { get; set; }
        public string RoutePlanJson { get; set; }
        public string LoadingListJson { get; set; }
        public string MmrSummary { get; set; }
        public string VesselSummary { get; set; }
        public string VesselTurnaround { get; set; }
        public string VesselActivity { get; set; }

        public string SpotfireTemplate { get; set; }
    }

    public class AzureConfigOption
    {
        public string KeyVaultName { get; set; }
        public string BlobUrl { get; set; }
        public string BlobConnKey { get; set; }
        public string BlobQueue { get; set; }
        public string HostName { get; set; }
        public string DatabrickUrl { get; set; }
        public string DatabrickTokenKey { get; set; }
        public string DatabrickJobName { get; set; }
        public string DbConnKey { get; set; }
        public string CorsUrl { get; set; }
        public bool EnableApi { get; set; }
        public IEnumerable<string> AllowADGroups { get; set; }
    }

    public class LctConfigOption
    {
        public string Host { get; set; }
        public string MrrUrl { get; set; }
        public string VesselUrl { get; set; }
        public string VesselBookActivityUrl { get; set; }
        public string VesselPlanUrl { get; set; }
        public string LocationUrl { get; set; }
        public string PublishUrl { get; set; }
        public bool EnableApi { get; set; }
        public string PublishPurpose { get; set; }
        public int PublishPurposeId { get; set; }
    }

}