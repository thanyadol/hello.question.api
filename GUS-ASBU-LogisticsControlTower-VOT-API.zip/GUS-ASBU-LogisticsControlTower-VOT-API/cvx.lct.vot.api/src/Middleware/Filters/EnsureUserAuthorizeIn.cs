using System;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Net.Http.Headers;
using System.Security.Principal;
using System.Threading.Tasks;
using Chevron.Identity;
using Chevron.Identity.AspNet.Client;
using cvx.lct.vot.api.Exceptions;
using cvx.lct.vot.api.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Options;
using Microsoft.Graph;

namespace cvx.lct.vot.api.Filters
{
    /* public abstract class ActionFilterAttribute : Attribute, IActionFilter, IFilterMetadata, 
                IAsyncActionFilter, IResultFilter, IAsyncResultFilter, IOrderedFilter
    {

    }*/

    /* 
    public class AsyncActionFilterExample : IAsyncActionFilter
    {
        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            // execute any code before the action executes
            var result = await next();
            // execute any code after the action executes
        }
    }*/

    public class EnsureUserAuthorizeInAsync : IAsyncActionFilter
    {

        private readonly IAzureADOptions _options;
        private readonly ITokenManagerProvider _tokenManager;
        private readonly ICvxHttpClient _client;
        private GraphServiceClient _graphClient;
        private readonly IHttpContextAccessor _httpContextAccessor;

        // private readonly IUserService _userService;
        public EnsureUserAuthorizeInAsync(IHttpContextAccessor httpContextAccessor,
               IOptionsMonitor<AzureADOptions> optionsAccessor, ITokenManagerProvider tokenManager, ICvxHttpClient client)

        {
            _options = optionsAccessor.CurrentValue;
            _client = client ?? throw new ArgumentNullException(nameof(client));
            _tokenManager = tokenManager ?? throw new ArgumentNullException(nameof(tokenManager));
            _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
            //_userService = userService ?? throw new ArgumentNullException(nameof(userService));
        }


        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            //var 
            if (!context.HttpContext.User.Identity.IsAuthenticated)
            {
                throw new UserNotAuthenException();
            }

            if (!this.IsAssignedAdGroup())
                throw new UserNotAuthorizeException();

            //return;

            // next() calls the action method.
            var resultContext = await next();
            // resultContext.Result is set.
            // Do something after the action executes.
        }


        public bool IsAssignedAdGroup()
        {
            IPrincipal principal = _httpContextAccessor.HttpContext.User;
            var User = new CvxClaimsPrincipal(principal);

            if (!User.IsUser) //Check by scope
                return true;

            this.GetAuthenticatedClient();

            var groupIds = Environment.Configuration.Instance.AllowADGroups();
            var isMember = false;
            Task.Run(async () =>
            {
                var checkMember = await _graphClient.DirectoryObjects[User.ObjectId]
                .CheckMemberGroups(groupIds)
                .Request()
                .PostAsync();

                isMember = checkMember.Count > 0;

            }).Wait();

            return isMember;
        }


        public GraphServiceClient GetAuthenticatedClient()
        {
            if (_graphClient != null)
                return _graphClient;

            _graphClient = new GraphServiceClient(new DelegateAuthenticationProvider(
                async requestMessage =>
                {
                    IPrincipal principal = _httpContextAccessor.HttpContext.User;

                    Credentials creds = new Credentials()
                    {
                        User = new CvxClaimsPrincipal(principal),
                        Options = _options,
                        Scopes = _options.GraphScopes
                    };

                    string accessToken = accessToken = await _tokenManager.GetOboAccessTokenAsync(creds);

                    requestMessage.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

                }));

            return _graphClient;
        }
    }

    public class EnsureUserAuthorizeIn : ActionFilterAttribute
    {

        public EnsureUserAuthorizeIn()
        {

        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {

        }

    }
}

