using System;
using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Services
{
    public class JobHubMiddleware : Hub
    {

        private readonly IJobHubService _jobService;
        private readonly ITravelHubService _travelService;

        public JobHubMiddleware(IJobHubService jobService, ITravelHubService travelService)
        {
            _jobService = jobService ?? throw new ArgumentNullException(nameof(jobService));
            _travelService = travelService ?? throw new ArgumentNullException(nameof(travelService));
        }

        public async Task PullAsync()
        {
            var entity = await _jobService.ListParamsAsync();
            await Clients.Caller.SendAsync("PullAsync", entity);
        }


        public async Task PublishAsync()
        {
            var entity = await _travelService.ListRecentlyActivityAsync();
            await Clients.Caller.SendAsync("PublishAsync", entity);
        }

        public async Task RunAsync(Guid id)
        {
            var entity = await _jobService.GetRecentlyParamsAsync(id);
            await Clients.Caller.SendAsync("RunAsync", entity);
        }
    }
}