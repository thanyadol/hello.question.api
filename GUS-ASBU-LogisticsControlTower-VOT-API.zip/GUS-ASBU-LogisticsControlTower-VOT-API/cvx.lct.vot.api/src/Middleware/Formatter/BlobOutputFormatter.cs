
using cvx.lct.vot.api.Services;
using Microsoft.AspNetCore.Mvc.Formatters;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace cvx.lct.vot.api.Formatters
{
    /// <summary>
    /// Original code taken from
    /// http://www.tugberkugurlu.com/archive/creating-custom-csvmediatypeformatter-in-asp-net-web-api-for-comma-separated-values-csv-format
    /// Adapted for ASP.NET Core and uses ; instead of , for delimiters
    /// </summary>
    public class BlobOutputFormatter : OutputFormatter
    {
        private readonly BlobFormatterOptions _options;
        private readonly IAzureService _azureService;
        private readonly bool useJsonAttributes = true;

        public string ContentType { get; private set; }

        public BlobOutputFormatter(BlobFormatterOptions blobFormatterOptions, IAzureService azureService)
        {
            ContentType = "text/blob";
            SupportedMediaTypes.Add(Microsoft.Net.Http.Headers.MediaTypeHeaderValue.Parse("text/blob"));
            _options = blobFormatterOptions ?? throw new ArgumentNullException(nameof(blobFormatterOptions));


            _azureService = azureService ?? throw new ArgumentNullException(nameof(azureService));

        }

        protected override bool CanWriteType(Type type)
        {

            if (type == null)
                throw new ArgumentNullException("type");

            return IsTypeOfIEnumerable(type);
        }

        private bool IsTypeOfIEnumerable(Type type)
        {
            if (type == null)
                throw new ArgumentNullException("type");

            return typeof(IEnumerable).IsAssignableFrom(type);
        }

        /// <summary>
        /// Returns the JsonProperty data annotation name
        /// </summary>
        /// <param name="pi">Property Info</param>
        /// <returns></returns>
        private string GetDisplayNameFromNewtonsoftJsonAnnotations(PropertyInfo pi)
        {
            if (pi.GetCustomAttribute<JsonPropertyAttribute>(false)?.PropertyName is string value)
            {
                return value;
            }

            return pi.GetCustomAttribute<DisplayAttribute>(false)?.Name ?? pi.Name;
        }

        public async override Task WriteResponseBodyAsync(OutputFormatterWriteContext context)
        {
            var response = context.HttpContext.Response;
            Stream originalBody = response.Body;

            Type type = context.Object.GetType();
            Type itemType;

            if (type.GetGenericArguments().Length > 0)
            {
                itemType = type.GetGenericArguments()[0];
            }
            else
            {
                itemType = type.GetElementType();
            }

            //stream to file
            var streamWriter = new MemoryStream();// new StreamWriter(response.Body, _options.Encoding);

            if (_options.IncludeExcelDelimiterHeader)
            {
                var writeVal = new string($"sep ={_options.CsvDelimiter}\n");
                await streamWriter.WriteAsync(_options.Encoding.GetBytes(writeVal), 0, writeVal.Length);
            }

            if (_options.UseSingleLineHeaderInCsv)
            {
                var values = useJsonAttributes
                    ? itemType.GetProperties().Where(pi => !pi.GetCustomAttributes<JsonIgnoreAttribute>(false).Any())    // Only get the properties that do not define JsonIgnore
                        .Select(pi => new
                        {
                            Order = pi.GetCustomAttribute<JsonPropertyAttribute>(false)?.Order ?? 0,
                            Prop = pi
                        }).OrderBy(d => d.Order).Select(d => GetDisplayNameFromNewtonsoftJsonAnnotations(d.Prop))
                    : itemType.GetProperties().Select(pi => pi.GetCustomAttribute<DisplayAttribute>(false)?.Name ?? pi.Name);

                var writeVal = string.Join(_options.CsvDelimiter, values) + "\n";
                await streamWriter.WriteAsync(_options.Encoding.GetBytes(writeVal), 0, writeVal.Length);
            }


            foreach (var obj in (IEnumerable<object>)context.Object)
            {
                var vals = useJsonAttributes
                    ? obj.GetType().GetProperties()
                        .Where(pi => !pi.GetCustomAttributes<JsonIgnoreAttribute>().Any())
                        .Select(pi => new
                        {
                            Order = pi.GetCustomAttribute<JsonPropertyAttribute>(false)?.Order ?? 0,
                            Value = pi.GetValue(obj, null)
                        }).OrderBy(d => d.Order).Select(d => new { d.Value })
                    : obj.GetType().GetProperties().Select(
                        pi => new
                        {
                            Value = pi.GetValue(obj, null)
                        });

                string valueLine = string.Empty;

                foreach (var val in vals)
                {
                    if (val.Value != null)
                    {

                        var _val = val.Value.ToString();

                        //Escape quotas
                        _val = _val.Replace("\"", "\"\"");

                        //Check if the value contans a delimiter and place it in quotes if so
                        if (_val.Contains(_options.CsvDelimiter))
                            _val = string.Concat("\"", _val, "\"");

                        //Replace any \r or \n special characters from a new line with a space
                        if (_val.Contains("\r"))
                            _val = _val.Replace("\r", " ");
                        if (_val.Contains("\n"))
                            _val = _val.Replace("\n", " ");

                        valueLine = string.Concat(valueLine, _val, _options.CsvDelimiter);

                    }
                    else
                    {
                        valueLine = string.Concat(valueLine, string.Empty, _options.CsvDelimiter);
                    }
                }

                var writeVal = valueLine.Remove(valueLine.Length - _options.CsvDelimiter.Length) + "\n";
                await streamWriter.WriteAsync(_options.Encoding.GetBytes(writeVal), 0, writeVal.Length);
            }

            //write file to azure
            streamWriter.Position = 0;
            var strUri = await _azureService.UploadBlobAsync(new Uri($"{ Environment.Configuration.Instance.GetBlobUrl() }/lct-processed-input-data/{ itemType.GUID }/{ itemType.Name }.csv"), streamWriter);

            streamWriter.Position = 0;
            await streamWriter.CopyToAsync(originalBody);

            //retrun only url of file
            await streamWriter.FlushAsync();

            response.Body.Write(_options.Encoding.GetBytes(strUri), 0, strUri.Length);
        }
    }


    //formatter option
    public class BlobFormatterOptions
    {
        public bool UseSingleLineHeaderInCsv { get; set; } = true;

        public string CsvDelimiter { get; set; } = ";";

        public Encoding Encoding { get; set; } = Encoding.Default;

        public bool IncludeExcelDelimiterHeader { get; set; } = false;
    }
}